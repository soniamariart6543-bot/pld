# Bonefire Relics（骨火遗物）

> **服务器权威（Server-Authoritative）遗物升级系统 · Minecraft 1.20.1 · Fabric + Forge 双加载器**

开局发放的整套遗物装备与升级玩法：无尽镐、战利品骨头、遗物法杖、骨甲、教程书「骨与火」、野生果奶——全部通过升级界面消耗经验与材料成长，数据由服务端权威校验，防作弊、防丢弃、防销毁。

A server-authoritative relic upgrade system for Minecraft 1.20.1: endless pickaxe, loot bone, relic wand, bone armor with skills, guide book and more — dual-loader (Fabric / Forge).

---

## ✨ 功能特性 Features

| 遗物 | 特性 |
|---|---|
| **无尽镐** | 永不损耗（不可破坏）；时运/效率可升级；挖掘技能「补给」——每挖 150 方块获得 5 秒补给（回饥饿+饱食） |
| **战利品骨头** | 攻击伤害/火焰附加/抢夺/时运可升级；「骨火」技能随攻击力成长；火焰附加 II 时 1.2% 概率**秒杀** |
| **遗物法杖** | 与骨头一体两面随时切换（各自独立升级数据）；追踪火球直线发射（240 格射程）；法术强度/吸血/爆炸升级；灵魂蓝焰形态附加凋零 |
| **遗物骨甲** | 骨 → 钻石骨甲 → 下界合金骨甲材质升级（护甲值 +5/级）；「骨甲护体」受击自动触发抗性+生命恢复；**每件 +3 火焰/寒冰/奥秘法术强度**（Spell Power 适配） |
| **野生果奶** | 无限食用：每次 +8 饥饿 +8 饱食，**去除一项负面效果**，不可丢弃，紫色物品名 |
| **教程书「骨与火」** | 开局发放，右键查看全部玩法说明 |

其他系统：
- **服务器权威升级**：升级请求全部服务端校验（经验/材料/前置条件），防篡改
- **防丢弃防销毁**：全部遗物 Q 键丢不出、免疫火焰/岩浆/爆炸（虚空除外）
- **神话品质联动**（可选）：整合包装有 Tierify 时，装备类遗物固定神话（Mythic）品质，升级/切换不丢品质
- **创造模式快捷发放**：`/relic grant` 系列命令

---

## 📦 版本说明 Build Variants

| 文件 | 加载器 | 说明 |
|---|---|---|
| `BonefireRelics-6.3.8.jar` | Fabric | 标准版，无 Spell Power 依赖 |
| `BonefireRelics-6.3.8-适配版.jar` | Fabric | **Spell Power 适配版**：骨甲法强、法杖伤害体系接入 Spell Power（推荐用于含 spell_power 的整合包） |
| `BonefireRelics-6.3.8-forge.jar` | Forge | Forge 标准版，骨甲法强带**可选依赖守卫**（装了 Spell Power 才生效） |

## 🔗 依赖 Dependencies

- **必选**：
  - Fabric 版：Fabric API（0.92.2+1.20.1）
  - Forge 版：Forge 47.x（1.20.1）
- **可选**：
  - Spell Power `spell_power`（0.12.0+1.20.1）——适配版/Forge 版骨甲法强
  - Spell Engine `spell_engine`（0.15.12+1.20.1）——适配版构建依赖
  - Tierify——神话品质联动

---

## 🛠️ 构建 Build

环境要求：**JDK 17**、**Gradle 8.8**（系统安装，项目无 wrapper）。

```bash
# 设置 JDK 17
# Windows: $env:JAVA_HOME = "C:\Program Files\Java\jdk-17"

# Fabric（relic-upgrades 目录）
gradle build
# 产物：build/libs/bonefire_relics-6.3.8.jar

# Forge（relic-upgrades-forge 目录）
gradle build
# 产物：build/libs/bonefire_relics_forge-6.3.8.jar
```

> ⚠️ **适配版编译依赖说明**：Fabric 项目的 `build.gradle` 中以 `modImplementation files(...)` 引用 Spell Power / Spell Engine 的**本地 jar 路径**（默认指向本地整合包目录）。拉取源码编译前，请先将 `spell_power-0.12.0+1.20.1.jar` 与 `spell_engine-0.15.12+1.20.1.jar`（Modrinth 可下载）放到你自己的路径，并修改 `build.gradle` 中对应两行。
> 若不需要 Spell Power 适配，可直接编译标准版（不引 spell 依赖的默认配置）。

---

## 🎮 玩法指南 Quick Guide

1. 出生自动获得：无尽镐、战利品骨头（可切换法杖）、骨甲全套、教程书、野生果奶
2. 右键教程书「骨与火」了解全部机制
3. 使用升级界面（物品相关交互入口）消耗经验与材料升级各项属性
4. 骨甲需先进入下界才能穿戴（进入后永久解锁）

---

## 📄 许可 License

**MIT License** —— 自由使用、修改与分发，保留版权声明即可。

---

## 更新日志 Changelog

见 `更新日志.md` 与 `更新日志-6.3.8.docx`。
