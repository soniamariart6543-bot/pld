package cn.bmcvp.relic.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.api.distmarker.Dist;
import cn.bmcvp.relic.RelicEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * Forge 客户端：背包界面注入「遗物」按钮（ScreenEvent.Init.Post，免 Mixin）+ 按键 R 备用入口。
 */
@Mod.EventBusSubscriber(modid = cn.bmcvp.relic.BmcvpRelicUpgradesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BmcvpRelicUpgradesClient {
    private static final net.minecraft.client.KeyMapping OPEN_SCREEN = new net.minecraft.client.KeyMapping(
            "key.bmcvp_relic_upgrades.open", GLFW.GLFW_KEY_R, "key.categories.misc");

    /** 创造背包当前按钮引用（用于切标签时显隐）。 */
    private static Button creativeRelicButton;

    /**
     * 反射读取 CreativeModeInventoryScreen 的当前标签字段（私有静态 CreativeModeTab）。
     * 注意：Forge 构建经 reobfJar 混淆后字段名为 SRG（f_xxx），不能按字面名查找，
     * 改为按「static + CreativeModeTab 类型」匹配，与混淆名无关。
     */
    private static final java.lang.reflect.Field CREATIVE_SELECTED_TAB = initSelectedTabField();

    private static java.lang.reflect.Field initSelectedTabField() {
        try {
            for (java.lang.reflect.Field field : CreativeModeInventoryScreen.class.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(field.getModifiers())
                        && CreativeModeTab.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    return field;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** 当前创造背包标签是否为「背包」标签（物品库/搜索标签返回 false）。 */
    private static boolean isCreativeInventoryTab() {
        if (CREATIVE_SELECTED_TAB == null) {
            return true;
        }
        try {
            Object tab = CREATIVE_SELECTED_TAB.get(null);
            if (!(tab instanceof CreativeModeTab creativeTab)) {
                return false;
            }
            return creativeTab.getType() == CreativeModeTab.Type.INVENTORY;
        } catch (Exception ignored) {
            return true;
        }
    }

    private BmcvpRelicUpgradesClient() {
    }

    /**
     * 法杖攻击：客户端 tick 起始阶段检测攻击键按下，与 Fabric 版（START_CLIENT_TICK + attackKey）同机制。
     * 必须在 Phase.START 检测：原版 Minecraft.handleKeybinds() 在 tick 中段会先消费攻击键（consumeClick→doAttack），
     * END 阶段必然为 false。此处先消费 → 每次点击发射一发直线火球，完全无索敌。
     */
    @SubscribeEvent
    public static void onClientTickStart(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        if (!cn.bmcvp.relic.RelicService.isRelic(mc.player.getMainHandItem(), cn.bmcvp.relic.UpgradeDefinition.RelicType.WAND)) {
            return;
        }
        while (mc.options.keyAttack.consumeClick()) {
            cn.bmcvp.relic.RelicNetworking.sendToServer(new cn.bmcvp.relic.RelicNetworking.WandSwingPacket());
        }
    }

    @Mod.EventBusSubscriber(modid = cn.bmcvp.relic.BmcvpRelicUpgradesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ClientModBus {
        private ClientModBus() {
        }

        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(RelicEntities.RELIC_FIREBALL.get(), RelicFireballRenderer::new);
        }

        @SubscribeEvent
        public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
            OPEN_SCREEN.setKeyConflictContext(KeyConflictContext.IN_GAME);
            event.register(OPEN_SCREEN);
        }
    }

    /** 背包界面注入「遗物」按钮：生存背包=模式区分（创造人物右下角64,68/生存6.0原位置129,65）；创造背包=物品栏左上角上方(9,36)。 */
    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getScreen() instanceof InventoryScreen inventoryScreen) {
            boolean creative = mc.player != null && mc.player.getAbilities().instabuild;
            int offsetX = creative ? 64 : 129;
            int offsetY = creative ? 68 : 65;
            Button button = Button.builder(Component.literal("遗物"),
                            b -> mc.setScreen(new RelicUpgradeScreen(inventoryScreen)))
                    .bounds(inventoryScreen.getGuiLeft() + offsetX, inventoryScreen.getGuiTop() + offsetY, 39, 14)
                    .build();
            event.addListener(button);
        } else if (event.getScreen() instanceof CreativeModeInventoryScreen creativeScreen) {
            // 创造背包无人物模型：按钮置于背包物品栏左上角上方
            Button button = Button.builder(Component.literal("遗物"),
                            b -> mc.setScreen(new RelicUpgradeScreen(creativeScreen)))
                    .bounds(creativeScreen.getGuiLeft() + 9, creativeScreen.getGuiTop() + 36, 39, 14)
                    .build();
            event.addListener(button);
            creativeRelicButton = button;
        }
    }

    /** 每帧：创造背包仅「背包」标签显示遗物按钮，切到物品库/搜索标签隐藏，避免遮挡物品格影响拿取。 */
    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render.Pre event) {
        if (event.getScreen() instanceof CreativeModeInventoryScreen && creativeRelicButton != null) {
            boolean show = isCreativeInventoryTab();
            creativeRelicButton.visible = show;
            creativeRelicButton.active = show;
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        while (OPEN_SCREEN.consumeClick()) {
            if (mc.player != null) {
                mc.setScreen(new RelicUpgradeScreen(mc.screen));
            }
        }
    }
}
