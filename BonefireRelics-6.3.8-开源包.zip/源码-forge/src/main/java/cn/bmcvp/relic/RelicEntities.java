package cn.bmcvp.relic;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 遗物自定义实体注册（Forge）。 */
public final class RelicEntities {
    public static final DeferredRegister<EntityType<?>> REGISTER =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BmcvpRelicUpgradesMod.MODID);

    public static final RegistryObject<EntityType<RelicFireballEntity>> RELIC_FIREBALL = REGISTER.register(
            "relic_fireball",
            () -> EntityType.Builder.<RelicFireballEntity>of(RelicFireballEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f).build("relic_fireball"));

    private RelicEntities() {
    }
}
