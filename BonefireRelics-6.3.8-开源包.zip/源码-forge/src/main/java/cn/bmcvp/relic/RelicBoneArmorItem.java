package cn.bmcvp.relic;

import com.google.common.collect.Multimap;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.UUID;

/**
 * 遗物骨甲：地狱装备，只有进入过下界的玩家才能装备。
 * v6.3.8（Spell Power 可选依赖守卫）：若安装了 spell_power，每件骨甲在对应装备槽位
 * 附加 +3 火焰 / +3 寒冰 / +3 奥秘法术强度；未安装则安全跳过，不影响其他功能。
 */
public class RelicBoneArmorItem extends ArmorItem {
    public static final String NETHER_UNLOCK_TAG = "bmcvp_relic_visited_nether";

    private static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0001-4a3e-9f8e-1a2b3c4d5e01");
    private static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0002-4a3e-9f8e-1a2b3c4d5e02");
    private static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0003-4a3e-9f8e-1a2b3c4d5e03");

    public RelicBoneArmorItem(ArmorMaterial material, ArmorItem.Type type, Properties properties) {
        super(material, type, properties);
    }

    /** Spell Power 守卫：仅当模组已加载时附加 3 系法术强度各 +3（运行时按注册表 id 查询，零编译依赖）。 */
    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        Multimap<Attribute, AttributeModifier> modifiers = super.getAttributeModifiers(slot, stack);
        if (slot == this.type.getSlot() && ModList.get().isLoaded("spell_power")) {
            addSpellPower(modifiers, "fire", FIRE_POWER_UUID, "bmcvp_bone_fire_power");
            addSpellPower(modifiers, "frost", FROST_POWER_UUID, "bmcvp_bone_frost_power");
            addSpellPower(modifiers, "arcane", ARCANE_POWER_UUID, "bmcvp_bone_arcane_power");
        }
        return modifiers;
    }

    private static void addSpellPower(Multimap<Attribute, AttributeModifier> map, String school, UUID uuid, String name) {
        Attribute attribute = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation("spell_power", school));
        if (attribute != null) {
            map.put(attribute, new AttributeModifier(uuid, name, 3.0, AttributeModifier.Operation.ADDITION));
        }
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!player.getTags().contains(NETHER_UNLOCK_TAG)) {
            player.displayClientMessage(Component.literal("§c需要先进入地狱才能使用骨甲"), true);
            return InteractionResultHolder.fail(player.getItemInHand(hand));
        }
        return super.use(level, player, hand);
    }
}
