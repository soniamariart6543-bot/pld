package cn.bmcvp.relic;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import java.util.List;

/**
 * 野生果奶（v6.3.8，Forge）：可无限食用的补给品。
 * 进食动画 32 tick，每次恢复 8 点饥饿值与 8 点饱食度，并去除一项负面效果；
 * 食用后物品不消耗，满腹也可食用；名字紫色，与其他遗物一样不可丢弃。
 */
public class InfiniteAppleItem extends Item {
    public InfiniteAppleItem(Properties properties) {
        super(properties);
    }

    @Override
    public Component getName(ItemStack stack) {
        // 名字紫色（品红紫）
        return Component.translatable(this.getDescriptionId(stack)).withStyle(ChatFormatting.LIGHT_PURPLE);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        // 满腹也可食用（always edible）
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        // 功能标签：可去除负面效果（模仿牛奶的清除机制）
        tooltip.add(Component.literal("可去除一项负面效果").withStyle(ChatFormatting.BLUE));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity user) {
        if (user instanceof ServerPlayer player) {
            // 每次 +8 饥饿值 +8 饱食度（原版饱和公式：saturationModifier × food × 2 = 0.5 × 8 × 2 = 8.0）
            player.getFoodData().eat(8, 0.5f);
            // 去除一项负面效果（只移除一个，保留其余）。
            // 用标准 removeEffect（牛奶同源的 LivingEntity 公开移除，带完整客户端同步），保证效果图标正常消失。
            for (MobEffectInstance effect : player.getActiveEffects()) {
                if (effect.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                    player.removeEffect(effect.getEffect());
                    break;
                }
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
        return stack; // 无限：不消耗
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 32;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }
}
