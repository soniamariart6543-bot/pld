package cn.bmcvp.relic.client;

import cn.bmcvp.relic.RelicFireballEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** 追踪火球渲染：始终面向相机的火球贴图精灵。 */
public class RelicFireballRenderer extends EntityRenderer<RelicFireballEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("bmcvp_relic_upgrades", "textures/entity/relic_fireball.png");
    private static final float SIZE = 0.6f;

    public RelicFireballRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(RelicFireballEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RelicFireballEntity entity, float yaw, float tickDelta, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.scale(SIZE, SIZE, SIZE);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutout(TEXTURE));
        Matrix4f m = poseStack.last().pose();
        Matrix3f n = poseStack.last().normal();
        vc.vertex(m, -0.5f, -0.5f, 0.0f).color(255, 255, 255, 255).uv(0.0f, 1.0f).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0f, 0.0f, 1.0f);
        vc.vertex(m, 0.5f, -0.5f, 0.0f).color(255, 255, 255, 255).uv(1.0f, 1.0f).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0f, 0.0f, 1.0f);
        vc.vertex(m, 0.5f, 0.5f, 0.0f).color(255, 255, 255, 255).uv(1.0f, 0.0f).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0f, 0.0f, 1.0f);
        vc.vertex(m, -0.5f, 0.5f, 0.0f).color(255, 255, 255, 255).uv(0.0f, 0.0f).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0f, 0.0f, 1.0f);
        poseStack.popPose();
        super.render(entity, yaw, tickDelta, poseStack, buffer, light);
    }
}
