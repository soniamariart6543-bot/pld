package cn.bmcvp.relic.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;

/**
 * 跑马灯文字组件：解决 UI 文字显示不全的问题。
 *
 * <ul>
 *   <li>文字总宽 ≤ 组件宽度：静止居中显示；</li>
 *   <li>文字总宽 &gt; 组件宽度：以 25~30 像素/秒的速度缓慢向左滚动，首尾无缝衔接
 *       （绘制两份文本，间隔 GAP_PIXELS 后重新从右侧进入），无限循环；</li>
 *   <li>渲染全程严格裁剪（enableScissor/disableScissor），不影响父级 UI；</li>
 *   <li>鼠标悬停显示完整未截断文字的 Tooltip（原版半透明背景+描边样式）；</li>
 *   <li>滚动偏移基于实时帧率差（System.nanoTime）累计，速度与帧率无关。</li>
 * </ul>
 */
public class MarqueeTextWidget extends AbstractWidget {
    /** 滚动速度：25~30 像素/秒（取 27）。 */
    private static final float SCROLL_SPEED = 27.0f;
    /** 循环间隔（等效数个空格），保证首尾无缝衔接。 */
    private static final int GAP_PIXELS = 36;
    /** 当前滚动偏移（像素）。 */
    private float offset;
    /** 上次渲染时间（纳秒），用于按真实帧率差累计偏移。 */
    private long lastNanos = System.nanoTime();
    /** 文字颜色（ARGB）。 */
    private int color = 0xFFFFFFFF;
    /** 字体（AbstractWidget 不提供，自行获取）。 */
    private final Font font = Minecraft.getInstance().font;

    public MarqueeTextWidget(Component message, int x, int y, int width, int height) {
        super(x, y, width, height, message);
        // 原版 Tooltip 机制：父类 render() 会自动 updateTooltip（悬停显示完整文字）
        this.setTooltip(Tooltip.create(message));
    }

    @Override
    public void setMessage(Component message) {
        super.setMessage(message);
        this.setTooltip(Tooltip.create(message));
    }

    public void setColor(int color) {
        this.color = color;
    }

    @Override
    protected void renderWidget(GuiGraphics gui, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        // 帧率无关的时间差；跳变（切屏/恢复）时限制在 0.25 秒内，避免滚动瞬移
        float delta = Math.max(0.0f, Math.min((now - this.lastNanos) / 1_000_000_000.0f, 0.25f));
        this.lastNanos = now;

        Font font = this.font;
        Component message = this.getMessage();
        String text = message.getString();
        int textWidth = font.width(text);
        int y = this.getY() + (this.getHeight() - font.lineHeight) / 2;
        int safeColor = 0xFF000000 | (this.color & 0x00FFFFFF);

        // 严格裁剪：文字只在组件范围内滚动（mojmap 1.20.1 enableScissor 已正确
        // 处理 GUI 缩放与 Y 翻转）。必须用 String 版本绘制——Text/Component 版本的
        // 颜色参数在无样式文本上会异常变黑（黑字问题根因）。
        gui.enableScissor(this.getX(), this.getY(), this.getX() + this.getWidth(), this.getY() + this.getHeight());
        try {
            if (textWidth <= this.getWidth()) {
                // 短文字：静止居中
                int x = this.getX() + (this.getWidth() - textWidth) / 2;
                gui.drawString(font, text, x, y, safeColor);
            } else {
                // 长文字：缓慢左滚，画两份实现首尾无缝衔接
                float total = textWidth + GAP_PIXELS;
                this.offset = (this.offset + delta * SCROLL_SPEED) % total;
                int startX = this.getX() - (int) this.offset;
                gui.drawString(font, text, startX, y, safeColor);
                gui.drawString(font, text, startX + (int) total, y, safeColor);
            }
        } finally {
            gui.disableScissor();
        }

        // 悬停完整 Tooltip 由原版 setTooltip 机制自动显示（render -> updateTooltip）
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= this.getX() && mouseY >= this.getY()
                && mouseX < this.getX() + this.getWidth() && mouseY < this.getY() + this.getHeight();
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        // 纯展示组件，无需屏幕阅读叙述
    }
}
