package cn.bmcvp.relic;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/**
 * 遗物法杖直线火球（v6.3.5+，Forge）：完全直线飞行，指哪儿打哪儿。
 * 命中任意实体生物（非发射者）即爆炸：AOE 魔法伤害扩散到目标周围怪物，不破坏方块。
 * 渲染：relic_fireball.png（火球贴图）。
 */
public class RelicFireballEntity extends AbstractHurtingProjectile {
    /** 发射速度（格/tick）：与 WandSkillHandler.LAUNCH_SPEED 保持一致。 */
    public static final double SPEED = 2.0;
    private static final int MAX_LIFE = 120;        // 120 tick × 2.0 格/tick = 240 格射程
    private static final double EXPLOSION_RADIUS = 3.0; // 爆炸扩散半径
    /** 凋零 II 参数：5 秒（100 tick），伤害等级 1。 */
    private static final int WITHER_TICKS = 100;
    private static final int WITHER_AMPLIFIER = 1;

    private ServerPlayer owner;
    private float baseDamage;
    private int spell;
    private int explosion;
    private boolean soul; // 下界灵魂之杖（tier 1）
    private int life = MAX_LIFE;

    public RelicFireballEntity(EntityType<? extends AbstractHurtingProjectile> type, Level level) {
        super(type, level);
    }

    /** 直线发射：速度由发射方（WandSkillHandler）按标准抛射物发射机制设置，本类只负责恒定直线飞行。 */
    public RelicFireballEntity(Level level, ServerPlayer owner, float baseDamage, int spell, int explosion, boolean soul) {
        super(RelicEntities.RELIC_FIREBALL.get(), level);
        this.owner = owner;
        this.baseDamage = baseDamage;
        this.spell = spell;
        this.explosion = explosion;
        this.soul = soul;
        this.setPos(owner.getX(), owner.getEyeY(), owner.getZ());
        this.setNoGravity(true);
    }

    @Override
    public void tick() {
        // 完全直线：不重定向速度，保持初始方向
        super.tick();
        // 抵消原版抛射物阻力（每 tick ×0.9）：把速度归一化回发射速度，实现恒定速度直线飞行
        Vec3 v = this.getDeltaMovement();
        double len = v.length();
        if (len > 1.0E-4) {
            this.setDeltaMovement(v.scale(SPEED / len));
        }
        if (this.level() instanceof ServerLevel sl) {
            Vec3 p = this.position();
            if (soul) {
                // 灵魂蓝焰：灵魂沙之火色调
                sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
                sl.sendParticles(ParticleTypes.SOUL, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
            } else {
                sl.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
                sl.sendParticles(ParticleTypes.SMALL_FLAME, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
            }
        }
        if (--life <= 0) {
            discard();
        }
    }

    /** 命中任意活体（非发射者，含其他玩家；PvP/PvE 均生效）即触发爆炸。 */
    @Override
    protected boolean canHitEntity(Entity entity) {
        return entity instanceof LivingEntity le && le != owner && le.isAlive();
    }

    /** 命中生物：对目标造成法伤，并在目标位置产生爆炸（AOE 魔法伤害扩散周围怪物，不破坏方块）。 */
    @Override
    protected void onHitEntity(EntityHitResult hitResult) {
        if (!(hitResult.getEntity() instanceof LivingEntity hit) || owner == null) {
            this.discard();
            return;
        }
        explodeAt(hit);
        this.discard();
    }

    /** 撞墙：直接消失（不爆炸、不破坏方块）。 */
    @Override
    protected void onHitBlock(BlockHitResult hitResult) {
        this.discard();
    }

    /** 火球命中实例入口（抛射物命中调用）：委托静态结算。 */
    private void explodeAt(LivingEntity hit) {
        if (owner == null) {
            return;
        }
        ServerLevel sl = this.level() instanceof ServerLevel s ? s : null;
        if (sl == null) {
            return;
        }
        explodeAt(sl, owner, hit, baseDamage, spell, explosion, soul);
    }

    /**
     * 火球伤害结算（静态，火球命中与法杖近战共用）：
     * 目标受法伤（基础 + 法术强度，+火罚+连击+吸血）；
     * 目标位置产生爆炸视觉（粒子+声音，不破坏方块），对周围 3 格内怪物造成爆炸 AOE 魔法伤害（5 + 爆炸等级×0.5）。
     */
    public static void explodeAt(ServerLevel sl, ServerPlayer owner, LivingEntity hit,
                                 float baseDamage, int spell, int explosion, boolean soul) {
        if (owner == null || sl == null || hit == null || !hit.isAlive()) {
            return;
        }
        Vec3 center = hit.position().add(0, hit.getBbHeight() / 2, 0);
        // 暴击率：下界灵魂之杖 35%（暴击伤害 150%）；普通法杖无暴击（Forge 既定）
        float critChance = soul ? 0.35f : 0.0f;

        // 1) 直接命中目标：法伤结算（火罚 + 连击 + 吸血）
        DamageSource source = owner.damageSources().indirectMagic(owner, owner);
        float dmg = baseDamage;
        if (spell >= WandSkillHandler.FIRE_PUNISH_SPELL) {
            dmg += hit.getHealth() * WandSkillHandler.FIRE_PUNISH_PERCENT;
        }
        dmg = rollCrit(dmg, critChance, owner, soul);
        hit.hurt(source, dmg);
        WandSkillHandler.lifestealFrom(owner, dmg);
        applySoulWither(hit, soul);
        // 连击（灵魂杖基础概率 10% → 30%，上限 30% → 45%）
        float chance = soul
                ? Math.min(0.30f + spell * 0.01f, 0.45f)
                : Math.min(0.10f + spell * 0.01f, 0.30f);
        if (sl.random.nextFloat() < chance && hit.isAlive()) {
            hit.hurt(source, dmg);
            WandSkillHandler.lifestealFrom(owner, dmg);
            applySoulWither(hit, soul);
        }

        // 2) 爆炸视觉：粒子 + 声音（不破坏方块）
        spawnExplosionVisual(sl, center, false, soul, explosion);

        // 3) 爆炸 AOE：对周围 3 格内怪物造成爆炸魔法伤害（扩散到目标周围的怪）
        if (explosion > 0) {
            float boom = (float) (5 + explosion * 0.5);
            for (LivingEntity e : hostilesIn(sl, boxAround(center, EXPLOSION_RADIUS), owner)) {
                float actual = rollCrit(boom, critChance, owner, soul);
                e.hurt(source, actual);
                WandSkillHandler.lifestealFrom(owner, actual);
                applySoulWither(e, soul);
            }
        }

        // 4) 灵魂爆裂（下界灵魂之杖专属）：击杀目标后爆炸并传播凋零，爆炸等级最高 12
        if (soul && !hit.isAlive()) {
            soulBurst(sl, owner, center, explosion, critChance, soul);
        }
    }

    /** 暴击判定：命中率 chance 时伤害 ×1.5（暴击伤害 150%）；仅下界灵魂之杖判定（Forge 既定）。 */
    private static float rollCrit(float damage, float chance, ServerPlayer owner, boolean soul) {
        if (soul && owner.getRandom().nextFloat() < chance) {
            return damage * 1.5f;
        }
        return damage;
    }

    /** 下界灵魂之杖：目标附加凋零 II（5 秒）。 */
    private static void applySoulWither(LivingEntity target, boolean soul) {
        if (soul && target != null && target.isAlive()) {
            target.addEffect(new MobEffectInstance(MobEffects.WITHER, WITHER_TICKS, WITHER_AMPLIFIER));
        }
    }

    /** 灵魂爆裂：击杀目标后原地爆炸并传播凋零（半径随爆炸等级增长，最高 12 级）。 */
    private static void soulBurst(ServerLevel sl, ServerPlayer owner, Vec3 center, int explosion,
                                  float critChance, boolean soul) {
        float boom = (float) (5 + explosion * 0.5);
        spawnExplosionVisual(sl, center, true, soul, explosion);
        DamageSource boomSource = owner.damageSources().indirectMagic(owner, owner);
        for (LivingEntity e : hostilesIn(sl, boxAround(center, 3.0 + explosion * 0.25), owner)) {
            float actual = rollCrit(boom, critChance, owner, soul);
            e.hurt(boomSource, actual);
            WandSkillHandler.lifestealFrom(owner, actual);
            applySoulWither(e, soul);
        }
    }

    /** 爆炸视觉：粒子 + 声音（不破坏方块）；burst=true 时为灵魂爆裂大范围蓝焰特效。 */
    private static void spawnExplosionVisual(ServerLevel sl, Vec3 center, boolean burst, boolean soul, int explosion) {
        sl.sendParticles(ParticleTypes.EXPLOSION, center.x, center.y, center.z, 1, 0.0, 0.0, 0.0, 0.0);
        if (soul) {
            if (burst) {
                double r = 3.0 + explosion * 0.25;
                sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, center.x, center.y, center.z, 32, r, r, r, 0.05);
            } else {
                sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
                sl.sendParticles(ParticleTypes.SOUL, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
            }
        } else {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
            sl.sendParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
        }
        sl.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private static AABB boxAround(Vec3 center, double radius) {
        return new AABB(center.x - radius, center.y - radius, center.z - radius,
                center.x + radius, center.y + radius, center.z + radius);
    }

    private static List<LivingEntity> hostilesIn(ServerLevel sl, AABB box, ServerPlayer owner) {
        return sl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != owner && e.isAlive() && e instanceof Monster);
    }

    @Override
    public boolean isNoGravity() {
        // 昀晞 · 恒定直线弹道保持无重力
        return true;
    }
}
