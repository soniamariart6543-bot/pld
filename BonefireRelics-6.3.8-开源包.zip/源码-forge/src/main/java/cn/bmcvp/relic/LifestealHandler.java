package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 战利品骨头吸血（Forge 移植版，对齐 Fabric 行为）：
 * 主手持骨头造成伤害后按吸血等级比例回血，溢出转为临时血量（最多 50% 基础生命值），
 * 临时血持续 8 秒，再次触发刷新持续时间。
 */
public final class LifestealHandler {
    private static final int TEMP_HP_TICKS = 160; // 8 秒
    /** 临时血账本：记录「本次吸血贡献的吸收量」与到期 tick；到期只扣自己加的部分，不影响其他来源（金苹果等）的吸收心。 */
    private static final Map<ServerPlayer, Accum> ABSORPTION = new WeakHashMap<>();

    private record Accum(float amount, long expiryTick) {
    }

    private LifestealHandler() {
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target == player) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            return;
        }
        int level = RelicService.value(stack, "fortune");
        if (level > 0 && player.getServer() != null) {
            player.getServer().execute(() -> applyLifesteal(player, event.getAmount(), level));
        }
    }

    /** 临时血量到期清除：只减去吸血贡献的吸收量（不触碰其他来源）。 */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        long now = event.getServer().getTickCount();
        ABSORPTION.entrySet().removeIf(entry -> {
            Accum acc = entry.getValue();
            if (acc.expiryTick() <= now) {
                ServerPlayer player = entry.getKey();
                if (player != null && !player.isRemoved()) {
                    player.setAbsorptionAmount(Math.max(0.0f, player.getAbsorptionAmount() - acc.amount()));
                }
                return true;
            }
            return false;
        });
    }

    /** 法杖吸血入口（供 WandSkillHandler 调用）：按吸血等级回血 + 溢出转临时血。 */
    public static void applyWandLifesteal(ServerPlayer player, float damage, int level) {
        applyLifesteal(player, damage, level);
    }

    private static void applyLifesteal(ServerPlayer player, float damage, int level) {
        float percent = RelicService.lifestealPercent(level);
        float lifesteal = damage * percent;
        if (lifesteal <= 0) {
            return;
        }
        float before = player.getHealth();
        player.heal(lifesteal);
        float healed = player.getHealth() - before;
        float overflow = lifesteal - healed;
        if (overflow > 0) {
            float maxAbsorption = player.getMaxHealth() * 0.5f;
            float absorptionBefore = player.getAbsorptionAmount();
            float newAbsorption = Math.min(absorptionBefore + overflow, maxAbsorption);
            player.setAbsorptionAmount(newAbsorption);
            float added = newAbsorption - absorptionBefore;
            // 累计自己贡献的吸收量并刷新到期时间
            Accum acc = ABSORPTION.get(player);
            float ourShare = acc == null ? 0.0f : acc.amount();
            ABSORPTION.put(player, new Accum(ourShare + added,
                    player.getServer().getTickCount() + (long) TEMP_HP_TICKS));
        }
    }
}
