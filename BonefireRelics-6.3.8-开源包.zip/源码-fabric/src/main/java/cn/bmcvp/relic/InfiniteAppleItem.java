package cn.bmcvp.relic;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import java.util.List;

/**
 * 野生果奶（v6.3.8）：可无限食用的补给品。
 * 进食动画 32 tick，每次恢复 8 点饥饿值与 8 点饱食度，并去除一项负面效果；
 * 食用后物品不消耗，满腹也可食用；名字紫色，与其他遗物一样不可丢弃。
 */
public class InfiniteAppleItem extends Item {
    public InfiniteAppleItem(Settings settings) {
        super(settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        // 名字紫色（品红紫）
        return Text.translatable(this.getTranslationKey(stack)).formatted(Formatting.LIGHT_PURPLE);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        // 满腹也可食用（always edible）
        user.setCurrentHand(hand);
        return TypedActionResult.consume(user.getStackInHand(hand));
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        // 功能标签：可去除负面效果（模仿牛奶的清除机制）
        tooltip.add(Text.literal("可去除一项负面效果").formatted(Formatting.BLUE));
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (user instanceof ServerPlayerEntity player) {
            // 每次 +8 饥饿值 +8 饱食度（原版饱和公式：saturationModifier × food × 2 = 0.5 × 8 × 2 = 8.0）
            player.getHungerManager().add(8, 0.5f);
            // 去除一项负面效果（只移除一个，保留其余）。
            // 用公开 removeStatusEffect（与牛奶同源的 LivingEntity 标准移除，带完整客户端同步）——
            // 不能用 removeStatusEffectInternal（静默移除不同步，会导致效果图标永久残留、计时停止）。
            for (StatusEffectInstance effect : player.getActiveStatusEffects().values()) {
                if (effect.getEffectType().getCategory() == StatusEffectCategory.HARMFUL) {
                    player.removeStatusEffect(effect.getEffectType());
                    break;
                }
            }
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
        return stack; // 无限：不消耗
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 32;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.EAT;
    }
}
