package cn.bmcvp.relic;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** 遗物自定义实体注册。 */
public final class RelicEntities {
    public static final EntityType<RelicFireballEntity> RELIC_FIREBALL = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(BmcvpRelicUpgrades.MODID, "relic_fireball"),
            EntityType.Builder.<RelicFireballEntity>create(RelicFireballEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.3f, 0.3f).build("relic_fireball"));

    private RelicEntities() {
    }

    public static void initialize() {
        // 触发静态注册
    }
}
