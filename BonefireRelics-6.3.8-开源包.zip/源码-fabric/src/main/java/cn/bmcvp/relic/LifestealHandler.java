package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 战利品骨头的吸血逻辑：根据攻击伤害回血，溢出转为临时血量（最多 50% 基础生命值），
 * 临时血持续 8 秒，再次攻击刷新持续时间。
 */
public final class LifestealHandler {
    private static final int TEMP_HP_TICKS = 160; // 8 秒
    /** 临时血账本：记录「本次吸血贡献的吸收量」与到期 tick；到期只扣自己加的部分，不影响其他来源（金苹果等）的吸收心。 */
    private static final Map<ServerPlayerEntity, Accum> ABSORPTION = new WeakHashMap<>();

    private record Accum(float amount, long expiryTick) {
    }

    public static void initialize() {
        // 伤害应用前记录，延迟到伤害应用后回血
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (amount > 0 && source.getAttacker() instanceof ServerPlayerEntity player && entity != player) {
                ItemStack stack = player.getMainHandStack();
                if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
                    int level = RelicService.value(stack, "fortune");
                    if (level > 0 && player.getServer() != null) {
                        player.getServer().execute(() -> applyLifesteal(player, amount, level));
                    }
                }
            }
            return true;
        });

        // 临时血量到期清除：只减去吸血贡献的吸收量（不触碰其他来源）
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long now = server.getTicks();
            ABSORPTION.entrySet().removeIf(entry -> {
                Accum acc = entry.getValue();
                if (acc.expiryTick() <= now) {
                    ServerPlayerEntity player = entry.getKey();
                    if (player != null && !player.isRemoved()) {
                        player.setAbsorptionAmount(Math.max(0.0f, player.getAbsorptionAmount() - acc.amount()));
                    }
                    return true;
                }
                return false;
            });
        });
    }

    /** 法杖吸血入口（供 WandSkillHandler 调用）：按吸血等级回血 + 溢出转临时血。 */
    public static void applyWandLifesteal(ServerPlayerEntity player, float damage, int level) {
        applyLifesteal(player, damage, level);
    }

    private static void applyLifesteal(ServerPlayerEntity player, float damage, int level) {
        float percent = RelicService.lifestealPercent(level);
        float lifesteal = damage * percent;
        if (lifesteal <= 0) {
            return;
        }
        float before = player.getHealth();
        player.heal(lifesteal);
        float healed = player.getHealth() - before;
        float overflow = lifesteal - healed;
        if (overflow > 0) {
            float maxAbsorption = player.getMaxHealth() * 0.5f;
            float absorptionBefore = player.getAbsorptionAmount();
            float newAbsorption = Math.min(absorptionBefore + overflow, maxAbsorption);
            player.setAbsorptionAmount(newAbsorption);
            float added = newAbsorption - absorptionBefore;
            // 累计自己贡献的吸收量并刷新到期时间
            Accum acc = ABSORPTION.get(player);
            float ourShare = acc == null ? 0.0f : acc.amount();
            ABSORPTION.put(player, new Accum(ourShare + added,
                    player.getServer().getTicks() + (long) TEMP_HP_TICKS));
        }
    }
}
