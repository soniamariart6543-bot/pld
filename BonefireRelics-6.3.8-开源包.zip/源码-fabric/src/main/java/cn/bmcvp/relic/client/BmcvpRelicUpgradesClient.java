package cn.bmcvp.relic.client;

import cn.bmcvp.relic.BmcvpRelicUpgrades;
import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import cn.bmcvp.relic.RelicEntities;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;

public class BmcvpRelicUpgradesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RelicEntities.RELIC_FIREBALL, RelicFireballRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(BmcvpRelicUpgrades.RESULT, (client, handler, buf, response) -> {
            String message = buf.readString(BmcvpRelicUpgrades.PACKET_STRING_MAX_LENGTH);
            client.execute(() -> RelicUpgradeScreen.receiveServerResult(message));
        });
        // 法杖攻击：左键按下且手持法杖时，每次点击都通知服务端释放直线火球（无索敌，纯视线方向）。
        // 必须在 START_CLIENT_TICK 检测：原版 MinecraftClient.tick() 中 handleInputEvents()
        // 会先消费 attackKey 的按下事件（wasPressed→doAttack），END_CLIENT_TICK 阶段必然为 false，
        // 导致法杖永远无法开火（v6.3.5 遗留 bug）。在 START 阶段消费按键同时抑制原版近战动作。
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                return;
            }
            if (!RelicService.isRelic(client.player.getMainHandStack(), UpgradeDefinition.RelicType.WAND)) {
                return;
            }
            if (!client.options.attackKey.wasPressed()) {
                return;
            }
            ClientPlayNetworking.send(BmcvpRelicUpgrades.WAND_SWING, PacketByteBufs.create());
        });
    }
}
