package cn.bmcvp.relic;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.spell_power.api.SpellPower;
import net.spell_power.api.SpellSchool;
import net.spell_power.api.SpellSchools;

/**
 * 魔法法杖攻击（v6.3.5+）：左键点击即释放直线火球，沿视线方向飞行。
 * <ul>
 *   <li>无索敌：纯粹沿玩家视线方向直线飞行，每次点击左键都释放；</li>
 *   <li>命中任意活体生物（含其他玩家，PvP/PvE 均生效）即爆炸（不破坏方块），AOE 魔法伤害扩散周围怪物；</li>
 *   <li>基础 10 点魔法伤害 + 法术强度×1（一点提升一点伤害）；</li>
 *   <li>爆炸伤害 = 5 + 爆炸等级×0.5（上限 10 点）；连击/火罚/吸血同前。</li>
 * </ul>
 */
public final class WandSkillHandler {
    public static final float BASE_DAMAGE = 10.0f;
    public static final float DAMAGE_PER_SPELL = 1.0f;
    public static final int FIRE_PUNISH_SPELL = 15;
    public static final float FIRE_PUNISH_PERCENT = 0.05f;
    /** 直线发射速度（格/tick）：与 RelicFireballEntity.SPEED 保持一致。 */
    public static final float LAUNCH_SPEED = 2.0f;
    /** 下界灵魂之杖：遗物本体部分伤害 +5，封顶 45（Spell Power 加成独立保留，不参与封顶）。 */
    public static final float SOUL_DAMAGE_BONUS = 5.0f;
    public static final float MAX_SOUL_DAMAGE = 45.0f;
    /** 近战射程（格）：视线前方 2 格内的目标直接结算火球伤害（近距离也能命中）。 */
    public static final double MELEE_RANGE = 2.0;
    /** 近战视线锥角过滤：目标中心与视线夹角 ≤ 60°（点积 ≥ 0.5）才视为正前方目标。 */
    private static final double MELEE_DOT_MIN = 0.5;

    /**
     * 接入所有法术类型：累加所有法术学校的法术强度，并应用骨火 2.5 倍加成。
     * 常规可选依赖守卫（Fabric 标准做法）：FabricLoader.isModLoaded 检测 spell_power，
     * 未安装时短路返回 0，不触发任何 Spell Power 类加载；已安装则直调 API。
     */
    public static float allSpellPowerBonus(ServerPlayerEntity player) {
        if (!FabricLoader.getInstance().isModLoaded("spell_power")) {
            return 0.0f;
        }
        float total = 0.0f;
        for (SpellSchool school : SpellSchools.all()) {
            total += (float) SpellPower.getSpellPower(school, player).baseValue();
        }
        return total * 2.5f;
    }

    private WandSkillHandler() {
    }

    /** 左键触发入口：每次点击沿视线方向释放一个直线火球。 */
    public static void fireSwing(ServerPlayerEntity player) {
        fire(player);
    }

    public static void initialize() {
        // 法杖不做近战：持法杖时取消近战伤害；火球由左键点击（WAND_SWING 包）触发。
        // 保留 MAGIC/INDIRECT_MAGIC 放行，避免取消火球自身的魔法伤害。
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((target, source, amount) -> {
            if (amount <= 0) {
                return true;
            }
            if (!(source.getAttacker() instanceof ServerPlayerEntity player)) {
                return true;
            }
            if (target == player || target.isRemoved()) {
                return true;
            }
            if (source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC)) {
                return true;
            }
            ItemStack stack = player.getMainHandStack();
            if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
                return true;
            }
            return false; // 取消法杖近战伤害
        });
    }

    /**
     * 直线发射（如同丢出物品 / 弩箭射击）：沿玩家视线方向以标准抛射物发射机制投出，
     * divergence=0 无随机散布，配合 RelicFireballEntity 的速度保持实现完全直线飞行。
     */
    private static void fire(ServerPlayerEntity player) {
        ItemStack stack = player.getMainHandStack();
        // 服务端权威校验：换手 / 空手不再发射（兼防空 NBT 崩溃）
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
            return;
        }
        int spell = RelicService.value(stack, "spell");
        int explosion = RelicService.value(stack, "explosion");
        boolean soul = RelicService.value(stack, "tier") == 1; // 下界灵魂之杖
        ServerWorld world = player.getServerWorld();
        // 适配 Spell Power：火球伤害 = 基础 + 法杖等级加成 + 所有法术类型强度 × 2.5（暴击在命中时判定）
        // 只计算一次 Spell Power：soul 分支复用同一份加成，避免同一 tick 重复遍历法术学校
        float spellPower = allSpellPowerBonus(player);
        float damage = BASE_DAMAGE + spell * DAMAGE_PER_SPELL + spellPower;
        if (soul) {
            // 下界灵魂之杖：遗物本体部分（基础+法术强度）附加 +5 并封顶 45；Spell Power 加成独立保留
            damage = Math.min(damage - spellPower + SOUL_DAMAGE_BONUS, MAX_SOUL_DAMAGE) + spellPower;
        }
        // 近战攻击：视线前方 2 格内有可命中实体 → 直接结算火球伤害（近距离也能命中，不生成飞行火球）
        LivingEntity melee = meleeTarget(player, MELEE_RANGE);
        if (melee != null) {
            RelicFireballEntity.explodeAt(world, player, melee, damage, spell, explosion, soul);
            return;
        }
        RelicFireballEntity fb = new RelicFireballEntity(world, player, damage, spell, explosion, soul);
        // 标准抛射物发射（与雪球 / 末影珍珠 / 弩箭同一机制）：视线方向，divergence=0 → 完全直线
        fb.setVelocity(player, player.getPitch(), player.getYaw(), 0.0F, LAUNCH_SPEED, 0.0F);
        world.spawnEntity(fb);
        // 发射音效（弩箭射击感）
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    /**
     * 近战目标检测：玩家视线前方 range 格内的活体（含其他玩家，与火球命中口径一致）。
     * 用「眼睛位置 → 目标中心」的距离 + 视线锥角（60°）过滤，返回最近的可命中目标。
     */
    private static LivingEntity meleeTarget(ServerPlayerEntity player, double range) {
        ServerWorld world = player.getServerWorld();
        Vec3d eye = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F).normalize();
        Box box = player.getBoundingBox().expand(range);
        LivingEntity best = null;
        double bestDistSq = range * range;
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isRemoved())) {
            Vec3d center = e.getPos().add(0, e.getHeight() * 0.5, 0);
            Vec3d to = center.subtract(eye);
            double distSq = to.lengthSquared();
            if (distSq > bestDistSq) {
                continue;
            }
            if (to.normalize().dotProduct(dir) < MELEE_DOT_MIN) {
                continue;
            }
            best = e;
            bestDistSq = distSq;
        }
        return best;
    }

    /** 供火球实体命中后调用：按法杖吸血等级回血。 */
    public static void lifestealFrom(ServerPlayerEntity player, float damage) {
        ItemStack stack = player.getMainHandStack();
        int level = RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)
                ? RelicService.value(stack, "wfortune") : 0;
        if (level <= 0) {
            return;
        }
        LifestealHandler.applyWandLifesteal(player, damage, level);
    }
}
