# Bonefire Relics（遗物）· 7.1.4 开源包

Minecraft 1.20.1 / Fabric 模组 **Bonefire Relics** 的完整源代码与构建脚本。
本包内含可直接构建的 Gradle 工程、发布产物（`dist\`）、更新日志与许可协议。

---

## 1. 这是什么

一套服务端权威（server-authoritative）的「遗物」成长系统：

- **无尽铁镐 / 星辉钻镐 / 永恒下界镐** 与 **骨斧**：可互相转化、逐级升级（效率 / 时运 / 裂地 / 巨力等）
- **战利品骨头**：可转化为 **魔法法杖**，拥有骨火 / 骨裂 / 火焰附加 II / 抢夺 / 吸血与法术强度路线
- **遗物骨甲** 四件套（含钻石 / 下界合金阶段）
- **秘法核心**（法术书形态，需 spell_engine）：装载法师卷册系法术、生长、冷却减免、免符文判定
- **护甲超限转化**：护甲值超过阈值后转化为减伤 / 最大生命 / 法术抗性（配置文件可调）
- **六章任务数据 + 原版成就**：进度按曲线推进，每章发放经验与材料
- **虚空神心（终极方案）**：三项主属性满级后所有遗物融入秘法核心；免疫非玩家伤害、双向处决、飞行、夜视、再生、急迫 II、骨甲与三系法强全继承、命中落雷、固定 15 级抢夺
- **融合演出**：升空 → 螺旋火焰漩涡 → 30 道外围环雷 → 脚下爆炸成坑 → 三道天罚 → 巨坑基岩化（创造模式有「一键成神」按钮，可反复触发）

---

## 2. 环境要求

| 项目 | 版本 |
|---|---|
| Minecraft | 1.20.1 |
| Fabric Loader | ≥ 0.15.0（开发基线 0.15.11，实测 0.16.9 / 0.19.5 均可运行） |
| Fabric API | 0.92.2+1.20.1（编译基线） |
| JDK | **17**（必须，编译与运行均要求 17 级别） |
| Gradle | 无需安装，使用包内 `gradlew`（Gradle Wrapper 8.x） |
| Yarn 映射 | 1.20.1+build.10 |

---

## 3. 构建

```bat
cd src-fabric
gradlew.bat build            :: Windows
./gradlew build              :: macOS / Linux
```

产物路径：`src-fabric\build\libs\bonefire_relics-7.1.4.jar`

---

## 4. 依赖（必须放入 `src-fabric\libs\`）

工程使用三个可选模组作为**编译期依赖**（均为第三方开源模组，本包不附带其二进制文件，请自行下载对应版本放入 `libs\`）：

| 文件名（必须一致） | 说明 | 获取 |
|---|---|---|
| `spell_engine-0.15.12+1.20.1.jar` | 法术引擎（法术书 / 法术容器 API） | Modrinth / CurseForge 搜 `Spell Engine` |
| `spell_power-0.12.0+1.20.1.jar` | 法术强度三系属性（奥术 / 火焰 / 冰霜） | Modrinth / CurseForge 搜 `Spell Power` |
| `trinkets-3.7.2.jar` | 饰品栏（法术书槽 `charm/spell_book`） | Modrinth / CurseForge 搜 `Trinkets` |

另有 `libs\cca-compile-stub.jar`（本工程自带的 2KB 空接口桩，用于闭合 Trinkets 的
Cardinal Components 继承链，仅编译期使用，不会打进发布 jar）——**已随包附带**。

⚠️ 若缺少上表任一 jar，`build.gradle` 只会打印一条「守卫依赖缺失，已跳过」警告，
随后编译会因找不到 `net.spell_engine.* / net.spell_power.* / dev.emi.trinkets.*` 符号而失败。
请先补齐三个 jar 再构建。

---

## 5. 目录结构

```
7.1.4\
├─ README.md                            本文件
├─ CHANGELOG.md                         版本变更摘要
├─ LICENSE                              MIT 许可
├─ 更新日志-7.1.4.docx                  发布更新日志（功能全览）
├─ 更新日志-7.1.4-体检修复补充.docx      同日体检修复说明
├─ dist\
│   ├─ BonefireRelics-7.1.4.jar         发布产物（可直接放进 mods\）
│   └─ BonefireRelics-7.1.4-sources.jar 源码 jar（反查/调试用）
└─ src-fabric\                          Fabric 工程（可直接 gradlew build）
    ├─ build.gradle / settings.gradle / gradle.properties
    ├─ gradlew / gradlew.bat / gradle\wrapper\
    ├─ libs\                            依赖放置处（含 cca 桩）
    └─ src\main\java\cn\bmcvp\relic\    源码（含 mixin 与 client 子包）
        └─ resources\                   资源：贴图 / 模型 / 语言 / 数据包 / mixin 配置
```

---

## 6. 运行期依赖与降级

发布 jar 的 `fabric.mod.json` 只**硬依赖** `fabricloader / fabric / minecraft / java`，
`trinkets / spell_engine / spell_power` 全部列为 **suggests（软依赖）**：

- 缺 **spell_engine** → 秘法核心与虚空神心降级为**护甲形态**物品，其余功能照常
- 缺 **spell_power** → 三系法强相关效果静默跳过（含神心 +30 法强）
- 缺 **trinkets** → 饰品栏相关判定跳过，仍可用护甲栏 / 手持触发

服务器与客户端行为一致（服务端权威）：升级、发放、融合、毁灭模式等均由服务端校验。

---

## 7. 许可

MIT License，Copyright (c) 2026 遗物团队 —— 详见 `LICENSE`。

第三方依赖（Spell Engine / Spell Power / Trinkets / Fabric API / Minecraft）版权归各自作者所有，
本包仅提供源码与构建脚本，**不包含**上述第三方二进制文件。
Minecraft 相关资产（贴图 / 音效 / 模型）的使用需遵守 Mojang 的最终用户许可协议。
