package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientPlayerEntity.class})
public abstract class ClientDropProtectionMixin {
   @Inject(
      method = {"dropSelectedItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void bmcvp$blockClientDrop(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
      if (RelicService.isAnyRelic(((ClientPlayerEntity)(Object)this).getMainHandStack())) {
         cir.setReturnValue(false);
      }
   }
}
