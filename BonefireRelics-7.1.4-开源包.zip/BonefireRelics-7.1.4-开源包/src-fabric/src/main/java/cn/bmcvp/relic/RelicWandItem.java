package cn.bmcvp.relic;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import java.util.UUID;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.minecraft.item.Item.Settings;
// （无 spell_power 直连依赖：法强相关计算统一走 WandSkillHandler 的 isModLoaded 守卫分支）

public class RelicWandItem extends SwordItem {
   public static final double SPELL_POWER = 15.0;
   private static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0011-4a3e-9f8e-1a2b3c4d5e01");
   private static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0012-4a3e-9f8e-1a2b3c4d5e02");
   private static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0013-4a3e-9f8e-1a2b3c4d5e03");

   public RelicWandItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
      super(material, attackDamage, attackSpeed, settings);
   }

}
