package cn.bmcvp.relic;

import java.util.List;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * 虚空神心 —— 秘法核心的终极形态（2026-09-13 昀晞「终极方案」）。
 *
 * 来源：三项主属性（镐子材质 6 / 骨头伤害 41 / 法杖法强 30）全部满级时，
 * 所有遗物融入秘法核心 → 核心化为神心。
 * 效果（穿戴 = 主手/副手/饰品栏持有）：
 *   · 返还「骨头」与「镐子」并**保留原有升级等级**；骨甲被吸收，**不返还**，但获得骨甲的全部属性效果；
 *   · 免疫所有非玩家伤害；无法被玩家伤害杀死；
 *   · 被实体攻击时**直接处决**该实体（斩杀线 = 目标自身最大生命 ×120%）；
 *   · 可持续飞行、永久夜视、持续生命恢复。
 */
public class VoidHeartItem extends ArmorItem {
   /** 护甲栏可穿的胸甲型（2026-09-13 昀晞：改成护甲栏任意位置可穿）。 */
   public VoidHeartItem() {
      super(ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE, new Settings().maxCount(1).fireproof());
   }
   @Override
   public boolean hasGlint(ItemStack stack) {
      return true;
   }

   @Override
   @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
   public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
      tooltip.add(Text.translatable("tooltip.bonefire_relics.void_heart.1").formatted(Formatting.DARK_RED));
      for (int i = 2; i <= 11; i++) {
         Formatting color = (i == 2 || i == 3) ? Formatting.GOLD : (i >= 7 ? Formatting.DARK_GRAY : Formatting.GRAY);
         tooltip.add(Text.translatable("tooltip.bonefire_relics.void_heart." + i).formatted(color));
      }
   }

   @Override
   public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
      if (!world.isClient && user instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer) {
         VoidHeartHandler.onUse(serverPlayer);
      }
      return TypedActionResult.success(user.getStackInHand(hand));
   }
}
