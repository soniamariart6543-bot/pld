package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntity.class})
public abstract class KillCreditMixin {
   @Inject(
      method = {"onDeath"},
      at = {@At("TAIL")}
   )
   private void bmcvp$recordKillCredit(DamageSource source, CallbackInfo ci) {
      if (!((Object)this instanceof ServerPlayerEntity)) {
         if (source.getAttacker() instanceof ServerPlayerEntity killer) {
            ArcaneCoreGrowth.recordKill(killer);
         }
      }
   }
}
