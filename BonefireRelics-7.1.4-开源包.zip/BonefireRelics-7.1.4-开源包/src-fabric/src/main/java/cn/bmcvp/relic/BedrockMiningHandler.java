package cn.bmcvp.relic;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * 无尽铁镐「破岩」（v2，模仿 bedrock-breaking 的挖掘速度方案）：
 * 满级 M6 铁镐把基岩视作「等效硬度 50（黑曜石级）」——由 mixin 在 calcBlockBreakingDelta 注入
 * dig = 8 + eff² + 1 的挖掘速度，原版挖掘管线（进度条/长按/松手/服务端破块）全部接管；
 * 破块完成由本类监听：掉落基岩物品 + 破坏粒子音效。
 */
public final class BedrockMiningHandler {
   private static final int MAX_PICKAXE_TIER = 6;
   /** 等效硬度：黑曜石 = 50（钻石镐无效率 ≈9.4s/块）。 */
   private static final float BEDROCK_HARDNESS = 50.0F;
   /** 基准挖掘速度 = 钻石镐速度 8（无效率）；dig = 8 + eff² + 1。 */
   private static final float BASE_DIG_SPEED = 8.0F;

   private static boolean initialized;

   private BedrockMiningHandler() {
   }

   public static void initialize() {
      if (initialized) {
         return;
      }
      initialized = true;
      // 服务端：满级遗物镐挖掉基岩 → 掉落基岩物品（可拾取放置），粒子音效反馈
      PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
         if (world.isClient || !state.isOf(Blocks.BEDROCK) || !canBreakWithPickaxe(player)) {
            return;
         }
         BlockState bs = world.getBlockState(pos);
         world.syncWorldEvent(2001, pos, Block.getRawIdFromState(bs));
         world.playSound(null, (double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D,
            SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.7F, 0.9F);
         ItemEntity item = new ItemEntity(
            world, (double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D, new ItemStack(Items.BEDROCK)
         );
         item.setToDefaultPickupDelay();
         world.spawnEntity(item);
      });
   }

   /** 主手是否为「材质满级 M6」的无尽铁镐（双端判定用；不要求服务端实例）。 */
   public static boolean canBreakWithPickaxe(PlayerEntity player) {
      if (player == null || player.isCreative() || player.isSpectator()) {
         return false;
      }
      ItemStack stack = player.getMainHandStack();
      return RelicService.isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)
         && RelicService.value(stack, "tier") == MAX_PICKAXE_TIER;
   }

   /** 基岩挖掘每 tick 进度（双端一致）：dig / 50 / 30，clamp 0..1。 */
   public static float mineDelta(PlayerEntity player) {
      int efficiency = RelicService.value(player.getMainHandStack(), "efficiency");
      float digSpeed = BASE_DIG_SPEED + (float)(efficiency * efficiency) + 1.0F;
      float delta = digSpeed / BEDROCK_HARDNESS / 30.0F;
      return Math.max(0.0F, Math.min(1.0F, delta));
   }
}
