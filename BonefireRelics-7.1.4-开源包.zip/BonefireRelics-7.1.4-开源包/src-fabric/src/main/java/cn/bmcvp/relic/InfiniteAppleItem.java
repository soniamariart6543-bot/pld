package cn.bmcvp.relic;

import java.util.List;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import net.minecraft.text.Text;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.item.Item.Settings;

public class InfiniteAppleItem extends Item {
   public InfiniteAppleItem(Settings settings) {
      super(settings);
   }

   public Text getName(ItemStack stack) {
      return Text.translatable(this.getTranslationKey(stack)).formatted(Formatting.LIGHT_PURPLE);
   }

   public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
      user.setCurrentHand(hand);
      return TypedActionResult.consume(user.getStackInHand(hand));
   }

   public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
      tooltip.add(Text.literal("恢复 25% 最大生命值").formatted(Formatting.GREEN));
      tooltip.add(Text.literal("可去除一项负面效果").formatted(Formatting.BLUE));
   }

   public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
      if (user instanceof ServerPlayerEntity player) {
         player.heal(player.getMaxHealth() * 0.25F);
         player.getHungerManager().add(8, 0.5F);

         for (StatusEffectInstance effect : player.getActiveStatusEffects().values()) {
            if (effect.getEffectType().getCategory() == StatusEffectCategory.HARMFUL) {
               player.removeStatusEffect(effect.getEffectType());
               break;
            }
         }

         world.playSound(
            null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 1.0F, 1.0F
         );
      }

      return stack;
   }

   public int getMaxUseTime(ItemStack stack) {
      return 32;
   }

   public UseAction getUseAction(ItemStack stack) {
      return UseAction.EAT;
   }
}
