package cn.bmcvp.relic;

import com.google.common.collect.Multimap;
import dev.emi.trinkets.api.SlotReference;
import java.util.List;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.world.World;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.item.Item.Settings;
import net.spell_engine.api.item.trinket.SpellBookTrinketItem;

public final class ArcaneCoreSpellBookItem extends SpellBookTrinketItem {
   public ArcaneCoreSpellBookItem(Identifier poolId, Settings settings) {
      super(poolId, settings);
   }

   public Multimap<EntityAttribute, EntityAttributeModifier> getModifiers(ItemStack stack, SlotReference slot, LivingEntity entity, UUID uuid) {
      return ArcaneCoreAttributes.modifiers(stack, uuid);
   }

   public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
      super.appendTooltip(stack, world, tooltip, context);
      ArcaneCoreTooltip.append(stack, tooltip);
   }
}
