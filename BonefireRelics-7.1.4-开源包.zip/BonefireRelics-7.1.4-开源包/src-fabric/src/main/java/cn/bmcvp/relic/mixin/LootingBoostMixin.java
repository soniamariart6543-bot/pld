package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.VoidHeartHandler;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 「穿戴神心时击杀生物 抢夺 +5 级」（2026-09-13 昀晞）。
 *
 * 为什么必须 mixin：1.20.1 的抢夺等级由 `EnchantmentHelper.getLooting(LivingEntity)` 决定，
 * 它只读主手武器上的附魔（外加附魔自带属性），**没有任何事件能在掉落生成前加等级**。
 * 所以这里在返回值上直接 +5（仅对持有/穿戴神心的击杀者生效）。
 */
@Mixin(EnchantmentHelper.class)
public abstract class LootingBoostMixin {
   @Inject(method = "getLooting", at = @At("RETURN"), cancellable = true, require = 0)
   private static void bonefire$boostLooting(LivingEntity entity, CallbackInfoReturnable<Integer> cir) {
      try {
         if (entity instanceof net.minecraft.server.network.ServerPlayerEntity player
            && VoidHeartHandler.isHeldOrWorn(player)) {
            // 神心：抢夺固定 15 级（2026-09-13 昀晞要求）
            cir.setReturnValue(VoidHeartHandler.lootingBonus(player));
         }
      } catch (Throwable ignored) {
      }
   }
}
