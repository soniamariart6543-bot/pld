package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Formatting;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class ArcaneCoreTooltip {
   public static volatile int killsCache;

   private ArcaneCoreTooltip() {
   }

   public static List<String> unlockedSkills(int level) {
      List<String> skills = new ArrayList<>();
      if (ArcaneCoreGrowth.hasMagnet(level)) {
         skills.add("魂引");
      }

      if (ArcaneCoreGrowth.hasExecution(level)) {
         skills.add("破甲斩杀");
      }

      if (level >= 1) {
         skills.add("死而复生");
      }

      if (ArcaneCoreGrowth.hasSoulReaper(level)) {
         skills.add("灵魂收割");
      }

      return skills;
   }

   public static String nextSkill(int level) {
      if (level < 5) {
         return "魂引（Lv.5）";
      } else if (level < 10) {
         return "破甲斩杀（Lv.10）";
      } else {
         return level < 30 ? "灵魂收割（Lv.30）" : null;
      }
   }

   public static void append(ItemStack stack, List<Text> tooltip) {
      int level = ArcaneCoreGrowth.levelOf(stack);
      tooltip.add(Text.literal("秘法核心 · 成长 Lv." + level + " / 30").formatted(new Formatting[]{Formatting.DARK_PURPLE, Formatting.BOLD}));
      if (level >= 30) {
         tooltip.add(Text.literal("已满级：穿戴获得全部成长属性与特性").formatted(Formatting.GOLD));
      } else {
         int next = ArcaneCoreGrowth.killThreshold(level + 1);
         tooltip.add(Text.literal("击杀档案 " + killsCache + " / 升 Lv." + (level + 1) + " 需 " + next).formatted(Formatting.GRAY));
      }

      List<String> unlocked = unlockedSkills(level);
      if (!unlocked.isEmpty()) {
         tooltip.add(Text.literal("成长技能：" + String.join("、", unlocked)).formatted(Formatting.GREEN));
      }

      String nextSkill = nextSkill(level);
      if (nextSkill != null) {
         tooltip.add(Text.literal("下一技能：" + nextSkill).formatted(Formatting.DARK_GRAY));
      }
   }
}
