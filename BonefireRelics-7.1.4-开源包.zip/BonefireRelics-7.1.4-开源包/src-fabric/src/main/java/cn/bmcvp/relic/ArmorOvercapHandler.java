package cn.bmcvp.relic;

import java.lang.reflect.Field;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AfterRespawn;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Join;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;

public final class ArmorOvercapHandler {
   public static final UUID OVERCAP_HEALTH_UUID = UUID.fromString("11111210-0000-0000-0000-000000000001");
   private static final int REFRESH_INTERVAL_TICKS = 10;
   private static boolean initialized;
   private static boolean armorCapRaised;
   private static int tickCounter;

   private ArmorOvercapHandler() {
   }

   public static void initialize() {
      if (!initialized) {
         initialized = true;
         ArmorOvercapConfig.load();
         // 抬升护甲属性上限（2026-09-13 体检：这个方法此前从未被调用，等于「上限抬升」从未生效）
         ensureArmorCapRaised();
         ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
            tickCounter++;
            if (tickCounter % 10 == 0) {
               for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                  refreshPlayer(player);
               }
            }
         });
         ServerPlayConnectionEvents.JOIN.register((Join)(handler, sender, server) -> server.execute(() -> refreshPlayer(handler.player)));
         ServerPlayerEvents.AFTER_RESPAWN.register((AfterRespawn)(oldPlayer, newPlayer, alive) -> refreshPlayer(newPlayer));
      }
   }

   public static void ensureArmorCapRaised() {
      if (!armorCapRaised) {
         armorCapRaised = true;

         try {
            if (EntityAttributes.GENERIC_ARMOR instanceof ClampedEntityAttribute clamped) {
               for (Field field : ClampedEntityAttribute.class.getDeclaredFields()) {
                  if (field.getType() == double.class) {
                     field.setAccessible(true);
                     double value = field.getDouble(clamped);
                     if (value >= 29.0 && value <= 31.0) {
                        field.setDouble(clamped, 220.0);
                        return;
                     }
                  }
               }
            }
         } catch (Exception var8) {
         }
      }
   }

   public static boolean isActive(ServerPlayerEntity player) {
      ArmorOvercapConfig config = ArmorOvercapConfig.get();
      if (!config.enabled) {
         return false;
      }
      // 2026-09-13 昀晞：条件改为「穿神心 或 穿骨甲」任一即可触发
      //  （神心直接激活，不再看"≥N 件骨甲"的件数门槛 —— 融合后骨甲已被吸收，件数恒为 0）
      if (VoidHeartHandler.ownsHeart(player)) {
         return true;
      }
      return countRelicArmor(player) >= config.minRelicArmorPieces;
   }

   private static int countRelicArmor(ServerPlayerEntity player) {
      int count = 0;

      for (ItemStack stack : player.getInventory().armor) {
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            count++;
         }
      }

      return count;
   }

   public static int armorValue(ServerPlayerEntity player) {
      int sum = 0;

      for (ItemStack stack : player.getInventory().armor) {
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            sum += RelicService.value(stack, "armor");
         }
      }
      // ⚠ 关键修复（2026-09-13）：本函数只数"穿在身上的骨甲 NBT"，神心的护甲是**属性修饰器**，
      //   此前完全没被计入 → 融合后骨甲消失 → 护甲和恒为 0 → 超限永远算不出来（界面恒显示"未激活"）。
      if (VoidHeartHandler.ownsHeart(player)) {
         sum += (int)VoidHeartHandler.HEART_ARMOR_BONUS;
      }

      return sum;
   }

   public static int overcapValue(ServerPlayerEntity player) {
      if (!isActive(player)) {
         return 0;
      } else {
         ArmorOvercapConfig config = ArmorOvercapConfig.get();
         return Math.max(0, armorValue(player) - (int)config.threshold);
      }
   }

   public static float reductionOf(ServerPlayerEntity player) {
      if (!isActive(player)) {
         return 0.0F;
      } else {
         ArmorOvercapConfig config = ArmorOvercapConfig.get();
         double reduction = (double)overcapValue(player) * config.drPercentPerPoint / 100.0;
         return (float)Math.min(reduction, config.drCapPercent / 100.0);
      }
   }

   public static float magicResistOf(ServerPlayerEntity player) {
      if (!isActive(player)) {
         return 0.0F;
      } else {
         ArmorOvercapConfig config = ArmorOvercapConfig.get();
         double resist = (double)overcapValue(player) * config.magicResistPercentPerPoint / 100.0;
         return (float)Math.min(resist, config.magicResistCapPercent / 100.0);
      }
   }

   public static void refreshPlayer(ServerPlayerEntity player) {
      ArmorOvercapConfig config = ArmorOvercapConfig.get();
      boolean active = isActive(player);
      int armor = active ? armorValue(player) : 0;
      int overcap = active ? Math.max(0, armor - (int)config.threshold) : 0;
      EntityAttributeInstance health = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
      if (health != null) {
         if (overcap <= 0) {
            if (health.getModifier(OVERCAP_HEALTH_UUID) != null) {
               health.removeModifier(OVERCAP_HEALTH_UUID);
            }
         } else {
            double bonus = Math.min((double)overcap * config.healthPerPoint, config.healthCap);
            double amount;
            Operation operation;
            if (config.isHpMode()) {
               amount = bonus;
               operation = Operation.ADDITION;
            } else {
               amount = bonus / 100.0;
               operation = Operation.MULTIPLY_TOTAL;
            }

            EntityAttributeModifier current = health.getModifier(OVERCAP_HEALTH_UUID);
            if (current == null || current.getValue() != amount || current.getOperation() != operation) {
               health.removeModifier(OVERCAP_HEALTH_UUID);
               if (amount > 0.0) {
                  health.addPersistentModifier(new EntityAttributeModifier(OVERCAP_HEALTH_UUID, "bonefire_relics_armor_overcap_health", amount, operation));
               }
            }
         }
      }
   }

   public static void onUpgradeApplied(ServerPlayerEntity player) {
      refreshPlayer(player);
   }
}
