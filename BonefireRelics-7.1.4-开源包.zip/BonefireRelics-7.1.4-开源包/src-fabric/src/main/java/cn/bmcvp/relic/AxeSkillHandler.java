package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDamage;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * 骨斧（bone_axe）被动技能管线（服务端，事件层；仅普通近战攻击 source=PLAYER_ATTACK 触发）：
 * ① 血涌：普通攻击命中 → 目标流血（每秒掉 1.2% 当前生命，真伤，持续 5 秒，重复命中刷新时长）
 * ② 裂地：普通攻击对同目标累计伤害 ≥ 目标最大生命 × 触发线（Lv1 10% → Lv10 5%）
 *    → 从玩家脚下沿视线发射三道冲击波（正前 / 左 45° / 右 45°），无视方块与实体阻挡，
 *      每 tick 前进、整段 24 格特效必然放完；途经目标造成一次真伤并触发小爆炸（法杖最小爆炸
 *      口径），爆炸不打断波的推进。
 *    冲击波伤害 = 真伤：基础 min(10+8×(lv-1),80) + 目标当前生命 5%
 * ③ 吸血：armor 槽（吸血路线），命中后按 LifestealHandler 回血
 * 环境守卫：伤害全部复用 bonefire_relics:true_magic（B 口径真伤）；dot/波结算在服务端 tick。
 */
public final class AxeSkillHandler {
   private static final float BLEED_RATIO = 0.012F;
   private static final int BLEED_TOTAL_TICKS = 100;
   private static final int BLEED_JUMP_TICKS = 20;
   /** 裂地波总距离：24 格（无视方块/实体，必然放完整段）。 */
   private static final float WAVE_RANGE = 24.0F;
   /** 波每 tick 前进距离（0.6 格/tick → 24 格约 40 tick ≈ 2 秒放完）。 */
   private static final double WAVE_STEP = 0.6D;
   private static final double WAVE_SIDE = Math.toRadians(45.0D);
   private static final float WAVE_SIDE_F = (float)WAVE_SIDE;

   /** 流血中的目标 → 状态（owner 玩家 id / 剩余 tick / 跳血倒计时）。 */
   private static final Map<LivingEntity, BleedState> BLEEDS = new HashMap<>();
   /** 裂地累计：玩家 → 目标 → 已累计伤害。 */
   private static final Map<UUID, Map<UUID, Float>> CRACK_ACCUM = new HashMap<>();
   /** 飞行中的裂地波（服务端主线程逐 tick 推进）。 */
   private static final List<WaveState> WAVES = new ArrayList<>();
   /** 待入队波缓冲：裂地可能在 tickWaves 迭代中再次触发，先缓冲再统一入列（防 CME）。 */
   private static final List<WaveState> PENDING_WAVES = new ArrayList<>();

   private AxeSkillHandler() {
   }

   public static void initialize() {
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((AllowDamage)(entity, source, amount) -> {
         if (amount <= 0.0F) {
            return true;
         }
         LivingEntity target = entity;
         if (!(source.getAttacker() instanceof ServerPlayerEntity player)) {
            return true;
         }
         // 仅普通近战攻击（斧平A）触发；本 mod 真伤/魔法段/环境伤害不进入被动管线
         if (!source.isOf(DamageTypes.PLAYER_ATTACK)) {
            return true;
         }
         ItemStack stack = player.getMainHandStack();
         if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.AXE)) {
            return true;
         }
         if (!target.isAlive() || target.isRemoved() || player.getServer() == null) {
            return true;
         }
         // ① 血涌（普通攻击命中即挂/刷新流血）
         applyBleed(player, target);
         // ③ 吸血（armor 槽=吸血等级，路线与其它吸血相同）
         int vamp = RelicService.value(stack, "armor");
         if (vamp > 0) {
            LifestealHandler.applyLifesteal(player, amount, vamp);
         }
         // ② 裂地累计与触发
         int crack = RelicService.value(stack, "explosion");
         if (crack > 0) {
            handleCrack(player, target, amount, crack);
         }
         return true;
      });
      ServerTickEvents.END_SERVER_TICK.register((EndTick)AxeSkillHandler::tickBleeds);
      ServerTickEvents.END_SERVER_TICK.register((EndTick)AxeSkillHandler::tickWaves);
      // 运行优化：玩家退出时清理其裂地累计/飞行波/由其施加的流血（防内存残留）
      ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
         ServerPlayerEntity player = handler.getPlayer();
         if (player == null) {
            return;
         }
         CRACK_ACCUM.remove(player.getUuid());
         BLEEDS.entrySet().removeIf(entry -> entry.getValue().ownerId.equals(player.getUuid()));
         WAVES.removeIf(wave -> wave.ownerId.equals(player.getUuid()));
      });
   }

   private static void applyBleed(ServerPlayerEntity owner, LivingEntity target) {
      BleedState state = BLEEDS.get(target);
      if (state == null) {
         BLEEDS.put(target, new BleedState(owner.getUuid(), BLEED_TOTAL_TICKS, BLEED_JUMP_TICKS));
      } else {
         state.ownerId = owner.getUuid();
         state.remainTicks = BLEED_TOTAL_TICKS;
      }
   }

   private static void handleCrack(ServerPlayerEntity player, LivingEntity target, float amount, int level) {
      Map<UUID, Float> perTarget = CRACK_ACCUM.computeIfAbsent(player.getUuid(), u -> new HashMap<>());
      float acc = perTarget.getOrDefault(target.getUuid(), 0.0F) + amount;
      double triggerPct = 10.0D - (double)(level - 1) * (5.0D / 9.0D); // Lv1=10% → Lv10=5%
      if (acc >= (double)target.getMaxHealth() * triggerPct / 100.0D) {
         perTarget.put(target.getUuid(), 0.0F);
         enqueueWaves(player, level);
      } else {
         perTarget.put(target.getUuid(), acc);
      }
   }

   /** 从玩家脚下沿视线发射三道裂地波（正前 / 左 45° / 右 45°），入队后逐 tick 推进放完 24 格。 */
   private static void enqueueWaves(ServerPlayerEntity owner, int level) {
      ServerWorld world = owner.getServerWorld();
      Vec3d look = owner.getRotationVec(1.0F);
      Vec3d dir = new Vec3d(look.x, 0.0D, look.z).normalize();
      if (dir.lengthSquared() < 1.0E-4D) {
         dir = owner.getRotationVector();
      }
      // 从玩家脚部略高水平发射：波保持初始高度贴地扫过（不受俯仰/地形影响插入地面）
      Vec3d start = owner.getPos().add(0.0D, 0.8D, 0.0D);
      // 发射起手：一声低音爆
      world.playSound(null, start.x, start.y, start.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.4F, 1.5F);

      for (Vec3d waveDir : new Vec3d[]{dir, dir.rotateY(-WAVE_SIDE_F), dir.rotateY(WAVE_SIDE_F)}) {
         PENDING_WAVES.add(new WaveState(owner.getUuid(), level, start, waveDir, false));
      }
   }

   /** 击杀连锁（试用）：波击杀生物后，以该生物面朝方向在其位置再放一轮裂地（chain=true，仅一层不递归）。 */
   private static void enqueueChainWaves(ServerPlayerEntity owner, int level, LivingEntity dead) {
      ServerWorld world = owner.getServerWorld();
      Vec3d look = dead.getRotationVec(1.0F);
      Vec3d dir = new Vec3d(look.x, 0.0D, look.z).normalize();
      if (dir.lengthSquared() < 1.0E-4D) {
         dir = new Vec3d(owner.getRotationVec(1.0F).x, 0.0D, owner.getRotationVec(1.0F).z).normalize();
      }
      Vec3d start = dead.getPos().add(0.0D, 0.8D, 0.0D);
      world.playSound(null, start.x, start.y, start.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.35F, 1.6F);

      for (Vec3d waveDir : new Vec3d[]{dir, dir.rotateY(-WAVE_SIDE_F), dir.rotateY(WAVE_SIDE_F)}) {
         PENDING_WAVES.add(new WaveState(owner.getUuid(), level, start, waveDir, true));
      }
   }

   /** 逐 tick 推进所有飞行波；无视方块与实体阻挡，整段 24 格必然放完。 */
   private static void tickWaves(MinecraftServer server) {
      if (!PENDING_WAVES.isEmpty()) {
         WAVES.addAll(PENDING_WAVES);
         PENDING_WAVES.clear();
      }
      if (WAVES.isEmpty()) {
         return;
      }
      List<WaveState> finished = new ArrayList<>();

      for (int i = WAVES.size() - 1; i >= 0; i--) {
         WaveState wave = WAVES.get(i);
         ServerPlayerEntity owner = server.getPlayerManager().getPlayer(wave.ownerId);
         if (owner == null || owner.isRemoved() || owner.getServerWorld() == null) {
            finished.add(wave);
            continue;
         }
         ServerWorld world = owner.getServerWorld();
         wave.traveled += WAVE_STEP;
         wave.pos = wave.pos.add(wave.step);
         // —— 波头特效：小烟 + 火焰（发射感）——
         // 波头“火球发射体”视觉（对齐法杖火球尾焰配方）：烟 + 火焰 + 小火
         world.spawnParticles(ParticleTypes.POOF, wave.pos.x, wave.pos.y, wave.pos.z, 1, 0.03D, 0.03D, 0.03D, 0.0D);
         world.spawnParticles(ParticleTypes.FLAME, wave.pos.x, wave.pos.y, wave.pos.z, 3, 0.05D, 0.03D, 0.05D, 0.01D);
         world.spawnParticles(ParticleTypes.SMALL_FLAME, wave.pos.x, wave.pos.y, wave.pos.z, 1, 0.04D, 0.02D, 0.04D, 0.0D);
         // —— 贴地震地感：地面尘烟 + 火焰自地表喷溅 ——
         double groundY = groundSurfaceY(world, wave.pos);
         if (!Double.isNaN(groundY)) {
            world.spawnParticles(ParticleTypes.POOF, wave.pos.x, groundY + 0.12D, wave.pos.z, 1, 0.06D, 0.02D, 0.06D, 0.0D);
            world.spawnParticles(ParticleTypes.FLAME, wave.pos.x, groundY + 0.18D, wave.pos.z, 3, 0.14D, 0.05D, 0.14D, 0.03D);
         }
         // —— 命中判定（每目标全程只结算一次真伤 + 小爆炸，不打断推进）——
         Box box = new Box(
            wave.pos.x - 0.5D, wave.pos.y - 0.9D, wave.pos.z - 0.5D,
            wave.pos.x + 0.5D, wave.pos.y + 0.9D, wave.pos.z + 0.5D
         );
         for (LivingEntity hit : world.getEntitiesByClass(LivingEntity.class, box, e -> e != owner
            && !(e instanceof PlayerEntity)
            && e.isAlive()
            && !e.isRemoved())) {
            if (wave.hitIds.contains(hit.getId())) {
               continue;
            }
            wave.hitIds.add(hit.getId());
            float base = (float)Math.min(10 + (wave.level - 1) * 8, 80);
            hit.damage(WandSkillHandler.trueDamageSource(owner), base + hit.getHealth() * 0.05F);
            // 击杀连锁（概率 50%）：非连锁波击杀生物 → 50% 以该生物面朝方向再放一轮（仅一层，不递归）
            if (!wave.chain && !hit.isAlive() && !hit.isRemoved() && world.random.nextFloat() < 0.5F) {
               enqueueChainWaves(owner, wave.level, hit);
            }
            // 命中小爆炸（对齐法杖最小爆炸：单颗 EXPLOSION + 火焰烟尘，不破坏方块）
            double hitGround = groundSurfaceY(world, wave.pos);
            double boomY = Double.isNaN(hitGround) ? wave.pos.y : hitGround + 0.3D;
            world.spawnParticles(ParticleTypes.EXPLOSION, wave.pos.x, boomY, wave.pos.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            world.spawnParticles(ParticleTypes.FLAME, wave.pos.x, boomY, wave.pos.z, 12, 0.45D, 0.25D, 0.45D, 0.03D);
            world.spawnParticles(ParticleTypes.LARGE_SMOKE, wave.pos.x, boomY, wave.pos.z, 6, 0.3D, 0.15D, 0.3D, 0.02D);
            world.playSound(null, wave.pos.x, boomY, wave.pos.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.7F, 1.0F);
         }
         if (wave.traveled >= WAVE_RANGE) {
            // 整段放完：未命中目标则不爆炸，仅少量烟尘收尾
            if (wave.hitIds.isEmpty()) {
               double endGround = groundSurfaceY(world, wave.pos);
               double endY = Double.isNaN(endGround) ? wave.pos.y : endGround + 0.3D;
               world.spawnParticles(ParticleTypes.POOF, wave.pos.x, endY, wave.pos.z, 2, 0.1D, 0.1D, 0.1D, 0.0D);
            }
            finished.add(wave);
         }
      }
      if (!finished.isEmpty()) {
         WAVES.removeAll(finished);
      }
   }

   /** 向下找最近的方块表面高度（悬空未找到返回 NaN）。 */
   private static double groundSurfaceY(ServerWorld world, Vec3d pos) {
      int bx = (int)Math.floor(pos.x);
      int bz = (int)Math.floor(pos.z);
      int topY = (int)Math.floor(pos.y);
      for (int dy = 0; dy <= 10; dy++) {
         int yy = topY - dy;
         if (yy < world.getBottomY()) {
            break;
         }
         if (!world.getBlockState(new BlockPos(bx, yy, bz)).isAir()) {
            return (double)yy + 1.0D;
         }
      }
      return Double.NaN;
   }

   private static void tickBleeds(MinecraftServer server) {
      if (BLEEDS.isEmpty()) {
         return;
      }
      // 快照遍历 + 完成项统一移除（防与流血重挂/伤害链路上的 CME）
      List<LivingEntity> finished = new ArrayList<>();
      for (LivingEntity target : new ArrayList<>(BLEEDS.keySet())) {
         BleedState state = BLEEDS.get(target);
         if (state == null) {
            continue;
         }
         ServerPlayerEntity owner = server.getPlayerManager().getPlayer(state.ownerId);
         if (!target.isAlive() || target.isRemoved() || target.getWorld().isClient || owner == null || owner.isRemoved()) {
            finished.add(target);
            continue;
         }
         state.remainTicks--;
         state.jumpCooldown--;
         if (state.jumpCooldown <= 0) {
            state.jumpCooldown = BLEED_JUMP_TICKS;
            float damage = target.getHealth() * BLEED_RATIO;
            if (damage > 0.0F && target.isAlive()) {
               target.damage(WandSkillHandler.trueDamageSource(owner), damage);
            }
         }
         if (state.remainTicks <= 0) {
            finished.add(target);
         }
      }
      if (!finished.isEmpty()) {
         finished.forEach(BLEEDS::remove);
      }
   }

   /** 流血状态（可变）。 */
   private static final class BleedState {
      UUID ownerId;
      int remainTicks;
      int jumpCooldown;

      BleedState(UUID ownerId, int remainTicks, int jumpCooldown) {
         this.ownerId = ownerId;
         this.remainTicks = remainTicks;
         this.jumpCooldown = jumpCooldown;
      }
   }

   /** 飞行中的一道裂地波。 */
   private static final class WaveState {
      final UUID ownerId;
      final int level;
      Vec3d pos;
      final Vec3d step;
      double traveled;
      final Set<Integer> hitIds = new HashSet<>();

      final boolean chain;

      WaveState(UUID ownerId, int level, Vec3d start, Vec3d dir, boolean chain) {
         this.ownerId = ownerId;
         this.level = level;
         this.pos = start;
         this.step = dir.multiply(WAVE_STEP);
         this.chain = chain;
      }
   }
}
