package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

public record UpgradeDefinition(
   String id,
   String title,
   UpgradeDefinition.RelicType relic,
   List<UpgradeDefinition.Cost> costs,
   int experienceLevels,
   UpgradeDefinition.Requirement requirement,
   UpgradeDefinition.Effect effect
) {
   public static final int PICKAXE_TIER_MAX = 6;
   private static final Map<String, UpgradeDefinition> BY_ID = buildById();

   private static UpgradeDefinition.Cost c(Item item, int count) {
      return new UpgradeDefinition.Cost(item, Math.max(1, count / 2));
   }

   private static UpgradeDefinition.Requirement r(int tier, int efficiency, int fortune, int fire, int looting, int damage) {
      return new UpgradeDefinition.Requirement(tier, efficiency, fortune, fire, looting, damage, -1, -1);
   }

   private static UpgradeDefinition.Requirement r(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor) {
      return new UpgradeDefinition.Requirement(tier, efficiency, fortune, fire, looting, damage, armor, -1);
   }

   private static UpgradeDefinition.Requirement r8(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor, int explosion) {
      return new UpgradeDefinition.Requirement(tier, efficiency, fortune, fire, looting, damage, armor, explosion);
   }

   private static UpgradeDefinition.Effect x(int tier, int efficiency, int fortune, int fire, int looting, int damage) {
      return new UpgradeDefinition.Effect(tier, efficiency, fortune, fire, looting, damage, -1, -1);
   }

   private static UpgradeDefinition.Effect x(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor) {
      return new UpgradeDefinition.Effect(tier, efficiency, fortune, fire, looting, damage, armor, -1);
   }

   private static UpgradeDefinition.Effect x8(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor, int explosion) {
      return new UpgradeDefinition.Effect(tier, efficiency, fortune, fire, looting, damage, armor, explosion);
   }

   private static String roman(int value) {
      return switch (value) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> Integer.toString(value);
      };
   }

   private static UpgradeDefinition pickaxeMaterial(String id, String title, int from, int to, int experience, List<UpgradeDefinition.Cost> costs) {
      return new UpgradeDefinition(id, title, UpgradeDefinition.RelicType.PICKAXE, costs, experience, r(from, -1, -1, -1, -1, -1), x(to, -1, -1, -1, -1, -1));
   }

   private static UpgradeDefinition boneArmorMaterial(String id, String title, int from, int to, int experience, List<UpgradeDefinition.Cost> costs) {
      return new UpgradeDefinition(id, title, UpgradeDefinition.RelicType.BONE_ARMOR, costs, experience, r(from, -1, -1, -1, -1, -1), x(to, -1, -1, -1, -1, -1));
   }

   private static void addArmorAttributes(List<UpgradeDefinition> routes, UpgradeDefinition.RelicType type, String prefix, String titlePrefix) {
      int[] protExp = new int[]{4, 8, 14, 22};

      for (int level = 2; level <= 5; level++) {
         int cost = 16 << level - 2;
         routes.add(
            new UpgradeDefinition(
               prefix + "prot" + level,
               titlePrefix + "保护 " + roman(level),
               type,
               List.of(c(Items.LAPIS_LAZULI, cost), c(Items.REDSTONE, cost), c(Items.IRON_NUGGET, cost * 2)),
               protExp[level - 2],
               r(-1, level - 1, -1, -1, -1, -1),
               x(-1, level, -1, -1, -1, -1)
            )
         );
      }

      int[] toughExp = new int[]{6, 12, 18, 24};
      List<List<UpgradeDefinition.Cost>> toughCosts = List.of(
         List.of(c(Items.LAPIS_LAZULI, 10), c(Items.EMERALD, 4), c(Items.DIAMOND, 1)),
         List.of(c(Items.LAPIS_LAZULI, 20), c(Items.EMERALD, 8), c(Items.DIAMOND, 2)),
         List.of(c(Items.LAPIS_LAZULI, 40), c(Items.EMERALD, 16), c(Items.DIAMOND, 4)),
         List.of(c(Items.LAPIS_LAZULI, 80), c(Items.EMERALD, 32), c(Items.DIAMOND, 8))
      );

      for (int level = 2; level <= 10; level++) {
         int index = Math.min(level, 5) - 2;
         routes.add(
            new UpgradeDefinition(
               prefix + "tough" + level,
               titlePrefix + "韧性 " + roman(level),
               type,
               toughCosts.get(index),
               toughExp[index],
               r(-1, -1, level - 1, -1, -1, -1),
               x(-1, -1, level, -1, -1, -1)
            )
         );
      }

      routes.add(
         new UpgradeDefinition(
            prefix + "thorn2",
            titlePrefix + "荆棘 II",
            type,
            List.of(c(Items.LAPIS_LAZULI, 32), c(Items.LEATHER, 16), c(Items.BLAZE_POWDER, 8)),
            8,
            r(-1, -1, -1, 1, -1, -1),
            x(-1, -1, -1, 2, -1, -1)
         )
      );
      routes.add(
         new UpgradeDefinition(
            prefix + "thorn3",
            titlePrefix + "荆棘 III",
            type,
            List.of(c(Items.LAPIS_LAZULI, 64), c(Items.LEATHER, 32), c(Items.BLAZE_POWDER, 16)),
            16,
            r(-1, -1, -1, 2, -1, -1),
            x(-1, -1, -1, 3, -1, -1)
         )
      );
      int[] armorExp = new int[]{4, 6, 8, 10, 12};
      List<List<UpgradeDefinition.Cost>> armorCosts = List.of(
         List.of(c(Items.LAPIS_LAZULI, 8), c(Items.EMERALD, 4), c(Items.DIAMOND, 1)),
         List.of(c(Items.LAPIS_LAZULI, 16), c(Items.EMERALD, 8), c(Items.DIAMOND, 2)),
         List.of(c(Items.LAPIS_LAZULI, 32), c(Items.EMERALD, 16), c(Items.DIAMOND, 4)),
         List.of(c(Items.LAPIS_LAZULI, 64), c(Items.EMERALD, 32), c(Items.DIAMOND, 8)),
         List.of(c(Items.LAPIS_LAZULI, 128), c(Items.EMERALD, 64), c(Items.DIAMOND, 16))
      );

      for (int level = 1; level <= 50; level++) {
         int costIndex = (level - 1) / 10;
         routes.add(
            new UpgradeDefinition(
               prefix + "armor" + level,
               titlePrefix + "护甲值 +" + level,
               type,
               armorCosts.get(costIndex),
               armorExp[costIndex],
               r(-1, -1, -1, -1, -1, -1, level - 1),
               x(-1, -1, -1, -1, -1, -1, level)
            )
         );
      }

      addProtectionFamily(routes, type, prefix, titlePrefix, 1, "fp", "火焰保护");
      addProtectionFamily(routes, type, prefix, titlePrefix, 2, "bp", "爆炸保护");
      addProtectionFamily(routes, type, prefix, titlePrefix, 3, "pp", "弹射物保护");
   }

   private static void addProtectionFamily(
      List<UpgradeDefinition> routes, UpgradeDefinition.RelicType type, String prefix, String titlePrefix, int ptype, String key, String name
   ) {
      int[] exp = new int[]{5, 8, 11, 14, 17};

      for (int level = 1; level <= 5; level++) {
         int cost = 8 << level - 1;
         List<UpgradeDefinition.Cost> costs = level == 1
            ? List.of()
            : List.of(c(Items.LAPIS_LAZULI, cost), c(Items.GOLD_INGOT, cost / 2), c(Items.RABBIT_FOOT, level));
         routes.add(
            new UpgradeDefinition(
               prefix + key + level,
               titlePrefix + name + " " + roman(level),
               type,
               costs,
               exp[level - 1],
               r(-1, -1, -1, -1, -1, level - 1),
               x(-1, -1, -1, -1, ptype, level)
            )
         );
      }
   }

   public static List<UpgradeDefinition> all() {
      return UpgradeDefinition.Catalog.ALL;
   }

   private static Map<String, UpgradeDefinition> buildById() {
      Map<String, UpgradeDefinition> map = new HashMap<>();

      for (UpgradeDefinition route : all()) {
         map.put(route.id(), route);
      }

      return Map.copyOf(map);
   }

   public static UpgradeDefinition byId(String id) {
      return BY_ID.get(id);
   }

   private static final class Catalog {
      private static final List<UpgradeDefinition> ALL = create();

      private static List<UpgradeDefinition> create() {
         ArrayList<UpgradeDefinition> routes = new ArrayList<>();
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m1",
               "材质 M1：钻石覆层",
               0,
               1,
               8,
               List.of(
                  UpgradeDefinition.c(Items.DIAMOND, 6),
                  UpgradeDefinition.c(Items.IRON_INGOT, 32),
                  UpgradeDefinition.c(Items.OBSIDIAN, 8),
                  UpgradeDefinition.c(Items.AMETHYST_SHARD, 16)
               )
            )
         );
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m2",
               "材质 M2：下界合金铸体",
               1,
               2,
               18,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 1),
                  UpgradeDefinition.c(Items.ANCIENT_DEBRIS, 4),
                  UpgradeDefinition.c(Items.DIAMOND, 12),
                  UpgradeDefinition.c(Items.BLAZE_ROD, 8),
                  UpgradeDefinition.c(Items.MAGMA_CREAM, 16),
                  UpgradeDefinition.c(Items.ECHO_SHARD, 1)
               )
            )
         );
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m3",
               "材质 M3：下界合金·铁",
               2,
               3,
               24,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 2),
                  UpgradeDefinition.c(Items.IRON_BLOCK, 16),
                  UpgradeDefinition.c(Items.GOLD_INGOT, 16),
                  UpgradeDefinition.c(Items.NETHERITE_SCRAP, 4)
               )
            )
         );
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m4",
               "材质 M4：下界合金·金",
               3,
               4,
               28,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 4),
                  UpgradeDefinition.c(Items.GOLD_BLOCK, 16),
                  UpgradeDefinition.c(Items.EMERALD, 16),
                  UpgradeDefinition.c(Items.NETHERITE_SCRAP, 8)
               )
            )
         );
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m5",
               "材质 M5：下界合金·绿宝石",
               4,
               5,
               30,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 8),
                  UpgradeDefinition.c(Items.EMERALD_BLOCK, 16),
                  UpgradeDefinition.c(Items.DIAMOND_BLOCK, 8),
                  UpgradeDefinition.c(Items.NETHERITE_BLOCK, 1)
               )
            )
         );
         routes.add(
            UpgradeDefinition.pickaxeMaterial(
               "m6",
               "材质 M6：下界合金·钻石",
               5,
               6,
               30,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 16),
                  UpgradeDefinition.c(Items.DIAMOND_BLOCK, 16),
                  UpgradeDefinition.c(Items.NETHERITE_BLOCK, 4),
                  UpgradeDefinition.c(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, 1)
               )
            )
         );
         routes.add(
            new UpgradeDefinition(
               "eff2",
               "效率 II",
               UpgradeDefinition.RelicType.PICKAXE,
               List.of(
                  UpgradeDefinition.c(Items.LAPIS_LAZULI, 16),
                  UpgradeDefinition.c(Items.REDSTONE, 16),
                  UpgradeDefinition.c(Items.IRON_NUGGET, 32)
               ),
               4,
               UpgradeDefinition.r(-1, 1, -1, -1, -1, -1),
               UpgradeDefinition.x(-1, 2, -1, -1, -1, -1)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "eff3",
               "效率 III",
               UpgradeDefinition.RelicType.PICKAXE,
               List.of(
                  UpgradeDefinition.c(Items.LAPIS_LAZULI, 32),
                  UpgradeDefinition.c(Items.REDSTONE, 32),
                  UpgradeDefinition.c(Items.IRON_NUGGET, 64)
               ),
               8,
               UpgradeDefinition.r(-1, 2, -1, -1, -1, -1),
               UpgradeDefinition.x(-1, 3, -1, -1, -1, -1)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "eff4",
               "效率 IV",
               UpgradeDefinition.RelicType.PICKAXE,
               List.of(
                  UpgradeDefinition.c(Items.LAPIS_LAZULI, 64),
                  UpgradeDefinition.c(Items.REDSTONE, 64),
                  UpgradeDefinition.c(Items.IRON_NUGGET, 128)
               ),
               14,
               UpgradeDefinition.r(-1, 3, -1, -1, -1, -1),
               UpgradeDefinition.x(-1, 4, -1, -1, -1, -1)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "eff5",
               "效率 V",
               UpgradeDefinition.RelicType.PICKAXE,
               List.of(
                  UpgradeDefinition.c(Items.LAPIS_LAZULI, 128),
                  UpgradeDefinition.c(Items.REDSTONE, 128),
                  UpgradeDefinition.c(Items.IRON_NUGGET, 256)
               ),
               22,
               UpgradeDefinition.r(-1, 4, -1, -1, -1, -1),
               UpgradeDefinition.x(-1, 5, -1, -1, -1, -1)
            )
         );
         List<List<UpgradeDefinition.Cost>> fortuneCosts = List.of(
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 10), UpgradeDefinition.c(Items.EMERALD, 4), UpgradeDefinition.c(Items.DIAMOND, 1)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 20), UpgradeDefinition.c(Items.EMERALD, 8), UpgradeDefinition.c(Items.DIAMOND, 2)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 40), UpgradeDefinition.c(Items.EMERALD, 16), UpgradeDefinition.c(Items.DIAMOND, 4)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 80), UpgradeDefinition.c(Items.EMERALD, 32), UpgradeDefinition.c(Items.DIAMOND, 8)
            )
         );
         int[] fortuneExperience = new int[]{6, 12, 18, 24};

         for (int level = 2; level <= 10; level++) {
            int index = Math.min(level, 5) - 2;
            routes.add(
               new UpgradeDefinition(
                  "fortune" + level,
                  "时运 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.PICKAXE,
                  fortuneCosts.get(index),
                  fortuneExperience[index],
                  UpgradeDefinition.r(-1, -1, level - 1, -1, -1, -1),
                  UpgradeDefinition.x(-1, -1, level, -1, -1, -1)
               )
            );
         }

         routes.add(
            new UpgradeDefinition(
               "d1",
               "伤害 D1：主手 +10",
               UpgradeDefinition.RelicType.BONE,
               List.of(UpgradeDefinition.c(Items.ROTTEN_FLESH, 64), UpgradeDefinition.c(Items.STRING, 32)),
               5,
               UpgradeDefinition.r(-1, -1, -1, -1, -1, 0),
               UpgradeDefinition.x(-1, -1, -1, -1, -1, 1)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "d2",
               "伤害 D2：主手 +11",
               UpgradeDefinition.RelicType.BONE,
               List.of(
                  UpgradeDefinition.c(Items.ROTTEN_FLESH, 128),
                  UpgradeDefinition.c(Items.SPIDER_EYE, 32),
                  UpgradeDefinition.c(Items.FERMENTED_SPIDER_EYE, 8)
               ),
               11,
               UpgradeDefinition.r(-1, -1, -1, -1, -1, 1),
               UpgradeDefinition.x(-1, -1, -1, -1, -1, 2)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "d3",
               "伤害 D3：主手 +12",
               UpgradeDefinition.RelicType.BONE,
               List.of(
                  UpgradeDefinition.c(Items.GUNPOWDER, 64), UpgradeDefinition.c(Items.SLIME_BALL, 32), UpgradeDefinition.c(Items.PHANTOM_MEMBRANE, 8)
               ),
               20,
               UpgradeDefinition.r(-1, -1, -1, -1, -1, 2),
               UpgradeDefinition.x(-1, -1, -1, -1, -1, 3)
            )
         );
         List<UpgradeDefinition.Cost> dragonBoneFormula = List.of(
            UpgradeDefinition.c(Items.BONE, 256),
            UpgradeDefinition.c(Items.ROTTEN_FLESH, 256),
            UpgradeDefinition.c(Items.BLAZE_POWDER, 64),
            UpgradeDefinition.c(Items.DRAGON_BREATH, 8)
         );

         for (int stage = 4; stage <= 41; stage++) {
            int bonusDamage = 9 + stage;
            routes.add(
               new UpgradeDefinition(
                  "d" + stage,
                  "伤害 D" + stage + "：主手 +" + bonusDamage,
                  UpgradeDefinition.RelicType.BONE,
                  dragonBoneFormula,
                  30,
                  UpgradeDefinition.r(-1, -1, -1, -1, -1, stage - 1),
                  UpgradeDefinition.x(-1, -1, -1, -1, -1, stage)
               )
            );
         }

         routes.add(
            new UpgradeDefinition(
               "fire2",
               "火焰附加 II",
               UpgradeDefinition.RelicType.BONE,
               List.of(
                  UpgradeDefinition.c(Items.LAPIS_LAZULI, 32), UpgradeDefinition.c(Items.LEATHER, 16), UpgradeDefinition.c(Items.BLAZE_POWDER, 8)
               ),
               8,
               UpgradeDefinition.r(-1, -1, -1, 1, -1, -1),
               UpgradeDefinition.x(-1, -1, -1, 2, -1, -1)
            )
         );
         List<List<UpgradeDefinition.Cost>> lootCosts = List.of(
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 32), UpgradeDefinition.c(Items.EMERALD, 16), UpgradeDefinition.c(Items.RABBIT_FOOT, 4)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 64), UpgradeDefinition.c(Items.EMERALD, 32), UpgradeDefinition.c(Items.RABBIT_FOOT, 8)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 128), UpgradeDefinition.c(Items.EMERALD, 64), UpgradeDefinition.c(Items.RABBIT_FOOT, 16)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 256), UpgradeDefinition.c(Items.EMERALD, 128), UpgradeDefinition.c(Items.RABBIT_FOOT, 32)
            )
         );
         int[] lootExperience = new int[]{8, 16, 24, 30};

         for (int level = 2; level <= 10; level++) {
            int index = Math.min(level, 5) - 2;
            routes.add(
               new UpgradeDefinition(
                  "loot" + level,
                  "抢夺 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.BONE,
                  lootCosts.get(index),
                  lootExperience[index],
                  UpgradeDefinition.r(-1, -1, -1, -1, level - 1, -1),
                  UpgradeDefinition.x(-1, -1, -1, -1, level, -1)
               )
            );
         }

         int[] lsExp = new int[]{6, 10, 14, 18, 22};
         List<List<UpgradeDefinition.Cost>> lsCosts = List.of(
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 16), UpgradeDefinition.c(Items.GOLD_INGOT, 8), UpgradeDefinition.c(Items.DIAMOND, 1)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 32), UpgradeDefinition.c(Items.GOLD_INGOT, 16), UpgradeDefinition.c(Items.DIAMOND, 2)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 64), UpgradeDefinition.c(Items.GOLD_INGOT, 32), UpgradeDefinition.c(Items.DIAMOND, 4)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 128), UpgradeDefinition.c(Items.GOLD_INGOT, 64), UpgradeDefinition.c(Items.DIAMOND, 8)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 256), UpgradeDefinition.c(Items.GOLD_INGOT, 128), UpgradeDefinition.c(Items.DIAMOND, 16)
            )
         );

         for (int level = 1; level <= 10; level++) {
            int costIndex = (level - 1) / 2;
            routes.add(
               new UpgradeDefinition(
                  "lifesteal" + level,
                  "吸血 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.BONE,
                  lsCosts.get(costIndex),
                  lsExp[costIndex],
                  UpgradeDefinition.r(-1, -1, level - 1, -1, -1, -1),
                  UpgradeDefinition.x(-1, -1, level, -1, -1, -1)
               )
            );
         }

         routes.add(
            UpgradeDefinition.boneArmorMaterial(
               "bam1",
               "材质 B1：钻石骨甲（护甲值 +5）",
               0,
               1,
               8,
               List.of(
                  UpgradeDefinition.c(Items.DIAMOND, 6), UpgradeDefinition.c(Items.IRON_INGOT, 32), UpgradeDefinition.c(Items.OBSIDIAN, 8)
               )
            )
         );
         routes.add(
            UpgradeDefinition.boneArmorMaterial(
               "bam2",
               "材质 B2：下界合金骨甲（护甲值 +5）",
               1,
               2,
               18,
               List.of(
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 1),
                  UpgradeDefinition.c(Items.ANCIENT_DEBRIS, 4),
                  UpgradeDefinition.c(Items.DIAMOND, 12),
                  UpgradeDefinition.c(Items.BLAZE_ROD, 8)
               )
            )
         );
         UpgradeDefinition.addArmorAttributes(routes, UpgradeDefinition.RelicType.BONE_ARMOR, "ba_", "骨甲·");
         routes.add(
            new UpgradeDefinition(
               "soul1",
               "材质 S1：下界灵魂之杖",
               UpgradeDefinition.RelicType.WAND,
               List.of(
                  UpgradeDefinition.c(Items.NETHER_STAR, 2),
                  UpgradeDefinition.c(Items.NETHERITE_INGOT, 6),
                  UpgradeDefinition.c(Items.SOUL_SAND, 64),
                  UpgradeDefinition.c(Items.GLOWSTONE_DUST, 32),
                  UpgradeDefinition.c(Items.BLAZE_POWDER, 16),
                  UpgradeDefinition.c(Items.GHAST_TEAR, 4)
               ),
               30,
               UpgradeDefinition.r(0, -1, -1, -1, -1, -1, 30),
               UpgradeDefinition.x(1, -1, -1, -1, -1, -1)
            )
         );
         int[] spellExp = new int[]{5, 11, 20, 30};
         List<List<UpgradeDefinition.Cost>> spellCosts = List.of(
            List.of(UpgradeDefinition.c(Items.BLAZE_POWDER, 32), UpgradeDefinition.c(Items.GLOWSTONE_DUST, 16)),
            List.of(
               UpgradeDefinition.c(Items.BLAZE_POWDER, 64), UpgradeDefinition.c(Items.GLOWSTONE_DUST, 32), UpgradeDefinition.c(Items.GHAST_TEAR, 8)
            ),
            List.of(
               UpgradeDefinition.c(Items.MAGMA_CREAM, 64), UpgradeDefinition.c(Items.ENDER_PEARL, 16), UpgradeDefinition.c(Items.BLAZE_ROD, 32)
            )
         );
         List<UpgradeDefinition.Cost> spellFixed = List.of(
            UpgradeDefinition.c(Items.BLAZE_POWDER, 128), UpgradeDefinition.c(Items.GLOWSTONE_DUST, 64), UpgradeDefinition.c(Items.ENDER_PEARL, 16)
         );

         for (int level = 1; level <= 30; level++) {
            int costIndex = level <= 12 ? (level - 1) / 4 : 3;
            routes.add(
               new UpgradeDefinition(
                  "spell" + level,
                  "法术强度 +" + level,
                  UpgradeDefinition.RelicType.WAND,
                  level <= 12 ? spellCosts.get(costIndex) : spellFixed,
                  costIndex >= 3 ? 30 : spellExp[costIndex],
                  UpgradeDefinition.r(-1, -1, -1, -1, -1, -1, level - 1),
                  UpgradeDefinition.x(-1, -1, -1, -1, -1, -1, level)
               )
            );
         }

         int[] wlsExp = new int[]{6, 10, 14, 18, 22};
         List<List<UpgradeDefinition.Cost>> wlsCosts = List.of(
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 16), UpgradeDefinition.c(Items.GOLD_INGOT, 8), UpgradeDefinition.c(Items.DIAMOND, 1)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 32), UpgradeDefinition.c(Items.GOLD_INGOT, 16), UpgradeDefinition.c(Items.DIAMOND, 2)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 64), UpgradeDefinition.c(Items.GOLD_INGOT, 32), UpgradeDefinition.c(Items.DIAMOND, 4)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 128), UpgradeDefinition.c(Items.GOLD_INGOT, 64), UpgradeDefinition.c(Items.DIAMOND, 8)
            ),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 256), UpgradeDefinition.c(Items.GOLD_INGOT, 128), UpgradeDefinition.c(Items.DIAMOND, 16)
            )
         );

         for (int level = 1; level <= 10; level++) {
            int costIndex = (level - 1) / 2;
            routes.add(
               new UpgradeDefinition(
                  "wlifesteal" + level,
                  "吸血 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.WAND,
                  wlsCosts.get(costIndex),
                  wlsExp[costIndex],
                  UpgradeDefinition.r(-1, -1, level - 1, -1, -1, -1),
                  UpgradeDefinition.x(-1, -1, level, -1, -1, -1)
               )
            );
         }

         int[] explExp = new int[]{6, 10, 14, 18, 22, 26, 30, 34, 38, 42};
         List<List<UpgradeDefinition.Cost>> explCosts = List.of(
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 16), UpgradeDefinition.c(Items.BLAZE_POWDER, 8)),
            List.of(
               UpgradeDefinition.c(Items.GUNPOWDER, 32), UpgradeDefinition.c(Items.BLAZE_POWDER, 16), UpgradeDefinition.c(Items.GHAST_TEAR, 4)
            ),
            List.of(
               UpgradeDefinition.c(Items.GUNPOWDER, 64), UpgradeDefinition.c(Items.MAGMA_CREAM, 16), UpgradeDefinition.c(Items.ENDER_PEARL, 8)
            ),
            List.of(
               UpgradeDefinition.c(Items.GUNPOWDER, 128), UpgradeDefinition.c(Items.MAGMA_CREAM, 32), UpgradeDefinition.c(Items.ENDER_PEARL, 16)
            ),
            List.of(
               UpgradeDefinition.c(Items.GUNPOWDER, 256), UpgradeDefinition.c(Items.MAGMA_CREAM, 64), UpgradeDefinition.c(Items.ENDER_PEARL, 32)
            )
         );

         for (int level = 1; level <= 10; level++) {
            int costIndex = (level - 1) / 2;
            routes.add(
               new UpgradeDefinition(
                  "expl" + level,
                  "爆炸 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.WAND,
                  explCosts.get(costIndex),
                  explExp[costIndex],
                  UpgradeDefinition.r8(-1, -1, -1, -1, -1, -1, -1, level - 1),
                  UpgradeDefinition.x8(-1, -1, -1, -1, -1, -1, -1, level)
               )
            );
         }

         routes.add(
            new UpgradeDefinition(
               "expl11",
               "爆炸 XI",
               UpgradeDefinition.RelicType.WAND,
               List.of(
                  UpgradeDefinition.c(Items.GUNPOWDER, 300),
                  UpgradeDefinition.c(Items.MAGMA_CREAM, 80),
                  UpgradeDefinition.c(Items.ENDER_PEARL, 40)
               ),
               46,
               UpgradeDefinition.r8(1, -1, -1, -1, -1, -1, -1, 10),
               UpgradeDefinition.x8(1, -1, -1, -1, -1, -1, -1, 11)
            )
         );
         routes.add(
            new UpgradeDefinition(
               "expl12",
               "爆炸 XII",
               UpgradeDefinition.RelicType.WAND,
               List.of(
                  UpgradeDefinition.c(Items.GUNPOWDER, 400),
                  UpgradeDefinition.c(Items.MAGMA_CREAM, 100),
                  UpgradeDefinition.c(Items.ENDER_PEARL, 50),
                  UpgradeDefinition.c(Items.NETHER_STAR, 2)
               ),
               50,
               UpgradeDefinition.r8(1, -1, -1, -1, -1, -1, -1, 11),
               UpgradeDefinition.x8(1, -1, -1, -1, -1, -1, -1, 12)
            )
         );
         addBoneAxeRoutes(routes);
         return List.copyOf(routes);
      }

      /** 骨斧（RelicType.AXE）路线：材质3 / 效率II-X / 时运II-X / 巨力1-27 / 裂地1-10 / 吸血1-10。 */
      private static void addBoneAxeRoutes(List<UpgradeDefinition> routes) {
         // —— 材质：2 级到顶（骨=铁级 → M1 钻石 / M2 下界合金），每级攻击 +5（伤害公式含 5×tier）——
         int[] axeMExp = new int[]{20, 30};
         List<List<UpgradeDefinition.Cost>> axeMCosts = List.of(
            List.of(UpgradeDefinition.c(Items.DIAMOND, 8), UpgradeDefinition.c(Items.IRON_BLOCK, 12), UpgradeDefinition.c(Items.AMETHYST_SHARD, 24)),
            List.of(
               UpgradeDefinition.c(Items.NETHERITE_INGOT, 4),
               UpgradeDefinition.c(Items.DIAMOND_BLOCK, 12),
               UpgradeDefinition.c(Items.ANCIENT_DEBRIS, 8),
               UpgradeDefinition.c(Items.NETHERITE_SCRAP, 12)
            )
         );
         String[] axeMNames = new String[]{"钻石骨斧（攻击 +5）", "下界合金骨斧（攻击 +10）"};

         for (int i = 1; i <= 2; i++) {
            routes.add(
               new UpgradeDefinition(
                  "axe_m" + i,
                  "材质 M" + i + "：" + axeMNames[i - 1],
                  UpgradeDefinition.RelicType.AXE,
                  axeMCosts.get(i - 1),
                  axeMExp[i - 1],
                  UpgradeDefinition.r(i - 1, -1, -1, -1, -1, -1),
                  UpgradeDefinition.x(i, -1, -1, -1, -1, -1)
               )
            );
         }

         // —— 效率 II..X（初始 I）——
         int[] axeEffExp = new int[]{4, 8, 14, 22, 32, 44, 58, 74, 92};
         List<List<UpgradeDefinition.Cost>> axeEffCosts = List.of(
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 16), UpgradeDefinition.c(Items.REDSTONE, 16), UpgradeDefinition.c(Items.IRON_NUGGET, 32)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 64), UpgradeDefinition.c(Items.REDSTONE, 64), UpgradeDefinition.c(Items.IRON_NUGGET, 128)),
            List.of(
               UpgradeDefinition.c(Items.LAPIS_LAZULI, 256), UpgradeDefinition.c(Items.REDSTONE, 256), UpgradeDefinition.c(Items.IRON_INGOT, 32)
            )
         );

         for (int level = 2; level <= 10; level++) {
            int costIndex = Math.min((level - 1) / 3, 2);
            routes.add(
               new UpgradeDefinition(
                  "axe_eff" + level,
                  "效率 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.AXE,
                  axeEffCosts.get(costIndex),
                  axeEffExp[level - 2],
                  UpgradeDefinition.r(-1, level - 1, -1, -1, -1, -1),
                  UpgradeDefinition.x(-1, level, -1, -1, -1, -1)
               )
            );
         }

         // —— 时运 II..X（初始 I，成本曲线同镐 4 档循环）——
         List<List<UpgradeDefinition.Cost>> axeForCosts = List.of(
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 10), UpgradeDefinition.c(Items.EMERALD, 4), UpgradeDefinition.c(Items.DIAMOND, 1)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 20), UpgradeDefinition.c(Items.EMERALD, 8), UpgradeDefinition.c(Items.DIAMOND, 2)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 40), UpgradeDefinition.c(Items.EMERALD, 16), UpgradeDefinition.c(Items.DIAMOND, 4)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 80), UpgradeDefinition.c(Items.EMERALD, 32), UpgradeDefinition.c(Items.DIAMOND, 8))
         );
         int[] axeForExp = new int[]{6, 12, 18, 24};

         for (int level = 2; level <= 10; level++) {
            int index = Math.min(level, 5) - 2;
            routes.add(
               new UpgradeDefinition(
                  "axe_for" + level,
                  "时运 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.AXE,
                  axeForCosts.get(index),
                  axeForExp[index],
                  UpgradeDefinition.r(-1, -1, level - 1, -1, -1, -1),
                  UpgradeDefinition.x(-1, -1, level, -1, -1, -1)
               )
            );
         }

         // —— 巨力：0..32，每级攻击 +1（仿骨头伤害 D 线；骨=铁级 8+5×材质(0..2)+巨力=最高 50）——
         List<UpgradeDefinition.Cost> axeGiantHeavy = List.of(
            UpgradeDefinition.c(Items.BONE, 256),
            UpgradeDefinition.c(Items.ROTTEN_FLESH, 256),
            UpgradeDefinition.c(Items.PHANTOM_MEMBRANE, 16),
            UpgradeDefinition.c(Items.DRAGON_BREATH, 8)
         );

         for (int stage = 1; stage <= 32; stage++) {
            List<UpgradeDefinition.Cost> costs;
            int exp;
            if (stage == 1) {
               costs = List.of(UpgradeDefinition.c(Items.BONE, 64), UpgradeDefinition.c(Items.ROTTEN_FLESH, 64));
               exp = 5;
            } else if (stage == 2) {
               costs = List.of(UpgradeDefinition.c(Items.BONE, 128), UpgradeDefinition.c(Items.SPIDER_EYE, 32), UpgradeDefinition.c(Items.GUNPOWDER, 64));
               exp = 11;
            } else if (stage == 3) {
               costs = List.of(UpgradeDefinition.c(Items.BONE, 192), UpgradeDefinition.c(Items.BLAZE_POWDER, 64), UpgradeDefinition.c(Items.GHAST_TEAR, 8));
               exp = 20;
            } else {
               costs = axeGiantHeavy;
               exp = 30;
            }

            routes.add(
               new UpgradeDefinition(
                  "axe_g" + stage,
                  "巨力 G" + stage + "：主手 +" + (8 + stage),
                  UpgradeDefinition.RelicType.AXE,
                  costs,
                  exp,
                  UpgradeDefinition.r(-1, -1, -1, -1, -1, stage - 1),
                  UpgradeDefinition.x(-1, -1, -1, -1, -1, stage)
               )
            );
         }

         // —— 裂地 I..X（explosion 槽；触发线 10%→5%，波基础真伤 10→80）——
         int[] crackExp = new int[]{6, 10, 14, 18, 22, 26, 30, 34, 38, 42};
         List<List<UpgradeDefinition.Cost>> crackCosts = List.of(
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 8), UpgradeDefinition.c(Items.BONE, 16)),
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 16), UpgradeDefinition.c(Items.BLAZE_POWDER, 8), UpgradeDefinition.c(Items.GHAST_TEAR, 2)),
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 32), UpgradeDefinition.c(Items.MAGMA_CREAM, 8), UpgradeDefinition.c(Items.ENDER_PEARL, 4)),
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 64), UpgradeDefinition.c(Items.MAGMA_CREAM, 16), UpgradeDefinition.c(Items.ENDER_PEARL, 8)),
            List.of(UpgradeDefinition.c(Items.GUNPOWDER, 128), UpgradeDefinition.c(Items.MAGMA_CREAM, 32), UpgradeDefinition.c(Items.ENDER_PEARL, 16))
         );

         for (int level = 1; level <= 10; level++) {
            int costIndex = (level - 1) / 2;
            routes.add(
               new UpgradeDefinition(
                  "axe_crack" + level,
                  "裂地 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.AXE,
                  crackCosts.get(costIndex),
                  crackExp[costIndex],
                  UpgradeDefinition.r8(-1, -1, -1, -1, -1, -1, -1, level - 1),
                  UpgradeDefinition.x8(-1, -1, -1, -1, -1, -1, -1, level)
               )
            );
         }

         // —— 吸血 I..X（armor 槽；路线与其他吸血相同：青金石/金锭/钻石曲线）——
         int[] axeVampExp = new int[]{6, 10, 14, 18, 22};
         List<List<UpgradeDefinition.Cost>> axeVampCosts = List.of(
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 16), UpgradeDefinition.c(Items.GOLD_INGOT, 8), UpgradeDefinition.c(Items.DIAMOND, 1)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 32), UpgradeDefinition.c(Items.GOLD_INGOT, 16), UpgradeDefinition.c(Items.DIAMOND, 2)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 64), UpgradeDefinition.c(Items.GOLD_INGOT, 32), UpgradeDefinition.c(Items.DIAMOND, 4)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 128), UpgradeDefinition.c(Items.GOLD_INGOT, 64), UpgradeDefinition.c(Items.DIAMOND, 8)),
            List.of(UpgradeDefinition.c(Items.LAPIS_LAZULI, 256), UpgradeDefinition.c(Items.GOLD_INGOT, 128), UpgradeDefinition.c(Items.DIAMOND, 16))
         );

         for (int level = 1; level <= 10; level++) {
            int costIndex = (level - 1) / 2;
            routes.add(
               new UpgradeDefinition(
                  "axe_vamp" + level,
                  "吸血 " + UpgradeDefinition.roman(level),
                  UpgradeDefinition.RelicType.AXE,
                  axeVampCosts.get(costIndex),
                  axeVampExp[costIndex],
                  UpgradeDefinition.r8(-1, -1, -1, -1, -1, -1, level - 1, -1),
                  UpgradeDefinition.x8(-1, -1, -1, -1, -1, -1, level, -1)
               )
            );
         }
      }
   }

   public static record Cost(Item item, int count) {
   }

   public static record Effect(int materialTier, int efficiency, int fortune, int fireAspect, int looting, int boneDamage, int armor, int explosion) {
   }

   public static enum RelicType {
      PICKAXE,
      BONE,
      BONE_ARMOR,
      WAND,
      AXE;
   }

   public static record Requirement(int materialTier, int efficiency, int fortune, int fireAspect, int looting, int boneDamage, int armor, int explosion) {
   }
}
