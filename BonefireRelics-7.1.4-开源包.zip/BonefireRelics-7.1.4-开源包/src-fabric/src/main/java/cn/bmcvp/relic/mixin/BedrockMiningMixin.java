package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.BedrockMiningHandler;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 无尽铁镐「破岩」：材质满级（M6）时把基岩的挖掘速度 delta 改为等效「钻石镐无效率挖黑曜石」
 * （等效硬度 50、dig = 8 + eff² + 1，沿原版效率公式）→ 原版挖掘管线全程接管
 * （客户端进度条/长按/松手取消/服务端破块全部自动），双端同逻辑。
 * 参考实现：nok-ko/bedrock-breaking 的 AbstractBlock mixin 思路（CC0）。
 */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BedrockMiningMixin {
   @Inject(method = {"calcBlockBreakingDelta"}, at = {@At("HEAD")}, cancellable = true)
   private void bmcvp$bedrockDelta(PlayerEntity player, BlockView world, BlockPos pos, CallbackInfoReturnable<Float> cir) {
      if (!BedrockMiningHandler.canBreakWithPickaxe(player)) {
         return;
      }
      BlockState state = world.getBlockState(pos);
      if (state.isOf(Blocks.BEDROCK)) {
         cir.setReturnValue(BedrockMiningHandler.mineDelta(player));
      }
   }
}
