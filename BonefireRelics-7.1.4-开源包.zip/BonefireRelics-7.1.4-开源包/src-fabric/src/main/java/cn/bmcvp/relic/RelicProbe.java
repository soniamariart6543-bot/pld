package cn.bmcvp.relic;

import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketInventory;
import dev.emi.trinkets.api.TrinketsApi;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 临时诊断探针（2026-09-12 昀晞要求安装）。
 *
 * 用途两条：
 *  1) 遗物审计：每 20 tick 扫一遍玩家背包 + 饰品栏里的遗物（含秘法核心），
 *     与上一次快照比对，任何「失去 / 获得 / 数量变化」都写进
 *     `<gameDir>/logs/bonefire-audit-<yyyyMMdd>.log`。
 *     → 下次再出现「战利品骨头 / 野生果奶 消失」，日志能直接指认时间点与槽位。
 *  2) 客户端界面探针：每 20 tick 记录一次当前 ScreenHandler 的类名 / 槽位数 / syncId，
 *     只在变化时写 `<gameDir>/logs/bonefire-probe-client-<yyyyMMdd>.log`。
 *     → 用来钉死「客户端 54 格 vs 服务端发 54/55」那个槽位不同步到底出在哪个界面。
 *
 * 探针只读不写游戏数据（不吃物品、不改背包），确定问题后可整类删除：
 * 删掉本文件 + 主类里的 RelicProbe.initialize() + 客户端里的 RelicProbe.initializeClient() 即可。
 */
public final class RelicProbe {
   /**
    * 总开关：默认**关闭**（发布版零输出）。
    * 需要用诊断时给游戏 JVM 加启动参数 {@code -Dbonefire.probe=true} 即可开启，
    * 无需改代码重新构建（2026-09-13 体检：探针不该常驻生产构建）。
    */
   public static final boolean ENABLED = Boolean.getBoolean("bonefire.probe");

   private static final Logger LOGGER = LoggerFactory.getLogger("bonefire_probe");
   private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
   private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyyMMdd");

   /** 每个玩家上一次的遗物快照：key = 槽位标识，value = 物品 id x 数量。 */
   private static final Map<UUID, Map<String, String>> LAST = new ConcurrentHashMap<>();
   private static final Map<UUID, Integer> LAST_TICK = new ConcurrentHashMap<>();
   private static final Map<UUID, Boolean> FIRST_DONE = new ConcurrentHashMap<>();
   private static String lastClientHandler = "";
   private static int clientTicks;

   private RelicProbe() {
   }

   public static void initialize() {
      if (!ENABLED) {
         return;
      }
      ServerTickEvents.END_SERVER_TICK.register(RelicProbe::onServerTick);
      LOGGER.info("[PROBE] 遗物审计探针已启用 → logs/bonefire-audit-<日期>.log");
   }

   @Environment(EnvType.CLIENT)
   public static void initializeClient() {
      if (!ENABLED) {
         return;
      }
      ClientTickEvents.END_CLIENT_TICK.register(RelicProbe::onClientTick);
      LOGGER.info("[PROBE] 客户端界面探针已启用 → logs/bonefire-probe-client-<日期>.log");
   }

   private static Path auditFile() {
      return FabricLoader.getInstance().getGameDir().resolve("logs").resolve("bonefire-audit-" + LocalDateTime.now().format(DAY) + ".log");
   }

   private static Path screenFile() {
      return FabricLoader.getInstance().getGameDir().resolve("logs").resolve("bonefire-probe-client-" + LocalDateTime.now().format(DAY) + ".log");
   }

   private static void write(Path file, String line) {
      String row = "[" + LocalDateTime.now().format(CLOCK) + "] " + line + System.lineSeparator();
      try {
         Files.createDirectories(file.getParent());
         Files.writeString(file, row, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
      } catch (IOException error) {
         // 探针本身绝不影响游戏
      }
      LOGGER.info(line);
   }

   private static void onServerTick(MinecraftServer server) {
      for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
         try {
            sample(player);
         } catch (Throwable error) {
            // 探针不得打断游戏
         }
      }
   }

   private static void sample(ServerPlayerEntity player) {
      UUID id = player.getUuid();
      int age = player.age;
      Integer lastTick = LAST_TICK.get(id);
      // 复活后玩家是「新实体」、age 归零，此时 age - lastTick 变成负数会把采样永久卡住，
      // 所以只在 age 前进且未满 20 tick 时跳过；age 回退（复活）立即重新采样。
      if (lastTick != null && age >= lastTick && age - lastTick < 20) {
         return;
      }
      LAST_TICK.put(id, age);

      Map<String, String> now = snapshot(player);
      Map<String, String> prev = LAST.put(id, now);
      String name = player.getGameProfile().getName();

      if (prev == null) {
         if (FIRST_DONE.putIfAbsent(id, Boolean.TRUE) == null) {
            write(auditFile(), "[INIT] 玩家 " + name + " 开始审计，当前遗物 " + now.size() + " 件：" + now);
         }
         return;
      }

      List<String> lost = new ArrayList<>();
      List<String> changed = new ArrayList<>();
      List<String> gained = new ArrayList<>();
      for (Map.Entry<String, String> entry : prev.entrySet()) {
         String cur = now.get(entry.getKey());
         if (cur == null) {
            lost.add(entry.getKey() + "(" + entry.getValue() + ")");
         } else if (!Objects.equals(cur, entry.getValue())) {
            changed.add(entry.getKey() + " " + entry.getValue() + "→" + cur);
         }
      }
      for (Map.Entry<String, String> entry : now.entrySet()) {
         if (!prev.containsKey(entry.getKey())) {
            gained.add(entry.getKey() + "(" + entry.getValue() + ")");
         }
      }
      if (!lost.isEmpty() || !changed.isEmpty() || !gained.isEmpty()) {
         StringBuilder line = new StringBuilder("[DIFF] 玩家 ").append(name);
         if (!lost.isEmpty()) {
            line.append(" | 失去: ").append(lost);
         }
         if (!changed.isEmpty()) {
            line.append(" | 变化: ").append(changed);
         }
         if (!gained.isEmpty()) {
            line.append(" | 获得: ").append(gained);
         }
         write(auditFile(), line.toString());
      }
   }

   /** 采集：背包全部槽位 + 饰品栏全部槽位里的遗物。 */
   private static Map<String, String> snapshot(ServerPlayerEntity player) {
      Map<String, String> map = new LinkedHashMap<>();
      PlayerInventory inventory = player.getInventory();
      for (int i = 0; i < inventory.size(); i++) {
         ItemStack stack = inventory.getStack(i);
         if (isTracked(stack)) {
            map.put("inv#" + i, stack.getItem().getTranslationKey() + "x" + stack.getCount());
         }
      }
      if (FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            for (Map.Entry<String, Map<String, TrinketInventory>> group : component.get().getInventory().entrySet()) {
               for (Map.Entry<String, TrinketInventory> slot : group.getValue().entrySet()) {
                  TrinketInventory inv = slot.getValue();
                  for (int i = 0; i < inv.size(); i++) {
                     ItemStack stack = inv.getStack(i);
                     if (isTracked(stack)) {
                        map.put("trk#" + group.getKey() + "/" + slot.getKey() + "#" + i,
                           stack.getItem().getTranslationKey() + "x" + stack.getCount());
                     }
                  }
               }
            }
         }
      }
      return map;
   }

   /** 与保命模块同一口径：遗物 + 秘法核心。 */
   private static boolean isTracked(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return false;
      }
      if (RelicService.isAnyRelic(stack)) {
         return true;
      }
      return ModItems.ARCANE_CORE != null && stack.isOf(ModItems.ARCANE_CORE);
   }

   @Environment(EnvType.CLIENT)
   private static void onClientTick(MinecraftClient client) {
      if (++clientTicks % 20 != 0) {
         return;
      }
      if (client.player == null) {
         return;
      }
      try {
         ScreenHandler handler = client.player.currentScreenHandler;
         String key = handler.getClass().getName() + " | slots=" + handler.slots.size() + " | syncId=" + handler.syncId;
         if (!key.equals(lastClientHandler)) {
            lastClientHandler = key;
            write(screenFile(), "[SCREEN] " + key);
         }
      } catch (Throwable error) {
         // 探针不得打断游戏
      }
   }
}
