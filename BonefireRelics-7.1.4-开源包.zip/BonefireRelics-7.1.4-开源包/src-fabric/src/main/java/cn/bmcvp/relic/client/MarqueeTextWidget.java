package cn.bmcvp.relic.client;

import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.tooltip.Tooltip;

public class MarqueeTextWidget extends ClickableWidget {
   private static final float SCROLL_SPEED = 27.0F;
   private static final int GAP_PIXELS = 36;
   private float offset;
   private long lastNanos = System.nanoTime();
   private int color = -1;
   private final TextRenderer font = MinecraftClient.getInstance().textRenderer;

   public MarqueeTextWidget(Text message, int x, int y, int width, int height) {
      super(x, y, width, height, message);
      this.setTooltip(Tooltip.of(message));
   }

   public void setMessage(Text message) {
      super.setMessage(message);
      this.setTooltip(Tooltip.of(message));
   }

   public void setColor(int color) {
      this.color = color;
   }

   protected void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
      long now = System.nanoTime();
      float dt = Math.max(0.0F, Math.min((float)(now - this.lastNanos) / 1.0E9F, 0.25F));
      this.lastNanos = now;
      TextRenderer font = this.font;
      Text message = this.getMessage();
      String text = message.getString();
      int textWidth = font.getWidth(message);
      int y = this.getY() + (this.getHeight() - 9) / 2;
      int safeColor = 0xFF000000 | this.color & 16777215;
      context.enableScissor(this.getX(), this.getY(), this.getX() + this.getWidth(), this.getY() + this.getHeight());

      try {
         if (textWidth <= this.getWidth()) {
            int x = this.getX() + (this.getWidth() - textWidth) / 2;
            context.drawTextWithShadow(font, text, x, y, safeColor);
         } else {
            float total = (float)(textWidth + 36);
            this.offset = (this.offset + dt * 27.0F) % total;
            int startX = this.getX() - (int)this.offset;
            context.drawTextWithShadow(font, text, startX, y, safeColor);
            context.drawTextWithShadow(font, text, startX + (int)total, y, safeColor);
         }
      } finally {
         context.disableScissor();
      }
   }

   public boolean isMouseOver(double mouseX, double mouseY) {
      return mouseX >= (double)this.getX()
         && mouseY >= (double)this.getY()
         && mouseX < (double)(this.getX() + this.getWidth())
         && mouseY < (double)(this.getY() + this.getHeight());
   }

   protected void appendClickableNarrations(NarrationMessageBuilder builder) {
   }
}
