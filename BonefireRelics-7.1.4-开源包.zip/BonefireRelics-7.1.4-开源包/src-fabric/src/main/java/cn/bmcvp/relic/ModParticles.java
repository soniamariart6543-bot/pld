package cn.bmcvp.relic;

import net.minecraft.particle.DefaultParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** 本 mod 自定义粒子注册（common 端；客户端渲染工厂见 client/ArcaneReviveParticle） */
public final class ModParticles {
   public static final DefaultParticleType ARCANE_REVIVE = new ArcaneReviveParticleType();

   private ModParticles() {
   }

   public static void initialize() {
      Registry.register(
         Registries.PARTICLE_TYPE, new Identifier(BmcvpRelicUpgrades.MODID, "arcane_revive"), ARCANE_REVIVE
      );
   }
}
