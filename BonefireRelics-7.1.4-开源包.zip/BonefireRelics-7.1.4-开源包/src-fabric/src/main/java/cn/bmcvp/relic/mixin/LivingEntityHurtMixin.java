package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.ArmorOvercapHandler;
import cn.bmcvp.relic.ArmorSkillHandler;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.damage.DamageTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class LivingEntityHurtMixin {
   private static final TagKey<DamageType> SPELL_POWER_ALL = TagKey.of(RegistryKeys.DAMAGE_TYPE, new Identifier("spell_power", "all"));

   @Inject(
      method = {"modifyAppliedDamage"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void bmcvp$overcapReduction(DamageSource source, float amount, CallbackInfoReturnable<Float> cir) {
      if ((Object)this instanceof ServerPlayerEntity player) {
         float result = cir.getReturnValueF();
         float reduction = ArmorOvercapHandler.reductionOf(player);
         if (reduction > 0.0F) {
            result *= 1.0F - reduction;
            cir.setReturnValue(result);
         }

         float magicResist = ArmorOvercapHandler.magicResistOf(player);
         if (magicResist > 0.0F && isSpellDamage(source)) {
            result *= 1.0F - magicResist;
            cir.setReturnValue(result);
         }

         ArmorSkillHandler.onPlayerDamaged(player, result);
      }
   }

   private static boolean isSpellDamage(DamageSource source) {
      return source.isIn(SPELL_POWER_ALL) || source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC);
   }
}
