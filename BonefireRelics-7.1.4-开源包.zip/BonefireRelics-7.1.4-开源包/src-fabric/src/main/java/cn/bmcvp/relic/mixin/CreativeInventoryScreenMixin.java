package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.client.RelicButtonConfig;
import cn.bmcvp.relic.client.RelicUpgradeScreen;
import net.minecraft.item.ItemGroup;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.item.ItemGroup.Type;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({CreativeInventoryScreen.class})
public abstract class CreativeInventoryScreenMixin {
   @Shadow
   private static ItemGroup selectedTab;
   @Unique
   private ButtonWidget bmcvp$relicButton;

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void bmcvp$addRelicButton(CallbackInfo ci) {
      CreativeInventoryScreen self = (CreativeInventoryScreen)(Object)this;
      HandledScreenAccessor layout = (HandledScreenAccessor)this;
      ScreenInvoker screen = (ScreenInvoker)this;
      this.bmcvp$relicButton = ButtonWidget.builder(Text.literal("遗物"), b -> MinecraftClient.getInstance().setScreen(new RelicUpgradeScreen(self)))
         .dimensions(layout.bmcvp$getX() + RelicButtonConfig.get().creativeButtonX, layout.bmcvp$getY() + RelicButtonConfig.get().creativeButtonY,
            RelicButtonConfig.get().buttonWidth, RelicButtonConfig.get().buttonHeight)
         .build();
      screen.bmcvp$addDrawableChild(this.bmcvp$relicButton);
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void bmcvp$updateRelicButton(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.bmcvp$relicButton != null) {
         boolean show = selectedTab != null && selectedTab.getType() == Type.INVENTORY;
         this.bmcvp$relicButton.visible = show;
         this.bmcvp$relicButton.active = show;
         if (show) {
            HandledScreenAccessor layout = (HandledScreenAccessor)this;
            this.bmcvp$relicButton.setPosition(layout.bmcvp$getX() + RelicButtonConfig.get().creativeButtonX,
               layout.bmcvp$getY() + RelicButtonConfig.get().creativeButtonY);
         }
      }
   }
}
