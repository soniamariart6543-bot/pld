package cn.bmcvp.relic;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.advancement.Advancement;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * 自研任务数据 —— 六章主线（《骨与火》任务书）。
 *
 * 口径（2026-09-12 昀晞定）：
 *  · 三项主属性：镐子材质 tier(0..6)、骨头伤害 damage(0..41)、法杖法强 spell(0..30)；
 *  · **总合计算**：三项各自归一化到 0..1 后求和 ÷3 → 进度 0..1；
 *  · 六章按递增曲线：0 / 5% / 15% / 35% / 65% / 100%（第 1 章无门槛）；
 *  · **只有非创造模式的升级才推进章节**，创造升级不写入任务书进度；
 *  · 章节数据全部来自 data/bonefire_relics/task/chapters.json（改数据即改任务，无需改代码）。
 */
public final class RelicChapters {
   /** 章节标签前缀：每解锁一章打一个 scoreboard tag（跟着玩家存档走）。 */
   private static final String TAG_PREFIX = "bonefire_chapter_";
   /** 三件主属性上限（与 UpgradeDefinition / RelicService 的取值域一致）。 */
   public static final int TIER_MAX = UpgradeDefinition.PICKAXE_TIER_MAX;
   public static final int BONE_MAX = 41;
   public static final int SPELL_MAX = 30;

   private static List<Chapter> cache;
   /** 后门开关：创造模式下点「一键满级」是否计入任务书（读 chapters.json 的 rule.creative_max_upgrade_counts）。 */
   private static Boolean backdoor;

   private RelicChapters() {
   }

   public record Chapter(int index, String name, double threshold, String goal, String lore,
                         int rewardExperience, List<RewardItem> rewardItems) {
   }

   /** 章节奖励里的一项材料。 */
   public record RewardItem(String id, int count) {
   }

   /** 内置兜底（chapters.json 缺失时使用）。 */
   private static final List<Chapter> DEFAULT = List.of(
      new Chapter(1, "醒来的骨", 0.00, "握住第一件遗物，完成第一次升级。", "茧裂之后，第一个捡起神骨的人听见了极轻的一声响。", 0, List.of()),
      new Chapter(2, "三系咒印", 0.05, "让任意一项主属性起步。", "信徒把神言刻在骨旁，刻痕有三：秘法、火、霜。", 10,
         List.of(new RewardItem("minecraft:lapis_lazuli", 320), new RewardItem("minecraft:redstone", 320),
            new RewardItem("minecraft:iron_ingot", 64), new RewardItem("minecraft:diamond", 8))),
      new Chapter(3, "心之所在", 0.15, "三项主属性合计推进到 15%。", "秘法核心是唯一还会跳动的遗物。", 16,
         List.of(new RewardItem("minecraft:lapis_lazuli", 512), new RewardItem("minecraft:redstone", 512),
            new RewardItem("minecraft:diamond", 20), new RewardItem("minecraft:emerald", 96))),
      new Chapter(4, "骨甲成环", 0.35, "合计推进到 35%。", "穿上骨甲时，你会短暂变成神的轮廓。", 24,
         List.of(new RewardItem("minecraft:lapis_lazuli", 768), new RewardItem("minecraft:redstone", 768),
            new RewardItem("minecraft:diamond", 40), new RewardItem("minecraft:netherite_ingot", 4),
            new RewardItem("minecraft:bone", 768))),
      new Chapter(5, "掘开旧土", 0.65, "合计推进到 65%。", "旧土之下埋着那场战争的证据。", 32,
         List.of(new RewardItem("minecraft:lapis_lazuli", 1024), new RewardItem("minecraft:redstone", 1024),
            new RewardItem("minecraft:diamond", 64), new RewardItem("minecraft:netherite_ingot", 16))),
      new Chapter(6, "归来之炬", 1.00, "三项主属性全部抵达极限。", "当所有骨都醒来，火会自己找到心脏。", 45,
         List.of(new RewardItem("minecraft:lapis_lazuli", 1280), new RewardItem("minecraft:redstone", 1280),
            new RewardItem("minecraft:diamond", 96), new RewardItem("minecraft:netherite_ingot", 32)))
   );

   /** 读取任务数据（首次调用时载入并缓存）。 */
   public static List<Chapter> all() {
      if (cache == null) {
         cache = load();
      }
      return cache;
   }

   private static List<Chapter> load() {
      try {
         Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(BmcvpRelicUpgrades.MODID);
         if (container.isPresent()) {
            Optional<Path> path = container.get().findPath("data/bonefire_relics/task/chapters.json");
            if (path.isPresent()) {
               String json = Files.readString(path.get(), StandardCharsets.UTF_8);
               JsonObject root = JsonParser.parseString(json).getAsJsonObject();
               JsonArray array = root.getAsJsonArray("chapters");
               if (root.has("rule")) {
                  JsonObject rule = root.getAsJsonObject("rule");
                  if (rule.has("creative_max_upgrade_counts")) {
                     backdoor = rule.get("creative_max_upgrade_counts").getAsBoolean();
                  }
               }
               List<Chapter> list = new ArrayList<>();
               for (JsonElement element : array) {
                  JsonObject object = element.getAsJsonObject();
                  int rewardExperience = 0;
                  List<RewardItem> rewardItems = new ArrayList<>();
                  if (object.has("reward")) {
                     JsonObject reward = object.getAsJsonObject("reward");
                     if (reward.has("experience")) {
                        rewardExperience = reward.get("experience").getAsInt();
                     }
                     if (reward.has("items")) {
                        for (JsonElement itemElement : reward.getAsJsonArray("items")) {
                           JsonObject item = itemElement.getAsJsonObject();
                           rewardItems.add(new RewardItem(item.get("id").getAsString(), item.get("count").getAsInt()));
                        }
                     }
                  }
                  list.add(new Chapter(
                     object.get("index").getAsInt(),
                     object.get("name").getAsString(),
                     object.get("threshold").getAsDouble(),
                     object.has("goal") ? object.get("goal").getAsString() : "",
                     object.has("lore") ? object.get("lore").getAsString() : "",
                     rewardExperience,
                     List.copyOf(rewardItems)
                  ));
               }
               if (!list.isEmpty()) {
                  list.sort((a, b) -> Integer.compare(a.index(), b.index()));
                  System.out.println("[BONEFIRE] 任务数据已载入：" + list.size() + " 章（data/bonefire_relics/task/chapters.json）");
                  return List.copyOf(list);
               }
            }
         }
      } catch (Throwable error) {
         System.out.println("[BONEFIRE] 任务数据读取失败，改用内置兜底：" + error);
      }
      return DEFAULT;
   }

   /** 当前三项主属性值：{镐子材质, 骨头伤害, 法杖法强}（取身上最好的一件）。 */
   public static int[] attributes(ServerPlayerEntity player) {
      int tier = 0;
      int damage = 0;
      int spell = 0;
      PlayerInventory inventory = player.getInventory();
      for (int i = 0; i < inventory.size(); i++) {
         ItemStack stack = inventory.getStack(i);
         if (stack.isEmpty()) {
            continue;
         }
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)
            || RelicService.isRelic(stack, UpgradeDefinition.RelicType.AXE)) {
            tier = Math.max(tier, RelicService.value(stack, "tier"));
         }
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            damage = Math.max(damage, RelicService.value(stack, "damage"));
         }
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
            spell = Math.max(spell, RelicService.value(stack, "spell"));
         }
      }
      return new int[]{Math.min(tier, TIER_MAX), Math.min(damage, BONE_MAX), Math.min(spell, SPELL_MAX)};
   }

   /**
    * 总合进度 0..1：三项各自归一化后求和 ÷3。
    * ⚠️ 用「历史最高值」而非「当前持有值」：镐⇄骨斧、骨头⇄法杖是**同一件东西的两种形态**，
    * 三项属性无法同时携带，若只看当前形态，换个形态进度就掉、第 6 章永远够不到（2026-09-13 实测）。
    */
   public static double progress(ServerPlayerEntity player) {
      int[] v = effectiveAttributes(player);
      return ((double)v[0] / TIER_MAX + (double)v[1] / BONE_MAX + (double)v[2] / SPELL_MAX) / 3.0;
   }

   // ——— 历史最高值：用 scoreboard 记在玩家身上（持久化，跨死亡/重登/换形态）———
   private static final String[] OBJECTIVES = {"bonefire_tier", "bonefire_damage", "bonefire_spell"};

   /** 读取历史最高三项（无记录返回 0）。 */
   public static int[] recordedAttributes(ServerPlayerEntity player) {
      int[] best = new int[3];
      try {
         Scoreboard scoreboard = player.getServer() == null ? null : player.getServer().getScoreboard();
         if (scoreboard == null) {
            return best;
         }
         for (int i = 0; i < 3; i++) {
            ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVES[i]);
            if (objective != null) {
               best[i] = scoreboard.getPlayerScore(player.getEntityName(), objective).getScore();
            }
         }
      } catch (Throwable error) {
         System.out.println("[BONEFIRE] 读取历史最高属性失败：" + error);
      }
      return best;
   }

   /** 把三项历史最高值抬到至少 values（只增不减）。 */
   public static void recordAttributes(ServerPlayerEntity player, int[] values) {
      try {
         Scoreboard scoreboard = player.getServer() == null ? null : player.getServer().getScoreboard();
         if (scoreboard == null) {
            return;
         }
         int[] best = recordedAttributes(player);
         for (int i = 0; i < 3; i++) {
            if (values[i] <= best[i]) {
               continue;
            }
            ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVES[i]);
            if (objective == null) {
               objective = scoreboard.addObjective(OBJECTIVES[i], ScoreboardCriterion.DUMMY,
                  Text.literal(OBJECTIVES[i]), ScoreboardCriterion.RenderType.INTEGER);
            }
            scoreboard.getPlayerScore(player.getEntityName(), objective).setScore(values[i]);
         }
      } catch (Throwable error) {
         System.out.println("[BONEFIRE] 记录历史最高属性失败：" + error);
      }
   }

   /** 综合口径：当前持有值 与 历史最高值 取大者。 */
   public static int[] effectiveAttributes(ServerPlayerEntity player) {
      int[] carried = attributes(player);
      int[] best = recordedAttributes(player);
      return new int[]{
         Math.max(carried[0], best[0]),
         Math.max(carried[1], best[1]),
         Math.max(carried[2], best[2])
      };
   }

   public static int progressPercent(ServerPlayerEntity player) {
      return (int)Math.round(progress(player) * 100.0);
   }

   /** 按曲线求当前应达章号（第 1 章无门槛）。 */
   public static int chapterFor(double progress) {
      List<Chapter> chapters = all();
      int result = 1;
      for (Chapter chapter : chapters) {
         if (progress + 1.0E-9 >= chapter.threshold()) {
            result = chapter.index();
         }
      }
      return result;
   }

   /** 已记录在玩家身上的最高章号（scoreboard tag）。 */
   public static int recorded(ServerPlayerEntity player) {
      int best = 0;
      for (Chapter chapter : all()) {
         if (player.getCommandTags().contains(TAG_PREFIX + chapter.index())) {
            best = Math.max(best, chapter.index());
         }
      }
      return best;
   }

   public static Chapter chapter(int index) {
      for (Chapter chapter : all()) {
         if (chapter.index() == index) {
            return chapter;
         }
      }
      return all().get(0);
   }

   /**
    * 升级后推进任务书。
    * · 普通升级：**只有非创造模式才计入**（创造升级直接返回）。
    * · 后门：创造模式下点「一键满级」（force = true）**会计入** —— 见 {@link #onUpgrade(ServerPlayerEntity, boolean)} 的重载说明。
    * 返回是否发生了章节推进。
    */
   public static boolean onUpgrade(ServerPlayerEntity player, boolean creative) {
      return onUpgrade(player, creative, false);
   }

   /**
    * @param force 后门：true = 无视创造模式强行计入（供「一键满级」按钮使用）。
    */
   public static boolean onUpgrade(ServerPlayerEntity player, boolean creative, boolean force) {
      if (creative && !force) {
         return false;
      }
      // 先记录历史最高（换形态/换装备都不会掉进度）
      recordAttributes(player, attributes(player));
      double progress = progress(player);
      // 自动融合已关闭（2026-09-13 昀晞要求）：融合只由「融合 · 虚空神心」按钮 / 命令触发
      int now = chapterFor(progress);
      int was = recorded(player);
      if (now <= was) {
         // 没跨章也刷新一次客户端数据，保证书里的进度条是最新的
         sendInfo(player);
         return false;
      }
      for (int i = was + 1; i <= now; i++) {
         player.addCommandTag(TAG_PREFIX + i);
         grantAdvancement(player, i);
      }
      Chapter chapter = chapter(now);
      player.sendMessage(Text.literal("《骨与火》更新了 —— 第 " + now + " 章 · " + chapter.name()
         + "（总进度 " + Math.round(progress * 100.0) + "%）"), false);
      // 跳章时逐章补发奖励，不漏账
      for (int i = was + 1; i <= now; i++) {
         grantReward(player, chapter(i));
      }
      sendInfo(player);
      return true;
   }

   /**
    * 章节奖励：经验等级 + 大量材料（设计口径：至少够 5 次升级）。
    * 数量 > 64 自动拆成多叠；用 offerOrDrop 发放，背包满则掉在脚下，不会消失。
    */
   public static void grantReward(ServerPlayerEntity player, Chapter chapter) {
      if (chapter.rewardExperience() > 0) {
         player.addExperienceLevels(chapter.rewardExperience());
      }
      StringBuilder detail = new StringBuilder();
      if (chapter.rewardExperience() > 0) {
         detail.append("+").append(chapter.rewardExperience()).append(" 级经验");
      }
      for (RewardItem rewardItem : chapter.rewardItems()) {
         ItemStack prototype;
         try {
            prototype = new ItemStack(Registries.ITEM.get(new Identifier(rewardItem.id())));
         } catch (Throwable error) {
            continue;
         }
         if (prototype.isEmpty()) {
            continue;
         }
         Item giveItem = prototype.getItem();
         int perStack = giveItem.getMaxCount() > 0 ? giveItem.getMaxCount() : 64;
         int left = rewardItem.count();
         while (left > 0) {
            int give = Math.min(perStack, left);
            player.getInventory().offerOrDrop(new ItemStack(giveItem, give));
            left -= give;
         }
         detail.append(detail.length() > 0 ? "、" : "")
            .append(prototype.getName().getString())
            .append("×")
            .append(rewardItem.count());
      }
      player.sendMessage(Text.literal("第 " + chapter.index() + " 章奖励：" + detail), false);
   }

   /** 章节对应的原版进度 id：data/bonefire_relics/advancements/chapterN.json（trigger = impossible，由本模组授予）。 */
   private static void grantAdvancement(ServerPlayerEntity player, int index) {
      try {
         MinecraftServer server = player.getServer();
         if (server == null) {
            return;
         }
         Advancement advancement = server.getAdvancementLoader()
            .get(new Identifier(BmcvpRelicUpgrades.MODID, "chapter" + index));
         if (advancement != null) {
            player.getAdvancementTracker().grantCriterion(advancement, "unlocked");
         }
      } catch (Throwable error) {
         System.out.println("[BONEFIRE] 授予进度 chapter" + index + " 失败：" + error);
      }
   }

   /**
    * 玩家进入世界时：补齐第 1 章标记 + **回填已解锁章节的原版进度**（老档在本次更新前升的也算），并同步任务书状态。
    */
   public static void onJoin(ServerPlayerEntity player) {
      if (!player.getCommandTags().contains(TAG_PREFIX + 1)) {
         player.addCommandTag(TAG_PREFIX + 1);
      }
      // 自动融合已关闭：进世界不再自动补融合
      int was = recorded(player);
      for (Chapter chapter : all()) {
         if (chapter.index() <= was) {
            grantAdvancement(player, chapter.index());
         }
      }
      sendInfo(player);
   }

   /** 后门开关（默认 true）：创造模式下点「一键满级」是否计入任务书。 */
   public static boolean creativeMaxUpgradeCounts() {
      all();
      return backdoor == null || backdoor;
   }

   /** 同步任务书状态给客户端（供指南书页面显示）。 */
   public static void sendInfo(ServerPlayerEntity player) {
      try {
         int[] v = effectiveAttributes(player);
         PacketByteBuf buf = PacketByteBufs.create();
         buf.writeInt(progressPercent(player));
         buf.writeInt(chapterFor(progress(player)));
         buf.writeInt(recorded(player));
         buf.writeInt(v[0]);
         buf.writeInt(v[1]);
         buf.writeInt(v[2]);
         ServerPlayNetworking.send(player, BmcvpRelicUpgrades.CHAPTER_INFO, buf);
      } catch (Throwable error) {
         System.out.println("[BONEFIRE] 任务书同步失败：" + error);
      }
   }

   /**
    * 创造模式后门：一键满级时**直接把三项历史最高值拉满**（6 / 41 / 30）并推进任务书。
    * 为什么需要：镐⇄骨斧、骨头⇄法杖是同件物品的两种形态，三项属性天然无法同时携带，
    * 靠「实际持有」永远到不了 100%，所以后门按满进度结算（第 6 章可解锁）。
    */
   public static void backdoorFullProgress(ServerPlayerEntity player) {
      recordAttributes(player, new int[]{TIER_MAX, BONE_MAX, SPELL_MAX});
      onUpgrade(player, player.getAbilities().creativeMode, true);
   }
}