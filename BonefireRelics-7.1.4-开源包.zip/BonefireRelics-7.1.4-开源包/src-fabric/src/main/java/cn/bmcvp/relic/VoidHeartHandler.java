package cn.bmcvp.relic;

import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketInventory;
import dev.emi.trinkets.api.TrinketsApi;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import java.util.List;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 虚空神心的装备效果（服务端）：
 *   · 飞行 / 永久夜视 / 持续生命恢复；
 *   · 免疫所有非玩家伤害，且无法被玩家伤害杀死；
 *   · 被实体攻击时直接处决该实体（斩杀线 = 持有者最大生命 ×120%）；
 *   · 穿戴时继承骨甲全部属性（护甲 +50、韧性 +20，并触发护甲超限转化）；
 *   · 首次穿戴返还「骨头」与「镐子」（保留升级等级），骨甲不返还。
 */
public final class VoidHeartHandler {
   private static final UUID ARMOR_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d31");
   private static final UUID TOUGH_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d32");
   private static final UUID SPEED_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d34");
   /** 神心提供的移动速度加成（加成到 generic.movement_speed 属性）。 */
   private static final UUID KB_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d33");
   private static final UUID SP_ARCANE_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d41");
   private static final UUID SP_FIRE_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d42");
   private static final UUID SP_FROST_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d43");
   /** 疾跑倍率压制修饰器（神心持有者：疾跑 1.3 → 1.2）。 */
   private static final UUID SPRINT_CAP_UUID = UUID.fromString("7a1d5c9e-30b4-4c8f-9a52-6f0e2c1b7d35");
   /** 斩杀线系数：**目标自身最大生命**的 120%（来袭实体一律处决）。 */
   private static final float EXECUTE_THRESHOLD = 1.2F;
   /** 神心提供的护甲值（四件骨甲全属性之和）。跨类共用，勿各自写字面量。 */
   public static final double HEART_ARMOR_BONUS = 200.0;
   /** 神心固定提供的抢夺等级（2026-09-13 昀晞：固定 15 级）。 */
   public static final int HEART_LOOTING_LEVEL = 15;
   /** 神心提供的护甲韧性。 */
   public static final double HEART_TOUGHNESS_BONUS = 20.0;

   // ————————————————————————————————————————————————————————————
   // 心跳状态缓存与节流（2026-09-13 体检优化）
   // 原先每个持有神心的玩家**每 tick**都要跑 2 次全容器扫描 + 把 7 个属性修饰器
   // 全部移除再全部加回（每次都触发属性集重算）。现在：
   //   · 装备状态每 5 tick 采一次样（最多 0.25 秒延迟，状态翻转时立即生效）；
   //   · 属性修饰器只在状态翻转时或每 10 tick 刷一次（与超限转化刷新同频）。
   // ————————————————————————————————————————————————————————————
   private static final class HeartState {
      boolean held;         // hasHeart：持有（含背包/饰品栏/末影箱）
      boolean worn;         // isWorn：穿戴在护甲栏或饰品栏
      boolean wornChanged;  // 本次采样是否发生翻转（翻转时立即施加/撤销属性）
      boolean armorApplied; // 当前是否已施加神心属性
      boolean firstSample = true;
      int sampleTick = -1000;
   }

   private static final Map<UUID, HeartState> HEART_STATE = new ConcurrentHashMap<>();
   private static final int STATE_TTL = 5;      // 装备状态采样间隔（tick）
   private static final int ATTR_REFRESH = 10;  // 属性重刷间隔（tick）

   private VoidHeartHandler() {
   }

   /** 处决重入保护：我们自己发出的处决伤害不应再次触发处决逻辑。 */
   private static boolean EXECUTING = false;

   /**
    * 以**玩家归属**处决目标（2026-09-13 昀晞实测修正）。
    *
    * 关键：绝对不能再用 target.kill() —— 它的伤害源是 genericKill（**没有击杀者**），
    * 战利品上下文因此拿不到 KILLER_ENTITY → 抢夺附魔、神心抢夺加成全部失效，经验也不掉。
    * 带着神心打怪时「所有命中都是处决」，所以连骨头自带的抢夺也一起废掉（两个现象同源）。
    * 现在改为 playerAttack 伤害源结算（击杀归属该玩家），并对伤害免疫的实体保留 kill() 兜底。
    */
   public static void executeWithCredit(PlayerEntity killer, LivingEntity target) {
      if (target == null || !target.isAlive() || EXECUTING) {
         return;
      }
      EXECUTING = true;
      try {
         target.damage(killer.getDamageSources().playerAttack(killer), Float.MAX_VALUE);
      } catch (Throwable ignored) {
      } finally {
         EXECUTING = false;
      }
      if (target.isAlive()) {
         try {
            target.kill();   // 兜底：对玩家攻击免疫的实体
         } catch (Throwable ignored) {
         }
      }
   }

   public static void initialize() {
      ServerTickEvents.END_SERVER_TICK.register(server -> {
         for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            try {
               tick(player);
            } catch (Throwable error) {
               System.out.println("[VOIDHEART] tick 异常：" + error);
            }
         }
         // 心跳状态缓存清理：只在缓存条目多于在线人数时做（避免掉线玩家条目常驻）
         if (HEART_STATE.size() > server.getPlayerManager().getPlayerList().size()) {
            java.util.Set<UUID> online = new java.util.HashSet<>();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
               online.add(player.getUuid());
            }
            HEART_STATE.keySet().removeIf(id -> !online.contains(id));
         }
      });
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
         if (!(entity instanceof ServerPlayerEntity player)) {
            return true;
         }
         // 融合演出期间同样免伤：升空/雷击途中不会被摔伤、窒息或爆炸打断
         if (FusionCinematic.isRunning(player)) {
            return false;
         }
         if (!hasHeart(player)) {
            return true;
         }
         Entity attacker = source.getAttacker();
         // ① 双神心对撞（2026-09-13 体检修正）：来袭者**也是神心持有者**时不取消伤害，
         //    放行原版结算 —— 否则两名成神玩家互相完全打不出伤害（第二条监听器因此永不可达）。
         if (attacker instanceof ServerPlayerEntity attackerPlayer && hasHeart(attackerPlayer)) {
            return true;
         }
         // 被实体攻击 → 直接处决该实体（斩杀线 = 最大生命 ×1.2）
         if (attacker instanceof LivingEntity living && !(attacker instanceof ServerPlayerEntity)) {
            // 斩杀线 = **目标自身最大生命 ×120%**（2026-09-13 昀晞修正）：
            // 任何生物的当前生命都不可能超过其最大生命的 120%，因此来袭实体一律被处决。
            float threshold = living.getMaxHealth() * EXECUTE_THRESHOLD;
            if (living.getHealth() <= threshold) {
               executeWithCredit(player, living);
            }
         }
         // 免疫一切伤害（含玩家伤害：杀不死）
         return false;
      });
      // ② 反向：**神心持有者主动攻击实体**时，同样直接处决该实体（2026-09-13 昀晓补充）
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
         if (EXECUTING) {
            return true;   // 我们自己发出的处决伤害：直接放行给原版结算，不再重复落雷/处决
         }
         if (!(source.getAttacker() instanceof ServerPlayerEntity holder) || !hasHeart(holder)) {
            return true;
         }
         if (entity instanceof ServerPlayerEntity) {
            return true;   // 不对其他玩家生效
         }
         // 命中生物实体 → 落一道雷（真实雷电：伤害 + 点燃；受击者就是被命中的那个实体）
         try {
            net.minecraft.server.world.ServerWorld sw = holder.getServerWorld();
            net.minecraft.entity.LightningEntity bolt =
               net.minecraft.entity.EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
               bolt.refreshPositionAfterTeleport(entity.getX(), entity.getY(), entity.getZ());
               // ⚠ 纯观赏（setCosmetic=true）：不点火、不破坏 —— 否则雷火会烧掉掉落物（2026-09-13 实测问题）
               bolt.setCosmetic(true);
               sw.spawnEntity(bolt);
            }
         } catch (Throwable ignored) {
         }
         try {
            float threshold = entity.getMaxHealth() * EXECUTE_THRESHOLD;
            if (entity.getHealth() <= threshold) {
               executeWithCredit(holder, entity);
            }
         } catch (Throwable ignored) {
         }
         return true;
      });
   }

   /**
    * 手持或穿戴神心：主手 / 副手 / 护甲栏 / 饰品栏（法术书饰品槽也算）。
    * 2026-09-13 昀晞实测修正：抢夺加成原先只认 isWorn（护甲栏 + 饰品栏），而创造发放 /
    * 「一键成神」给的神心默认在手里或背包里 —— 结果「拿着神心打怪」时抢夺完全不生效
    * （顺带因为手里不是骨头，骨头自带的抢夺附魔也不参与结算）。
    * 背包 / 末影箱仍不算，与「超限与护甲继承必须穿戴」的规则保持一致。
    */
   public static boolean isHeldOrWorn(ServerPlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return false;
      }
      if (isHeartStack(player.getMainHandStack()) || isHeartStack(player.getOffHandStack())) {
         return true;
      }
      return isWorn(player);
   }

   /**
    * 神心授予的抢夺等级：**固定 15 级**（2026-09-13 昀晞要求，不再与骨头等级相加）。
    */
   public static int lootingBonus(PlayerEntity player) {
      return HEART_LOOTING_LEVEL;
   }
   /** 是否「穿戴」着神心：主手 / 副手 / 饰品栏任一。 */
   public static boolean hasHeart(ServerPlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return false;
      }
      if (isHeartStack(player.getMainHandStack())
         || isHeartStack(player.getOffHandStack())) {
         return true;
      }
      for (int i = 0; i < player.getInventory().size(); i++) {
         ItemStack stack = player.getInventory().getStack(i);
         if (isHeartStack(stack)) {
            return true; // 背包/装备栏里持有即生效（饰品槽穿戴失败时的兜底）
         }
      }
      if (FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
               for (TrinketInventory inv : group.values()) {
                  for (int i = 0; i < inv.size(); i++) {
                     if (isHeartStack(inv.getStack(i))) {
                        return true;
                     }
                  }
               }
            }
         }
      }
      return false;
   }

   /**
    * 是否「穿戴」神心：**护甲栏（四个护甲位任一）或饰品栏（Trinkets 任一槽）都算**
    * （2026-09-13 昀晞：超限/护甲属性不再只认护甲栏，饰品栏穿上同样触发）。
    */
   public static boolean isWorn(ServerPlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return false;
      }
      for (ItemStack stack : player.getInventory().armor) {
         if (isHeartStack(stack)) {
            return true;
         }
      }
      if (FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
               for (TrinketInventory inv : group.values()) {
                  for (int i = 0; i < inv.size(); i++) {
                     if (isHeartStack(inv.getStack(i))) {
                        return true;
                     }
                  }
               }
            }
         }
      }
      return false;
   }

   private static void tick(ServerPlayerEntity player) {
      HeartState state = HEART_STATE.computeIfAbsent(player.getUuid(), id -> new HeartState());
      int age = player.age;
      // 装备状态采样（全容器扫描很贵）：每 STATE_TTL tick 一次；age 回退（复活）立即重采
      if (age < state.sampleTick || age - state.sampleTick >= STATE_TTL) {
         boolean held = hasHeart(player);
         boolean worn = held && isWorn(player);
         state.wornChanged = held != state.held || worn != state.worn;
         state.held = held;
         state.worn = worn;
         state.sampleTick = age;
      }
      boolean refreshAttributes = state.wornChanged || age % ATTR_REFRESH == 0;

      if (state.held) {
         returnStoredRelics(player);
         // 飞行
         if (!player.getAbilities().allowFlying) {
            player.getAbilities().allowFlying = true;
            player.sendAbilitiesUpdate();
         }
         // 永久夜视 + 持续回复
         player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, true, false, false));
         player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 1, true, false, false));
         // 永久急迫 II（amplifier 1 = II 级；每 tick 续期即等于永久）
         player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 400, 1, true, false, false));
         // 疾跑倍率压制（2026-09-13 昀晞：常态走 = 原版疾跑速度，疾跑 ×1.2）：
         // 原版疾跑通过「Sprinting speed boost」修饰器给 +30%，这里在神心生效期间叠加 -10%，
         // 使疾跑倍率落在 1.2；不疾跑时移除，不影响常态移动速度。
         EntityAttributeInstance moveAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
         if (moveAttr != null) {
            boolean wantCap = state.held && player.isSprinting();
            boolean hasCap = moveAttr.getModifier(SPRINT_CAP_UUID) != null;
            if (wantCap && !hasCap) {
               moveAttr.addPersistentModifier(new EntityAttributeModifier(SPRINT_CAP_UUID, "void_heart_sprint_cap", -0.1, EntityAttributeModifier.Operation.MULTIPLY_TOTAL));
            } else if (!wantCap && hasCap) {
               moveAttr.removeModifier(SPRINT_CAP_UUID);
            }
         }
         // 护甲继承与超限转化**必须穿戴**才生效（昀晞 2026-09-13）
         if (state.worn) {
            if (refreshAttributes) {
               applyArmorAttributes(player);
               state.armorApplied = true;
            }
         } else if (state.armorApplied || state.wornChanged || state.firstSample) {
            state.armorApplied = false;
            removeArmorAttributes(player);
         }
      } else {
         if (state.armorApplied || state.wornChanged || state.firstSample) {
            state.armorApplied = false;
            removeArmorAttributes(player);
         }
         if (player.getAbilities().allowFlying && !player.isCreative() && !player.isSpectator()) {
            player.getAbilities().allowFlying = false;
            player.getAbilities().flying = false;
            player.sendAbilitiesUpdate();
         }
      }
      state.firstSample = false;
   }

   /** 继承骨甲全属性：护甲 +200（四件之和）、护甲韧性 +20、抗击退 +25%，并让超限转化重新计算。 */
   private static void applyArmorAttributes(ServerPlayerEntity player) {
      sanitizeAttributes(player);   // 先去重，再逐项补齐（防重复累加）
      EntityAttributeInstance armor = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
      if (armor != null && armor.getModifier(ARMOR_UUID) == null) {
         // 四件骨甲全属性之和：护甲 +200（2026-09-13 昀晞）
         armor.addPersistentModifier(new EntityAttributeModifier(ARMOR_UUID, "void_heart_armor", HEART_ARMOR_BONUS, EntityAttributeModifier.Operation.ADDITION));
      }
      EntityAttributeInstance tough = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
      if (tough != null && tough.getModifier(TOUGH_UUID) == null) {
         tough.addPersistentModifier(new EntityAttributeModifier(TOUGH_UUID, "void_heart_toughness", HEART_TOUGHNESS_BONUS, EntityAttributeModifier.Operation.ADDITION));
      }
      // 骨甲继承（满级四件的抵御感）：抗击退
      EntityAttributeInstance kb = player.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
      if (kb != null && kb.getModifier(KB_UUID) == null) {
         kb.addPersistentModifier(new EntityAttributeModifier(KB_UUID, "void_heart_knockback", 0.25, EntityAttributeModifier.Operation.ADDITION));
      }
      // 飞行速度（原版默认 0.05）：飞行不吃 generic.movement_speed，必须单独抬 abilities.flySpeed
      try {
         float want = (float)ArmorOvercapConfig.get().heartFlySpeed;
         if (Math.abs(player.getAbilities().getFlySpeed() - want) > 1.0E-4F) {
            player.getAbilities().setFlySpeed(want);
            player.sendAbilitiesUpdate();
         }
      } catch (Throwable ignored) {
      }
      // 地面移动速度（配置驱动，昀晞 2026-09-13）
      EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
      if (speed != null && speed.getModifier(SPEED_UUID) == null) {
         speed.addPersistentModifier(new EntityAttributeModifier(SPEED_UUID, "void_heart_speed",
            ArmorOvercapConfig.get().heartSpeedBonus, EntityAttributeModifier.Operation.ADDITION));
      }
      // 秘法核心继承：三系法术强度（spell_power 提供的属性，存在才加）
      addSpellPower(player, "arcane", SP_ARCANE_UUID, 30.0);
      addSpellPower(player, "fire", SP_FIRE_UUID, 30.0);
      addSpellPower(player, "frost", SP_FROST_UUID, 30.0);
      ArmorOvercapHandler.onUpgradeApplied(player);
   }

   private static void removeArmorAttributes(ServerPlayerEntity player) {
      EntityAttributeInstance armor = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
      if (armor != null && armor.getModifier(ARMOR_UUID) != null) {
         armor.removeModifier(ARMOR_UUID);
      }
      EntityAttributeInstance tough = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
      if (tough != null && tough.getModifier(TOUGH_UUID) != null) {
         tough.removeModifier(TOUGH_UUID);
      }
      EntityAttributeInstance kb = player.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
      if (kb != null && kb.getModifier(KB_UUID) != null) {
         kb.removeModifier(KB_UUID);
      }
      EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
      if (speed != null && speed.getModifier(SPEED_UUID) != null) {
         speed.removeModifier(SPEED_UUID);
      }
      // 恢复原版飞行速度
      try {
         if (Math.abs(player.getAbilities().getFlySpeed() - 0.05F) > 1.0E-4F
            && !player.isCreative() && !player.isSpectator()) {
            player.getAbilities().setFlySpeed(0.05F);
            player.sendAbilitiesUpdate();
         }
      } catch (Throwable ignored) {
      }
      removeSpellPower(player, "arcane", SP_ARCANE_UUID);
      removeSpellPower(player, "fire", SP_FIRE_UUID);
      removeSpellPower(player, "frost", SP_FROST_UUID);
   }

   /** 首次穿戴：返还骨头与镐子（保留升级等级；骨甲不返还）。 */
   private static void returnStoredRelics(ServerPlayerEntity player) {
      ItemStack heart = findHeart(player);
      if (heart == null || !heart.hasNbt()) {
         return;
      }
      NbtCompound stored = heart.getNbt().getCompound("void_heart_stored");
      if (stored.isEmpty() || stored.getBoolean("returned")) {
         return;
      }
      int returned = 0;
      for (String key : new String[]{"bone", "pickaxe"}) {
         if (!stored.contains(key, 10)) {
            continue;
         }
         ItemStack stack = ItemStack.fromNbt(stored.getCompound(key));
         if (!stack.isEmpty()) {
            player.getInventory().offerOrDrop(stack);
            returned++;
         }
      }
      stored.putBoolean("returned", true);
      heart.getNbt().put("void_heart_stored", stored);
      player.getInventory().markDirty();
      player.playerScreenHandler.sendContentUpdates();
      player.sendMessage(net.minecraft.text.Text.literal("虚空神心回应了你：骨头与镐子已归位（等级保留）；骨甲已融入心口。"), false);
      System.out.println("[VOIDHEART] 返还遗物 " + returned + " 件");
   }

   private static ItemStack findHeart(ServerPlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return null;
      }
      if (isHeartStack(player.getMainHandStack())) {
         return player.getMainHandStack();
      }
      if (isHeartStack(player.getOffHandStack())) {
         return player.getOffHandStack();
      }
      for (int i = 0; i < player.getInventory().size(); i++) {
         ItemStack stack = player.getInventory().getStack(i);
         if (isHeartStack(stack)) {
            return stack;
         }
      }
      if (FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
               for (TrinketInventory inv : group.values()) {
                  for (int i = 0; i < inv.size(); i++) {
                     if (isHeartStack(inv.getStack(i))) {
                        return inv.getStack(i);
                     }
                  }
               }
            }
         }
      }
      return null;
   }

   /** 手持神心右键：给一次状态回执（提示当前效果）。 */
   public static void onUse(ServerPlayerEntity player) {
      player.sendMessage(net.minecraft.text.Text.literal(
         hasHeart(player)
            ? "虚空神心：免疫一切伤害 · 处决来袭者 · 飞行 / 夜视 / 恢复 已生效"
            : "虚空神心：请「穿戴」它（主手、副手或饰品栏）以激活力量"), false);
   }

   /**
    * 是否持有神心：**背包/护甲栏/主副手 + 饰品栏（Trinkets 全部槽位逐一遍历）**。
    * 2026-09-13 修：此前只遍历背包，神心放在饰品格时服务端认不到（超限因此不触发）。
    */
   public static boolean ownsHeart(PlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return false;
      }
      // ① 先走全容器扫描（背包全槽 / 双手 / 当前界面所有槽 + 光标 / 饰品栏全部组槽 / 末影箱）
      if (scanAllContainers(player)) {
         return true;
      }
      for (int i = 0; i < player.getInventory().size(); i++) {
         if (player.getInventory().getStack(i).isOf(ModItems.RELIC_VOID_HEART)) {
            return true;
         }
      }
      if (isHeartStack(player.getMainHandStack())
         || isHeartStack(player.getOffHandStack())) {
         return true;
      }
      if (player instanceof ServerPlayerEntity serverPlayer && FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(serverPlayer);
         if (component.isPresent()) {
            for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
               for (TrinketInventory inv : group.values()) {
                  for (int i = 0; i < inv.size(); i++) {
                     if (isHeartStack(inv.getStack(i))) {
                        return true;
                     }
                  }
               }
            }
         }
      }
      return false;
   }

   /** 加/减 spell_power 的属性修饰器（属性不存在时静默跳过，换整合包也不会崩）。 */
   private static void addSpellPower(ServerPlayerEntity player, String path, UUID uuid, double value) {
      try {
         net.minecraft.entity.attribute.EntityAttribute attribute =
            net.minecraft.registry.Registries.ATTRIBUTE.get(new net.minecraft.util.Identifier("spell_power", path));
         if (attribute == null) {
            return;
         }
         EntityAttributeInstance instance = player.getAttributeInstance(attribute);
         if (instance != null && instance.getModifier(uuid) == null) {
            instance.addPersistentModifier(new EntityAttributeModifier(uuid, "void_heart_spell_" + path, value,
               EntityAttributeModifier.Operation.ADDITION));
         }
      } catch (Throwable ignored) {
      }
   }

   private static void removeSpellPower(ServerPlayerEntity player, String path, UUID uuid) {
      try {
         net.minecraft.entity.attribute.EntityAttribute attribute =
            net.minecraft.registry.Registries.ATTRIBUTE.get(new net.minecraft.util.Identifier("spell_power", path));
         if (attribute == null) {
            return;
         }
         EntityAttributeInstance instance = player.getAttributeInstance(attribute);
         if (instance != null && instance.getModifier(uuid) != null) {
            instance.removeModifier(uuid);
         }
      } catch (Throwable ignored) {
      }
   }

   /**
    * 是否是虚空神心 —— **按注册 id 判定，两种形态都认**：
    * `bonefire_relics:relic_void_heart`（护甲形态）与 `bonefire_relics:void_heart_spell_book`（法术书形态）。
    * 不再依赖静态字段 RELIC_VOID_HEART（服务端/客户端加载顺序不同可能导致它指向另一种形态，
    * 那样比对永远失败 —— 2026-09-13 实测就是这个原因导致超限一直"未激活"）。
    */
   public static boolean isHeartStack(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return false;
      }
      // ⚠ 这里必须用原生 isOf：批量替换曾把本行也改成 isHeartStack(stack) → 无限递归 → StackOverflowError（2026-09-13 事故）
      if (ModItems.RELIC_VOID_HEART != null && stack.isOf(ModItems.RELIC_VOID_HEART)) {
         return true;
      }
      try {
         net.minecraft.util.Identifier id = net.minecraft.registry.Registries.ITEM.getId(stack.getItem());
         if (!"bonefire_relics".equals(id.getNamespace())) {
            return false;
         }
         String path = id.getPath();
         return "relic_void_heart".equals(path) || "void_heart_spell_book".equals(path);
      } catch (Throwable ignored) {
         return false;
      }
   }

   /**
    * 全容器扫描（2026-09-13 昀晞：直接扫玩家数据里所有可能的槽容器）：
    *   ① 主手 / 副手
    *   ② 背包全部：main + armor + offHand
    *   ③ 当前打开界面的**全部槽位** + 光标上的物品
    *   ④ 饰品栏：Trinkets 全部 group → 全部 slot → 全部 index（含法术书槽）
    *   ⑤ 末影箱
    * 服务端与客户端共用同一实现，避免两边口径不一致。
    */
   public static boolean scanAllContainers(net.minecraft.entity.player.PlayerEntity player) {
      if (player == null) {
         return false;
      }
      // ① 双手
      if (isHeartStack(player.getMainHandStack()) || isHeartStack(player.getOffHandStack())) {
         return true;
      }
      // ② 背包全部（主格 + 护甲 + 副手）
      try {
         PlayerInventory inv = player.getInventory();
         for (List<ItemStack> list : List.of(inv.main, inv.armor, inv.offHand)) {
            for (ItemStack stack : list) {
               if (isHeartStack(stack)) {
                  return true;
               }
            }
         }
      } catch (Throwable ignored) {
      }
      // ③ 当前界面全部槽 + 光标
      try {
         ScreenHandler handler = player.currentScreenHandler;
         if (handler != null) {
            for (Slot slot : handler.slots) {
               if (isHeartStack(slot.getStack())) {
                  return true;
               }
            }
            if (isHeartStack(handler.getCursorStack())) {
               return true;
            }
         }
      } catch (Throwable ignored) {
      }
      // ④ 饰品栏（全部组 / 全部槽 / 全部索引）
      try {
         if (FabricLoader.getInstance().isModLoaded("trinkets")) {
            Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
            if (component.isPresent()) {
               for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
                  for (TrinketInventory inv : group.values()) {
                     for (int i = 0; i < inv.size(); i++) {
                        if (isHeartStack(inv.getStack(i))) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      } catch (Throwable ignored) {
      }
      // ⑤ 末影箱
      try {
         net.minecraft.inventory.Inventory ender = player.getEnderChestInventory();
         for (int i = 0; i < ender.size(); i++) {
            if (isHeartStack(ender.getStack(i))) {
               return true;
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }

   /** 神心的「毁灭模式」开关（存在神心 NBT 里，持久化）。火球在毁灭模式下 = 1 个 TNT 效果。 */
   /**
    * 全容器找到神心**本体**（背包全槽 / 双手 / 当前界面槽 + 光标 / 饰品栏全部组槽 / 末影箱）。
    * 2026-09-13 修：此前只遍历背包，神心在**法术书饰品格**时读不到 → 毁灭模式永远切不动。
    */
   public static ItemStack findHeartStack(net.minecraft.entity.player.PlayerEntity player) {
      if (player == null) {
         return null;
      }
      try {
         if (isHeartStack(player.getMainHandStack())) {
            return player.getMainHandStack();
         }
         if (isHeartStack(player.getOffHandStack())) {
            return player.getOffHandStack();
         }
         PlayerInventory inv = player.getInventory();
         for (List<ItemStack> list : List.of(inv.main, inv.armor, inv.offHand)) {
            for (ItemStack stack : list) {
               if (isHeartStack(stack)) {
                  return stack;
               }
            }
         }
         ScreenHandler handler = player.currentScreenHandler;
         if (handler != null) {
            for (Slot slot : handler.slots) {
               if (isHeartStack(slot.getStack())) {
                  return slot.getStack();
               }
            }
            if (isHeartStack(handler.getCursorStack())) {
               return handler.getCursorStack();
            }
         }
         if (FabricLoader.getInstance().isModLoaded("trinkets")) {
            Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
            if (component.isPresent()) {
               for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
                  for (TrinketInventory tinv : group.values()) {
                     for (int i = 0; i < tinv.size(); i++) {
                        if (isHeartStack(tinv.getStack(i))) {
                           return tinv.getStack(i);
                        }
                     }
                  }
               }
            }
         }
         net.minecraft.inventory.Inventory ender = player.getEnderChestInventory();
         for (int i = 0; i < ender.size(); i++) {
            if (isHeartStack(ender.getStack(i))) {
               return ender.getStack(i);
            }
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   public static boolean isDestructiveMode(net.minecraft.entity.player.PlayerEntity player) {
      try {
         ItemStack heart = findHeartStack(player);
         return heart != null && heart.hasNbt() && heart.getNbt().getBoolean("void_fire_mode");
      } catch (Throwable ignored) {
         return false;
      }
   }

   /** 切换毁灭模式（潜行 + 右键法杖触发）。返回切换后的状态。 */
   public static boolean toggleDestructiveMode(net.minecraft.entity.player.PlayerEntity player) {
      try {
         ItemStack heart = findHeartStack(player);   // 全容器（含法术书饰品栏）
         if (heart == null) {
            return false;
         }
         boolean now = !(heart.hasNbt() && heart.getNbt().getBoolean("void_fire_mode"));
         heart.getOrCreateNbt().putBoolean("void_fire_mode", now);
         if (player instanceof ServerPlayerEntity serverPlayer) {
            serverPlayer.playerScreenHandler.sendContentUpdates();
         }
         return now;
      } catch (Throwable ignored) {
         return false;
      }
   }

   /**
    * 属性修饰器去重（2026-09-13 修"速度被算两次"）：
    * `addPersistentModifier` 会把修饰器**写进玩家存档**，历史版本可能已积累同名重复项，
    * 仅靠 `getModifier(uuid) == null` 的判断清不掉 → 每次进入前先把 `void_heart_*` 全部移除，
    * 再由正常流程重新加**各一份**，确保任何时刻只有一套加成。
    */
   private static void sanitizeAttributes(ServerPlayerEntity player) {
      try {
         for (net.minecraft.entity.attribute.EntityAttribute attribute : List.of(
            EntityAttributes.GENERIC_ARMOR,
            EntityAttributes.GENERIC_ARMOR_TOUGHNESS,
            EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE,
            EntityAttributes.GENERIC_MOVEMENT_SPEED)) {
            net.minecraft.entity.attribute.EntityAttributeInstance instance = player.getAttributeInstance(attribute);
            if (instance == null) {
               continue;
            }
            List<EntityAttributeModifier> stale = new java.util.ArrayList<>();
            for (EntityAttributeModifier modifier : instance.getModifiers()) {
               String name = modifier.getName();
               // 疾跑压制修饰器由 tick 单独管理（疾跑时存在、停下即移除），不参与这里的清理
               if (modifier.getId().equals(SPRINT_CAP_UUID)) {
                  continue;
               }
               if (name != null && name.startsWith("void_heart_")) {
                  stale.add(modifier);
               }
            }
            for (EntityAttributeModifier modifier : stale) {
               instance.removeModifier(modifier);
            }
         }
      } catch (Throwable ignored) {
      }
   }
}
