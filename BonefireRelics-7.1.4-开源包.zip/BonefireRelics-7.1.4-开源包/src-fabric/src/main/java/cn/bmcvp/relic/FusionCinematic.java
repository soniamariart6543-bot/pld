package cn.bmcvp.relic;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * 融合演出（2026-09-13 昀晞要求）：
 *   ① 角色升空 10 格（6 秒，匀速、无重力残留）；
 *   ② 周围生成**多层螺旋火焰粒子**形成漩涡——粒子沿固定半径环分布、delta 全 0，
 *      所以「数量多但绝不溢出」（半径封顶 4.2 格外圈）；
 *   ③ 顶点悬浮 15 秒（漩涡全开）；
 *   ④ 收尾祭仪（2026-09-13 昀晞追加）：
 *      · 外围 30 道环雷沿最外层火焰环**顺时针**依次落下，绕满一整圈；
 *      · 脚下（起飞点地面）爆炸，炸出半径 5 格的巨坑；
 *      · 爆炸过后三道天罚劈在玩家身上；
 *      · 巨坑以 5 格半径整体**基岩化**（坑壁与坑底成基岩，坑内留空，不把玩家活埋）；
 *   ⑤ 演出结束 → 执行终极融合（万骨归心）或纯演出收尾。
 * 全程服务端驱动，客户端只是看演出。所有雷电均 setCosmetic(true)，不点火、不破坏、不烧掉落物。
 */
public final class FusionCinematic {
   private static final Map<UUID, State> ACTIVE = new ConcurrentHashMap<>();

   private static final int RISE_TICKS = 120;         // 升空用时（6 秒，缓缓升起）
   private static final double RISE_HEIGHT = 10.0;    // 升空高度（格）
   private static final int HOLD_TICKS = 300;         // 顶点悬浮（15 秒，漩涡全开）

   // ——— 收尾祭仪参数 ———
   private static final int RING_BOLTS = 30;          // 外围顺时针落雷数
   private static final int RING_BOLT_GAP = 6;        // 每道间隔 tick（30×6＝180 tick ≈ 9 秒绕满一圈）
   private static final int SOUND_EVERY = 10;         // 每 10 道补一次雷声（第 10 / 20 / 30 道）
   private static final double RING_RADIUS = 4.2;     // 与最外层火焰环同半径（雷落在火焰外圈上）
   private static final int BOOM_DELAY = 10;          // 环雷走完 → 脚下爆炸
   private static final int FINAL_STRIKES = 3;        // 爆炸后打在玩家身上的三道雷
   private static final int FINAL_GAP = 20;           // 每道间隔（1 秒）
   private static final int BEDROCK_DELAY = 20;       // 三道雷之后 → 爆后的坑基岩化
   private static final int END_DELAY = 20;           // 基岩化后停留一拍收镜
   private static final double CRATER_RADIUS = 5.0;   // 巨坑半径（格）
   private static final int BLOCK_BUDGET = 256;       // 每 tick 最多处理的格数（分批执行，避免单 tick 上万次读取）
   private static final int[][] NEIGHBOURS = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

   private FusionCinematic() {
   }

   public static void initialize() {
      ServerTickEvents.END_SERVER_TICK.register(FusionCinematic::tickAll);
   }

   private static final class State {
      double startX;     // 起飞点（爆炸与巨坑都以这里为中心）
      double startY;
      double startZ;
      int tick;
      boolean merge;   // true=演出结束执行融合；false=纯演出（创造模式「一键成神」反复发放用，绝不动玩家物品）
      // 分批方块作业（2026-09-13 体检：原先单 tick 扫完上千格，可能造成顿卡）
      boolean carving;        // 正在开挖巨坑
      int carveIndex;         // 开挖进度（格栅扁平索引）
      boolean bedrocking;     // 正在基岩化
      int bedrockIndex;       // 基岩化进度
      int bedrockReplaced;    // 已替换为基岩的方块数
      BlockPos craterCenter;  // 巨坑中心（爆开时锁定）
   }

   public static boolean isRunning(ServerPlayerEntity player) {
      return ACTIVE.containsKey(player.getUuid());
   }

   /** 开始演出（收尾执行融合）。返回 false 表示该玩家已经在演出中。 */
   public static boolean start(ServerPlayerEntity player) {
      return start(player, true);
   }

   /**
    * 开始演出。
    * @param mergeAtEnd true＝演出结束执行终极融合（生存路线）；
    *                   false＝**纯演出**：只放特效与三道雷，绝不消耗/改写玩家背包
    *                   （创造模式「一键成神」反复发放用）。
    * @return false 表示该玩家已经在演出中
    */
   public static boolean start(ServerPlayerEntity player, boolean mergeAtEnd) {
      if (ACTIVE.containsKey(player.getUuid())) {
         return false;
      }
      State state = new State();
      state.startX = player.getX();
      state.startY = player.getY();
      state.startZ = player.getZ();
      state.tick = 0;
      state.merge = mergeAtEnd;
      ACTIVE.put(player.getUuid(), state);
      player.fallDistance = 0.0F;
      player.setVelocity(0.0, 0.0, 0.0);
      player.velocityModified = true;
      player.sendMessage(Text.literal(mergeAtEnd ? "万骨归心 —— 融合开始。" : "万骨归心 —— 神心降临。"), false);
      System.out.println("[FUSION] 演出开始（merge=" + mergeAtEnd + "）：" + player.getEntityName());
      return true;
   }

   private static void tickAll(MinecraftServer server) {
      if (ACTIVE.isEmpty()) {
         return;
      }
      // 掉线清理：演出中退出的玩家状态会被永久驻留，这里按在线名单剔除
      java.util.Set<UUID> online = new java.util.HashSet<>();
      for (ServerPlayerEntity onlinePlayer : server.getPlayerManager().getPlayerList()) {
         online.add(onlinePlayer.getUuid());
      }
      ACTIVE.keySet().removeIf(id -> !online.contains(id));
      for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
         State state = ACTIVE.get(player.getUuid());
         if (state == null) {
            continue;
         }
         try {
            tick(player, state);
         } catch (Throwable error) {
            System.out.println("[FUSION] 演出异常：" + error);
            ACTIVE.remove(player.getUuid());
         }
      }
   }

   private static void tick(ServerPlayerEntity player, State state) {
      state.tick++;
      ServerWorld world = player.getServerWorld();
      double cx = player.getX();
      double cy = player.getY();
      double cz = player.getZ();

      // ——— 螺旋火焰漩涡：3 层环，半径 1.2 / 1.6 / 2.0（封顶 2.0，不溢出）；delta 全 0 = 不随机扩散 ———
      for (int ring = 0; ring < 3; ring++) {
         double radius = 1.8 + ring * 1.2;      // 1.8 / 3.0 / 4.2 —— 漩涡加大
         int points = 16 + ring * 8;            // 16 / 24 / 32 点 → 更密
         double phase = state.tick * 0.42 + ring * 0.9;
         for (int i = 0; i < points; i++) {
            double angle = phase + i * (Math.PI * 2.0 / points);
            double px = cx + Math.cos(angle) * radius;
            double pz = cz + Math.sin(angle) * radius;
            double py = cy + 0.3 + Math.sin(angle * 2.0 + state.tick * 0.25) * 0.7;
            world.spawnParticles(ParticleTypes.FLAME, px, py, pz, 1, 0.0, 0.0, 0.0, 0.0);
            if (i % 3 == 0) {
               world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, px, py + 0.35, pz, 1, 0.0, 0.0, 0.0, 0.0);
            }
            if (i % 4 == 0) {
               world.spawnParticles(ParticleTypes.LAVA, px, py, pz, 1, 0.0, 0.0, 0.0, 0.0);
            }
            // 上升粒子柱：让漩涡有高度感（半径固定，仍不外溢）
            if (i % 2 == 0) {
               double lift = 1.0 + ((state.tick * 0.25 + i) % 3.0);
               world.spawnParticles(ParticleTypes.FLAME, px, py + lift, pz, 1, 0.0, 0.0, 0.0, 0.0);
            }
         }
      }

      if (state.tick <= RISE_TICKS) {
         // ① 升空：匀速插值到起点上方 10 格
         double target = state.startY + RISE_HEIGHT * state.tick / RISE_TICKS;
         player.requestTeleport(cx, target, cz);
         player.setVelocity(0.0, 0.0, 0.0);
         player.velocityModified = true;
         player.fallDistance = 0.0F;
         return;
      }

      if (state.tick <= RISE_TICKS + HOLD_TICKS) {
         // ② 顶点悬浮：锁死不下坠
         player.setVelocity(0.0, 0.0, 0.0);
         player.velocityModified = true;
         player.fallDistance = 0.0F;
         return;
      }

      // ④ 收尾祭仪（悬浮必须继续锁死：整段若自由落体会下落甚至摔伤）
      player.setVelocity(0.0, 0.0, 0.0);
      player.velocityModified = true;
      player.fallDistance = 0.0F;
      int into = state.tick - RISE_TICKS - HOLD_TICKS;

      // ④-0 分批推进上一阶段登记的大范围方块作业（每 tick 至多 BLOCK_BUDGET 格）
      if (state.craterCenter != null) {
         int carveR = (int)Math.ceil(CRATER_RADIUS);
         if (state.carving) {
            state.carveIndex = drainCarve(world, state.craterCenter, carveR, state.carveIndex, BLOCK_BUDGET);
            if (state.carveIndex >= gridVolume(carveR)) {
               state.carving = false;
               state.carveIndex = 0;
            }
         }
         if (state.bedrocking) {
            state.bedrockIndex = drainBedrock(world, state.craterCenter, carveR + 1, CRATER_RADIUS,
               state.bedrockIndex, BLOCK_BUDGET, state);
            if (state.bedrockIndex >= gridVolume(carveR + 1)) {
               state.bedrocking = false;
               state.bedrockIndex = 0;
               player.sendMessage(Text.literal("巨坑基岩化 —— 替换 " + state.bedrockReplaced + " 格"), true);
            }
         }
      }

      // ④-1 外围 30 道环雷：沿最外层火焰环（半径 4.2）顺时针依次落下，绕满一整圈
      if (into >= 1 && into <= RING_BOLTS * RING_BOLT_GAP && (into - 1) % RING_BOLT_GAP == 0) {
         int index = (into - 1) / RING_BOLT_GAP;                  // 0 .. 29
         double angle = index * (Math.PI * 2.0 / RING_BOLTS);     // 每道 12°；角度递增＝俯视顺时针
         double bx = cx + Math.cos(angle) * RING_RADIUS;
         double bz = cz + Math.sin(angle) * RING_RADIUS;
         spawnBolt(world, bx, cy, bz);
         world.spawnParticles(ParticleTypes.FLAME, bx, cy + 0.4, bz, 12, 0.15, 0.4, 0.15, 0.02);
         world.spawnParticles(ParticleTypes.EXPLOSION, bx, cy + 0.3, bz, 1, 0.1, 0.1, 0.1, 0.0);
         // 雷声：只在第 10 / 20 / 30 道（昀晞要求）——30 道全响会太吵，三段闷雷刚好做节拍
         if ((index + 1) % SOUND_EVERY == 0) {
            world.playSound(null, bx, cy, bz,
               SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.WEATHER, 2.5F, 1.0F);
            world.playSound(null, bx, cy, bz,
               SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.WEATHER, 8.0F, 1.0F);
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, bx, cy + 0.5, bz, 1, 0.0, 0.0, 0.0, 0.0);
            player.sendMessage(Text.literal("环雷 " + (index + 1) + " / " + RING_BOLTS), true);
         }
      }

      // ④-2 脚下爆炸：以**起飞点地面**为中心（玩家此刻悬在 10 格高空，坑开在脚下大地上）
      int boomAt = RING_BOLTS * RING_BOLT_GAP + BOOM_DELAY;
      if (into == boomAt) {
         // 登记分批开挖（本 tick 起每 tick 推进 BLOCK_BUDGET 格，约 6 tick 完成）
         state.craterCenter = BlockPos.ofFloored(state.startX, state.startY, state.startZ);
         state.carving = true;
         state.carveIndex = 0;
         world.playSound(null, state.startX, state.startY, state.startZ,
            SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 6.0F, 0.85F);
         world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
            state.startX, state.startY + 1.0, state.startZ, 16, 2.5, 2.0, 2.5, 0.0);
         world.spawnParticles(ParticleTypes.LARGE_SMOKE,
            state.startX, state.startY + 1.0, state.startZ, 150, 3.5, 2.0, 3.5, 0.06);
         world.spawnParticles(ParticleTypes.FLAME,
            state.startX, state.startY + 0.5, state.startZ, 200, 4.0, 1.5, 4.0, 0.12);
         player.sendMessage(Text.literal("脚下大地崩裂 —— 巨坑已成。"), true);
      }

      // ④-3 爆炸过后：三道天罚依次劈在玩家身上
      int firstStrike = boomAt + FINAL_GAP;
      int lastStrike = firstStrike + (FINAL_STRIKES - 1) * FINAL_GAP;
      if (into >= firstStrike && into <= lastStrike && (into - firstStrike) % FINAL_GAP == 0) {
         int n = (into - firstStrike) / FINAL_GAP + 1;
         spawnBolt(world, cx, cy, cz);
         world.spawnParticles(ParticleTypes.EXPLOSION, cx, cy + 0.4, cz, 3, 0.3, 0.3, 0.3, 0.0);
         player.sendMessage(Text.literal("天罚 " + n + " / " + FINAL_STRIKES), true);
      }

      // ④-4 爆后的坑 → 以 5 格半径整体基岩化（坑壁与坑底成基岩，坑内留空）
      int bedrockAt = lastStrike + BEDROCK_DELAY;
      if (into == bedrockAt) {
         // 登记分批基岩化（约 9 tick 完成后播报替换格数）
         if (state.craterCenter == null) {
            state.craterCenter = BlockPos.ofFloored(state.startX, state.startY, state.startZ);
         }
         state.bedrocking = true;
         state.bedrockIndex = 0;
         state.bedrockReplaced = 0;
         world.playSound(null, state.startX, state.startY, state.startZ,
            SoundEvents.BLOCK_STONE_PLACE, SoundCategory.BLOCKS, 4.0F, 0.5F);
         world.spawnParticles(ParticleTypes.CRIT,
            state.startX, state.startY + 2.0, state.startZ, 120, 3.0, 2.0, 3.0, 0.2);
      }

      if (into >= bedrockAt + END_DELAY) {
         // ⑤ 收尾（先清掉落距离；万一融合失败则给缓降保护，绝不把玩家摔了）
         player.fallDistance = 0.0F;
         String result;
         if (state.merge) {
            result = RelicService.tryMergeVoidHeart(player);
         } else {
            // 纯演出模式：不碰背包（创造模式反复发放神心，绝不能吃掉玩家身上的遗物/骨甲）
            result = "一键成神完成 —— 虚空神心已发放（演出模式，未改动背包）。";
         }
         if (!result.startsWith("融合完成") && !result.startsWith("一键成神完成")) {
            player.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
               net.minecraft.entity.effect.StatusEffects.SLOW_FALLING, 200, 0, true, false, false));
         }
         world.spawnParticles(ParticleTypes.FLASH, cx, cy + 1.0, cz, 1, 0.0, 0.0, 0.0, 0.0);
         world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, cx, cy + 0.6, cz, 1, 0.0, 0.0, 0.0, 0.0);
         player.sendMessage(Text.literal(result), false);
         System.out.println("[FUSION] 演出结束：" + result);
         ACTIVE.remove(player.getUuid());
      }
   }

   /** 生成一道纯观赏雷（不点火、不破坏、不伤害、不烧掉落物）。 */
   private static void spawnBolt(ServerWorld world, double x, double y, double z) {
      LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
      if (bolt != null) {
         bolt.refreshPositionAfterTeleport(x, y, z);
         bolt.setCosmetic(true);
         world.spawnEntity(bolt);
      }
   }

   /** 格栅边长（半径 r → 2r+1）×3 = 总格数。 */
   private static int gridVolume(int gridRadius) {
      int n = gridRadius * 2 + 1;
      return n * n * n;
   }

   /**
    * 爆炸开挖（分批版，2026-09-13 体检优化）：把以 center 为中心、半径 radius 的球体内方块挖成空气
    * （等价一次 TNT 爆炸的坑），每 tick 只处理 budget 格，避免单 tick 上千次方块读写造成顿卡。
    *
    * 故意**不生成真实爆炸实体**——真实爆炸会炸伤生物、点燃地面、并毁掉地上的掉落物
    * （与“落雷不要吞掉落物”同一条原则）。
    * 跳过：不可破坏方块（硬度 &lt; 0：基岩/屏障/传送门框架…）、带方块实体的容器与机器
    * （箱子/熔炉/模组机器 → 绝不吞玩家财产）、流体（避免水与岩浆乱流）。
    *
    * @return 推进后的扁平索引（达到 gridVolume(gridRadius) 即完成）
    */
   private static int drainCarve(ServerWorld world, BlockPos center, int gridRadius, int cursor, int budget) {
      int n = gridRadius * 2 + 1;
      int total = n * n * n;
      int end = Math.min(total, cursor + budget);
      double radius2 = (double)gridRadius * gridRadius;
      for (int i = cursor; i < end; i++) {
         int dx = (i / (n * n)) - gridRadius;
         int dy = ((i / n) % n) - gridRadius;
         int dz = (i % n) - gridRadius;
         if ((double)(dx * dx + dy * dy + dz * dz) > radius2) {
            continue;
         }
         BlockPos pos = center.add(dx, dy, dz);
         BlockState st = world.getBlockState(pos);
         if (st.isAir() || !st.getFluidState().isEmpty() || st.hasBlockEntity() || st.getHardness(world, pos) < 0.0F) {
            continue;
         }
         world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
      }
      return end;
   }

   /**
    * 巨坑基岩化（分批版）：凡紧贴坑内空腔（六向相邻存在坑内空气）的方块替换为基岩。
    * 坑内空气保留 —— 不把玩家活埋进基岩里（坑是敞口基岩巨碗，可站、可飞离）。
    * 同样跳过容器/机器与不可破坏方块；每 tick 只处理 budget 格。
    *
    * @return 推进后的扁平索引（达到 gridVolume(gridRadius) 即完成）
    */
   private static int drainBedrock(ServerWorld world, BlockPos center, int gridRadius, double craterRadius,
                                  int cursor, int budget, State state) {
      int n = gridRadius * 2 + 1;
      int total = n * n * n;
      int end = Math.min(total, cursor + budget);
      double inner2 = craterRadius * craterRadius;
      double outer2 = (double)gridRadius * gridRadius;
      BlockState bedrock = Blocks.BEDROCK.getDefaultState();
      BlockPos.Mutable probe = new BlockPos.Mutable();
      for (int i = cursor; i < end; i++) {
         int dx = (i / (n * n)) - gridRadius;
         int dy = ((i / n) % n) - gridRadius;
         int dz = (i % n) - gridRadius;
         double dist2 = dx * dx + dy * dy + dz * dz;
         if (dist2 <= inner2 || dist2 > outer2) {
            continue;   // 坑内空气跳过；只处理紧贴坑壁的一层
         }
         BlockPos pos = center.add(dx, dy, dz);
         BlockState st = world.getBlockState(pos);
         if (st.isAir() || !st.getFluidState().isEmpty() || st.isOf(Blocks.BEDROCK) || st.hasBlockEntity()
            || st.getHardness(world, pos) < 0.0F) {
            continue;
         }
         if (!touchesCarvedAir(world, probe, pos, center, craterRadius)) {
            continue;
         }
         world.setBlockState(pos, bedrock, Block.NOTIFY_ALL);
         state.bedrockReplaced++;
      }
      return end;
   }

   /** 该方块是否紧贴「坑内空腔」（六向相邻里存在坑内空气）；probe 复用以免每格新建对象。 */
   private static boolean touchesCarvedAir(ServerWorld world, BlockPos.Mutable probe, BlockPos pos, BlockPos center, double radius) {
      double radius2 = radius * radius;
      for (int[] offset : NEIGHBOURS) {
         probe.set(pos.getX() + offset[0], pos.getY() + offset[1], pos.getZ() + offset[2]);
         double dx = probe.getX() - center.getX();
         double dy = probe.getY() - center.getY();
         double dz = probe.getZ() - center.getZ();
         if (dx * dx + dy * dy + dz * dz > radius2) {
            continue;
         }
         if (world.getBlockState(probe).isAir()) {
            return true;
         }
      }
      return false;
   }
}
