package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.KeepInventoryStore;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * v9：respawnPlayer TAIL 立即补一次遗物 + 推送客户端；随后由
 * RelicStabilizeMixin 每 tick 持续守护，直到稳定才放手（对抗 YIGD 重生覆写）。
 */
@Mixin({PlayerManager.class})
public abstract class PlayerRespawnKeepMixin {
   @Inject(method = {"respawnPlayer"}, at = {@At("TAIL")})
   private void bmcvp$giveBackOnRespawn(ServerPlayerEntity oldPlayer, boolean alive, CallbackInfoReturnable<ServerPlayerEntity> cir) {
      ServerPlayerEntity player = cir.getReturnValue();
      if (player == null) {
         return;
      }
      int placed = KeepInventoryStore.attemptRestore(player);
      if (placed > 0) {
         player.playerScreenHandler.sendContentUpdates();
         player.currentScreenHandler.sendContentUpdates();
         System.out.println("[KEEP] pushed inventory sync to client");
      }
   }
}
