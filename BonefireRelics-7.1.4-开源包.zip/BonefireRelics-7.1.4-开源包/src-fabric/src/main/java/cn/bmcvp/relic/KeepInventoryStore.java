package cn.bmcvp.relic;

import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketInventory;
import dev.emi.trinkets.api.TrinketsApi;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 遗物死亡暂存/发还（v10，饰品栏版）。
 * YIGD(You're in Grave Danger) 在重生时用自身快照 applyToPlayer() 整体覆写玩家背包，
 * 会把我们发还的遗物清掉。对策：发还改为「持续守护直到稳定」——
 * 死亡 onDeath HEAD 摘除暂存（早于 YIGD 收包）→ 重生后每 tick 检测，槽空即补回，
 * 连续 OK 满 STABLE_TICKS 才释放（YIGD 只覆写一次，之后自然稳固）。
 *
 * v10（2026-09-12）：**补上饰品（Trinkets）栏**。
 * 秘法核心是 ArcaneCoreTrinketItem（装备在饰品槽），v9 只遍历 PlayerInventory
 * （主格 36 + 装备 4 + 副手）→ 核心留在身上被 YIGD 收进墓碑。现在饰品槽同样
 * 摘除/暂存/发还；条目按 group/slot/index 定位（不持有引用，重生换实体后仍能写回）。
 *
 * 独立普通类：mixin 类不允许非 private 静态成员。
 */
public final class KeepInventoryStore {
   private static final int STABLE_TICKS = 80;

   private static final Map<UUID, List<Integer>> KEEP_SLOTS = new ConcurrentHashMap<>();
   private static final Map<UUID, List<ItemStack>> KEEP_STACKS = new ConcurrentHashMap<>();
   private static final Map<UUID, List<TrinketSlot>> KEEP_TRINKETS = new ConcurrentHashMap<>();
   private static final Map<UUID, Integer> KEEP_OK_SINCE = new ConcurrentHashMap<>();
   /** 落盘文件是否已读过（首次触碰时读一次）。 */
   private static boolean loaded;

   private KeepInventoryStore() {
   }

   /**
    * 暂存落盘文件：`<gameDir>/config/bonefire_relics_keep.dat`。
    * 2026-09-12 新增 —— 起因：昀晞把遗物摘下来暂存后游戏 **JVM 闪退**
    * （hs_err: C2 编译器 EXCEPTION_ACCESS_VIOLATION，与 mod 无关），
    * 内存里的暂存直接蒸发，战利品骨头 / 野生果奶永久丢失。
    * 现在每次摘除/补回都落盘，重登自动读回补发 → 闪退不再吞遗物。
    */
   private static File keepFile() {
      return FabricLoader.getInstance().getGameDir().resolve("config").resolve("bonefire_relics_keep.dat").toFile();
   }

   private static void persist() {
      try {
         NbtCompound root = new NbtCompound();
         for (Map.Entry<UUID, List<Integer>> entry : KEEP_SLOTS.entrySet()) {
            UUID id = entry.getKey();
            List<Integer> slots = entry.getValue();
            List<ItemStack> stacks = KEEP_STACKS.get(id);
            if (slots == null || stacks == null) {
               continue;
            }
            NbtCompound player = new NbtCompound();
            NbtList inv = new NbtList();
            for (int i = 0; i < slots.size() && i < stacks.size(); i++) {
               NbtCompound row = new NbtCompound();
               row.putInt("slot", slots.get(i));
               row.put("stack", stacks.get(i).writeNbt(new NbtCompound()));
               inv.add(row);
            }
            player.put("inv", inv);
            List<TrinketSlot> trinkets = KEEP_TRINKETS.get(id);
            if (trinkets != null && !trinkets.isEmpty()) {
               NbtList list = new NbtList();
               for (TrinketSlot t : trinkets) {
                  NbtCompound row = new NbtCompound();
                  row.putString("group", t.group());
                  row.putString("slot", t.slot());
                  row.putInt("index", t.index());
                  row.put("stack", t.stack().writeNbt(new NbtCompound()));
                  list.add(row);
               }
               player.put("trinkets", list);
            }
            root.put(id.toString(), player);
         }
         File file = keepFile();
         if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
         }
         if (root.isEmpty()) {
            if (file.exists()) {
               file.delete();
            }
         } else {
            NbtIo.write(root, file);
            System.out.println("[KEEP] persist 落盘 " + root.getKeys().size() + " 名玩家");
         }
      } catch (Throwable error) {
         System.out.println("[KEEP] persist 失败: " + error);
      }
   }

   /** 重登/启动时读回落盘暂存（只读一次）。 */
   private static void loadIfNeeded() {
      if (loaded) {
         return;
      }
      loaded = true;
      File file = keepFile();
      if (!file.exists()) {
         return;
      }
      try {
         NbtCompound root = NbtIo.read(file);
         if (root == null) {
            return;
         }
         for (String key : root.getKeys()) {
            UUID id;
            try {
               id = UUID.fromString(key);
            } catch (IllegalArgumentException bad) {
               continue;
            }
            NbtCompound player = root.getCompound(key);
            List<Integer> slots = new ArrayList<>();
            List<ItemStack> stacks = new ArrayList<>();
            NbtList inv = player.getList("inv", NbtElement.COMPOUND_TYPE);
            for (int i = 0; i < inv.size(); i++) {
               NbtCompound row = inv.getCompound(i);
               ItemStack stack = ItemStack.fromNbt(row.getCompound("stack"));
               if (stack.isEmpty()) {
                  continue;
               }
               slots.add(row.getInt("slot"));
               stacks.add(stack);
            }
            List<TrinketSlot> trinkets = new ArrayList<>();
            NbtList list = player.getList("trinkets", NbtElement.COMPOUND_TYPE);
            for (int i = 0; i < list.size(); i++) {
               NbtCompound row = list.getCompound(i);
               ItemStack stack = ItemStack.fromNbt(row.getCompound("stack"));
               if (stack.isEmpty()) {
                  continue;
               }
               trinkets.add(new TrinketSlot(row.getString("group"), row.getString("slot"), row.getInt("index"), stack));
            }
            if (!slots.isEmpty() || !trinkets.isEmpty()) {
               KEEP_SLOTS.put(id, slots);
               KEEP_STACKS.put(id, stacks);
               if (!trinkets.isEmpty()) {
                  KEEP_TRINKETS.put(id, trinkets);
               }
               KEEP_OK_SINCE.remove(id);
               System.out.println("[KEEP] 读回落盘暂存: 背包 " + slots.size() + " 件 / 饰品 " + trinkets.size() + " 件");
            }
         }
      } catch (IOException error) {
         System.out.println("[KEEP] 读回落盘暂存失败: " + error);
      }
   }

   /** 饰品槽暂存条目：记 group/slot/index（用于重定位），不持有 inventory 引用。 */
   private record TrinketSlot(String group, String slot, int index, ItemStack stack) {
   }

   /** 死亡保留口径：NBT 遗物 + 秘法核心（核心可能是 0 级、没有遗物 NBT）。 */
   private static boolean isProtected(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return false;
      }
      if (RelicService.isAnyRelic(stack)) {
         return true;
      }
      return ModItems.ARCANE_CORE != null && stack.isOf(ModItems.ARCANE_CORE);
   }

   private static Optional<TrinketComponent> trinkets(ServerPlayerEntity player) {
      if (!FabricLoader.getInstance().isModLoaded("trinkets")) {
         return Optional.empty();
      }
      return TrinketsApi.getTrinketComponent(player);
   }

   private static TrinketInventory resolve(TrinketComponent component, TrinketSlot entry) {
      Map<String, TrinketInventory> group = component.getInventory().get(entry.group());
      return group == null ? null : group.get(entry.slot());
   }

   /** 摘除背包（含饰品栏）全部遗物并暂存（原槽置空）。返回摘除件数。 */
   public static int extract(ServerPlayerEntity player) {
      UUID id = player.getUuid();
      PlayerInventory inventory = player.getInventory();
      List<Integer> slots = new ArrayList<>();
      List<ItemStack> stacks = new ArrayList<>();

      for (int i = 0; i < inventory.size(); i++) {
         ItemStack stack = inventory.getStack(i);
         if (!stack.isEmpty() && RelicService.isAnyRelic(stack)) {
            slots.add(i);
            stacks.add(stack.copy());
            inventory.setStack(i, ItemStack.EMPTY);

         }
      }

      if (!slots.isEmpty()) {
         KEEP_SLOTS.put(id, slots);
         KEEP_STACKS.put(id, stacks);
         KEEP_OK_SINCE.remove(id);
         System.out.println("[KEEP] extract n=" + slots.size());
      }

      int trinketCount = extractTrinkets(player, id);
      if (slots.size() + trinketCount > 0) {
         persist();
      }
      return slots.size() + trinketCount;
   }

   /** v10：饰品栏摘除（秘法核心等装备在饰品槽的遗物）。 */
   private static int extractTrinkets(ServerPlayerEntity player, UUID id) {
      Optional<TrinketComponent> component = trinkets(player);
      if (component.isEmpty()) {
         return 0;
      }
      List<TrinketSlot> kept = new ArrayList<>();
      for (Map.Entry<String, Map<String, TrinketInventory>> group : component.get().getInventory().entrySet()) {
         for (Map.Entry<String, TrinketInventory> slot : group.getValue().entrySet()) {
            TrinketInventory inv = slot.getValue();
            for (int i = 0; i < inv.size(); i++) {
               ItemStack stack = inv.getStack(i);
               if (isProtected(stack)) {
                  kept.add(new TrinketSlot(group.getKey(), slot.getKey(), i, stack.copy()));
                  inv.setStack(i, ItemStack.EMPTY);
               }
            }
         }
      }
      if (!kept.isEmpty()) {
         KEEP_TRINKETS.put(id, kept);
         KEEP_OK_SINCE.remove(id);
         System.out.println("[KEEP] extract trinkets=" + kept.size());
      }
      return kept.size();
   }

   public static boolean isPending(UUID playerId) {
      return KEEP_SLOTS.containsKey(playerId) || KEEP_TRINKETS.containsKey(playerId);
   }

   /**
    * 是否处于「死亡流程中」（还没复活）。
    * 2026-09-12 实测教训：补回如果发生在死亡当刻，YIGD 生成墓碑时会把刚补回的遗物一起收走，
    * 重生时墓碑再发一份 → **同一件遗物变成两套**（昀晞实测「出现了两套骨甲」）。
    * 因此死亡期间一律不补回，等复活后（血量 > 0）再由每 tick 稳定器补。
    */
   private static boolean isDeadOrDying(ServerPlayerEntity player) {
      return player.isRemoved() || player.isDead() || player.getHealth() <= 0.0F;
   }

   /** 玩家当前是否已经持有同一件遗物（按 NBT 全等比较，背包 + 饰品栏）。 */
   private static boolean holds(ServerPlayerEntity player, ItemStack want) {
      PlayerInventory inventory = player.getInventory();
      for (int i = 0; i < inventory.size(); i++) {
         ItemStack cur = inventory.getStack(i);
         if (!cur.isEmpty() && ItemStack.areEqual(cur, want)) {
            return true;
         }
      }
      Optional<TrinketComponent> component = trinkets(player);
      if (component.isPresent()) {
         for (Map<String, TrinketInventory> group : component.get().getInventory().values()) {
            for (TrinketInventory inv : group.values()) {
               for (int i = 0; i < inv.size(); i++) {
                  ItemStack cur = inv.getStack(i);
                  if (!cur.isEmpty() && ItemStack.areEqual(cur, want)) {
                     return true;
                  }
               }
            }
         }
      }
      return false;
   }

   /**
    * 尝试把暂存遗物补进空槽，返回本次补回件数。
    * ⚠️ 教训（2026-09-12 第二版）：补回成功**不清表**——表清了、稳定器就停手，
    * 紧接着 YIGD 复活覆写背包就再也补不回来（昀晞实测「死亡后遗物直接消失」）。
    * 表只由 stabilize 在「连续 80 tick 全在位」后统一释放。
    * 防重复改由 holds() 判断：已经在身上（哪怕换到别的槽）就跳过，不重复补第二件。
    */
   public static int attemptRestore(ServerPlayerEntity player) {
      if (isDeadOrDying(player)) {
         return 0;
      }
      UUID id = player.getUuid();
      List<Integer> slots = KEEP_SLOTS.get(id);
      List<ItemStack> stacks = KEEP_STACKS.get(id);
      int placed = 0;
      if (slots != null && stacks != null) {
         PlayerInventory inventory = player.getInventory();
         for (int i = 0; i < slots.size() && i < stacks.size(); i++) {
            ItemStack want = stacks.get(i);
            if (holds(player, want)) {
               continue;
            }
            int slot = slots.get(i);
            if (slot >= 0 && slot < inventory.size() && inventory.getStack(slot).isEmpty()) {
               inventory.setStack(slot, want.copy());
               placed++;

            }
         }
      }

      int trinketPlaced = restoreTrinkets(player, id);
      if (placed + trinketPlaced > 0) {
         KEEP_OK_SINCE.remove(id);
         System.out.println("[KEEP] restore placed=" + placed + " trinkets=" + trinketPlaced);
         persist();
      }
      return placed + trinketPlaced;
   }

   /** v10：把暂存的饰品写回原 group/slot/index（仅空槽写入）。 */
   private static int restoreTrinkets(ServerPlayerEntity player, UUID id) {
      List<TrinketSlot> kept = KEEP_TRINKETS.get(id);
      if (kept == null || kept.isEmpty()) {
         return 0;
      }
      Optional<TrinketComponent> component = trinkets(player);
      if (component.isEmpty()) {
         return 0;
      }
      int placed = 0;
      for (TrinketSlot entry : kept) {
         TrinketInventory inv = resolve(component.get(), entry);
         if (inv == null || entry.index() < 0 || entry.index() >= inv.size()) {
            continue;
         }
         if (holds(player, entry.stack())) {
            continue;
         }
         if (inv.getStack(entry.index()).isEmpty()) {
            inv.setStack(entry.index(), entry.stack().copy());
            placed++;
         }
      }
      return placed;
   }

   /**
    * 全量在位校验：暂存列表里的每件遗物都必须在位（含饰品栏）。
    * 判定放宽为「原槽位是全等的同一件」**或**「身上任意位置（背包/饰品）持有全等同一件」——
    * 这样即便 YIGD 把它发还到别的槽位，也认作在位并正常释放，避免稳定器永远不放手。
    */
   public static boolean allPresent(ServerPlayerEntity player) {
      UUID id = player.getUuid();
      List<Integer> slots = KEEP_SLOTS.get(id);
      List<ItemStack> stacks = KEEP_STACKS.get(id);
      if (slots != null && stacks != null) {
         PlayerInventory inventory = player.getInventory();
         for (int i = 0; i < slots.size() && i < stacks.size(); i++) {
            int slot = slots.get(i);
            ItemStack want = stacks.get(i);
            if (slot >= 0 && slot < inventory.size()) {
               ItemStack cur = inventory.getStack(slot);
               if (!cur.isEmpty() && ItemStack.areEqual(cur, want)) {
                  continue;
               }
            }
            if (!holds(player, want)) {
               return false;
            }
         }
      }
      return trinketsPresent(player, id);
   }

   /** v10：饰品栏在位校验。 */
   private static boolean trinketsPresent(ServerPlayerEntity player, UUID id) {
      List<TrinketSlot> kept = KEEP_TRINKETS.get(id);
      if (kept == null || kept.isEmpty()) {
         return true;
      }
      Optional<TrinketComponent> component = trinkets(player);
      if (component.isEmpty()) {
         return false;
      }
      for (TrinketSlot entry : kept) {
         TrinketInventory inv = resolve(component.get(), entry);
         if (inv == null || entry.index() < 0 || entry.index() >= inv.size()) {
            return false;
         }
         ItemStack cur = inv.getStack(entry.index());
         if (cur.isEmpty() || !ItemStack.areEqual(cur, entry.stack())) {
            return false;
         }
      }
      return true;
   }

   /** 每 tick 由稳定器调用：全在→计时；缺失→补回；连续 OK 满阈值→释放。 */
   public static void stabilize(ServerPlayerEntity player) {
      UUID id = player.getUuid();
      loadIfNeeded();
      if (!isPending(id)) {
         return;
      }
      // 死亡流程中一律不补回（否则 YIGD 墓碑会把补回的遗物一起收走 → 重生后变两套）
      if (isDeadOrDying(player)) {
         return;
      }
      if (allPresent(player)) {
         Integer since = KEEP_OK_SINCE.get(id);
         if (since == null) {
            KEEP_OK_SINCE.put(id, player.age);
         } else if (player.age - since >= STABLE_TICKS) {
            KEEP_SLOTS.remove(id);
            KEEP_STACKS.remove(id);
            KEEP_TRINKETS.remove(id);
            KEEP_OK_SINCE.remove(id);
            System.out.println("[KEEP] stable released n=all");
            persist();
         }
      } else {
         KEEP_OK_SINCE.remove(id);
         attemptRestore(player);
      }
   }

   /** 重登兜底：仍在暂存（异常中断/闪退场景）直接补一次。 */
   public static void restoreOnJoin(ServerPlayerEntity player) {
      loadIfNeeded();
      if (isPending(player.getUuid())) {
         attemptRestore(player);
      }
   }
}
