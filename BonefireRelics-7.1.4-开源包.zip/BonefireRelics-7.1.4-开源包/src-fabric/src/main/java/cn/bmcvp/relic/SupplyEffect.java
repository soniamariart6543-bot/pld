package cn.bmcvp.relic;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.effect.StatusEffectCategory;

public class SupplyEffect extends StatusEffect {
   public SupplyEffect() {
      super(StatusEffectCategory.BENEFICIAL, 16755200);
   }

   public boolean canApplyUpdateEffect(int duration, int amplifier) {
      return duration % 20 == 0;
   }

   public void applyUpdateEffect(LivingEntity entity, int amplifier) {
      if (entity instanceof PlayerEntity player) {
         HungerManager hunger = player.getHungerManager();
         if (hunger.getFoodLevel() < 20) {
            hunger.setFoodLevel(hunger.getFoodLevel() + 1);
         }

         float saturation = Math.min(hunger.getSaturationLevel() + 1.0F, (float)hunger.getFoodLevel());
         hunger.setSaturationLevel(saturation);
      }
   }
}
