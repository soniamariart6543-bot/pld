package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.KeepInventoryStore;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * v8「墓碑 mod 感知」第一步：onDeath HEAD 先把遗物摘除暂存。
 * 早于任何掉落/墓碑捕获（YIGD 在 LivingEntity.drop HEAD 收包，
 * 而 drop() 在 onDeath 方法体内才被调用），遗物因此不会进墓碑/地面。
 */
@Mixin({ServerPlayerEntity.class})
public abstract class RelicKeepInventoryMixin {
   @Inject(method = {"onDeath"}, at = {@At("HEAD")})
   private void bmcvp$extractRelics(DamageSource source, CallbackInfo ci) {
      KeepInventoryStore.extract((ServerPlayerEntity)(Object)this);
   }
}