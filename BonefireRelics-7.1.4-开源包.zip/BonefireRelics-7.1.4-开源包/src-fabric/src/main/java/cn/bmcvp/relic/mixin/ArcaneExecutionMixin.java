package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class ArcaneExecutionMixin {
   @Inject(
      method = {"modifyAppliedDamage"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void bmcvp$execution(DamageSource source, float amount, CallbackInfoReturnable<Float> cir) {
      if (source.getAttacker() instanceof ServerPlayerEntity player) {
         if (!((Object)this instanceof ServerPlayerEntity)) {
            LivingEntity victim = (LivingEntity)(Object)this;
            if (!ArcaneCoreGrowth.isExempt(victim)) {
               int level = ArcaneCoreGrowth.equippedLevel(player);
               if (ArcaneCoreGrowth.hasExecution(level)) {
                  if (ArcaneCoreGrowth.underExecuteLine(victim.getHealth(), victim.getMaxHealth())) {
                     if (!(player.getRandom().nextFloat() >= ArcaneCoreGrowth.executeChance(level))) {
                        if (ArcaneCoreGrowth.hasSoulReaper(level)) {
                           ArcaneCoreGrowth.soulReaper(player, victim, level);
                        }

                        cir.setReturnValue(Math.max(victim.getHealth(), amount));
                     }
                  }
               }
            }
         }
      }
   }
}
