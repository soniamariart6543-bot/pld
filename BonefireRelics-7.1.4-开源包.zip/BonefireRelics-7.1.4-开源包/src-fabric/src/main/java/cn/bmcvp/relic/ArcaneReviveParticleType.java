package cn.bmcvp.relic;

import net.minecraft.particle.DefaultParticleType;

/** 秘法核心·复活专用粒子类型（构造默认，交由 registry 使用） */
public final class ArcaneReviveParticleType extends DefaultParticleType {
   public ArcaneReviveParticleType() {
      super(false);
   }
}
