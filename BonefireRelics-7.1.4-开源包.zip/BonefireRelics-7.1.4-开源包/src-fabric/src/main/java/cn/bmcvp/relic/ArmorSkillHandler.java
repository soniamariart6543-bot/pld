package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public final class ArmorSkillHandler {
   private static final Map<ServerPlayerEntity, ArmorSkillHandler.Accum> DATA = new WeakHashMap<>();

   private ArmorSkillHandler() {
   }

   public static void initialize() {
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         long now = (long)server.getTicks();
         DATA.entrySet().removeIf(entry -> {
            ServerPlayerEntity player = entry.getKey();
            return player == null || player.isRemoved() || now - entry.getValue().lastDamageTick() > 400L;
         });
      });
   }

   public static void onPlayerDamaged(ServerPlayerEntity player, float amount) {
      if (!(amount <= 0.0F)) {
         if (equippedBoneArmor(player) == 0) {
            DATA.remove(player);
         } else {
            float maxHp = player.getMaxHealth();
            ArmorSkillHandler.Accum acc = DATA.get(player);
            float cumulative = (acc == null ? 0.0F : acc.damage()) + amount;
            DATA.put(player, new ArmorSkillHandler.Accum(cumulative, (long)player.getServer().getTicks()));
            if (amount >= maxHp * 0.8F || cumulative >= maxHp * 2.0F) {
               DATA.remove(player);
               grantBuff(player);
            }
         }
      }
   }

   private static void grantBuff(ServerPlayerEntity player) {
      player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 0));
      player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 0));
   }

   public static int equippedBoneArmor(ServerPlayerEntity player) {
      int count = 0;

      for (ItemStack stack : player.getInventory().armor) {
         if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            count++;
         }
      }

      return count;
   }

   private static record Accum(float damage, long lastDamageTick) {
   }
}
