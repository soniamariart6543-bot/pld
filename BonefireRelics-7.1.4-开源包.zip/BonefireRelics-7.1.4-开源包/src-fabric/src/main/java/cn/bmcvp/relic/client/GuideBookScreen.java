package cn.bmcvp.relic.client;

import cn.bmcvp.relic.BmcvpRelicUpgrades;
import cn.bmcvp.relic.RelicChapters;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * 《骨与火》—— 老书样式的遗物指南。
 *
 * 结构（2026-09-13 昀晞要求）：
 *   ① 前面是**完整的故事**（诸神并起 → 诸神之战 → 永恒之茧 → 茧裂 → 遗物的诞生 → 归来之炬）；
 *   ② 中间一页是**任务书进度**（六章，数据来自 data/bonefire_relics/task/chapters.json，服务端回传）；
 *   ③ 最后才是**功能介绍**（三件遗物用法 / 骨甲铸体 / 创造模式与命令）。
 * 版面：双页翻开的皮质封面 + 米色书页 + 中缝，正文自动换行并自动分页（按字号实际宽度计算）。
 */
public class GuideBookScreen extends Screen {
   // ——— 任务书（自研任务数据）状态：由服务端 CHAPTER_INFO 包回传 ———
   public static int chapterPercent;
   public static int chapterNow;
   public static int chapterRecorded;
   public static int attrTier;
   public static int attrBone;
   public static int attrSpell;

   // ——— 故事（以 # 开头的行是小标题）———
   private static final String[] STORY = {
      "# 序 · 烬",
      "远古时代，诸神并起，各拥信徒。神的力量来自信徒的供奉——香火、火种与记忆；无人记得的神，会先一步熄灭。",
      "因此在诸神之间，最珍贵的不是神力，而是人心；而“永恒”这种权柄，只容有一位主人。",
      "# 第一纪 · 诸神并起",
      "那时天空很低，神会亲自走到田边。烬恒——尊号“不熄之炬”——掌火焰与永恒，他的信徒自称薪火之民。",
      "与他们相对的是寒寂之神，掌霜与寂灭；此外还有枢轮（机枢与万械）、沉海（潮汐与遗忘）、丰岁（丰收与饥荒）、骸猎（骸骨与狩猎）。",
      "诸神各守一方，井水不犯河水，直到香火不再够分。",
      "# 第二纪 · 诸神之战",
      "战争的起因并非仇恨，而是供奉：信徒有限，火种有限，而“永恒”只能有一位主人。",
      "寒寂之神在“万炉齐熄之夜”冻结了薪火之民的圣炉。信徒失去了唯一能向烬恒献祭的火——于是烬恒拔起自己的火，第一次把它当作武器。",
      "诸神亲自下场。山川被改写，天空被烧成灰色。这一战没有胜者，只有还没熄灭的人。",
      "# 第三纪 · 永恒之茧",
      "烬恒做出了选择：以自身为燃料。",
      "他剖开自己的胸腔，把“永恒之火”点燃在自己身上——火不再是武器，而成了一道壁垒：由他的名字织成的护罩，罩住了全部信徒与属地。",
      "茧内的时间近乎停滞：信徒在护罩里沉睡，一睡就是千万年。代价是神的躯体在燃烧中一寸寸化成灰。",
      "唯有骨留了下来——因为他的“永恒”，一直藏在骨里。",
      "# 千万年之后 · 茧裂",
      "当最后一缕心火熄灭，契约完成，茧壳自行崩解。信徒与后裔走出护罩，世界已经换了模样。",
      "他们第一眼看到的，是神残存的巨大骨架——“第一座山，是神的背。”",
      "他们把这片土地称作“旧土”，把神的骨称作“烬骨晶”，并在骨旁立下了第一座炉。",
      "# 第四纪 · 遗物的诞生",
      "神骸崩解为烬骨晶，后裔以火与泪把它锻成可以握住的东西。每一件遗物都不是道具，而是神留在人间的一段身体：",
      "指骨成了战利品骨头，颅盖与肋条成了骨甲，腕骨成了骨斧，脊成了法杖，最后一滴乳白神血凝成野生果奶。",
      "而那颗由心脏打造的秘法核心，是唯一仍会跳动的遗物——一切法力的源头。",
      "# 遗物之理",
      "以凡世的材料与经验“喂养”神骸，它便在人间重新长成，这是升级；每块骨各自记得神的记忆，所以各项属性互不相牵。",
      "神骨认主，凡火熔不化：纵使死于他乡，骨也会自行归位。心脏是神留下的最后一块，绝不容失散。",
      "# 终局传说 · 归来之炬",
      "当所有遗物都被唤醒到最后一阶，散落在旧土各处的骨会自行聚拢，心脏会重新跳动——“归来之炬”于是点燃。",
      "有人说那会复活最初的那位神；也有人说，被唤醒的只是他留给世界的火种：一个愿意为他人燃尽自己的约定。"
   };

   // ——— 功能介绍（放最后）———
   private static final String[] FEATURES = {
      "# 无尽铁镐",
      "7 级材质路线（M1 钻石覆层 → M6 下界合金·钻石）；效率最高 V、时运最高 X。",
      "技能·补给：每挖掘 150 个方块获得「补给」5 秒，每秒恢复 1 点饥饿值与饱食度。",
      "# 战利品骨头",
      "主手武器，伤害最高 +50；火焰附加、抢夺、吸血。",
      "技能·骨火：每命中 3 次，对最近至多 3 只怪物造成火焰魔法伤害（基础 8，随攻击力成长，上限 20）。",
      "火焰附加 II：攻击时 1.2% 概率秒杀（伤害 999）。",
      "技能·骨裂：攻击力 ≥20 后，每次攻击附加 8% 目标当前生命值伤害。",
      "# 遗物骨甲",
      "需先进入地狱才能穿戴。",
      "护甲超限转化：穿戴 ≥2 件骨甲且全身护甲超 40 点后，每 1 点 = 1% 全面减伤 + 1% 最大生命 + 1% 法术抗性。",
      "技能·骨甲护体：单次受击 ≥80% 最大生命，或 20 秒内累计 ≥200% → 抗性 + 生命恢复 5 秒。",
      "# 骨甲铸体（材质）",
      "基础骨甲护甲值上限 20 点；升级材质（铸体）解锁更高上限：钻石铸体 → 上限 30；合金铸体 → 上限 50。",
      "每次材质升级，该件骨甲护甲值 +5（上限 50）。",
      "# 秘法核心",
      "由心脏打造的遗物，随击杀成长；提供三系法术强度加成与冷却减免，施法免符文消耗。",
      "# 创造模式与命令",
      "创造模式：升级不消耗材料与经验；每个升级界面右上角都有「一键满级」（会把身上所有遗物一次拉满，并计入任务书）。",
      "管理员命令：/relic grant <all|pickaxe|bone|bone_armor|arcane_core>"
   };

   /** 已排版的页：每页若干行；null 表示「任务书进度页」（动态绘制）。 */
   private static List<List<String>> pages;
   private static int questPageIndex = -1;

   // ——— 版面参数 ———
   private static final int BOOK_W = 286;
   private static final int BOOK_H = 210;
   private static final int PAGE_TEXT_W = 112;
   private static final int PAGE_TEXT_H = 150;
   private static final int LINE_H = 11;
   // 颜色
   private static final int C_COVER = -12961222;
   private static final int C_COVER_EDGE = -11374790;
   private static final int C_PAPER_L = -1450530;
   private static final int C_PAPER_R = -1842209;
   private static final int C_SPINE = -7697498;
   private static final int C_INK = -13748201;
   private static final int C_HEAD = -9929246;
   private static final int C_DIM = -7760987;

   private int page;

   public GuideBookScreen() {
      super(Text.literal("骨与火"));
   }

   /** 排版：故事 → 任务书页 → 功能介绍（自动换行 + 自动分页）。 */
   private static void buildPages() {
      if (pages != null) {
         return;
      }
      List<List<String>> result = new ArrayList<>();
      List<String> current = new ArrayList<>();
      int[] cursor = new int[]{0};

      List<String> all = new ArrayList<>();
      all.addAll(List.of(STORY));
      all.add("@@QUEST@@");
      all.addAll(List.of(FEATURES));

      for (String paragraph : all) {
         if ("@@QUEST@@".equals(paragraph)) {
            if (!current.isEmpty()) {
               result.add(current);
               current = new ArrayList<>();
            }
            questPageIndex = result.size();
            result.add(null);
            continue;
         }
         boolean heading = paragraph.startsWith("#");
         String text = heading ? paragraph.substring(1).trim() : paragraph;
         if (heading && !current.isEmpty()) {
            result.add(current);
            current = new ArrayList<>();
         }
         if (heading && !current.isEmpty()) {
            current.add("");
         }
         if (heading && !current.isEmpty()) {
            current.add("");
         }
         // 换行（按实际像素宽度）
         List<String> wrapped = wrap(text);
         if (heading) {
            // 小标题前后留白
            current.add("");
            for (String line : wrapped) {
               current.add("§h" + line);
            }
         } else {
            for (String line : wrapped) {
               current.add(line);
            }
            current.add("");
         }
         while (current.size() > linesPerPage()) {
            List<String> pageLines = new ArrayList<>(current.subList(0, linesPerPage()));
            result.add(pageLines);
            current = new ArrayList<>(current.subList(linesPerPage(), current.size()));
         }
      }
      if (!current.isEmpty()) {
         result.add(current);
      }
      // 保证双页：总页数为偶数
      if (result.size() % 2 != 0) {
         result.add(new ArrayList<>());
      }
      pages = result;
   }

   private static int linesPerPage() {
      return Math.max(1, PAGE_TEXT_H / LINE_H);
   }

   /** 按像素宽度手工换行（中文逐字、英文按空格）。 */
   private static List<String> wrap(String text) {
      List<String> lines = new ArrayList<>();
      StringBuilder line = new StringBuilder();
      int width = 0;
      net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
      for (int i = 0; i < text.length(); i++) {
         char c = text.charAt(i);
         int charWidth = 9;
         try {
            charWidth = client.textRenderer.getWidth(String.valueOf(c));
         } catch (Throwable ignored) {
         }
         if (c == '\n' || width + charWidth > PAGE_TEXT_W) {
            lines.add(line.toString());
            line = new StringBuilder();
            width = 0;
            if (c == '\n') {
               continue;
            }
         }
         line.append(c);
         width += charWidth;
      }
      if (line.length() > 0) {
         lines.add(line.toString());
      }
      return lines;
   }

   protected void init() {
      buildPages();
      // 打开书就向服务端要一次任务书状态
      ClientPlayNetworking.send(BmcvpRelicUpgrades.CHAPTER_REQ, PacketByteBufs.create());
      int left = this.width / 2 - BOOK_W / 2;
      int top = this.height / 2 - BOOK_H / 2;
      this.addDrawableChild(ButtonWidget.builder(Text.literal("◀ 上页"), b -> {
         if (this.page > 1) {
            this.page -= 2;
         }
      }).dimensions(left + 40, top + BOOK_H - 24, 70, 18).build());
      this.addDrawableChild(ButtonWidget.builder(Text.literal("下页 ▶"), b -> {
         if (this.page + 2 < pages.size()) {
            this.page += 2;
         }
      }).dimensions(left + BOOK_W - 110, top + BOOK_H - 24, 70, 18).build());
      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("合上"), b -> this.close())
            .dimensions(left + BOOK_W / 2 - 35, top + BOOK_H - 24, 70, 18).build()
      );
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      this.renderBackground(context);
      buildPages();
      int left = this.width / 2 - BOOK_W / 2;
      int top = this.height / 2 - BOOK_H / 2;
      this.drawBook(context, left, top);

      int leftPageIndex = this.page;
      int rightPageIndex = this.page + 1;
      this.drawPage(context, leftPageIndex, left + 12, top + 26);
      this.drawPage(context, rightPageIndex, left + 148, top + 26);

      // 页码
      String footer = (leftPageIndex + 1) + " - " + Math.min(rightPageIndex + 1, pages.size()) + " / " + pages.size();
      context.drawCenteredTextWithShadow(this.textRenderer, footer, this.width / 2, top + BOOK_H - 14, C_DIM);
      context.drawCenteredTextWithShadow(this.textRenderer, "《 骨与火 》", this.width / 2, top - 3, -1);

      super.render(context, mouseX, mouseY, delta);
   }

   /** 书本外观：皮革封面 + 米色书页 + 中缝。 */
   private void drawBook(DrawContext context, int left, int top) {
      // 封面
      context.fill(left - 8, top - 8, left + BOOK_W + 8, top + BOOK_H + 8, C_COVER);
      context.fill(left - 6, top - 6, left + BOOK_W + 6, top + BOOK_H + 6, C_COVER_EDGE);
      // 书页
      context.fill(left, top, left + 143, top + BOOK_H, C_PAPER_L);
      context.fill(left + 143, top, left + BOOK_W, top + BOOK_H, C_PAPER_R);
      // 页边阴影
      context.fill(left, top, left + 3, top + BOOK_H, -6250336);
      context.fill(left + BOOK_W - 3, top, left + BOOK_W, top + BOOK_H, -6250336);
      context.fill(left, top, left + BOOK_W, top + 3, -6250336);
      context.fill(left, top + BOOK_H - 3, left + BOOK_W, top + BOOK_H, -6250336);
      // 中缝
      context.fill(left + 141, top, left + 146, top + BOOK_H, C_SPINE);
      context.fill(left + 140, top, left + 141, top + BOOK_H, -3092272);
      context.fill(left + 146, top, left + 147, top + BOOK_H, -3092272);
   }

   /** 绘制某一页（index 为 null 页 → 任务书进度页）。 */
   private void drawPage(DrawContext context, int index, int x, int y) {
      if (index < 0 || index >= pages.size()) {
         return;
      }
      List<String> lines = pages.get(index);
      if (lines == null) {
         this.drawQuestPage(context, x, y);
         return;
      }
      for (int i = 0; i < lines.size() && i < linesPerPage(); i++) {
         String line = lines.get(i);
         boolean heading = line.startsWith("§h");
         String text = heading ? line.substring(2) : line;
         context.drawText(this.textRenderer, text, x, y + i * LINE_H, heading ? C_HEAD : C_INK, false);
      }
   }

   /** 任务书进度页：六章状态 + 三项主属性（数据由服务端计算回传）。 */
   private void drawQuestPage(DrawContext context, int x, int y) {
      List<String> lines = new ArrayList<>();
      lines.add("§h任务书 · 六章");
      lines.add("总进度 " + chapterPercent + "%　（三项归一化求和）");
      lines.add("镐 " + attrTier + "/" + RelicChapters.TIER_MAX
         + "　骨 " + attrBone + "/" + RelicChapters.BONE_MAX
         + "　杖 " + attrSpell + "/" + RelicChapters.SPELL_MAX);
      lines.add("只有非创造升级才计入；");
      lines.add("创造点「一键满级」也计入。");
      for (RelicChapters.Chapter chapter : RelicChapters.all()) {
         boolean done = chapter.index() <= chapterRecorded;
         int percent = (int)Math.round(chapter.threshold() * 100.0);
         lines.add((done ? "★" : "·") + " 第" + chapter.index() + "章 " + chapter.name() + " " + percent + "%");
      }
      RelicChapters.Chapter current = RelicChapters.chapter(Math.max(1, chapterRecorded));
      lines.add("");
      lines.add(current.goal());

      for (int i = 0; i < lines.size() && i < linesPerPage(); i++) {
         String line = lines.get(i);
         boolean heading = line.startsWith("§h");
         String text = heading ? line.substring(2) : line;
         context.drawText(this.textRenderer, text, x, y + i * LINE_H, heading ? C_HEAD : C_INK, false);
      }
   }

   public boolean shouldPause() {
      return false;
   }
}
