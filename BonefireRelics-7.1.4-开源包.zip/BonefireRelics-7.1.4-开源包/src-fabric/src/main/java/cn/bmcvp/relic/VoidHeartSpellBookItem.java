package cn.bmcvp.relic;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.Settings;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.spell_engine.api.item.trinket.SpellBookTrinketItem;

/**
 * 虚空神心 · 法术书形态（照抄 ArcaneCoreSpellBookItem 的穿戴方式）：
 * 走 spell_engine 的 SpellBookTrinketItem → 进「法术书饰品槽（charm/spell_book）」，
 * 与秘法核心共用同一条已被验证可用的穿戴路径，且**法术能力完整保留**。
 */
public final class VoidHeartSpellBookItem extends SpellBookTrinketItem {
   public VoidHeartSpellBookItem(Identifier poolId, Settings settings) {
      super(poolId, settings);
   }

   @Override
   public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
      super.appendTooltip(stack, world, tooltip, context);
      tooltip.add(Text.translatable("tooltip.bonefire_relics.void_heart.1").formatted(Formatting.DARK_RED));
      for (int i = 2; i <= 11; i++) {
         Formatting color = (i == 2 || i == 3) ? Formatting.GOLD : (i >= 7 ? Formatting.DARK_GRAY : Formatting.GRAY);
         tooltip.add(Text.translatable("tooltip.bonefire_relics.void_heart." + i).formatted(color));
      }
   }
}