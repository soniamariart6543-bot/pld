package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.KeepInventoryStore;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * v9 稳定器：ServerPlayerEntity.tick 每 tick 守护暂存遗物——
 * 槽被 YIGD 等重生覆写清空则立即补回，连续在位满阈值自动释放。
 */
@Mixin({ServerPlayerEntity.class})
public abstract class RelicStabilizeMixin {
   @Inject(method = {"tick"}, at = {@At("HEAD")})
   private void bmcvp$stabilizeRelics(CallbackInfo ci) {
      KeepInventoryStore.stabilize((ServerPlayerEntity)(Object)this);
   }
}
