package cn.bmcvp.relic.client;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import cn.bmcvp.relic.ArmorOvercapConfig;
import cn.bmcvp.relic.BmcvpRelicUpgrades;
import cn.bmcvp.relic.ModItems;
import cn.bmcvp.relic.ModParticles;
import cn.bmcvp.relic.RelicEntities;
import cn.bmcvp.relic.RelicProbe;
import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketsApi;
import java.util.Optional;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.StartTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DefaultParticleType;

public class BmcvpRelicUpgradesClient implements ClientModInitializer {
   private static int coreInfoCounter;

   public void onInitializeClient() {
      ArmorOvercapConfig.load();
      RelicButtonConfig.load();
      RelicProbe.initializeClient();
      EntityRendererRegistry.register(RelicEntities.RELIC_FIREBALL, RelicFireballRenderer::new);
      ParticleFactoryRegistry.getInstance()
         .register(
            ModParticles.ARCANE_REVIVE,
            new ParticleFactoryRegistry.PendingParticleFactory<DefaultParticleType>() {
               public ParticleFactory<DefaultParticleType> create(FabricSpriteProvider spriteProvider) {
                  return (parameters, world, x, y, z, vx, vy, vz) -> new ArcaneReviveParticle(
                     world, x, y, z, vx, vy, vz, spriteProvider
                  );
               }
            }
         );
      ClientPlayNetworking.registerGlobalReceiver(BmcvpRelicUpgrades.RESULT, (client, handler, buf, response) -> {
         String message = buf.readString(64);
         client.execute(() -> RelicUpgradeScreen.receiveServerResult(message));
      });
      // 任务书（六章）状态回包：必须在 netty 线程里先读完 buf，再切回客户端线程写状态
      ClientPlayNetworking.registerGlobalReceiver(BmcvpRelicUpgrades.CHAPTER_INFO, (client, handler, buf, response) -> {
         int percent = buf.readInt();
         int now = buf.readInt();
         int recorded = buf.readInt();
         int tier = buf.readInt();
         int bone = buf.readInt();
         int spell = buf.readInt();
         client.execute(() -> {
            GuideBookScreen.chapterPercent = percent;
            GuideBookScreen.chapterNow = now;
            GuideBookScreen.chapterRecorded = recorded;
            GuideBookScreen.attrTier = tier;
            GuideBookScreen.attrBone = bone;
            GuideBookScreen.attrSpell = spell;
         });
      });
      ClientTickEvents.START_CLIENT_TICK.register((StartTick)client -> {
         if (client.player != null) {
            if (RelicService.isRelic(client.player.getMainHandStack(), UpgradeDefinition.RelicType.WAND)) {
               if (client.options.attackKey.wasPressed()) {
                  ClientPlayNetworking.send(BmcvpRelicUpgrades.WAND_SWING, PacketByteBufs.create());
               }
            }
         }
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         if (client.player != null && client.getNetworkHandler() != null) {
            if (++coreInfoCounter % 40 == 0) {
               if (playerHasArcaneCore(client.player)) {
                  ClientPlayNetworking.send(BmcvpRelicUpgrades.GROWTH_INFO_REQ, PacketByteBufs.create());
               }
            }
         }
      });
   }

   private static boolean playerHasArcaneCore(PlayerEntity player) {
      if (ModItems.ARCANE_CORE == null) {
         return false;
      } else {
         for (ItemStack stack : player.getInventory().main) {
            if (stack.isOf(ModItems.ARCANE_CORE)) {
               return true;
            }
         }

         if (player.getOffHandStack().isOf(ModItems.ARCANE_CORE)) {
            return true;
         } else {
            for (ItemStack stackx : player.getInventory().armor) {
               if (stackx.isOf(ModItems.ARCANE_CORE)) {
                  return true;
               }
            }

            Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
            return component.isPresent() && !component.get().getEquipped(ArcaneCoreGrowth::isArcaneCore).isEmpty();
         }
      }
   }
}
