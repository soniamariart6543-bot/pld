package cn.bmcvp.relic.mixin.se;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import cn.bmcvp.relic.ModItems;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.spell_engine.api.spell.Spell;
import net.spell_engine.internals.SpellHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 秘法核心：施法**不需要符文、也不消耗符文**（完全免符文）。
 *
 * 判定（双保险）：
 *   ① casterStack（正在施法的物品，通常为法杖）为秘法核心法术书
 *   ② 或玩家身上（饰品槽/背包/副手/装备栏）带着秘法核心
 * 手段：ammoForSpell HEAD 返回 (satisfied=true, ammo=ItemStack.EMPTY)
 *   · satisfied=true → 背包里没有符文也能施法
 *   · ammo=空 → performSpell 扣减循环匹配不到物品 → 不消耗符文
 * 其它法术书/法杖不受影响；未装 spell_engine 时该配置整体不加载。
 * 注：调试探针已按"收尾清理"约定移除（2026-09-10）。
 */
@Mixin({SpellHelper.class})
public abstract class ArcaneCoreNoRuneCostMixin {
   @Inject(method = {"ammoForSpell"}, at = {@At("HEAD")}, cancellable = true)
   private static void bmcvp$freeCastForArcaneCore(
      PlayerEntity caster, Spell spell, ItemStack casterStack, CallbackInfoReturnable<SpellHelper.AmmoResult> cir
   ) {
      boolean hasCoreItem = ModItems.ARCANE_CORE != null && casterStack != null && !casterStack.isEmpty()
         && casterStack.isOf(ModItems.ARCANE_CORE);
      // 双端判定：客户端(Render thread)也会跑这段前置检查，必须同样认得出"身上带核心"
      boolean hasCoreOnBody = ArcaneCoreGrowth.hasCoreEquipped(caster);
      if (hasCoreItem || hasCoreOnBody) {
         cir.setReturnValue(new SpellHelper.AmmoResult(true, ItemStack.EMPTY));
      }
   }
}
