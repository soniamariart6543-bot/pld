package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ItemEntity.class})
public abstract class ItemEntityProtectionMixin {
   @Inject(
      method = {"damage"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void bmcvp$protectRelic(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
      ItemEntity self = (ItemEntity)(Object)this;
      if (RelicService.isAnyRelic(self.getStack())) {
         cir.setReturnValue(false);
      }
   }
}
