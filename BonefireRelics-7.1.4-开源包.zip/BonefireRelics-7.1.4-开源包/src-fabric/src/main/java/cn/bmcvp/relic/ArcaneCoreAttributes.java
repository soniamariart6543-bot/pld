package cn.bmcvp.relic;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import java.util.UUID;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.spell_power.api.SpellSchools;

public final class ArcaneCoreAttributes {
   private ArcaneCoreAttributes() {
   }

   public static Multimap<EntityAttribute, EntityAttributeModifier> modifiers(ItemStack stack, UUID uuid) {
      int level = ArcaneCoreGrowth.levelOf(stack);
      if (level < 1) {
         level = 1;
      }

      Multimap<EntityAttribute, EntityAttributeModifier> map = HashMultimap.create();
      map.put(EntityAttributes.GENERIC_MAX_HEALTH, new EntityAttributeModifier(uuid, "Bonefire Arcane Core Max Health", ArcaneCoreGrowth.maxHealthFor(level), Operation.ADDITION));
      map.put(EntityAttributes.GENERIC_ATTACK_DAMAGE, new EntityAttributeModifier(uuid, "Bonefire Arcane Core Attack Damage", ArcaneCoreGrowth.attackFor(level), Operation.ADDITION));
      // 移动速度加成由 ArcaneCoreGrowth.syncAttributes 单源统一注入（trinket 双份会导致
      // “穿戴瞬间加速闪变后回落”，故饰品修饰不再重复添加速度）
      // 法强三系仅在 spell_power 存在时附加（缺失自动降级：无法强加成，不崩）
      if (net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("spell_power")) {
         map.put(SpellSchools.FIRE.attribute, new EntityAttributeModifier(uuid, "Bonefire Arcane Core Fire Power", 0.10, Operation.MULTIPLY_BASE));
         map.put(SpellSchools.FROST.attribute, new EntityAttributeModifier(uuid, "Bonefire Arcane Core Frost Power", 0.10, Operation.MULTIPLY_BASE));
         map.put(SpellSchools.ARCANE.attribute, new EntityAttributeModifier(uuid, "Bonefire Arcane Core Arcane Power", 0.10, Operation.MULTIPLY_BASE));
      }
      return map;
   }
}
