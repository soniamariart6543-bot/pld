package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDamage;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public final class LifestealHandler {
   private static final int TEMP_HP_TICKS = 160;
   private static final Map<ServerPlayerEntity, LifestealHandler.Accum> ABSORPTION = new WeakHashMap<>();

   public static void initialize() {
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((AllowDamage)(entity, source, amount) -> {
         if (amount > 0.0F && source.getAttacker() instanceof ServerPlayerEntity player && entity != player) {
            ItemStack stack = player.getMainHandStack();
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
               int level = RelicService.value(stack, "fortune");
               if (level > 0 && player.getServer() != null) {
                  player.getServer().execute(() -> applyLifesteal(player, amount, level));
               }
            }
         }

         return true;
      });
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         long now = (long)server.getTicks();
         ABSORPTION.entrySet().removeIf(entry -> {
            LifestealHandler.Accum acc = entry.getValue();
            if (acc.expiryTick() <= now) {
               ServerPlayerEntity player = entry.getKey();
               if (player != null && !player.isRemoved()) {
                  player.setAbsorptionAmount(Math.max(0.0F, player.getAbsorptionAmount() - acc.amount()));
               }

               return true;
            } else {
               return false;
            }
         });
      });
   }

   public static void applyWandLifesteal(ServerPlayerEntity player, float damage, int level) {
      applyLifesteal(player, damage, level);
   }

   public static void applyLifesteal(ServerPlayerEntity player, float damage, int level) {
      float percent = RelicService.lifestealPercent(level);
      float lifesteal = damage * percent;
      if (!(lifesteal <= 0.0F)) {
         float before = player.getHealth();
         player.heal(lifesteal);
         float healed = player.getHealth() - before;
         float overflow = lifesteal - healed;
         if (overflow > 0.0F) {
            float maxAbsorption = player.getMaxHealth() * 0.5F;
            float absorptionBefore = player.getAbsorptionAmount();
            float newAbsorption = Math.min(absorptionBefore + overflow, maxAbsorption);
            player.setAbsorptionAmount(newAbsorption);
            float added = newAbsorption - absorptionBefore;
            LifestealHandler.Accum acc = ABSORPTION.get(player);
            float ourShare = acc == null ? 0.0F : acc.amount();
            ABSORPTION.put(player, new LifestealHandler.Accum(ourShare + added, (long)player.getServer().getTicks() + 160L));
         }
      }
   }

   private static record Accum(float amount, long expiryTick) {
   }
}
