package cn.bmcvp.relic;

import cn.bmcvp.relic.client.GuideBookScreen;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item.Settings;

public class GuideBookItem extends Item {
   public GuideBookItem() {
      super(new Settings().maxCount(1).fireproof());
   }

   public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
      if (world.isClient) {
         MinecraftClient.getInstance().setScreen(new GuideBookScreen());
      }

      return TypedActionResult.success(user.getStackInHand(hand));
   }
}
