package cn.bmcvp.relic;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

public final class ModEffects {
   public static final StatusEffect SUPPLY = (StatusEffect)Registry.register(
      Registries.STATUS_EFFECT, new Identifier("bonefire_relics", "supply"), new SupplyEffect()
   );

   private ModEffects() {
   }

   public static void initialize() {
   }
}
