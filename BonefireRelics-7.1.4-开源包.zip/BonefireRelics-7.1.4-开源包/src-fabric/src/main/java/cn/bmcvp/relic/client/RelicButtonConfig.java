package cn.bmcvp.relic.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 「遗物」按钮位置配置（客户端）：config/bonefire_relics_button.json
 *
 * 偏移量相对 **GUI 面板左上角**（像素），可以为负数（表示面板外）。
 * 默认值放在面板右上方（面板外），避免与整理类 mod（如 InventoryProfilesNext 的整理/设置按钮）
 * 在 GAIN 面板内部抢位置；若你想放回面板内，改这里的数字即可，不必等新版本。
 *
 * 例：想放回原来的位置（面板内右侧）就写成
 *     "inventoryButtonX": 129, "inventoryButtonY": 65
 */
public final class RelicButtonConfig {
   public static final String FILE_NAME = "bonefire_relics_button.json";

   /** 生存背包界面按钮偏移（相对面板左上角）。 */
   public int inventoryButtonX = 137;
   public int inventoryButtonY = -15;
   /** 创造模式背包界面按钮偏移（创造面板更宽且顶部有物品栏标签，默认放面板下方）。 */
   public int creativeButtonX = 137;
   public int creativeButtonY = 140;
   /** 按钮尺寸。 */
   public int buttonWidth = 39;
   public int buttonHeight = 14;

   private static RelicButtonConfig instance = new RelicButtonConfig();

   private RelicButtonConfig() {
   }

   public static RelicButtonConfig get() {
      return instance;
   }

   public static void load() {
      Path dir = Path.of("config");
      Path file = dir.resolve(FILE_NAME);
      Gson gson = new GsonBuilder().setPrettyPrinting().create();
      try {
         if (Files.exists(file)) {
            RelicButtonConfig parsed = gson.fromJson(Files.readString(file, StandardCharsets.UTF_8), RelicButtonConfig.class);
            if (parsed != null) {
               instance = parsed;
            }
         } else {
            Files.createDirectories(dir);
            Files.writeString(file, gson.toJson(instance), StandardCharsets.UTF_8);
         }
      } catch (IOException ignored) {
      }
      sanitize();
   }

   private static void sanitize() {
      if (instance.buttonWidth < 20) {
         instance.buttonWidth = 20;
      }
      if (instance.buttonWidth > 200) {
         instance.buttonWidth = 200;
      }
      if (instance.buttonHeight < 10) {
         instance.buttonHeight = 10;
      }
      if (instance.buttonHeight > 40) {
         instance.buttonHeight = 40;
      }
      if (instance.inventoryButtonX < -200) {
         instance.inventoryButtonX = -200;
      }
      if (instance.inventoryButtonX > 400) {
         instance.inventoryButtonX = 400;
      }
      if (instance.inventoryButtonY < -200) {
         instance.inventoryButtonY = -200;
      }
      if (instance.inventoryButtonY > 400) {
         instance.inventoryButtonY = 400;
      }
      if (instance.creativeButtonX < -200) {
         instance.creativeButtonX = -200;
      }
      if (instance.creativeButtonX > 400) {
         instance.creativeButtonX = 400;
      }
      if (instance.creativeButtonY < -200) {
         instance.creativeButtonY = -200;
      }
      if (instance.creativeButtonY > 400) {
         instance.creativeButtonY = 400;
      }
   }
}
