package cn.bmcvp.relic;

import dev.emi.trinkets.api.TrinketsApi;
import java.util.List;
import net.fabricmc.fabric.api.util.TriState;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.item.ItemConvertible;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.registry.Registries;
import net.minecraft.item.ArmorItem.Type;
import net.minecraft.item.Item.Settings;
import net.spell_engine.api.item.trinket.SpellBooks;
import net.spell_engine.api.spell.SpellContainer;
import net.spell_engine.api.spell.SpellContainer.ContentType;
import net.spell_engine.internals.SpellRegistry;

public final class ModItems {
   public static final String MOD_ID = "bonefire_relics";
   private static final ToolMaterial NETHERITE_IRON = toolMaterial(4, 2400, 10.0F, 5.0F, 15, Items.NETHERITE_INGOT);
   private static final ToolMaterial NETHERITE_GOLD = toolMaterial(4, 2600, 11.0F, 5.5F, 18, Items.NETHERITE_INGOT);
   private static final ToolMaterial NETHERITE_EMERALD = toolMaterial(5, 3000, 12.0F, 6.0F, 20, Items.NETHERITE_INGOT);
   private static final ToolMaterial NETHERITE_DIAMOND = toolMaterial(5, 3600, 13.0F, 7.0F, 22, Items.NETHERITE_INGOT);
   private static final ArmorMaterial BONE_ARMOR = new ArmorMaterial() {
      public int getDurability(Type type) {
         return switch (type) {
            case HELMET -> 165;
            case CHESTPLATE -> 240;
            case LEGGINGS -> 225;
            case BOOTS -> 195;
            default -> throw new IncompatibleClassChangeError();
         };
      }

      public int getProtection(Type type) {
         return switch (type) {
            case HELMET -> 2;
            case CHESTPLATE -> 6;
            case LEGGINGS -> 5;
            case BOOTS -> 2;
            default -> throw new IncompatibleClassChangeError();
         };
      }

      public int getEnchantability() {
         return 25;
      }

      public SoundEvent getEquipSound() {
         return SoundEvents.ITEM_ARMOR_EQUIP_GENERIC;
      }

      public Ingredient getRepairIngredient() {
         return Ingredient.ofItems(new ItemConvertible[]{Items.BONE});
      }

      public String getName() {
         return "iron";
      }

      public float getToughness() {
         return 0.0F;
      }

      public float getKnockbackResistance() {
         return 0.0F;
      }
   };
   public static final Item RELIC_BONE = register("relic_bone", new RelicBoneItem());
   public static final Item RELIC_GUIDE_BOOK = register("relic_guide_book", new GuideBookItem());
   public static final Item MAGIC_WAND = register("magic_wand", new RelicWandItem(ToolMaterials.IRON, 3, -2.0F, new Settings().fireproof()));
   public static final Item RELIC_INFINITE_APPLE = register("relic_infinite_apple", new InfiniteAppleItem(new Settings().maxCount(1).fireproof()));
   /** 虚空神心：三项主属性满级后由秘法核心融合而成。初始化时按时装/法术书能力择一注册。 */
   public static Item RELIC_VOID_HEART = null;
   public static Item ARCANE_CORE = null;
   public static final Item RELIC_IRON_PICKAXE = pickaxe("relic_iron_pickaxe", ToolMaterials.IRON, false);
   public static final Item RELIC_DIAMOND_PICKAXE = pickaxe("relic_diamond_pickaxe", ToolMaterials.DIAMOND, false);
   public static final Item RELIC_NETHERITE_PICKAXE = pickaxe("relic_netherite_pickaxe", ToolMaterials.NETHERITE, true);
   public static final Item RELIC_NETHERITE_IRON_PICKAXE = pickaxe("relic_netherite_iron_pickaxe", NETHERITE_IRON, true);
   public static final Item RELIC_NETHERITE_GOLD_PICKAXE = pickaxe("relic_netherite_gold_pickaxe", NETHERITE_GOLD, true);
   public static final Item RELIC_NETHERITE_EMERALD_PICKAXE = pickaxe("relic_netherite_emerald_pickaxe", NETHERITE_EMERALD, true);
   public static final Item RELIC_NETHERITE_DIAMOND_PICKAXE = pickaxe("relic_netherite_diamond_pickaxe", NETHERITE_DIAMOND, true);
   public static final Item RELIC_BONE_HELMET = boneArmor("relic_bone_helmet", BONE_ARMOR, Type.HELMET);
   public static final Item RELIC_BONE_CHESTPLATE = boneArmor("relic_bone_chestplate", BONE_ARMOR, Type.CHESTPLATE);
   public static final Item RELIC_BONE_LEGGINGS = boneArmor("relic_bone_leggings", BONE_ARMOR, Type.LEGGINGS);
   public static final Item RELIC_BONE_BOOTS = boneArmor("relic_bone_boots", BONE_ARMOR, Type.BOOTS);
   public static final Item RELIC_BONE_DIAMOND_HELMET = boneArmor("relic_bone_diamond_helmet", ArmorMaterials.DIAMOND, Type.HELMET);
   public static final Item RELIC_BONE_DIAMOND_CHESTPLATE = boneArmor("relic_bone_diamond_chestplate", ArmorMaterials.DIAMOND, Type.CHESTPLATE);
   public static final Item RELIC_BONE_DIAMOND_LEGGINGS = boneArmor("relic_bone_diamond_leggings", ArmorMaterials.DIAMOND, Type.LEGGINGS);
   public static final Item RELIC_BONE_DIAMOND_BOOTS = boneArmor("relic_bone_diamond_boots", ArmorMaterials.DIAMOND, Type.BOOTS);
   public static final Item RELIC_BONE_NETHERITE_HELMET = boneArmor("relic_bone_netherite_helmet", ArmorMaterials.NETHERITE, Type.HELMET);
   public static final Item RELIC_BONE_NETHERITE_CHESTPLATE = boneArmor("relic_bone_netherite_chestplate", ArmorMaterials.NETHERITE, Type.CHESTPLATE);
   public static final Item RELIC_BONE_NETHERITE_LEGGINGS = boneArmor("relic_bone_netherite_leggings", ArmorMaterials.NETHERITE, Type.LEGGINGS);
   public static final Item RELIC_BONE_NETHERITE_BOOTS = boneArmor("relic_bone_netherite_boots", ArmorMaterials.NETHERITE, Type.BOOTS);
   // —— 骨斧（Bone Axe）：3 形态（骨=对标铁级 / 钻石 / 下界合金）——
   private static final ToolMaterial BONE_AXE_BONE = toolMaterial(2, 99999, 6.0F, 0.0F, 14, Items.BONE);
   private static final ToolMaterial BONE_AXE_DIAMOND = toolMaterial(3, 99999, 8.0F, 0.0F, 14, Items.DIAMOND);
   private static final ToolMaterial BONE_AXE_NETHERITE = toolMaterial(4, 99999, 9.0F, 0.0F, 15, Items.NETHERITE_INGOT);
   public static final Item RELIC_BONE_AXE = axe("relic_bone_axe", BONE_AXE_BONE, false);
   public static final Item RELIC_BONE_AXE_DIAMOND = axe("relic_bone_axe_diamond", BONE_AXE_DIAMOND, false);
   public static final Item RELIC_BONE_AXE_NETHERITE = axe("relic_bone_axe_netherite", BONE_AXE_NETHERITE, true);

   private static ToolMaterial toolMaterial(int miningLevel, int durability, float speed, float attack, int enchantability, Item repairItem) {
      return new ToolMaterial() {
         public int getDurability() {
            return durability;
         }

         public float getMiningSpeedMultiplier() {
            return speed;
         }

         public float getAttackDamage() {
            return attack;
         }

         public int getMiningLevel() {
            return miningLevel;
         }

         public int getEnchantability() {
            return enchantability;
         }

         public Ingredient getRepairIngredient() {
            return Ingredient.ofItems(new ItemConvertible[]{repairItem});
         }
      };
   }

   private ModItems() {
   }

   private static class PickaxeHandle extends PickaxeItem {
      PickaxeHandle(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
         super(material, attackDamage, attackSpeed, settings);
      }
   }

   /** 骨斧物品：攻击力与攻速由 material（0 攻）与参数固定；实际攻击=8+5×材质级+巨力级（refreshStack 注入）。 */
   private static class AxeHandle extends AxeItem {
      AxeHandle(ToolMaterial material, Settings settings) {
         super(material, 0.0F, 6.0F, settings);
      }
   }

   private static Item axe(String path, ToolMaterial material, boolean fireproof) {
      Settings settings = new Settings().fireproof();
      return register(path, new AxeHandle(material, settings));
   }

   private static Item pickaxe(String path, ToolMaterial material, boolean fireproof) {
      Settings settings = new Settings().fireproof();
      return register(path, new PickaxeHandle(material, 1, -2.8F, settings));
   }

   private static Item boneArmor(String path, ArmorMaterial material, Type type) {
      return register(path, new RelicBoneArmorItem(material, type, new Settings().fireproof()));
   }

   private static Item register(String path, Item item) {
      return (Item)Registry.register(Registries.ITEM, new Identifier("bonefire_relics", path), item);
   }

   public static void initialize() {
      FabricLoader loader = FabricLoader.getInstance();
      boolean hasTrinkets = loader.isModLoaded("trinkets");
      boolean hasSpellEngine = loader.isModLoaded("spell_engine");
      boolean hasSpellPower = loader.isModLoaded("spell_power");
      System.out.println(
         "[bonefire_relics] 可选依赖探测: trinkets=" + hasTrinkets + " spell_engine=" + hasSpellEngine + " spell_power=" + hasSpellPower
      );
      if (hasTrinkets) {
         if (hasSpellEngine) {
            Identifier poolId = new Identifier("bonefire_relics", "arcane_core");
            Identifier bookId = SpellBooks.itemIdFor(poolId);
            ArcaneCoreSpellBookItem book = new ArcaneCoreSpellBookItem(poolId, new Settings().maxCount(1).fireproof());
            SpellRegistry.book_containers.put(bookId, new SpellContainer(ContentType.MAGIC, false, poolId.toString(), 6, List.of()));
            SpellBooks.all.add(book);
            ARCANE_CORE = register(bookId.getPath(), book);
            // 虚空神心：同一条法术书路径（进 charm/spell_book 槽，法术能力保留）
            Identifier heartPoolId = new Identifier("bonefire_relics", "void_heart");
            Identifier heartBookId = SpellBooks.itemIdFor(heartPoolId);
            VoidHeartSpellBookItem heartBook = new VoidHeartSpellBookItem(heartPoolId, new Settings().maxCount(1).fireproof());
            SpellRegistry.book_containers.put(heartBookId, new SpellContainer(ContentType.MAGIC, false, heartPoolId.toString(), 6, List.of()));
            SpellBooks.all.add(heartBook);
            RELIC_VOID_HEART = register(heartBookId.getPath(), heartBook);
            System.out.println("[bonefire_relics] 虚空神心已注册（法术书形态）: " + RELIC_VOID_HEART.getTranslationKey());
         } else {
            ARCANE_CORE = register("arcane_core", new ArcaneCoreTrinketItem(new Settings().maxCount(1).fireproof()));
         }

         TrinketsApi.registerTrinketPredicate(new Identifier("bonefire_relics", "void_heart_slot"), (stack, slot, entity) -> {
            // 依赖守卫：神心未注册（无 spell_engine 且尚未兜底）时一律不放行，避免 NPE
            return RELIC_VOID_HEART != null && stack.isOf(RELIC_VOID_HEART) ? TriState.TRUE : TriState.FALSE;
         });
      TrinketsApi.registerTrinketPredicate(new Identifier("bonefire_relics", "arcane_core_slot"), (stack, slot, entity) -> {
            if (hasSpellEngine) {
               return TriState.FALSE;
            } else {
               // 虚空神心与秘法核心共用同一个 charm 槽（照抄秘法核心已验证可用的穿戴路径）
         if (stack.isOf(ARCANE_CORE)) {
            return TriState.TRUE;
         }
         return ModItems.RELIC_VOID_HEART != null && stack.isOf(ModItems.RELIC_VOID_HEART) ? TriState.TRUE : TriState.FALSE;
            }
         });
      } else {
         System.out.println("[bonefire_relics] 秘法核心未注册（缺 trinkets）——本体/骨甲/骨斧等功能不受影响");
      }
      if (ARCANE_CORE != null) {
         System.out.println("[bonefire_relics] 秘法核心已注册: " + ARCANE_CORE.getTranslationKey()
            + (hasSpellEngine ? "（法术书形态，池 bonefire_relics:arcane_core）" : "（饰品形态，无 spell_engine）"));
      }
   }

   /** 兜底：无 spell_engine 时，神心以护甲形态注册。 */
   public static void ensureVoidHeartRegistered() {
      if (RELIC_VOID_HEART == null) {
         RELIC_VOID_HEART = register("relic_void_heart", new VoidHeartItem());
      }
   }
}
