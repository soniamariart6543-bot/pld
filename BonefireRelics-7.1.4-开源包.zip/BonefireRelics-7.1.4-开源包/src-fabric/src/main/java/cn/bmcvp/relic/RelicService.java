package cn.bmcvp.relic;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.util.Formatting;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;

public final class RelicService {
   public static final String NBT = "bonefire_relics";
   public static final int MAX_EXPERIENCE_COST = 50;
   private static final UUID BONE_DAMAGE_UUID = UUID.fromString("11111201-0000-0000-0000-000000000001");
   /** 骨斧攻击伤害 modifier（攻击 = 8 + 5×材质级 + 巨力级，上限 8+15+27=50）。 */
   private static final UUID BONE_AXE_DAMAGE_UUID = UUID.fromString("11111202-0000-0000-0000-000000000001");
   private static final UUID[] ARMOR_TOUGHNESS_UUIDS = new UUID[]{
      UUID.fromString("11111202-0000-0000-0000-000000000001"),
      UUID.fromString("11111203-0000-0000-0000-000000000001"),
      UUID.fromString("11111204-0000-0000-0000-000000000001"),
      UUID.fromString("11111205-0000-0000-0000-000000000001")
   };
   private static final UUID[] ARMOR_VALUE_UUIDS = new UUID[]{
      UUID.fromString("11111206-0000-0000-0000-000000000001"),
      UUID.fromString("11111207-0000-0000-0000-000000000001"),
      UUID.fromString("11111208-0000-0000-0000-000000000001"),
      UUID.fromString("11111209-0000-0000-0000-000000000001")
   };
   private static final String MYTHIC_TOOL = "tiered:mythic_tool_1";
   private static final String MYTHIC_MELEE = "tiered:mythic_melee_1";
   private static final String MYTHIC_ARMOR = "tiered:mythic_armor_1";
   private static final int[] LIFESTEAL_PERCENT = new int[]{0, 5, 15, 25, 35, 45, 55, 63, 70, 78, 85};

   private RelicService() {
   }

   private static RelicService.Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
      String kindFilter = kindForSlot(type, slot);
      // 装备中也能升级（部位检索）：UI 部位语义 0=头盔..3=靴子，
      // 而 PlayerInventory.armor 索引 0=靴子(feet)..3=头盔(head)，物理槽需镜像映射 3-slot
      if (type == UpgradeDefinition.RelicType.BONE_ARMOR && slot >= 0 && slot < 4) {
         int armorIndex = 3 - slot;
         ItemStack worn = (ItemStack)player.getInventory().armor.get(armorIndex);
         if (isRelic(worn, type) && matchesKindFilter(worn, kindFilter)) {
            return new RelicService.Located(worn, 36 + armorIndex);
         }
      }

      // 装备中也能升级：通用检索（slot=-1）同样纳入装备栏中的骨甲，与 relicCount 统计口径保持一致
      if (type == UpgradeDefinition.RelicType.BONE_ARMOR && slot < 0) {
         for (int a = 0; a < player.getInventory().armor.size(); a++) {
            ItemStack wornArmor = (ItemStack)player.getInventory().armor.get(a);
            if (isRelic(wornArmor, type) && matchesKindFilter(wornArmor, kindFilter)) {
               return new RelicService.Located(wornArmor, 36 + a);
            }
         }
      }

      for (int i = 0; i < player.getInventory().main.size(); i++) {
         ItemStack stack = (ItemStack)player.getInventory().main.get(i);
         if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
            return new RelicService.Located(stack, i);
         }
      }

      ItemStack offHand = player.getOffHandStack();
      return isRelic(offHand, type) && matchesKindFilter(offHand, kindFilter) ? new RelicService.Located(offHand, 40) : null;
   }

   private static RelicService.Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
      return find(player, type, -1);
   }

   public static boolean anyRelic(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
      return find(player, type) != null;
   }

   private static boolean matchesKindFilter(ItemStack stack, String kindFilter) {
      return kindFilter == null ? true : stack.hasNbt() && kindFilter.equals(stack.getNbt().getCompound("bonefire_relics").getString("item"));
   }

   private static String kindForSlot(UpgradeDefinition.RelicType type, int slot) {
      if (type == UpgradeDefinition.RelicType.BONE_ARMOR && slot >= 0) {
         String[] slots = new String[]{"helmet", "chestplate", "leggings", "boots"};
         return "bone_" + slots[slot];
      } else {
         return null;
      }
   }

   private static int relicCount(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
      int count = 0;

      for (ItemStack stack : player.getInventory().main) {
         if (isRelic(stack, type)) {
            count++;
         }
      }

      for (ItemStack stackx : player.getInventory().armor) {
         if (isRelic(stackx, type)) {
            count++;
         }
      }

      if (isRelic(player.getOffHandStack(), type)) {
         count++;
      }

      return count;
   }

   private static int countBySlot(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
      String kindFilter = kindForSlot(type, slot);
      int count = 0;

      for (ItemStack stack : player.getInventory().main) {
         if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
            count++;
         }
      }

      if (type == UpgradeDefinition.RelicType.BONE_ARMOR && slot >= 0 && slot < 4) {
         int armorIndex = 3 - slot;
         ItemStack worn = (ItemStack)player.getInventory().armor.get(armorIndex);
         if (isRelic(worn, type) && matchesKindFilter(worn, kindFilter)) {
            count++;
         }
      }

      if (isRelic(player.getOffHandStack(), type) && matchesKindFilter(player.getOffHandStack(), kindFilter)) {
         count++;
      }

      return count;
   }

   public static boolean isAnyRelic(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else if (stack.isOf(ModItems.RELIC_GUIDE_BOOK)) {
         return true;
      } else if (stack.isOf(ModItems.RELIC_INFINITE_APPLE)) {
         return true;
      } else {
         return stack.hasNbt() && stack.getNbt().contains("bonefire_relics", 10)
            ? !stack.getNbt().getCompound("bonefire_relics").getString("item").isEmpty()
            : false;
      }
   }

   public static boolean isRelic(ItemStack stack, UpgradeDefinition.RelicType type) {
      return matchesRelic(stack, type, true);
   }

   /**
    * 只读判定（客户端界面专用，2026-09-13 体检）：判定口径与 isRelic 完全一致，
    * 但**不做旧档 NBT 修补** —— 客户端改写栈 NBT 会与服务端的权威副本产生分歧，
    * 而判定「是不是遗物」本就不应该有副作用（修补改由服务端在获得/升级等写路径完成）。
    */
   public static boolean isRelicReadOnly(ItemStack stack, UpgradeDefinition.RelicType type) {
      return matchesRelic(stack, type, false);
   }

   private static boolean matchesRelic(ItemStack stack, UpgradeDefinition.RelicType type, boolean repair) {
      if (!stack.isEmpty() && stack.hasNbt() && stack.getNbt().contains("bonefire_relics", 10)) {
         NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
         if (repair) {
            if (type == UpgradeDefinition.RelicType.BONE && matchesKind(data.getString("item"), type) && repairBoneDefaults(data)) {
               data = stack.getNbt().getCompound("bonefire_relics");
            }
            if (type == UpgradeDefinition.RelicType.AXE && matchesKind(data.getString("item"), type) && repairAxeDefaults(data)) {
               data = stack.getNbt().getCompound("bonefire_relics");
            }
         }
         return !data.contains("schema") ? isLegacyRelic(stack, type, data) : data.contains("schema", 3) && isCurrentRelic(stack, type, data);
      } else {
         return false;
      }
   }

   private static boolean repairBoneDefaults(NbtCompound data) {
      boolean touched = false;
      if (!data.contains("damage", 3)) {
         data.putInt("damage", 0);
         touched = true;
      }

      if (!data.contains("fire", 3)) {
         data.putInt("fire", 1);
         touched = true;
      }

      if (!data.contains("looting", 3)) {
         data.putInt("looting", 1);
         touched = true;
      }

      if (!data.contains("fortune", 3)) {
         data.putInt("fortune", 0);
         touched = true;
      }

      if (!data.contains("schema", 3)) {
         data.putInt("schema", 1);
         touched = true;
      }

      if (!data.contains("relic_id", 8)) {
         data.putString("relic_id", UUID.randomUUID().toString());
         touched = true;
      }

      return touched;
   }

   /** 骨斧旧档补默认并保证裂地 ≥1（裂地改为初始自带 1 级，2026-09-09）。 */
   private static boolean repairAxeDefaults(NbtCompound data) {
      boolean touched = false;
      if (!data.contains("efficiency", 3)) {
         data.putInt("efficiency", 1);
         touched = true;
      }

      if (!data.contains("fortune", 3)) {
         data.putInt("fortune", 1);
         touched = true;
      }

      if (!data.contains("damage", 3)) {
         data.putInt("damage", 0);
         touched = true;
      }

      int crack = data.getInt("explosion");
      if (crack < 1) {
         data.putInt("explosion", 1);
         touched = true;
      }

      if (!data.contains("armor", 3)) {
         data.putInt("armor", 0);
         touched = true;
      }

      if (!data.contains("schema", 3)) {
         data.putInt("schema", 1);
         touched = true;
      }

      if (!data.contains("relic_id", 8)) {
         data.putString("relic_id", UUID.randomUUID().toString());
         touched = true;
      }

      return touched;
   }

   private static boolean isCurrentRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
      if (data.getInt("schema") == 1 && matchesKind(data.getString("item"), type) && hasValidRelicId(data)) {
         int tier = data.getInt("tier");
         return isValidTier(type, tier) && hasValidState(type, data) && stack.isOf(itemFor(data.getString("item"), tier));
      } else {
         return false;
      }
   }

   private static boolean matchesKind(String kind, UpgradeDefinition.RelicType type) {
      return switch (type) {
         case PICKAXE -> kind.equals("pickaxe");
         case BONE -> kind.equals("bone");
         case BONE_ARMOR -> kind.equals("bone_helmet")
            || kind.equals("bone_chestplate")
            || kind.equals("bone_leggings")
            || kind.equals("bone_boots");
         case WAND -> kind.equals("magic_wand");
         case AXE -> kind.equals("bone_axe");
      };
   }

   private static boolean hasValidState(UpgradeDefinition.RelicType type, NbtCompound data) {
      return switch (type) {
         case PICKAXE -> between(data.getInt("efficiency"), 1, 5) && between(data.getInt("fortune"), 1, 10);
         case BONE -> between(data.getInt("damage"), 0, 41)
         && between(data.getInt("fire"), 1, 2)
         && between(data.getInt("looting"), 1, 10)
         && between(data.getInt("fortune"), 0, 10);
         case BONE_ARMOR -> between(data.getInt("efficiency"), 1, 5)
         && between(data.getInt("fortune"), 1, 10)
         && between(data.getInt("fire"), 1, 3)
         && between(data.getInt("looting"), 0, 3)
         && between(data.getInt("damage"), 0, 5)
         && between(data.getInt("armor"), 0, 50);
         case WAND -> between(data.getInt("spell"), 0, 30)
         && between(data.getInt("wfortune"), 0, 10)
         && between(data.getInt("explosion"), 0, 12);
         case AXE -> between(data.getInt("efficiency"), 1, 10)
         && between(data.getInt("fortune"), 1, 10)
         && between(data.getInt("damage"), 0, 32)
         && between(data.getInt("explosion"), 1, 10)
         && between(data.getInt("armor"), 0, 10);
      };
   }

   private static boolean between(int value, int min, int max) {
      return value >= min && value <= max;
   }

   static boolean hasValidRelicId(NbtCompound data) {
      if (!data.contains("relic_id", 8)) {
         return false;
      } else {
         try {
            UUID.fromString(data.getString("relic_id"));
            return true;
         } catch (IllegalArgumentException var2) {
            return false;
         }
      }
   }

   private static boolean isLegacyRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
      if (!data.contains("relic_id") && matchesKind(data.getString("item"), type)) {
         return switch (type) {
            case PICKAXE -> isLegacyPickaxe(stack, data) && between(data.getInt("efficiency"), 1, 5) && between(data.getInt("fortune"), 0, 10);
            case BONE -> stack.isOf(Items.BONE)
            && data.getInt("tier") == 0
            && between(data.getInt("damage"), 0, 41)
            && between(data.getInt("fire"), 1, 2)
            && between(data.getInt("looting"), 1, 10);
            case BONE_ARMOR -> false;
            case WAND -> false;
            case AXE -> false;
         };
      } else {
         return false;
      }
   }

   private static boolean isLegacyPickaxe(ItemStack stack, NbtCompound data) {
      return switch (data.getInt("tier")) {
         case 0 -> stack.isOf(Items.IRON_PICKAXE);
         case 1 -> stack.isOf(Items.DIAMOND_PICKAXE);
         case 2 -> stack.isOf(Items.NETHERITE_PICKAXE);
         default -> false;
      };
   }

   private static boolean isValidTier(UpgradeDefinition.RelicType type, int tier) {
      return switch (type) {
         case PICKAXE -> between(tier, 0, 6);
         case BONE -> tier == 0;
         case BONE_ARMOR -> between(tier, 0, 2);
         case WAND -> between(tier, 0, 1);
         // 骨斧与无尽铁镐共享 tier 槽位空间（0..6），材质升级仅到 3（下界合金），
         // 由镐转化的高 tier 数据仍视为合法，形态/加成按 min(tier,3) 解释。
         case AXE -> between(tier, 0, 6);
      };
   }

   public static int value(ItemStack stack, String key) {
      return stack != null && !stack.isEmpty() && stack.hasNbt() ? stack.getNbt().getCompound("bonefire_relics").getInt(key) : 0;
   }

   public static float lifestealPercent(int level) {
      if (level < 0) {
         level = 0;
      }

      if (level > 10) {
         level = 10;
      }

      return (float)LIFESTEAL_PERCENT[level] / 100.0F;
   }

   public static boolean meets(ItemStack stack, UpgradeDefinition.Requirement requirement) {
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      boolean wand = data.getString("item").equals("magic_wand");
      return (requirement.materialTier() < 0 || value(stack, "tier") == requirement.materialTier())
         && (requirement.efficiency() < 0 || value(stack, "efficiency") == requirement.efficiency())
         && (requirement.fortune() < 0 || value(stack, wand ? "wfortune" : "fortune") == requirement.fortune())
         && (requirement.fireAspect() < 0 || value(stack, "fire") == requirement.fireAspect())
         && (requirement.looting() < 0 || value(stack, "looting") == requirement.looting())
         && (requirement.boneDamage() < 0 || value(stack, "damage") == requirement.boneDamage())
         && (requirement.armor() < 0 || value(stack, wand ? "spell" : "armor") == requirement.armor())
         && (requirement.explosion() < 0 || value(stack, "explosion") == requirement.explosion());
   }

   public static int count(ServerPlayerEntity player, Item item) {
      int count = 0;

      for (ItemStack stack : player.getInventory().main) {
         if (stack.isOf(item)) {
            count += stack.getCount();
         }
      }

      if (player.getOffHandStack().isOf(item)) {
         count += player.getOffHandStack().getCount();
      }

      return count;
   }

   private static Map<Item, Integer> aggregateCosts(UpgradeDefinition definition) {
      Map<Item, Integer> totals = new HashMap<>();

      for (UpgradeDefinition.Cost cost : definition.costs()) {
         totals.merge(cost.item(), cost.count(), Integer::sum);
      }

      return totals;
   }

   public static boolean hasCosts(ServerPlayerEntity player, UpgradeDefinition definition) {
      for (Entry<Item, Integer> cost : aggregateCosts(definition).entrySet()) {
         if (count(player, cost.getKey()) < cost.getValue()) {
            return false;
         }
      }

      return true;
   }

   private static void remove(ServerPlayerEntity player, Item item, int required) {
      for (ItemStack stack : player.getInventory().main) {
         if (stack.isOf(item) && required > 0) {
            int taken = Math.min(required, stack.getCount());
            stack.decrement(taken);
            required -= taken;
         }
      }

      ItemStack offHand = player.getOffHandStack();
      if (required > 0 && offHand.isOf(item)) {
         offHand.decrement(Math.min(required, offHand.getCount()));
      }
   }

   private static void writeBack(ServerPlayerEntity player, RelicService.Located target, ItemStack output) {
      int index = target.inventorySlot();
      if (index == 40) {
         player.getInventory().offHand.set(0, output);
      } else if (index >= 36 && index <= 39) {
         player.getInventory().armor.set(index - 36, output);
      } else {
         player.getInventory().main.set(index, output);
      }
   }

   public static String tryUpgrade(ServerPlayerEntity player, String id, int slot) {
      UpgradeDefinition definition = UpgradeDefinition.byId(id);
      if (definition == null) {
         return "未知升级请求";
      } else if (definition.experienceLevels() >= 0 && definition.experienceLevels() <= 50) {
         boolean creative = player.getAbilities().creativeMode;
         RelicService.Located target = find(player, definition.relic(), slot);
         if (target == null) {
            return slot >= 0 ? "未在背包、副手或装备栏中找到对应部位的遗物" : "背包、副手或装备栏中未找到对应遗物";
         } else {
            if (definition.relic() == UpgradeDefinition.RelicType.BONE_ARMOR && definition.effect().armor() > 0) {
               int cap = armorCap(value(target.stack(), "tier"));
               if (definition.effect().armor() > cap) {
                  return "护甲上限不足：当前铸体（材质）上限 " + cap + "，需升级材质解锁（钻石铸体 30 / 合金铸体 50）";
               }
            }

            int sameCount = slot >= 0 ? countBySlot(player, definition.relic(), slot) : relicCount(player, definition.relic());
            if (sameCount != 1) {
               return "检测到多件同类遗物；请暂时只保留要升级的一件";
            } else if (!meets(target.stack(), definition.requirement())) {
               return "遗物当前等级不满足此前置条件";
            } else {
               if (!creative) {
                  if (!hasCosts(player, definition)) {
                     return "材料不足；未扣除任何材料或经验";
                  }

                  if (player.experienceLevel < definition.experienceLevels()) {
                     return "经验等级不足；未扣除任何材料或经验";
                  }
               }

               if (!creative) {
                  for (UpgradeDefinition.Cost cost : definition.costs()) {
                     remove(player, cost.item(), cost.count());
                  }

                  if (definition.experienceLevels() > 0) {
                     player.addExperienceLevels(-definition.experienceLevels());
                  }
               }

               ItemStack output = upgradedCopy(target.stack(), definition.effect());
               writeBack(player, target, output);
               player.getInventory().markDirty();
               player.playerScreenHandler.sendContentUpdates();
               ArmorOvercapHandler.onUpgradeApplied(player);
               return "升级成功：" + definition.title() + "（消耗 " + definition.experienceLevels() + " 级经验）";
            }
         }
      } else {
         return "升级配置的经验成本非法；未扣除任何内容";
      }
   }

   public static String tryMaxUpgrade(ServerPlayerEntity player, String id, int slot) {
      if (!player.getAbilities().creativeMode) {
         return "一键满级仅创造模式可用";
      } else {
         UpgradeDefinition definition = UpgradeDefinition.byId(id);
         if (definition == null) {
            return "未知升级请求";
         } else {
            RelicService.Located target = find(player, definition.relic(), slot);
            if (target == null) {
               return slot >= 0 ? "未在背包、副手或装备栏中找到对应部位的遗物" : "背包、副手或装备栏中未找到对应遗物";
            } else {
               int sameCount = slot >= 0 ? countBySlot(player, definition.relic(), slot) : relicCount(player, definition.relic());
               if (sameCount != 1) {
                  return "检测到多件同类遗物；请暂时只保留要升级的一件";
               } else {
                  UpgradeDefinition.Effect maxEffect = maxEffectFor(definition, target.stack());
                  if (maxEffect == null) {
                     return "无法解析满级目标";
                  } else if (isAlreadyMax(target.stack(), maxEffect)) {
                     return "该项已满级";
                  } else {
                     ItemStack output = upgradedCopy(target.stack(), maxEffect);
                     writeBack(player, target, output);
                     player.getInventory().markDirty();
                     player.playerScreenHandler.sendContentUpdates();
                     ArmorOvercapHandler.onUpgradeApplied(player);
                     return "创造模式一键满级：" + definition.title() + " 已拉满";
                  }
               }
            }
         }
      }
   }

   /**
    * 一键满级（全部）：把身上**所有遗物**（背包 + 副手 + 装备栏）替换为满级版本。
    * 与升级界面里的单项「满级」按钮同源，口径改为「全部」；配合创造模式后门计入任务书。
    * @return 实际被拉满的件数
    */
   public static int maxAllCarried(ServerPlayerEntity player) {
      int count = 0;
      PlayerInventory inventory = player.getInventory();
      for (int i = 0; i < inventory.size(); i++) {
         ItemStack stack = inventory.getStack(i);
         if (stack.isEmpty() || !isAnyRelic(stack)) {
            continue;
         }
         ItemStack maxed = maxedCopy(stack);
         if (!maxed.isEmpty() && !ItemStack.areEqual(maxed, stack)) {
            inventory.setStack(i, maxed);
            count++;
         }
      }
      if (count > 0) {
         inventory.markDirty();
         player.playerScreenHandler.sendContentUpdates();
         ArmorOvercapHandler.onUpgradeApplied(player);
      }
      return count;
   }

   /**
    * 生成一件遗物的**满级版本**（遍历该遗物全部升级路线，套用满级效果；服务端通用，不要求创造模式）。
    * 用于开局礼包 / 发放命令；骨甲法强与超限属性由 ArmorOvercapHandler 在持有或穿戴时刷新。
    */
   public static ItemStack maxedCopy(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return ItemStack.EMPTY;
      }
      ItemStack result = stack.copy();
      int guard = 0;
      boolean changed = true;
      while (changed && guard++ < 64) {
         changed = false;
         for (UpgradeDefinition definition : UpgradeDefinition.all()) {
            if (!isRelic(result, definition.relic())) {
               continue;
            }
            UpgradeDefinition.Effect max = maxEffectFor(definition, result);
            if (max != null && !isAlreadyMax(result, max)) {
               result = upgradedCopy(result, max);
               changed = true;
            }
         }
      }
      return result;
   }

   private static UpgradeDefinition.Effect maxEffectFor(UpgradeDefinition definition, ItemStack stack) {
      UpgradeDefinition.Effect e = definition.effect();
      UpgradeDefinition.RelicType type = definition.relic();
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      boolean wand = data.getString("item").equals("magic_wand");
      if (e.materialTier() >= 0) {
         return switch (type) {
            case PICKAXE -> new UpgradeDefinition.Effect(6, -1, -1, -1, -1, -1, -1, -1);
            case BONE_ARMOR -> new UpgradeDefinition.Effect(2, -1, -1, -1, -1, -1, -1, -1);
            case WAND -> new UpgradeDefinition.Effect(1, -1, -1, -1, -1, -1, -1, -1);
            case AXE -> new UpgradeDefinition.Effect(2, -1, -1, -1, -1, -1, -1, -1);
            default -> null;
         };
      } else if (e.efficiency() >= 0) {
         int cap = type == UpgradeDefinition.RelicType.AXE ? 10 : 5;
         return new UpgradeDefinition.Effect(-1, cap, -1, -1, -1, -1, -1, -1);
      } else if (e.fortune() >= 0) {
         return new UpgradeDefinition.Effect(-1, -1, 10, -1, -1, -1, -1, -1);
      } else if (e.fireAspect() >= 0) {
         int cap = type == UpgradeDefinition.RelicType.BONE ? 2 : 3;
         return new UpgradeDefinition.Effect(-1, -1, -1, cap, -1, -1, -1, -1);
      } else if (e.looting() >= 0 && e.boneDamage() >= 0) {
         return new UpgradeDefinition.Effect(-1, -1, -1, -1, e.looting(), 5, -1, -1);
      } else if (e.looting() >= 0) {
         return new UpgradeDefinition.Effect(-1, -1, -1, -1, 10, -1, -1, -1);
      } else if (e.boneDamage() >= 0) {
         int cap = type == UpgradeDefinition.RelicType.AXE ? 32 : 41;
         return new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, cap, -1, -1);
      } else if (e.armor() >= 0) {
         return switch (type) {
            case AXE -> new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, -1, 10, -1);
            case WAND -> new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, -1, 30, -1);
            default -> new UpgradeDefinition.Effect(2, -1, -1, -1, -1, -1, 50, -1);
         };
      } else if (e.explosion() >= 0) {
         int cap = data.getString("item").equals("magic_wand") && data.getInt("tier") == 1 ? 12 : 10;
         return new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, -1, -1, cap);
      } else {
         return null;
      }
   }

   private static boolean isAlreadyMax(ItemStack stack, UpgradeDefinition.Effect effect) {
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      boolean wand = data.getString("item").equals("magic_wand");
      boolean family = effect.looting() >= 0 && effect.boneDamage() >= 0;
      if (effect.materialTier() >= 0 && data.getInt("tier") < effect.materialTier()) {
         return false;
      } else if (!family && effect.efficiency() >= 0 && data.getInt("efficiency") < effect.efficiency()) {
         return false;
      } else if (!family && effect.fortune() >= 0 && data.getInt(wand ? "wfortune" : "fortune") < effect.fortune()) {
         return false;
      } else if (!family && effect.fireAspect() >= 0 && data.getInt("fire") < effect.fireAspect()) {
         return false;
      } else if (!family && effect.looting() >= 0 && data.getInt("looting") < effect.looting()) {
         return false;
      } else if (effect.boneDamage() >= 0 && data.getInt("damage") < effect.boneDamage()) {
         return false;
      } else {
         return !family && effect.armor() >= 0 && data.getInt(wand ? "spell" : "armor") < effect.armor()
            ? false
            : family || effect.explosion() < 0 || data.getInt("explosion") >= effect.explosion();
      }
   }

   private static void applyMythic(ItemStack stack, String tierId) {
      NbtCompound tiered = stack.getOrCreateSubNbt("Tiered");
      if (!tiered.contains("Tier", 8)) {
         tiered.putString("Tier", tierId);
      }

      try {
         Class<?> modifierUtils = Class.forName("draylar.tiered.api.ModifierUtils");
         Method setAttr = modifierUtils.getMethod("setItemStackAttribute", Identifier.class, ItemStack.class);
         setAttr.invoke(null, new Identifier(tierId), stack);
      } catch (Throwable var5) {
      }
   }

   private static ItemStack upgradedCopy(ItemStack old, UpgradeDefinition.Effect effect) {
      NbtCompound data = old.getNbt().getCompound("bonefire_relics").copy();
      if (!data.contains("relic_id", 8)) {
         data.putString("relic_id", UUID.randomUUID().toString());
      }

      data.putInt("schema", 1);
      int previousTier = data.getInt("tier");
      put(data, "tier", effect.materialTier());
      put(data, "efficiency", effect.efficiency());
      put(data, "fortune", effect.fortune());
      put(data, "fire", effect.fireAspect());
      put(data, "looting", effect.looting());
      put(data, "damage", effect.boneDamage());
      // 裂地（explosion）为法杖与骨斧共有槽位：必须放在物品分支之外统一写入
      // （此前仅在 magic_wand 分支写 → 骨斧裂地升级永远写不进去，卡在 1 级）
      if (effect.explosion() >= 0) {
         data.putInt("explosion", effect.explosion());
      }

      if (data.getString("item").equals("magic_wand")) {
         if (effect.armor() >= 0) {
            data.putInt("spell", effect.armor());
         }

         if (effect.fortune() >= 0) {
            data.putInt("wfortune", effect.fortune());
         }

         put(data, "armor", -1);
      } else {
         put(data, "armor", effect.armor());
         if (effect.materialTier() >= 0 && matchesKind(data.getString("item"), UpgradeDefinition.RelicType.BONE_ARMOR)) {
            int gainedTier = effect.materialTier() - previousTier;
            if (gainedTier > 0) {
               data.putInt("armor", Math.min(data.getInt("armor") + 5 * gainedTier, 50));
            }
         }
      }

      NbtCompound tiered = old.getSubNbt("Tiered");
      ItemStack output = new ItemStack(itemFor(data.getString("item"), data.getInt("tier")));
      output.getOrCreateNbt().put("bonefire_relics", data);
      if (tiered != null) {
         output.getOrCreateNbt().put("Tiered", tiered.copy());
      }

      refreshStack(output);
      if (tiered != null && tiered.contains("Tier", 8)) {
         applyMythic(output, tiered.getString("Tier"));
      }

      return output;
   }

   private static void put(NbtCompound nbt, String key, int value) {
      if (value >= 0) {
         nbt.putInt(key, value);
      }
   }

   private static Item itemFor(String kind, int tier) {
      return switch (kind) {
         case "pickaxe" -> pickaxeFor(tier);
         case "bone" -> ModItems.RELIC_BONE;
         case "bone_helmet" -> boneArmorFor(tier, 0);
         case "bone_chestplate" -> boneArmorFor(tier, 1);
         case "bone_leggings" -> boneArmorFor(tier, 2);
         case "bone_boots" -> boneArmorFor(tier, 3);
         case "magic_wand" -> ModItems.MAGIC_WAND;
         case "bone_axe" -> axeFor(tier);
         default -> Items.AIR;
      };
   }

   private static Item axeFor(int tier) {
      return switch (Math.min(tier, 2)) {
         case 1 -> ModItems.RELIC_BONE_AXE_DIAMOND;
         case 2 -> ModItems.RELIC_BONE_AXE_NETHERITE;
         default -> ModItems.RELIC_BONE_AXE;
      };
   }

   private static Item pickaxeFor(int tier) {
      return switch (tier) {
         case 0 -> ModItems.RELIC_IRON_PICKAXE;
         case 1 -> ModItems.RELIC_DIAMOND_PICKAXE;
         case 2 -> ModItems.RELIC_NETHERITE_PICKAXE;
         case 3 -> ModItems.RELIC_NETHERITE_IRON_PICKAXE;
         case 4 -> ModItems.RELIC_NETHERITE_GOLD_PICKAXE;
         case 5 -> ModItems.RELIC_NETHERITE_EMERALD_PICKAXE;
         default -> ModItems.RELIC_NETHERITE_DIAMOND_PICKAXE;
      };
   }

   private static Item boneArmorFor(int tier, int slot) {
      return switch (tier) {
         case 1 -> {
            switch (slot) {
               case 0:
                  yield ModItems.RELIC_BONE_DIAMOND_HELMET;
               case 1:
                  yield ModItems.RELIC_BONE_DIAMOND_CHESTPLATE;
               case 2:
                  yield ModItems.RELIC_BONE_DIAMOND_LEGGINGS;
               default:
                  yield ModItems.RELIC_BONE_DIAMOND_BOOTS;
            }
         }
         case 2 -> {
            switch (slot) {
               case 0:
                  yield ModItems.RELIC_BONE_NETHERITE_HELMET;
               case 1:
                  yield ModItems.RELIC_BONE_NETHERITE_CHESTPLATE;
               case 2:
                  yield ModItems.RELIC_BONE_NETHERITE_LEGGINGS;
               default:
                  yield ModItems.RELIC_BONE_NETHERITE_BOOTS;
            }
         }
         default -> {
            switch (slot) {
               case 0:
                  yield ModItems.RELIC_BONE_HELMET;
               case 1:
                  yield ModItems.RELIC_BONE_CHESTPLATE;
               case 2:
                  yield ModItems.RELIC_BONE_LEGGINGS;
               default:
                  yield ModItems.RELIC_BONE_BOOTS;
            }
         }
      };
   }

   public static void refreshStack(ItemStack stack) {
      NbtCompound root = stack.getOrCreateNbt();
      NbtCompound data = root.getCompound("bonefire_relics");
      root.putBoolean("Unbreakable", true);
      String kind = data.getString("item");
      Map<Enchantment, Integer> enchantments = new HashMap<>();
      if (kind.equals("pickaxe")) {
         int efficiency = data.getInt("efficiency");
         int fortune = data.getInt("fortune");
         if (efficiency > 0) {
            enchantments.put(Enchantments.EFFICIENCY, efficiency);
         }

         if (fortune > 0) {
            enchantments.put(Enchantments.FORTUNE, fortune);
         }
      } else if (kind.equals("bone")) {
         int fire = data.getInt("fire");
         int looting = data.getInt("looting");
         if (fire > 0) {
            enchantments.put(Enchantments.FIRE_ASPECT, fire);
         }

         if (looting > 0) {
            enchantments.put(Enchantments.LOOTING, looting);
         }

         stack.addAttributeModifier(
            EntityAttributes.GENERIC_ATTACK_DAMAGE,
            new EntityAttributeModifier(BONE_DAMAGE_UUID, "bonefire_relics_bone_damage", 9.0 + (double)data.getInt("damage"), Operation.ADDITION),
            EquipmentSlot.MAINHAND
         );
      } else if (kind.equals("bone_axe")) {
         int axeEfficiency = data.getInt("efficiency");
         int axeFortune = data.getInt("fortune");
         if (axeEfficiency > 0) {
            enchantments.put(Enchantments.EFFICIENCY, axeEfficiency);
         }

         if (axeFortune > 0) {
            enchantments.put(Enchantments.FORTUNE, axeFortune);
         }

         int axeTier = Math.min(data.getInt("tier"), 2);
         stack.addAttributeModifier(
            EntityAttributes.GENERIC_ATTACK_DAMAGE,
            new EntityAttributeModifier(
               BONE_AXE_DAMAGE_UUID, "bonefire_relics_bone_axe_damage", 8.0 + (double)(axeTier * 5) + (double)data.getInt("damage"), Operation.ADDITION
            ),
            EquipmentSlot.MAINHAND
         );
      } else if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
         int protection = data.getInt("efficiency");
         int thorns = data.getInt("fire");
         int ptype = data.getInt("looting");
         int plevel = data.getInt("damage");
         int toughness = data.getInt("fortune");
         if (protection > 0) {
            enchantments.put(Enchantments.PROTECTION, protection);
         }

         if (thorns > 0) {
            enchantments.put(Enchantments.THORNS, thorns);
         }

         if (ptype > 0 && plevel > 0) {
            enchantments.put(protectionFamily(ptype), plevel);
         }

         int slotIndex = armorSlotIndex(kind);
         if (toughness > 0) {
            stack.addAttributeModifier(
               EntityAttributes.GENERIC_ARMOR_TOUGHNESS,
               new EntityAttributeModifier(ARMOR_TOUGHNESS_UUIDS[slotIndex], "bonefire_relics_armor_toughness", (double)toughness, Operation.ADDITION),
               armorSlot(kind)
            );
         }

         int armor = data.getInt("armor");
         if (armor > 0) {
            stack.addAttributeModifier(
               EntityAttributes.GENERIC_ARMOR,
               new EntityAttributeModifier(ARMOR_VALUE_UUIDS[slotIndex], "bonefire_relics_armor_value", (double)armor, Operation.ADDITION),
               armorSlot(kind)
            );
         }

         // 骨甲法术强度（成长型）：基础 5 + 材质级×5（tier0=5 / tier1=10 / tier2=15），
         // 火/冰/奥三系同步（spell_power 缺失自动跳过 —— 服务端环境守卫）
         if (net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("spell_power")) {
            int boneArmorSpellPower = 5 + Math.min(data.getInt("tier"), 2) * 5;
            EquipmentSlot powerSlot = armorSlot(kind);
            stack.addAttributeModifier(
               net.spell_power.api.SpellSchools.FIRE.attribute,
               new EntityAttributeModifier(RelicBoneArmorItem.FIRE_POWER_UUID, "bonefire_relics_bone_armor_fire_power", (double)boneArmorSpellPower, Operation.ADDITION),
               powerSlot
            );
            stack.addAttributeModifier(
               net.spell_power.api.SpellSchools.FROST.attribute,
               new EntityAttributeModifier(RelicBoneArmorItem.FROST_POWER_UUID, "bonefire_relics_bone_armor_frost_power", (double)boneArmorSpellPower, Operation.ADDITION),
               powerSlot
            );
            stack.addAttributeModifier(
               net.spell_power.api.SpellSchools.ARCANE.attribute,
               new EntityAttributeModifier(RelicBoneArmorItem.ARCANE_POWER_UUID, "bonefire_relics_bone_armor_arcane_power", (double)boneArmorSpellPower, Operation.ADDITION),
               powerSlot
            );
         }
      }

      EnchantmentHelper.set(enchantments, stack);
      if (!usesFireTwoModel(data) && !usesSoulModel(data)) {
         root.remove("CustomModelData");
      } else {
         root.putInt("CustomModelData", 1);
      }

      stack.setCustomName(
         Text.literal(displayName(kind, data.getInt("tier"), data)).formatted(nameColor(kind, data.getInt("tier"), data))
      );
      writeLore(root, loreLines(kind, data.getInt("tier"), data));
   }

   private static Enchantment protectionFamily(int ptype) {
      return switch (ptype) {
         case 1 -> Enchantments.FIRE_PROTECTION;
         case 2 -> Enchantments.BLAST_PROTECTION;
         default -> Enchantments.PROJECTILE_PROTECTION;
      };
   }

   private static EquipmentSlot armorSlot(String kind) {
      if (kind.endsWith("_helmet")) {
         return EquipmentSlot.HEAD;
      } else if (kind.endsWith("_chestplate")) {
         return EquipmentSlot.CHEST;
      } else {
         return kind.endsWith("_leggings") ? EquipmentSlot.LEGS : EquipmentSlot.FEET;
      }
   }

   private static int armorSlotIndex(String kind) {
      if (kind.endsWith("_helmet")) {
         return 0;
      } else if (kind.endsWith("_chestplate")) {
         return 1;
      } else {
         return kind.endsWith("_leggings") ? 2 : 3;
      }
   }

   static boolean usesFireTwoModel(NbtCompound data) {
      return "bone".equals(data.getString("item")) && data.getInt("fire") == 2;
   }

   static boolean usesSoulModel(NbtCompound data) {
      return "magic_wand".equals(data.getString("item")) && data.getInt("tier") == 1;
   }

   private static Formatting nameColor(String kind, int tier, NbtCompound data) {
      if (kind.equals("bone_axe")) {
         return tier >= 2 ? Formatting.GOLD : (tier == 1 ? Formatting.LIGHT_PURPLE : Formatting.WHITE);
      } else if (kind.equals("bone")) {
         int damage = data.getInt("damage");
         return damage >= 21 ? Formatting.DARK_PURPLE : (damage >= 6 ? Formatting.RED : Formatting.GOLD);
      } else if (kind.equals("magic_wand")) {
         return tier == 1 ? Formatting.AQUA : Formatting.WHITE;
      } else if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
         return tier >= 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE);
      } else {
         return tier >= 6
            ? Formatting.DARK_PURPLE
            : (tier >= 3 ? Formatting.LIGHT_PURPLE : (tier == 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE)));
      }
   }

   private static String displayName(String kind, int tier, NbtCompound data) {
      if (kind.equals("bone_axe")) {
         return switch (Math.min(tier, 2)) {
            case 1 -> "钻石骨斧";
            case 2 -> "下界合金骨斧";
            default -> data.getInt("explosion") >= 1 ? "裂地骨斧" : "骨斧";
         };
      } else if (kind.equals("bone")) {
         if (data.getInt("fire") == 2) {
            return "蚀炎魂骨";
         } else if (data.getInt("damage") >= 21) {
            return "噬魂龙骨";
         } else if (data.getInt("looting") >= 6) {
            return "贪猎魂骨";
         } else {
            return data.getInt("damage") >= 6 ? "裂杀号骨" : "战利魂骨";
         }
      } else if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
         String slotName = armorSlotName(kind);

         return switch (tier) {
            case 1 -> "钻石骨甲·" + slotName;
            case 2 -> "下界合金骨甲·" + slotName;
            default -> "遗物骨甲·" + slotName;
         };
      } else if (kind.equals("magic_wand")) {
         return tier == 1 ? "下界灵魂之杖" : "遗物法杖";
      } else {
         return switch (tier) {
            case 1 -> "星辉钻镐";
            case 2 -> "永恒下界镐";
            case 3 -> "下界合金·铁镐";
            case 4 -> "下界合金·金镐";
            case 5 -> "下界合金·绿宝石镐";
            case 6 -> "下界合金·钻石镐";
            default -> data.getInt("fortune") >= 6 ? "寻脉铁镐" : (data.getInt("efficiency") >= 4 ? "迅凿铁镐" : "无尽铁镐");
         };
      }
   }

   private static String armorSlotName(String kind) {
      if (kind.endsWith("_helmet")) {
         return "头盔";
      } else if (kind.endsWith("_chestplate")) {
         return "胸甲";
      } else {
         return kind.endsWith("_leggings") ? "护腿" : "靴子";
      }
   }

   private static List<String> loreLines(String kind, int tier, NbtCompound data) {
      ArrayList<String> lines = new ArrayList<>();
      lines.add("{\"text\":\"遗物成长 · 不可破坏\",\"color\":\"gray\",\"italic\":false}");
      if (kind.equals("bone")) {
         lines.add("{\"text\":\"主手额外攻击伤害：+" + (9 + data.getInt("damage")) + "\",\"color\":\"gold\",\"italic\":false}");
         lines.add("{\"text\":\"火焰附加：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
         lines.add("{\"text\":\"处决：攻击时 1.2% 概率直接移除目标（无视血量与减伤，必定死亡）\",\"color\":\"light_purple\",\"italic\":false}");

         lines.add("{\"text\":\"抢夺：" + roman(data.getInt("looting")) + "\",\"color\":\"green\",\"italic\":false}");
         int lifesteal = data.getInt("fortune");
         if (lifesteal > 0) {
            lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(lifesteal) * 100.0F) + "%\",\"color\":\"dark_red\",\"italic\":false}");
         }

         lines.add("{\"text\":\"骨火：每命中3次 → 对最近至多3只怪物造成火焰魔法伤害（基础8，攻击每+1伤害+1，上限20）\",\"color\":\"gold\",\"italic\":false}");
         if (9 + data.getInt("damage") >= 20) {
            lines.add("{\"text\":\"骨裂：攻击力≥20 后每次攻击附加 8% 目标当前生命值伤害\",\"color\":\"light_purple\",\"italic\":false}");
         }
      } else if (kind.equals("pickaxe")) {
         lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
         lines.add("{\"text\":\"效率：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
         lines.add("{\"text\":\"时运：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
         lines.add("{\"text\":\"补给：每挖掘150个方块 → 「补给」5秒（每秒恢复1饥饿值+1饱食度）\",\"color\":\"gold\",\"italic\":false}");
      } else if (kind.equals("magic_wand")) {
         int spell = data.getInt("spell");
         boolean soul = tier == 1;
         lines.add("{\"text\":\"法术强度：" + spell + "/30\",\"color\":\"aqua\",\"italic\":false}");
         int explosion = data.getInt("explosion");
         int baseDamage = soul ? 15 : 10;
         lines.add(
            "{\"text\":\"火球：左键攻击释放直线火球，命中任意生物即爆炸（不破坏方块），伤害 "
               + (baseDamage + spell)
               + " 点魔法伤害"
               + (soul ? "（上限45）" : "")
               + "\",\"color\":\"gold\",\"italic\":false}"
         );
         if (explosion > 0) {
            lines.add(
               "{\"text\":\"爆炸：命中后对周围怪物造成 "
                  + (int)(5.0 + (double)explosion * 0.5)
                  + " 点范围魔法伤害"
                  + (soul ? "（最高XII级）" : "")
                  + "\",\"color\":\"red\",\"italic\":false}"
            );
         }

         if (soul) {
            lines.add("{\"text\":\"灵魂蓝焰：火球化为灵魂之火，命中附加凋零 II（5秒）\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"灵魂爆裂：击杀目标后爆炸并传播凋零效果\",\"color\":\"light_purple\",\"italic\":false}");
            lines.add("{\"text\":\"暴击：35% 概率造成双倍伤害\",\"color\":\"red\",\"italic\":false}");
         }

         lines.add(
            "{\"text\":\"连击：每次攻击 "
               + (int)(Math.min((soul ? 0.3 : 0.1) + (double)spell * 0.01, soul ? 0.45 : 0.3) * 100.0)
               + "% 概率额外攻击一次（每点法术强度+1%"
               + (soul ? "，基础30%，上限45%" : "，上限30%")
               + "）\",\"color\":\"light_purple\",\"italic\":false}"
         );
         if (spell >= 15) {
            lines.add("{\"text\":\"火罚：附加目标当前生命值 5% 伤害\",\"color\":\"dark_red\",\"italic\":false}");
         }

         int wls = data.getInt("wfortune");
         if (wls > 0) {
            lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(wls) * 100.0F) + "%\",\"color\":\"dark_red\",\"italic\":false}");
         }
      } else if (kind.equals("bone_axe")) {
         int axeTier = Math.min(tier, 2);
         int axeDamage = 8 + axeTier * 5 + data.getInt("damage");
         lines.add("{\"text\":\"材质：" + axeStage(axeTier) + "\",\"color\":\"aqua\",\"italic\":false}");
         lines.add("{\"text\":\"主手攻击伤害：" + axeDamage + "（最高 50）\",\"color\":\"gold\",\"italic\":false}");
         lines.add("{\"text\":\"攻速 10 · 无法破坏\",\"color\":\"gray\",\"italic\":false}");
         lines.add("{\"text\":\"效率：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
         lines.add("{\"text\":\"时运：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
         lines.add("{\"text\":\"处决：攻击时 1.2% 概率直接移除目标（无视血量与减伤，必定死亡）\",\"color\":\"light_purple\",\"italic\":false}");
         int axeVampire = data.getInt("armor");
         if (axeVampire > 0) {
            lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(axeVampire) * 100.0F) + "%\",\"color\":\"dark_red\",\"italic\":false}");
         }

         lines.add("{\"text\":\"血涌：普通攻击命中使目标流血（每秒掉 1.2% 当前生命 × 5 秒，真伤）\",\"color\":\"red\",\"italic\":false}");
         int crack = data.getInt("explosion");
         if (crack > 0) {
            int waveBase = Math.min(10 + (crack - 1) * 8, 80);
            double triggerPct = 10.0 - (double)(crack - 1) * (5.0 / 9.0);
            String triggerText = crack >= 10 ? "5%" : String.format(java.util.Locale.ROOT, "%.1f%%", triggerPct);
            lines.add(
               "{\"text\":\"裂地 Lv" + roman(crack)
                  + "：普通攻击对目标累计伤害达其最大生命 " + triggerText
                  + " → 触发三道冲击波（正前/左45°/右45°·穿墙·6 格）\",\"color\":\"gold\",\"italic\":false}"
            );
            lines.add(
               "{\"text\":\"冲击波真伤：基础 " + waveBase + " + 目标当前生命 5%\",\"color\":\"dark_red\",\"italic\":false}"
            );
         }
      } else {
         lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
         lines.add("{\"text\":\"护甲值：+" + data.getInt("armor") + "\",\"color\":\"gray\",\"italic\":false}");
         lines.add("{\"text\":\"保护：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
         lines.add("{\"text\":\"韧性：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
         lines.add("{\"text\":\"荆棘：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
         int ptype = data.getInt("looting");
         int plevel = data.getInt("damage");
         if (ptype > 0 && plevel > 0) {
            lines.add("{\"text\":\"" + protectionFamilyName(ptype) + "：" + roman(plevel) + "\",\"color\":\"light_purple\",\"italic\":false}");
         }

         lines.add("{\"text\":\"护甲超限：穿戴≥2件骨甲且全身护甲超 40 点后，每 1 点 = 1% 全面减伤 + 1% 最大生命 + 1% 法术抗性\",\"color\":\"gold\",\"italic\":false}");
         lines.add("{\"text\":\"铸体（材质）护甲上限：" + armorCap(data.getInt("tier")) + "（钻石铸体 30 / 合金铸体 50）\",\"color\":\"aqua\",\"italic\":false}");
         lines.add("{\"text\":\"骨甲护体：单次受击≥80%最大生命 或 20秒内累计≥200% → 抗性+生命恢复5秒\",\"color\":\"gold\",\"italic\":false}");
         int armorSpellBonus = 5 + Math.min(tier, 2) * 5;
         lines.add("{\"text\":\"法术强度：火/冰/奥 +" + armorSpellBonus + "（成长型：基础 5 + 材质每级 +5）\",\"color\":\"aqua\",\"italic\":false}");
      }

      lines.add("{\"text\":\"服务器校验升级\",\"color\":\"dark_gray\",\"italic\":false}");
      return lines;
   }

   public static int armorCap(int tier) {
      return tier >= 2 ? 50 : (tier == 1 ? 30 : 20);
   }

   private static String protectionFamilyName(int ptype) {
      return switch (ptype) {
         case 1 -> "火焰保护";
         case 2 -> "爆炸保护";
         default -> "弹射物保护";
      };
   }

   private static String roman(int value) {
      return switch (value) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> Integer.toString(value);
      };
   }

   private static String toolStage(int tier) {
      return switch (tier) {
         case 1 -> "钻石覆层";
         case 2 -> "下界合金铸体";
         case 3 -> "下界合金·铁";
         case 4 -> "下界合金·金";
         case 5 -> "下界合金·绿宝石";
         case 6 -> "下界合金·钻石";
         default -> "铁质遗物";
      };
   }

   /** 骨斧材质阶段（0 骨=对标铁 / 1 钻石 / 2+ 下界合金）。 */
   private static String axeStage(int tier) {
      return switch (Math.min(tier, 2)) {
         case 1 -> "钻石";
         default -> tier >= 2 ? "下界合金" : "骨（铁级）";
      };
   }

   private static void writeLore(NbtCompound root, List<String> lines) {
      NbtCompound display = root.contains("display", 10) ? root.getCompound("display") : new NbtCompound();
      NbtList lore = new NbtList();

      for (String line : lines) {
         lore.add(NbtString.of(line));
      }

      display.put("Lore", lore);
      root.put("display", display);
   }

   private static ItemStack newRelic(String kind, int tier) {
      ItemStack stack = new ItemStack(itemFor(kind, tier));
      NbtCompound data = new NbtCompound();
      data.putInt("schema", 1);
      data.putString("relic_id", UUID.randomUUID().toString());
      data.putString("item", kind);
      data.putInt("tier", tier);
      stack.getOrCreateNbt().put("bonefire_relics", data);
      return stack;
   }

   public static ItemStack initialPickaxe() {
      ItemStack stack = newRelic("pickaxe", 0);
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      data.putInt("efficiency", 1);
      data.putInt("fortune", 1);
      refreshStack(stack);
      applyMythic(stack, "tiered:mythic_tool_1");
      return stack;
   }

   public static ItemStack initialWand() {
      ItemStack stack = newRelic("magic_wand", 0);
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      data.putInt("spell", 0);
      data.putInt("fortune", 0);
      data.putInt("explosion", 0);
      refreshStack(stack);
      applyMythic(stack, "tiered:mythic_melee_1");
      return stack;
   }

   public static String switchRelic(ServerPlayerEntity player) {
      return switchRelic(player, 0);
   }

   /** pairCode：0=骨头⇄法杖；1=无尽铁镐⇄骨斧。 */
   public static String switchRelic(ServerPlayerEntity player, int pairCode) {
      RelicService.KindPair pair = pairCode == 1 ? RelicService.KindPair.PICKAXE_AXE : RelicService.KindPair.BONE_WAND;
      RelicService.Located target = null;
      List<UpgradeDefinition.RelicType> pairTypes = pair == RelicService.KindPair.PICKAXE_AXE
         ? List.of(UpgradeDefinition.RelicType.PICKAXE, UpgradeDefinition.RelicType.AXE)
         : List.of(UpgradeDefinition.RelicType.BONE, UpgradeDefinition.RelicType.WAND);

      if (pair == RelicService.KindPair.PICKAXE_AXE) {
         // 修复历史“非法”切形态坏档：斧高效率切镐后 eff>5、或镐切斧缺裂地级(explosion<1)
         for (ItemStack stack : player.getInventory().main) {
            if (stack.isEmpty() || !stack.hasNbt() || !stack.getNbt().contains("bonefire_relics", 10)) {
               continue;
            }
            NbtCompound d = stack.getNbt().getCompound("bonefire_relics");
            String k = d.getString("item");
            if (k.equals("pickaxe")) {
               if (d.getInt("efficiency") > 5) {
                  d.putInt("efficiency", 5);
               }
            } else if (k.equals("bone_axe") && d.getInt("explosion") < 1) {
               d.putInt("explosion", 1);
            }
         }
      }

      for (UpgradeDefinition.RelicType type : pairTypes) {
         RelicService.Located loc = find(player, type);
         if (loc != null) {
            target = loc;
            break;
         }
      }

      if (target == null) {
         return pair == RelicService.KindPair.PICKAXE_AXE ? "背包中未找到 无尽铁镐/骨斧，无法切换" : "背包中未找到 骨头/法杖，无法切换";
      } else {
         NbtCompound data = target.stack().getNbt().getCompound("bonefire_relics");
         String kind = data.getString("item");
         String msg;
         String newKind;
         if (pair == RelicService.KindPair.BONE_WAND) {
            if (kind.equals("bone")) {
               newKind = "magic_wand";
               msg = "已切换为：遗物法杖";
               if (data.contains("soul", 3)) {
                  data.putInt("tier", data.getInt("soul"));
                  data.remove("soul");
               }
            } else {
               if (!kind.equals("magic_wand")) {
                  return "未知遗物，无法切换";
               }

               newKind = "bone";
               msg = "已切换为：战利品骨头";
               if (data.getInt("tier") == 1) {
                  data.putInt("soul", 1);
                  data.putInt("tier", 0);
               }

               repairBoneDefaults(data);
            }
         } else {
            if (kind.equals("pickaxe")) {
               newKind = "bone_axe";
               msg = "已切换为：骨斧（形态/加成按骨斧规则解释）";
               if (data.getInt("explosion") < 1) {
                  data.putInt("explosion", 1); // 骨斧要求裂地至少 I 级，否则判非法
               }
            } else {
               if (!kind.equals("bone_axe")) {
                  return "未知遗物，无法切换";
               }

               newKind = "pickaxe";
               msg = "已切换为：无尽铁镐（形态按镐规则解释）";
               if (data.getInt("efficiency") > 5) {
                  data.putInt("efficiency", 5); // 铁镐效率上限 V=5
                  msg = msg + "（效率超过铁镐上限 V，已收敛至 V）";
               }
            }
         }

         data.putString("item", newKind);
         ItemStack output = new ItemStack(itemFor(newKind, data.getInt("tier")));
         output.getOrCreateNbt().put("bonefire_relics", data);
         if (newKind.equals("magic_wand")) {
            applyMythic(output, "tiered:mythic_melee_1");
         }

         refreshStack(output);
         writeBack(player, target, output);
         player.getInventory().markDirty();
         return msg;
      }
   }

   /** 可转化遗物对。 */
   private enum KindPair {
      BONE_WAND,
      PICKAXE_AXE
   }

   public static ItemStack initialBone() {
      ItemStack stack = newRelic("bone", 0);
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      data.putInt("damage", 0);
      data.putInt("fire", 1);
      data.putInt("looting", 1);
      refreshStack(stack);
      return stack;
   }

   public static ItemStack initialBoneAxe() {
      ItemStack stack = newRelic("bone_axe", 0);
      NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
      data.putInt("efficiency", 1);
      data.putInt("fortune", 1);
      data.putInt("damage", 0);
      // 裂地初始自带 1 级（触发线 10% 起步；升级至 X=10）
      data.putInt("explosion", 1);
      data.putInt("armor", 0);
      refreshStack(stack);
      return stack;
   }

   public static ItemStack initialGuideBook() {
      return new ItemStack(ModItems.RELIC_GUIDE_BOOK);
   }

   public static List<ItemStack> initialAllRelics() {
      return List.of(initialPickaxe(), initialBone(), initialBoneAxe(), initialGuideBook());
   }

   public static List<ItemStack> initialBoneArmor() {
      return armorSet(0);
   }

   private static List<ItemStack> armorSet(int tier) {
      String[] slots = new String[]{"helmet", "chestplate", "leggings", "boots"};
      ArrayList<ItemStack> result = new ArrayList<>();

      for (String slot : slots) {
         String kind = "bone_" + slot;
         ItemStack stack = newRelic(kind, tier);
         NbtCompound data = stack.getNbt().getCompound("bonefire_relics");
         data.putInt("efficiency", 1);
         data.putInt("fortune", 1);
         data.putInt("fire", 1);
         data.putInt("looting", 0);
         data.putInt("damage", 0);
         data.putInt("armor", 10);
         refreshStack(stack);
         applyMythic(stack, "tiered:mythic_armor_1");
         result.add(stack);
      }

      return result;
   }

   private static record Located(ItemStack stack, int inventorySlot) {
   }

   /** 生成一颗全新的虚空神心（创造发放用；不含存档遗物）。 */
   public static ItemStack newVoidHeart() {
      ItemStack heart = new ItemStack(ModItems.RELIC_VOID_HEART);
      NbtCompound stored = new NbtCompound();
      stored.putBoolean("returned", true);
      heart.getOrCreateNbt().put("void_heart_stored", stored);
      return heart;
   }

   /**
    * 终极融合：三项主属性（镐材质 6 / 骨头伤害 41 / 法杖法强 30）全部满级时，
    * 所有遗物融入秘法核心 → 核心化为**虚空神心**。
    * · 骨头与镐子（含骨斧/法杖形态）的 NBT **原样存进神心**，穿戴时返还 → 等级保留；
    * · 骨甲被吸收、**不返还**，其属性效果由神心继承；
    * · 产物优先放主手，主手有东西则塞背包。
    * @return 提示文本；条件不满足时返回原因
    */
   public static String tryMergeVoidHeart(ServerPlayerEntity player) {
      if (ModItems.RELIC_VOID_HEART == null) {
         return "虚空神心未注册";
      }
      if (VoidHeartHandler.ownsHeart(player)) {
         return "你已经拥有虚空神心了";
      }
      int[] best = RelicChapters.recordedAttributes(player);
      if (best[0] < RelicChapters.TIER_MAX || best[1] < RelicChapters.BONE_MAX || best[2] < RelicChapters.SPELL_MAX) {
         return "三项主属性未全部满级（镐 " + best[0] + "/" + RelicChapters.TIER_MAX
            + "　骨 " + best[1] + "/" + RelicChapters.BONE_MAX
            + "　杖 " + best[2] + "/" + RelicChapters.SPELL_MAX + "）";
      }

      ItemStack heart = new ItemStack(ModItems.RELIC_VOID_HEART);
      NbtCompound stored = new NbtCompound();
      stored.putBoolean("returned", false);
      int absorbed = 0;
      int removedArmor = 0;

      PlayerInventory inventory = player.getInventory();
      for (int i = 0; i < inventory.size(); i++) {
         ItemStack stack = inventory.getStack(i);
         if (stack.isEmpty()) {
            continue;
         }
         boolean isBone = isRelic(stack, UpgradeDefinition.RelicType.BONE)
            || isRelic(stack, UpgradeDefinition.RelicType.WAND);
         boolean isPick = isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)
            || isRelic(stack, UpgradeDefinition.RelicType.AXE);
         boolean isArmor = isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR);
         if (isBone) {
            stored.put("bone", stack.copy().writeNbt(new NbtCompound()));
            inventory.setStack(i, ItemStack.EMPTY);
            absorbed++;
         } else if (isPick) {
            stored.put("pickaxe", stack.copy().writeNbt(new NbtCompound()));
            inventory.setStack(i, ItemStack.EMPTY);
            absorbed++;
         } else if (isArmor) {
            inventory.setStack(i, ItemStack.EMPTY);   // 骨甲：吸收，不返还
            removedArmor++;
         }
      }

      // 秘法核心（背包或饰品栏）一并融入
      if (ModItems.ARCANE_CORE != null) {
         for (int i = 0; i < inventory.size(); i++) {
            if (inventory.getStack(i).isOf(ModItems.ARCANE_CORE)) {
               inventory.setStack(i, ItemStack.EMPTY);
            }
         }
      }

      heart.getOrCreateNbt().put("void_heart_stored", stored);
      // 优先主手
      if (inventory.getMainHandStack().isEmpty()) {
         inventory.setStack(inventory.selectedSlot, heart);
      } else {
         inventory.offerOrDrop(heart);
      }
      inventory.markDirty();
      player.playerScreenHandler.sendContentUpdates();
      player.sendMessage(Text.literal("所有遗物融入心口——秘法核心化为【虚空神心】。握住它，骨头与镐子会回来；骨甲已永远属于你。"), false);
      System.out.println("[VOIDHEART] 融合完成：吸收 " + absorbed + " 件遗物，吞噬骨甲 " + removedArmor + " 件");
      return "融合完成：虚空神心已入手（吸收 " + absorbed + " 件，吞噬骨甲 " + removedArmor + " 件）";
   }
}