package cn.bmcvp.relic;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import java.util.UUID;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.text.Text;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.minecraft.item.ArmorItem.Type;
import net.minecraft.item.Item.Settings;
// （无 spell_power 直连依赖：三系法强写入统一走 RelicService 的 isModLoaded 守卫分支）

public class RelicBoneArmorItem extends ArmorItem {
   public static final String NETHER_UNLOCK_TAG = "bonefire_relics_visited_nether";
   static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0001-4a3e-9f8e-1a2b3c4d5e01");
   static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0002-4a3e-9f8e-1a2b3c4d5e02");
   static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0003-4a3e-9f8e-1a2b3c4d5e03");

   public RelicBoneArmorItem(ArmorMaterial material, Type type, Settings settings) {
      super(material, type, settings);
   }

   public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
      if (!user.getCommandTags().contains("bonefire_relics_visited_nether")) {
         user.sendMessage(Text.literal("§c需要先进入地狱才能使用骨甲"), true);
         return TypedActionResult.fail(user.getStackInHand(hand));
      } else {
         return super.use(world, user, hand);
      }
   }
}
