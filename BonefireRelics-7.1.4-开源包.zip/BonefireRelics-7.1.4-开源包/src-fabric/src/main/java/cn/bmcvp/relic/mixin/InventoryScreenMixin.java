package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.client.RelicButtonConfig;
import cn.bmcvp.relic.client.RelicUpgradeScreen;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InventoryScreen.class})
public abstract class InventoryScreenMixin {
   @Unique
   private ButtonWidget bmcvp$relicButton;

   @Unique
   private static boolean bmcvp$isCreative() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player != null && mc.player.getAbilities().creativeMode;
   }

   @Unique
   private static int bmcvp$buttonX() {
      return bmcvp$isCreative()
         ? RelicButtonConfig.get().creativeButtonX
         : RelicButtonConfig.get().inventoryButtonX;
   }

   @Unique
   private static int bmcvp$buttonY() {
      return bmcvp$isCreative()
         ? RelicButtonConfig.get().creativeButtonY
         : RelicButtonConfig.get().inventoryButtonY;
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void bmcvp$addRelicButton(CallbackInfo ci) {
      InventoryScreen self = (InventoryScreen)(Object)this;
      HandledScreenAccessor layout = (HandledScreenAccessor)this;
      ScreenInvoker screen = (ScreenInvoker)this;
      RelicButtonConfig cfg = RelicButtonConfig.get();
      this.bmcvp$relicButton = ButtonWidget.builder(Text.literal("遗物"), b -> MinecraftClient.getInstance().setScreen(new RelicUpgradeScreen(self)))
         .dimensions(layout.bmcvp$getX() + bmcvp$buttonX(), layout.bmcvp$getY() + bmcvp$buttonY(),
            cfg.buttonWidth, cfg.buttonHeight)
         .build();
      screen.bmcvp$addDrawableChild(this.bmcvp$relicButton);
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void bmcvp$repositionRelicButton(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.bmcvp$relicButton != null) {
         HandledScreenAccessor layout = (HandledScreenAccessor)this;
         this.bmcvp$relicButton.setPosition(layout.bmcvp$getX() + bmcvp$buttonX(), layout.bmcvp$getY() + bmcvp$buttonY());
      }
   }
}
