package cn.bmcvp.relic;

import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketInventory;
import dev.emi.trinkets.api.TrinketsApi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AfterRespawn;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Join;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.PersistentState;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Pair;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;

public final class ArcaneCoreGrowth {
   public static final int MAX_LEVEL = 30;
   public static final int REVIVE_MAX_LEVEL = 20;
   public static final int REVIVE_BASE_COOLDOWN_TICKS = 12000;
   public static final int REVIVE_MIN_COOLDOWN_TICKS = 6000;
   public static final int EXECUTE_UNLOCK_LEVEL = 10;
   public static final float EXECUTE_BASE_CHANCE = 0.1F;
   public static final float EXECUTE_MAX_CHANCE = 0.4F;
   public static final String LEVEL_KEY = "bonefire_core_level";
   public static final String REVIVE_CD_KEY = "bonefire_core_revive_cd";
   private static final String KILL_STATE_ID = "bonefire_relics_growth_kills";
   private static final float EXECUTE_HEALTH_RATIO = 0.3F;
   private static final double REAP_RADIUS = 5.0;
   private static final int REAP_WEAKNESS_TICKS = 60;
   private static final float REAP_HEAL = 5.0F;
   private static final double MAGNET_RADIUS = 6.0;
   private static final double MAGNET_SPEED = 0.35;
   private static boolean initialized;
   private static int tickCounter;

   private ArcaneCoreGrowth() {
   }

   public static int levelOf(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         int level = stack.getOrCreateNbt().getInt("bonefire_core_level");
         return level < 1 ? 1 : Math.min(30, level);
      } else {
         return 1;
      }
   }

   public static ItemStack withLevel(ItemStack stack, int level) {
      ItemStack out = stack.copy();
      int clamped = Math.max(1, Math.min(30, level));
      out.getOrCreateNbt().putInt("bonefire_core_level", clamped);
      return out;
   }

   public static boolean isArcaneCore(ItemStack stack) {
      // 虚空神心继承秘法核心：把神心视作核心，核心的全部属性与技能判定（三系法强/冷却/免符文等）随之生效
      if (VoidHeartHandler.isHeartStack(stack)) {
         return true;
      }

      return ModItems.ARCANE_CORE != null && !stack.isEmpty() && stack.isOf(ModItems.ARCANE_CORE);
   }

   public static double maxHealthFor(int level) {
      return 10.0 + 20.0 * (double)(level - 1) / 29.0;
   }

   public static double attackFor(int level) {
      return 3.0 + 7.0 * (double)(level - 1) / 29.0;
   }

   public static double speedFor(int level) {
      // 速度加成 Lv1 +10% → Lv30 +60%（MULTIPLY_TOTAL：0.1 基速 → Lv30 约 0.16），单源稳定无闪变
      return 0.1 + 0.5 * (double)(level - 1) / 29.0;
   }

   public static int killThreshold(int level) {
      if (level <= 2) {
         return level == 2 ? 1 : 0;
      } else {
         return (int)Math.round(119.0 * (double)(level - 2) / 28.0) + 1;
      }
   }

   public static int experienceCost(int currentLevel) {
      return 2 + currentLevel / 3;
   }

   public static Item materialFor(int currentLevel) {
      if (currentLevel >= 21) {
         return Items.ENDER_PEARL;
      } else if (currentLevel >= 11) {
         return Items.GOLD_INGOT;
      } else {
         return currentLevel >= 2 ? Items.BONE : null;
      }
   }

   public static int materialCount(int currentLevel) {
      if (currentLevel >= 21) {
         return 10 + 2 * (currentLevel - 21);
      } else if (currentLevel >= 11) {
         return currentLevel + 1;
      } else {
         return currentLevel >= 2 ? currentLevel : 0;
      }
   }

   private static ArcaneCoreGrowth.KillState killState(ServerWorld world) {
      return (ArcaneCoreGrowth.KillState)world.getServer()
         .getOverworld()
         .getPersistentStateManager()
         .getOrCreate(ArcaneCoreGrowth.KillState::fromNbt, ArcaneCoreGrowth.KillState::new, "bonefire_relics_growth_kills");
   }

   public static int killsOf(ServerPlayerEntity player) {
      return killState(player.getServerWorld()).of(player.getUuid());
   }

   public static void recordKill(ServerPlayerEntity killer) {
      killState(killer.getServerWorld()).add(killer.getUuid(), 1);
   }

   public static ArcaneCoreGrowth.Holder findCore(ServerPlayerEntity player) {
      if (net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("trinkets")) {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            List<Pair<SlotReference, ItemStack>> equipped = component.get().getEquipped(ArcaneCoreGrowth::isArcaneCore);
            if (!equipped.isEmpty()) {
               Pair<SlotReference, ItemStack> pair = equipped.get(0);
               TrinketInventory inv = ((SlotReference)pair.getLeft()).inventory();
               return new ArcaneCoreGrowth.Holder((ItemStack)pair.getRight(), (ix, s) -> {
                  inv.setStack(ix, s);
                  inv.getComponent().update();
               }, ((SlotReference)pair.getLeft()).index());
            }
         }
      }

      for (int i = 0; i < player.getInventory().main.size(); i++) {
         ItemStack stack = (ItemStack)player.getInventory().main.get(i);
         if (isArcaneCore(stack)) {
            return new ArcaneCoreGrowth.Holder(stack, (idx, s) -> player.getInventory().main.set(idx, s), i);
         }
      }

      ItemStack off = player.getOffHandStack();
      if (isArcaneCore(off)) {
         return new ArcaneCoreGrowth.Holder(off, (idx, s) -> player.getInventory().offHand.set(0, s), 0);
      } else {
         for (int ix = 0; ix < player.getInventory().armor.size(); ix++) {
            ItemStack stack = (ItemStack)player.getInventory().armor.get(ix);
            if (isArcaneCore(stack)) {
               return new ArcaneCoreGrowth.Holder(stack, (idx, s) -> player.getInventory().armor.set(idx, s), ix);
            }
         }

         return null;
      }
   }

   public static ItemStack equippedCore(ServerPlayerEntity player) {
      if (ModItems.ARCANE_CORE == null) {
         return ItemStack.EMPTY;
      } else {
         Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
         if (component.isPresent()) {
            List<Pair<SlotReference, ItemStack>> equipped = component.get().getEquipped(ArcaneCoreGrowth::isArcaneCore);
            if (!equipped.isEmpty()) {
               return (ItemStack)equipped.get(0).getRight();
            }
         }

         return ItemStack.EMPTY;
      }
   }

   public static int equippedLevel(ServerPlayerEntity player) {
      ItemStack core = equippedCore(player);
      return core.isEmpty() ? 0 : levelOf(core);
   }

   /**
    * 玩家是否带着秘法核心（**双端可用**：服务端走 equippedCore，客户端走 背包/副手/装备栏 + 饰品槽）。
    * 用途：spell_engine 的 ammoForSpell 前置检查在客户端(Render thread)与服务端都会调用，
    * 若只认 ServerPlayerEntity，客户端那一关会因"没有符文"直接拦住施法。
    */
   public static boolean hasCoreEquipped(PlayerEntity player) {
      if (ModItems.ARCANE_CORE == null || player == null) {
         return false;
      }
      if (player instanceof ServerPlayerEntity serverPlayer) {
         return !equippedCore(serverPlayer).isEmpty();
      }
      // 客户端：背包主格 + 装备栏 + 副手
      for (ItemStack stack : player.getInventory().main) {
         if (isCoreOrHeart(stack)) {
            return true;
         }
      }
      for (ItemStack stack : player.getInventory().armor) {
         if (isCoreOrHeart(stack)) {
            return true;
         }
      }
      if (isCoreOrHeart(player.getOffHandStack())) {
         return true;
      }
      // 客户端：饰品槽（trinkets 缺失时跳过）
      if (net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("trinkets")) {
         try {
            Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(player);
            if (component.isPresent() && !component.get().getEquipped(ArcaneCoreGrowth::isArcaneCore).isEmpty()) {
               return true;
            }
         } catch (Throwable ignored) {
            // 客户端饰品组件不可用时忽略
         }
      }
      return false;
   }

   public static void syncAttributes(ServerPlayerEntity player) {
      ItemStack core = equippedCore(player);
      int level = core.isEmpty() ? 0 : levelOf(core);

      for (EntityAttribute attribute : List.of(EntityAttributes.GENERIC_MAX_HEALTH, EntityAttributes.GENERIC_ATTACK_DAMAGE, EntityAttributes.GENERIC_MOVEMENT_SPEED)) {
         EntityAttributeInstance instance = player.getAttributeInstance(attribute);
         if (instance != null) {
            UUID fixedUuid = attributeUuid(attribute);

            for (EntityAttributeModifier modifier : new ArrayList<EntityAttributeModifier>(instance.getModifiers())) {
               if (modifier.getName().startsWith("Bonefire Arcane Core") && !modifier.getId().equals(fixedUuid)) {
                  instance.removeModifier(modifier.getId());
               }
            }

            if (level > 0) {
               double value = attributeValue(attribute, level);
               Operation operation = attribute == EntityAttributes.GENERIC_MOVEMENT_SPEED ? Operation.MULTIPLY_TOTAL : Operation.ADDITION;
               EntityAttributeModifier existing = instance.getModifier(fixedUuid);
               if (existing == null || existing.getValue() != value || existing.getOperation() != operation) {
                  instance.removeModifier(fixedUuid);
                  instance.addPersistentModifier(new EntityAttributeModifier(fixedUuid, "Bonefire Arcane Core " + attribute.getTranslationKey(), value, operation));
               }
            }
         }
      }
   }

   private static UUID attributeUuid(EntityAttribute attribute) {
      if (attribute == EntityAttributes.GENERIC_ATTACK_DAMAGE) {
         return UUID.fromString("11111212-0000-0000-0000-000000000001");
      } else {
         return attribute == EntityAttributes.GENERIC_MOVEMENT_SPEED
            ? UUID.fromString("11111213-0000-0000-0000-000000000001")
            : UUID.fromString("11111211-0000-0000-0000-000000000001");
      }
   }

   private static double attributeValue(EntityAttribute attribute, int level) {
      if (attribute == EntityAttributes.GENERIC_ATTACK_DAMAGE) {
         return attackFor(level);
      } else {
         return attribute == EntityAttributes.GENERIC_MOVEMENT_SPEED ? speedFor(level) : maxHealthFor(level);
      }
   }

   public static String tryGrowthUpgrade(ServerPlayerEntity player) {
      ArcaneCoreGrowth.Holder holder = findCore(player);
      if (holder == null) {
         return "背包或穿戴槽中未找到秘法核心";
      } else {
         int level = levelOf(holder.stack());
         if (level >= 30) {
            return "秘法核心已达满级 Lv.30";
         } else {
            boolean creative = player.getAbilities().creativeMode;
            if (!creative) {
               int needKills = killThreshold(level + 1);
               if (killsOf(player) < needKills) {
                  return "击杀不足：需要累计击杀 " + needKills + "（当前 " + killsOf(player) + "）";
               }

               int needXp = experienceCost(level);
               if (player.experienceLevel < needXp) {
                  return "经验等级不足：需要 " + needXp + " 级";
               }

               Item material = materialFor(level);
               int needCount = materialCount(level);
               if (material != null) {
                  int have = countItem(player, material);
                  if (have < needCount) {
                     return "材料不足：还差 " + material.getName().getString() + " ×" + (needCount - have);
                  }

                  removeItem(player, material, needCount);
               }

               player.addExperienceLevels(-needXp);
            }

            ItemStack upgraded = withLevel(holder.stack(), level + 1);
            holder.write(upgraded);
            player.getInventory().markDirty();
            player.playerScreenHandler.sendContentUpdates();
            syncAttributes(player);
            return "升级成功：秘法核心 Lv." + level + "→" + (level + 1);
         }
      }
   }

   public static String forceLevel(ServerPlayerEntity player, int level) {
      ArcaneCoreGrowth.Holder holder = findCore(player);
      if (holder == null) {
         return "背包或穿戴槽中未找到秘法核心";
      } else if (level >= 1 && level <= 30) {
         int before = levelOf(holder.stack());
         holder.write(withLevel(holder.stack(), level));
         player.getInventory().markDirty();
         player.playerScreenHandler.sendContentUpdates();
         syncAttributes(player);
         return "秘法核心等级已设为 Lv." + level + (before != level ? "（原 Lv." + before + "）" : "");
      } else {
         return "等级需在 1..30 之间";
      }
   }

   private static int countItem(ServerPlayerEntity player, Item item) {
      int count = 0;

      for (ItemStack stack : player.getInventory().main) {
         if (stack.isOf(item)) {
            count += stack.getCount();
         }
      }

      if (player.getOffHandStack().isOf(item)) {
         count += player.getOffHandStack().getCount();
      }

      return count;
   }

   private static void removeItem(ServerPlayerEntity player, Item item, int required) {
      for (ItemStack stack : player.getInventory().main) {
         if (stack.isOf(item) && required > 0) {
            int taken = Math.min(required, stack.getCount());
            stack.decrement(taken);
            required -= taken;
         }
      }

      ItemStack off = player.getOffHandStack();
      if (required > 0 && off.isOf(item)) {
         off.decrement(Math.min(required, off.getCount()));
      }
   }

   public static boolean hasMagnet(int level) {
      return level >= 5;
   }

   public static boolean hasExecution(int level) {
      return level >= 10;
   }

   public static boolean hasSoulReaper(int level) {
      return level >= 30;
   }

   public static boolean isExempt(Entity victim) {
      return victim instanceof PlayerEntity || victim instanceof WitherEntity || victim instanceof EnderDragonEntity;
   }

   private static double growCurve(double x) {
      double t = Math.max(0.0, Math.min(1.0, x));
      return t * t * (3.0 - 2.0 * t);
   }

   public static float executeChance(int level) {
      if (level < EXECUTE_UNLOCK_LEVEL) {
         return 0.0F;
      } else {
         double t = growCurve((double)(level - EXECUTE_UNLOCK_LEVEL) / (double)(MAX_LEVEL - EXECUTE_UNLOCK_LEVEL));
         return EXECUTE_BASE_CHANCE + (float)((EXECUTE_MAX_CHANCE - EXECUTE_BASE_CHANCE) * t);
      }
   }

   public static int executeChancePercent(int level) {
      return (int)Math.round(executeChance(level) * 100.0);
   }

   public static boolean underExecuteLine(float health, float maxHealth) {
      return health <= maxHealth * EXECUTE_HEALTH_RATIO;
   }

   public static float reviveHealFor(int level, float maxHealth) {
      if (level >= REVIVE_MAX_LEVEL) {
         return maxHealth;
      } else {
         double t = growCurve((double)(Math.max(1, level) - 1) / (double)(REVIVE_MAX_LEVEL - 1));
         return 4.0F + (float)((maxHealth - 4.0F) * t);
      }
   }

   public static int reviveCooldownTicks(int level) {
      if (level >= REVIVE_MAX_LEVEL) {
         return REVIVE_MIN_COOLDOWN_TICKS;
      } else {
         double t = growCurve((double)(Math.max(1, level) - 1) / (double)(REVIVE_MAX_LEVEL - 1));
         return (int)Math.round(
            (double)REVIVE_BASE_COOLDOWN_TICKS - (double)(REVIVE_BASE_COOLDOWN_TICKS - REVIVE_MIN_COOLDOWN_TICKS) * t
         );
      }
   }

   public static int reviveCooldownSeconds(int level) {
      return reviveCooldownTicks(level) / 20;
   }

   public static void soulReaper(ServerPlayerEntity player, Entity around, int level) {
      if (hasSoulReaper(level)) {
         ServerWorld world = player.getServerWorld();
         double attack = player.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE);
         float damage = (float)(attack * 2.0);
         Box box = around.getBoundingBox().expand(5.0);

         for (Entity entity : world.getOtherEntities(around, box)) {
            if (entity instanceof LivingEntity) {
               LivingEntity living = (LivingEntity)entity;
               if (!isExempt(living)) {
                  living.damage(world.getDamageSources().playerAttack(player), damage);
                  living.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 60, 1), player);
               }
            }
         }

         player.heal(5.0F);
         world.spawnParticles(ParticleTypes.ENCHANT, around.getX(), around.getY() + 1.0, around.getZ(), 48, 5.0, 0.5, 5.0, 0.6);
      }
   }

   public static boolean tryRevive(ServerPlayerEntity player, DamageSource source) {
      if (!source.isOf(DamageTypes.OUT_OF_WORLD) && !source.isOf(DamageTypes.GENERIC_KILL)) {
         ItemStack core = equippedCore(player);
         if (core.isEmpty()) {
            return false;
         } else {
            int level = levelOf(core);
            long now = player.getServerWorld().getTime();
            long cdUntil = core.getOrCreateNbt().getLong("bonefire_core_revive_cd");
            if (now < cdUntil) {
               return false;
            } else {
               int cdTicks = reviveCooldownTicks(level);
               core.getOrCreateNbt().putLong("bonefire_core_revive_cd", now + (long)cdTicks);
               float maxHealth = player.getMaxHealth();
               float heal = reviveHealFor(level, maxHealth);
               player.setHealth(heal);
               player.clearStatusEffects();
               player.getServerWorld()
                  .spawnParticles(
                     ModParticles.ARCANE_REVIVE, player.getX(), player.getY() + 0.5, player.getZ(), 64, 0.5, 0.5, 0.5, 0.4
                  );
               player.getServerWorld().playSound(null, player.getBlockPos(), SoundEvents.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1.0F, 1.0F);
               int cdSec = cdTicks / 20;
               String healText = level >= REVIVE_MAX_LEVEL ? "满血" : String.format("%.1f 点生命", heal);
               player.sendMessage(
                  Text.literal(
                     "秘法核心·死而复生 已生效：回复 " + healText + "（Lv." + level + "），复活 CD " + (cdSec / 60) + " 分 " + (cdSec % 60) + " 秒"
                  ),
                  true
               );
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private static void magnetPull(ServerPlayerEntity player) {
      ServerWorld world = player.getServerWorld();
      Box box = player.getBoundingBox().expand(6.0);
      List<Entity> targets = new ArrayList<>();
      targets.addAll(world.getEntitiesByClass(ItemEntity.class, box, Entity::isAlive));
      targets.addAll(world.getEntitiesByClass(ExperienceOrbEntity.class, box, Entity::isAlive));
      if (!targets.isEmpty()) {
         Vec3d center = player.getPos().add(0.0, 0.5, 0.0);
         int pulled = 0;

         for (Entity entity : targets) {
            if (pulled >= 12) {
               break;
            }

            double dist = entity.squaredDistanceTo(player);
            double stop = 4.0;
            if (!(dist < stop) && !(dist > 36.0) && (!(entity instanceof ItemEntity item) || item.getOwner() == null || item.getOwner() == player)) {
               Vec3d diff = center.subtract(entity.getPos());
               double len = Math.max(diff.length(), 0.01);
               entity.setVelocity(diff.multiply(0.35 / len).add(new Vec3d(0.0, 0.06, 0.0)));
               entity.velocityModified = true;
               pulled++;
            }
         }
      }
   }

   public static void initialize() {
      if (!initialized) {
         initialized = true;
         ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
            tickCounter++;
            if (tickCounter % 10 == 0) {
               for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                  if (hasMagnet(equippedLevel(player))) {
                     magnetPull(player);
                  }

                  syncAttributes(player);
               }
            }
         });
         ServerPlayConnectionEvents.JOIN.register((Join)(handler, sender, server) -> server.execute(() -> syncAttributes(handler.player)));
         ServerPlayerEvents.AFTER_RESPAWN.register((AfterRespawn)(oldPlayer, newPlayer, alive) -> syncAttributes(newPlayer));
      }
   }

   public static record Holder(ItemStack stack, ArcaneCoreGrowth.WriteTarget target, int index) {
      public void write(ItemStack out) {
         this.target.write(this.index, out);
      }
   }

   public static final class KillState extends PersistentState {
      private final Map<UUID, Integer> kills = new HashMap<>();

      public int of(UUID uuid) {
         return this.kills.getOrDefault(uuid, 0);
      }

      public void add(UUID uuid, int amount) {
         this.kills.merge(uuid, amount, Integer::sum);
         this.markDirty();
      }

      public static ArcaneCoreGrowth.KillState fromNbt(NbtCompound nbt) {
         ArcaneCoreGrowth.KillState state = new ArcaneCoreGrowth.KillState();

         for (String key : nbt.getKeys()) {
            try {
               state.kills.put(UUID.fromString(key), nbt.getInt(key));
            } catch (IllegalArgumentException var5) {
            }
         }

         return state;
      }

      public NbtCompound writeNbt(NbtCompound nbt) {
         for (Entry<UUID, Integer> entry : this.kills.entrySet()) {
            nbt.putInt(entry.getKey().toString(), entry.getValue());
         }

         return nbt;
      }
   }

   public interface WriteTarget {
      void write(int var1, ItemStack var2);
   }

   /**
    * 「核心或神心」统一判定（2026-09-13）：
    * 神心继承秘法核心 → 冷却减免 / 免符文 / 复活等以"是否持有核心"为准的技能必须一并生效。
    * 神心用 id 级判定（VoidHeartHandler.isHeartStack），避免静态字段指向另一种形态时漏判。
    */
   public static boolean isCoreOrHeart(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return false;
      }
      if (VoidHeartHandler.isHeartStack(stack)) {
         return true;
      }
      return ModItems.ARCANE_CORE != null && stack.isOf(ModItems.ARCANE_CORE);
   }
}
