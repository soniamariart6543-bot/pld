package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ServerPlayNetworkHandler.class})
public abstract class RelicDropProtectionMixin {
   @Inject(
      method = {"onPlayerAction"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void bmcvp$blockRelicDrop(PlayerActionC2SPacket packet, CallbackInfo ci) {
      Action action = packet.getAction();
      if (action == Action.DROP_ITEM || action == Action.DROP_ALL_ITEMS) {
         ServerPlayerEntity player = ((ServerPlayNetworkHandler)(Object)this).player;
         if (RelicService.isAnyRelic(player.getInventory().getMainHandStack())) {
            ci.cancel();
         }
      }
   }
}
