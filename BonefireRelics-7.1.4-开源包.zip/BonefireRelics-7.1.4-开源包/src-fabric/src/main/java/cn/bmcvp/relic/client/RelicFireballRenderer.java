package cn.bmcvp.relic.client;

import cn.bmcvp.relic.RelicFireballEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class RelicFireballRenderer extends EntityRenderer<RelicFireballEntity> {
   private static final Identifier TEXTURE = new Identifier("bonefire_relics", "textures/entity/relic_fireball.png");
   private static final float SIZE = 0.6F;

   public RelicFireballRenderer(Context ctx) {
      super(ctx);
   }

   public Identifier getTexture(RelicFireballEntity entity) {
      return TEXTURE;
   }

   public void render(RelicFireballEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
      matrices.push();
      matrices.multiply(this.dispatcher.getRotation());
      matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(180.0F));
      matrices.scale(0.6F, 0.6F, 0.6F);
      VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(TEXTURE));
      Matrix4f matrix4f = matrices.peek().getPositionMatrix();
      Matrix3f normal = matrices.peek().getNormalMatrix();
      vc.vertex(matrix4f, -0.5F, -0.5F, 0.0F)
         .color(255, 255, 255, 255)
         .texture(0.0F, 1.0F)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(light)
         .normal(normal, 0.0F, 0.0F, 1.0F);
      vc.vertex(matrix4f, 0.5F, -0.5F, 0.0F)
         .color(255, 255, 255, 255)
         .texture(1.0F, 1.0F)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(light)
         .normal(normal, 0.0F, 0.0F, 1.0F);
      vc.vertex(matrix4f, 0.5F, 0.5F, 0.0F)
         .color(255, 255, 255, 255)
         .texture(1.0F, 0.0F)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(light)
         .normal(normal, 0.0F, 0.0F, 1.0F);
      vc.vertex(matrix4f, -0.5F, 0.5F, 0.0F)
         .color(255, 255, 255, 255)
         .texture(0.0F, 0.0F)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(light)
         .normal(normal, 0.0F, 0.0F, 1.0F);
      matrices.pop();
      super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
   }
}
