package cn.bmcvp.relic;

import java.util.List;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.ExplosiveProjectileEntity;
import net.minecraft.world.World;
import net.minecraft.util.math.Box;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;

public class RelicFireballEntity extends ExplosiveProjectileEntity {
   public static final double SPEED = 2.0;
   private static final int MAX_LIFE = 120;
   private static final double EXPLOSION_RADIUS = 3.0;
   private static final int WITHER_TICKS = 100;
   private static final int WITHER_AMPLIFIER = 1;
   private ServerPlayerEntity owner;
   private float baseDamage;
   private int spell;
   private int explosion;
   /** 毁灭模式（神心）：命中时按 1 个 TNT 结算 —— 破坏方块 + 点燃地面 / 引爆 TNT。 */
   private boolean destructive;
   private boolean soul;
   private int life = 120;

   public RelicFireballEntity(EntityType<? extends ExplosiveProjectileEntity> type, World world) {
      super(type, world);
   }

   public RelicFireballEntity(World world, ServerPlayerEntity owner, float baseDamage, int spell, int explosion, boolean soul) {
      super(RelicEntities.RELIC_FIREBALL, world);
      this.owner = owner;
      this.baseDamage = baseDamage;
      this.spell = spell;
      this.explosion = explosion;
      this.destructive = cn.bmcvp.relic.VoidHeartHandler.isDestructiveMode(owner);
      this.soul = soul;
      this.setPos(owner.getX(), owner.getEyeY(), owner.getZ());
      this.setNoGravity(true);
   }

   public void tick() {
      super.tick();
      Vec3d v = this.getVelocity();
      double len = v.length();
      if (len > 1.0E-4) {
         this.setVelocity(v.multiply(2.0 / len));
      }

      if (this.getWorld() instanceof ServerWorld sw) {
         Vec3d p = this.getPos();
         if (this.soul) {
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
            sw.spawnParticles(ParticleTypes.SOUL, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
         } else {
            sw.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
            sw.spawnParticles(ParticleTypes.SMALL_FLAME, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
         }
      }

      // 近距补扫：放大命中判定（小目标/贴脸时原版投射物碰撞易漏）——实体未撞上时按
      // 当前位置周边 0.8 格自动引爆最近敌对目标
      if (!this.getWorld().isClient && this.owner != null && !this.isRemoved()) {
         LivingEntity near = null;
         for (LivingEntity candidate : this.getWorld().getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(0.8D), e -> e != this.owner
            && !(e instanceof net.minecraft.entity.player.PlayerEntity)
            && e.isAlive()
            && !e.isRemoved())) {
            near = candidate;
            break;
         }

         if (near != null) {
            this.explodeAt(near);
            this.discard();
            return;
         }
      }

      if (--this.life <= 0) {
         this.discard();
      }
   }

   protected boolean canHit(Entity entity) {
      if (entity instanceof LivingEntity le && le != this.owner && le.isAlive()) {
         return true;
      }

      return false;
   }

   protected void onEntityHit(EntityHitResult hitResult) {
      if (hitResult.getEntity() instanceof LivingEntity hit && this.owner != null) {
         this.explodeAt(hit);
         // 毁灭模式（神心）：命中实体同样按 1 个 TNT 结算
         if (this.destructive && this.getWorld() instanceof ServerWorld sw) {
            sw.createExplosion(this, this.getX(), this.getY(), this.getZ(), 4.0F, true,
               net.minecraft.world.World.ExplosionSourceType.TNT);
         }
         this.discard();
         return;
      }

      this.discard();
   }

   protected void onBlockHit(BlockHitResult hitResult) {
      // 普通模式：仅范围魔法 AoE + 粒子/音效（不破坏方块）
      // 毁灭模式（神心）：1 个 TNT 效果 —— 4.0F 威力 / 破坏方块 / createFire=true 点燃地面与 TNT
      if (this.owner != null && this.getWorld() instanceof ServerWorld sw) {
         if (this.destructive) {
            sw.createExplosion(this, this.getX(), this.getY(), this.getZ(), 4.0F, true,
               net.minecraft.world.World.ExplosionSourceType.TNT);
         }
         explodeAtBlock(sw, this.owner, hitResult.getBlockPos(), this.explosion, this.soul);
      }

      this.discard();
   }

   /** 方块命中爆炸：以命中方块为中心的范围魔法伤害，视觉用纯粒子（不破坏方块）。 */
   public static void explodeAtBlock(ServerWorld sw, ServerPlayerEntity owner, BlockPos pos, int explosion, boolean soul) {
      if (owner == null || sw == null || pos == null) {
         return;
      }
      Vec3d center = Vec3d.ofCenter(pos);
      spawnExplosionVisual(sw, center, false, soul, explosion);
      float critChance = soul ? 0.35F : 0.25F;
      float boom = (float)(5.0 + (double)explosion * 0.5) + WandSkillHandler.allSpellPowerBonus(owner);
      DamageSource boomSource = owner.getDamageSources().indirectMagic(owner, owner);

      for (LivingEntity e : hostilesIn(sw, boxAround(center, 3.0 + (double)explosion * 0.25), owner)) {
         float actual = rollCrit(boom, critChance, owner);
         e.damage(boomSource, actual);
         WandSkillHandler.lifestealFrom(owner, actual);
         applySoulWither(e, soul);
      }
   }

   private void explodeAt(LivingEntity hit) {
      if (this.owner != null) {
         ServerWorld sw = this.getWorld() instanceof ServerWorld s ? s : null;
         if (sw != null) {
            explodeAt(sw, this.owner, hit, this.baseDamage, this.spell, this.explosion, this.soul);
         }
      }
   }

   public static void explodeAt(ServerWorld sw, ServerPlayerEntity owner, LivingEntity hit, float baseDamage, int spell, int explosion, boolean soul) {
      if (owner != null && sw != null && hit != null && hit.isAlive()) {
         Vec3d center = hit.getPos().add(0.0, (double)(hit.getHeight() / 2.0F), 0.0);
         float critChance = soul ? 0.35F : 0.25F;
         DamageSource source = owner.getDamageSources().indirectMagic(owner, owner);
         DamageSource trueSource = WandSkillHandler.trueDamageSource(owner);
         // 真伤段：一阶段 = 3 + 魔法成长部分 × 30%；二阶段（灵魂杖）= 魔法段 × 50%
         float trueBase = soul ? baseDamage * 0.5F : 3.0F + Math.max(0.0F, baseDamage - 6.0F) * 0.30F;
         float punishPart = spell >= 15 ? hit.getHealth() * 0.05F : 0.0F;
         // 一阶段总伤害（魔法 + 真伤基座）上限 200（超出按比例缩放）
         float magicBase = baseDamage;
         if (!soul) {
            float sum = magicBase + trueBase;
            if (sum > 200.0F) {
               float k = 200.0F / sum;
               magicBase *= k;
               trueBase *= k;
            }
         }
         float magicPart = rollCrit(magicBase, critChance, owner);
         float truePart = rollCrit(trueBase + punishPart, critChance, owner);
         float chance = soul ? Math.min(0.3F + (float)spell * 0.01F, 0.45F) : Math.min(0.1F + (float)spell * 0.01F, 0.3F);
         boolean combo = hit.isAlive() && sw.random.nextFloat() < chance;
         float magicTotal = magicPart;
         float trueTotal = truePart;
         if (combo) {
            magicTotal = magicPart + magicPart;
            trueTotal = truePart + truePart;
         }

         // 三系 spell 系数已按法强等级线性并入魔法段（WandSkillHandler.fire），此处不再重复叠加
         if (magicTotal > 0.0F) {
            hit.damage(source, magicTotal);
         }

         if (trueTotal > 0.0F) {
            hit.damage(trueSource, trueTotal);
         }

         float lifestealTotal = magicPart + truePart;
         if (combo) {
            lifestealTotal += magicPart + truePart;
         }

         WandSkillHandler.lifestealFrom(owner, lifestealTotal);
         applySoulWither(hit, soul);
         spawnExplosionVisual(sw, center, false, soul, explosion);
         if (explosion > 0) {
            float boom = (float)(5.0 + (double)explosion * 0.5) + WandSkillHandler.allSpellPowerBonus(owner);

            for (LivingEntity e : hostilesIn(sw, boxAround(center, 3.0), owner)) {
               float actual = rollCrit(boom, critChance, owner);
               e.damage(source, actual);
               WandSkillHandler.lifestealFrom(owner, actual);
               applySoulWither(e, soul);
            }
         }

         if (soul && !hit.isAlive()) {
            soulBurst(sw, owner, center, explosion, critChance, soul);
         }
      }
   }

   private static float rollCrit(float damage, float chance, ServerPlayerEntity owner) {
      return owner.getRandom().nextFloat() < chance ? damage * 1.5F : damage;
   }

   private static void applySoulWither(LivingEntity target, boolean soul) {
      if (soul && target != null && target.isAlive()) {
         target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1));
      }
   }

   private static void soulBurst(ServerWorld sw, ServerPlayerEntity owner, Vec3d center, int explosion, float critChance, boolean soul) {
      float boom = (float)(5.0 + (double)explosion * 0.5);
      spawnExplosionVisual(sw, center, true, soul, explosion);
      DamageSource boomSource = owner.getDamageSources().indirectMagic(owner, owner);

      for (LivingEntity e : hostilesIn(sw, boxAround(center, 3.0 + (double)explosion * 0.25), owner)) {
         float actual = rollCrit(boom, critChance, owner);
         e.damage(boomSource, actual);
         WandSkillHandler.lifestealFrom(owner, actual);
         applySoulWither(e, soul);
      }
   }

   private static void spawnExplosionVisual(ServerWorld sw, Vec3d center, boolean burst, boolean soul, int explosion) {
      sw.spawnParticles(ParticleTypes.EXPLOSION, center.x, center.y, center.z, 1, 0.0, 0.0, 0.0, 0.0);
      if (soul) {
         if (burst) {
            double r = 3.0 + (double)explosion * 0.25;
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, center.x, center.y, center.z, 32, r, r, r, 0.05);
         } else {
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
            sw.spawnParticles(ParticleTypes.SOUL, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
         }
      } else {
         sw.spawnParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
         sw.spawnParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
      }

      sw.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 1.0F, 1.0F);
   }

   private static Box boxAround(Vec3d center, double radius) {
      return new Box(
         center.x - radius,
         center.y - radius,
         center.z - radius,
         center.x + radius,
         center.y + radius,
         center.z + radius
      );
   }

   private static List<LivingEntity> hostilesIn(ServerWorld sw, Box box, ServerPlayerEntity owner) {
      return sw.getEntitiesByClass(LivingEntity.class, box, e -> e != owner && e.isAlive() && e instanceof HostileEntity);
   }

   public boolean hasNoGravity() {
      return true;
   }
}
