package cn.bmcvp.relic.mixin.se;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.spell_engine.api.spell.Spell;
import net.spell_engine.internals.SpellHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 秘法核心：法术冷却缩短 10%。
 *
 * 挂在冷却计算源头 SpellHelper.getCooldownDuration(LivingEntity, Spell, ItemStack)：
 *   · 2 参重载（LivingEntity, Spell）委托到 3 参版本 → 自动继承
 *   · cooldownToSet(...)（真正写入冷却处）调用的正是 2 参版本 → 同样继承
 *   只在此一处缩放，不会重复计算。
 * 仅装备秘法核心的玩家生效；未装 spell_engine 时该配置整体不加载。
 * 注：日志探针已按"收尾清理"约定移除（2026-09-10）。
 */
@Mixin({SpellHelper.class})
public abstract class ArcaneCoreCooldownMixin {
   /** 冷却缩减比例：10%。 */
   private static final float COOLDOWN_MULTIPLIER = 0.90F;

   @Inject(
      method = {"getCooldownDuration(Lnet/minecraft/entity/LivingEntity;Lnet/spell_engine/api/spell/Spell;Lnet/minecraft/item/ItemStack;)F"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void bmcvp$reduceCooldown(
      LivingEntity caster, Spell spell, ItemStack casterStack, CallbackInfoReturnable<Float> cir
   ) {
      float base = cir.getReturnValueF();
      if (base <= 0.0F) {
         return;
      }
      if (caster instanceof PlayerEntity player && ArcaneCoreGrowth.hasCoreEquipped(player)) {
         cir.setReturnValue(base * COOLDOWN_MULTIPLIER);
      }
   }
}
