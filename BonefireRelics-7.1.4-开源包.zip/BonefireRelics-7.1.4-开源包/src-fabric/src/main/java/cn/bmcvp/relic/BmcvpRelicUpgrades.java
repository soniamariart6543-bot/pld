package cn.bmcvp.relic;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Join;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.server.network.ServerPlayerEntity;

public class BmcvpRelicUpgrades implements ModInitializer {
   public static final String MODID = "bonefire_relics";
   public static final Identifier UPGRADE = new Identifier("bonefire_relics", "upgrade");
   public static final Identifier MAX_UPGRADE = new Identifier("bonefire_relics", "max_upgrade");
   public static final Identifier RESULT = new Identifier("bonefire_relics", "result");
   public static final Identifier GRANT = new Identifier("bonefire_relics", "grant");
   public static final Identifier WAND_SWING = new Identifier("bonefire_relics", "wand_swing");
   public static final Identifier WAND_SWITCH = new Identifier("bonefire_relics", "wand_switch");
   public static final Identifier GROWTH_UPGRADE = new Identifier("bonefire_relics", "growth_upgrade");
   public static final Identifier GROWTH_INFO_REQ = new Identifier("bonefire_relics", "growth_info_req");
   /** 任务书（六章）状态查询 / 回包：客户端开指南书时请求，服务端回传章号与三项主属性。 */
   public static final Identifier CHAPTER_REQ = new Identifier("bonefire_relics", "chapter_req");
   public static final Identifier CHAPTER_INFO = new Identifier("bonefire_relics", "chapter_info");
   /** 一键满级（全部遗物）：每个升级界面都有的「一键满级」按钮走这里；计入任务书（后门）。 */
   public static final Identifier MAX_ALL = new Identifier("bonefire_relics", "max_all");
   /** 秘法核心升级界面里的「融合 · 虚空神心」按钮：手动触发终极融合。 */
   /** 法杖爆炸模式切换（供法杖升级界面按钮调用）。 */
   /** 创造模式「一键成神」：发放神心 + 播放融合演出（可反复发放）。 */
   public static final Identifier ASCEND = new Identifier("bonefire_relics", "ascend");
   public static final Identifier WAND_MODE = new Identifier("bonefire_relics", "wand_mode");
   public static final Identifier MERGE_HEART = new Identifier("bonefire_relics", "merge_heart");
   public static final int PACKET_STRING_MAX_LENGTH = 64;
   private static final String PICKAXE_GRANTED = "bonefire_relics_pickaxe_granted";
   private static final String BONE_AXE_GRANTED = "bonefire_relics_bone_axe_granted";
   private static final String BONE_GRANTED = "bonefire_relics_bone_granted";
   private static final String BONE_ARMOR_GRANTED = "bonefire_relics_bone_armor_granted";
   private static final String GUIDE_GRANTED = "bonefire_relics_guide_granted";
   private static final String APPLE_GRANTED = "bonefire_relics_apple_granted";
   private static final String VISITED_NETHER = "bonefire_relics_visited_nether";
   private static final String ARCANE_CORE_GRANTED = "bonefire_relics_arcane_core_granted";

   public void onInitialize() {
      ModParticles.initialize();
      ModItems.initialize();
      // 依赖守卫：无 spell_engine / 无 trinkets 时以护甲形态补注册神心（必须在 ModItems.initialize 之后）
      ModItems.ensureVoidHeartRegistered();
      ModEffects.initialize();
      LifestealHandler.initialize();
      AxeSkillHandler.initialize();
      BedrockMiningHandler.initialize();
      ArmorOvercapHandler.initialize();
      BoneSkillHandler.initialize();
      ArmorSkillHandler.initialize();
      PickaxeSkillHandler.initialize();
      WandSkillHandler.initialize();
      RelicEntities.initialize();
      ArcaneCoreGrowth.initialize();
      RelicProbe.initialize();
      VoidHeartHandler.initialize();
      FusionCinematic.initialize();
      ServerPlayNetworking.registerGlobalReceiver(UPGRADE, (server, player, handler, buf, responseSender) -> {
         String id = buf.readString(64);
         int slot = buf.readInt();
         server.execute(() -> {
            String result;
            try {
               result = RelicService.tryUpgrade(player, id, slot);
            } catch (Exception error) {
               result = "升级失败（服务器内部错误），请重试";
            }
            // 任务书推进：只有非创造模式的升级才计入（创造升级不更新《骨与火》）
            if (result != null && result.startsWith("升级成功")) {
               RelicChapters.onUpgrade(player, player.getAbilities().creativeMode);
            }
            sendResult(player, result);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(MAX_UPGRADE, (server, player, handler, buf, responseSender) -> {
         String id = buf.readString(64);
         int slot = buf.readInt();
         server.execute(() -> {
            String result;
            try {
               result = RelicService.tryMaxUpgrade(player, id, slot);
            } catch (Exception error) {
               result = "一键满级失败（服务器内部错误），请重试";
            }
            if (result != null && (result.startsWith("升级成功") || result.startsWith("已满级"))) {
               // 后门：一键满级在创造模式下也计入任务书（普通升级仍然只认非创造）
               RelicChapters.onUpgrade(player, player.getAbilities().creativeMode, RelicChapters.creativeMaxUpgradeCounts());
            }
            sendResult(player, result);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(ASCEND, (server, player, handler, buf, responseSender) ->
         server.execute(() -> {
            String result;
            try {
               if (!player.getAbilities().creativeMode) {
                  result = "一键成神仅创造模式可用";
               } else {
                  // 反复发放：每次都发一颗新的神心（进背包/掉落），再播一次纯演出（不动背包里的任何东西）
                  player.getInventory().offerOrDrop(RelicService.newVoidHeart());
                  boolean started = FusionCinematic.start(player, false);
                  result = "一键成神：已发放虚空神心"
                     + (started ? "，演出开始（升空 10 格 → 螺旋火焰 → 三道雷，约 30 秒）" : "（上一场演出还在进行，本次未重复触发）");
               }
            } catch (Exception error) {
               result = "一键成神失败：" + error;
            }
            sendResult(player, result);
         }));
      ServerPlayNetworking.registerGlobalReceiver(WAND_MODE, (server, player, handler, buf, responseSender) ->
         server.execute(() -> {
            String result;
            try {
               if (VoidHeartHandler.ownsHeart(player)) {
                  boolean now = VoidHeartHandler.toggleDestructiveMode(player);
                  result = now
                     ? "法杖模式：毁灭（1 个 TNT 效果 · 可破坏方块 / 点燃 TNT / 点燃地面）"
                     : "法杖模式：普通（不破坏地形）";
               } else {
                  result = "需要先拥有虚空神心才能切换毁灭模式";
               }
            } catch (Exception error) {
               result = "模式切换失败：" + error;
            }
            sendResult(player, result);
         }));
      ServerPlayNetworking.registerGlobalReceiver(MERGE_HEART, (server, player, handler, buf, responseSender) ->
         server.execute(() -> {
            String result;
            try {
               int[] best = RelicChapters.recordedAttributes(player);
               if (VoidHeartHandler.ownsHeart(player)) {
                  result = "你已经拥有虚空神心了";
               } else if (best[0] < RelicChapters.TIER_MAX || best[1] < RelicChapters.BONE_MAX
                  || best[2] < RelicChapters.SPELL_MAX) {
                  result = "三项主属性未全部满级（镐 " + best[0] + "/" + RelicChapters.TIER_MAX
                     + "　骨 " + best[1] + "/" + RelicChapters.BONE_MAX
                     + "　杖 " + best[2] + "/" + RelicChapters.SPELL_MAX + "）";
               } else if (FusionCinematic.start(player)) {
                  result = "融合开始：万骨归心 —— 升空 10 格，三道雷将至";
               } else {
                  result = "融合演出进行中…";
               }
               RelicChapters.sendInfo(player);
            } catch (Exception error) {
               result = "融合失败（服务器内部错误）：" + error;
            }
            sendResult(player, result);
         }));
      ServerPlayNetworking.registerGlobalReceiver(CHAPTER_REQ, (server, player, handler, buf, responseSender) ->
         server.execute(() -> RelicChapters.sendInfo(player)));
      ServerPlayNetworking.registerGlobalReceiver(MAX_ALL, (server, player, handler, buf, responseSender) ->
         server.execute(() -> {
            String result;
            try {
               int count = RelicService.maxAllCarried(player);
               int[] v = RelicChapters.attributes(player);
               int percent = RelicChapters.progressPercent(player);
               int chapter = RelicChapters.chapterFor(RelicChapters.progress(player));
               // 诊断输出：写进游戏日志，方便核对三项主属性是否都读到满值
               System.out.println("[BONEFIRE] MAX_ALL 拉满=" + count + " 件 | 镐材质 " + v[0] + "/" + RelicChapters.TIER_MAX
                  + " 骨头伤害 " + v[1] + "/" + RelicChapters.BONE_MAX
                  + " 法杖法强 " + v[2] + "/" + RelicChapters.SPELL_MAX
                  + " | 总进度 " + percent + "% → 第 " + chapter + " 章");
               if (count > 0) {
                  // 后门：一键满级拉完即计入任务书，并直接把三项历史最高拉满（形态互斥导致天然无法同时持有）
                  RelicChapters.backdoorFullProgress(player);
                  result = "一键满级：已拉满 " + count + " 件遗物（镐 " + v[0] + "/" + RelicChapters.TIER_MAX
                     + "　骨 " + v[1] + "/" + RelicChapters.BONE_MAX
                     + "　杖 " + v[2] + "/" + RelicChapters.SPELL_MAX
                     + " → 进度 " + RelicChapters.progressPercent(player) + "%）";
               } else {
                  result = "一键满级：身上没有可拉满的遗物（遗物放在箱子里不算）";
               }
            } catch (Exception error) {
               result = "一键满级失败（服务器内部错误）：" + error;
            }
            sendResult(player, result);
         }));
      ServerPlayNetworking.registerGlobalReceiver(GRANT, (server, player, handler, buf, responseSender) -> {
         String relic = buf.readString(64);
         server.execute(() -> grantCreative(player, relic));
      });
      ServerPlayNetworking.registerGlobalReceiver(
         WAND_SWING, (server, player, handler, buf, responseSender) -> server.execute(() -> WandSkillHandler.fireSwing(player))
      );
      ServerPlayNetworking.registerGlobalReceiver(WAND_SWITCH, (server, player, handler, buf, responseSender) -> {
         // 必须在 handler 内先读完 buf（netty 缓冲在 receiver 返回后即释放），再异步执行
         int pairCode = buf.readInt();
         server.execute(() -> {
            String result;
            try {
               result = RelicService.switchRelic(player, pairCode);
            } catch (Exception error) {
               result = "切换失败（服务器内部错误），请重试";
            }
            sendResult(player, result);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(GROWTH_UPGRADE, (server, player, handler, buf, responseSender) -> {
         int flag = buf.readInt();
         server.execute(() -> {
            String result;
            try {
               if (flag == 1 && player.getAbilities().creativeMode) {
                  result = ArcaneCoreGrowth.forceLevel(player, 30);
               } else if (flag == 1) {
                  result = "一键满级仅创造模式可用";
               } else {
                  result = ArcaneCoreGrowth.tryGrowthUpgrade(player);
               }
            } catch (Exception error) {
               result = "升级失败（服务器内部错误），请重试";
            }
            sendResult(player, result);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(GROWTH_INFO_REQ, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            String info;
            try {
               ArcaneCoreGrowth.Holder holder = ArcaneCoreGrowth.findCore(player);
               int level = holder == null ? 0 : ArcaneCoreGrowth.levelOf(holder.stack());
               int kills = ArcaneCoreGrowth.killsOf(player);
               info = "K|" + kills + "|" + level;
            } catch (Exception error) {
               info = "K|0|0";
            }
            sendResult(player, info);
         }));
      ServerPlayConnectionEvents.JOIN.register((Join)(handler, sender, server) -> {
         ServerPlayerEntity player = handler.player;
         server.execute(() -> {
             KeepInventoryStore.restoreOnJoin(player);
             grantStarterRelics(player);
             // 任务书：补齐第 1 章 + 回填已解锁章节的原版进度（内部同时同步客户端状态）
             RelicChapters.onJoin(player);
         });
      });
      CommandRegistrationCallback.EVENT
         .register(
            (CommandRegistrationCallback)(dispatcher, registryAccess, environment) -> {
               dispatcher.register(
                  (LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal("relic").requires(source -> source.hasPermissionLevel(2)))
                     .then(
                        ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal(
                                                "grant"
                                             )
                                             .executes(context -> grant(context, "all")))
                                          .then(CommandManager.literal("all").executes(context -> grant(context, "all"))))
                                       .then(CommandManager.literal("pickaxe").executes(context -> grant(context, "pickaxe"))))
                                    .then(CommandManager.literal("bone_axe").executes(context -> grant(context, "bone_axe")))
                                     .then(CommandManager.literal("bone").executes(context -> grant(context, "bone"))))
                                 .then(CommandManager.literal("bone_armor").executes(context -> grant(context, "bone_armor"))))
                              .then(CommandManager.literal("apple").executes(context -> grant(context, "apple"))))
                           .then(CommandManager.literal("arcane_core").executes(context -> grant(context, "arcane_core")))
                           .then(CommandManager.literal("max").executes(context -> grant(context, "max")))
            .then(CommandManager.literal("void_heart").executes(context -> grant(context, "void_heart")))
                     )
               );
               dispatcher.register(
                  (LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal("relic").requires(source -> source.hasPermissionLevel(2)))
                     .then(CommandManager.literal("core").then(CommandManager.argument("level", IntegerArgumentType.integer(1, 30)).executes(context -> {
                        ServerPlayerEntity target;
                        try {
                           target = ((ServerCommandSource)context.getSource()).getPlayer();
                        } catch (Exception var4) {
                           ((ServerCommandSource)context.getSource()).sendError(Text.literal("该命令只能由游戏内玩家执行。"));
                           return 0;
                        }

                        int level = IntegerArgumentType.getInteger(context, "level");
                        String result = ArcaneCoreGrowth.forceLevel(target, level);
                        ((ServerCommandSource)context.getSource()).sendFeedback(() -> Text.literal(result), false);
                        return 1;
                     })))
               );
            }
         );
   }

   private static void grantStarterRelics(ServerPlayerEntity player) {
      if (!player.getCommandTags().contains("bonefire_relics_pickaxe_granted")) {
         if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.PICKAXE)) {
            deliverRelics(player, List.of(RelicService.maxedCopy(RelicService.initialPickaxe())));
            player.sendMessage(Text.literal("[遗物成长] 已发放：无尽铁镐（满级）"), false);
         }

         player.addCommandTag("bonefire_relics_pickaxe_granted");
      }

      if (!player.getCommandTags().contains("bonefire_relics_bone_granted")) {
         if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE)) {
            deliverRelics(player, List.of(RelicService.maxedCopy(RelicService.initialBone())));
            player.sendMessage(Text.literal("[遗物成长] 已发放：战利品骨头（满级）"), false);
         }

         player.addCommandTag("bonefire_relics_bone_granted");
      }

      // 2026-09-09：开局不再发放骨斧（需要时由无尽铁镐 ⇄ 切出）；骨斧 tag 预留兼容老档
      if (!player.getCommandTags().contains("bonefire_relics_bone_axe_granted")) {
         player.addCommandTag("bonefire_relics_bone_axe_granted");
      }

      if (!player.getCommandTags().contains("bonefire_relics_guide_granted")) {
         deliverRelics(player, List.of(RelicService.initialGuideBook()));
         player.sendMessage(Text.literal("[遗物成长] 已发放：骨与火教程书"), false);
         player.addCommandTag("bonefire_relics_guide_granted");
      }

      if (!player.getCommandTags().contains("bonefire_relics_bone_armor_granted")) {
         if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            player.addCommandTag("bonefire_relics_visited_nether");
            List<ItemStack> maxedArmor = new ArrayList<>();
            for (ItemStack piece : RelicService.initialBoneArmor()) {
               maxedArmor.add(RelicService.maxedCopy(piece));
            }

            deliverRelics(player, maxedArmor);
            player.sendMessage(Text.literal("[遗物成长] 已发放：遗物骨甲一套（满级）"), false);
         }

         player.addCommandTag("bonefire_relics_bone_armor_granted");
      }

      if (!player.getCommandTags().contains("bonefire_relics_apple_granted")) {
         deliverRelics(player, List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE)));
         player.sendMessage(Text.literal("[遗物成长] 已发放：无限苹果"), false);
         player.addCommandTag("bonefire_relics_apple_granted");
      }

      if (!player.getCommandTags().contains("bonefire_relics_arcane_core_granted")) {
         if (ModItems.ARCANE_CORE != null) {
            deliverRelics(player, List.of(ArcaneCoreGrowth.withLevel(new ItemStack(ModItems.ARCANE_CORE), 30)));
            player.sendMessage(
               Text.literal("[遗物成长] 已发放：秘法核心 Lv.30（穿戴成长：属性 / 磁吸 / 斩杀 / 死而复生）"),
               false
            );
         }
         player.addCommandTag("bonefire_relics_arcane_core_granted");
      }
   }

   private static void grantCreative(ServerPlayerEntity player, String section) {
      if (player.getAbilities().creativeMode) {
         List<ItemStack> relics = (List<ItemStack>)(switch (section) {
            case "pickaxe" -> List.of(RelicService.initialPickaxe());
            case "bone" -> List.of(RelicService.initialBone());
            case "guide" -> List.of(RelicService.initialGuideBook());
            case "wand" -> List.of(RelicService.initialWand());
            case "bone_axe" -> List.of(RelicService.initialBoneAxe());
            case "apple" -> List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE));
            case "arcane_core" -> ModItems.ARCANE_CORE == null ? List.of() : List.of(new ItemStack(ModItems.ARCANE_CORE));
         case "void_heart" -> ModItems.RELIC_VOID_HEART == null ? List.of() : List.of(RelicService.newVoidHeart());
            case "bone_armor" -> {
               player.addCommandTag("bonefire_relics_visited_nether");
               yield RelicService.initialBoneArmor();
            }
            case "full" -> {
               player.addCommandTag("bonefire_relics_visited_nether");
               ArrayList<ItemStack> full = new ArrayList<>(RelicService.initialAllRelics());
               full.add(RelicService.initialWand());
               full.add(new ItemStack(ModItems.RELIC_INFINITE_APPLE));
               full.addAll(RelicService.initialBoneArmor());
               if (ModItems.ARCANE_CORE != null) {
                  full.add(new ItemStack(ModItems.ARCANE_CORE));
               }

               yield full;
            }
            default -> RelicService.initialAllRelics();
         });
         deliverRelics(player, relics);
         player.sendMessage(Text.literal("[遗物成长] 创造模式已发放对应遗物"), false);
      }
   }

   private static int grant(CommandContext<ServerCommandSource> context, String section) {
      ServerPlayerEntity player;
      try {
         player = ((ServerCommandSource)context.getSource()).getPlayer();
      } catch (Exception var6) {
         ((ServerCommandSource)context.getSource()).sendError(Text.literal("该命令只能由游戏内玩家执行。"));
         return 0;
      }
      List<ItemStack> relics = switch (section) {
         case "pickaxe" -> List.of(RelicService.initialPickaxe());
         case "bone" -> List.of(RelicService.initialBone());
         case "bone_axe" -> List.of(RelicService.initialBoneAxe());
         case "bone_armor" -> RelicService.initialBoneArmor();
         case "apple" -> List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE));
         case "arcane_core" -> ModItems.ARCANE_CORE == null ? List.of() : List.of(new ItemStack(ModItems.ARCANE_CORE));
         case "void_heart" -> ModItems.RELIC_VOID_HEART == null ? List.of() : List.of(RelicService.newVoidHeart());
         case "max" -> maxedRelics();
         default -> RelicService.initialAllRelics();
      };
      int dropped = deliverRelics(player, relics);
      String suffix = dropped == 0 ? "" : "（其中 " + dropped + " 件已掉落）";
      ((ServerCommandSource)context.getSource())
         .sendFeedback(() -> Text.literal("已发放 " + relics.size() + " 件" + sectionName(section) + "遗物。" + suffix), false);
      return relics.size();
   }

   /** 满级遗物一套：铁镐 / 战利品骨头 / 教程书 / 法杖 / 无限苹果 / 骨甲（全部满级）+ 秘法核心 Lv.30。 */
   private static List<ItemStack> maxedRelics() {
      List<ItemStack> relics = new ArrayList<>();
      relics.add(RelicService.maxedCopy(RelicService.initialPickaxe()));
      relics.add(RelicService.maxedCopy(RelicService.initialBone()));
      relics.add(RelicService.initialGuideBook());
      relics.add(RelicService.maxedCopy(RelicService.initialWand()));
      relics.add(new ItemStack(ModItems.RELIC_INFINITE_APPLE));
      for (ItemStack piece : RelicService.initialBoneArmor()) {
         relics.add(RelicService.maxedCopy(piece));
      }
      if (ModItems.ARCANE_CORE != null) {
         relics.add(ArcaneCoreGrowth.withLevel(new ItemStack(ModItems.ARCANE_CORE), 30));
      }
      return relics;
   }

   /** 统一的 RESULT 回包（截断至 64 字符），避免各 receiver 重复实现。 */
   private static void sendResult(ServerPlayerEntity player, String result) {
      if (ServerPlayNetworking.canSend(player, RESULT)) {
         String networkResult = result.length() <= 64 ? result : result.substring(0, 63) + "…";
         ServerPlayNetworking.send(player, RESULT, PacketByteBufs.create().writeString(networkResult, 64));
      }
   }

   private static int deliverRelics(ServerPlayerEntity player, List<ItemStack> relics) {
      int dropped = 0;

      for (ItemStack relic : relics) {
         player.getInventory().insertStack(relic);
         if (!relic.isEmpty()) {
            player.dropItem(relic, false);
            dropped++;
         }
      }

      player.getInventory().markDirty();
      return dropped;
   }

   private static String sectionName(String section) {
      return switch (section) {
         case "pickaxe" -> "无尽铁镐";
         case "bone" -> "战利品骨头";
         case "bone_armor" -> "遗物骨甲";
         case "bone_axe" -> "骨斧";
         case "max" -> "满级";
         default -> "开局";
      };
   }
}
