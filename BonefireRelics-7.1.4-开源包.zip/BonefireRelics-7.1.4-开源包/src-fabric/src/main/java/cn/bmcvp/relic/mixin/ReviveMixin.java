package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class ReviveMixin {
   @Inject(
      method = {"tryUseTotem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void bmcvp$arcaneRevive(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
      if ((Object)this instanceof ServerPlayerEntity player) {
         if (ArcaneCoreGrowth.tryRevive(player, source)) {
            cir.setReturnValue(true);
            cir.cancel();
         }
      }
   }
}
