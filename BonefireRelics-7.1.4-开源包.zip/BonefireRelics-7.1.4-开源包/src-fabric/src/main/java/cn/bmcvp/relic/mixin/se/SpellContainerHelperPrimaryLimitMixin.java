package cn.bmcvp.relic.mixin.se;

import cn.bmcvp.relic.ModItems;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.spell_engine.api.spell.Spell;
import net.spell_engine.api.spell.SpellContainer;
import net.spell_engine.internals.SpellContainerHelper;
import net.spell_engine.internals.SpellRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({SpellContainerHelper.class})
public abstract class SpellContainerHelperPrimaryLimitMixin {
   @Inject(
      method = {"addSpell(Lnet/minecraft/util/Identifier;Lnet/minecraft/item/ItemStack;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void bmcvp$limitPrimarySpell(Identifier spellId, ItemStack stack, CallbackInfo ci) {
      if (ModItems.ARCANE_CORE != null && stack.isOf(ModItems.ARCANE_CORE)) {
         Spell spell = SpellRegistry.getSpell(spellId);
         if (spell != null && "primary".equals(spell.group)) {
            if (containerHasPrimary(stack)) {
               ci.cancel();
            }
         }
      }
   }

   private static boolean containerHasPrimary(ItemStack stack) {
      SpellContainer container = SpellContainerHelper.containerFromItemStack(stack);
      if (container != null && !container.spell_ids.isEmpty()) {
         for (String id : container.spell_ids) {
            Spell existing = SpellRegistry.getSpell(Identifier.tryParse(id));
            if (existing != null && "primary".equals(existing.group)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }
}
