package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents.After;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public final class PickaxeSkillHandler {
   private static final Map<ServerPlayerEntity, Integer> MINED = new WeakHashMap<>();

   private PickaxeSkillHandler() {
   }

   public static void initialize() {
      PlayerBlockBreakEvents.AFTER.register((After)(world, player, pos, state, blockEntity) -> {
         if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
            ItemStack stack = serverPlayer.getMainHandStack();
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)) {
               int mined = MINED.merge(serverPlayer, 1, Integer::sum);
               if (mined >= 150) {
                  MINED.put(serverPlayer, 0);
                  serverPlayer.addStatusEffect(new StatusEffectInstance(ModEffects.SUPPLY, 100, 0));
               }
            }
         }
      });
   }
}
