package cn.bmcvp.relic.client;

import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;

/** 秘法核心·复活特效粒子：不死图腾式爆发，贴图为秘法核心图标 */
public final class ArcaneReviveParticle extends SpriteBillboardParticle {
   private final SpriteProvider spriteProvider;

   ArcaneReviveParticle(
      ClientWorld world,
      double x,
      double y,
      double z,
      double vx,
      double vy,
      double vz,
      SpriteProvider spriteProvider
   ) {
      super(world, x, y, z, vx, vy, vz);
      this.spriteProvider = spriteProvider;
      this.setSprite(spriteProvider.getSprite(this.random));
      this.maxAge = 60;
      this.scale(1.6F);
      this.velocityY = 0.16;
      this.setAlpha(0.9F);
      this.collidesWithWorld = false;
   }

   @Override
   public ParticleTextureSheet getType() {
      return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public void tick() {
      super.tick();
      this.velocityY *= 0.95;
      if (this.age > this.maxAge - 16) {
         this.setAlpha(Math.max(0.0F, this.alpha - 0.07F));
      }
   }
}
