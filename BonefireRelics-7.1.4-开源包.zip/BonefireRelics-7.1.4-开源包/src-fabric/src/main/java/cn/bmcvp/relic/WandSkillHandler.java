package cn.bmcvp.relic;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDamage;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.spell_power.api.SpellPower;
import net.spell_power.api.SpellSchool;
import net.spell_power.api.SpellSchools;

public final class WandSkillHandler {
   public static final float DAMAGE_PER_SPELL = 1.0F;
   public static final int FIRE_PUNISH_SPELL = 15;
   public static final float FIRE_PUNISH_PERCENT = 0.05F;
   public static final float LAUNCH_SPEED = 2.0F;
   public static final float SOUL_DAMAGE_BONUS = 5.0F;
   public static final float MAX_SOUL_DAMAGE = 45.0F;
   public static final TagKey<DamageType> SPELL_POWER_ALL = TagKey.of(RegistryKeys.DAMAGE_TYPE, new Identifier("spell_power", "all"));

   public static float allSpellPowerBonus(ServerPlayerEntity player) {
      if (!FabricLoader.getInstance().isModLoaded("spell_power")) {
         return 0.0F;
      } else {
         float total = 0.0F;

         for (SpellSchool school : SpellSchools.all()) {
            total += (float)SpellPower.getSpellPower(school, player).baseValue();
         }

         return total * 1.0F;
      }
   }

   public static float totalSpellPower(ServerPlayerEntity player) {
      if (!FabricLoader.getInstance().isModLoaded("spell_power")) {
         return 0.0F;
      } else {
         float total = 0.0F;

         for (SpellSchool school : SpellSchools.all()) {
            total += (float)SpellPower.getSpellPower(school, player).baseValue();
         }

         return total;
      }
   }

   public static float spellBookAmplify(ServerPlayerEntity player, DamageSource source) {
      if (!FabricLoader.getInstance().isModLoaded("spell_power")) {
         return 1.0F;
      } else {
         return !source.isIn(SPELL_POWER_ALL) ? 1.0F : 1.0F + totalSpellPower(player) * 0.003F;
      }
   }

   public static DamageSource trueDamageSource(ServerPlayerEntity owner) {
      RegistryKey<DamageType> key = RegistryKey.of(RegistryKeys.DAMAGE_TYPE, new Identifier("bonefire_relics", "true_magic"));
      RegistryEntry<DamageType> entry = owner.getWorld().getRegistryManager().get(RegistryKeys.DAMAGE_TYPE).entryOf(key);
      return new DamageSource(entry, owner);
   }

   private WandSkillHandler() {
   }

   public static void fireSwing(ServerPlayerEntity player) {
      fire(player);
   }

   public static void initialize() {
      // 潜行 + 右键（法杖）→ 切换神心毁灭模式：可破坏方块 / 点燃 TNT / 点燃地面（1 个 TNT 效果）
      net.fabricmc.fabric.api.event.player.UseItemCallback.EVENT.register((player, world, hand) -> {
         ItemStack stack = player.getStackInHand(hand);
         if (!world.isClient && player.isSneaking() && stack.getItem() == ModItems.MAGIC_WAND
            && VoidHeartHandler.ownsHeart(player)) {
            boolean now = VoidHeartHandler.toggleDestructiveMode(player);
            player.sendMessage(net.minecraft.text.Text.literal(now
               ? "法杖模式：毁灭（1 个 TNT 效果 · 可破坏方块 / 点燃 TNT / 点燃地面）"
               : "法杖模式：普通（不破坏地形）"), false);
            return net.minecraft.util.TypedActionResult.success(stack);
         }
         return net.minecraft.util.TypedActionResult.pass(stack);
      });
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((AllowDamage)(target, source, amount) -> {
         if (amount <= 0.0F) {
            return true;
         } else if (source.getAttacker() instanceof ServerPlayerEntity player) {
            if (target == player || target.isRemoved()) {
               return true;
            } else if (!source.isOf(DamageTypes.PLAYER_ATTACK)) {
               return true;
            } else {
               ItemStack stack = player.getMainHandStack();
               return !RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND);
            }
         } else {
            return true;
         }
      });
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         if (server.getTicks() % 20 == 0) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
               applyWandSpellPower(p);
            }
         }
      });
   }

   private static void applyWandSpellPower(ServerPlayerEntity player) {
      if (FabricLoader.getInstance().isModLoaded("spell_power")) {
         ItemStack stack = player.getMainHandStack();
         boolean holds = RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND);

         for (SpellSchool school : new SpellSchool[]{SpellSchools.FIRE, SpellSchools.FROST, SpellSchools.ARCANE}) {
            EntityAttributeInstance inst = player.getAttributeInstance(school.attribute);
            if (inst != null) {
               UUID id = UUID.nameUUIDFromBytes(("bonefire_relics:wand_power:" + school.id).getBytes(StandardCharsets.UTF_8));
               if (holds) {
                  if (inst.getModifier(id) == null) {
                     inst.addPersistentModifier(new EntityAttributeModifier(id, "Bonefire Wand " + school.id, 30.0, Operation.ADDITION));
                  }
               } else if (inst.getModifier(id) != null) {
                  inst.removeModifier(id);
               }
            }
         }
      }
   }

   private static void fire(ServerPlayerEntity player) {
      ItemStack stack = player.getMainHandStack();
      if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
         int spell = RelicService.value(stack, "spell");
         int explosion = RelicService.value(stack, "explosion");
         boolean soul = RelicService.value(stack, "tier") == 1;
         ServerWorld world = player.getServerWorld();
         float spellPower = allSpellPowerBonus(player);
         float unlock = Math.min(spell, 30) / 30.0F; // 法强等级线性解锁 spell 系数（0 级 0% → 30 级 100%）
         float damage;
         if (soul) {
            // 二阶段（灵魂杖）：前置=法强满级，基座 15 + 三系全额
            damage = 15.0F + spellPower;
         } else {
            // 一阶段：未升级只有基础魔法 6（不吃 spell 加成），升级后按等级解锁 spell 系数
            damage = 6.0F + unlock * spellPower;
         }

         LivingEntity melee = meleeTarget(player, 2.6);
         if (melee != null) {
            RelicFireballEntity.explodeAt(world, player, melee, damage, spell, explosion, soul);
         } else {
            RelicFireballEntity fb = new RelicFireballEntity(world, player, damage, spell, explosion, soul);
            fb.setVelocity(player, player.getPitch(), player.getYaw(), 0.0F, 2.0F, 0.0F);
            world.spawnEntity(fb);
            world.playSound(
               null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F
            );
         }
      }
   }

   private static LivingEntity meleeTarget(ServerPlayerEntity player, double range) {
      ServerWorld world = player.getServerWorld();
      Vec3d eye = player.getEyePos();
      Vec3d dir = player.getRotationVec(1.0F).normalize();
      Box box = player.getBoundingBox().expand(range);
      LivingEntity best = null;
      double bestDistSq = range * range;

      for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, box, ex -> ex != player && ex.isAlive() && !ex.isRemoved())) {
         Vec3d center = e.getPos().add(0.0, (double)e.getHeight() * 0.5, 0.0);
         Vec3d to = center.subtract(eye);
         double distSq = to.lengthSquared();
         if (!(distSq > bestDistSq) && !(to.normalize().dotProduct(dir) < 0.35)) {
            best = e;
            bestDistSq = distSq;
         }
      }

      return best;
   }

   public static void lifestealFrom(ServerPlayerEntity player, float damage) {
      ItemStack stack = player.getMainHandStack();
      int level = RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND) ? RelicService.value(stack, "wfortune") : 0;
      if (level > 0) {
         LifestealHandler.applyWandLifesteal(player, damage, level);
      }
   }
}
