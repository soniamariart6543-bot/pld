package cn.bmcvp.relic;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.entity.EntityType.Builder;

public final class RelicEntities {
   public static final EntityType<RelicFireballEntity> RELIC_FIREBALL = (EntityType<RelicFireballEntity>)Registry.register(
      Registries.ENTITY_TYPE,
      new Identifier("bonefire_relics", "relic_fireball"),
      Builder.<RelicFireballEntity>create(RelicFireballEntity::new, SpawnGroup.MISC).setDimensions(0.6F, 0.6F).build("relic_fireball")
   );

   private RelicEntities() {
   }

   public static void initialize() {
   }
}
