package cn.bmcvp.relic.client;

import cn.bmcvp.relic.ArcaneCoreGrowth;
import cn.bmcvp.relic.ArcaneCoreTooltip;
import cn.bmcvp.relic.ArmorOvercapConfig;
import cn.bmcvp.relic.BmcvpRelicUpgrades;
import cn.bmcvp.relic.ModItems;
import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;

public class RelicUpgradeScreen extends Screen {
   private static final int RESULT_REFRESH_DELAY_TICKS = 5;
   private static String lastResult = "选择一件遗物";
   private static RelicUpgradeScreen activeScreen;
   private final Screen parent;
   private RelicUpgradeScreen.View view = RelicUpgradeScreen.View.MODULES;
   private UpgradeDefinition.RelicType category;
   /** 遗物主界面页码：0=升级 1=发放。 */
   private int modulePage;
   private int armorSlot = -1;
   private boolean refreshRequested;
   private int refreshDelayTicks;
   /** 发出请求后等待服务端回包的超时计数（>0 递减）；到 0 仍未收到 RESULT 时自动按背包实况刷新兜底。 */
   private int pendingResultTicks;
   private int growthInfoCounter;
   private int growthKills;
   private int growthCoreLevel = 1;
   private int lastBuiltGrowthLevel = -1;
   private final MarqueeTextWidget statusText = new MarqueeTextWidget(Text.literal(lastResult), 0, 0, 300, 12);
   private final MarqueeTextWidget overcapStatusText = new MarqueeTextWidget(Text.literal(""), 0, 0, 400, 12);
   private final Map<RelicUpgradeScreen.Attribute, MarqueeTextWidget> cardProgression = new EnumMap<>(RelicUpgradeScreen.Attribute.class);
   private final Map<RelicUpgradeScreen.Attribute, MarqueeTextWidget> cardRequirement = new EnumMap<>(RelicUpgradeScreen.Attribute.class);
   private final Map<RelicUpgradeScreen.Attribute, MarqueeTextWidget> cardCosts = new EnumMap<>(RelicUpgradeScreen.Attribute.class);
   private final MarqueeTextWidget familyCostMarquee = new MarqueeTextWidget(Text.literal(""), 0, 0, 180, 10);
   private final MarqueeTextWidget familyProgressionMarquee = new MarqueeTextWidget(Text.literal(""), 0, 0, 180, 10);
   private final MarqueeTextWidget familyRequirementMarquee = new MarqueeTextWidget(Text.literal(""), 0, 0, 180, 10);
   private Map<Item, Integer> inventoryCounts = Map.of();
   private static final int ARMOR_PANEL_W = 430;
   private static final int ARMOR_PANEL_H = 264;
   private static final int ARMOR_COL1_X = 10;
   private static final int ARMOR_COL2_X = 216;
   private static final int ARMOR_CARD_W = 204;
   private static final int ARMOR_CARD_H = 58;
   private static final int ARMOR_CARD_GAP = 6;
   private static final int ARMOR_CARDS_TOP = 44;
   private static final int ARMOR_BOTTOM_Y = 240;
   private static final int FAMILY_PANEL_W = 430;
   private static final int FAMILY_PANEL_H = 200;

   public RelicUpgradeScreen(Screen parent) {
      super(Text.literal("遗物升级"));
      this.parent = parent;
   }

   public static void receiveServerResult(String text) {
      if (text.startsWith("K|")) {
         String[] parts = text.split("\\|");
         if (parts.length >= 3) {
            try {
               int kills = Integer.parseInt(parts[1]);
               int level = Integer.parseInt(parts[2]);
               ArcaneCoreTooltip.killsCache = kills;
               if (activeScreen != null) {
                  activeScreen.growthKills = kills;
                  activeScreen.growthCoreLevel = Math.max(1, Math.min(30, level));
               }
            } catch (NumberFormatException var4) {
            }
         }
      } else {
         lastResult = text;
         if (activeScreen != null) {
            activeScreen.markResultReceived();
            activeScreen.requestRefreshAfterInventorySync();
         }
      }
   }

   private void requestRefreshAfterInventorySync() {
      this.refreshRequested = true;
      this.refreshDelayTicks = 5;
   }

   /** 主动请求已发出：开启 3 秒回包超时兜底。 */
   private void markResultPending() {
      this.pendingResultTicks = 60;
   }

   /** 收到服务端 RESULT 回包：取消超时兜底。 */
   private void markResultReceived() {
      this.pendingResultTicks = 0;
   }

   protected void init() {
      activeScreen = this;
      if (this.view == RelicUpgradeScreen.View.MODULES) {
         this.initModuleButtons();
      } else if (this.view == RelicUpgradeScreen.View.SLOT_SELECT) {
         this.initSlotSelectButtons();
      } else if (this.view == RelicUpgradeScreen.View.FAMILY_SELECT) {
         this.initFamilySelectButtons();
      } else if (this.view == RelicUpgradeScreen.View.GROWTH) {
         this.initGrowthButtons();
      } else {
         this.initAttributeButtons();
      }
      // 每个升级界面都挂上「一键满级」（创造模式显示）：口径 = 身上所有遗物一次拉满，并计入任务书
      this.addMaxAllButton();
   }

   /** 一键满级（全部遗物）按钮：放在面板标题栏右侧，所有视图通用。 */
   private void addMaxAllButton() {
      if (!this.isCreative()) {
         return;
      }
      int left = this.width / 2 - 130;
      int top = this.height / 2 - 100;
      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("一键满级"), b -> this.sendMaxAll())
            .tooltip(Tooltip.of(Text.literal("创造模式：把身上所有遗物一次拉满（服务端执行，会计入《骨与火》任务书）")))
            .dimensions(left + 168, top + 3, 88, 18)
            .build()
      );
   }

   private void sendMaxAll() {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         ClientPlayNetworking.send(BmcvpRelicUpgrades.MAX_ALL, PacketByteBufs.create());
         this.markResultPending();
         lastResult = "一键满级（全部遗物）请求已发送…";
         this.requestRefreshAfterInventorySync();
      }
   }

   public void tick() {
      super.tick();
      this.refreshInventoryCounts();
      if (this.view == RelicUpgradeScreen.View.GROWTH) {
         if (this.growthInfoCounter++ % 20 == 0) {
            this.sendGrowthInfoRequest();
         }

         if (this.lastBuiltGrowthLevel != this.growthCoreLevel) {
            this.lastBuiltGrowthLevel = this.growthCoreLevel;
            this.rebuild();
            return;
         }
      }

      if (this.pendingResultTicks > 0) {
         if (--this.pendingResultTicks <= 0) {
            this.pendingResultTicks = 0;
            // 服务端 3 秒内未回包：按本地背包实况重建界面，杜绝“请求已发送…”永久悬挂
            if (this.view == RelicUpgradeScreen.View.MODULES || this.view == RelicUpgradeScreen.View.ATTRIBUTES) {
               lastResult = "请求无响应：已按背包实况刷新，请重试";
               this.refreshRequested = true;
               this.refreshDelayTicks = 3;
            }
         }
      }

      if (this.refreshRequested) {
         if (this.refreshDelayTicks-- <= 0) {
            this.refreshRequested = false;
            if (this.client != null
               && this.client.player != null
               && (this.view == RelicUpgradeScreen.View.ATTRIBUTES || this.view == RelicUpgradeScreen.View.MODULES)) {
               this.rebuild();
            }
         }
      }
   }

   private void initSlotSelectButtons() {
      int left = this.width / 2 - 150;
      int top = this.height / 2 - 82;
      String[] names = new String[]{"头盔", "胸甲", "护腿", "靴子"};

      for (int i = 0; i < 4; i++) {
         int slot = i;
         this.addDrawableChild(ButtonWidget.builder(Text.literal(names[i]), b -> {
            this.armorSlot = slot;
            this.view = RelicUpgradeScreen.View.ATTRIBUTES;
            this.rebuild();
         }).dimensions(left + 14, top + 46 + i * 30, 130, 24).build());
      }

      this.addDrawableChild(ButtonWidget.builder(Text.literal("返回"), b -> {
         this.view = RelicUpgradeScreen.View.MODULES;
         this.category = null;
         this.rebuild();
      }).dimensions(this.width / 2 - 40, top + 170, 80, 20).build());
   }

   private void initModuleButtons() {
      int left = this.width / 2 - 210;
      int top = this.height / 2 - 82;
      if (this.modulePage == 1) {
         this.initGrantPageButtons(left, top);
      } else {
         boolean isWand = "magic_wand".equals(this.currentBoneOrWandKind());
         boolean isAxe = "bone_axe".equals(this.currentPickaxeOrAxeKind());
         // 行1：可转化对（无尽铁镐⇄骨斧 / 战利品骨头⇄魔法法杖）
         this.addDrawableChild(
            this.moduleButton(
               left + 10,
               top + 34,
               150,
               isAxe ? ModItems.RELIC_BONE_AXE : ModItems.RELIC_IRON_PICKAXE,
               isAxe ? UpgradeDefinition.RelicType.AXE : UpgradeDefinition.RelicType.PICKAXE
            )
         );
         this.addDrawableChild(ButtonWidget.builder(Text.literal("⇄"), b -> {
            this.sendRelicSwitch(1);
            lastResult = "切换请求已发送…（无尽铁镐⇄骨斧）";
            this.requestRefreshAfterInventorySync();
         }).dimensions(left + 160, top + 34, 20, 56).build());
         this.addDrawableChild(
            this.moduleButton(
               left + 190,
               top + 34,
               150,
               isWand ? ModItems.MAGIC_WAND : ModItems.RELIC_BONE,
               isWand ? UpgradeDefinition.RelicType.WAND : UpgradeDefinition.RelicType.BONE
            )
         );
         this.addDrawableChild(ButtonWidget.builder(Text.literal("⇄"), b -> {
            this.sendRelicSwitch(0);
            lastResult = "切换请求已发送…（骨头⇄法杖）";
            this.requestRefreshAfterInventorySync();
         }).dimensions(left + 340, top + 34, 20, 56).build());
         // 行2：遗物骨甲 / 秘法核心成长
         this.addDrawableChild(this.moduleButton(left + 10, top + 98, 150, ModItems.RELIC_BONE_CHESTPLATE, UpgradeDefinition.RelicType.BONE_ARMOR));
         this.addDrawableChild(ButtonWidget.builder(Text.literal(""), b -> {
            this.view = RelicUpgradeScreen.View.GROWTH;
            this.rebuild();
         }).dimensions(left + 190, top + 98, 150, 56).build());
         // 底部：返回 + 状态
         this.addDrawableChild(
            ButtonWidget.builder(Text.literal("返回"), b -> this.client.setScreen(this.parent))
               .dimensions(left + 356, top + 166, 54, 20)
               .build()
         );
      }

      this.addModulePageToggle(left, top);
   }

   /** 页②（发放）：创造模式集中发放按钮；非创造不生成按钮（渲染层给出灰提示）。 */
   private void initGrantPageButtons(int left, int top) {
      if (!this.isCreative()) {
         return;
      }
      // 创造模式「一键成神」：反复发放神心 + 融合演出。
      // 位置＝发放页最下一整行（y=top+156）：上方按钮网格末行到 top+152，底部状态栏在 top+176，两边都不重叠；
      // 也刻意避开右上角翻页按钮（left+330, top+3）——2026-09-13 被压过一次，别挪回顶部。
      this.addDrawableChild(ButtonWidget.builder(Text.literal("一键成神（发放神心 + 融合演出 · 可反复）"), b -> {
         this.sendAscend();
         lastResult = "一键成神请求已发送…";
         this.requestRefreshAfterInventorySync();
      })
      .tooltip(Tooltip.of(Text.literal("创造模式：每次点击发放一颗虚空神心，并播放融合演出\n（升空 10 格 → 螺旋火焰漩涡 → 三道雷，约 30 秒）\n可反复使用；演出为纯观赏，不会吞掉背包/身上的遗物。")))
      .dimensions(left + 14, top + 156, 392, 18)
      .build());
      int xL = left + 14;
      int xR = left + 216;
      int gy = top + 36;
      String[][] leftCol = new String[][]{{"bone", "发放：战利品骨头"}, {"guide", "发放：骨与火"}, {"wand", "发放：魔法法杖"}, {"pickaxe", "发放：无尽铁镐"}, {"bone_axe", "发放：骨斧"}};

      for (int i = 0; i < leftCol.length; i++) {
         String key = leftCol[i][0];
         String label = leftCol[i][1];
         this.addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> this.sendGrant(key)).dimensions(xL, gy + i * 24, 188, 20).build());
      }

      int row = 0;
      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("发放：遗物骨甲"), b -> this.sendGrant("bone_armor")).dimensions(xR, gy + row++ * 24, 188, 20).build()
      );
      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("发放：全套遗物"), b -> this.sendGrant("full"))
            .tooltip(Tooltip.of(Text.literal("创造模式一次发放全部遗物（含秘法核心，未注册时自动省略）")))
            .dimensions(xR, gy + row++ * 24, 188, 20)
            .build()
      );
      if (ModItems.ARCANE_CORE != null) {
         this.addDrawableChild(
            ButtonWidget.builder(Text.literal("发放：秘法核心"), b -> this.sendGrant("arcane_core"))
               .tooltip(Tooltip.of(Text.literal("创造模式发放法术书「秘法核心」（可装载 6 个 wizards 卷册系法术）")))
               .dimensions(xR, gy + row++ * 24, 188, 20)
               .build()
         );
      }

      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("返回"), b -> this.client.setScreen(this.parent)).dimensions(xR, gy + row * 24, 188, 20).build()
      );
   }
   private void addModulePageToggle(int left, int top) {
      String label = this.modulePage == 1 ? "◀ 升级" : "发放 ▸";
      this.addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
         this.modulePage = this.modulePage == 1 ? 0 : 1;
         this.category = null;
         this.rebuild();
      }).dimensions(left + 330, top + 3, 76, 16).build());
   }

   private boolean isCreative() {
      return this.client != null && this.client.player != null && this.client.player.getAbilities().creativeMode;
   }

   private void sendGrant(String relic) {
      ClientPlayNetworking.send(BmcvpRelicUpgrades.GRANT, PacketByteBufs.create().writeString(relic, 64));
      lastResult = "创造模式发放请求已发送…";
      this.requestRefreshAfterInventorySync();
      this.markResultPending();
   }

   private ButtonWidget moduleButton(int x, int y, int width, Item icon, UpgradeDefinition.RelicType type) {
      return ButtonWidget.builder(Text.literal(""), b -> this.openCategory(type)).dimensions(x, y, width, 56).build();
   }

   private void openCategory(UpgradeDefinition.RelicType type) {
      this.category = type;
      if (type == UpgradeDefinition.RelicType.BONE_ARMOR) {
         this.armorSlot = -1;
         this.view = RelicUpgradeScreen.View.SLOT_SELECT;
      } else {
         this.armorSlot = -1;
         this.view = RelicUpgradeScreen.View.ATTRIBUTES;
      }

      lastResult = this.categoryTitle(type);
      this.rebuild();
   }

   private void initAttributeButtons() {
      // 法杖页专属：爆炸模式切换按钮（神心权能）
      if (this.category == UpgradeDefinition.RelicType.WAND) {

         this.addDrawableChild(ButtonWidget.builder(Text.literal("切换法杖爆炸模式"), b -> {
            this.sendWandMode();
            lastResult = "模式切换请求已发送…";
            this.requestRefreshAfterInventorySync();
         })
         .tooltip(Tooltip.of(Text.literal("拥有虚空神心后可切换：毁灭模式 = 火球按 1 个 TNT 结算\n（可破坏方块 / 点燃 TNT / 点燃地面）。服务端校验。")))
         .dimensions(this.width / 2 - 130, this.height / 2 - 97, 160, 18)
         .build());
      }
      if (this.category == UpgradeDefinition.RelicType.BONE_ARMOR) {
         this.initArmorColumnButtons();
      } else {
         this.initRelicColumnButtons();
      }
   }

   /** 发送遗物形态切换（0=骨头⇄法杖，1=铁镐⇄骨斧）。 */
   private void sendRelicSwitch(int pairCode) {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         PacketByteBuf buf = PacketByteBufs.create();
         buf.writeInt(pairCode);
         ClientPlayNetworking.send(BmcvpRelicUpgrades.WAND_SWITCH, buf);
         this.markResultPending();
      }
   }

   private void initProtectionFamilyButtons(int left, int top, RelicUpgradeScreen.RelicSelection selection, boolean conflict, boolean hasTarget) {
      int y = top + 49 + this.attributesFor(this.category).size() * 62 + 6;
      String[] names = new String[]{"火焰保护", "爆炸保护", "弹射物保护"};
      int[] types = new int[]{1, 2, 3};

      for (int i = 0; i < 3; i++) {
         int ptype = types[i];
         UpgradeDefinition route = hasTarget ? this.protectionFamilyRoute(selection.stack(), ptype) : null;
         int current = hasTarget ? this.currentProtectionLevel(selection.stack(), ptype) : 0;
         String label = route == null ? names[i] + " 已满" : names[i] + " → " + this.roman(current + 1);
         ButtonWidget button = ButtonWidget.builder(Text.literal(label), pressed -> this.sendUpgrade(route))
            .dimensions(left + 18 + i * 130, y, 126, 20)
            .build();
         button.active = route != null && hasTarget && !conflict;
         this.addDrawableChild(button);
      }
   }

   private void sendUpgrade(UpgradeDefinition route) {
      if (route != null) {
         PacketByteBuf out = PacketByteBufs.create();
         out.writeString(route.id(), 64);
         out.writeInt(this.armorSlot);
         ClientPlayNetworking.send(BmcvpRelicUpgrades.UPGRADE, out);
         this.markResultPending();
         lastResult = this.isCreative() ? "创造模式：升级请求已发送（免费）…" : "升级请求已发送…";
         this.requestRefreshAfterInventorySync();
      }
   }

   private void sendMaxUpgrade(UpgradeDefinition route) {
      if (route != null) {
         PacketByteBuf out = PacketByteBufs.create();
         out.writeString(route.id(), 64);
         out.writeInt(this.armorSlot);
         ClientPlayNetworking.send(BmcvpRelicUpgrades.MAX_UPGRADE, out);
         this.markResultPending();
         lastResult = "创造模式：一键满级请求已发送…";
         this.requestRefreshAfterInventorySync();
      }
   }

   private void addMaxUpgradeButton(int x, int y, int width, int height, UpgradeDefinition route, boolean active) {
      if (this.isCreative() && route != null) {
         ButtonWidget button = ButtonWidget.builder(Text.literal("满级"), pressed -> this.sendMaxUpgrade(route))
            .tooltip(Tooltip.of(Text.literal("创造模式：一键将该项拉满（服务端校验，免费）")))
            .dimensions(x, y, width, height)
            .build();
         button.active = active;
         this.addDrawableChild(button);
      }
   }

   private void refreshInventoryCounts() {
      if (this.client != null && this.client.player != null) {
         Map<Item, Integer> counts = new HashMap<>();

         for (ItemStack stack : this.client.player.getInventory().main) {
            if (!stack.isEmpty()) {
               counts.merge(stack.getItem(), stack.getCount(), Integer::sum);
            }
         }

         ItemStack offHand = this.client.player.getOffHandStack();
         if (!offHand.isEmpty()) {
            counts.merge(offHand.getItem(), offHand.getCount(), Integer::sum);
         }

         this.inventoryCounts = counts;
      } else {
         this.inventoryCounts = Map.of();
      }
   }

   private int availableCostItems(Item item) {
      return this.inventoryCounts.getOrDefault(item, 0);
   }

   private RelicUpgradeScreen.RelicSelection relicSelection(UpgradeDefinition.RelicType type) {
      if (this.client != null && this.client.player != null) {
         ItemStack single = null;
         int count = 0;

         for (ItemStack stack : this.client.player.getInventory().main) {
            if (RelicService.isRelicReadOnly(stack, type) && (type != UpgradeDefinition.RelicType.BONE_ARMOR || this.matchesSlot(stack, this.armorSlot))) {
               count++;
               single = stack;
            }
         }

         ItemStack offHand = this.client.player.getOffHandStack();
         if (RelicService.isRelicReadOnly(offHand, type) && (type != UpgradeDefinition.RelicType.BONE_ARMOR || this.matchesSlot(offHand, this.armorSlot))) {
            count++;
            single = offHand;
         }

         if (type == UpgradeDefinition.RelicType.BONE_ARMOR) {
            if (this.armorSlot >= 0 && this.armorSlot < 4) {
               // UI 部位语义 0=头盔..3=靴子 → PlayerInventory.armor 索引镜像（0=靴子..3=头盔）
               int armorIndex = 3 - this.armorSlot;
               ItemStack worn = (ItemStack)this.client.player.getInventory().armor.get(armorIndex);
               if (RelicService.isRelicReadOnly(worn, type) && this.matchesSlot(worn, this.armorSlot)) {
                  count++;
                  single = worn;
               }
            } else {
               // 装备中也能升级：未指定部位时同样把四件装备栏骨甲计入检索
               for (ItemStack worn : this.client.player.getInventory().armor) {
                  if (RelicService.isRelicReadOnly(worn, type)) {
                     count++;
                     single = worn;
                  }
               }
            }
         }

         return new RelicUpgradeScreen.RelicSelection(count == 1 ? single : null, count);
      } else {
         return new RelicUpgradeScreen.RelicSelection(null, 0);
      }
   }

   private String currentBoneOrWandKind() {
      if (this.client != null && this.client.player != null) {
         for (ItemStack stack : this.client.player.getInventory().main) {
            String kind = relicKind(stack);
            if ("bone".equals(kind) || "magic_wand".equals(kind)) {
               return kind;
            }
         }

         String offHand = relicKind(this.client.player.getOffHandStack());
         return !"bone".equals(offHand) && !"magic_wand".equals(offHand) ? null : offHand;
      } else {
         return null;
      }
   }

   private String currentPickaxeOrAxeKind() {
      if (this.client != null && this.client.player != null) {
         for (ItemStack stack : this.client.player.getInventory().main) {
            String kind = relicKind(stack);
            if ("pickaxe".equals(kind) || "bone_axe".equals(kind)) {
               return kind;
            }
         }

         String offHand = relicKind(this.client.player.getOffHandStack());
         return !"pickaxe".equals(offHand) && !"bone_axe".equals(offHand) ? null : offHand;
      } else {
         return null;
      }
   }

   private static String relicKind(ItemStack stack) {
      return !stack.isEmpty() && stack.hasNbt() && stack.getNbt().contains("bonefire_relics", 10)
         ? stack.getNbt().getCompound("bonefire_relics").getString("item")
         : "";
   }

   private boolean matchesSlot(ItemStack stack, int slot) {
      if (slot >= 0 && stack.hasNbt()) {
         String kind = stack.getNbt().getCompound("bonefire_relics").getString("item");
         String[] slots = new String[]{"helmet", "chestplate", "leggings", "boots"};
         return kind.equals("bone_" + slots[slot]);
      } else {
         return false;
      }
   }

   private UpgradeDefinition nextRoute(RelicUpgradeScreen.Attribute attribute, ItemStack stack) {
      if (stack != null && stack.hasNbt()) {
         String prefix = "ba_";
         UpgradeDefinition.RelicType cat = this.category;

         String routeId = switch (attribute) {
            case MATERIAL -> {
               int v = RelicService.value(stack, "tier");
               switch (cat) {
                  case BONE_ARMOR:
                     yield v < 2 ? "bam" + (v + 1) : null;
                  case WAND:
                     yield v < 1 ? "soul" + (v + 1) : null;
                  case AXE:
                     yield v < 2 ? "axe_m" + (v + 1) : null;
                  default:
                     yield v < 6 ? "m" + (v + 1) : null;
               }
            }
            case ARMOR -> {
               int v = RelicService.value(stack, "armor");
               int cap = RelicService.armorCap(RelicService.value(stack, "tier"));
               yield v < cap ? prefix + "armor" + (v + 1) : null;
            }
            case EFFICIENCY -> {
               int v = RelicService.value(stack, "efficiency");
               if (cat == UpgradeDefinition.RelicType.PICKAXE) {
                  yield v < 5 ? "eff" + (v + 1) : null;
               } else if (cat == UpgradeDefinition.RelicType.AXE) {
                  yield v < 10 ? "axe_eff" + (v + 1) : null;
               } else {
                  yield v < 5 ? prefix + "prot" + (v + 1) : null;
               }
            }
            case FORTUNE -> {
               int v = RelicService.value(stack, "fortune");
               if (cat == UpgradeDefinition.RelicType.PICKAXE) {
                  yield v < 10 ? "fortune" + (v + 1) : null;
               } else if (cat == UpgradeDefinition.RelicType.AXE) {
                  yield v < 10 ? "axe_for" + (v + 1) : null;
               } else {
                  yield v < 10 ? prefix + "tough" + (v + 1) : null;
               }
            }
            case DAMAGE -> {
               int v = RelicService.value(stack, "damage");
               if (cat == UpgradeDefinition.RelicType.AXE) {
                  yield v < 32 ? "axe_g" + (v + 1) : null;
               } else {
                  yield v < 41 ? "d" + (v + 1) : null;
               }
            }
            case FIRE -> {
               int v = RelicService.value(stack, "fire");
               yield cat == UpgradeDefinition.RelicType.BONE ? (v < 2 ? "fire" + (v + 1) : null) : (v < 3 ? prefix + "thorn" + (v + 1) : null);
            }
            case LOOTING -> {
               int v = RelicService.value(stack, "looting");
               yield v < 10 ? "loot" + (v + 1) : null;
            }
            case LIFESTEAL -> {
               int v = cat == UpgradeDefinition.RelicType.WAND
                  ? RelicService.value(stack, "wfortune")
                  : (cat == UpgradeDefinition.RelicType.AXE ? RelicService.value(stack, "armor") : RelicService.value(stack, "fortune"));
               if (cat == UpgradeDefinition.RelicType.WAND) {
                  yield v < 10 ? "wlifesteal" + (v + 1) : null;
               } else if (cat == UpgradeDefinition.RelicType.AXE) {
                  yield v < 10 ? "axe_vamp" + (v + 1) : null;
               } else {
                  yield v < 10 ? "lifesteal" + (v + 1) : null;
               }
            }
            case SPELL -> {
               int v = RelicService.value(stack, "spell");
               yield v < 30 ? "spell" + (v + 1) : null;
            }
            case EXPLOSION -> {
               int v = RelicService.value(stack, "explosion");
               if (cat == UpgradeDefinition.RelicType.AXE) {
                  yield v < 10 ? "axe_crack" + (v + 1) : null;
               } else {
                  int cap = RelicService.value(stack, "tier") == 1 ? 12 : 10;
                  yield v < cap ? "expl" + (v + 1) : null;
               }
            }
            default -> null;
         };
         return routeId == null ? null : UpgradeDefinition.byId(routeId);
      } else {
         return null;
      }
   }

   private UpgradeDefinition protectionFamilyRoute(ItemStack stack, int ptype) {
      if (stack != null && stack.hasNbt()) {
         int currentType = RelicService.value(stack, "looting");
         int currentLevel = RelicService.value(stack, "damage");
         if (currentType != 0 && currentType != ptype) {
            return null;
         } else if (currentLevel >= 5) {
            return null;
         } else {
            String prefix = "ba_";

            String key = switch (ptype) {
               case 1 -> "fp";
               case 2 -> "bp";
               default -> "pp";
            };
            return UpgradeDefinition.byId(prefix + key + (currentLevel + 1));
         }
      } else {
         return null;
      }
   }

   private int currentProtectionLevel(ItemStack stack, int ptype) {
      int currentType = RelicService.value(stack, "looting");
      return currentType == ptype ? RelicService.value(stack, "damage") : 0;
   }

   private int currentLevel(RelicUpgradeScreen.Attribute attribute, ItemStack stack) {
      return switch (attribute) {
         case MATERIAL -> RelicService.value(stack, "tier");
         case ARMOR -> RelicService.value(stack, "armor");
         case EFFICIENCY -> RelicService.value(stack, "efficiency");
         case FORTUNE -> RelicService.value(stack, "fortune");
         case DAMAGE -> this.category == UpgradeDefinition.RelicType.AXE
            ? 8 + Math.min(RelicService.value(stack, "tier"), 2) * 5 + RelicService.value(stack, "damage")
            : 9 + RelicService.value(stack, "damage");
         case FIRE -> RelicService.value(stack, "fire");
         case LOOTING -> RelicService.value(stack, "looting");
         case LIFESTEAL -> this.category == UpgradeDefinition.RelicType.WAND
            ? RelicService.value(stack, "wfortune")
            : (this.category == UpgradeDefinition.RelicType.AXE ? RelicService.value(stack, "armor") : RelicService.value(stack, "fortune"));
         case SPELL -> RelicService.value(stack, "spell");
         case EXPLOSION -> RelicService.value(stack, "explosion");
      };
   }

   private int armorPanelLeft() {
      return this.width / 2 - 215;
   }

   private int armorPanelTop() {
      return this.height / 2 - 132;
   }

   private static RelicUpgradeScreen.CardPosition cardPosition(RelicUpgradeScreen.Attribute attribute) {
      return switch (attribute) {
         case MATERIAL -> new RelicUpgradeScreen.CardPosition(0, 0);
         case ARMOR -> new RelicUpgradeScreen.CardPosition(1, 0);
         case EFFICIENCY -> new RelicUpgradeScreen.CardPosition(0, 1);
         case FORTUNE -> new RelicUpgradeScreen.CardPosition(1, 1);
         default -> new RelicUpgradeScreen.CardPosition(0, 0);
         case FIRE -> new RelicUpgradeScreen.CardPosition(0, 2);
      };
   }

   private void initArmorColumnButtons() {
      int left = this.armorPanelLeft();
      int top = this.armorPanelTop();
      List<RelicUpgradeScreen.Attribute> attributes = this.attributesFor(this.category);
      RelicUpgradeScreen.RelicSelection selection = this.relicSelection(this.category);
      boolean conflict = selection.count() > 1;
      boolean hasTarget = selection.stack() != null;

      for (RelicUpgradeScreen.Attribute attribute : attributes) {
         RelicUpgradeScreen.CardPosition pos = cardPosition(attribute);
         UpgradeDefinition route = hasTarget ? this.nextRoute(attribute, selection.stack()) : null;
         int current = hasTarget ? this.currentLevel(attribute, selection.stack()) : 0;
         String label;
         if (route == null) {
            label = "已满级";
         } else if (attribute == RelicUpgradeScreen.Attribute.MATERIAL) {
            label = "升级材质";
         } else {
            label = "升级至 " + this.levelText(attribute, current + 1);
         }

         int x = left + (pos.col() == 0 ? 10 : 216) + 204 - 112;
         int y = top + 44 + pos.row() * 64 + 4;
         ButtonWidget button = ButtonWidget.builder(Text.literal(label), pressed -> this.sendUpgrade(route))
            .dimensions(x, y, 84, 16)
            .build();
         button.active = route != null && hasTarget && !conflict;
         this.addDrawableChild(button);
         this.addMaxUpgradeButton(x + 88, y, 26, 16, route, hasTarget && !conflict);
      }

      this.initArmorFamilyButton(left, top, selection, conflict, hasTarget);
      this.addDrawableChild(ButtonWidget.builder(Text.literal("←"), b -> {
         this.view = RelicUpgradeScreen.View.MODULES;
         this.category = null;
         this.rebuild();
      }).dimensions(left + 18, top + 240, 24, 16).build());
      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("返回"), b -> this.client.setScreen(this.parent))
            .dimensions(left + 430 - 62, top + 240, 44, 16)
            .build()
      );
   }

   private void initArmorFamilyButton(int left, int top, RelicUpgradeScreen.RelicSelection selection, boolean conflict, boolean hasTarget) {
      int y = top + 44 + 128 + 4;
      if (hasTarget) {
         int currentType = RelicService.value(selection.stack(), "looting");
         if (currentType == 0) {
            this.addDrawableChild(ButtonWidget.builder(Text.literal("选择保护家族"), b -> {
               this.view = RelicUpgradeScreen.View.FAMILY_SELECT;
               this.rebuild();
            }).dimensions(left + 216 + 8, y, 188, 16).build());
         } else {
            UpgradeDefinition route = this.protectionFamilyRoute(selection.stack(), currentType);
            int current = this.currentProtectionLevel(selection.stack(), currentType);
            String label = route == null ? "已满级" : "升级至 " + this.roman(current + 1);
            int x = left + 216 + 204 - 112;
            ButtonWidget button = ButtonWidget.builder(Text.literal(label), pressed -> this.sendUpgrade(route))
               .dimensions(x, y, 84, 16)
               .build();
            button.active = route != null && !conflict;
            this.addDrawableChild(button);
            this.addMaxUpgradeButton(x + 88, y, 26, 16, route, !conflict);
         }
      }
   }

   /** 通用属性页按钮（两列压缩卡，与骨甲列布局统一）：每卡内升级/满级 + 底部 ←/⇄/一键全满/返回。 */
   private void initRelicColumnButtons() {
      int left = this.armorPanelLeft();
      int top = this.armorPanelTop();
      boolean axePage = this.category == UpgradeDefinition.RelicType.AXE;
      List<RelicUpgradeScreen.Attribute> attributes = this.attributesFor(this.category);
      RelicUpgradeScreen.RelicSelection selection = this.relicSelection(this.category);
      boolean conflict = selection.count() > 1;
      boolean hasTarget = selection.stack() != null;

      for (int i = 0; i < attributes.size(); i++) {
         RelicUpgradeScreen.Attribute attribute = attributes.get(i);
         int col = i % 2;
         int row = i / 2;
         UpgradeDefinition route = hasTarget ? this.nextRoute(attribute, selection.stack()) : null;
         int current = hasTarget ? this.currentLevel(attribute, selection.stack()) : 0;
         String label;
         if (route == null) {
            label = "已满级";
         } else if (attribute == RelicUpgradeScreen.Attribute.MATERIAL) {
            label = "升级材质";
         } else {
            label = "升级至 " + this.levelText(attribute, current + 1);
         }

         int x = left + (col == 0 ? 10 : 216) + 204 - 112;
         int y = top + 44 + row * 64 + 4;
         ButtonWidget button = ButtonWidget.builder(Text.literal(label), pressed -> this.sendUpgrade(route))
            .dimensions(x, y, 84, 16)
            .build();
         button.active = route != null && hasTarget && !conflict;
         this.addDrawableChild(button);
         this.addMaxUpgradeButton(x + 88, y, 26, 16, route, hasTarget && !conflict);
      }

      int bottomY = top + 240;
      this.addDrawableChild(ButtonWidget.builder(Text.literal("←"), b -> {
         this.view = RelicUpgradeScreen.View.MODULES;
         this.category = null;
         this.rebuild();
      }).dimensions(left + 18, bottomY, 24, 20).build());
      boolean convertible = this.category == UpgradeDefinition.RelicType.WAND
         || this.category == UpgradeDefinition.RelicType.BONE
         || this.category == UpgradeDefinition.RelicType.PICKAXE
         || this.category == UpgradeDefinition.RelicType.AXE;
      if (convertible) {
         int pairCode = this.category == UpgradeDefinition.RelicType.PICKAXE || this.category == UpgradeDefinition.RelicType.AXE ? 1 : 0;
         String switchLabel = this.category == UpgradeDefinition.RelicType.BONE || this.category == UpgradeDefinition.RelicType.WAND
            ? "⇄ 切法杖/骨头"
            : "⇄ 切骨斧/铁镐";
         this.addDrawableChild(ButtonWidget.builder(Text.literal(switchLabel), b -> {
            this.sendRelicSwitch(pairCode);
            lastResult = "切换请求已发送…";
            this.rebuild();
         }).dimensions(left + 150, bottomY, 120, 20).build());
      }

      if (axePage && this.isCreative()) {
         this.addDrawableChild(
            ButtonWidget.builder(Text.literal("一键全满"), b -> {
                  for (String id : new String[]{"axe_m1", "axe_eff2", "axe_for2", "axe_g1", "axe_crack1", "axe_vamp1"}) {
                     this.sendMaxUpgrade(UpgradeDefinition.byId(id));
                  }

                  lastResult = "创造模式：骨斧六路线一键满级请求已发送…";
                  this.requestRefreshAfterInventorySync();
               })
               .tooltip(Tooltip.of(Text.literal("创造模式：骨斧 材质/效率/时运/巨力/裂地/吸血 全部拉满（服务端逐项校验）")))
               .dimensions(left + 288, bottomY, 88, 20)
               .build()
         );
      }

      this.addDrawableChild(
         ButtonWidget.builder(Text.literal("返回"), b -> this.client.setScreen(this.parent))
            .dimensions(left + 376, bottomY, 44, 20)
            .build()
      );
   }

   /** 通用属性页渲染（两列压缩卡，与骨甲列布局统一；无超限条/保护家族行）。 */
   private void renderRelicColumn(DrawContext context, int mouseX, int mouseY, float delta) {
      int left = this.armorPanelLeft();
      int top = this.armorPanelTop();
      int accent = this.category == UpgradeDefinition.RelicType.BONE ? -9808844 : -13216148;
      this.panel(context, left, top, 430, 264, accent, this.categoryTitle(this.category));
      RelicUpgradeScreen.RelicSelection selection = this.relicSelection(this.category);
      if (selection.count() == 0) {
         context.drawCenteredTextWithShadow(this.textRenderer, "背包中未找到对应遗物", this.width / 2, top + 34, -43691);
      } else if (selection.count() > 1) {
         context.drawCenteredTextWithShadow(this.textRenderer, "请只保留一件同类遗物", this.width / 2, top + 34, -43691);
      }

      List<RelicUpgradeScreen.Attribute> attributes = this.attributesFor(this.category);
      for (int i = 0; i < attributes.size(); i++) {
         this.renderArmorCard(context, left, top, attributes.get(i), i % 2, i / 2, selection, mouseX, mouseY, delta);
      }

      this.renderStatusMarquee(context, top + 240 + 3, 406, mouseX, mouseY, delta);
   }

   private void renderArmorAttributes(DrawContext context, int mouseX, int mouseY, float delta) {
      int left = this.armorPanelLeft();
      int top = this.armorPanelTop();
      this.panel(context, left, top, 430, 264, -14268347, "遗物骨甲");
      RelicUpgradeScreen.RelicSelection selection = this.relicSelection(this.category);
      this.renderOvercapStatus(context, left, top, mouseX, mouseY, delta);
      if (selection.count() == 0) {
         context.drawCenteredTextWithShadow(this.textRenderer, "背包中未找到对应遗物", this.width / 2, top + 34, -43691);
      } else if (selection.count() > 1) {
         context.drawCenteredTextWithShadow(this.textRenderer, "请只保留一件同类遗物", this.width / 2, top + 34, -43691);
      }

      for (RelicUpgradeScreen.Attribute attribute : this.attributesFor(this.category)) {
         RelicUpgradeScreen.CardPosition pos = cardPosition(attribute);
         this.renderArmorCard(context, left, top, attribute, pos.col(), pos.row(), selection, mouseX, mouseY, delta);
      }

      this.renderArmorFamily(context, left, top, selection, mouseX, mouseY, delta);
      this.renderStatusMarquee(context, top + 240 + 3, 406, mouseX, mouseY, delta);
   }

   private void renderArmorCard(
      DrawContext context,
      int left,
      int top,
      RelicUpgradeScreen.Attribute attribute,
      int col,
      int row,
      RelicUpgradeScreen.RelicSelection selection,
      int mouseX,
      int mouseY,
      float delta
   ) {
      int x = left + (col == 0 ? 10 : 216);
      int y = top + 44 + row * 64;
      context.fill(x, y, x + 204, y + 58, -14277082);
      if (selection.stack() == null) {
         context.drawTextWithShadow(this.textRenderer, this.attributeTitle(attribute), x + 8, y + 4, -171);
      } else {
         int current = this.currentLevel(attribute, selection.stack());
         UpgradeDefinition route = this.nextRoute(attribute, selection.stack());
         String progression = route == null
            ? this.levelText(attribute, current)
            : this.levelText(attribute, current) + "→" + this.levelText(attribute, current + 1);
         this.renderCardMarquee(
            this.cardProgression,
            attribute,
            this.attributeTitle(attribute) + " " + progression,
            x + 6,
            y + 3,
            80,
            route == null ? -5592406 : -1,
            context,
            mouseX,
            mouseY,
            delta
         );
         if (route == null) {
            String fullText = "已满级";
            if (attribute == RelicUpgradeScreen.Attribute.ARMOR && RelicService.value(selection.stack(), "armor") < 50) {
               int cap = RelicService.armorCap(RelicService.value(selection.stack(), "tier"));
               fullText = "需升级材质（当前上限 " + cap + "）";
            }

            context.drawTextWithShadow(this.textRenderer, fullText, x + 8, y + 22, -5592406);
         } else {
            int currentXp = this.client.player == null ? 0 : this.client.player.experienceLevel;
            int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
            String xpText = "经验 " + currentXp + "/" + route.experienceLevels();
            context.drawTextWithShadow(this.textRenderer, xpText, x + 8, y + 22, xpColor);
            int costsX = x + 8 + this.textRenderer.getWidth(xpText) + 4;
            this.renderCardMarquee(
               this.cardCosts,
               attribute,
               this.costSummary(route),
               costsX,
               y + 21,
               x + 204 - 12 - costsX,
               this.allCostsSatisfied(route) ? -11141291 : -43691,
               context,
               mouseX,
               mouseY,
               delta
            );
            this.renderCardMarquee(
               this.cardRequirement, attribute, "前置 " + this.requirementText(route), x + 6, y + 39, 192, -5592406, context, mouseX, mouseY, delta
            );
         }
      }
   }

   private String costSummary(UpgradeDefinition route) {
      StringBuilder builder = new StringBuilder();

      for (UpgradeDefinition.Cost cost : route.costs()) {
         if (builder.length() > 0) {
            builder.append(" · ");
         }

         int owned = this.availableCostItems(cost.item());
         builder.append(cost.item().getName().getString()).append(" ").append(owned).append("/").append(cost.count());
      }

      return builder.toString();
   }

   private boolean allCostsSatisfied(UpgradeDefinition route) {
      for (UpgradeDefinition.Cost cost : route.costs()) {
         if (this.availableCostItems(cost.item()) < cost.count()) {
            return false;
         }
      }

      return true;
   }

   private void renderArmorFamily(DrawContext context, int left, int top, RelicUpgradeScreen.RelicSelection selection, int mouseX, int mouseY, float delta) {
      int x = left + 216;
      int y = top + 44 + 128;
      context.fill(x, y, x + 204, y + 58, -14277082);
      if (selection.stack() == null) {
         context.drawTextWithShadow(this.textRenderer, "保护家族", x + 8, y + 4, -171);
      } else {
         int currentType = RelicService.value(selection.stack(), "looting");
         if (currentType == 0) {
            context.drawTextWithShadow(this.textRenderer, "火焰/爆炸/弹射物 三选一，选定后不可更换", x + 8, y + 26, -5592406);
            context.drawTextWithShadow(this.textRenderer, "第一级无需材料，仅消耗经验", x + 8, y + 42, -11141291);
         } else {
            String familyName = familyName(currentType);
            int current = this.currentProtectionLevel(selection.stack(), currentType);
            UpgradeDefinition route = this.protectionFamilyRoute(selection.stack(), currentType);
            String progression = route == null ? this.roman(current) : this.roman(current) + "→" + this.roman(current + 1);
            this.familyProgressionMarquee.setMessage(Text.literal(familyName + " " + progression));
            this.familyProgressionMarquee.setX(x + 6);
            this.familyProgressionMarquee.setY(y + 3);
            this.familyProgressionMarquee.setWidth(192);
            this.familyProgressionMarquee.setColor(route == null ? -5592406 : -1);
            this.familyProgressionMarquee.render(context, mouseX, mouseY, delta);
            if (route == null) {
               context.drawTextWithShadow(this.textRenderer, "已满级", x + 8, y + 22, -5592406);
            } else {
               int currentXp = this.client.player == null ? 0 : this.client.player.experienceLevel;
               int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
               String xpText = "经验 " + currentXp + "/" + route.experienceLevels();
               context.drawTextWithShadow(this.textRenderer, xpText, x + 8, y + 22, xpColor);
               int costsX = x + 8 + this.textRenderer.getWidth(xpText) + 4;
               this.familyCostMarquee.setMessage(Text.literal(this.costSummary(route)));
               this.familyCostMarquee.setX(costsX);
               this.familyCostMarquee.setY(y + 21);
               this.familyCostMarquee.setWidth(x + 204 - 12 - costsX);
               this.familyCostMarquee.setColor(this.allCostsSatisfied(route) ? -11141291 : -43691);
               this.familyCostMarquee.render(context, mouseX, mouseY, delta);
               this.familyRequirementMarquee.setMessage(Text.literal("前置 " + this.requirementText(route)));
               this.familyRequirementMarquee.setX(x + 6);
               this.familyRequirementMarquee.setY(y + 39);
               this.familyRequirementMarquee.setWidth(192);
               this.familyRequirementMarquee.setColor(-5592406);
               this.familyRequirementMarquee.render(context, mouseX, mouseY, delta);
            }
         }
      }
   }

   private static String familyName(int ptype) {
      return switch (ptype) {
         case 1 -> "火焰保护";
         case 2 -> "爆炸保护";
         default -> "弹射物保护";
      };
   }

   private void renderOvercapStatus(DrawContext context, int left, int top, int mouseX, int mouseY, float delta) {
      ArmorOvercapConfig config = ArmorOvercapConfig.get();
      int armor = this.clientArmorValue();
      int count = this.clientRelicArmorCount();
      // 持有/穿戴虚空神心 → 视为满足骨甲条件（记 4 件，与服务端口径一致）
      if (this.clientHasVoidHeart()) {
         count = Math.max(4, count);
      }
      // 神心持有/穿戴 → 直接激活；否则按骨甲件数（与服务端 isActive 完全一致）
      boolean active = config.enabled && (this.clientHasVoidHeart() || count >= config.minRelicArmorPieces);
      int overcap = active ? Math.max(0, armor - (int)config.threshold) : 0;
      double reduction = Math.min((double)overcap * config.drPercentPerPoint / 100.0, config.drCapPercent / 100.0);
      double health = Math.min((double)overcap * config.healthPerPoint, config.healthCap);
      double magicResist = Math.min((double)overcap * config.magicResistPercentPerPoint / 100.0, config.magicResistCapPercent / 100.0);
      String badge = active && overcap > 0 ? "超限转化 " + fmt(reduction * 100.0) + "%" : "未激活";
      context.drawTextWithShadow(this.textRenderer, badge, left + 430 - 12 - this.textRenderer.getWidth(badge), top + 7, active && overcap > 0 ? -13261 : -5592406);
      String status = active && overcap > 0
         ? "护甲 "
            + armor
            + "/"
            + (int)config.threshold
            + " · 超限 "
            + overcap
            + " 点 → 全面减伤 "
            + fmt(reduction * 100.0)
            + "% ｜ 最大生命 +"
            + fmt(health)
            + (config.isHpMode() ? "" : "%")   // 与服务端一致：HP 模式为绝对值，PERCENT 模式为百分比
            + " ｜ 法抗 +"
            + fmt(magicResist * 100.0)
            + "%"
         : "未激活：需穿戴 ≥" + config.minRelicArmorPieces + " 件遗物骨甲 且 全身护甲 > " + (int)config.threshold + " 点";
      this.overcapStatusText.setMessage(Text.literal(status));
      this.overcapStatusText.setX(left + 10);
      this.overcapStatusText.setY(top + 25);
      this.overcapStatusText.setWidth(410);
      this.overcapStatusText.setColor(active && overcap > 0 ? -11141291 : -5592406);
      this.overcapStatusText.render(context, mouseX, mouseY, delta);
      if (mouseX >= left + 10 && mouseX <= left + 430 - 10 && mouseY >= top + 22 && mouseY <= top + 40) {
         context.drawTooltip(
            this.textRenderer,
            List.of(
               Text.literal("护甲超 40 点后每 1 点 = 1% 全面减伤（覆盖火焰/爆炸/摔落/弹射物/魔法等全部保护类型）+ 1% 最大生命 + 1% 法术抗性，需穿戴 ≥" + config.minRelicArmorPieces + " 件遗物骨甲。")
            ),
            mouseX,
            mouseY
         );
      }
   }

   private int clientArmorValue() {
      if (this.client != null && this.client.player != null) {
         int sum = 0;

         for (ItemStack stack : this.client.player.getInventory().armor) {
            if (RelicService.isRelicReadOnly(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
               sum += RelicService.value(stack, "armor");
            }
         }

         // 与服务端 armorValue 口径一致：计入神心提供的护甲（否则融合后界面恒为"未激活"）
         if (this.clientHasVoidHeart()) {
            sum += (int)cn.bmcvp.relic.VoidHeartHandler.HEART_ARMOR_BONUS;
         }
         return sum;
      } else {
         return 0;
      }
   }

   private int clientRelicArmorCount() {
      if (this.client != null && this.client.player != null) {
         int count = 0;

         for (ItemStack stack : this.client.player.getInventory().armor) {
            if (RelicService.isRelicReadOnly(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
               count++;
            }
         }

         return count;
      } else {
         return 0;
      }
   }

   private void initFamilySelectButtons() {
      int left = this.width / 2 - 215;
      int top = this.height / 2 - 100;
      String[] names = new String[]{"火焰保护", "爆炸保护", "弹射物保护"};
      int[] types = new int[]{1, 2, 3};
      RelicUpgradeScreen.RelicSelection selection = this.relicSelection(this.category);
      boolean conflict = selection.count() > 1;
      boolean hasTarget = selection.stack() != null;

      for (int i = 0; i < 3; i++) {
         int ptype = types[i];
         UpgradeDefinition route = hasTarget ? this.protectionFamilyRoute(selection.stack(), ptype) : null;
         String label = route == null ? names[i] + " 不可用" : "选择 " + names[i];
         ButtonWidget button = ButtonWidget.builder(Text.literal(label), pressed -> this.sendFamilyChoice(route))
            .dimensions(left + 14, top + 46 + i * 30, 130, 24)
            .build();
         button.active = route != null && hasTarget && !conflict;
         this.addDrawableChild(button);
      }

      this.addDrawableChild(ButtonWidget.builder(Text.literal("返回"), b -> {
         this.view = RelicUpgradeScreen.View.ATTRIBUTES;
         this.rebuild();
      }).dimensions(this.width / 2 - 40, top + 158, 80, 20).build());
   }

   private void sendFamilyChoice(UpgradeDefinition route) {
      if (route != null) {
         this.view = RelicUpgradeScreen.View.ATTRIBUTES;
         this.sendUpgrade(route);
      }
   }

   private void renderFamilySelect(DrawContext context) {
      int left = this.width / 2 - 215;
      int top = this.height / 2 - 100;
      this.panel(context, left, top, 430, 200, -14268347, "保护家族（三选一）");
      String[] names = new String[]{"火焰保护", "爆炸保护", "弹射物保护"};

      for (int i = 0; i < 3; i++) {
         int y = top + 46 + i * 30;
         context.drawTextWithShadow(this.textRenderer, names[i], left + 160, y + 6, -1);
         context.drawTextWithShadow(this.textRenderer, "第一级无需材料 · 仅需经验 5 级", left + 160, y + 15, -11141291);
      }

      context.drawCenteredTextWithShadow(this.textRenderer, "选定后不可更换（四个部位独立选择）", this.width / 2, top + 138, -5592406);
   }

   private static String fmt(double value) {
      return value == Math.floor(value) && !Double.isInfinite(value) ? String.valueOf((long)value) : String.format(Locale.ROOT, "%.1f", value);
   }

   private void rebuild() {
      this.clearAndInit();
      this.refreshScrollBounds();
   }

   /** 大页面纵向滚动偏移（滚轮），仅在内容超出窗口时生效。 */
   private double viewScroll;
   private double maxViewScroll;
   /** 自适应缩放（让界面在当前窗口/界面大小下尽量大且横向完整，高度不足交给滚动）。 */
   private static final double MIN_UI_SCALE = 0.7D;
   private static final double MAX_UI_SCALE = 1.0D;
   private double currentScale = 1.0D;

   private float needWidth() {
      return 452.0F;
   }

   /** 宽优先：横向尽量完整且尽量大；高度溢出交给纵向滚动。 */
   private double scaleFor(int width, int height) {
      double s = (double)(width - 14) / (double)this.needWidth();
      return Math.max(MIN_UI_SCALE, Math.min(MAX_UI_SCALE, s));
   }

   private double mapX(double x) {
      double cx = (double)this.width / 2.0D;
      return cx + (x - cx) / this.currentScale;
   }

   private double mapY(double y) {
      double cy = (double)this.height / 2.0D;
      return cy + (y - cy) / this.currentScale + this.viewScroll;
   }

   private void refreshScrollBounds() {
      if (this.view == RelicUpgradeScreen.View.MODULES || this.view == RelicUpgradeScreen.View.SLOT_SELECT
         || this.category == null) {
         this.maxViewScroll = 0.0D;
         this.viewScroll = 0.0D;
         return;
      }
      int rows = this.attributesFor(this.category).size();
      boolean axe = this.category == UpgradeDefinition.RelicType.AXE;
      int contentBottom = this.height / 2 + (axe ? rows * 96 + 250 : rows * 100 + 230);
      if (this.view == RelicUpgradeScreen.View.GROWTH) {
         contentBottom = this.height / 2 + 430;
      } else if (this.view == RelicUpgradeScreen.View.FAMILY_SELECT) {
         contentBottom = this.height / 2 + 240;
      }
      this.maxViewScroll = Math.max(0.0D, (double)contentBottom - (double)this.height + 40.0D);
      this.viewScroll = Math.max(0.0D, Math.min(this.viewScroll, this.maxViewScroll));
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double verticalAmount) {
      if (this.maxViewScroll > 0.0D) {
         this.viewScroll = Math.max(0.0D, Math.min(this.maxViewScroll, this.viewScroll - verticalAmount * 14.0D));
         return true;
      }
      return super.mouseScrolled(this.mapX(mouseX), this.mapY(mouseY), verticalAmount);
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      return super.mouseClicked(this.mapX(mouseX), this.mapY(mouseY), button);
   }

   @Override
   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      return super.mouseReleased(this.mapX(mouseX), this.mapY(mouseY), button);
   }

   @Override
   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      return super.mouseDragged(this.mapX(mouseX), this.mapY(mouseY), button, deltaX / this.currentScale, deltaY / this.currentScale);
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      this.renderBackground(context);
      this.currentScale = this.scaleFor(this.width, this.height);
      double cx = (double)this.width / 2.0D;
      double cy = (double)this.height / 2.0D;
      int mappedX = (int)this.mapX((double)mouseX);
      int mappedY = (int)this.mapY((double)mouseY);
      context.getMatrices().push();
      context.getMatrices().translate(0.0D, -this.viewScroll, 0.0D);
      context.getMatrices().translate(cx, cy, 0.0D);
      context.getMatrices().scale((float)this.currentScale, (float)this.currentScale, 1.0F);
      context.getMatrices().translate(-cx, -cy, 0.0D);
      if (this.view == RelicUpgradeScreen.View.MODULES) {
         this.renderModules(context, mappedX, mappedY, delta);
      } else if (this.view == RelicUpgradeScreen.View.SLOT_SELECT) {
         this.renderSlotSelect(context);
      } else if (this.view == RelicUpgradeScreen.View.FAMILY_SELECT) {
         this.renderFamilySelect(context);
      } else if (this.view == RelicUpgradeScreen.View.GROWTH) {
         this.renderGrowth(context);
      } else {
         this.renderAttributes(context, mappedX, mappedY, delta);
      }

      super.render(context, mappedX, mappedY, delta);
      context.getMatrices().pop();
   }

   private void sendAscend() {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         ClientPlayNetworking.send(BmcvpRelicUpgrades.ASCEND, PacketByteBufs.create());
      }
   }

   private void sendWandMode() {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         ClientPlayNetworking.send(BmcvpRelicUpgrades.WAND_MODE, PacketByteBufs.create());
      }
   }

   private void sendMergeHeart() {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         ClientPlayNetworking.send(BmcvpRelicUpgrades.MERGE_HEART, PacketByteBufs.create());
      }
   }

   private void sendGrowthInfoRequest() {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         ClientPlayNetworking.send(BmcvpRelicUpgrades.GROWTH_INFO_REQ, PacketByteBufs.create());
      }
   }

   private void sendGrowthUpgrade(int flag) {
      if (this.client != null && this.client.getNetworkHandler() != null) {
         PacketByteBuf buf = PacketByteBufs.create();
         buf.writeInt(flag);
         ClientPlayNetworking.send(BmcvpRelicUpgrades.GROWTH_UPGRADE, buf);
         this.markResultPending();
      }
   }

   private void initGrowthButtons() {
      int left = this.width / 2 - 215;
      int top = this.height / 2 - 185;
      this.growthInfoCounter = 0;
      this.lastBuiltGrowthLevel = this.growthCoreLevel;
      this.sendGrowthInfoRequest();
      boolean creative = this.isCreative();

      // 融合 · 虚空神心（终极方案）：三项主属性满级时把全部遗物融入秘法核心
      ButtonWidget merge = ButtonWidget.builder(Text.literal("融合 · 虚空神心"), b -> {
         this.sendMergeHeart();
         lastResult = "融合请求已发送…";
         this.requestRefreshAfterInventorySync();
      })
      .tooltip(Tooltip.of(Text.literal("条件：镐子材质 6/6、骨头伤害 41/41、法杖法强 30/30（三项主属性全满）。\n融合后所有遗物归心，骨甲不再返还。\n生存模式不可用（置灰），创造模式可直接点击。")))
      .dimensions(left + 20, top + 276, 200, 26)
      .build();
      merge.active = this.isCreative();   // 生存模式置灰，创造可直接点
      this.addDrawableChild(merge);
      this.addDrawableChild(ButtonWidget.builder(Text.literal("返回"), b -> {
         this.view = RelicUpgradeScreen.View.MODULES;
         this.rebuild();
      }).dimensions(left + 20, top + 312, 60, 20).build());
      boolean maxed = this.growthCoreLevel >= 30;
      ButtonWidget upgrade = ButtonWidget.builder(
            Text.literal(maxed ? "已达满级" : "升级 Lv." + this.growthCoreLevel + " → " + (this.growthCoreLevel + 1)), b -> {
               this.sendGrowthUpgrade(0);
               lastResult = "升级请求已发送…";
               this.requestRefreshAfterInventorySync();
            }
         )
         .tooltip(Tooltip.of(Text.literal("消耗：击杀档案达标 + 经验等级 + 基础材料（材料随级阶段递进）")))
         .dimensions(left + 150, top + 306, 130, 26)
         .build();
      upgrade.active = !maxed;
      this.addDrawableChild(upgrade);
      if (creative) {
         this.addDrawableChild(
            ButtonWidget.builder(Text.literal("一键满级"), b -> {
                  this.sendGrowthUpgrade(1);
                  lastResult = "满级请求已发送…";
                  this.requestRefreshAfterInventorySync();
               })
               .tooltip(Tooltip.of(Text.literal("创造模式：秘法核心直接升至 Lv.30（服务端校验）")))
               .dimensions(left + 330, top + 306, 80, 26)
               .build()
         );
      }
   }

   private void renderGrowth(DrawContext context) {
      int left = this.width / 2 - 215;
      int top = this.height / 2 - 185;
      this.panel(context, left, top, 430, 350, -11846871, "秘法核心 · 成长");
      int level = this.growthCoreLevel;
      boolean creative = this.isCreative();
      int xL = left + 22;
      int xR = left + 248;
      context.drawTextWithShadow(this.textRenderer, Text.literal("Lv." + level + " / 30"), xL, top + 40, -11141291);
      context.drawTextWithShadow(this.textRenderer, Text.literal("— 升级条件 —"), xR, top + 42, -5592406);
      String hp = String.format("%.1f", ArcaneCoreGrowth.maxHealthFor(level));
      String atk = String.format("%.1f", ArcaneCoreGrowth.attackFor(level));
      String spd = String.format("%.2f", ArcaneCoreGrowth.speedFor(level));
      context.drawTextWithShadow(this.textRenderer, Text.literal("生命  +" + hp + "（上限 +30.0）"), xL, top + 66, -1);
      context.drawTextWithShadow(this.textRenderer, Text.literal("攻击  +" + atk + "（上限 +10.0）"), xL, top + 86, -1);
      context.drawTextWithShadow(this.textRenderer, Text.literal("移速  +" + spd + "（上限 +0.30）"), xL, top + 106, -1);
      int ry = top + 66;
      if (level >= 30) {
         context.drawTextWithShadow(this.textRenderer, Text.literal("已达满级 Lv.30"), xR, ry, -11141291);
         ry += 20;
         context.drawTextWithShadow(this.textRenderer, Text.literal("属性与特性全部生效"), xR, ry, -5592406);
      } else {
         int needKills = ArcaneCoreGrowth.killThreshold(level + 1);
         int killsColor = this.growthKills >= needKills ? -11141291 : -43691;
         context.drawTextWithShadow(this.textRenderer, Text.literal("击杀  " + this.growthKills + " / " + needKills), xR, ry, killsColor);
         ry += 20;
         int needXp = ArcaneCoreGrowth.experienceCost(level);
         int haveXp = this.client.player == null ? 0 : this.client.player.experienceLevel;
         int xpColor = !creative && haveXp < needXp ? -43691 : -11141291;
         context.drawTextWithShadow(this.textRenderer, Text.literal(creative ? "经验  免费（创造）" : "经验  " + haveXp + " / " + needXp + " 级"), xR, ry, xpColor);
         ry += 20;
         Item material = ArcaneCoreGrowth.materialFor(level);
         if (material == null) {
            context.drawTextWithShadow(this.textRenderer, Text.literal(creative ? "材料  免费（创造）" : "材料  免费（首级）"), xR, ry, -11141291);
         } else {
            int needCount = ArcaneCoreGrowth.materialCount(level);
            int have = creative ? needCount : this.availableCostItems(material);
            int matColor = !creative && have < needCount ? -43691 : -11141291;
            context.drawTextWithShadow(
               this.textRenderer, Text.literal(material.getName().getString() + "  " + have + " / " + needCount), xR, ry, matColor
            );
         }
      }

      context.drawTextWithShadow(this.textRenderer, Text.literal("— 成长特性 —"), xL, top + 150, -5592406);
      int ty = top + 172;
      ty = this.drawFeature(context, xL, ty, level, 5, "魂引", "磁吸拾取（6 格）");
      int execPercent = ArcaneCoreGrowth.executeChancePercent(level);
      String execDesc = level >= ArcaneCoreGrowth.EXECUTE_UNLOCK_LEVEL
         ? "残血处决 ≤30% · 处决率 " + execPercent + "%"
         : "残血处决 ≤30% · 处决率 10%→40%（Lv.10 解锁）";
      ty = this.drawFeature(context, xL, ty, level, ArcaneCoreGrowth.EXECUTE_UNLOCK_LEVEL, "破甲斩杀", execDesc);
      int reviveCdMin = ArcaneCoreGrowth.reviveCooldownSeconds(Math.max(1, level)) / 60;
      String reviveDesc = level >= ArcaneCoreGrowth.REVIVE_MAX_LEVEL
         ? "满血复活 · CD 5 分钟"
         : "回复 2 心→满血 · CD " + reviveCdMin + " 分→5 分";
      ty = this.drawFeature(context, xL, ty, level, 1, "死而复生", reviveDesc);
      this.drawFeature(context, xL, ty, level, 30, "灵魂收割", "斩杀群伤 + 回血");
      context.drawTextWithShadow(this.textRenderer, Text.literal("材料阶段：骨头 2-10 → 金锭 12-21 → 末影珍珠 10-26"), xL, top + 256, -5592406);
      context.drawTextWithShadow(this.textRenderer, Text.literal(creative ? "创造模式升级免费；可直接一键满级测试。" : "击杀长期累计 · 任意生物；穿戴或背包中皆可升级。"), xL, top + 274, -5592406);
   }

   private int drawFeature(DrawContext context, int x, int y, int level, int need, String name, String desc) {
      boolean unlocked = level >= need;
      context.drawTextWithShadow(this.textRenderer, Text.literal((unlocked ? "✓ " : "○ ") + name + " · " + desc), x, y, unlocked ? -11141291 : -5592406);
      return y + 20;
   }

   private void renderSlotSelect(DrawContext context) {
      int left = this.width / 2 - 150;
      int top = this.height / 2 - 82;
      this.panel(context, left, top, 300, 190, -14268347, "选择升级部位");
      String[] names = new String[]{"头盔", "胸甲", "护腿", "靴子"};

      for (int i = 0; i < 4; i++) {
         context.drawCenteredTextWithShadow(this.textRenderer, names[i], left + 79, top + 54 + i * 30, -1);
      }
   }

   private void panel(DrawContext context, int left, int top, int panelWidth, int panelHeight, int accent, String title) {
      context.fill(left, top, left + panelWidth, top + panelHeight, -366993376);
      context.fill(left + 2, top + 2, left + panelWidth - 2, top + 22, accent);
      context.drawCenteredTextWithShadow(this.textRenderer, title, left + panelWidth / 2, top + 7, -1);
   }

   private void renderModules(DrawContext context, int mouseX, int mouseY, float delta) {
      int left = this.width / 2 - 210;
      int top = this.height / 2 - 82;
      boolean creative = this.isCreative();
      if (this.modulePage == 1) {
         int panelH = creative ? 196 : 150;
         this.panel(context, left, top, 420, panelH, -11846871, "遗物 · 发放（2/2）");
         if (creative) {
            context.drawTextWithShadow(this.textRenderer, "发放按钮仅创造模式可用 · 点击即发放（升级全部免费）", left + 14, top + 26, -11141291);
         } else {
            context.drawCenteredTextWithShadow(this.textRenderer, "发放按钮仅创造模式可用 —— 请切回「◀ 升级」页", this.width / 2, top + 56, -43691);
         }

         this.renderStatusMarquee(context, top + panelH - 20, 396, mouseX, mouseY, delta);
      } else {
         boolean isWand = "magic_wand".equals(this.currentBoneOrWandKind());
         boolean isAxe = "bone_axe".equals(this.currentPickaxeOrAxeKind());
         this.panel(context, left, top, 420, 200, -11846871, "遗物升级（1/2 · 升级）");
         this.renderModuleCard(
            context,
            left + 10,
            top + 34,
            150,
            isAxe ? "骨斧" : "无尽铁镐",
            new ItemStack(isAxe ? ModItems.RELIC_BONE_AXE : ModItems.RELIC_IRON_PICKAXE),
            -13216148
         );
         this.renderModuleCard(
            context,
            left + 190,
            top + 34,
            150,
            isWand ? "魔法法杖" : "战利品骨头",
            new ItemStack(isWand ? ModItems.MAGIC_WAND : ModItems.RELIC_BONE),
            isWand ? -13216148 : -9808844
         );
         this.renderModuleCard(context, left + 10, top + 98, 150, "遗物骨甲", new ItemStack(ModItems.RELIC_BONE_CHESTPLATE), -14268347);
         this.renderModuleCard(
            context,
            left + 190,
            top + 98,
            150,
            "秘法核心 · 成长",
            new ItemStack(ModItems.ARCANE_CORE == null ? ModItems.RELIC_GUIDE_BOOK : ModItems.ARCANE_CORE),
            -11846871
         );
         this.renderStatusMarquee(context, top + 180, 396, mouseX, mouseY, delta);
      }
   }

   private void renderModuleCard(DrawContext context, int x, int y, int width, String title, ItemStack icon, int accent) {
      context.fill(x, y, x + width, y + 56, -13948117);
      context.fill(x, y, x + width, y + 3, accent);
      context.getMatrices().push();
      context.getMatrices().translate((float)(x + 6), (float)(y + 8), 0.0F);
      context.getMatrices().scale(2.0F, 2.0F, 1.0F);
      context.drawItem(icon, 0, 0);
      context.getMatrices().pop();
      context.drawTextWithShadow(this.textRenderer, title, x + 52, y + 22, -1);
   }

   private void renderAttributes(DrawContext context, int mouseX, int mouseY, float delta) {
      if (this.category == UpgradeDefinition.RelicType.BONE_ARMOR) {
         this.renderArmorAttributes(context, mouseX, mouseY, delta);
      } else {
         this.renderRelicColumn(context, mouseX, mouseY, delta);
      }
   }

   private void renderProtectionFamily(DrawContext context, int left, int y, RelicUpgradeScreen.RelicSelection selection) {
      context.drawTextWithShadow(this.textRenderer, "保护家族（三选一）", left + 18, y - 10, -171);
      String[] names = new String[]{"火焰保护", "爆炸保护", "弹射物保护"};
      int[] types = new int[]{1, 2, 3};

      for (int i = 0; i < 3; i++) {
         int current = selection.stack() == null ? 0 : this.currentProtectionLevel(selection.stack(), types[i]);
         String text = names[i] + " " + this.roman(current);
         context.drawTextWithShadow(this.textRenderer, text, left + 18 + i * 130, y, current > 0 ? -11141291 : -5592406);
      }
   }

   private void renderAttributeCard(
      DrawContext context,
      int left,
      int y,
      RelicUpgradeScreen.Attribute attribute,
      RelicUpgradeScreen.RelicSelection selection,
      int mouseX,
      int mouseY,
      float delta
   ) {
      context.fill(left + 10, y, left + 420, y + 58, -14277082);
      context.drawTextWithShadow(this.textRenderer, this.attributeTitle(attribute), left + 18, y + 7, -171);
      if (selection.stack() != null) {
         int current = this.currentLevel(attribute, selection.stack());
         UpgradeDefinition route = this.nextRoute(attribute, selection.stack());
         String progression = route == null
            ? this.levelText(attribute, current)
            : this.levelText(attribute, current) + " → " + this.levelText(attribute, current + 1);
         this.renderCardMarquee(
            this.cardProgression, attribute, progression, left + 16, y + 24, 156, route == null ? -5592406 : -1, context, mouseX, mouseY, delta
         );
         if (route != null) {
            int currentXp = this.client.player == null ? 0 : this.client.player.experienceLevel;
            int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
            context.drawTextWithShadow(this.textRenderer, "经验 " + currentXp + "/" + route.experienceLevels(), left + 190, y + 7, xpColor);
            this.renderCardMarquee(
               this.cardCosts,
               attribute,
               this.costSummary(route),
               left + 190,
               y + 21,
               220,
               this.allCostsSatisfied(route) ? -11141291 : -43691,
               context,
               mouseX,
               mouseY,
               delta
            );
            this.renderCardMarquee(
               this.cardRequirement, attribute, "前置 " + this.requirementText(route), left + 190, y + 39, 220, -5592406, context, mouseX, mouseY, delta
            );
         }
      }
   }

   private List<RelicUpgradeScreen.Attribute> attributesFor(UpgradeDefinition.RelicType type) {
      return switch (type) {
         case BONE_ARMOR -> List.of(
         RelicUpgradeScreen.Attribute.MATERIAL,
         RelicUpgradeScreen.Attribute.ARMOR,
         RelicUpgradeScreen.Attribute.EFFICIENCY,
         RelicUpgradeScreen.Attribute.FORTUNE,
         RelicUpgradeScreen.Attribute.FIRE
      );
         case WAND -> List.of(
         RelicUpgradeScreen.Attribute.MATERIAL,
         RelicUpgradeScreen.Attribute.SPELL,
         RelicUpgradeScreen.Attribute.LIFESTEAL,
         RelicUpgradeScreen.Attribute.EXPLOSION
      );
         case PICKAXE -> List.of(RelicUpgradeScreen.Attribute.MATERIAL, RelicUpgradeScreen.Attribute.EFFICIENCY, RelicUpgradeScreen.Attribute.FORTUNE);
         case BONE -> List.of(
         RelicUpgradeScreen.Attribute.DAMAGE, RelicUpgradeScreen.Attribute.FIRE, RelicUpgradeScreen.Attribute.LOOTING, RelicUpgradeScreen.Attribute.LIFESTEAL
      );
         case AXE -> List.of(
         RelicUpgradeScreen.Attribute.MATERIAL,
         RelicUpgradeScreen.Attribute.EFFICIENCY,
         RelicUpgradeScreen.Attribute.FORTUNE,
         RelicUpgradeScreen.Attribute.DAMAGE,
         RelicUpgradeScreen.Attribute.EXPLOSION,
         RelicUpgradeScreen.Attribute.LIFESTEAL
      );
      };
   }

   private String attributeTitle(RelicUpgradeScreen.Attribute attribute) {
      boolean toolLike = this.category == UpgradeDefinition.RelicType.PICKAXE || this.category == UpgradeDefinition.RelicType.AXE;
      return switch (attribute) {
         case MATERIAL -> "材质";
         case ARMOR -> "护甲值";
         case EFFICIENCY -> toolLike ? "效率" : "保护";
         case FORTUNE -> toolLike ? "时运" : "韧性";
         case DAMAGE -> this.category == UpgradeDefinition.RelicType.AXE ? "巨力" : "主手伤害";
         case FIRE -> this.category == UpgradeDefinition.RelicType.BONE ? "火焰附加" : "荆棘";
         case LOOTING -> "抢夺";
         case LIFESTEAL -> "吸血";
         case SPELL -> "法术强度";
         case EXPLOSION -> this.category == UpgradeDefinition.RelicType.AXE ? "裂地" : "爆炸";
      };
   }

   private String levelText(RelicUpgradeScreen.Attribute attribute, int level) {
      return switch (attribute) {
         case MATERIAL -> this.materialName(level);
         case ARMOR -> "+" + level;
         default -> this.roman(level);
         case DAMAGE -> "+" + level;
         case LIFESTEAL -> (int)(RelicService.lifestealPercent(level) * 100.0F) + "%";
         case SPELL -> "+" + level;
         case EXPLOSION -> this.roman(level);
      };
   }

   private String materialName(int tier) {
      if (this.category == UpgradeDefinition.RelicType.WAND) {
         return tier == 1 ? "下界灵魂之杖" : "魔法法杖";
      } else if (this.category == UpgradeDefinition.RelicType.AXE) {
         return switch (Math.min(tier, 2)) {
            case 0 -> "骨";
            case 1 -> "钻石";
            default -> "下界合金";
         };
      } else {
         return switch (tier) {
            case 1 -> "钻石覆层";
            case 2 -> "下界合金铸体";
            case 3 -> "下界合金·铁";
            case 4 -> "下界合金·金";
            case 5 -> "下界合金·绿宝石";
            case 6 -> "下界合金·钻石";
            default -> "铁质";
         };
      }
   }

   private String requirementText(UpgradeDefinition route) {
      UpgradeDefinition.Requirement requirement = route.requirement();
      // 法杖二阶段（灵魂杖）：同时带材质与法术强度前置，优先展示"需法术强度满级"
      if (this.category == UpgradeDefinition.RelicType.WAND && requirement.armor() >= 0) {
         return "法术强度 +" + requirement.armor();
      }
      if (requirement.materialTier() >= 0) {
         return this.materialName(requirement.materialTier());
      } else if (requirement.efficiency() >= 0) {
         String key = this.category == UpgradeDefinition.RelicType.PICKAXE || this.category == UpgradeDefinition.RelicType.AXE ? "效率 " : "保护 ";
         return key + this.roman(requirement.efficiency());
      } else if (requirement.fortune() >= 0) {
         String key = this.category == UpgradeDefinition.RelicType.PICKAXE || this.category == UpgradeDefinition.RelicType.AXE
            ? "时运 "
            : (this.category == UpgradeDefinition.RelicType.WAND ? "吸血 " : (this.category == UpgradeDefinition.RelicType.BONE ? "吸血 " : "韧性 "));
         return key + this.roman(requirement.fortune());
      } else if (requirement.boneDamage() >= 0) {
         return this.category == UpgradeDefinition.RelicType.AXE
            ? "巨力 +" + requirement.boneDamage()
            : "伤害 +" + (9 + requirement.boneDamage());
      } else if (requirement.fireAspect() >= 0) {
         String key = this.category == UpgradeDefinition.RelicType.BONE ? "火焰 " : "荆棘 ";
         return key + this.roman(requirement.fireAspect());
      } else if (requirement.looting() >= 0) {
         return "抢夺 " + this.roman(requirement.looting());
      } else if (requirement.armor() >= 0) {
         return this.category == UpgradeDefinition.RelicType.WAND
            ? "法术强度 +" + requirement.armor()
            : (this.category == UpgradeDefinition.RelicType.AXE ? "吸血 " + this.roman(requirement.armor()) : "护甲值 +" + requirement.armor());
      } else {
         return requirement.explosion() >= 0
            ? (this.category == UpgradeDefinition.RelicType.AXE ? "裂地 " : "爆炸 ") + this.roman(requirement.explosion())
            : "无";
      }
   }

   private String roman(int value) {
      return switch (value) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> Integer.toString(value);
      };
   }

   private void renderStatusMarquee(DrawContext context, int y, int width, int mouseX, int mouseY, float delta) {
      this.statusText.setMessage(Text.literal(lastResult));
      this.statusText.setX(this.width / 2 - width / 2);
      this.statusText.setY(y - 1);
      this.statusText.setWidth(width);
      this.statusText.setColor(this.statusColor(lastResult));
      this.statusText.render(context, mouseX, mouseY, delta);
   }

   private void renderCardMarquee(
      Map<RelicUpgradeScreen.Attribute, MarqueeTextWidget> map,
      RelicUpgradeScreen.Attribute attribute,
      String text,
      int x,
      int y,
      int width,
      int color,
      DrawContext context,
      int mouseX,
      int mouseY,
      float delta
   ) {
      MarqueeTextWidget widget = map.computeIfAbsent(attribute, a -> new MarqueeTextWidget(Text.literal(""), 0, 0, width, 10));
      widget.setMessage(Text.literal(text));
      widget.setX(x);
      widget.setY(y - 1);
      widget.setWidth(width);
      widget.setColor(color);
      widget.render(context, mouseX, mouseY, delta);
   }

   private int statusColor(String status) {
      return status.startsWith("升级成功")
         ? -11141291
         : (!status.contains("不足") && !status.contains("不满足") && !status.contains("多件") && !status.contains("未找到") ? -13227 : -43691);
   }

   private String categoryTitle(UpgradeDefinition.RelicType type) {
      return switch (type) {
         case BONE_ARMOR -> "遗物骨甲";
         case WAND -> "魔法法杖";
         case PICKAXE -> "无尽铁镐";
         case BONE -> "战利品骨头";
         case AXE -> "骨斧";
      };
   }

   public void close() {
      if (activeScreen == this) {
         activeScreen = null;
      }

      this.client.setScreen(this.parent);
   }

   public boolean shouldPause() {
      return false;
   }

   private static enum Attribute {
      MATERIAL,
      ARMOR,
      EFFICIENCY,
      FORTUNE,
      DAMAGE,
      FIRE,
      LOOTING,
      LIFESTEAL,
      SPELL,
      EXPLOSION;
   }

   private static record CardPosition(int col, int row) {
   }

   private static record RelicSelection(ItemStack stack, int count) {
   }

   private static enum View {
      MODULES,
      SLOT_SELECT,
      FAMILY_SELECT,
      ATTRIBUTES,
      GROWTH;
   }

   /** 客户端：是否持有/穿戴虚空神心（背包或饰品栏任一位置）。 */
   private boolean clientHasVoidHeart() {
      // 与服务端同一实现：全容器扫描（背包 + 界面槽 + 光标 + 饰品栏 + 末影箱）
      return this.client != null && this.client.player != null
         && cn.bmcvp.relic.VoidHeartHandler.scanAllContainers(this.client.player);
   }
}
