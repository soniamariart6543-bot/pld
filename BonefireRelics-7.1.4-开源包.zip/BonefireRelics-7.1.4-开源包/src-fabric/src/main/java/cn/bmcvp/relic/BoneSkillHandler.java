package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDamage;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.damage.DamageTypes;

public final class BoneSkillHandler {
   private static final int MAX_TARGETS = 3;
   private static final Map<ServerPlayerEntity, Integer> HIT_COUNTS = new WeakHashMap<>();
   private static boolean castingSkill;

   private BoneSkillHandler() {
   }

   public static void initialize() {
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((AllowDamage)(target, source, amount) -> {
         if (amount <= 0.0F) {
            return true;
         } else if (source.getAttacker() instanceof ServerPlayerEntity player) {
            if (target == player || target.isRemoved()) {
               return true;
            } else if (!castingSkill && !source.isOf(DamageTypes.MAGIC) && !source.isOf(DamageTypes.INDIRECT_MAGIC)) {
               ItemStack stack = player.getMainHandStack();
               if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
                  return true;
               } else {
                  int hits = HIT_COUNTS.merge(player, 1, Integer::sum);
                  if (hits >= 3) {
                     HIT_COUNTS.put(player, 0);
                     trigger(player, target);
                  }

                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      });
   }

   private static void trigger(ServerPlayerEntity player, LivingEntity hitTarget) {
      ServerWorld world = player.getServerWorld();
      List<LivingEntity> candidates = new ArrayList<>();
      if (hitTarget instanceof HostileEntity) {
         candidates.add(hitTarget);
      }

      Box box = hitTarget.getBoundingBox().expand(6.0);

      for (Entity entity : world.getEntitiesByClass(HostileEntity.class, box, e -> e != hitTarget && e.isAlive())) {
         candidates.add((LivingEntity)entity);
      }

      if (candidates.isEmpty()) {
         candidates.add(hitTarget);
      }

      candidates.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(hitTarget)));
      int count = Math.min(3, candidates.size());
      float skillDamage = currentSkillDamage(player);
      DamageSource source = player.getDamageSources().indirectMagic(player, player);
      castingSkill = true;

      try {
         for (int i = 0; i < count; i++) {
            LivingEntity target = candidates.get(i);
            float actual = skillDamage;
            if (player.getRandom().nextFloat() < 0.25F) {
               actual = skillDamage * 1.5F;
            }

            target.damage(source, actual);
            world.spawnParticles(
               ParticleTypes.FLAME,
               target.getX(),
               target.getY() + (double)(target.getHeight() / 2.0F),
               target.getZ(),
               24,
               0.5,
               0.4,
               0.5,
               0.05
            );
         }
      } finally {
         castingSkill = false;
      }
   }

   private static float currentSkillDamage(ServerPlayerEntity player) {
      ItemStack stack = player.getMainHandStack();
      int damageLevel = RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE) ? RelicService.value(stack, "damage") : 0;
      float base = Math.min(8.0F + (float)damageLevel * 1.0F, 20.0F);
      return base + WandSkillHandler.allSpellPowerBonus(player);
   }
}
