package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import cn.bmcvp.relic.WandSkillHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 遗物近战武器伤害管线（服务端守卫版，2026-09-08 重构）：
 * - 骨头 / 骨斧：每次近战攻击命中后 1.2% 纯概率一击必杀（真伤处决：无视血线/护甲/附魔/无敌帧）。
 *   骨头不再要求 fire==2（需求 #3：骨头也改为纯概率一击必杀）。
 * - 骨头：非处决命中仍保留 骨火（火焰/冰霜/奥术属性魔法溅射）与 骨裂（攻击≥20 追加 8% 当前生命）。
 * - 守卫：spell_power 缺失时骨火自动关闭（服务端环境隔离）；
 *   本 mod 真伤 bonefire_relics:true_magic 一律放行（防处决/裂地冲击波/血涌递归）。
 */
@Mixin({LivingEntity.class})
public abstract class InstantKillMixin {
   private static final float INSTANT_KILL_CHANCE = 0.012F;
   private static final RegistryKey<DamageType> TRUE_MAGIC_KEY =
      RegistryKey.of(RegistryKeys.DAMAGE_TYPE, new Identifier("bonefire_relics", "true_magic"));

   @ModifyVariable(method = {"damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"}, at = @At("HEAD"), argsOnly = true, require = 0)
   private float bmcvp$modifyBoneDamage(float amount, DamageSource source) {
      if (amount <= 0.0F) {
         return amount;
      } else if (source.getAttacker() instanceof ServerPlayerEntity player) {
         // 本 mod 真伤放行（防递归）
         if (source.isOf(TRUE_MAGIC_KEY)) {
            return amount;
         }

         LivingEntity target = (LivingEntity)(Object)this;
         if (target == player || target instanceof PlayerEntity || !target.isAlive()) {
            return amount;
         } else if (source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC)) {
            // 原版魔法段（法杖魔法/骨火溅射等）不进入近战管线
            return amount;
         } else {
            ItemStack stack = player.getMainHandStack();
            boolean isBone = RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE);
            boolean isAxe = RelicService.isRelic(stack, UpgradeDefinition.RelicType.AXE);
            if (!isBone && !isAxe) {
               return amount;
            } else {
               // —— 纯概率一击必杀（骨头 & 骨斧统一 1.2%，真伤处决）——
               if (player.getRandom().nextFloat() < INSTANT_KILL_CHANCE) {
                  if (target.getWorld() instanceof ServerWorld world) {
                     world.spawnParticles(
                        ParticleTypes.CRIT,
                        target.getX(),
                        target.getY() + (double)(target.getHeight() / 2.0F),
                        target.getZ(),
                        40,
                        0.6,
                        0.5,
                        0.6,
                        0.1
                     );
                  }

                  // 玩家归属处决（2026-09-13 修正）：走 playerAttack 伤害源，
                  // 否则 genericKill 无击杀者 → 抢夺附魔 / 神心加成 / 经验全部失效
                  cn.bmcvp.relic.VoidHeartHandler.executeWithCredit(player, target);
                  return 0.0F; // 取消原近战伤害，由真伤处决承担（避免双重扣血/重复触发）
               } else if (isBone) {
                  // —— 骨头附加：骨火（魔法溅射，spell_power 守卫）+ 骨裂（8% 当前生命）——
                  float schoolSum = 0.0F;
                  if (FabricLoader.getInstance().isModLoaded("spell_power")) {
                     schoolSum = (float)(
                        player.getAttributeValue(net.spell_power.api.SpellSchools.FIRE.attribute)
                           + player.getAttributeValue(net.spell_power.api.SpellSchools.FROST.attribute)
                           + player.getAttributeValue(net.spell_power.api.SpellSchools.ARCANE.attribute)
                     );
                  }

                  float magicProc = amount * (0.18F + schoolSum * 0.01F);
                  if (magicProc > 0.0F) {
                     target.damage(player.getDamageSources().indirectMagic(player, player), magicProc);
                  }

                  int attack = 9 + RelicService.value(stack, "damage");
                  return attack >= 20 ? amount + target.getHealth() * 0.08F : amount;
               } else {
                  // 骨斧：处决之外的普通命中原样放行（血涌/裂地/吸血由 AxeSkillHandler 在事件层处理）
                  return amount;
               }
            }
         }
      } else {
         return amount;
      }
   }
}
