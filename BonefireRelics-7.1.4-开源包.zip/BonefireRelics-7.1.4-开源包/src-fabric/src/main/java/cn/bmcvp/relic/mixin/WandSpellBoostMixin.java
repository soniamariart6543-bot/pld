package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import cn.bmcvp.relic.WandSkillHandler;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class WandSpellBoostMixin {
   @ModifyVariable(
      method = {"damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"},
      at = @At("HEAD"),
      argsOnly = true,
      require = 0
   )
   private float bmcvp$boostSpellBook(float amount, DamageSource source) {
      if (amount <= 0.0F) {
         return amount;
      } else if (source.getAttacker() instanceof ServerPlayerEntity player) {
         LivingEntity target = (LivingEntity)(Object)this;
         if (target != player && !target.isRemoved() && target.isAlive()) {
            ItemStack stack = player.getMainHandStack();
            if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
               return amount;
            } else {
               float mult = WandSkillHandler.spellBookAmplify(player, source);
               return mult <= 1.0F ? amount : amount * mult;
            }
         } else {
            return amount;
         }
      } else {
         return amount;
      }
   }

   @Inject(
      method = {"damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"},
      at = {@At("RETURN")},
      require = 0
   )
   private void bmcvp$lifestealSpellBook(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
      if (cir.getReturnValueZ() && !(amount <= 0.0F)) {
         if (source.getAttacker() instanceof ServerPlayerEntity player) {
            LivingEntity target = (LivingEntity)(Object)this;
            if (target != player && !target.isRemoved()) {
               ItemStack stack = player.getMainHandStack();
               if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
                  if (source.isIn(WandSkillHandler.SPELL_POWER_ALL)) {
                     WandSkillHandler.lifestealFrom(player, amount);
                  }
               }
            }
         }
      }
   }
}
