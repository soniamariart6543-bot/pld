package cn.bmcvp.relic;

import net.minecraft.item.Item;
import net.minecraft.item.Item.Settings;

public class RelicBoneItem extends Item {
   public RelicBoneItem() {
      super(new Settings().maxCount(1).fireproof());
   }
}
