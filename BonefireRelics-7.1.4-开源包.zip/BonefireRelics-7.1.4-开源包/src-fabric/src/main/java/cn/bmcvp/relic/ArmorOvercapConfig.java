package cn.bmcvp.relic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ArmorOvercapConfig {
   public static final String FILE_NAME = "bonefire_relics_armor_overcap.json";
   public boolean enabled = true;
   public double threshold = 40.0;
   public int minRelicArmorPieces = 1;
   /** 神心的地面移动速度加成（ADDITION 到 generic.movement_speed；原版基础 0.1）。0.1 ≈ 2 倍速。 */
   public double heartSpeedBonus = 0.03;   // 神心移速加成：原版基础 0.1 + 0.03 = 0.13 ≈ 原版疾跑速度（2026-09-13 昀晞）
   /** 神心的飞行速度（原版默认 0.05；设 0.1 = 飞行翻倍）。 */
   public double heartFlySpeed = 0.1;   // 2026-09-13：改为 1 件（骨甲融合后身上无骨甲，1 件更实际）
   public double drPercentPerPoint = 1.0;
   public double drCapPercent = 95.0;
   public String healthMode = "PERCENT";
   public double healthPerPoint = 1.0;
   public double healthCap = 160.0;
   public double magicResistPercentPerPoint = 1.0;
   public double magicResistCapPercent = 55.0;
   private static ArmorOvercapConfig instance = new ArmorOvercapConfig();

   private ArmorOvercapConfig() {
   }

   public static ArmorOvercapConfig get() {
      return instance;
   }

   public static void load() {
      Path dir = Path.of("config");
      Path file = dir.resolve("bonefire_relics_armor_overcap.json");
      Gson gson = new GsonBuilder().setPrettyPrinting().create();

      try {
         if (Files.exists(file)) {
            ArmorOvercapConfig parsed = (ArmorOvercapConfig)gson.fromJson(Files.readString(file, StandardCharsets.UTF_8), ArmorOvercapConfig.class);
            if (parsed != null) {
               instance = parsed;
            }
         } else {
            Files.createDirectories(dir);
            Files.writeString(file, gson.toJson(instance), StandardCharsets.UTF_8);
         }
      } catch (IOException var4) {
      }

      sanitize();
   }

   private static void sanitize() {
      if (instance.threshold < 0.0) {
         instance.threshold = 0.0;
      }

      if (instance.minRelicArmorPieces < 1) {
         instance.minRelicArmorPieces = 1;
      }

      if (instance.drPercentPerPoint < 0.0) {
         instance.drPercentPerPoint = 0.0;
      }

      if (instance.drPercentPerPoint > 10.0) {
         instance.drPercentPerPoint = 10.0;
      }

      if (instance.drCapPercent < 0.0) {
         instance.drCapPercent = 0.0;
      }

      if (instance.drCapPercent > 99.0) {
         instance.drCapPercent = 99.0;
      }

      if (instance.healthPerPoint < 0.0) {
         instance.healthPerPoint = 0.0;
      }

      if (instance.healthCap < 0.0) {
         instance.healthCap = 0.0;
      }

      if (instance.magicResistPercentPerPoint < 0.0) {
         instance.magicResistPercentPerPoint = 0.0;
      }

      if (instance.magicResistPercentPerPoint > 10.0) {
         instance.magicResistPercentPerPoint = 10.0;
      }

      if (instance.magicResistCapPercent < 0.0) {
         instance.magicResistCapPercent = 0.0;
      }

      if (instance.magicResistCapPercent > 99.0) {
         instance.magicResistCapPercent = 99.0;
      }

      if (!"HP".equals(instance.healthMode)) {
         instance.healthMode = "PERCENT";
      }


   }

   public boolean isHpMode() {
      return "HP".equals(this.healthMode);
   }


}
