本目录用于放置「编译期依赖」，请按下表的**准确文件名**放入 jar 后再执行 gradlew build。

必须放入（本包不附带，请自行下载对应版本）：
  spell_engine-0.15.12+1.20.1.jar     —— 法术引擎（法术书 / 法术容器 API）
  spell_power-0.12.0+1.20.1.jar       —— 法术强度三系属性（奥术 / 火焰 / 冰霜）
  trinkets-3.7.2.jar                  —— 饰品栏（法术书槽 charm/spell_book）

获取方式：在 Modrinth 或 CurseForge 搜索对应模组名（Spell Engine / Spell Power / Trinkets），
下载与 Minecraft 1.20.1 + Fabric 匹配的版本；文件名若与上表不同，请改名或同步修改
src-fabric\build.gradle 里的 externalMods 列表。

已随包附带：
  cca-compile-stub.jar                —— 本工程自带的 2KB 空接口桩（Cardinal Components API 5.2.3
                                         继承链闭合用；仅 compileOnly，不会打进发布 jar）

缺少依赖时的表现：build.gradle 会打印「守卫依赖缺失，已跳过」警告，随后编译因找不到
net.spell_engine.* / net.spell_power.* / dev.emi.trinkets.* 符号而失败——补齐 jar 即恢复。

提示：这三个模组在运行期是**软依赖**（fabric.mod.json 中列为 suggests）。发布出去的 jar 即使
目标环境没有它们也能正常加载：秘法核心与虚空神心会降级为护甲形态，其余功能不受影响。
