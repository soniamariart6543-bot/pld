package cn.bmcvp.relic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 护甲超限转化配置。读取 config/bonefire_relics_armor_overcap.json，缺失则生成默认模板。
 */
public final class ArmorOvercapConfig {
    public static final String FILE_NAME = "bonefire_relics_armor_overcap.json";

    public boolean enabled = true;
    public double threshold = 40.0;
    public int minRelicArmorPieces = 2;
    public double drPercentPerPoint = 0.5;
    public double drCapPercent = 95.0;
    public String healthMode = "PERCENT";
    public double healthPerPoint = 1.0;
    public double healthCap = 100.0;
    public String armorSource = "TOTAL_ATTRIBUTE";

    private static ArmorOvercapConfig instance = new ArmorOvercapConfig();

    private ArmorOvercapConfig() {
    }

    public static ArmorOvercapConfig get() {
        return instance;
    }

    public static void load() {
        Path dir = Path.of("config");
        Path file = dir.resolve(FILE_NAME);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            if (Files.exists(file)) {
                ArmorOvercapConfig parsed = gson.fromJson(Files.readString(file, StandardCharsets.UTF_8),
                        ArmorOvercapConfig.class);
                if (parsed != null) {
                    instance = parsed;
                }
            } else {
                Files.createDirectories(dir);
                Files.writeString(file, gson.toJson(instance), StandardCharsets.UTF_8);
            }
        } catch (IOException ignored) {
            // 配置不可用时使用默认值
        }
        sanitize();
    }

    private static void sanitize() {
        if (instance.threshold < 0) {
            instance.threshold = 0;
        }
        if (instance.minRelicArmorPieces < 1) {
            instance.minRelicArmorPieces = 1;
        }
        if (instance.drPercentPerPoint < 0) {
            instance.drPercentPerPoint = 0;
        }
        if (instance.drPercentPerPoint > 10) {
            instance.drPercentPerPoint = 10;
        }
        if (instance.drCapPercent < 0) {
            instance.drCapPercent = 0;
        }
        if (instance.drCapPercent > 99) {
            instance.drCapPercent = 99;
        }
        if (instance.healthPerPoint < 0) {
            instance.healthPerPoint = 0;
        }
        if (instance.healthCap < 0) {
            instance.healthCap = 0;
        }
        if (!"HP".equals(instance.healthMode)) {
            instance.healthMode = "PERCENT";
        }
        if (!"RELIC_NBT".equals(instance.armorSource)) {
            instance.armorSource = "TOTAL_ATTRIBUTE";
        }
    }

    public boolean isHpMode() {
        return "HP".equals(healthMode);
    }

    public boolean isRelicNbtSource() {
        return "RELIC_NBT".equals(armorSource);
    }
}
