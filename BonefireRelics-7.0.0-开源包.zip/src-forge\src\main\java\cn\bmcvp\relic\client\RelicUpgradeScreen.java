package cn.bmcvp.relic.client;

import cn.bmcvp.relic.ArmorOvercapConfig;
import cn.bmcvp.relic.ArmorOvercapHandler;
import cn.bmcvp.relic.ModItems;
import cn.bmcvp.relic.RelicNetworking;
import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * 遗物升级界面（Forge 移植版）。
 * 创造模式：升级免费（服务端校验）；模块首页显示各遗物发放按钮。
 */
public class RelicUpgradeScreen extends Screen {
    private static final int RESULT_REFRESH_DELAY_TICKS = 5;
    private static String lastResult = "选择一件遗物";
    private static RelicUpgradeScreen activeScreen;

    private final Screen parent;
    private View view = View.MODULES;
    private UpgradeDefinition.RelicType category;
    private int armorSlot = -1; // -1=未选部位, 0=头盔, 1=胸甲, 2=护腿, 3=靴子
    private boolean refreshRequested;
    private int refreshDelayTicks;

    // 跑马灯文字组件：显示完整的长文字（超出宽度自动滚动 + 悬停完整 Tooltip）
    private final MarqueeTextWidget statusText = new MarqueeTextWidget(Component.literal(lastResult), 0, 0, 300, 12);
    private final MarqueeTextWidget overcapStatusText = new MarqueeTextWidget(Component.literal(""), 0, 0, 400, 12);
    private final Map<Attribute, MarqueeTextWidget> cardProgression = new EnumMap<>(Attribute.class);
    private final Map<Attribute, MarqueeTextWidget> cardRequirement = new EnumMap<>(Attribute.class);
    private final Map<Attribute, MarqueeTextWidget> cardCosts = new EnumMap<>(Attribute.class);
    private final MarqueeTextWidget familyCostMarquee = new MarqueeTextWidget(Component.literal(""), 0, 0, 180, 10);
    private final MarqueeTextWidget familyProgressionMarquee = new MarqueeTextWidget(Component.literal(""), 0, 0, 180, 10);
    private final MarqueeTextWidget familyRequirementMarquee = new MarqueeTextWidget(Component.literal(""), 0, 0, 180, 10);

    /** 背包物品数量缓存：每 tick 刷新一次，避免每帧对每个卡片全背包遍历统计材料。 */
    private Map<Item, Integer> inventoryCounts = Map.of();

    public RelicUpgradeScreen(Screen parent) {
        super(Component.literal("遗物升级"));
        this.parent = parent;
    }

    public static void receiveServerResult(String text) {
        lastResult = text;
        if (activeScreen != null) {
            activeScreen.requestRefreshAfterInventorySync();
        }
    }

    private void requestRefreshAfterInventorySync() {
        this.refreshRequested = true;
        this.refreshDelayTicks = RESULT_REFRESH_DELAY_TICKS;
    }

    @Override
    protected void init() {
        activeScreen = this;
        if (this.view == View.MODULES) {
            initModuleButtons();
        } else if (this.view == View.SLOT_SELECT) {
            initSlotSelectButtons();
        } else if (this.view == View.FAMILY_SELECT) {
            initFamilySelectButtons();
        } else {
            initAttributeButtons();
        }
    }

    @Override
    public void tick() {
        super.tick();
        refreshInventoryCounts();
        if (!this.refreshRequested) {
            return;
        }
        if (this.refreshDelayTicks-- > 0) {
            return;
        }
        this.refreshRequested = false;
        if (this.minecraft != null && this.minecraft.player != null
                && (this.view == View.ATTRIBUTES || this.view == View.MODULES)) {
            this.rebuild();
        }
    }

    private boolean isCreative() {
        return this.minecraft != null && this.minecraft.player != null
                && this.minecraft.player.getAbilities().instabuild;
    }

    // =====================================================================
    // 模块选择视图
    // =====================================================================
    private void initSlotSelectButtons() {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 82;
        String[] names = {"头盔", "胸甲", "护腿", "靴子"};
        for (int i = 0; i < 4; i++) {
            final int slot = i;
            addRenderableWidget(Button.builder(Component.literal(names[i]), b -> {
                this.armorSlot = slot;
                this.view = View.ATTRIBUTES;
                this.rebuild();
            }).bounds(left + 14, top + 46 + i * 30, 130, 24).build());
        }
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> {
            this.view = View.MODULES;
            this.category = null;
            this.rebuild();
        }).bounds(this.width / 2 - 40, top + 170, 80, 20).build());
    }

    private void initModuleButtons() {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 82;
        addRenderableWidget(moduleButton(left + 14, top + 46, 130, ModItems.RELIC_IRON_PICKAXE.get(),
                UpgradeDefinition.RelicType.PICKAXE));
        // 骨头 ⇄ 法杖一体两面：卡片点击进入当前形态对应属性视图
        boolean isWand = "magic_wand".equals(currentBoneOrWandKind());
        addRenderableWidget(moduleButton(left + 156, top + 46, 116,
                isWand ? ModItems.MAGIC_WAND.get() : ModItems.RELIC_BONE.get(),
                isWand ? UpgradeDefinition.RelicType.WAND : UpgradeDefinition.RelicType.BONE));
        addRenderableWidget(moduleButton(left + 85, top + 116, 130, ModItems.RELIC_BONE_CHESTPLATE.get(),
                UpgradeDefinition.RelicType.BONE_ARMOR));
        // 切换按钮：骨头 ⇄ 法杖（物品本体互换，各自升级数据保留）。
        // 只做切换，不跳转、不改变视图；停留在当前模块视图并刷新显示（骨头卡片跟随形态）。
        addRenderableWidget(Button.builder(Component.literal("⇄"), b -> {
            cn.bmcvp.relic.RelicNetworking.sendToServer(new cn.bmcvp.relic.RelicNetworking.WandSwitchPacket());
            this.lastResult = "切换请求已发送…";
            this.requestRefreshAfterInventorySync();
        }).bounds(left + 274, top + 46, 24, 56).build());
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> this.minecraft.setScreen(this.parent))
                .bounds(this.width / 2 - 40, top + 170, 80, 20).build());

        // 创造模式：各遗物发放按钮（服务端校验 instabuild）
        if (isCreative()) {
            int y = top + 200;
            addRenderableWidget(Button.builder(Component.literal("发放：无尽铁镐"), b -> sendGrant("pickaxe"))
                    .bounds(left + 8, y, 92, 20).build());
            addRenderableWidget(Button.builder(Component.literal("发放：战利品骨头"), b -> sendGrant("bone"))
                    .bounds(left + 104, y, 92, 20).build());
            addRenderableWidget(Button.builder(Component.literal("发放：遗物骨甲"), b -> sendGrant("bone_armor"))
                    .bounds(left + 200, y, 92, 20).build());
            addRenderableWidget(Button.builder(Component.literal("发放：骨与火"), b -> sendGrant("guide"))
                    .bounds(left + 8, y + 24, 92, 20).build());
            addRenderableWidget(Button.builder(Component.literal("发放：魔法法杖"), b -> sendGrant("wand"))
                    .bounds(left + 104, y + 24, 92, 20).build());
        }
    }

    private Button moduleButton(int x, int y, int width, Item icon, UpgradeDefinition.RelicType type) {
        return Button.builder(Component.literal(""), b -> openCategory(type))
                .bounds(x, y, width, 56).build();
    }

    private void sendGrant(String relic) {
        RelicNetworking.sendToServer(new RelicNetworking.GrantRequestPacket(relic));
        lastResult = "创造模式发放请求已发送…";
        this.requestRefreshAfterInventorySync();
    }

    private void openCategory(UpgradeDefinition.RelicType type) {
        this.category = type;
        if (type == UpgradeDefinition.RelicType.BONE_ARMOR) {
            this.armorSlot = -1;
            this.view = View.SLOT_SELECT;
        } else {
            this.armorSlot = -1;
            this.view = View.ATTRIBUTES;
        }
        lastResult = categoryTitle(type);
        this.rebuild();
    }

    // =====================================================================
    // 属性视图
    // =====================================================================
    private void initAttributeButtons() {
        if (this.category == UpgradeDefinition.RelicType.BONE_ARMOR) {
            initArmorColumnButtons();
            return;
        }
        int left = this.width / 2 - 215;
        int top = this.height / 2 - 185;
        List<Attribute> attributes = attributesFor(this.category);
        RelicSelection selection = relicSelection(this.category);
        boolean conflict = selection.count() > 1;
        boolean hasTarget = selection.stack() != null;

        for (int i = 0; i < attributes.size(); i++) {
            Attribute attribute = attributes.get(i);
            UpgradeDefinition route = hasTarget ? nextRoute(attribute, selection.stack()) : null;
            int current = hasTarget ? currentLevel(attribute, selection.stack()) : 0;
            String label = route == null ? "已满级" : "升级至 " + levelText(attribute, current + 1);
            Button button = Button.builder(Component.literal(label), pressed -> sendUpgrade(route))
                    .bounds(left + 18, top + 49 + i * 62, 158, 20).build();
            button.active = route != null && hasTarget && !conflict;
            addRenderableWidget(button);
            // v7.0.0 创造模式一键满级：升级按钮右侧小按钮（仅创造模式显示）
            addMaxUpgradeButton(left + 182, top + 49 + i * 62, 56, 20, route, hasTarget && !conflict);
        }

        addRenderableWidget(Button.builder(Component.literal("←"), b -> {
            this.view = View.MODULES;
            this.category = null;
            this.rebuild();
        }).bounds(left + 18, top + 320, 24, 20).build());
        // 骨头 ⇄ 法杖双向切换（物品本体互换，界面跟随形态）
        if (this.category == UpgradeDefinition.RelicType.WAND || this.category == UpgradeDefinition.RelicType.BONE) {
            addRenderableWidget(Button.builder(Component.literal("⇄ 切换遗物"), b -> {
                cn.bmcvp.relic.RelicNetworking.sendToServer(new cn.bmcvp.relic.RelicNetworking.WandSwitchPacket());
                this.category = this.category == UpgradeDefinition.RelicType.BONE
                        ? UpgradeDefinition.RelicType.WAND : UpgradeDefinition.RelicType.BONE;
                this.lastResult = "切换请求已发送…";
                this.rebuild();
            }).bounds(left + 200, top + 320, 90, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> this.minecraft.setScreen(this.parent))
                .bounds(left + 376, top + 320, 44, 20).build());
    }

    private void sendUpgrade(UpgradeDefinition route) {
        if (route == null) {
            return;
        }
        RelicNetworking.sendToServer(new RelicNetworking.UpgradeRequestPacket(route.id(), this.armorSlot));
        lastResult = isCreative() ? "创造模式：升级请求已发送（免费）…" : "升级请求已发送…";
        this.requestRefreshAfterInventorySync();
    }

    /** v7.0.0：创造模式一键满级请求（服务端校验 creativeMode，仅将单属性拉满）。 */
    private void sendMaxUpgrade(UpgradeDefinition route) {
        if (route == null) {
            return;
        }
        RelicNetworking.sendToServer(new RelicNetworking.MaxUpgradeRequestPacket(route.id(), this.armorSlot));
        lastResult = "创造模式：一键满级请求已发送…";
        this.requestRefreshAfterInventorySync();
    }

    /**
     * v7.0.0：创建「一键满级」小按钮（置于升级按钮右侧）。
     * 仅创造模式且存在下一级路线时显示；已满级 / 非创造不显示，保持页面整洁。
     */
    private void addMaxUpgradeButton(int x, int y, int width, int height, UpgradeDefinition route, boolean active) {
        if (!isCreative() || route == null) {
            return;
        }
        Button button = Button.builder(Component.literal("满级"), pressed -> sendMaxUpgrade(route))
                .tooltip(Tooltip.create(Component.literal("创造模式：一键将该项拉满（服务端校验，免费）")))
                .bounds(x, y, width, height).build();
        button.active = active;
        addRenderableWidget(button);
    }

    // =====================================================================
    // 数据读取
    // =====================================================================
    private void refreshInventoryCounts() {
        if (this.minecraft == null || this.minecraft.player == null) {
            this.inventoryCounts = Map.of();
            return;
        }
        Map<Item, Integer> counts = new HashMap<>();
        for (ItemStack stack : this.minecraft.player.getInventory().items) {
            if (!stack.isEmpty()) {
                counts.merge(stack.getItem(), stack.getCount(), Integer::sum);
            }
        }
        ItemStack offHand = this.minecraft.player.getOffhandItem();
        if (!offHand.isEmpty()) {
            counts.merge(offHand.getItem(), offHand.getCount(), Integer::sum);
        }
        this.inventoryCounts = counts;
    }

    private int availableCostItems(Item item) {
        return this.inventoryCounts.getOrDefault(item, 0);
    }

    private RelicSelection relicSelection(UpgradeDefinition.RelicType type) {
        if (this.minecraft == null || this.minecraft.player == null) {
            return new RelicSelection(null, 0);
        }
        ItemStack single = null;
        int count = 0;
        for (ItemStack stack : this.minecraft.player.getInventory().items) {
            if (!RelicService.isRelic(stack, type)) {
                continue;
            }
            if (type == UpgradeDefinition.RelicType.BONE_ARMOR && !matchesSlot(stack, this.armorSlot)) {
                continue;
            }
            count++;
            single = stack;
        }
        ItemStack offHand = this.minecraft.player.getOffhandItem();
        if (RelicService.isRelic(offHand, type)
                && (type != UpgradeDefinition.RelicType.BONE_ARMOR || matchesSlot(offHand, this.armorSlot))) {
            count++;
            single = offHand;
        }
        return new RelicSelection(count == 1 ? single : null, count);
    }

    /** 当前骨头/法杖形态：返回持有中的 kind（"bone" 或 "magic_wand"），未持有返回 null。 */
    private String currentBoneOrWandKind() {
        if (this.minecraft == null || this.minecraft.player == null) {
            return null;
        }
        for (ItemStack stack : this.minecraft.player.getInventory().items) {
            String kind = relicKind(stack);
            if ("bone".equals(kind) || "magic_wand".equals(kind)) {
                return kind;
            }
        }
        String offHand = relicKind(this.minecraft.player.getOffhandItem());
        return "bone".equals(offHand) || "magic_wand".equals(offHand) ? offHand : null;
    }

    private static String relicKind(ItemStack stack) {
        if (stack.isEmpty() || !stack.hasTag() || !stack.getTag().contains("bonefire_relics", 10)) {
            return "";
        }
        return stack.getTag().getCompound("bonefire_relics").getString("item");
    }

    /** 判断骨甲堆叠是否属于当前选择的部位。 */
    private boolean matchesSlot(ItemStack stack, int slot) {
        if (slot < 0 || !stack.hasTag()) {
            return false;
        }
        String kind = stack.getTag().getCompound("bonefire_relics").getString("item");
        String[] slots = {"helmet", "chestplate", "leggings", "boots"};
        return kind.equals("bone_" + slots[slot]);
    }

    private UpgradeDefinition nextRoute(Attribute attribute, ItemStack stack) {
        if (stack == null || !stack.hasTag()) {
            return null;
        }
        String prefix = "ba_";
        String routeId = switch (attribute) {
            case MATERIAL -> {
                int v = RelicService.value(stack, "tier");
                yield switch (this.category) {
                    case BONE_ARMOR -> (v < 2 ? "bam" + (v + 1) : null);
                    case WAND -> (v < 1 ? "soul" + (v + 1) : null); // 法杖材质：soul1 = 下界灵魂之杖
                    default -> (v < 6 ? "m" + (v + 1) : null);
                };
            }
            case ARMOR -> {
                int v = RelicService.value(stack, "armor");
                int cap = RelicService.armorCap(RelicService.value(stack, "tier"));
                yield v < cap ? prefix + "armor" + (v + 1) : null;
            }
            case EFFICIENCY -> {
                int v = RelicService.value(stack, "efficiency");
                yield this.category == UpgradeDefinition.RelicType.PICKAXE
                        ? (v < 5 ? "eff" + (v + 1) : null)
                        : (v < 5 ? prefix + "prot" + (v + 1) : null);
            }
            case FORTUNE -> {
                int v = RelicService.value(stack, "fortune");
                yield this.category == UpgradeDefinition.RelicType.PICKAXE
                        ? (v < 10 ? "fortune" + (v + 1) : null)
                        : (v < 10 ? prefix + "tough" + (v + 1) : null);
            }
            case DAMAGE -> {
                int v = RelicService.value(stack, "damage");
                yield v < 41 ? "d" + (v + 1) : null;
            }
            case FIRE -> {
                int v = RelicService.value(stack, "fire");
                yield this.category == UpgradeDefinition.RelicType.BONE
                        ? (v < 2 ? "fire" + (v + 1) : null)
                        : (v < 3 ? prefix + "thorn" + (v + 1) : null);
            }
            case LOOTING -> {
                int v = RelicService.value(stack, "looting");
                yield v < 10 ? "loot" + (v + 1) : null;
            }
            case LIFESTEAL -> {
                int v = this.category == UpgradeDefinition.RelicType.WAND
                        ? RelicService.value(stack, "wfortune") : RelicService.value(stack, "fortune");
                yield v < 10 ? (this.category == UpgradeDefinition.RelicType.WAND
                        ? "wlifesteal" + (v + 1) : "lifesteal" + (v + 1)) : null;
            }
            case SPELL -> {
                int v = RelicService.value(stack, "spell");
                yield v < 30 ? "spell" + (v + 1) : null;
            }
            case EXPLOSION -> {
                int v = RelicService.value(stack, "explosion");
                // 下界灵魂之杖（tier 1）爆炸最高 12 级，普通法杖 10 级
                int cap = RelicService.value(stack, "tier") == 1 ? 12 : 10;
                yield v < cap ? "expl" + (v + 1) : null;
            }
            default -> null;
        };
        return routeId == null ? null : UpgradeDefinition.byId(routeId);
    }

    private UpgradeDefinition protectionFamilyRoute(ItemStack stack, int ptype) {
        if (stack == null || !stack.hasTag()) {
            return null;
        }
        int currentType = RelicService.value(stack, "looting");
        int currentLevel = RelicService.value(stack, "damage");
        if (currentType != 0 && currentType != ptype) {
            return null;
        }
        if (currentLevel >= 5) {
            return null;
        }
        String prefix = "ba_";
        String key = switch (ptype) {
            case 1 -> "fp";
            case 2 -> "bp";
            default -> "pp";
        };
        return UpgradeDefinition.byId(prefix + key + (currentLevel + 1));
    }

    private int currentProtectionLevel(ItemStack stack, int ptype) {
        int currentType = RelicService.value(stack, "looting");
        return currentType == ptype ? RelicService.value(stack, "damage") : 0;
    }

    private int currentLevel(Attribute attribute, ItemStack stack) {
        return switch (attribute) {
            case MATERIAL -> RelicService.value(stack, "tier");
            case ARMOR -> RelicService.value(stack, "armor");
            case EFFICIENCY -> RelicService.value(stack, "efficiency");
            case FORTUNE -> RelicService.value(stack, "fortune");
            case DAMAGE -> 9 + RelicService.value(stack, "damage");
            case FIRE -> RelicService.value(stack, "fire");
            case LOOTING -> RelicService.value(stack, "looting");
            case LIFESTEAL -> this.category == UpgradeDefinition.RelicType.WAND
                    ? RelicService.value(stack, "wfortune") : RelicService.value(stack, "fortune");
            case SPELL -> RelicService.value(stack, "spell");
            case EXPLOSION -> RelicService.value(stack, "explosion");
        };
    }

    // =====================================================================
    // 骨甲视图：两列布局 + 护甲超限转化状态条
    // =====================================================================
    private static final int ARMOR_PANEL_W = 430;
    private static final int ARMOR_PANEL_H = 264;
    private static final int ARMOR_COL1_X = 10;
    private static final int ARMOR_COL2_X = 216;
    private static final int ARMOR_CARD_W = 204;
    private static final int ARMOR_CARD_H = 58;
    private static final int ARMOR_CARD_GAP = 6;
    private static final int ARMOR_CARDS_TOP = 44;
    private static final int ARMOR_BOTTOM_Y = 240;

    private int armorPanelLeft() {
        return this.width / 2 - ARMOR_PANEL_W / 2;
    }

    private int armorPanelTop() {
        return this.height / 2 - ARMOR_PANEL_H / 2;
    }

    private record CardPosition(int col, int row) {
    }

    private static CardPosition cardPosition(Attribute attribute) {
        return switch (attribute) {
            case MATERIAL -> new CardPosition(0, 0);
            case EFFICIENCY -> new CardPosition(0, 1);
            case FIRE -> new CardPosition(0, 2);
            case ARMOR -> new CardPosition(1, 0);
            case FORTUNE -> new CardPosition(1, 1);
            default -> new CardPosition(0, 0);
        };
    }

    private void initArmorColumnButtons() {
        int left = armorPanelLeft();
        int top = armorPanelTop();
        List<Attribute> attributes = attributesFor(this.category);
        RelicSelection selection = relicSelection(this.category);
        boolean conflict = selection.count() > 1;
        boolean hasTarget = selection.stack() != null;

        for (Attribute attribute : attributes) {
            CardPosition pos = cardPosition(attribute);
            UpgradeDefinition route = hasTarget ? nextRoute(attribute, selection.stack()) : null;
            int current = hasTarget ? currentLevel(attribute, selection.stack()) : 0;
            String label = route == null ? "已满级" : "升级至 " + levelText(attribute, current + 1);
            // v7.0.0：升级按钮左移 20px，右侧留出「一键满级」小按钮位（两列对称，不越卡片右缘）
            int x = left + (pos.col() == 0 ? ARMOR_COL1_X : ARMOR_COL2_X) + ARMOR_CARD_W - 112;
            int y = top + ARMOR_CARDS_TOP + pos.row() * (ARMOR_CARD_H + ARMOR_CARD_GAP) + 4;
            Button button = Button.builder(Component.literal(label), pressed -> sendUpgrade(route))
                    .bounds(x, y, 84, 16).build();
            button.active = route != null && hasTarget && !conflict;
            addRenderableWidget(button);
            addMaxUpgradeButton(x + 88, y, 26, 16, route, hasTarget && !conflict);
        }

        initArmorFamilyButton(left, top, selection, conflict, hasTarget);

        addRenderableWidget(Button.builder(Component.literal("←"), b -> {
            this.view = View.MODULES;
            this.category = null;
            this.rebuild();
        }).bounds(left + 18, top + ARMOR_BOTTOM_Y, 24, 16).build());
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> this.minecraft.setScreen(this.parent))
                .bounds(left + ARMOR_PANEL_W - 62, top + ARMOR_BOTTOM_Y, 44, 16).build());
    }

    /**
     * 保护家族按钮（单按钮）：未选择 → 进入三选一视图；选定后只保留该家族，直接升级并仅显示其材料。
     */
    private void initArmorFamilyButton(int left, int top, RelicSelection selection, boolean conflict, boolean hasTarget) {
        int y = top + ARMOR_CARDS_TOP + 2 * (ARMOR_CARD_H + ARMOR_CARD_GAP) + 4;
        if (!hasTarget) {
            return;
        }
        int currentType = RelicService.value(selection.stack(), "looting");
        if (currentType == 0) {
            addRenderableWidget(Button.builder(Component.literal("选择保护家族"), b -> {
                this.view = View.FAMILY_SELECT;
                this.rebuild();
            }).bounds(left + ARMOR_COL2_X + 8, y, ARMOR_CARD_W - 16, 16).build());
            return;
        }
        UpgradeDefinition route = protectionFamilyRoute(selection.stack(), currentType);
        int current = currentProtectionLevel(selection.stack(), currentType);
        String label = route == null ? "已满级" : "升级至 " + roman(current + 1);
        // v7.0.0：与属性卡片同规——升级按钮左移 20px，右侧留一键满级按钮位
        int x = left + ARMOR_COL2_X + ARMOR_CARD_W - 112;
        Button button = Button.builder(Component.literal(label), pressed -> sendUpgrade(route))
                .bounds(x, y, 84, 16).build();
        button.active = route != null && !conflict;
        addRenderableWidget(button);
        addMaxUpgradeButton(x + 88, y, 26, 16, route, !conflict);
    }

    private void renderArmorAttributes(GuiGraphics gui, int mouseX, int mouseY, float delta) {
        int left = armorPanelLeft();
        int top = armorPanelTop();
        this.panel(gui, left, top, ARMOR_PANEL_W, ARMOR_PANEL_H, -14268347, "遗物骨甲");
        RelicSelection selection = relicSelection(this.category);
        renderOvercapStatus(gui, left, top, mouseX, mouseY, delta);
        if (selection.count() == 0) {
            gui.drawCenteredString(this.font, "背包中未找到对应遗物", this.width / 2, top + 34, -43691);
        } else if (selection.count() > 1) {
            gui.drawCenteredString(this.font, "请只保留一件同类遗物", this.width / 2, top + 34, -43691);
        }
        for (Attribute attribute : attributesFor(this.category)) {
            renderArmorCard(gui, left, top, attribute, selection, mouseX, mouseY, delta);
        }
        renderArmorFamily(gui, left, top, selection, mouseX, mouseY, delta);
        renderStatusMarquee(gui, top + ARMOR_BOTTOM_Y + 3, ARMOR_PANEL_W - 24, mouseX, mouseY, delta);
    }

    private void renderArmorCard(GuiGraphics gui, int left, int top, Attribute attribute, RelicSelection selection,
            int mouseX, int mouseY, float delta) {
        CardPosition pos = cardPosition(attribute);
        int x = left + (pos.col() == 0 ? ARMOR_COL1_X : ARMOR_COL2_X);
        int y = top + ARMOR_CARDS_TOP + pos.row() * (ARMOR_CARD_H + ARMOR_CARD_GAP);
        gui.fill(x, y, x + ARMOR_CARD_W, y + ARMOR_CARD_H, -14277082);
        if (selection.stack() == null) {
            gui.drawString(this.font, attributeTitle(attribute), x + 8, y + 4, -171);
            return;
        }
        int current = currentLevel(attribute, selection.stack());
        UpgradeDefinition route = nextRoute(attribute, selection.stack());
        String progression = route == null ? levelText(attribute, current)
                : levelText(attribute, current) + "→" + levelText(attribute, current + 1);
        renderCardMarquee(cardProgression, attribute,
                attributeTitle(attribute) + " " + progression, x + 6, y + 3, ARMOR_CARD_W - 12,
                route == null ? -5592406 : -1, gui, mouseX, mouseY, delta);
        if (route == null) {
            String fullText = "已满级";
            if (attribute == Attribute.ARMOR && RelicService.value(selection.stack(), "armor") < 50) {
                int cap = RelicService.armorCap(RelicService.value(selection.stack(), "tier"));
                fullText = "需升级材质（当前上限 " + cap + "）";
            }
            gui.drawString(this.font, fullText, x + 8, y + 22, -5592406);
            return;
        }
        int currentXp = this.minecraft.player == null ? 0 : this.minecraft.player.experienceLevel;
        int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
        String xpText = "经验 " + currentXp + "/" + route.experienceLevels();
        gui.drawString(this.font, xpText, x + 8, y + 22, xpColor);
        int costsX = x + 8 + this.font.width(xpText) + 4;
        renderCardMarquee(cardCosts, attribute, costSummary(route),
                costsX, y + 21, x + ARMOR_CARD_W - 12 - costsX,
                allCostsSatisfied(route) ? -11141291 : -43691, gui, mouseX, mouseY, delta);
        renderCardMarquee(cardRequirement, attribute, "前置 " + requirementText(route),
                x + 6, y + 39, ARMOR_CARD_W - 12, -5592406, gui, mouseX, mouseY, delta);
    }

    private String costSummary(UpgradeDefinition route) {
        StringBuilder builder = new StringBuilder();
        for (UpgradeDefinition.Cost cost : route.costs()) {
            if (builder.length() > 0) {
                builder.append(" · ");
            }
            int owned = availableCostItems(cost.item());
            builder.append(cost.item().getDescription().getString()).append(" ").append(owned).append("/").append(cost.count());
        }
        return builder.toString();
    }

    private boolean allCostsSatisfied(UpgradeDefinition route) {
        for (UpgradeDefinition.Cost cost : route.costs()) {
            if (availableCostItems(cost.item()) < cost.count()) {
                return false;
            }
        }
        return true;
    }

    private void renderArmorFamily(GuiGraphics gui, int left, int top, RelicSelection selection,
            int mouseX, int mouseY, float delta) {
        int x = left + ARMOR_COL2_X;
        int y = top + ARMOR_CARDS_TOP + 2 * (ARMOR_CARD_H + ARMOR_CARD_GAP);
        gui.fill(x, y, x + ARMOR_CARD_W, y + ARMOR_CARD_H, -14277082);
        if (selection.stack() == null) {
            gui.drawString(this.font, "保护家族", x + 8, y + 4, -171);
            return;
        }
        int currentType = RelicService.value(selection.stack(), "looting");
        if (currentType == 0) {
            gui.drawString(this.font, "火焰/爆炸/弹射物 三选一，选定后不可更换", x + 8, y + 26, -5592406);
            gui.drawString(this.font, "第一级无需材料，仅消耗经验", x + 8, y + 42, -11141291);
            return;
        }
        String familyName = familyName(currentType);
        int current = currentProtectionLevel(selection.stack(), currentType);
        UpgradeDefinition route = protectionFamilyRoute(selection.stack(), currentType);
        String progression = route == null ? roman(current) : roman(current) + "→" + roman(current + 1);
        familyProgressionMarquee.setMessage(Component.literal(familyName + " " + progression));
        familyProgressionMarquee.setX(x + 6);
        familyProgressionMarquee.setY(y + 3);
        familyProgressionMarquee.setWidth(ARMOR_CARD_W - 12);
        familyProgressionMarquee.setColor(route == null ? -5592406 : -1);
        familyProgressionMarquee.render(gui, mouseX, mouseY, delta);
        if (route == null) {
            gui.drawString(this.font, "已满级", x + 8, y + 22, -5592406);
            return;
        }
        int currentXp = this.minecraft.player == null ? 0 : this.minecraft.player.experienceLevel;
        int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
        String xpText = "经验 " + currentXp + "/" + route.experienceLevels();
        gui.drawString(this.font, xpText, x + 8, y + 22, xpColor);
        int costsX = x + 8 + this.font.width(xpText) + 4;
        familyCostMarquee.setMessage(Component.literal(costSummary(route)));
        familyCostMarquee.setX(costsX);
        familyCostMarquee.setY(y + 21);
        familyCostMarquee.setWidth(x + ARMOR_CARD_W - 12 - costsX);
        familyCostMarquee.setColor(allCostsSatisfied(route) ? -11141291 : -43691);
        familyCostMarquee.render(gui, mouseX, mouseY, delta);
        familyRequirementMarquee.setMessage(Component.literal("前置 " + requirementText(route)));
        familyRequirementMarquee.setX(x + 6);
        familyRequirementMarquee.setY(y + 39);
        familyRequirementMarquee.setWidth(ARMOR_CARD_W - 12);
        familyRequirementMarquee.setColor(-5592406);
        familyRequirementMarquee.render(gui, mouseX, mouseY, delta);
    }

    private static String familyName(int ptype) {
        return switch (ptype) {
            case 1 -> "火焰保护";
            case 2 -> "爆炸保护";
            default -> "弹射物保护";
        };
    }

    private void renderOvercapStatus(GuiGraphics gui, int left, int top, int mouseX, int mouseY, float delta) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        int armor = clientArmorValue();
        int count = clientRelicArmorCount();
        boolean active = config.enabled && count >= config.minRelicArmorPieces;
        int overcap = active ? Math.max(0, armor - (int) config.threshold) : 0;
        double reduction = Math.min(overcap * config.drPercentPerPoint / 100.0, config.drCapPercent / 100.0);
        double health = Math.min(overcap * config.healthPerPoint, config.healthCap);

        String badge = active && overcap > 0 ? "超限转化 " + fmt(reduction * 100.0) + "%" : "未激活";
        gui.drawString(this.font, badge,
                left + ARMOR_PANEL_W - 12 - this.font.width(badge), top + 7,
                active && overcap > 0 ? -13261 : -5592406);

        String status = active && overcap > 0
                ? "护甲 " + armor + "/" + (int) config.threshold + " · 超限 " + overcap + " 点 → 全面减伤 "
                        + fmt(reduction * 100.0) + "% ｜ 最大生命 +" + fmt(health) + "%"
                : "未激活：需穿戴 ≥" + config.minRelicArmorPieces + " 件遗物骨甲 且 全身护甲 > "
                        + (int) config.threshold + " 点";
        overcapStatusText.setMessage(Component.literal(status));
        overcapStatusText.setX(left + 10);
        overcapStatusText.setY(top + 25);
        overcapStatusText.setWidth(ARMOR_PANEL_W - 20);
        overcapStatusText.setColor(active && overcap > 0 ? -11141291 : -5592406);
        overcapStatusText.render(gui, mouseX, mouseY, delta);

        if (mouseX >= left + 10 && mouseX <= left + ARMOR_PANEL_W - 10
                && mouseY >= top + 22 && mouseY <= top + 40) {
            gui.renderComponentTooltip(this.font, List.of(Component.literal(
                    "护甲超 40 点后每 1 点 = 0.5% 全面减伤，覆盖火焰/爆炸/摔落/弹射物/魔法等全部保护类型；"
                            + "每 1 点另 +1% 最大生命。需穿戴 ≥" + config.minRelicArmorPieces + " 件遗物骨甲。")),
                    mouseX, mouseY);
        }
    }

    private int clientArmorValue() {
        if (this.minecraft == null || this.minecraft.player == null) {
            return 0;
        }
        ArmorOvercapHandler.ensureArmorCapRaised();
        return (int) Math.floor(this.minecraft.player.getAttributeValue(Attributes.ARMOR));
    }

    private int clientRelicArmorCount() {
        if (this.minecraft == null || this.minecraft.player == null) {
            return 0;
        }
        int count = 0;
        for (ItemStack stack : this.minecraft.player.getInventory().armor) {
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                count++;
            }
        }
        return count;
    }

    private static String fmt(double value) {
        if (value == Math.floor(value) && !Double.isInfinite(value)) {
            return String.valueOf((long) value);
        }
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    // =====================================================================
    // 保护家族三选一视图（第一级无需材料）
    // =====================================================================
    private static final int FAMILY_PANEL_W = 430;
    private static final int FAMILY_PANEL_H = 200;

    private void initFamilySelectButtons() {
        int left = this.width / 2 - FAMILY_PANEL_W / 2;
        int top = this.height / 2 - FAMILY_PANEL_H / 2;
        String[] names = {"火焰保护", "爆炸保护", "弹射物保护"};
        int[] types = {1, 2, 3};
        RelicSelection selection = relicSelection(this.category);
        boolean conflict = selection.count() > 1;
        boolean hasTarget = selection.stack() != null;
        for (int i = 0; i < 3; i++) {
            final int ptype = types[i];
            UpgradeDefinition route = hasTarget ? protectionFamilyRoute(selection.stack(), ptype) : null;
            String label = route == null ? names[i] + " 不可用" : "选择 " + names[i];
            Button button = Button.builder(Component.literal(label), pressed -> sendFamilyChoice(route))
                    .bounds(left + 14, top + 46 + i * 30, 130, 24).build();
            button.active = route != null && hasTarget && !conflict;
            addRenderableWidget(button);
        }
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> {
            this.view = View.ATTRIBUTES;
            this.rebuild();
        }).bounds(this.width / 2 - 40, top + 158, 80, 20).build());
    }

    private void sendFamilyChoice(UpgradeDefinition route) {
        if (route == null) {
            return;
        }
        this.view = View.ATTRIBUTES;
        sendUpgrade(route);
    }

    private void renderFamilySelect(GuiGraphics gui) {
        int left = this.width / 2 - FAMILY_PANEL_W / 2;
        int top = this.height / 2 - FAMILY_PANEL_H / 2;
        this.panel(gui, left, top, FAMILY_PANEL_W, FAMILY_PANEL_H, -14268347, "保护家族（三选一）");
        String[] names = {"火焰保护", "爆炸保护", "弹射物保护"};
        for (int i = 0; i < 3; i++) {
            int y = top + 46 + i * 30;
            gui.drawString(this.font, names[i], left + 160, y + 6, -1);
            gui.drawString(this.font, "第一级无需材料 · 仅需经验 5 级", left + 160, y + 15, -11141291);
        }
        gui.drawCenteredString(this.font, "选定后不可更换（四个部位独立选择）",
                this.width / 2, top + 138, -5592406);
    }

    // =====================================================================
    // 渲染
    // =====================================================================
    @Override
    public void render(GuiGraphics gui, int mouseX, int mouseY, float delta) {
        this.renderBackground(gui);
        if (this.view == View.MODULES) {
            renderModules(gui, mouseX, mouseY, delta);
        } else if (this.view == View.SLOT_SELECT) {
            renderSlotSelect(gui);
        } else if (this.view == View.FAMILY_SELECT) {
            renderFamilySelect(gui);
        } else {
            renderAttributes(gui, mouseX, mouseY, delta);
        }
        super.render(gui, mouseX, mouseY, delta);
    }

    private void renderSlotSelect(GuiGraphics gui) {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 82;
        this.panel(gui, left, top, 300, 190, -14268347, "选择升级部位");
        String[] names = {"头盔", "胸甲", "护腿", "靴子"};
        for (int i = 0; i < 4; i++) {
            gui.drawCenteredString(this.font, names[i], left + 79, top + 54 + i * 30, -1);
        }
    }

    private void panel(GuiGraphics gui, int left, int top, int panelWidth, int panelHeight, int accent, String title) {
        gui.fill(left, top, left + panelWidth, top + panelHeight, -366993376);
        gui.fill(left + 2, top + 2, left + panelWidth - 2, top + 22, accent);
        gui.drawCenteredString(this.font, title, left + panelWidth / 2, top + 7, -1);
    }

    private void renderModules(GuiGraphics gui, int mouseX, int mouseY, float delta) {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 82;
        int panelH = isCreative() ? 258 : 208;
        this.panel(gui, left, top, 300, panelH, -11846871, "遗物升级");
        renderModuleCard(gui, left + 14, top + 46, "无尽铁镐", new ItemStack(ModItems.RELIC_IRON_PICKAXE.get()), -13216148);
        // 骨头 ⇄ 法杖一体两面：卡片随当前形态显示对应图标与名称
        boolean isWand = "magic_wand".equals(currentBoneOrWandKind());
        renderModuleCard(gui, left + 156, top + 46,
                isWand ? "魔法法杖" : "战利品骨头",
                new ItemStack(isWand ? ModItems.MAGIC_WAND.get() : ModItems.RELIC_BONE.get()),
                isWand ? -13216148 : -9808844);
        renderModuleCard(gui, left + 85, top + 116, "遗物骨甲", new ItemStack(ModItems.RELIC_BONE_CHESTPLATE.get()), -14268347);
        if (isCreative()) {
            gui.drawCenteredString(this.font, "创造模式：各遗物发放按钮（升级全部免费）",
                    this.width / 2, top + 190, -11141291);
            renderStatusMarquee(gui, top + 246, 260, mouseX, mouseY, delta);
        } else {
            renderStatusMarquee(gui, top + 196, 260, mouseX, mouseY, delta);
        }
    }

    private void renderModuleCard(GuiGraphics gui, int x, int y, String title, ItemStack icon, int accent) {
        gui.fill(x, y, x + 130, y + 56, -13948117);
        gui.fill(x, y, x + 130, y + 3, accent);
        // 2x 放大图标
        gui.pose().pushPose();
        gui.pose().translate(x + 6, y + 8, 0);
        gui.pose().scale(2f, 2f, 1f);
        gui.renderItem(icon, 0, 0);
        gui.pose().popPose();
        gui.drawString(this.font, title, x + 52, y + 22, -1);
    }

    private void renderAttributes(GuiGraphics gui, int mouseX, int mouseY, float delta) {
        if (this.category == UpgradeDefinition.RelicType.BONE_ARMOR) {
            renderArmorAttributes(gui, mouseX, mouseY, delta);
            return;
        }
        int left = this.width / 2 - 215;
        int top = this.height / 2 - 185;
        int accent = this.category == UpgradeDefinition.RelicType.BONE ? -9808844 : -13216148;
        this.panel(gui, left, top, 430, 350, accent, categoryTitle(this.category));
        RelicSelection selection = relicSelection(this.category);
        if (selection.count() == 0) {
            gui.drawCenteredString(this.font, "背包中未找到对应遗物", this.width / 2, top + 34, -43691);
        } else if (selection.count() > 1) {
            gui.drawCenteredString(this.font, "请只保留一件同类遗物", this.width / 2, top + 34, -43691);
        }
        List<Attribute> attributes = attributesFor(this.category);
        for (int i = 0; i < attributes.size(); i++) {
            renderAttributeCard(gui, left, top + 50 + i * 62, attributes.get(i), selection, mouseX, mouseY, delta);
        }
        renderStatusMarquee(gui, top + 335, 400, mouseX, mouseY, delta);
    }

    private void renderAttributeCard(GuiGraphics gui, int left, int y, Attribute attribute, RelicSelection selection,
            int mouseX, int mouseY, float delta) {
        gui.fill(left + 10, y, left + 420, y + 58, -14277082);
        gui.drawString(this.font, attributeTitle(attribute), left + 18, y + 7, -171);
        if (selection.stack() == null) {
            return;
        }
        int current = currentLevel(attribute, selection.stack());
        UpgradeDefinition route = nextRoute(attribute, selection.stack());
        String progression = route == null ? levelText(attribute, current)
                : levelText(attribute, current) + " → " + levelText(attribute, current + 1);
        renderCardMarquee(cardProgression, attribute, progression, left + 16, y + 24, 170,
                route == null ? -5592406 : -1, gui, mouseX, mouseY, delta);
        if (route == null) {
            return;
        }
        int currentXp = this.minecraft.player == null ? 0 : this.minecraft.player.experienceLevel;
        int xpColor = currentXp >= route.experienceLevels() ? -11141291 : -43691;
        gui.drawString(this.font, "经验 " + currentXp + "/" + route.experienceLevels(), left + 190, y + 7, xpColor);
        renderCardMarquee(cardCosts, attribute, costSummary(route),
                left + 190, y + 21, 220,
                allCostsSatisfied(route) ? -11141291 : -43691, gui, mouseX, mouseY, delta);
        renderCardMarquee(cardRequirement, attribute, "前置 " + requirementText(route),
                left + 190, y + 39, 220, -5592406, gui, mouseX, mouseY, delta);
    }

    // =====================================================================
    // 文本辅助
    // =====================================================================
    private List<Attribute> attributesFor(UpgradeDefinition.RelicType type) {
        return switch (type) {
            case PICKAXE -> List.of(Attribute.MATERIAL, Attribute.EFFICIENCY, Attribute.FORTUNE);
            case BONE -> List.of(Attribute.DAMAGE, Attribute.FIRE, Attribute.LOOTING, Attribute.LIFESTEAL);
            case BONE_ARMOR -> List.of(Attribute.MATERIAL, Attribute.ARMOR, Attribute.EFFICIENCY, Attribute.FORTUNE, Attribute.FIRE);
            case WAND -> List.of(Attribute.MATERIAL, Attribute.SPELL, Attribute.LIFESTEAL, Attribute.EXPLOSION);
        };
    }

    private String attributeTitle(Attribute attribute) {
        return switch (attribute) {
            case MATERIAL -> "材质";
            case ARMOR -> "护甲值";
            case EFFICIENCY -> this.category == UpgradeDefinition.RelicType.PICKAXE ? "效率" : "保护";
            case FORTUNE -> this.category == UpgradeDefinition.RelicType.PICKAXE ? "时运" : "韧性";
            case DAMAGE -> "主手伤害";
            case FIRE -> this.category == UpgradeDefinition.RelicType.BONE ? "火焰附加" : "荆棘";
            case LOOTING -> "抢夺";
            case LIFESTEAL -> "吸血";
            case SPELL -> "法术强度";
            case EXPLOSION -> "爆炸";
        };
    }

    private String levelText(Attribute attribute, int level) {
        return switch (attribute) {
            case MATERIAL -> materialName(level);
            case DAMAGE -> "+" + level;
            case ARMOR -> "+" + level;
            case LIFESTEAL -> (int) (RelicService.lifestealPercent(level) * 100) + "%";
            case SPELL -> "+" + level;
            case EXPLOSION -> roman(level);
            default -> roman(level);
        };
    }

    private String materialName(int tier) {
        // 法杖材质名（0 = 魔法法杖，1 = 下界灵魂之杖）
        if (this.category == UpgradeDefinition.RelicType.WAND) {
            return tier == 1 ? "下界灵魂之杖" : "魔法法杖";
        }
        return switch (tier) {
            case 1 -> "钻石覆层";
            case 2 -> "下界合金铸体";
            case 3 -> "下界合金·铁";
            case 4 -> "下界合金·金";
            case 5 -> "下界合金·绿宝石";
            case 6 -> "下界合金·钻石";
            default -> "铁质";
        };
    }

    private String requirementText(UpgradeDefinition route) {
        UpgradeDefinition.Requirement requirement = route.requirement();
        if (requirement.materialTier() >= 0) {
            return materialName(requirement.materialTier());
        }
        if (requirement.efficiency() >= 0) {
            String key = this.category == UpgradeDefinition.RelicType.PICKAXE ? "效率 " : "保护 ";
            return key + roman(requirement.efficiency());
        }
        if (requirement.fortune() >= 0) {
            // 法杖：fortune 槽表示吸血（wfortune）前置
            String key = this.category == UpgradeDefinition.RelicType.PICKAXE ? "时运 "
                    : (this.category == UpgradeDefinition.RelicType.BONE ? "吸血 "
                    : (this.category == UpgradeDefinition.RelicType.WAND ? "吸血 " : "韧性 "));
            return key + roman(requirement.fortune());
        }
        if (requirement.boneDamage() >= 0) {
            return "伤害 +" + (9 + requirement.boneDamage());
        }
        if (requirement.fireAspect() >= 0) {
            String key = this.category == UpgradeDefinition.RelicType.BONE ? "火焰 " : "荆棘 ";
            return key + roman(requirement.fireAspect());
        }
        if (requirement.looting() >= 0) {
            return "抢夺 " + roman(requirement.looting());
        }
        if (requirement.armor() >= 0) {
            // 法杖：armor 槽表示法术强度（spell）前置
            if (this.category == UpgradeDefinition.RelicType.WAND) {
                return "法术强度 +" + requirement.armor();
            }
            return "护甲值 +" + requirement.armor();
        }
        if (requirement.explosion() >= 0) {
            return "爆炸 " + roman(requirement.explosion());
        }
        return "无";
    }

    private String roman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    /** 状态消息（升级结果/错误提示）跑马灯渲染：显示完整文字，居中于面板。 */
    private void renderStatusMarquee(GuiGraphics gui, int y, int width, int mouseX, int mouseY, float delta) {
        statusText.setMessage(Component.literal(lastResult));
        statusText.setX(this.width / 2 - width / 2);
        statusText.setY(y - 1);
        statusText.setWidth(width);
        statusText.setColor(statusColor(lastResult));
        statusText.render(gui, mouseX, mouseY, delta);
    }

    /** 卡片内长文本跑马灯渲染（复用组件实例，位置/文字按帧更新）。 */
    private void renderCardMarquee(Map<Attribute, MarqueeTextWidget> map, Attribute attribute,
            String text, int x, int y, int width, int color,
            GuiGraphics gui, int mouseX, int mouseY, float delta) {
        MarqueeTextWidget widget = map.computeIfAbsent(attribute,
                a -> new MarqueeTextWidget(Component.literal(""), 0, 0, width, 10));
        widget.setMessage(Component.literal(text));
        widget.setX(x);
        widget.setY(y - 1);
        widget.setWidth(width);
        widget.setColor(color);
        widget.render(gui, mouseX, mouseY, delta);
    }

    private int statusColor(String status) {
        return status.startsWith("升级成功") ? -11141291
                : (status.contains("不足") || status.contains("不满足") || status.contains("多件") || status.contains("未找到") ? -43691 : -13227);
    }

    private String categoryTitle(UpgradeDefinition.RelicType type) {
        return switch (type) {
            case PICKAXE -> "无尽铁镐";
            case BONE -> "战利品骨头";
            case BONE_ARMOR -> "遗物骨甲";
            case WAND -> "魔法法杖";
        };
    }

    @Override
    public void onClose() {
        if (activeScreen == this) {
            activeScreen = null;
        }
        this.minecraft.setScreen(this.parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private enum View {
        MODULES,
        SLOT_SELECT,
        FAMILY_SELECT,
        ATTRIBUTES
    }

    private enum Attribute {
        MATERIAL,
        ARMOR,
        EFFICIENCY,
        FORTUNE,
        DAMAGE,
        FIRE,
        LOOTING,
        LIFESTEAL,
        SPELL,
        EXPLOSION
    }

    private record RelicSelection(ItemStack stack, int count) {
    }
}
