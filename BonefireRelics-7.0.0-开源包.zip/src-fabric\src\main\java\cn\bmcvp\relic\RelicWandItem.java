package cn.bmcvp.relic;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.spell_power.api.SpellSchools;
import java.util.UUID;

/**
 * 遗物法杖（v6.3.8+ Spell Power 适配）：主手持有时提供 3 系法术强度。
 *
 * <p>背景：Spell Engine 的法术书技能伤害 = 施法者对应学校法强 × 技能系数（无基础伤害），
 * 遗物法杖此前是纯 SwordItem 不提供任何法强，导致手持法杖时法术体系伤害为 0
 * （技能只有特效与击退——击退由 Spell Engine 独立施加，与伤害无关）。
 * 本类让遗物法杖像骨甲一样接入 Spell Power 属性体系：主手槽位附加
 * +N 火焰 / +N 寒冰 / +N 奥秘法术强度（固定 UUID，不叠加、不漂移）。
 */
public class RelicWandItem extends SwordItem {
    /** 每系法术强度加成（可调：数值越大，Spell Engine 技能伤害越明显）。 */
    public static final double SPELL_POWER = 15.0;

    private static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0011-4a3e-9f8e-1a2b3c4d5e01");
    private static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0012-4a3e-9f8e-1a2b3c4d5e02");
    private static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0013-4a3e-9f8e-1a2b3c4d5e03");

    public RelicWandItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    /** Spell Power 适配：主手/副手槽位附加 3 系法术强度（主手直持、副手配法术书均可生效）。
     *  与骨甲同法：先拷贝父类 modifier 到可变 Multimap（父类 ImmutableMultimap 不可 put）。 */
    @Override
    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(ItemStack stack, EquipmentSlot slot) {
        Multimap<EntityAttribute, EntityAttributeModifier> modifiers = LinkedHashMultimap.create();
        modifiers.putAll(super.getAttributeModifiers(stack, slot));
        if (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND) {
            modifiers.put(SpellSchools.FIRE.attribute,
                    new EntityAttributeModifier(FIRE_POWER_UUID, "bonefire_relics_wand_fire_power", SPELL_POWER,
                            EntityAttributeModifier.Operation.ADDITION));
            modifiers.put(SpellSchools.FROST.attribute,
                    new EntityAttributeModifier(FROST_POWER_UUID, "bonefire_relics_wand_frost_power", SPELL_POWER,
                            EntityAttributeModifier.Operation.ADDITION));
            modifiers.put(SpellSchools.ARCANE.attribute,
                    new EntityAttributeModifier(ARCANE_POWER_UUID, "bonefire_relics_wand_arcane_power", SPELL_POWER,
                            EntityAttributeModifier.Operation.ADDITION));
        }
        return modifiers;
    }
}
