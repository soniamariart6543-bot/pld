package cn.bmcvp.relic;

import com.mojang.brigadier.context.CommandContext;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * 遗物升级（Forge 1.20.1 移植版）。全部逻辑服务端权威，客户端只发送请求并接收结果。
 * 创造模式：升级不消耗材料与经验；升级界面提供各遗物发放按钮（服务端校验 instabuild）。
 */
@Mod(BmcvpRelicUpgradesMod.MODID)
public final class BmcvpRelicUpgradesMod {
    public static final String MODID = "bonefire_relics";
    public static final int PACKET_STRING_MAX_LENGTH = 64;

    private static final String PICKAXE_GRANTED = "bonefire_relics_pickaxe_granted";
    private static final String BONE_GRANTED = "bonefire_relics_bone_granted";
    private static final String BONE_ARMOR_GRANTED = "bonefire_relics_bone_armor_granted";
    private static final String GUIDE_GRANTED = "bonefire_relics_guide_granted";
    private static final String APPLE_GRANTED = "bonefire_relics_apple_granted";
    private static final String VISITED_NETHER = "bonefire_relics_visited_nether";

    // FMLJavaModLoadingContext.get() 虽被标记移除，但无参构造器是 47.4.10 验证可用的稳定方式（构造器注入在该版本不可用）
    @SuppressWarnings("removal")
    public BmcvpRelicUpgradesMod() {
        ModItems.REGISTER.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModEffects.REGISTER.register(FMLJavaModLoadingContext.get().getModEventBus());
        RelicEntities.REGISTER.register(FMLJavaModLoadingContext.get().getModEventBus());
        RelicNetworking.register();
        ArmorOvercapConfig.load();
        ArmorOvercapHandler.initialize();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(ArmorOvercapHandler.class);
        MinecraftForge.EVENT_BUS.register(BoneSkillHandler.class);
        MinecraftForge.EVENT_BUS.register(LifestealHandler.class);
        MinecraftForge.EVENT_BUS.register(ArmorSkillHandler.class);
        MinecraftForge.EVENT_BUS.register(PickaxeSkillHandler.class);
        MinecraftForge.EVENT_BUS.register(RelicProtectionHandler.class);
        MinecraftForge.EVENT_BUS.register(WandSkillHandler.class);
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            player.getServer().execute(() -> grantStarterRelics(player));
        }
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("relic")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("grant")
                        .executes(context -> grant(context, "all"))
                        .then(Commands.literal("all").executes(context -> grant(context, "all")))
                        .then(Commands.literal("pickaxe").executes(context -> grant(context, "pickaxe")))
                        .then(Commands.literal("bone").executes(context -> grant(context, "bone")))
                        .then(Commands.literal("bone_armor").executes(context -> grant(context, "bone_armor")))
                        .then(Commands.literal("apple").executes(context -> grant(context, "apple")))));
    }

    /** 开局遗物：镐、骨头、教程书、骨甲、无限苹果分别独立检测、独立发放。 */
    private static void grantStarterRelics(ServerPlayer player) {
        if (!player.getTags().contains(PICKAXE_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.PICKAXE)) {
                deliverRelics(player, List.of(RelicService.initialPickaxe()));
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 已发放：无尽铁镐"), false);
            }
            player.addTag(PICKAXE_GRANTED);
        }
        if (!player.getTags().contains(BONE_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE)) {
                deliverRelics(player, List.of(RelicService.initialBone()));
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 已发放：战利品骨头"), false);
            }
            player.addTag(BONE_GRANTED);
        }
        if (!player.getTags().contains(GUIDE_GRANTED)) {
            deliverRelics(player, List.of(RelicService.initialGuideBook()));
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 已发放：骨与火教程书"), false);
            player.addTag(GUIDE_GRANTED);
        }
        // 骨甲：出生即发放（不再等待首次进入地狱），并打「已访问下界」标记解锁穿戴
        if (!player.getTags().contains(BONE_ARMOR_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                player.addTag(VISITED_NETHER);
                deliverRelics(player, RelicService.initialBoneArmor());
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 已发放：遗物骨甲一套"), false);
            }
            player.addTag(BONE_ARMOR_GRANTED);
        }
        // 无限苹果：出生即发放（不消耗，每次 +2 饥饿值 +2 饱食度）
        if (!player.getTags().contains(APPLE_GRANTED)) {
            deliverRelics(player, List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE.get())));
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 已发放：无限苹果"), false);
            player.addTag(APPLE_GRANTED);
        }
    }

    /** 创造模式发放（服务器权威，仅 instabuild 玩家可调用）。骨甲发放同时解锁地狱标记以便穿戴。 */
    public static void grantCreative(ServerPlayer player, String section) {
        if (player == null || !player.getAbilities().instabuild) {
            return;
        }
        List<ItemStack> relics = switch (section) {
            case "pickaxe" -> List.of(RelicService.initialPickaxe());
            case "bone" -> List.of(RelicService.initialBone());
            case "guide" -> List.of(RelicService.initialGuideBook());
            case "wand" -> List.of(RelicService.initialWand());
            case "apple" -> List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE.get()));
            case "bone_armor" -> {
                player.addTag(VISITED_NETHER);
                yield RelicService.initialBoneArmor();
            }
            default -> RelicService.initialAllRelics();
        };
        deliverRelics(player, relics);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("[遗物成长] 创造模式已发放对应遗物"), false);
    }

    private static int grant(CommandContext<CommandSourceStack> context, String section) {
        ServerPlayer player;
        try {
            player = context.getSource().getPlayerOrException();
        } catch (Exception error) {
            context.getSource().sendFailure(net.minecraft.network.chat.Component.literal("该命令只能由游戏内玩家执行。"));
            return 0;
        }
        List<ItemStack> relics = switch (section) {
            case "pickaxe" -> List.of(RelicService.initialPickaxe());
            case "bone" -> List.of(RelicService.initialBone());
            case "bone_armor" -> RelicService.initialBoneArmor();
            case "apple" -> List.of(new ItemStack(ModItems.RELIC_INFINITE_APPLE.get()));
            default -> RelicService.initialAllRelics();
        };
        int dropped = deliverRelics(player, relics);
        String suffix = dropped == 0 ? "" : "（其中 " + dropped + " 件已掉落）";
        context.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal(
                "已发放 " + relics.size() + " 件" + sectionName(section) + "遗物。" + suffix), false);
        return relics.size();
    }

    private static int deliverRelics(ServerPlayer player, List<ItemStack> relics) {
        int dropped = 0;
        for (ItemStack relic : relics) {
            player.getInventory().add(relic);
            if (!relic.isEmpty()) {
                player.drop(relic, false);
                dropped++;
            }
        }
        player.getInventory().setChanged();
        return dropped;
    }

    private static String sectionName(String section) {
        return switch (section) {
            case "pickaxe" -> "无尽铁镐";
            case "bone" -> "战利品骨头";
            case "bone_armor" -> "遗物骨甲";
            case "apple" -> "无限苹果";
            default -> "开局";
        };
    }
}
