# Bonefire Relics（遗物成长）

> 服务端权威的遗物升级系统 · Minecraft 1.20.1（Fabric / Forge 双版本）

一套「捡起来就能玩」的成长系遗物模组：从一把铁镐、一根骨头开始，用材料与经验一步步升级出传奇装备——无尽铁镐、战利品骨头、遗物骨甲、魔法法杖，附赠技能、吸血、暴击、AOE、护甲超限转化等一整套玩法。

## ✨ 特性

| 遗物 | 特色 |
| --- | --- |
| **无尽铁镐** | 7 级材质进化（铁 → 下界合金·钻石）、效率 V、时运 X、挖掘补给 |
| **战利品骨头** | 主手伤害 +50、火焰附加 II（秒杀概率）、抢夺 X、吸血 X、骨火 / 骨裂 |
| **遗物骨甲** | 3 阶铸体、护甲值 +50、保护 / 韧性 / 荆棘、保护家族（火焰 / 爆炸 / 弹射物三选一）、护甲超限转化（全面减伤 + 最大生命） |
| **魔法法杖** | 下界灵魂之杖形态（灵魂蓝焰 / 凋零 / 暴击 / 灵魂爆裂）、左键直线火球、法术强度 30、爆炸 XII、吸血、连击 / 火罚 |
| **Spell Engine 衔接** | 法杖主 / 副手持有时提供 3 系法术强度，法术书技能（wizards / paladins / archers 等）正常结算伤害 |
| **创造模式工具** | 一键发放遗物、一键满级按钮（服务端校验，免费） |
| **防丢失** | 遗物不可破坏、防丢弃 / 防销毁保护 |
| **教程书** | 《骨与火》游戏内指引；无限苹果（食用不消耗） |

## 🚀 构建

环境要求：JDK 17+、Gradle 8.x。

```bash
# Fabric 版
cd src-fabric
gradle build --no-daemon
# 产物：build/libs/bonefire_relics-<version>.jar

# Forge 版
cd src-forge
gradle build --no-daemon
# 产物：build/libs/bonefire_relics_forge-<version>.jar
```

构建产物放入 `.minecraft/mods` 即可（Fabric 版需 Fabric Loader ≥ 0.15）。

## 📦 目录结构

```
BonefireRelics-7.0.0-release/
├── CHANGELOG.md          # 更新日志
├── README.md             # 本文件
├── LICENSE               # MIT 开源协议
├── dist/                 # 预构建产物（jar）
├── src-fabric/           # Fabric 版源码
└── src-forge/            # Forge 版源码
```

## 📜 许可

MIT License —— 自由使用、修改、分发；保留版权声明即可。详见 `LICENSE`。

## 🙏 致谢

- 适配测试环境：Prominence II Hasturian Era CN 3.9.2（Fabric 1.20.1，437 模组）
- 联动模组：Spell Engine / Spell Power / Tierify / dummmmmmy 等
