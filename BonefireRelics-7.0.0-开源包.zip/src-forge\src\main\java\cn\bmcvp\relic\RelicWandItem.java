package cn.bmcvp.relic;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.UUID;

/**
 * 遗物法杖（v6.3.8+，Forge Spell Power 可选适配）：主手/副手持有时提供 3 系法术强度。
 *
 * <p>背景：Spell Engine 的法术书技能伤害 = 施法者对应学校法强 × 技能系数（无基础伤害），
 * 遗物法杖此前是纯 SwordItem 不提供任何法强。本类让遗物法杖像骨甲一样接入 Spell Power
 * 属性体系（可选依赖守卫：未安装 spell_power 时短路，不触发任何 Spell Power 类加载）。
 */
public class RelicWandItem extends SwordItem {
    /** 每系法术强度加成（可调：数值越大，Spell Engine 技能伤害越明显）。 */
    public static final double SPELL_POWER = 15.0;

    private static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0011-4a3e-9f8e-1a2b3c4d5e01");
    private static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0012-4a3e-9f8e-1a2b3c4d5e02");
    private static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0013-4a3e-9f8e-1a2b3c4d5e03");

    public RelicWandItem(Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
    }

    /** Spell Power 可选适配：主手/副手槽位附加 3 系法术强度（与骨甲同法，先拷贝到可变 Multimap）。 */
    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        Multimap<Attribute, AttributeModifier> modifiers = LinkedHashMultimap.create();
        modifiers.putAll(super.getAttributeModifiers(slot, stack));
        if ((slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND)
                && ModList.get().isLoaded("spell_power")) {
            addSpellPower(modifiers, "fire", FIRE_POWER_UUID, "bonefire_relics_wand_fire_power");
            addSpellPower(modifiers, "frost", FROST_POWER_UUID, "bonefire_relics_wand_frost_power");
            addSpellPower(modifiers, "arcane", ARCANE_POWER_UUID, "bonefire_relics_wand_arcane_power");
        }
        return modifiers;
    }

    private static void addSpellPower(Multimap<Attribute, AttributeModifier> map, String school, UUID uuid, String name) {
        Attribute attribute = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation("spell_power", school));
        if (attribute != null) {
            map.put(attribute, new AttributeModifier(uuid, name, SPELL_POWER, AttributeModifier.Operation.ADDITION));
        }
    }
}
