package cn.bmcvp.relic;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.spell_power.api.SpellSchools;
import java.util.UUID;

/**
 * 遗物骨甲：地狱装备，只有进入过下界的玩家才能装备。
 * v6.3.8+（Prominence Spell Power 适配）：每件骨甲在对应装备槽位上附加
 * +3 火焰 / +3 寒冰 / +3 奥秘法术强度（固定 UUID，升级/刷新不叠加、不漂移）。
 */
public class RelicBoneArmorItem extends ArmorItem {
    public static final String NETHER_UNLOCK_TAG = "bonefire_relics_visited_nether";

    private static final UUID FIRE_POWER_UUID = UUID.fromString("c1b5a5f0-0001-4a3e-9f8e-1a2b3c4d5e01");
    private static final UUID FROST_POWER_UUID = UUID.fromString("c1b5a5f0-0002-4a3e-9f8e-1a2b3c4d5e02");
    private static final UUID ARCANE_POWER_UUID = UUID.fromString("c1b5a5f0-0003-4a3e-9f8e-1a2b3c4d5e03");

    public RelicBoneArmorItem(ArmorMaterial material, Type type, Settings settings) {
        super(material, type, settings);
    }

    /** Spell Power 适配：对应装备槽位附加 3 系法术强度各 +3。
     *  注意：父类返回的 ImmutableMultimap 不可直接 put，须先拷贝到可变 Multimap。 */
    @Override
    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(ItemStack stack, EquipmentSlot slot) {
        Multimap<EntityAttribute, EntityAttributeModifier> modifiers = LinkedHashMultimap.create();
        modifiers.putAll(super.getAttributeModifiers(stack, slot));
        if (slot == this.getSlotType()) {
            modifiers.put(SpellSchools.FIRE.attribute,
                    new EntityAttributeModifier(FIRE_POWER_UUID, "bonefire_relics_bone_fire_power", 3.0,
                            EntityAttributeModifier.Operation.ADDITION));
            modifiers.put(SpellSchools.FROST.attribute,
                    new EntityAttributeModifier(FROST_POWER_UUID, "bonefire_relics_bone_frost_power", 3.0,
                            EntityAttributeModifier.Operation.ADDITION));
            modifiers.put(SpellSchools.ARCANE.attribute,
                    new EntityAttributeModifier(ARCANE_POWER_UUID, "bonefire_relics_bone_arcane_power", 3.0,
                            EntityAttributeModifier.Operation.ADDITION));
        }
        return modifiers;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        if (!user.getCommandTags().contains(NETHER_UNLOCK_TAG)) {
            user.sendMessage(Text.literal("§c需要先进入地狱才能使用骨甲"), true);
            return TypedActionResult.fail(user.getStackInHand(hand));
        }
        return super.use(world, user, hand);
    }
}
