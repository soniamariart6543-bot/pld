package cn.bmcvp.relic.client;

import cn.bmcvp.relic.RelicFireballEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** 追踪火球渲染：始终面向相机的火球贴图精灵。 */
public class RelicFireballRenderer extends EntityRenderer<RelicFireballEntity> {
    private static final Identifier TEXTURE = new Identifier("bonefire_relics", "textures/entity/relic_fireball.png");
    private static final float SIZE = 0.6f;

    public RelicFireballRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(RelicFireballEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RelicFireballEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        matrices.multiply(this.dispatcher.getRotation());
        matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(180.0F));
        matrices.scale(SIZE, SIZE, SIZE);
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(TEXTURE));
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        Matrix3f normal = matrices.peek().getNormalMatrix();
        // 面向相机的平面贴图（XY 平面）
        vc.vertex(matrix4f, -0.5f, -0.5f, 0.0f).color(255, 255, 255, 255).texture(0.0f, 1.0f).overlay(OverlayTexture.DEFAULT_UV)
                .light(light).normal(normal, 0.0f, 0.0f, 1.0f);
        vc.vertex(matrix4f, 0.5f, -0.5f, 0.0f).color(255, 255, 255, 255).texture(1.0f, 1.0f).overlay(OverlayTexture.DEFAULT_UV)
                .light(light).normal(normal, 0.0f, 0.0f, 1.0f);
        vc.vertex(matrix4f, 0.5f, 0.5f, 0.0f).color(255, 255, 255, 255).texture(1.0f, 0.0f).overlay(OverlayTexture.DEFAULT_UV)
                .light(light).normal(normal, 0.0f, 0.0f, 1.0f);
        vc.vertex(matrix4f, -0.5f, 0.5f, 0.0f).color(255, 255, 255, 255).texture(0.0f, 0.0f).overlay(OverlayTexture.DEFAULT_UV)
                .light(light).normal(normal, 0.0f, 0.0f, 1.0f);
        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
