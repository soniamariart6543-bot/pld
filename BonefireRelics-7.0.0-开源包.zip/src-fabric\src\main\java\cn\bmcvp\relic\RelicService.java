package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * 遗物升级核心逻辑。全部在服务器执行，客户端只发送升级 id 并接收结果文本。
 */
public final class RelicService {
    public static final String NBT = "bonefire_relics";
    public static final int MAX_EXPERIENCE_COST = 50;

    private static final UUID BONE_DAMAGE_UUID = UUID.fromString("11111201-0000-0000-0000-000000000001");
    // 每个部位独立 UUID，避免相同 UUID 在 AttributeContainer 中被去重（只保留最后穿的一件）
    private static final UUID[] ARMOR_TOUGHNESS_UUIDS = new UUID[]{
            UUID.fromString("11111202-0000-0000-0000-000000000001"), // helmet
            UUID.fromString("11111203-0000-0000-0000-000000000001"), // chestplate
            UUID.fromString("11111204-0000-0000-0000-000000000001"), // leggings
            UUID.fromString("11111205-0000-0000-0000-000000000001")  // boots
    };
    private static final UUID[] ARMOR_VALUE_UUIDS = new UUID[]{
            UUID.fromString("11111206-0000-0000-0000-000000000001"), // helmet
            UUID.fromString("11111207-0000-0000-0000-000000000001"), // chestplate
            UUID.fromString("11111208-0000-0000-0000-000000000001"), // leggings
            UUID.fromString("11111209-0000-0000-0000-000000000001")  // boots
    };

    // Tierify 神话品质模板（Prominence 品质系统）：装备类遗物固定神话品质。
    // 仅装备类适用（Tierify 按 tag 匹配：c:pickaxes / c:swords / c:helmets 等）；
    // 骨头、教程书、野生果奶非装备类，绝不写入 Tiered NBT（会被 Tierify 随机品质覆盖）。
    private static final String MYTHIC_TOOL = "tiered:mythic_tool_1";
    private static final String MYTHIC_MELEE = "tiered:mythic_melee_1";
    private static final String MYTHIC_ARMOR = "tiered:mythic_armor_1";

    private RelicService() {
    }

    // =====================================================================
    // 查找 / 识别
    // =====================================================================
    private static Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
        String kindFilter = kindForSlot(type, slot);
        for (int i = 0; i < player.getInventory().main.size(); i++) {
            ItemStack stack = player.getInventory().main.get(i);
            if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
                return new Located(stack, i);
            }
        }
        ItemStack offHand = player.getOffHandStack();
        if (isRelic(offHand, type) && matchesKindFilter(offHand, kindFilter)) {
            return new Located(offHand, 40);
        }
        return null;
    }

    private static Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        return find(player, type, -1);
    }

    public static boolean anyRelic(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        return find(player, type) != null;
    }

    private static boolean matchesKindFilter(ItemStack stack, String kindFilter) {
        if (kindFilter == null) {
            return true;
        }
        return stack.hasNbt() && kindFilter.equals(stack.getNbt().getCompound(NBT).getString("item"));
    }

    private static String kindForSlot(UpgradeDefinition.RelicType type, int slot) {
        if (type != UpgradeDefinition.RelicType.BONE_ARMOR || slot < 0) {
            return null;
        }
        String[] slots = {"helmet", "chestplate", "leggings", "boots"};
        return "bone_" + slots[slot];
    }

    private static int relicCount(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (isRelic(stack, type)) {
                count++;
            }
        }
        if (isRelic(player.getOffHandStack(), type)) {
            count++;
        }
        return count;
    }

    private static int countBySlot(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
        String kindFilter = kindForSlot(type, slot);
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
                count++;
            }
        }
        if (isRelic(player.getOffHandStack(), type) && matchesKindFilter(player.getOffHandStack(), kindFilter)) {
            count++;
        }
        return count;
    }

    /** 是否为任意遗物（含教程书骨与火、野生果奶）：用于防丢弃 / 防销毁。 */
    public static boolean isAnyRelic(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (stack.isOf(ModItems.RELIC_GUIDE_BOOK)) {
            return true;
        }
        if (stack.isOf(ModItems.RELIC_INFINITE_APPLE)) {
            return true;
        }
        if (!stack.hasNbt() || !stack.getNbt().contains(NBT, 10)) {
            return false;
        }
        return !stack.getNbt().getCompound(NBT).getString("item").isEmpty();
    }

    public static boolean isRelic(ItemStack stack, UpgradeDefinition.RelicType type) {
        if (stack.isEmpty() || !stack.hasNbt() || !stack.getNbt().contains(NBT, 10)) {
            return false;
        }
        NbtCompound data = stack.getNbt().getCompound(NBT);
        if (data.contains("schema")) {
            return data.contains("schema", 3) && isCurrentRelic(stack, type, data);
        }
        return isLegacyRelic(stack, type, data);
    }

    private static boolean isCurrentRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
        if (data.getInt("schema") != 1 || !matchesKind(data.getString("item"), type) || !hasValidRelicId(data)) {
            return false;
        }
        int tier = data.getInt("tier");
        return isValidTier(type, tier) && hasValidState(type, data)
                && stack.isOf(itemFor(data.getString("item"), tier));
    }

    /** 判断 NBT 中的物品 kind 是否属于给定遗物类型。 */
    private static boolean matchesKind(String kind, UpgradeDefinition.RelicType type) {
        return switch (type) {
            case PICKAXE -> kind.equals("pickaxe");
            case BONE -> kind.equals("bone");
            case BONE_ARMOR -> kind.startsWith("bone_");
            case WAND -> kind.equals("magic_wand");
        };
    }

    private static boolean hasValidState(UpgradeDefinition.RelicType type, NbtCompound data) {
        return switch (type) {
            case PICKAXE -> between(data.getInt("efficiency"), 1, 5) && between(data.getInt("fortune"), 1, 10);
            case BONE -> between(data.getInt("damage"), 0, 41) && between(data.getInt("fire"), 1, 2)
                    && between(data.getInt("looting"), 1, 10)
                    && between(data.getInt("fortune"), 0, 10);
            case BONE_ARMOR -> between(data.getInt("efficiency"), 1, 5)
                    && between(data.getInt("fortune"), 1, 10)
                    && between(data.getInt("fire"), 1, 3)
                    && between(data.getInt("looting"), 0, 3)
                    && between(data.getInt("damage"), 0, 5)
                    && between(data.getInt("armor"), 0, 50);
            case WAND -> between(data.getInt("spell"), 0, 30) && between(data.getInt("wfortune"), 0, 10)
                    && between(data.getInt("explosion"), 0, 12); // 爆炸最高 12（灵魂态专属 XI/XII）
        };
    }

    private static boolean between(int value, int min, int max) {
        return value >= min && value <= max;
    }

    static boolean hasValidRelicId(NbtCompound data) {
        if (!data.contains("relic_id", 8)) {
            return false;
        }
        try {
            UUID.fromString(data.getString("relic_id"));
            return true;
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private static boolean isLegacyRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
        if (data.contains("relic_id") || !matchesKind(data.getString("item"), type)) {
            return false;
        }
        return switch (type) {
            case PICKAXE -> isLegacyPickaxe(stack, data) && between(data.getInt("efficiency"), 1, 5)
                    && between(data.getInt("fortune"), 0, 10);
            case BONE -> stack.isOf(Items.BONE) && data.getInt("tier") == 0
                    && between(data.getInt("damage"), 0, 41) && between(data.getInt("fire"), 1, 2)
                    && between(data.getInt("looting"), 1, 10);
            case BONE_ARMOR -> false;
            case WAND -> false;
        };
    }

    private static boolean isLegacyPickaxe(ItemStack stack, NbtCompound data) {
        return switch (data.getInt("tier")) {
            case 0 -> stack.isOf(Items.IRON_PICKAXE);
            case 1 -> stack.isOf(Items.DIAMOND_PICKAXE);
            case 2 -> stack.isOf(Items.NETHERITE_PICKAXE);
            default -> false;
        };
    }

    private static boolean isValidTier(UpgradeDefinition.RelicType type, int tier) {
        return switch (type) {
            case PICKAXE -> between(tier, 0, UpgradeDefinition.PICKAXE_TIER_MAX);
            case BONE -> tier == 0;
            case BONE_ARMOR -> between(tier, 0, 2);
            case WAND -> between(tier, 0, 1); // tier 1 = 下界灵魂之杖
        };
    }

    // =====================================================================
    // 数值读取
    // =====================================================================
    public static int value(ItemStack stack, String key) {
        // NBT 防御：空栈 / 无 NBT 时返回 0，避免调用方漏检导致 NPE
        if (stack == null || stack.isEmpty() || !stack.hasNbt()) {
            return 0;
        }
        return stack.getNbt().getCompound(NBT).getInt(key);
    }

    /** 吸血百分比曲线（0-10 级）。1级5%、2级15%、10级85%，曲线递增。 */
    private static final int[] LIFESTEAL_PERCENT = {0, 5, 15, 25, 35, 45, 55, 63, 70, 78, 85};

    public static float lifestealPercent(int level) {
        if (level < 0) {
            level = 0;
        }
        if (level > 10) {
            level = 10;
        }
        return LIFESTEAL_PERCENT[level] / 100.0f;
    }

    /**
     * 前置校验：仅依据当前物品自身的当前属性。
     * 字段映射说明：NBT 槽位与需求槽位语义在不同遗物间复用。
     *  - 法杖（magic_wand）的「法术强度」存 spell 槽，但需求复用了 requirement.armor() 槽表示 spell 前置等级；
     *  - 法杖的「吸血」存 wfortune 槽，但需求复用了 requirement.fortune() 槽表示 wfortune 前置等级。
     * 因此对法杖做如下映射，使升级只依赖当前物品当前属性：
     *  - armor() >= 0  -> 检查 spell
     *  - fortune() >= 0 -> 检查 wfortune
     */
    public static boolean meets(ItemStack stack, UpgradeDefinition.Requirement requirement) {
        NbtCompound data = stack.getNbt().getCompound(NBT);
        boolean wand = data.getString("item").equals("magic_wand");
        return !(requirement.materialTier() >= 0 && value(stack, "tier") != requirement.materialTier()
                || requirement.efficiency() >= 0 && value(stack, "efficiency") != requirement.efficiency()
                || requirement.fortune() >= 0 && value(stack, wand ? "wfortune" : "fortune") != requirement.fortune()
                || requirement.fireAspect() >= 0 && value(stack, "fire") != requirement.fireAspect()
                || requirement.looting() >= 0 && value(stack, "looting") != requirement.looting()
                || requirement.boneDamage() >= 0 && value(stack, "damage") != requirement.boneDamage()
                || requirement.armor() >= 0 && value(stack, wand ? "spell" : "armor") != requirement.armor()
                || requirement.explosion() >= 0 && value(stack, "explosion") != requirement.explosion());
    }

    // =====================================================================
    // 成本统计与扣除
    // =====================================================================
    public static int count(ServerPlayerEntity player, Item item) {
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (stack.isOf(item)) {
                count += stack.getCount();
            }
        }
        if (player.getOffHandStack().isOf(item)) {
            count += player.getOffHandStack().getCount();
        }
        return count;
    }

    private static Map<Item, Integer> aggregateCosts(UpgradeDefinition definition) {
        Map<Item, Integer> totals = new HashMap<>();
        for (UpgradeDefinition.Cost cost : definition.costs()) {
            totals.merge(cost.item(), cost.count(), Integer::sum);
        }
        return totals;
    }

    public static boolean hasCosts(ServerPlayerEntity player, UpgradeDefinition definition) {
        for (Map.Entry<Item, Integer> cost : aggregateCosts(definition).entrySet()) {
            if (count(player, cost.getKey()) < cost.getValue()) {
                return false;
            }
        }
        return true;
    }

    private static void remove(ServerPlayerEntity player, Item item, int required) {
        for (ItemStack stack : player.getInventory().main) {
            if (!stack.isOf(item) || required <= 0) {
                continue;
            }
            int taken = Math.min(required, stack.getCount());
            stack.decrement(taken);
            required -= taken;
        }
        ItemStack offHand = player.getOffHandStack();
        if (required > 0 && offHand.isOf(item)) {
            offHand.decrement(Math.min(required, offHand.getCount()));
        }
    }

    public static int availability(ServerPlayerEntity player, UpgradeDefinition definition) {
        if (!anyRelic(player, definition.relic())) {
            return 0;
        }
        if (relicCount(player, definition.relic()) != 1) {
            return 5;
        }
        Located target = find(player, definition.relic());
        if (target == null || !meets(target.stack(), definition.requirement())) {
            return 1;
        }
        if (!hasCosts(player, definition)) {
            return 2;
        }
        if (definition.experienceLevels() < 0 || definition.experienceLevels() > MAX_EXPERIENCE_COST
                || player.experienceLevel < definition.experienceLevels()) {
            return 3;
        }
        return 4;
    }

    // =====================================================================
    // 升级主流程
    // =====================================================================
    public static String tryUpgrade(ServerPlayerEntity player, String id, int slot) {
        UpgradeDefinition definition = UpgradeDefinition.byId(id);
        if (definition == null) {
            return "未知升级请求";
        }
        if (definition.experienceLevels() < 0 || definition.experienceLevels() > MAX_EXPERIENCE_COST) {
            return "升级配置的经验成本非法；未扣除任何内容";
        }
        boolean creative = player.getAbilities().creativeMode;
        Located target = find(player, definition.relic(), slot);
        if (target == null) {
            return slot >= 0 ? "背包或副手中未找到对应部位的遗物" : "背包或副手中未找到对应遗物";
        }
        // 骨甲铸体（材质）：护甲值升级目标超过当前铸体上限时拒绝
        if (definition.relic() == UpgradeDefinition.RelicType.BONE_ARMOR && definition.effect().armor() > 0) {
            int cap = armorCap(value(target.stack(), "tier"));
            if (definition.effect().armor() > cap) {
                return "护甲上限不足：当前铸体（材质）上限 " + cap + "，需升级材质解锁（钻石铸体 30 / 合金铸体 50）";
            }
        }
        int sameCount = slot >= 0 ? countBySlot(player, definition.relic(), slot) : relicCount(player, definition.relic());
        if (sameCount != 1) {
            return "检测到多件同类遗物；请暂时只保留要升级的一件";
        }
        if (!meets(target.stack(), definition.requirement())) {
            return "遗物当前等级不满足此前置条件";
        }
        if (!creative) {
            if (!hasCosts(player, definition)) {
                return "材料不足；未扣除任何材料或经验";
            }
            if (player.experienceLevel < definition.experienceLevels()) {
                return "经验等级不足；未扣除任何材料或经验";
            }
        }
        if (!creative) {
            for (UpgradeDefinition.Cost cost : definition.costs()) {
                remove(player, cost.item(), cost.count());
            }
            if (definition.experienceLevels() > 0) {
                player.addExperienceLevels(-definition.experienceLevels());
            }
        }
        ItemStack output = upgradedCopy(target.stack(), definition.effect());
        if (target.inventorySlot() == 40) {
            player.getInventory().offHand.set(0, output);
        } else {
            player.getInventory().main.set(target.inventorySlot(), output);
        }
        player.getInventory().markDirty();
        player.playerScreenHandler.sendContentUpdates();
        ArmorOvercapHandler.onUpgradeApplied(player);
        return "升级成功：" + definition.title() + "（消耗 " + definition.experienceLevels() + " 级经验）";
    }

    // =====================================================================
    // 创造模式一键满级（v7.0.0）
    // 客户端发送当前下一级 route.id，服务端据此解析「属性」并直接拉满该属性，
    // 复用 upgradedCopy 重建物品（保留品质 / 附魔 / lore）。仅创造模式可用。
    // =====================================================================
    public static String tryMaxUpgrade(ServerPlayerEntity player, String id, int slot) {
        if (!player.getAbilities().creativeMode) {
            return "一键满级仅创造模式可用";
        }
        UpgradeDefinition definition = UpgradeDefinition.byId(id);
        if (definition == null) {
            return "未知升级请求";
        }
        Located target = find(player, definition.relic(), slot);
        if (target == null) {
            return slot >= 0 ? "背包或副手中未找到对应部位的遗物" : "背包或副手中未找到对应遗物";
        }
        int sameCount = slot >= 0 ? countBySlot(player, definition.relic(), slot)
                : relicCount(player, definition.relic());
        if (sameCount != 1) {
            return "检测到多件同类遗物；请暂时只保留要升级的一件";
        }
        UpgradeDefinition.Effect maxEffect = maxEffectFor(definition, target.stack());
        if (maxEffect == null) {
            return "无法解析满级目标";
        }
        if (isAlreadyMax(target.stack(), maxEffect)) {
            return "该项已满级";
        }
        ItemStack output = upgradedCopy(target.stack(), maxEffect);
        if (target.inventorySlot() == 40) {
            player.getInventory().offHand.set(0, output);
        } else {
            player.getInventory().main.set(target.inventorySlot(), output);
        }
        player.getInventory().markDirty();
        player.playerScreenHandler.sendContentUpdates();
        ArmorOvercapHandler.onUpgradeApplied(player);
        return "创造模式一键满级：" + definition.title() + " 已拉满";
    }

    /** 由当前下一级 route 解析「满级 Effect」：目标槽 = 满级值，其余槽 -1（不变）。 */
    private static UpgradeDefinition.Effect maxEffectFor(UpgradeDefinition definition, ItemStack stack) {
        UpgradeDefinition.Effect e = definition.effect();
        UpgradeDefinition.RelicType type = definition.relic();
        NbtCompound data = stack.getNbt().getCompound(NBT);
        boolean wand = data.getString("item").equals("magic_wand");
        if (e.materialTier() >= 0) {
            return switch (type) {
                case PICKAXE -> new UpgradeDefinition.Effect(6, -1, -1, -1, -1, -1, -1, -1);
                case BONE_ARMOR -> new UpgradeDefinition.Effect(2, -1, -1, -1, -1, -1, -1, -1);
                case WAND -> new UpgradeDefinition.Effect(1, -1, -1, -1, -1, -1, -1, -1); // 下界灵魂之杖
                default -> null;
            };
        }
        if (e.efficiency() >= 0) {
            // 镐效率 V / 骨甲保护 V
            return new UpgradeDefinition.Effect(-1, 5, -1, -1, -1, -1, -1, -1);
        }
        if (e.fortune() >= 0) {
            // 镐时运 X / 骨甲韧性 X / 骨头吸血 X / 法杖吸血 X（wfortune）
            return new UpgradeDefinition.Effect(-1, -1, 10, -1, -1, -1, -1, -1);
        }
        if (e.fireAspect() >= 0) {
            // 骨头火焰附加 II / 骨甲荆棘 III
            int cap = type == UpgradeDefinition.RelicType.BONE ? 2 : 3;
            return new UpgradeDefinition.Effect(-1, -1, -1, cap, -1, -1, -1, -1);
        }
        if (e.looting() >= 0 && e.boneDamage() >= 0) {
            // 骨甲保护家族（looting=ptype, boneDamage=plevel）：保持家族，等级拉满 V
            return new UpgradeDefinition.Effect(-1, -1, -1, -1, e.looting(), 5, -1, -1);
        }
        if (e.looting() >= 0) {
            // 骨头抢夺 X
            return new UpgradeDefinition.Effect(-1, -1, -1, -1, 10, -1, -1, -1);
        }
        if (e.boneDamage() >= 0) {
            // 骨头伤害 D41（主手 +50）
            return new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, 41, -1, -1);
        }
        if (e.armor() >= 0) {
            if (wand) {
                // 法杖法术强度 30
                return new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, -1, 30, -1);
            }
            // 骨甲护甲值 50：材质同步拉满（合金铸体解锁 50 上限）
            return new UpgradeDefinition.Effect(2, -1, -1, -1, -1, -1, 50, -1);
        }
        if (e.explosion() >= 0) {
            // 法杖爆炸：灵魂杖（tier 1）XII，普通法杖 X
            int cap = data.getInt("tier") == 1 ? 12 : 10;
            return new UpgradeDefinition.Effect(-1, -1, -1, -1, -1, -1, -1, cap);
        }
        return null;
    }

    /** 目标槽是否已全部达到满级值（家族场景仅比较等级槽 damage）。 */
    private static boolean isAlreadyMax(ItemStack stack, UpgradeDefinition.Effect effect) {
        NbtCompound data = stack.getNbt().getCompound(NBT);
        boolean wand = data.getString("item").equals("magic_wand");
        boolean family = effect.looting() >= 0 && effect.boneDamage() >= 0;
        if (effect.materialTier() >= 0 && data.getInt("tier") < effect.materialTier()) {
            return false;
        }
        if (!family && effect.efficiency() >= 0 && data.getInt("efficiency") < effect.efficiency()) {
            return false;
        }
        if (!family && effect.fortune() >= 0 && data.getInt(wand ? "wfortune" : "fortune") < effect.fortune()) {
            return false;
        }
        if (!family && effect.fireAspect() >= 0 && data.getInt("fire") < effect.fireAspect()) {
            return false;
        }
        if (!family && effect.looting() >= 0 && data.getInt("looting") < effect.looting()) {
            return false;
        }
        if (effect.boneDamage() >= 0 && data.getInt("damage") < effect.boneDamage()) {
            return false;
        }
        if (!family && effect.armor() >= 0 && data.getInt(wand ? "spell" : "armor") < effect.armor()) {
            return false;
        }
        if (!family && effect.explosion() >= 0 && data.getInt("explosion") < effect.explosion()) {
            return false;
        }
        return true;
    }

    /** 写入 Tierify 神话品质 NBT：{Tiered:{Tier:"tiered:xxx"}}，已带品质不覆盖。仅装备类遗物调用。
     *  <p>关键：Tierify 的属性是「烘焙进物品 NBT」的（EMI/创造栏发放时会调用
     *  ModifierUtils#setItemStackAttribute 把 tier 属性写入物品），只写 Tiered.Tier 不会带出属性。
     *  这里通过反射触发同样的烘焙流程（装 Tierify 才生效，未装静默跳过，零编译依赖）。 */
    private static void applyMythic(ItemStack stack, String tierId) {
        NbtCompound tiered = stack.getOrCreateSubNbt("Tiered");
        if (!tiered.contains("Tier", 8)) {
            tiered.putString("Tier", tierId);
        }
        try {
            Class<?> modifierUtils = Class.forName("draylar.tiered.api.ModifierUtils");
            java.lang.reflect.Method setAttr = modifierUtils.getMethod("setItemStackAttribute",
                    net.minecraft.util.Identifier.class, ItemStack.class);
            setAttr.invoke(null, new net.minecraft.util.Identifier(tierId), stack);
        } catch (Throwable ignored) {
            // Tierify 未安装/版本不兼容：品质 NBT 保留，属性烘焙跳过（不影响其他功能）
        }
    }

    private static ItemStack upgradedCopy(ItemStack old, UpgradeDefinition.Effect effect) {
        NbtCompound data = old.getNbt().getCompound(NBT).copy();
        if (!data.contains("relic_id", 8)) {
            data.putString("relic_id", UUID.randomUUID().toString());
        }
        data.putInt("schema", 1);
        put(data, "tier", effect.materialTier());
        put(data, "efficiency", effect.efficiency());
        put(data, "fortune", effect.fortune());
        put(data, "fire", effect.fireAspect());
        put(data, "looting", effect.looting());
        put(data, "damage", effect.boneDamage());
        if (data.getString("item").equals("magic_wand")) {
            // 法杖：法术强度存 NBT "spell"（复用 armor 槽），吸血存 wfortune 槽，爆炸存 explosion 槽
            if (effect.armor() >= 0) {
                data.putInt("spell", effect.armor());
            }
            if (effect.fortune() >= 0) {
                data.putInt("wfortune", effect.fortune());
            }
            if (effect.explosion() >= 0) {
                data.putInt("explosion", effect.explosion());
            }
            put(data, "armor", -1); // 法杖不写 armor
        } else {
            put(data, "armor", effect.armor());
            // 骨甲材质升级：仅当前部件护甲值 +5（计入护甲值升级等级，上限 50）
            if (effect.materialTier() >= 0 && data.getString("item").startsWith("bone_")) {
                data.putInt("armor", Math.min(data.getInt("armor") + 5, 50));
            }
        }
        // 保留 Tierify 神话品质（升级重建物品，不拷贝会掉品质）
        NbtCompound tiered = old.getSubNbt("Tiered");
        ItemStack output = new ItemStack(itemFor(data.getString("item"), data.getInt("tier")));
        output.getOrCreateNbt().put(NBT, data);
        if (tiered != null) {
            output.getOrCreateNbt().put("Tiered", tiered.copy());
        }
        refreshStack(output);
        // 重新烘焙 Tierify 属性：升级重建后根 NBT 的烘焙属性不复制，须按原 Tier 重新写入
        if (tiered != null && tiered.contains("Tier", 8)) {
            applyMythic(output, tiered.getString("Tier"));
        }
        return output;
    }

    private static void put(NbtCompound nbt, String key, int value) {
        // 值为 -1 表示「不变」，不写入
        if (value >= 0) {
            nbt.putInt(key, value);
        }
    }

    private static Item itemFor(String kind, int tier) {
        return switch (kind) {
            case "pickaxe" -> pickaxeFor(tier);
            case "bone" -> ModItems.RELIC_BONE;
            case "bone_helmet" -> boneArmorFor(tier, 0);
            case "bone_chestplate" -> boneArmorFor(tier, 1);
            case "bone_leggings" -> boneArmorFor(tier, 2);
            case "bone_boots" -> boneArmorFor(tier, 3);
            case "magic_wand" -> ModItems.MAGIC_WAND;
            default -> Items.AIR;
        };
    }

    private static Item pickaxeFor(int tier) {
        return switch (tier) {
            case 0 -> ModItems.RELIC_IRON_PICKAXE;
            case 1 -> ModItems.RELIC_DIAMOND_PICKAXE;
            case 2 -> ModItems.RELIC_NETHERITE_PICKAXE;
            case 3 -> ModItems.RELIC_NETHERITE_IRON_PICKAXE;
            case 4 -> ModItems.RELIC_NETHERITE_GOLD_PICKAXE;
            case 5 -> ModItems.RELIC_NETHERITE_EMERALD_PICKAXE;
            default -> ModItems.RELIC_NETHERITE_DIAMOND_PICKAXE;
        };
    }

    private static Item boneArmorFor(int tier, int slot) {
        return switch (tier) {
            case 1 -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_DIAMOND_HELMET;
                case 1 -> ModItems.RELIC_BONE_DIAMOND_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_DIAMOND_LEGGINGS;
                default -> ModItems.RELIC_BONE_DIAMOND_BOOTS;
            };
            case 2 -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_NETHERITE_HELMET;
                case 1 -> ModItems.RELIC_BONE_NETHERITE_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_NETHERITE_LEGGINGS;
                default -> ModItems.RELIC_BONE_NETHERITE_BOOTS;
            };
            default -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_HELMET;
                case 1 -> ModItems.RELIC_BONE_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_LEGGINGS;
                default -> ModItems.RELIC_BONE_BOOTS;
            };
        };
    }

    // =====================================================================
    // 刷新堆叠：附魔 / 属性 / 模型 / 显示名 / lore
    // =====================================================================
    public static void refreshStack(ItemStack stack) {
        NbtCompound root = stack.getOrCreateNbt();
        NbtCompound data = root.getCompound(NBT);
        root.putBoolean("Unbreakable", true);

        String kind = data.getString("item");
        Map<Enchantment, Integer> enchantments = new HashMap<>();
        if (kind.equals("pickaxe")) {
            int efficiency = data.getInt("efficiency");
            int fortune = data.getInt("fortune");
            if (efficiency > 0) {
                enchantments.put(Enchantments.EFFICIENCY, efficiency);
            }
            if (fortune > 0) {
                enchantments.put(Enchantments.FORTUNE, fortune);
            }
        } else if (kind.equals("bone")) {
            int fire = data.getInt("fire");
            int looting = data.getInt("looting");
            if (fire > 0) {
                enchantments.put(Enchantments.FIRE_ASPECT, fire);
            }
            if (looting > 0) {
                enchantments.put(Enchantments.LOOTING, looting);
            }
            stack.addAttributeModifier(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                    new EntityAttributeModifier(BONE_DAMAGE_UUID, "bonefire_relics_bone_damage",
                            9.0 + data.getInt("damage"), EntityAttributeModifier.Operation.ADDITION),
                    EquipmentSlot.MAINHAND);
        } else if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            int protection = data.getInt("efficiency");
            int thorns = data.getInt("fire");
            int ptype = data.getInt("looting");
            int plevel = data.getInt("damage");
            int toughness = data.getInt("fortune");
            if (protection > 0) {
                enchantments.put(Enchantments.PROTECTION, protection);
            }
            if (thorns > 0) {
                enchantments.put(Enchantments.THORNS, thorns);
            }
            if (ptype > 0 && plevel > 0) {
                enchantments.put(protectionFamily(ptype), plevel);
            }
            int slotIndex = armorSlotIndex(kind);
            if (toughness > 0) {
                stack.addAttributeModifier(EntityAttributes.GENERIC_ARMOR_TOUGHNESS,
                        new EntityAttributeModifier(ARMOR_TOUGHNESS_UUIDS[slotIndex], "bonefire_relics_armor_toughness",
                                toughness, EntityAttributeModifier.Operation.ADDITION),
                        armorSlot(kind));
            }
            int armor = data.getInt("armor");
            if (armor > 0) {
                stack.addAttributeModifier(EntityAttributes.GENERIC_ARMOR,
                        new EntityAttributeModifier(ARMOR_VALUE_UUIDS[slotIndex], "bonefire_relics_armor_value",
                                armor, EntityAttributeModifier.Operation.ADDITION),
                        armorSlot(kind));
            }
        }
        EnchantmentHelper.set(enchantments, stack);

        // 模型切换：骨头火焰二级 / 下界灵魂之杖 -> 专属模型（CustomModelData 1）
        if (usesFireTwoModel(data) || usesSoulModel(data)) {
            root.putInt("CustomModelData", 1);
        } else {
            root.remove("CustomModelData");
        }

        stack.setCustomName(Text.literal(displayName(kind, data.getInt("tier"), data))
                .formatted(nameColor(kind, data.getInt("tier"), data)));
        writeLore(root, loreLines(kind, data.getInt("tier"), data));
    }

    private static Enchantment protectionFamily(int ptype) {
        return switch (ptype) {
            case 1 -> Enchantments.FIRE_PROTECTION;
            case 2 -> Enchantments.BLAST_PROTECTION;
            default -> Enchantments.PROJECTILE_PROTECTION;
        };
    }

    private static EquipmentSlot armorSlot(String kind) {
        if (kind.endsWith("_helmet")) {
            return EquipmentSlot.HEAD;
        }
        if (kind.endsWith("_chestplate")) {
            return EquipmentSlot.CHEST;
        }
        if (kind.endsWith("_leggings")) {
            return EquipmentSlot.LEGS;
        }
        return EquipmentSlot.FEET;
    }

    private static int armorSlotIndex(String kind) {
        if (kind.endsWith("_helmet")) {
            return 0;
        }
        if (kind.endsWith("_chestplate")) {
            return 1;
        }
        if (kind.endsWith("_leggings")) {
            return 2;
        }
        return 3;
    }

    static boolean usesFireTwoModel(NbtCompound data) {
        return "bone".equals(data.getString("item")) && data.getInt("fire") == 2;
    }

    /** 下界灵魂之杖：法杖 tier 1 使用灵魂蓝焰外观模型。 */
    static boolean usesSoulModel(NbtCompound data) {
        return "magic_wand".equals(data.getString("item")) && data.getInt("tier") == 1;
    }

    private static Formatting nameColor(String kind, int tier, NbtCompound data) {
        if (kind.equals("bone")) {
            int damage = data.getInt("damage");
            return damage >= 21 ? Formatting.DARK_PURPLE : (damage >= 6 ? Formatting.RED : Formatting.GOLD);
        }
        if (kind.equals("magic_wand")) {
            return tier == 1 ? Formatting.AQUA : Formatting.WHITE; // 下界灵魂之杖：灵魂蓝
        }
        if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            return tier >= 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE);
        }
        return tier >= 6 ? Formatting.DARK_PURPLE : (tier >= 3 ? Formatting.LIGHT_PURPLE
                : (tier == 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE)));
    }

    private static String displayName(String kind, int tier, NbtCompound data) {
        if (kind.equals("bone")) {
            if (data.getInt("fire") == 2) {
                return "蚀炎魂骨";
            }
            if (data.getInt("damage") >= 21) {
                return "噬魂龙骨";
            }
            if (data.getInt("looting") >= 6) {
                return "贪猎魂骨";
            }
            if (data.getInt("damage") >= 6) {
                return "裂杀号骨";
            }
            return "战利魂骨";
        }
        if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            String slotName = armorSlotName(kind);
            return switch (tier) {
                case 1 -> "钻石骨甲·" + slotName;
                case 2 -> "下界合金骨甲·" + slotName;
                default -> "遗物骨甲·" + slotName;
            };
        }
        if (kind.equals("magic_wand")) {
            return tier == 1 ? "下界灵魂之杖" : "遗物法杖";
        }
        return switch (tier) {
            case 1 -> "星辉钻镐";
            case 2 -> "永恒下界镐";
            case 3 -> "下界合金·铁镐";
            case 4 -> "下界合金·金镐";
            case 5 -> "下界合金·绿宝石镐";
            case 6 -> "下界合金·钻石镐";
            default -> data.getInt("fortune") >= 6 ? "寻脉铁镐"
                    : (data.getInt("efficiency") >= 4 ? "迅凿铁镐" : "无尽铁镐");
        };
    }

    private static String armorSlotName(String kind) {
        if (kind.endsWith("_helmet")) {
            return "头盔";
        }
        if (kind.endsWith("_chestplate")) {
            return "胸甲";
        }
        if (kind.endsWith("_leggings")) {
            return "护腿";
        }
        return "靴子";
    }

    private static List<String> loreLines(String kind, int tier, NbtCompound data) {
        ArrayList<String> lines = new ArrayList<>();
        lines.add("{\"text\":\"遗物成长 · 不可破坏\",\"color\":\"gray\",\"italic\":false}");
        if (kind.equals("bone")) {
            lines.add("{\"text\":\"主手额外攻击伤害：+" + (9 + data.getInt("damage")) + "\",\"color\":\"gold\",\"italic\":false}");
            lines.add("{\"text\":\"火焰附加：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
            if (data.getInt("fire") >= 2) {
                lines.add("{\"text\":\"秒杀：攻击时 1.2% 概率伤害提升至 999\",\"color\":\"light_purple\",\"italic\":false}");
            }
            lines.add("{\"text\":\"抢夺：" + roman(data.getInt("looting")) + "\",\"color\":\"green\",\"italic\":false}");
            int lifesteal = data.getInt("fortune");
            if (lifesteal > 0) {
                lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(lifesteal) * 100) + "%\",\"color\":\"dark_red\",\"italic\":false}");
            }
            lines.add("{\"text\":\"骨火：每命中3次 → 对最近至多3只怪物造成火焰魔法伤害（基础8，攻击每+1伤害+1，上限20）\",\"color\":\"gold\",\"italic\":false}");
            if (9 + data.getInt("damage") >= 20) {
                lines.add("{\"text\":\"骨裂：攻击力≥20 后每次攻击附加 8% 目标当前生命值伤害\",\"color\":\"light_purple\",\"italic\":false}");
            }
        } else if (kind.equals("pickaxe")) {
            lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"效率：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
            lines.add("{\"text\":\"时运：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
            lines.add("{\"text\":\"补给：每挖掘150个方块 → 「补给」5秒（每秒恢复1饥饿值+1饱食度）\",\"color\":\"gold\",\"italic\":false}");
        } else if (kind.equals("magic_wand")) {
            int spell = data.getInt("spell");
            boolean soul = tier == 1;
            lines.add("{\"text\":\"法术强度：" + spell + "/30\",\"color\":\"aqua\",\"italic\":false}");
            int explosion = data.getInt("explosion");
            int baseDamage = soul ? 15 : 10;
            lines.add("{\"text\":\"火球：左键攻击释放直线火球，命中任意生物即爆炸（不破坏方块），伤害 " + (int)(baseDamage + spell) + " 点魔法伤害" + (soul ? "（上限45）" : "") + "\",\"color\":\"gold\",\"italic\":false}");
            if (explosion > 0) {
                lines.add("{\"text\":\"爆炸：命中后对周围怪物造成 " + (int)(5 + explosion * 0.5) + " 点范围魔法伤害" + (soul ? "（最高XII级）" : "") + "\",\"color\":\"red\",\"italic\":false}");
            }
            if (soul) {
                lines.add("{\"text\":\"灵魂蓝焰：火球化为灵魂之火，命中附加凋零 II（5秒）\",\"color\":\"aqua\",\"italic\":false}");
                lines.add("{\"text\":\"灵魂爆裂：击杀目标后爆炸并传播凋零效果\",\"color\":\"light_purple\",\"italic\":false}");
                lines.add("{\"text\":\"暴击：35% 概率造成双倍伤害\",\"color\":\"red\",\"italic\":false}");
            }
            lines.add("{\"text\":\"连击：每次攻击 " + (int)(Math.min((soul ? 0.30 : 0.10) + spell * 0.01, soul ? 0.45 : 0.30) * 100) + "% 概率额外攻击一次（每点法术强度+1%" + (soul ? "，基础30%，上限45%" : "，上限30%") + "）\",\"color\":\"light_purple\",\"italic\":false}");
            if (spell >= 15) {
                lines.add("{\"text\":\"火罚：附加目标当前生命值 5% 伤害\",\"color\":\"dark_red\",\"italic\":false}");
            }
            int wls = data.getInt("wfortune");
            if (wls > 0) {
                lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(wls) * 100) + "%\",\"color\":\"dark_red\",\"italic\":false}");
            }
        } else {
            lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"护甲值：+" + data.getInt("armor") + "\",\"color\":\"gray\",\"italic\":false}");
            lines.add("{\"text\":\"保护：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
            lines.add("{\"text\":\"韧性：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
            lines.add("{\"text\":\"荆棘：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
            int ptype = data.getInt("looting");
            int plevel = data.getInt("damage");
            if (ptype > 0 && plevel > 0) {
                lines.add("{\"text\":\"" + protectionFamilyName(ptype) + "：" + roman(plevel) + "\",\"color\":\"light_purple\",\"italic\":false}");
            }
            lines.add("{\"text\":\"护甲超限：穿戴≥2件骨甲且全身护甲超 40 点后，每 1 点 = 0.5% 全面减伤 + 1% 最大生命\",\"color\":\"gold\",\"italic\":false}");
            lines.add("{\"text\":\"铸体（材质）护甲上限：" + armorCap(data.getInt("tier")) + "（钻石铸体 30 / 合金铸体 50）\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"骨甲护体：单次受击≥80%最大生命 或 20秒内累计≥200% → 抗性+生命恢复5秒\",\"color\":\"gold\",\"italic\":false}");
        }
        lines.add("{\"text\":\"服务器校验升级\",\"color\":\"dark_gray\",\"italic\":false}");
        return lines;
    }

    /** 骨甲材质（铸体）对应护甲上限：基础 20 / 钻石铸体 30 / 合金铸体 50。 */
    public static int armorCap(int tier) {
        return tier >= 2 ? 50 : (tier == 1 ? 30 : 20);
    }

    private static String protectionFamilyName(int ptype) {
        return switch (ptype) {
            case 1 -> "火焰保护";
            case 2 -> "爆炸保护";
            default -> "弹射物保护";
        };
    }

    private static String roman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    private static String toolStage(int tier) {
        return switch (tier) {
            case 1 -> "钻石覆层";
            case 2 -> "下界合金铸体";
            case 3 -> "下界合金·铁";
            case 4 -> "下界合金·金";
            case 5 -> "下界合金·绿宝石";
            case 6 -> "下界合金·钻石";
            default -> "铁质遗物";
        };
    }

    private static void writeLore(NbtCompound root, List<String> lines) {
        NbtCompound display = root.contains("display", 10) ? root.getCompound("display") : new NbtCompound();
        NbtList lore = new NbtList();
        for (String line : lines) {
            lore.add(NbtString.of(line));
        }
        display.put("Lore", lore);
        root.put("display", display);
    }

    // =====================================================================
    // 初始遗物
    // =====================================================================
    private static ItemStack newRelic(String kind, int tier) {
        ItemStack stack = new ItemStack(itemFor(kind, tier));
        NbtCompound data = new NbtCompound();
        data.putInt("schema", 1);
        data.putString("relic_id", UUID.randomUUID().toString());
        data.putString("item", kind);
        data.putInt("tier", tier);
        stack.getOrCreateNbt().put(NBT, data);
        return stack;
    }

    public static ItemStack initialPickaxe() {
        ItemStack stack = newRelic("pickaxe", 0);
        NbtCompound data = stack.getNbt().getCompound(NBT);
        data.putInt("efficiency", 1);
        data.putInt("fortune", 1);
        refreshStack(stack);
        applyMythic(stack, MYTHIC_TOOL); // 神话品质
        return stack;
    }

    public static ItemStack initialWand() {
        ItemStack stack = newRelic("magic_wand", 0);
        NbtCompound data = stack.getNbt().getCompound(NBT);
        data.putInt("spell", 0);
        data.putInt("fortune", 0);
        data.putInt("explosion", 0);
        refreshStack(stack);
        applyMythic(stack, MYTHIC_MELEE); // 神话品质
        return stack;
    }

    /** 骨头 ⇄ 法杖切换：同一物品两形态互换，各自升级数据分开保留（bone 与 wand 数据共存于 NBT）。 */
    public static String switchRelic(ServerPlayerEntity player) {
        Located target = null;
        for (UpgradeDefinition.RelicType type : List.of(UpgradeDefinition.RelicType.BONE, UpgradeDefinition.RelicType.WAND)) {
            Located loc = find(player, type);
            if (loc != null) {
                target = loc;
                break;
            }
        }
        if (target == null) {
            return "背包中未找到骨头或法杖，无法切换";
        }
        NbtCompound data = target.stack().getNbt().getCompound(NBT);
        String kind = data.getString("item");
        String newKind;
        String msg;
        if (kind.equals("bone")) {
            newKind = "magic_wand";
            msg = "已切换为：遗物法杖";
            // 骨头 → 法杖：恢复灵魂态（tier 1 = 下界灵魂之杖）
            if (data.contains("soul", 3)) {
                data.putInt("tier", data.getInt("soul"));
                data.remove("soul");
            }
        } else if (kind.equals("magic_wand")) {
            newKind = "bone";
            msg = "已切换为：战利品骨头";
            // 法杖 → 骨头：灵魂态暂存（骨头材质等级恒为 0）
            if (data.getInt("tier") == 1) {
                data.putInt("soul", 1);
                data.putInt("tier", 0);
            }
        } else {
            return "未知遗物，无法切换";
        }
        data.putString("item", newKind);
        ItemStack output = new ItemStack(itemFor(newKind, data.getInt("tier")));
        output.getOrCreateNbt().put(NBT, data);
        // 品质保活：法杖形态恢复神话品质；骨头形态不带 Tiered（非装备类，避免被 Tierify 随机覆盖）
        if (newKind.equals("magic_wand")) {
            applyMythic(output, MYTHIC_MELEE);
        }
        refreshStack(output);
        if (target.inventorySlot() == 40) {
            player.getInventory().offHand.set(0, output);
        } else {
            player.getInventory().main.set(target.inventorySlot(), output);
        }
        player.getInventory().markDirty();
        return msg;
    }

    public static ItemStack initialBone() {
        ItemStack stack = newRelic("bone", 0);
        NbtCompound data = stack.getNbt().getCompound(NBT);
        data.putInt("damage", 0);
        data.putInt("fire", 1);
        data.putInt("looting", 1);
        refreshStack(stack);
        return stack;
    }

    public static ItemStack initialGuideBook() {
        return new ItemStack(ModItems.RELIC_GUIDE_BOOK);
    }

    public static List<ItemStack> initialAllRelics() {
        return List.of(initialPickaxe(), initialBone(), initialGuideBook());
    }

    public static List<ItemStack> initialBoneArmor() {
        return armorSet(0);
    }

    private static List<ItemStack> armorSet(int tier) {
        String[] slots = {"helmet", "chestplate", "leggings", "boots"};
        ArrayList<ItemStack> result = new ArrayList<>();
        for (String slot : slots) {
            String kind = "bone_" + slot;
            ItemStack stack = newRelic(kind, tier);
            NbtCompound data = stack.getNbt().getCompound(NBT);
            data.putInt("efficiency", 1);
            data.putInt("fortune", 1);
            data.putInt("fire", 1);
            data.putInt("looting", 0);
            data.putInt("damage", 0);
            data.putInt("armor", 10);
            refreshStack(stack);
            applyMythic(stack, MYTHIC_ARMOR); // 神话品质
            result.add(stack);
        }
        return result;
    }

    private record Located(ItemStack stack, int inventorySlot) {
    }
}
