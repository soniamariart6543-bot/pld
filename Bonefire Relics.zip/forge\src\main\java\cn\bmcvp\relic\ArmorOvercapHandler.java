package cn.bmcvp.relic;

import java.lang.reflect.Field;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 护甲超限转化（Forge）：服务端权威计算 C/A/E/R/H，刷新最大生命修饰符。
 * 减伤通过 LivingDamageEvent（护甲+附魔结算后、实际扣血前）乘算 (1-R)，无需 Mixin。
 */
public final class ArmorOvercapHandler {
    public static final UUID OVERCAP_HEALTH_UUID = UUID.fromString("11111210-0000-0000-0000-000000000001");
    private static final int REFRESH_INTERVAL_TICKS = 10;

    private static boolean initialized;
    private static boolean armorCapRaised;
    private static int tickCounter;

    private ArmorOvercapHandler() {
    }

    public static void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        ArmorOvercapConfig.load();
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        tickCounter++;
        if (tickCounter % REFRESH_INTERVAL_TICKS != 0) {
            return;
        }
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            refreshPlayer(player);
        }
    }

    /** 进服即时刷新，避免进入存档后血量加成丢失。 */
    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            player.getServer().execute(() -> refreshPlayer(player));
        }
    }

    /** 复活即时刷新（复活会重建玩家并重置属性，需补挂生命修饰符）。 */
    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            player.getServer().execute(() -> refreshPlayer(player));
        }
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        float reduction = reductionOf(player);
        if (reduction > 0.0F) {
            event.setAmount(event.getAmount() * (1.0F - reduction));
        }
    }

    /**
     * 抬高 generic.armor 属性上限（max 30 → 220）。反射修改 RangedAttribute.maximumValue，
     * 惰性执行（首次服务端 tick / 客户端界面渲染时），失败不阻断游戏。
     */
    public static void ensureArmorCapRaised() {
        if (armorCapRaised) {
            return;
        }
        armorCapRaised = true;
        try {
            Attribute attribute = Attributes.ARMOR;
            if (attribute instanceof RangedAttribute ranged) {
                for (Field field : RangedAttribute.class.getDeclaredFields()) {
                    if (field.getType() != double.class) {
                        continue;
                    }
                    field.setAccessible(true);
                    double value = field.getDouble(ranged);
                    if (value >= 29.0 && value <= 31.0) {
                        field.setDouble(ranged, 220.0);
                        return;
                    }
                }
            }
        } catch (Exception ignored) {
            // 上限抬升失败：不阻断游戏，总属性口径下护甲将受原版钳制
        }
    }

    public static boolean isActive(ServerPlayer player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        return config.enabled && equippedRelicArmorCount(player) >= config.minRelicArmorPieces;
    }

    public static int equippedRelicArmorCount(ServerPlayer player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().armor) {
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                count++;
            }
        }
        return count;
    }

    /** 全身护甲值 A：TOTAL_ATTRIBUTE=总护甲属性；RELIC_NBT=四件骨甲 bmcvp.armor 之和。 */
    public static int armorValue(ServerPlayer player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        if (config.isRelicNbtSource()) {
            int sum = 0;
            for (ItemStack stack : player.getInventory().armor) {
                if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                    sum += RelicService.value(stack, "armor");
                }
            }
            return sum;
        }
        ensureArmorCapRaised();
        return (int) Math.floor(player.getAttributeValue(Attributes.ARMOR));
    }

    /** 超限值 E = max(0, floor(A) - threshold)。 */
    public static int overcapValue(ServerPlayer player) {
        if (!isActive(player)) {
            return 0;
        }
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        return Math.max(0, armorValue(player) - (int) config.threshold);
    }

    /** 全面减伤 R = min(E × drPercentPerPoint%, drCapPercent%)。 */
    public static float reductionOf(ServerPlayer player) {
        if (!isActive(player)) {
            return 0.0f;
        }
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        double reduction = overcapValue(player) * config.drPercentPerPoint / 100.0;
        return (float) Math.min(reduction, config.drCapPercent / 100.0);
    }

    /**
     * 刷新最大生命修饰符。以「修饰符是否存在且数值正确」为准，而非缓存护甲值——
     * 进入存档 / 复活时原版会重建并重置玩家属性，可能清掉本修饰符；此处每次核对，
     * 缺失即补挂，保证血量加成在进服 / 复活后依然生效。
     */
    public static void refreshPlayer(ServerPlayer player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        boolean active = isActive(player);
        int armor = active ? armorValue(player) : 0;
        int overcap = active ? Math.max(0, armor - (int) config.threshold) : 0;
        AttributeInstance health = player.getAttribute(Attributes.MAX_HEALTH);
        if (health == null) {
            return;
        }
        if (overcap <= 0) {
            if (health.getModifier(OVERCAP_HEALTH_UUID) != null) {
                health.removeModifier(OVERCAP_HEALTH_UUID);
            }
            return;
        }
        double bonus = Math.min(overcap * config.healthPerPoint, config.healthCap);
        double amount;
        AttributeModifier.Operation operation;
        if (config.isHpMode()) {
            amount = bonus;
            operation = AttributeModifier.Operation.ADDITION;
        } else {
            amount = bonus / 100.0;
            operation = AttributeModifier.Operation.MULTIPLY_TOTAL;
        }
        AttributeModifier current = health.getModifier(OVERCAP_HEALTH_UUID);
        if (current != null && current.getAmount() == amount && current.getOperation() == operation) {
            return; // 已存在且数值正确
        }
        health.removeModifier(OVERCAP_HEALTH_UUID);
        if (amount > 0) {
            health.addPermanentModifier(new AttributeModifier(
                    OVERCAP_HEALTH_UUID, "bmcvp_armor_overcap_health", amount, operation));
        }
    }

    /** 升级成功后立即刷新（由 RelicService.tryUpgrade 成功分支调用）。 */
    public static void onUpgradeApplied(ServerPlayer player) {
        refreshPlayer(player);
    }
}
