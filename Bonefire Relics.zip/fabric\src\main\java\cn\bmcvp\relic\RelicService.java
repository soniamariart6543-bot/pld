package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * 遗物升级核心逻辑。全部在服务器执行，客户端只发送升级 id 并接收结果文本。
 */
public final class RelicService {
    public static final String NBT = "bmcvp";
    public static final int MAX_EXPERIENCE_COST = 50;

    private static final UUID BONE_DAMAGE_UUID = UUID.fromString("11111201-0000-0000-0000-000000000001");
    // 每个部位独立 UUID，避免相同 UUID 在 AttributeContainer 中被去重（只保留最后穿的一件）
    private static final UUID[] ARMOR_TOUGHNESS_UUIDS = new UUID[]{
            UUID.fromString("11111202-0000-0000-0000-000000000001"), // helmet
            UUID.fromString("11111203-0000-0000-0000-000000000001"), // chestplate
            UUID.fromString("11111204-0000-0000-0000-000000000001"), // leggings
            UUID.fromString("11111205-0000-0000-0000-000000000001")  // boots
    };
    private static final UUID[] ARMOR_VALUE_UUIDS = new UUID[]{
            UUID.fromString("11111206-0000-0000-0000-000000000001"), // helmet
            UUID.fromString("11111207-0000-0000-0000-000000000001"), // chestplate
            UUID.fromString("11111208-0000-0000-0000-000000000001"), // leggings
            UUID.fromString("11111209-0000-0000-0000-000000000001")  // boots
    };

    private RelicService() {
    }

    // =====================================================================
    // 查找 / 识别
    // =====================================================================
    private static Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
        String kindFilter = kindForSlot(type, slot);
        for (int i = 0; i < player.getInventory().main.size(); i++) {
            ItemStack stack = player.getInventory().main.get(i);
            if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
                return new Located(stack, i);
            }
        }
        ItemStack offHand = player.getOffHandStack();
        if (isRelic(offHand, type) && matchesKindFilter(offHand, kindFilter)) {
            return new Located(offHand, 40);
        }
        return null;
    }

    private static Located find(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        return find(player, type, -1);
    }

    public static boolean anyRelic(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        return find(player, type) != null;
    }

    private static boolean matchesKindFilter(ItemStack stack, String kindFilter) {
        if (kindFilter == null) {
            return true;
        }
        return stack.hasNbt() && kindFilter.equals(stack.getNbt().getCompound(NBT).getString("item"));
    }

    private static String kindForSlot(UpgradeDefinition.RelicType type, int slot) {
        if (type != UpgradeDefinition.RelicType.BONE_ARMOR || slot < 0) {
            return null;
        }
        String[] slots = {"helmet", "chestplate", "leggings", "boots"};
        return "bone_" + slots[slot];
    }

    private static int relicCount(ServerPlayerEntity player, UpgradeDefinition.RelicType type) {
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (isRelic(stack, type)) {
                count++;
            }
        }
        if (isRelic(player.getOffHandStack(), type)) {
            count++;
        }
        return count;
    }

    private static int countBySlot(ServerPlayerEntity player, UpgradeDefinition.RelicType type, int slot) {
        String kindFilter = kindForSlot(type, slot);
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (isRelic(stack, type) && matchesKindFilter(stack, kindFilter)) {
                count++;
            }
        }
        if (isRelic(player.getOffHandStack(), type) && matchesKindFilter(player.getOffHandStack(), kindFilter)) {
            count++;
        }
        return count;
    }

    /** 是否为任意遗物（含教程书骨与火）：用于防丢弃 / 防销毁。 */
    public static boolean isAnyRelic(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (stack.isOf(ModItems.RELIC_GUIDE_BOOK)) {
            return true;
        }
        if (!stack.hasNbt() || !stack.getNbt().contains(NBT, 10)) {
            return false;
        }
        return !stack.getNbt().getCompound(NBT).getString("item").isEmpty();
    }

    public static boolean isRelic(ItemStack stack, UpgradeDefinition.RelicType type) {
        if (stack.isEmpty() || !stack.hasNbt() || !stack.getNbt().contains(NBT, 10)) {
            return false;
        }
        NbtCompound data = stack.getNbt().getCompound(NBT);
        if (data.contains("schema")) {
            return data.contains("schema", 3) && isCurrentRelic(stack, type, data);
        }
        return isLegacyRelic(stack, type, data);
    }

    private static boolean isCurrentRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
        if (data.getInt("schema") != 1 || !matchesKind(data.getString("item"), type) || !hasValidRelicId(data)) {
            return false;
        }
        int tier = data.getInt("tier");
        return isValidTier(type, tier) && hasValidState(type, data)
                && stack.isOf(itemFor(data.getString("item"), tier));
    }

    /** 判断 NBT 中的物品 kind 是否属于给定遗物类型。 */
    private static boolean matchesKind(String kind, UpgradeDefinition.RelicType type) {
        return switch (type) {
            case PICKAXE -> kind.equals("pickaxe");
            case BONE -> kind.equals("bone");
            case BONE_ARMOR -> kind.startsWith("bone_");
        };
    }

    private static boolean hasValidState(UpgradeDefinition.RelicType type, NbtCompound data) {
        return switch (type) {
            case PICKAXE -> between(data.getInt("efficiency"), 1, 5) && between(data.getInt("fortune"), 1, 10);
            case BONE -> between(data.getInt("damage"), 0, 41) && between(data.getInt("fire"), 1, 2)
                    && between(data.getInt("looting"), 1, 10)
                    && between(data.getInt("fortune"), 0, 10);
            case BONE_ARMOR -> between(data.getInt("efficiency"), 1, 5)
                    && between(data.getInt("fortune"), 1, 10)
                    && between(data.getInt("fire"), 1, 3)
                    && between(data.getInt("looting"), 0, 3)
                    && between(data.getInt("damage"), 0, 5)
                    && between(data.getInt("armor"), 0, 50);
        };
    }

    private static boolean between(int value, int min, int max) {
        return value >= min && value <= max;
    }

    static boolean hasValidRelicId(NbtCompound data) {
        if (!data.contains("relic_id", 8)) {
            return false;
        }
        try {
            UUID.fromString(data.getString("relic_id"));
            return true;
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private static boolean isLegacyRelic(ItemStack stack, UpgradeDefinition.RelicType type, NbtCompound data) {
        if (data.contains("relic_id") || !matchesKind(data.getString("item"), type)) {
            return false;
        }
        return switch (type) {
            case PICKAXE -> isLegacyPickaxe(stack, data) && between(data.getInt("efficiency"), 1, 5)
                    && between(data.getInt("fortune"), 0, 10);
            case BONE -> stack.isOf(Items.BONE) && data.getInt("tier") == 0
                    && between(data.getInt("damage"), 0, 41) && between(data.getInt("fire"), 1, 2)
                    && between(data.getInt("looting"), 1, 10);
            case BONE_ARMOR -> false;
        };
    }

    private static boolean isLegacyPickaxe(ItemStack stack, NbtCompound data) {
        return switch (data.getInt("tier")) {
            case 0 -> stack.isOf(Items.IRON_PICKAXE);
            case 1 -> stack.isOf(Items.DIAMOND_PICKAXE);
            case 2 -> stack.isOf(Items.NETHERITE_PICKAXE);
            default -> false;
        };
    }

    private static boolean isValidTier(UpgradeDefinition.RelicType type, int tier) {
        return switch (type) {
            case PICKAXE -> between(tier, 0, UpgradeDefinition.PICKAXE_TIER_MAX);
            case BONE -> tier == 0;
            case BONE_ARMOR -> between(tier, 0, 2);
        };
    }

    // =====================================================================
    // 数值读取
    // =====================================================================
    public static int value(ItemStack stack, String key) {
        return stack.getNbt().getCompound(NBT).getInt(key);
    }

    /** 吸血百分比曲线（0-10 级）。1级5%、2级15%、10级85%，曲线递增。 */
    private static final int[] LIFESTEAL_PERCENT = {0, 5, 15, 25, 35, 45, 55, 63, 70, 78, 85};

    public static float lifestealPercent(int level) {
        if (level < 0) {
            level = 0;
        }
        if (level > 10) {
            level = 10;
        }
        return LIFESTEAL_PERCENT[level] / 100.0f;
    }

    public static boolean meets(ItemStack stack, UpgradeDefinition.Requirement requirement) {
        return !(requirement.materialTier() >= 0 && value(stack, "tier") != requirement.materialTier()
                || requirement.efficiency() >= 0 && value(stack, "efficiency") != requirement.efficiency()
                || requirement.fortune() >= 0 && value(stack, "fortune") != requirement.fortune()
                || requirement.fireAspect() >= 0 && value(stack, "fire") != requirement.fireAspect()
                || requirement.looting() >= 0 && value(stack, "looting") != requirement.looting()
                || requirement.boneDamage() >= 0 && value(stack, "damage") != requirement.boneDamage()
                || requirement.armor() >= 0 && value(stack, "armor") != requirement.armor());
    }

    // =====================================================================
    // 成本统计与扣除
    // =====================================================================
    public static int count(ServerPlayerEntity player, Item item) {
        int count = 0;
        for (ItemStack stack : player.getInventory().main) {
            if (stack.isOf(item)) {
                count += stack.getCount();
            }
        }
        if (player.getOffHandStack().isOf(item)) {
            count += player.getOffHandStack().getCount();
        }
        return count;
    }

    private static Map<Item, Integer> aggregateCosts(UpgradeDefinition definition) {
        Map<Item, Integer> totals = new HashMap<>();
        for (UpgradeDefinition.Cost cost : definition.costs()) {
            totals.merge(cost.item(), cost.count(), Integer::sum);
        }
        return totals;
    }

    public static boolean hasCosts(ServerPlayerEntity player, UpgradeDefinition definition) {
        for (Map.Entry<Item, Integer> cost : aggregateCosts(definition).entrySet()) {
            if (count(player, cost.getKey()) < cost.getValue()) {
                return false;
            }
        }
        return true;
    }

    private static void remove(ServerPlayerEntity player, Item item, int required) {
        for (ItemStack stack : player.getInventory().main) {
            if (!stack.isOf(item) || required <= 0) {
                continue;
            }
            int taken = Math.min(required, stack.getCount());
            stack.decrement(taken);
            required -= taken;
        }
        ItemStack offHand = player.getOffHandStack();
        if (required > 0 && offHand.isOf(item)) {
            offHand.decrement(Math.min(required, offHand.getCount()));
        }
    }

    public static int availability(ServerPlayerEntity player, UpgradeDefinition definition) {
        if (!anyRelic(player, definition.relic())) {
            return 0;
        }
        if (relicCount(player, definition.relic()) != 1) {
            return 5;
        }
        Located target = find(player, definition.relic());
        if (target == null || !meets(target.stack(), definition.requirement())) {
            return 1;
        }
        if (!hasCosts(player, definition)) {
            return 2;
        }
        if (definition.experienceLevels() < 0 || definition.experienceLevels() > MAX_EXPERIENCE_COST
                || player.experienceLevel < definition.experienceLevels()) {
            return 3;
        }
        return 4;
    }

    // =====================================================================
    // 升级主流程
    // =====================================================================
    public static String tryUpgrade(ServerPlayerEntity player, String id, int slot) {
        UpgradeDefinition definition = UpgradeDefinition.byId(id);
        if (definition == null) {
            return "未知升级请求";
        }
        if (definition.experienceLevels() < 0 || definition.experienceLevels() > MAX_EXPERIENCE_COST) {
            return "升级配置的经验成本非法；未扣除任何内容";
        }
        boolean creative = player.getAbilities().creativeMode;
        Located target = find(player, definition.relic(), slot);
        if (target == null) {
            return slot >= 0 ? "背包或副手中未找到对应部位的遗物" : "背包或副手中未找到对应遗物";
        }
        // 骨甲铸体（材质）：护甲值升级目标超过当前铸体上限时拒绝
        if (definition.relic() == UpgradeDefinition.RelicType.BONE_ARMOR && definition.effect().armor() > 0) {
            int cap = armorCap(value(target.stack(), "tier"));
            if (definition.effect().armor() > cap) {
                return "护甲上限不足：当前铸体（材质）上限 " + cap + "，需升级材质解锁（钻石铸体 30 / 合金铸体 50）";
            }
        }
        int sameCount = slot >= 0 ? countBySlot(player, definition.relic(), slot) : relicCount(player, definition.relic());
        if (sameCount != 1) {
            return "检测到多件同类遗物；请暂时只保留要升级的一件";
        }
        if (!meets(target.stack(), definition.requirement())) {
            return "遗物当前等级不满足此前置条件";
        }
        if (!creative) {
            if (!hasCosts(player, definition)) {
                return "材料不足；未扣除任何材料或经验";
            }
            if (player.experienceLevel < definition.experienceLevels()) {
                return "经验等级不足；未扣除任何材料或经验";
            }
        }
        if (!creative) {
            for (UpgradeDefinition.Cost cost : definition.costs()) {
                remove(player, cost.item(), cost.count());
            }
            if (definition.experienceLevels() > 0) {
                player.addExperienceLevels(-definition.experienceLevels());
            }
        }
        ItemStack output = upgradedCopy(target.stack(), definition.effect());
        if (target.inventorySlot() == 40) {
            player.getInventory().offHand.set(0, output);
        } else {
            player.getInventory().main.set(target.inventorySlot(), output);
        }
        player.getInventory().markDirty();
        player.playerScreenHandler.sendContentUpdates();
        ArmorOvercapHandler.onUpgradeApplied(player);
        return "升级成功：" + definition.title() + "（消耗 " + definition.experienceLevels() + " 级经验）";
    }

    private static ItemStack upgradedCopy(ItemStack old, UpgradeDefinition.Effect effect) {
        NbtCompound data = old.getNbt().getCompound(NBT).copy();
        if (!data.contains("relic_id", 8)) {
            data.putString("relic_id", UUID.randomUUID().toString());
        }
        data.putInt("schema", 1);
        put(data, "tier", effect.materialTier());
        put(data, "efficiency", effect.efficiency());
        put(data, "fortune", effect.fortune());
        put(data, "fire", effect.fireAspect());
        put(data, "looting", effect.looting());
        put(data, "damage", effect.boneDamage());
        put(data, "armor", effect.armor());
        // 骨甲材质升级：仅当前部件护甲值 +5（计入护甲值升级等级，上限 50）
        if (effect.materialTier() >= 0 && data.getString("item").startsWith("bone_")) {
            data.putInt("armor", Math.min(data.getInt("armor") + 5, 50));
        }
        ItemStack output = new ItemStack(itemFor(data.getString("item"), data.getInt("tier")));
        output.getOrCreateNbt().put(NBT, data);
        refreshStack(output);
        return output;
    }

    private static void put(NbtCompound nbt, String key, int value) {
        // 值为 -1 表示「不变」，不写入
        if (value >= 0) {
            nbt.putInt(key, value);
        }
    }

    private static Item itemFor(String kind, int tier) {
        return switch (kind) {
            case "pickaxe" -> pickaxeFor(tier);
            case "bone" -> ModItems.RELIC_BONE;
            case "bone_helmet" -> boneArmorFor(tier, 0);
            case "bone_chestplate" -> boneArmorFor(tier, 1);
            case "bone_leggings" -> boneArmorFor(tier, 2);
            case "bone_boots" -> boneArmorFor(tier, 3);
            default -> Items.AIR;
        };
    }

    private static Item pickaxeFor(int tier) {
        return switch (tier) {
            case 0 -> ModItems.RELIC_IRON_PICKAXE;
            case 1 -> ModItems.RELIC_DIAMOND_PICKAXE;
            case 2 -> ModItems.RELIC_NETHERITE_PICKAXE;
            case 3 -> ModItems.RELIC_NETHERITE_IRON_PICKAXE;
            case 4 -> ModItems.RELIC_NETHERITE_GOLD_PICKAXE;
            case 5 -> ModItems.RELIC_NETHERITE_EMERALD_PICKAXE;
            default -> ModItems.RELIC_NETHERITE_DIAMOND_PICKAXE;
        };
    }

    private static Item boneArmorFor(int tier, int slot) {
        return switch (tier) {
            case 1 -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_DIAMOND_HELMET;
                case 1 -> ModItems.RELIC_BONE_DIAMOND_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_DIAMOND_LEGGINGS;
                default -> ModItems.RELIC_BONE_DIAMOND_BOOTS;
            };
            case 2 -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_NETHERITE_HELMET;
                case 1 -> ModItems.RELIC_BONE_NETHERITE_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_NETHERITE_LEGGINGS;
                default -> ModItems.RELIC_BONE_NETHERITE_BOOTS;
            };
            default -> switch (slot) {
                case 0 -> ModItems.RELIC_BONE_HELMET;
                case 1 -> ModItems.RELIC_BONE_CHESTPLATE;
                case 2 -> ModItems.RELIC_BONE_LEGGINGS;
                default -> ModItems.RELIC_BONE_BOOTS;
            };
        };
    }

    // =====================================================================
    // 刷新堆叠：附魔 / 属性 / 模型 / 显示名 / lore
    // =====================================================================
    public static void refreshStack(ItemStack stack) {
        NbtCompound root = stack.getOrCreateNbt();
        NbtCompound data = root.getCompound(NBT);
        root.putBoolean("Unbreakable", true);

        String kind = data.getString("item");
        Map<Enchantment, Integer> enchantments = new HashMap<>();
        if (kind.equals("pickaxe")) {
            int efficiency = data.getInt("efficiency");
            int fortune = data.getInt("fortune");
            if (efficiency > 0) {
                enchantments.put(Enchantments.EFFICIENCY, efficiency);
            }
            if (fortune > 0) {
                enchantments.put(Enchantments.FORTUNE, fortune);
            }
        } else if (kind.equals("bone")) {
            int fire = data.getInt("fire");
            int looting = data.getInt("looting");
            if (fire > 0) {
                enchantments.put(Enchantments.FIRE_ASPECT, fire);
            }
            if (looting > 0) {
                enchantments.put(Enchantments.LOOTING, looting);
            }
            stack.addAttributeModifier(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                    new EntityAttributeModifier(BONE_DAMAGE_UUID, "bmcvp_bone_damage",
                            9.0 + data.getInt("damage"), EntityAttributeModifier.Operation.ADDITION),
                    EquipmentSlot.MAINHAND);
        } else if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            int protection = data.getInt("efficiency");
            int thorns = data.getInt("fire");
            int ptype = data.getInt("looting");
            int plevel = data.getInt("damage");
            int toughness = data.getInt("fortune");
            if (protection > 0) {
                enchantments.put(Enchantments.PROTECTION, protection);
            }
            if (thorns > 0) {
                enchantments.put(Enchantments.THORNS, thorns);
            }
            if (ptype > 0 && plevel > 0) {
                enchantments.put(protectionFamily(ptype), plevel);
            }
            int slotIndex = armorSlotIndex(kind);
            if (toughness > 0) {
                stack.addAttributeModifier(EntityAttributes.GENERIC_ARMOR_TOUGHNESS,
                        new EntityAttributeModifier(ARMOR_TOUGHNESS_UUIDS[slotIndex], "bmcvp_armor_toughness",
                                toughness, EntityAttributeModifier.Operation.ADDITION),
                        armorSlot(kind));
            }
            int armor = data.getInt("armor");
            if (armor > 0) {
                stack.addAttributeModifier(EntityAttributes.GENERIC_ARMOR,
                        new EntityAttributeModifier(ARMOR_VALUE_UUIDS[slotIndex], "bmcvp_armor_value",
                                armor, EntityAttributeModifier.Operation.ADDITION),
                        armorSlot(kind));
            }
        }
        EnchantmentHelper.set(enchantments, stack);

        // 模型切换：骨头火焰二级 -> 火焰模型
        if (usesFireTwoModel(data)) {
            root.putInt("CustomModelData", 1);
        } else {
            root.remove("CustomModelData");
        }

        stack.setCustomName(Text.literal(displayName(kind, data.getInt("tier"), data))
                .formatted(nameColor(kind, data.getInt("tier"), data)));
        writeLore(root, loreLines(kind, data.getInt("tier"), data));
    }

    private static Enchantment protectionFamily(int ptype) {
        return switch (ptype) {
            case 1 -> Enchantments.FIRE_PROTECTION;
            case 2 -> Enchantments.BLAST_PROTECTION;
            default -> Enchantments.PROJECTILE_PROTECTION;
        };
    }

    private static EquipmentSlot armorSlot(String kind) {
        if (kind.endsWith("_helmet")) {
            return EquipmentSlot.HEAD;
        }
        if (kind.endsWith("_chestplate")) {
            return EquipmentSlot.CHEST;
        }
        if (kind.endsWith("_leggings")) {
            return EquipmentSlot.LEGS;
        }
        return EquipmentSlot.FEET;
    }

    private static int armorSlotIndex(String kind) {
        if (kind.endsWith("_helmet")) {
            return 0;
        }
        if (kind.endsWith("_chestplate")) {
            return 1;
        }
        if (kind.endsWith("_leggings")) {
            return 2;
        }
        return 3;
    }

    static boolean usesFireTwoModel(NbtCompound data) {
        return "bone".equals(data.getString("item")) && data.getInt("fire") == 2;
    }


    private static Formatting nameColor(String kind, int tier, NbtCompound data) {
        if (kind.equals("bone")) {
            int damage = data.getInt("damage");
            return damage >= 21 ? Formatting.DARK_PURPLE : (damage >= 6 ? Formatting.RED : Formatting.GOLD);
        }
        if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            return tier >= 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE);
        }
        return tier >= 6 ? Formatting.DARK_PURPLE : (tier >= 3 ? Formatting.LIGHT_PURPLE
                : (tier == 2 ? Formatting.DARK_PURPLE : (tier == 1 ? Formatting.AQUA : Formatting.WHITE)));
    }

    private static String displayName(String kind, int tier, NbtCompound data) {
        if (kind.equals("bone")) {
            if (data.getInt("fire") == 2) {
                return "蚀炎魂骨";
            }
            if (data.getInt("damage") >= 21) {
                return "噬魂龙骨";
            }
            if (data.getInt("looting") >= 6) {
                return "贪猎魂骨";
            }
            if (data.getInt("damage") >= 6) {
                return "裂杀号骨";
            }
            return "战利魂骨";
        }
        if (matchesKind(kind, UpgradeDefinition.RelicType.BONE_ARMOR)) {
            String slotName = armorSlotName(kind);
            return switch (tier) {
                case 1 -> "钻石骨甲·" + slotName;
                case 2 -> "下界合金骨甲·" + slotName;
                default -> "遗物骨甲·" + slotName;
            };
        }
        return switch (tier) {
            case 1 -> "星辉钻镐";
            case 2 -> "永恒下界镐";
            case 3 -> "下界合金·铁镐";
            case 4 -> "下界合金·金镐";
            case 5 -> "下界合金·绿宝石镐";
            case 6 -> "下界合金·钻石镐";
            default -> data.getInt("fortune") >= 6 ? "寻脉铁镐"
                    : (data.getInt("efficiency") >= 4 ? "迅凿铁镐" : "无尽铁镐");
        };
    }

    private static String armorSlotName(String kind) {
        if (kind.endsWith("_helmet")) {
            return "头盔";
        }
        if (kind.endsWith("_chestplate")) {
            return "胸甲";
        }
        if (kind.endsWith("_leggings")) {
            return "护腿";
        }
        return "靴子";
    }

    private static List<String> loreLines(String kind, int tier, NbtCompound data) {
        ArrayList<String> lines = new ArrayList<>();
        lines.add("{\"text\":\"遗物成长 · 不可破坏\",\"color\":\"gray\",\"italic\":false}");
        if (kind.equals("bone")) {
            lines.add("{\"text\":\"主手额外攻击伤害：+" + (9 + data.getInt("damage")) + "\",\"color\":\"gold\",\"italic\":false}");
            lines.add("{\"text\":\"火焰附加：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
            if (data.getInt("fire") >= 2) {
                lines.add("{\"text\":\"秒杀：攻击时 1.2% 概率伤害提升至 999\",\"color\":\"light_purple\",\"italic\":false}");
            }
            lines.add("{\"text\":\"抢夺：" + roman(data.getInt("looting")) + "\",\"color\":\"green\",\"italic\":false}");
            int lifesteal = data.getInt("fortune");
            if (lifesteal > 0) {
                lines.add("{\"text\":\"吸血：" + (int)(lifestealPercent(lifesteal) * 100) + "%\",\"color\":\"dark_red\",\"italic\":false}");
            }
            lines.add("{\"text\":\"骨火：每命中3次 → 对最近至多3只怪物造成火焰魔法伤害（基础8，攻击每+1伤害+1，上限20）\",\"color\":\"gold\",\"italic\":false}");
        } else if (kind.equals("pickaxe")) {
            lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"效率：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
            lines.add("{\"text\":\"时运：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
            lines.add("{\"text\":\"补给：每挖掘150个方块 → 「补给」5秒（每秒恢复1饥饿值+1饱食度）\",\"color\":\"gold\",\"italic\":false}");
        } else {
            lines.add("{\"text\":\"材质：" + toolStage(tier) + "\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"护甲值：+" + data.getInt("armor") + "\",\"color\":\"gray\",\"italic\":false}");
            lines.add("{\"text\":\"保护：" + roman(data.getInt("efficiency")) + "\",\"color\":\"yellow\",\"italic\":false}");
            lines.add("{\"text\":\"韧性：" + roman(data.getInt("fortune")) + "\",\"color\":\"green\",\"italic\":false}");
            lines.add("{\"text\":\"荆棘：" + roman(data.getInt("fire")) + "\",\"color\":\"red\",\"italic\":false}");
            int ptype = data.getInt("looting");
            int plevel = data.getInt("damage");
            if (ptype > 0 && plevel > 0) {
                lines.add("{\"text\":\"" + protectionFamilyName(ptype) + "：" + roman(plevel) + "\",\"color\":\"light_purple\",\"italic\":false}");
            }
            lines.add("{\"text\":\"护甲超限：穿戴≥2件骨甲且全身护甲超 40 点后，每 1 点 = 0.5% 全面减伤 + 1% 最大生命\",\"color\":\"gold\",\"italic\":false}");
            lines.add("{\"text\":\"铸体（材质）护甲上限：" + armorCap(data.getInt("tier")) + "（钻石铸体 30 / 合金铸体 50）\",\"color\":\"aqua\",\"italic\":false}");
            lines.add("{\"text\":\"骨甲护体：单次受击≥80%最大生命 或 20秒内累计≥200% → 抗性+生命恢复5秒\",\"color\":\"gold\",\"italic\":false}");
        }
        lines.add("{\"text\":\"服务器校验升级\",\"color\":\"dark_gray\",\"italic\":false}");
        return lines;
    }

    /** 骨甲材质（铸体）对应护甲上限：基础 20 / 钻石铸体 30 / 合金铸体 50。 */
    public static int armorCap(int tier) {
        return tier >= 2 ? 50 : (tier == 1 ? 30 : 20);
    }

    private static String protectionFamilyName(int ptype) {
        return switch (ptype) {
            case 1 -> "火焰保护";
            case 2 -> "爆炸保护";
            default -> "弹射物保护";
        };
    }

    private static String roman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    private static String toolStage(int tier) {
        return switch (tier) {
            case 1 -> "钻石覆层";
            case 2 -> "下界合金铸体";
            case 3 -> "下界合金·铁";
            case 4 -> "下界合金·金";
            case 5 -> "下界合金·绿宝石";
            case 6 -> "下界合金·钻石";
            default -> "铁质遗物";
        };
    }

    private static void writeLore(NbtCompound root, List<String> lines) {
        NbtCompound display = root.contains("display", 10) ? root.getCompound("display") : new NbtCompound();
        NbtList lore = new NbtList();
        for (String line : lines) {
            lore.add(NbtString.of(line));
        }
        display.put("Lore", lore);
        root.put("display", display);
    }

    // =====================================================================
    // 初始遗物
    // =====================================================================
    private static ItemStack newRelic(String kind, int tier) {
        ItemStack stack = new ItemStack(itemFor(kind, tier));
        NbtCompound data = new NbtCompound();
        data.putInt("schema", 1);
        data.putString("relic_id", UUID.randomUUID().toString());
        data.putString("item", kind);
        data.putInt("tier", tier);
        stack.getOrCreateNbt().put(NBT, data);
        return stack;
    }

    public static ItemStack initialPickaxe() {
        ItemStack stack = newRelic("pickaxe", 0);
        NbtCompound data = stack.getNbt().getCompound(NBT);
        data.putInt("efficiency", 1);
        data.putInt("fortune", 1);
        refreshStack(stack);
        return stack;
    }

    public static ItemStack initialBone() {
        ItemStack stack = newRelic("bone", 0);
        NbtCompound data = stack.getNbt().getCompound(NBT);
        data.putInt("damage", 0);
        data.putInt("fire", 1);
        data.putInt("looting", 1);
        refreshStack(stack);
        return stack;
    }

    public static ItemStack initialGuideBook() {
        return new ItemStack(ModItems.RELIC_GUIDE_BOOK);
    }

    public static List<ItemStack> initialAllRelics() {
        return List.of(initialPickaxe(), initialBone(), initialGuideBook());
    }

    public static List<ItemStack> initialBoneArmor() {
        return armorSet(0);
    }

    private static List<ItemStack> armorSet(int tier) {
        String[] slots = {"helmet", "chestplate", "leggings", "boots"};
        ArrayList<ItemStack> result = new ArrayList<>();
        for (String slot : slots) {
            String kind = "bone_" + slot;
            ItemStack stack = newRelic(kind, tier);
            NbtCompound data = stack.getNbt().getCompound(NBT);
            data.putInt("efficiency", 1);
            data.putInt("fortune", 1);
            data.putInt("fire", 1);
            data.putInt("looting", 0);
            data.putInt("damage", 0);
            data.putInt("armor", 10);
            refreshStack(stack);
            result.add(stack);
        }
        return result;
    }

    private record Located(ItemStack stack, int inventorySlot) {
    }
}
