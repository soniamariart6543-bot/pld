package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/**
 * 战利品骨头技能「骨火」（v6.2）：每攻击命中 3 次触发一次，
 * 对当前命中目标 + 附近最近的至多 3 只怪物造成 8 点范围魔法伤害，并播放火焰粒子。
 * 全部服务端权威；技能自身的魔法伤害不计入命中计数，避免无限触发。
 */
public final class BoneSkillHandler {
    public static final int HITS_PER_CAST = 3;
    public static final double SKILL_RADIUS = 6.0;
    public static final float BASE_SKILL_DAMAGE = 8.0f;
    public static final float DAMAGE_PER_BONE_LEVEL = 1.0f;
    public static final float MAX_SKILL_DAMAGE = 20.0f;
    private static final int MAX_TARGETS = 3;
    private static final Map<ServerPlayerEntity, Integer> HIT_COUNTS = new WeakHashMap<>();
    /** 技能施放中重入保护：技能自身造成的伤害不再进入命中计数（防无限递归）。 */
    private static boolean castingSkill;

    private BoneSkillHandler() {
    }

    public static void initialize() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((target, source, amount) -> {
            if (amount <= 0) {
                return true;
            }
            if (!(source.getAttacker() instanceof ServerPlayerEntity player)) {
                return true;
            }
            if (target == player || target.isRemoved()) {
                return true;
            }
            // 技能自身的魔法伤害不计入命中，防止触发循环（indirectMagic 为 INDIRECT_MAGIC 类型）
            if (castingSkill || source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC)) {
                return true;
            }
            ItemStack stack = player.getMainHandStack();
            if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
                return true;
            }
            int hits = HIT_COUNTS.merge(player, 1, Integer::sum);
            if (hits >= HITS_PER_CAST) {
                HIT_COUNTS.put(player, 0);
                trigger(player, target);
            }
            return true;
        });
    }

    /** 触发骨火：选取最近至多 3 只怪物（无其他怪物时打当前目标），造成 8 点魔法伤害并播放火焰粒子。 */
    private static void trigger(ServerPlayerEntity player, LivingEntity hitTarget) {
        ServerWorld world = player.getServerWorld();
        List<LivingEntity> candidates = new ArrayList<>();
        if (hitTarget instanceof HostileEntity) {
            candidates.add(hitTarget);
        }
        var box = hitTarget.getBoundingBox().expand(SKILL_RADIUS);
        for (Entity entity : world.getEntitiesByClass(HostileEntity.class, box, (HostileEntity e) -> e != hitTarget && e.isAlive())) {
            candidates.add((LivingEntity) entity);
        }
        if (candidates.isEmpty()) {
            // 附近没有怪物：只打当前命中目标
            candidates.add(hitTarget);
        }
        candidates.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(hitTarget)));
        int count = Math.min(MAX_TARGETS, candidates.size());
        float skillDamage = currentSkillDamage(player);
        DamageSource source = player.getDamageSources().indirectMagic(player, player);
        castingSkill = true;
        try {
            for (int i = 0; i < count; i++) {
                LivingEntity target = candidates.get(i);
                target.damage(source, skillDamage);
                world.spawnParticles(ParticleTypes.FLAME,
                        target.getX(), target.getY() + target.getHeight() / 2, target.getZ(),
                        24, 0.5, 0.4, 0.5, 0.05);
            }
        } finally {
            castingSkill = false;
        }
    }

    /** 骨火伤害成长：基础 8 点 + 骨头伤害等级（攻击力-9）每级 +1，上限 20 点。 */
    private static float currentSkillDamage(ServerPlayerEntity player) {
        ItemStack stack = player.getMainHandStack();
        int damageLevel = RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)
                ? RelicService.value(stack, "damage") : 0;
        return Math.min(BASE_SKILL_DAMAGE + damageLevel * DAMAGE_PER_BONE_LEVEL, MAX_SKILL_DAMAGE);
    }
}
