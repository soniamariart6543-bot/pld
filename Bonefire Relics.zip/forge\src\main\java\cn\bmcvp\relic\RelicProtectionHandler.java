package cn.bmcvp.relic;

import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 防丢弃 / 防销毁（v6.3.1，Forge）：
 * - ItemTossEvent：玩家一切主动丢出遗物（Q 键 / 背包丢出 / 死亡掉落）均被拦截；
 * - ExplosionEvent.Detonate：把爆炸波及的遗物物品实体从影响列表移除；
 * - 遗物物品全部 fireResistant（火焰 / 岩浆不烧毁）；虚空丢弃与创造模式物品栏删除不受影响。
 */
public final class RelicProtectionHandler {
    private RelicProtectionHandler() {
    }

    @SubscribeEvent
    public static void onItemToss(ItemTossEvent event) {
        if (!RelicService.isAnyRelic(event.getEntity().getItem())) {
            return;
        }
        event.setCanceled(true);
        // 关键：Forge 触发该事件前已把物品从背包移除（ServerPlayer.drop 先 removeFromSelected 再抛事件），
        // 仅取消会导致物品直接消失；必须把物品放回背包。
        Player player = event.getPlayer();
        ItemStack stack = event.getEntity().getItem();
        if (!stack.isEmpty()) {
            player.getInventory().add(stack);
            // 客户端会先本地执行丢弃（生成掉落物实体并从快捷栏移除物品），服务端拦截后
            // 若不立即同步，客户端视图会长时间不同步（需打开容器等操作才刷新）。
            // 这里立即广播物品栏状态，让物品马上"弹回"正确位置。
            player.getInventory().setChanged();
            if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                serverPlayer.inventoryMenu.broadcastChanges();
            }
        }
    }

    @SubscribeEvent
    public static void onExplosionDetonate(ExplosionEvent.Detonate event) {
        event.getAffectedEntities().removeIf(entity ->
                entity instanceof ItemEntity itemEntity && RelicService.isAnyRelic(itemEntity.getItem()));
    }
}
