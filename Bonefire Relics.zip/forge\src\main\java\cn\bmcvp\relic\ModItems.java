package cn.bmcvp.relic;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * 遗物 mod 全部物品注册（Forge 1.20.1）。
 * 镐子材料共 7 级（tier 0..6）；防具仅保留骨甲一线，材质 3 阶（骨 → 钻石骨甲 → 下界合金骨甲）。
 */
public final class ModItems {
    public static final DeferredRegister<Item> REGISTER =
            DeferredRegister.create(ForgeRegistries.ITEMS, BmcvpRelicUpgradesMod.MODID);

    // ---- 自定义工具材质：高级下界合金四级 ----
    private static final Tier NETHERITE_IRON = toolMaterial(4, 2400, 10.0f, 5.0f, 15, Items.NETHERITE_INGOT);
    private static final Tier NETHERITE_GOLD = toolMaterial(4, 2600, 11.0f, 5.5f, 18, Items.NETHERITE_INGOT);
    private static final Tier NETHERITE_EMERALD = toolMaterial(5, 3000, 12.0f, 6.0f, 20, Items.NETHERITE_INGOT);
    private static final Tier NETHERITE_DIAMOND = toolMaterial(5, 3600, 13.0f, 7.0f, 22, Items.NETHERITE_INGOT);

    // getLevel() 为 Tier 接口的过时抽象方法（1.20.1 官方映射 @Deprecated），必须实现，故抑制弃用警告
    @SuppressWarnings("deprecation")
    private static Tier toolMaterial(int miningLevel, int durability, float speed, float attack, int enchantability, Item repairItem) {
        return new Tier() {
            @Override public int getUses() { return durability; }
            @Override public float getSpeed() { return speed; }
            @Override public float getAttackDamageBonus() { return attack; }
            @Override public int getLevel() { return miningLevel; }
            @Override public int getEnchantmentValue() { return enchantability; }
            @Override public Ingredient getRepairIngredient() { return Ingredient.of(repairItem); }
        };
    }

    // ---- 初始骨甲材质：防御对标锁链铁甲，耐久同铁甲 ----
    private static final ArmorMaterial BONE_ARMOR = new ArmorMaterial() {
        @Override public int getDurabilityForType(ArmorItem.Type type) {
            return switch (type) {
                case HELMET -> 165;
                case CHESTPLATE -> 240;
                case LEGGINGS -> 225;
                case BOOTS -> 195;
            };
        }
        @Override public int getDefenseForType(ArmorItem.Type type) {
            return switch (type) {
                case HELMET -> 2;
                case CHESTPLATE -> 6;
                case LEGGINGS -> 5;
                case BOOTS -> 2;
            };
        }
        @Override public int getEnchantmentValue() { return 25; }
        @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_GENERIC; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.BONE); }
        @Override public String getName() { return "iron"; }
        @Override public float getToughness() { return 0.0f; }
        @Override public float getKnockbackResistance() { return 0.0f; }
    };

    // ---- 战利品骨头 ----
    public static final RegistryObject<Item> RELIC_BONE = REGISTER.register("relic_bone", RelicBoneItem::new);

    // ---- 教程书：骨与火 ----
    public static final RegistryObject<Item> RELIC_GUIDE_BOOK = REGISTER.register("relic_guide_book", GuideBookItem::new);

    // ---- 镐：原生三级 ----
    public static final RegistryObject<Item> RELIC_IRON_PICKAXE = REGISTER.register("relic_iron_pickaxe", () -> pickaxe(Tiers.IRON, false));
    public static final RegistryObject<Item> RELIC_DIAMOND_PICKAXE = REGISTER.register("relic_diamond_pickaxe", () -> pickaxe(Tiers.DIAMOND, false));
    public static final RegistryObject<Item> RELIC_NETHERITE_PICKAXE = REGISTER.register("relic_netherite_pickaxe", () -> pickaxe(Tiers.NETHERITE, true));

    // ---- 镐：高级下界合金四级 ----
    public static final RegistryObject<Item> RELIC_NETHERITE_IRON_PICKAXE = REGISTER.register("relic_netherite_iron_pickaxe", () -> pickaxe(NETHERITE_IRON, true));
    public static final RegistryObject<Item> RELIC_NETHERITE_GOLD_PICKAXE = REGISTER.register("relic_netherite_gold_pickaxe", () -> pickaxe(NETHERITE_GOLD, true));
    public static final RegistryObject<Item> RELIC_NETHERITE_EMERALD_PICKAXE = REGISTER.register("relic_netherite_emerald_pickaxe", () -> pickaxe(NETHERITE_EMERALD, true));
    public static final RegistryObject<Item> RELIC_NETHERITE_DIAMOND_PICKAXE = REGISTER.register("relic_netherite_diamond_pickaxe", () -> pickaxe(NETHERITE_DIAMOND, true));

    // ---- 骨甲：tier 0（骨）----
    public static final RegistryObject<Item> RELIC_BONE_HELMET = REGISTER.register("relic_bone_helmet", () -> boneArmor(BONE_ARMOR, ArmorItem.Type.HELMET));
    public static final RegistryObject<Item> RELIC_BONE_CHESTPLATE = REGISTER.register("relic_bone_chestplate", () -> boneArmor(BONE_ARMOR, ArmorItem.Type.CHESTPLATE));
    public static final RegistryObject<Item> RELIC_BONE_LEGGINGS = REGISTER.register("relic_bone_leggings", () -> boneArmor(BONE_ARMOR, ArmorItem.Type.LEGGINGS));
    public static final RegistryObject<Item> RELIC_BONE_BOOTS = REGISTER.register("relic_bone_boots", () -> boneArmor(BONE_ARMOR, ArmorItem.Type.BOOTS));

    // ---- 骨甲：tier 1（钻石骨甲）----
    public static final RegistryObject<Item> RELIC_BONE_DIAMOND_HELMET = REGISTER.register("relic_bone_diamond_helmet", () -> boneArmor(ArmorMaterials.DIAMOND, ArmorItem.Type.HELMET));
    public static final RegistryObject<Item> RELIC_BONE_DIAMOND_CHESTPLATE = REGISTER.register("relic_bone_diamond_chestplate", () -> boneArmor(ArmorMaterials.DIAMOND, ArmorItem.Type.CHESTPLATE));
    public static final RegistryObject<Item> RELIC_BONE_DIAMOND_LEGGINGS = REGISTER.register("relic_bone_diamond_leggings", () -> boneArmor(ArmorMaterials.DIAMOND, ArmorItem.Type.LEGGINGS));
    public static final RegistryObject<Item> RELIC_BONE_DIAMOND_BOOTS = REGISTER.register("relic_bone_diamond_boots", () -> boneArmor(ArmorMaterials.DIAMOND, ArmorItem.Type.BOOTS));

    // ---- 骨甲：tier 2（下界合金骨甲）----
    public static final RegistryObject<Item> RELIC_BONE_NETHERITE_HELMET = REGISTER.register("relic_bone_netherite_helmet", () -> boneArmor(ArmorMaterials.NETHERITE, ArmorItem.Type.HELMET));
    public static final RegistryObject<Item> RELIC_BONE_NETHERITE_CHESTPLATE = REGISTER.register("relic_bone_netherite_chestplate", () -> boneArmor(ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE));
    public static final RegistryObject<Item> RELIC_BONE_NETHERITE_LEGGINGS = REGISTER.register("relic_bone_netherite_leggings", () -> boneArmor(ArmorMaterials.NETHERITE, ArmorItem.Type.LEGGINGS));
    public static final RegistryObject<Item> RELIC_BONE_NETHERITE_BOOTS = REGISTER.register("relic_bone_netherite_boots", () -> boneArmor(ArmorMaterials.NETHERITE, ArmorItem.Type.BOOTS));

    private ModItems() {
    }

    private static Item pickaxe(Tier material, boolean fireproof) {
        // 遗物一律防火（配合防销毁机制）
        Item.Properties properties = new Item.Properties().fireResistant();
        return new PickaxeItem(material, 1, -2.8f, properties);
    }

    private static Item boneArmor(ArmorMaterial material, ArmorItem.Type type) {
        return new RelicBoneArmorItem(material, type, new Item.Properties().fireResistant());
    }
}
