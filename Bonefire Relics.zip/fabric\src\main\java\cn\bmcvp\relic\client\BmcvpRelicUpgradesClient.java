package cn.bmcvp.relic.client;

import cn.bmcvp.relic.BmcvpRelicUpgrades;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class BmcvpRelicUpgradesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(BmcvpRelicUpgrades.RESULT, (client, handler, buf, response) -> {
            String message = buf.readString(BmcvpRelicUpgrades.PACKET_STRING_MAX_LENGTH);
            client.execute(() -> RelicUpgradeScreen.receiveServerResult(message));
        });
    }
}
