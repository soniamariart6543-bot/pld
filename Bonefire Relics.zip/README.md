# Bonefire Relics（骨与火 · 遗物成长）

一个以「遗物」为核心的成长向 Minecraft 1.20.1 模组：开局发放三件遗物，通过**服务器权威**升级系统让它们陪你一起变强。

支持 **Fabric** 与 **Forge** 双加载器，同一份玩法逻辑，两种实现（各自独立构建）。

> **模组显示名**：Bonefire Relics ｜ **版本**：6.3.3 ｜ **Minecraft**：1.20.1 ｜ **Java**：17

---

## 三件遗物

- **无尽铁镐**（无尽铁镐 / 7 级材质路线）
  - 效率 / 时运升级
  - 技能·补给：每挖掘 150 个方块，获得 5 秒「补给」（每秒恢复饥饿值与饱食度）
- **战利品骨头**（主手武器）
  - 伤害最高 +50，火焰附加 / 抢夺 / 吸血升级
  - 技能·骨火：每命中 3 次，对最近至多 3 只怪物造成火焰魔法伤害（基础 8，随攻击力成长至 20）
  - 秒杀：火焰附加 II 的骨头攻击时 1.2% 概率将本次伤害提升至 999
- **遗物骨甲**（需先进入地狱解锁）
  - 保护 / 韧性 / 荆棘 / 保护家族（火焰·爆炸·弹射物三选一）
  - 护甲超限转化：穿戴 ≥2 件骨甲且全身护甲超 40 点后，每 1 点 = 0.5% 全面减伤 + 1% 最大生命
  - 技能·骨甲护体：单次受击 ≥80% 或 20 秒内累计 ≥200% 最大生命时获得抗性 + 生命恢复 5 秒
  - 铸体（材质）升级：每次材质升级当前部位护甲值 +5（上限 50）；钻石铸体上限 30、合金铸体上限 50

## 特色

- **服务器权威校验**：升级、发放全部由服务端判定，防作弊
- **创造模式**：升级免费，升级界面一键发放各类遗物
- **遗物防丢失**：Q 键无法丢出遗物，遗物免疫火焰 / 岩浆 / 爆炸（虚空除外）
- **教程书「骨与火」**：开局自动发放，右键查看全部玩法
- **Fabric 与 Forge 双加载器**：同一玩法，独立实现

## 目录结构

```
Bonefire Relics/
├── fabric/   # Fabric 版（yarn 映射，Fabric Loom）
├── forge/    # Forge 版（官方映射，ForgeGradle）
├── LICENSE   # MIT 许可证
├── CHANGELOG.md
└── README.md
```

## 构建

需要 **JDK 17**（两项目均使用 Gradle 8.8 与 ForgeGradle 6 / Fabric Loom 1.6）。

```bash
# Fabric 版
cd fabric
gradle build --no-daemon
# 产物：build/libs/bmcvp_relic_upgrades-6.3.3.jar（remap 后）

# Forge 版
cd forge
gradle build --no-daemon
# 产物：build/libs/bmcvp_relic_upgrades_forge-6.3.3.jar（reobf 后）
```

## 版本兼容与说明

- Minecraft **1.20.1**，Java **17**
- Fabric 版依赖 **Fabric API 0.92.2+1.20.1**（见 `fabric/gradle.properties`）
- Forge 版依赖 **Forge 47.x**（47.3.22+ 编译，兼容 47.4.x 运行）
- **modId 固定为 `bmcvp_relic_upgrades`**（Fabric 与 Forge 二选一安装，勿同时装载），NBT 键 `bmcvp` 亦为存档兼容保留——请勿更改，否则会破坏旧存档与注册表
- 服务端与客户端需同时安装

## 开源说明

- 许可证：**MIT**（见根目录 `LICENSE`，两个子项目的 `src/main/resources/LICENSE` 同款）
- 项目名与目录以 **Bonefire Relics** 命名；Java 包名（`cn.bmcvp.relic`）与 modId 出于存档兼容保留
- 历史改动见 `CHANGELOG.md`

## 管理员命令

```
/relic grant <all|pickaxe|bone|bone_armor>
```
