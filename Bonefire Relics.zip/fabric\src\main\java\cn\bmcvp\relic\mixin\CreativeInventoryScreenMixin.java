package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.client.RelicUpgradeScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemGroup;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 创造背包（CreativeInventoryScreen）注入「遗物」按钮。
 * 仅在「背包」标签页显示；切到创造物品库/搜索等标签时隐藏按钮，避免遮挡物品格影响拿取。
 * 按钮位置：背包物品栏左上角上方 (x+9, y+36)。
 */
@Mixin(CreativeInventoryScreen.class)
public abstract class CreativeInventoryScreenMixin {
    @Shadow
    private static ItemGroup selectedTab;

    @Unique
    private ButtonWidget bmcvp$relicButton;

    @Inject(method = "init", at = @At("TAIL"))
    private void bmcvp$addRelicButton(CallbackInfo ci) {
        CreativeInventoryScreen self = (CreativeInventoryScreen) (Object) this;
        HandledScreenAccessor layout = (HandledScreenAccessor) (Object) this;
        ScreenInvoker screen = (ScreenInvoker) (Object) this;
        this.bmcvp$relicButton = ButtonWidget.builder(Text.literal("遗物"),
                        b -> MinecraftClient.getInstance().setScreen(new RelicUpgradeScreen(self)))
                .dimensions(layout.bmcvp$getX() + 9, layout.bmcvp$getY() + 36, 39, 14)
                .build();
        screen.bmcvp$addDrawableChild(this.bmcvp$relicButton);
    }

    // 每帧：仅「背包」标签显示按钮；跟随面板 x/y 保持贴位
    @Inject(method = "render", at = @At("HEAD"))
    private void bmcvp$updateRelicButton(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.bmcvp$relicButton == null) {
            return;
        }
        boolean show = selectedTab != null && selectedTab.getType() == ItemGroup.Type.INVENTORY;
        this.bmcvp$relicButton.visible = show;
        this.bmcvp$relicButton.active = show;
        if (show) {
            HandledScreenAccessor layout = (HandledScreenAccessor) (Object) this;
            this.bmcvp$relicButton.setPosition(layout.bmcvp$getX() + 9, layout.bmcvp$getY() + 36);
        }
    }
}
