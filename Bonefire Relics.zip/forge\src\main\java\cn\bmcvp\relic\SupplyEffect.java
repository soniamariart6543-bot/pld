package cn.bmcvp.relic;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;

/**
 * 自定义状态效果「补给」（v6.3，Forge）：持续期间每秒恢复 1 点饥饿值 + 1 点饱食度。
 */
public class SupplyEffect extends MobEffect {
    public SupplyEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFFAA00);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0; // 每秒一次
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!(entity instanceof Player player)) {
            return;
        }
        FoodData food = player.getFoodData();
        if (food.getFoodLevel() < 20) {
            food.setFoodLevel(food.getFoodLevel() + 1);
        }
        food.setSaturation(Math.min(food.getSaturationLevel() + 1.0f, food.getFoodLevel()));
    }
}
