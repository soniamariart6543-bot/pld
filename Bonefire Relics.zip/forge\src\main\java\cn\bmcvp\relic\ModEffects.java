package cn.bmcvp.relic;

import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 自定义状态效果注册（v6.3，Forge）。 */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> REGISTER =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, BmcvpRelicUpgradesMod.MODID);

    public static final RegistryObject<MobEffect> SUPPLY = REGISTER.register("supply", SupplyEffect::new);

    private ModEffects() {
    }
}
