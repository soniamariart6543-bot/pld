package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.ArmorOvercapHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 伤害管线末端注入护甲超限全面减伤层：最终伤害 ×= (1 - R)。
 *
 * <p>注入点 modifyAppliedDamage（Yarn 1.20.1 已通过 tiny 映射确认）：此时原版护甲（CombatRules）、
 * 保护附魔（EPF）与抗性提升效果均已结算，对所有伤害类型统一生效（虚空/饥饿/kill 除外，与原版保护一致）。
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityHurtMixin {
    @Inject(method = "modifyAppliedDamage", at = @At("RETURN"), cancellable = true)
    private void bmcvp$overcapReduction(DamageSource source, float amount, CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof ServerPlayerEntity player)) {
            return;
        }
        float result = cir.getReturnValueF();
        float reduction = ArmorOvercapHandler.reductionOf(player);
        if (reduction > 0.0F) {
            result = result * (1.0F - reduction);
            cir.setReturnValue(result);
        }
        // 骨甲护体：以最终伤害触发（服务端玩家）
        cn.bmcvp.relic.ArmorSkillHandler.onPlayerDamaged(player, result);
    }
}
