package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 骨甲技能「骨甲护体」（v6.3）：穿戴 ≥1 件遗物骨甲时，
 * 单次受击 ≥80% 最大生命，或 20 秒窗口内累计受击 ≥200% 最大生命 →
 * 获得 抗性提升 + 生命恢复，持续 5 秒。
 * 由 LivingEntityHurtMixin 在最终伤害后调用；只施加效果、不造成伤害，无递归风险。
 */
public final class ArmorSkillHandler {
    public static final float SINGLE_HIT_PERCENT = 0.8f;
    public static final float CUMULATIVE_PERCENT = 2.0f;
    public static final int RESET_TICKS = 400;   // 20 秒无受击则清零
    public static final int BUFF_TICKS = 100;    // 5 秒

    private static final Map<ServerPlayerEntity, Accum> DATA = new WeakHashMap<>();

    private record Accum(float damage, long lastDamageTick) {
    }

    private ArmorSkillHandler() {
    }

    public static void initialize() {
        // 定期清理过期累积（20 秒无受击）与离线玩家，防泄漏
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long now = server.getTicks();
            DATA.entrySet().removeIf(entry -> {
                ServerPlayerEntity player = entry.getKey();
                return player == null || player.isRemoved()
                        || now - entry.getValue().lastDamageTick() > RESET_TICKS;
            });
        });
    }

    /** 由 LivingEntityHurtMixin 在护甲/附魔/超限减伤结算后调用（服务端玩家，最终伤害）。 */
    public static void onPlayerDamaged(ServerPlayerEntity player, float amount) {
        if (amount <= 0) {
            return;
        }
        if (equippedBoneArmor(player) == 0) {
            DATA.remove(player);
            return;
        }
        float maxHp = player.getMaxHealth();
        Accum acc = DATA.get(player);
        float cumulative = (acc == null ? 0f : acc.damage()) + amount;
        DATA.put(player, new Accum(cumulative, player.getServer().getTicks()));
        if (amount >= maxHp * SINGLE_HIT_PERCENT || cumulative >= maxHp * CUMULATIVE_PERCENT) {
            DATA.remove(player);
            grantBuff(player);
        }
    }

    private static void grantBuff(ServerPlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, BUFF_TICKS, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, BUFF_TICKS, 0));
    }

    public static int equippedBoneArmor(ServerPlayerEntity player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().armor) {
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                count++;
            }
        }
        return count;
    }
}
