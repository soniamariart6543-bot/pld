package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 防销毁（v6.3.1）：遗物物品实体免疫所有伤害来源（火焰 / 岩浆 / 爆炸等）。
 * 虚空（掉落出世界直接移除，不走 damage）与创造模式物品栏删除不受影响。
 */
@Mixin(ItemEntity.class)
public abstract class ItemEntityProtectionMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void bmcvp$protectRelic(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (RelicService.isAnyRelic(self.getStack())) {
            cir.setReturnValue(false);
        }
    }
}
