package cn.bmcvp.relic;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerEntity;

/**
 * 自定义状态效果「补给」（v6.3）：持续期间每秒恢复 1 点饥饿值 + 1 点饱食度。
 */
public class SupplyEffect extends StatusEffect {
    public SupplyEffect() {
        super(StatusEffectCategory.BENEFICIAL, 0xFFAA00);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return duration % 20 == 0; // 每秒一次
    }

    @Override
    public void applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (!(entity instanceof PlayerEntity player)) {
            return;
        }
        HungerManager hunger = player.getHungerManager();
        if (hunger.getFoodLevel() < 20) {
            hunger.setFoodLevel(hunger.getFoodLevel() + 1);
        }
        float saturation = Math.min(hunger.getSaturationLevel() + 1.0f, hunger.getFoodLevel());
        hunger.setSaturationLevel(saturation);
    }
}
