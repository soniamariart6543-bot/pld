# Bonefire Relics — Changelog

> 版本路线：6.3.0 → 6.3.1 → 6.3.2 → 6.3.3 ｜ Fabric + Forge 双加载器

---

## 6.3.3（最新）

### 新功能

- **骨甲材质升级 +5 护甲值**：每次材料升级（骨 → 钻石骨甲 → 下界合金骨甲）时，当前升级部位护甲值 +5，计入护甲值升级属性，上限仍为 50 点；升级界面与教程书「骨与火」同步说明
- **骨头秒杀效果**：火焰附加 II 的战利品骨头攻击时，1.2% 概率触发，本次攻击伤害提升至 999（秒杀），触发时目标位置播放火焰粒子；物品说明与教程书同步提示
- **跑马灯 UI（MarqueeTextWidget）**：升级界面长文字超出宽度时缓慢左滚（27px/s，无缝循环），悬停显示完整 Tooltip；状态消息、护甲状态条、卡片属性行均改为完整显示

### 修复与优化

- **修复 Forge 版在 Forge 47.4.10 环境下 Mod 加载失败**（模组构造器兼容性问题），恢复稳定的加载方式，兼容 Forge 47.x
- **修复 Q 键丢弃遗物后客户端不同步**（物品"很久才回来"、需开容器刷新）：Fabric 客户端源头拦截丢弃，Forge 拦截后立即同步物品栏
- **修复秒杀事件顺序**（Forge：吸血可能读取原始伤害）、**秒杀限定非玩家目标**（防 PVP 滥用）
- **修复升级界面「遗物升级」首页状态文字与按钮重叠**（创造/生存模式）
- **代码清理**：移除未使用的导入与死代码，消除编译期弃用警告，两端构建无警告

---

## 6.3.2

- 新增遗物防丢弃/防销毁：Q 键无法丢出遗物；遗物免疫火焰/岩浆/爆炸（虚空除外）；箱子存取与背包丢出不受影响
- 全部遗物物品防火

## 6.3.0

- 新增骨甲技能「骨甲护体」：单次受击≥80%最大生命或20秒内累计≥200%时，获得抗性+生命恢复5秒
- 新增镐子技能「补给」：每挖掘150个方块获得「补给」5秒（每秒恢复1饥饿值+1饱食度）
- 新增教程书「骨与火」：开局发放，右键查看完整玩法说明
- 新增骨甲镀层机制：基础护甲上限20，钻石镀层30，合金镀层50
- 骨火技能随骨头攻击力成长（基础8，上限20）
- 修复骨火技能无限递归导致的服务器崩溃
- 修复进入存档/复活后护甲超限血量加成丢失
- 修复创造背包按钮遮挡物品拿取；升级不再刷聊天消息

---

## English

### 6.3.3 (latest)

**New features**

- **Bone armor material upgrades now grant +5 armor value** to the upgraded piece (bone → diamond → netherite); cap remains 50.
- **Instant-kill chance for the Bone**: with Fire Aspect II, each hit has a 1.2% chance to boost the attack to 999 damage.
- **Marquee text UI**: long texts scroll smoothly (27 px/s, seamless loop) with full tooltip on hover.

**Fixes & polish**

- Fixed Forge loading failure on Forge 47.4.10 (constructor compatibility).
- Fixed client desync after dropping relics with Q (Fabric: client-side intercept; Forge: immediate inventory sync).
- Fixed instant-kill event ordering; instant-kill now only affects non-player targets.
- Fixed overlapping status text/buttons on the upgrade screen.
- Removed unused imports and dead code; both builds are warning-free.

### 6.3.2

- Relics can no longer be dropped with Q; immune to fire/lava/explosions (void excluded).
- All relic items are fireproof.

### 6.3.0

- Bone armor skill "Bone Ward": taking ≥80% max health in one hit, or ≥200% cumulative within 20s, grants Resistance + Regeneration for 5s.
- Pickaxe skill "Supply": every 150 blocks mined grants 5s of Supply (restores 1 hunger + 1 saturation per second).
- Guide book "Bone and Fire" granted at spawn.
- Bone armor casting system: base cap 20, diamond 30, netherite 50.
- Bonefire skill scales with bone damage (base 8, cap 20).
- Fixed infinite recursion crash of the Bonefire skill.
- Fixed max-health bonus loss on relog/respawn.
- Fixed creative inventory button overlap; no more chat spam on upgrade.
