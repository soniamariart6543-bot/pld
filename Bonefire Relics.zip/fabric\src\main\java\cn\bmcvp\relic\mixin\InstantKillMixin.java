package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import cn.bmcvp.relic.UpgradeDefinition;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 战利品骨头「秒杀」：火焰附加 II 的骨头攻击时 1.2% 概率将本次伤害提升至 999。
 * 在 LivingEntity.damage 入口（护甲结算前）修改伤害参数；骨火技能的魔法伤害不触发。
 */
@Mixin(LivingEntity.class)
public abstract class InstantKillMixin {
    private static final float INSTANT_KILL_CHANCE = 0.012f;
    private static final float INSTANT_KILL_DAMAGE = 999.0f;

    @ModifyVariable(method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z",
            at = @At("HEAD"), argsOnly = true)
    private float bmcvp$instantKill(float amount, DamageSource source) {
        if (amount <= 0.0F) {
            return amount;
        }
        if (!(source.getAttacker() instanceof ServerPlayerEntity player)) {
            return amount;
        }
        LivingEntity target = (LivingEntity) (Object) this;
        if (target == player || target instanceof PlayerEntity || !target.isAlive()) {
            return amount;
        }
        // 骨火技能自身的魔法伤害不触发秒杀
        if (source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC)) {
            return amount;
        }
        ItemStack stack = player.getMainHandStack();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            return amount;
        }
        if (RelicService.value(stack, "fire") != 2) {
            return amount;
        }
        if (player.getRandom().nextFloat() >= INSTANT_KILL_CHANCE) {
            return amount;
        }
        if (target.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(ParticleTypes.FLAME,
                    target.getX(), target.getY() + target.getHeight() / 2, target.getZ(),
                    40, 0.6, 0.5, 0.6, 0.1);
        }
        return INSTANT_KILL_DAMAGE;
    }
}
