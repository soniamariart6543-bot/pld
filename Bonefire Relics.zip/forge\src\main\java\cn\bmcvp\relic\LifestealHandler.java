package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 战利品骨头吸血（Forge 移植版，对齐 Fabric 行为）：
 * 主手持骨头造成伤害后按吸血等级比例回血，溢出转为临时血量（最多 50% 基础生命值），
 * 临时血持续 8 秒，再次触发刷新持续时间。
 */
public final class LifestealHandler {
    private static final int TEMP_HP_TICKS = 160; // 8 秒
    private static final Map<ServerPlayer, Long> ABSORPTION_EXPIRY = new WeakHashMap<>();

    private LifestealHandler() {
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target == player) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            return;
        }
        int level = RelicService.value(stack, "fortune");
        if (level > 0 && player.getServer() != null) {
            player.getServer().execute(() -> applyLifesteal(player, event.getAmount(), level));
        }
    }

    /** 临时血量到期清除。 */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        long now = event.getServer().getTickCount();
        ABSORPTION_EXPIRY.entrySet().removeIf(entry -> {
            if (entry.getValue() <= now) {
                ServerPlayer player = entry.getKey();
                if (player != null && !player.isRemoved()) {
                    player.setAbsorptionAmount(0.0f);
                }
                return true;
            }
            return false;
        });
    }

    private static void applyLifesteal(ServerPlayer player, float damage, int level) {
        float percent = RelicService.lifestealPercent(level);
        float lifesteal = damage * percent;
        if (lifesteal <= 0) {
            return;
        }
        float before = player.getHealth();
        player.heal(lifesteal);
        float healed = player.getHealth() - before;
        float overflow = lifesteal - healed;
        if (overflow > 0) {
            float maxAbsorption = player.getMaxHealth() * 0.5f;
            float newAbsorption = Math.min(player.getAbsorptionAmount() + overflow, maxAbsorption);
            player.setAbsorptionAmount(newAbsorption);
            ABSORPTION_EXPIRY.put(player, player.getServer().getTickCount() + (long) TEMP_HP_TICKS);
        }
    }
}
