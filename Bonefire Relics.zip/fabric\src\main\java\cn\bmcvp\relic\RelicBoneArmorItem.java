package cn.bmcvp.relic;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * 遗物骨甲：地狱装备，只有进入过下界的玩家才能装备。
 */
public class RelicBoneArmorItem extends ArmorItem {
    public static final String NETHER_UNLOCK_TAG = "bmcvp_relic_visited_nether";

    public RelicBoneArmorItem(ArmorMaterial material, Type type, Settings settings) {
        super(material, type, settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        if (!user.getCommandTags().contains(NETHER_UNLOCK_TAG)) {
            user.sendMessage(Text.literal("§c需要先进入地狱才能使用骨甲"), true);
            return TypedActionResult.fail(user.getStackInHand(hand));
        }
        return super.use(world, user, hand);
    }
}
