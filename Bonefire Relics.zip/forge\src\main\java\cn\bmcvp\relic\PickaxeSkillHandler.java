package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 镐子技能「补给」（v6.3，Forge）：主手持遗物镐每累计挖掘 150 个方块，
 * 获得「补给」效果 5 秒（每秒恢复 1 饥饿值 + 1 饱食度）。
 */
public final class PickaxeSkillHandler {
    public static final int BLOCKS_PER_SUPPLY = 150;
    public static final int SUPPLY_TICKS = 100;
    private static final Map<ServerPlayer, Integer> MINED = new WeakHashMap<>();

    private PickaxeSkillHandler() {
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer serverPlayer)) {
            return;
        }
        ItemStack stack = serverPlayer.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)) {
            return;
        }
        int mined = MINED.merge(serverPlayer, 1, Integer::sum);
        if (mined >= BLOCKS_PER_SUPPLY) {
            MINED.put(serverPlayer, 0);
            serverPlayer.addEffect(new MobEffectInstance(ModEffects.SUPPLY.get(), SUPPLY_TICKS, 0));
        }
    }
}
