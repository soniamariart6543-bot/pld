package cn.bmcvp.relic;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** 自定义状态效果注册（v6.3）。 */
public final class ModEffects {
    public static final StatusEffect SUPPLY = Registry.register(Registries.STATUS_EFFECT,
            new Identifier(BmcvpRelicUpgrades.MODID, "supply"), new SupplyEffect());

    private ModEffects() {
    }

    public static void initialize() {
        // 触发静态注册
    }
}
