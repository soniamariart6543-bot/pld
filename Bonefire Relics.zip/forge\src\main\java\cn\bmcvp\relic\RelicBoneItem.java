package cn.bmcvp.relic;

import net.minecraft.world.item.Item;

/** 战利品骨头物品：仅用于承载遗物 NBT，最大堆叠 1。 */
public class RelicBoneItem extends Item {
    public RelicBoneItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }
}
