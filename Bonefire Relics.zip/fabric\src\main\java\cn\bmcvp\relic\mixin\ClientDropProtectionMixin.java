package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 防丢弃（客户端层，v6.3.3 修复）：Q 键按下时原版客户端会先本地丢弃（生成掉落物实体、
 * 从快捷栏移除物品）再发 DROP 包；仅服务端拦截会导致客户端视图不同步（物品"很久才回来"、
 * 需打开容器才刷新）并残留幽灵掉落物。
 * 本 mixin 在客户端源头拦截 dropSelectedItem：主手为遗物时直接返回 false，
 * 不生成实体、不移除物品、也不发送 DROP 包（服务端 mixin 仍保留作双保险）。
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientDropProtectionMixin {
    @Inject(method = "dropSelectedItem", at = @At("HEAD"), cancellable = true)
    private void bmcvp$blockClientDrop(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
        if (RelicService.isAnyRelic(((ClientPlayerEntity) (Object) this).getMainHandStack())) {
            cir.setReturnValue(false);
        }
    }
}
