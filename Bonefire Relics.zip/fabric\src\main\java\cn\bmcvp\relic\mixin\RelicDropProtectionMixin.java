package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.RelicService;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 防丢弃（v6.3.1）：Q 键丢出（DROP_ITEM / DROP_ALL_ITEMS）时，
 * 若选中快捷栏为遗物则拦截。背包内丢出（THROW 动作）与箱子存取不受影响。
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class RelicDropProtectionMixin {
    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true)
    private void bmcvp$blockRelicDrop(PlayerActionC2SPacket packet, CallbackInfo ci) {
        PlayerActionC2SPacket.Action action = packet.getAction();
        if (action != PlayerActionC2SPacket.Action.DROP_ITEM
                && action != PlayerActionC2SPacket.Action.DROP_ALL_ITEMS) {
            return;
        }
        ServerPlayerEntity player = ((ServerPlayNetworkHandler) (Object) this).player;
        if (RelicService.isAnyRelic(player.getInventory().getMainHandStack())) {
            ci.cancel();
        }
    }
}
