package cn.bmcvp.relic.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/**
 * 跑马灯文字组件：解决 UI 文字显示不全的问题。
 *
 * <ul>
 *   <li>文字总宽 ≤ 组件宽度：静止居中显示；</li>
 *   <li>文字总宽 &gt; 组件宽度：以 25~30 像素/秒的速度缓慢向左滚动，首尾无缝衔接
 *       （绘制两份文本，间隔 GAP_PIXELS 后重新从右侧进入），无限循环；</li>
 *   <li>渲染全程严格裁剪（enableScissor/disableScissor），不影响父级 UI；</li>
 *   <li>鼠标悬停显示完整未截断文字的 Tooltip（原版半透明背景+描边样式）；</li>
 *   <li>滚动偏移基于实时帧率差（System.nanoTime）累计，速度与帧率无关。</li>
 * </ul>
 */
public class MarqueeTextWidget extends ClickableWidget {
    /** 滚动速度：25~30 像素/秒（取 27）。 */
    private static final float SCROLL_SPEED = 27.0f;
    /** 循环间隔（等效数个空格），保证首尾无缝衔接。 */
    private static final int GAP_PIXELS = 36;
    /** 当前滚动偏移（像素）。 */
    private float offset;
    /** 上次渲染时间（纳秒），用于按真实帧率差累计偏移。 */
    private long lastNanos = System.nanoTime();
    /** 文字颜色（ARGB）。 */
    private int color = 0xFFFFFFFF;
    /** 字体（ClickableWidget 不提供，自行获取）。 */
    private final TextRenderer font = MinecraftClient.getInstance().textRenderer;

    public MarqueeTextWidget(Text message, int x, int y, int width, int height) {
        super(x, y, width, height, message);
    }

    public void setColor(int color) {
        this.color = color;
    }

    @Override
    protected void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        // 帧率无关的时间差；跳变（切屏/恢复）时限制在 0.25 秒内，避免滚动瞬移
        float dt = Math.max(0.0f, Math.min((now - this.lastNanos) / 1_000_000_000.0f, 0.25f));
        this.lastNanos = now;

        TextRenderer font = this.font;
        Text message = this.getMessage();
        int textWidth = font.getWidth(message);
        int y = this.getY() + (this.getHeight() - font.fontHeight) / 2;

        // 严格裁剪区域
        context.enableScissor(this.getX(), this.getY(), this.getX() + this.getWidth(), this.getY() + this.getHeight());
        try {
            if (textWidth <= this.getWidth()) {
                // 短文字：静止居中
                int x = this.getX() + (this.getWidth() - textWidth) / 2;
                context.drawTextWithShadow(font, message, x, y, this.color);
            } else {
                // 长文字：缓慢左滚，画两份实现首尾无缝衔接
                float total = textWidth + GAP_PIXELS;
                this.offset = (this.offset + dt * SCROLL_SPEED) % total;
                int startX = this.getX() - (int) this.offset;
                context.drawTextWithShadow(font, message, startX, y, this.color);
                context.drawTextWithShadow(font, message, startX + (int) total, y, this.color);
            }
        } finally {
            context.disableScissor();
        }

        // 悬停显示完整 Tooltip（未截断的原始文字，原版样式）
        if (this.hovered) {
            context.drawTooltip(font, message, mouseX, mouseY);
        }
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= this.getX() && mouseY >= this.getY()
                && mouseX < this.getX() + this.getWidth() && mouseY < this.getY() + this.getHeight();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        // 纯展示组件，无需屏幕阅读叙述
    }
}
