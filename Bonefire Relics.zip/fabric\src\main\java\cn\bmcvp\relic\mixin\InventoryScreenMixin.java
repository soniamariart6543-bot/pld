package cn.bmcvp.relic.mixin;

import cn.bmcvp.relic.client.RelicUpgradeScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {
    @Unique
    private ButtonWidget bmcvp$relicButton;

    /** 按钮位置按模式区分：创造=人物右下角（模型锚点 x+51,y+75 的右下），生存=遗物6.0原位置(x+129,y+65)。 */
    @Unique
    private static boolean bmcvp$isCreative() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.player.getAbilities().creativeMode;
    }

    @Unique
    private static int bmcvp$buttonX() {
        return bmcvp$isCreative() ? 64 : 129;
    }

    @Unique
    private static int bmcvp$buttonY() {
        return bmcvp$isCreative() ? 68 : 65;
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void bmcvp$addRelicButton(CallbackInfo ci) {
        InventoryScreen self = (InventoryScreen) (Object) this;
        HandledScreenAccessor layout = (HandledScreenAccessor) (Object) this;
        ScreenInvoker screen = (ScreenInvoker) (Object) this;
        this.bmcvp$relicButton = ButtonWidget.builder(Text.literal("遗物"),
                        b -> MinecraftClient.getInstance().setScreen(new RelicUpgradeScreen(self)))
                .dimensions(layout.bmcvp$getX() + bmcvp$buttonX(), layout.bmcvp$getY() + bmcvp$buttonY(), 39, 14)
                .build();
        screen.bmcvp$addDrawableChild(this.bmcvp$relicButton);
    }

    // 每帧跟随背包面板 x/y（配方书展开/收起会改变 x），保持按钮始终贴在面板内固定位置
    @Inject(method = "render", at = @At("HEAD"))
    private void bmcvp$repositionRelicButton(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.bmcvp$relicButton != null) {
            HandledScreenAccessor layout = (HandledScreenAccessor) (Object) this;
            this.bmcvp$relicButton.setPosition(layout.bmcvp$getX() + bmcvp$buttonX(),
                    layout.bmcvp$getY() + bmcvp$buttonY());
        }
    }
}
