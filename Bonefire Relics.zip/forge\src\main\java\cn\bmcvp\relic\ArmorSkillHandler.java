package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 骨甲技能「骨甲护体」（v6.3，Forge）：穿戴 ≥1 件遗物骨甲时，
 * 单次受击 ≥80% 最大生命，或 20 秒窗口内累计受击 ≥200% 最大生命 →
 * 获得 抗性提升 + 生命恢复，持续 5 秒。
 * 通过 LivingDamageEvent（护甲结算后的最终伤害）触发；只施加效果、不造成伤害，无递归风险。
 */
public final class ArmorSkillHandler {
    public static final float SINGLE_HIT_PERCENT = 0.8f;
    public static final float CUMULATIVE_PERCENT = 2.0f;
    public static final int RESET_TICKS = 400;   // 20 秒无受击则清零
    public static final int BUFF_TICKS = 100;    // 5 秒

    private static final Map<ServerPlayer, Accum> DATA = new WeakHashMap<>();

    private record Accum(float damage, long lastDamageTick) {
    }

    private ArmorSkillHandler() {
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            onPlayerDamaged(player, event.getAmount());
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        long now = event.getServer().getTickCount();
        DATA.entrySet().removeIf(entry -> {
            ServerPlayer player = entry.getKey();
            return player == null || player.isRemoved()
                    || now - entry.getValue().lastDamageTick() > RESET_TICKS;
        });
    }

    /** 玩家受到最终伤害（护甲结算后）。 */
    public static void onPlayerDamaged(ServerPlayer player, float amount) {
        if (amount <= 0) {
            return;
        }
        if (equippedBoneArmor(player) == 0) {
            DATA.remove(player);
            return;
        }
        float maxHp = player.getMaxHealth();
        Accum acc = DATA.get(player);
        float cumulative = (acc == null ? 0f : acc.damage()) + amount;
        DATA.put(player, new Accum(cumulative, player.getServer().getTickCount()));
        if (amount >= maxHp * SINGLE_HIT_PERCENT || cumulative >= maxHp * CUMULATIVE_PERCENT) {
            DATA.remove(player);
            grantBuff(player);
        }
    }

    private static void grantBuff(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, BUFF_TICKS, 0));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, BUFF_TICKS, 0));
    }

    public static int equippedBoneArmor(ServerPlayer player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().armor) {
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                count++;
            }
        }
        return count;
    }
}
