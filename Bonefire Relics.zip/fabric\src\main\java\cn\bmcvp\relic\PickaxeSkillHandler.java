package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 镐子技能「补给」（v6.3）：主手持遗物镐每累计挖掘 150 个方块，
 * 获得「补给」效果 5 秒（每秒恢复 1 饥饿值 + 1 饱食度）。
 */
public final class PickaxeSkillHandler {
    public static final int BLOCKS_PER_SUPPLY = 150;
    public static final int SUPPLY_TICKS = 100;
    private static final Map<ServerPlayerEntity, Integer> MINED = new WeakHashMap<>();

    private PickaxeSkillHandler() {
    }

    public static void initialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) {
                return;
            }
            ItemStack stack = serverPlayer.getMainHandStack();
            if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.PICKAXE)) {
                return;
            }
            int mined = MINED.merge(serverPlayer, 1, Integer::sum);
            if (mined >= BLOCKS_PER_SUPPLY) {
                MINED.put(serverPlayer, 0);
                serverPlayer.addStatusEffect(new StatusEffectInstance(ModEffects.SUPPLY, SUPPLY_TICKS, 0));
            }
        });
    }
}
