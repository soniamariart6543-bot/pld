package cn.bmcvp.relic;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * 遗物骨甲：地狱装备，只有进入过下界的玩家才能装备。
 */
public class RelicBoneArmorItem extends ArmorItem {
    public static final String NETHER_UNLOCK_TAG = "bmcvp_relic_visited_nether";

    public RelicBoneArmorItem(ArmorMaterial material, ArmorItem.Type type, Properties properties) {
        super(material, type, properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!player.getTags().contains(NETHER_UNLOCK_TAG)) {
            player.displayClientMessage(Component.literal("§c需要先进入地狱才能使用骨甲"), true);
            return InteractionResultHolder.fail(player.getItemInHand(hand));
        }
        return super.use(level, player, hand);
    }
}
