package cn.bmcvp.relic.client;

import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** 教程书「骨与火」界面：多页使用说明。 */
public class GuideBookScreen extends Screen {
    private static final List<List<String>> PAGES = List.of(
            List.of("欢迎使用「骨与火」", "遗物成长系统使用指南", "", "本模组包含三大遗物：", "无尽铁镐 / 战利品骨头 / 遗物骨甲。", "打开背包，点击「遗物」按钮", "进入升级界面（创造背包同样有）。"),
            List.of("无尽铁镐", "7 级材质路线；效率最高 V、时运最高 X。", "技能·补给：每挖掘 150 个方块", "获得「补给」5 秒，", "每秒恢复 1 点饥饿值与饱食度。"),
            List.of("战利品骨头", "主手武器，伤害最高 +50；", "火焰附加、抢夺、吸血。", "技能·骨火：每命中 3 次，", "对最近至多 3 只怪物造成火焰魔法伤害", "（基础 8，随攻击力成长，上限 20）。", "火焰附加 II：攻击时 1.2% 概率秒杀（伤害 999）。"),
            List.of("遗物骨甲", "需先进入地狱才能穿戴。", "护甲超限转化：穿戴≥2件骨甲且", "全身护甲超 40 点后，每 1 点 =", "0.5% 全面减伤 + 1% 最大生命。", "技能·骨甲护体：单次受击≥80%最大生命", "或 20 秒内累计≥200% →", "抗性 + 生命恢复 5 秒。"),
            List.of("骨甲铸体（材质）", "基础骨甲护甲值上限 20 点；", "升级材质（铸体）解锁更高上限：", "钻石铸体 → 上限 30；", "合金铸体 → 上限 50。", "铸体即材质升级：钻石骨甲 / 下界合金骨甲。", "每次材质升级，该件骨甲护甲值 +5（上限 50）。"),
            List.of("创造模式与命令", "创造模式：升级不消耗材料与经验；", "升级界面首页可一键发放各遗物。", "管理员命令：", "/relic grant <all|pickaxe|bone|bone_armor>")
    );

    private int page;

    public GuideBookScreen() {
        super(Text.literal("骨与火"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 130;
        int top = this.height / 2 - 100;
        addDrawableChild(ButtonWidget.builder(Text.literal("上一页"), b -> {
            if (this.page > 0) {
                this.page--;
            }
        }).dimensions(left + 20, top + 165, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("下一页"), b -> {
            if (this.page < PAGES.size() - 1) {
                this.page++;
            }
        }).dimensions(left + 170, top + 165, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("关闭"), b -> this.close())
                .dimensions(left + 95, top + 165, 70, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        int left = this.width / 2 - 130;
        int top = this.height / 2 - 100;
        context.fill(left, top, left + 260, top + 200, -366993376);
        context.fill(left + 2, top + 2, left + 258, top + 22, -14268347);
        context.drawCenteredTextWithShadow(this.textRenderer, "骨与火 · 第 " + (this.page + 1) + "/" + PAGES.size() + " 页",
                this.width / 2, top + 7, -1);
        List<String> lines = PAGES.get(this.page);
        for (int i = 0; i < lines.size(); i++) {
            int color = i == 0 ? -1 : -5592406;
            context.drawCenteredTextWithShadow(this.textRenderer, lines.get(i), this.width / 2, top + 30 + i * 11, color);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
