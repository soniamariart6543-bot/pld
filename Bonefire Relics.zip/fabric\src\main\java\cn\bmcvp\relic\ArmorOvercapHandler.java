package cn.bmcvp.relic;

import java.lang.reflect.Field;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 护甲超限转化：服务端权威计算 C/A/E/R/H，刷新最大生命修饰符。
 *
 * <p>规则（v1.2）：穿戴 ≥minRelicArmorPieces 件遗物骨甲 且 全身护甲（总属性）超过 threshold 后，
 * 每超出 1 点 = drPercentPerPoint% 全面减伤 + healthPerPoint% 最大生命。
 */
public final class ArmorOvercapHandler {
    public static final UUID OVERCAP_HEALTH_UUID = UUID.fromString("11111210-0000-0000-0000-000000000001");
    private static final int REFRESH_INTERVAL_TICKS = 10;

    private static boolean initialized;
    private static boolean armorCapRaised;
    private static int tickCounter;

    private ArmorOvercapHandler() {
    }

    public static void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        ArmorOvercapConfig.load();
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (tickCounter % REFRESH_INTERVAL_TICKS != 0) {
                return;
            }
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                refreshPlayer(player);
            }
        });
        // 进服 / 复活即时刷新（避免进入存档或复活后血量加成丢失）
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                server.execute(() -> refreshPlayer(handler.player)));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> refreshPlayer(newPlayer));
    }

    /**
     * 抬高 generic.armor 属性上限（max 30 → 220），使高护甲不再被钳制。
     * 反射修改 RangedAttribute.maxValue；惰性执行（首次服务端 tick / 客户端界面渲染时），
     * 避免在注册期触发属性类初始化。失败时总属性口径的转化将受原版 30 点钳制影响。
     */
    public static void ensureArmorCapRaised() {
        if (armorCapRaised) {
            return;
        }
        armorCapRaised = true;
        try {
            EntityAttribute attribute = EntityAttributes.GENERIC_ARMOR;
            if (attribute instanceof ClampedEntityAttribute clamped) {
                for (Field field : ClampedEntityAttribute.class.getDeclaredFields()) {
                    if (field.getType() != double.class) {
                        continue;
                    }
                    field.setAccessible(true);
                    double value = field.getDouble(clamped);
                    if (value >= 29.0 && value <= 31.0) {
                        field.setDouble(clamped, 220.0);
                        return;
                    }
                }
            }
        } catch (Exception ignored) {
            // 上限抬升失败：不阻断游戏，总属性口径下护甲将受原版钳制
        }
    }

    public static boolean isActive(ServerPlayerEntity player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        return config.enabled && equippedRelicArmorCount(player) >= config.minRelicArmorPieces;
    }

    public static int equippedRelicArmorCount(ServerPlayerEntity player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().armor) {
            if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                count++;
            }
        }
        return count;
    }

    /** 全身护甲值 A：TOTAL_ATTRIBUTE=总护甲属性；RELIC_NBT=四件骨甲 bmcvp.armor 之和。 */
    public static int armorValue(ServerPlayerEntity player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        if (config.isRelicNbtSource()) {
            int sum = 0;
            for (ItemStack stack : player.getInventory().armor) {
                if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                    sum += RelicService.value(stack, "armor");
                }
            }
            return sum;
        }
        ensureArmorCapRaised();
        return (int) Math.floor(player.getAttributeValue(EntityAttributes.GENERIC_ARMOR));
    }

    /** 超限值 E = max(0, floor(A) - threshold)。 */
    public static int overcapValue(ServerPlayerEntity player) {
        if (!isActive(player)) {
            return 0;
        }
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        return Math.max(0, armorValue(player) - (int) config.threshold);
    }

    /** 全面减伤 R = min(E × drPercentPerPoint%, drCapPercent%)。 */
    public static float reductionOf(ServerPlayerEntity player) {
        if (!isActive(player)) {
            return 0.0f;
        }
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        double reduction = overcapValue(player) * config.drPercentPerPoint / 100.0;
        return (float) Math.min(reduction, config.drCapPercent / 100.0);
    }

    /**
     * 刷新最大生命修饰符。以「修饰符是否存在且数值正确」为准，而非缓存护甲值——
     * 进入存档 / 复活时原版会重建并重置玩家属性，可能清掉本修饰符；此处每次核对，
     * 缺失即补挂，保证血量加成在进服 / 复活后依然生效。
     */
    public static void refreshPlayer(ServerPlayerEntity player) {
        ArmorOvercapConfig config = ArmorOvercapConfig.get();
        boolean active = isActive(player);
        int armor = active ? armorValue(player) : 0;
        int overcap = active ? Math.max(0, armor - (int) config.threshold) : 0;
        EntityAttributeInstance health = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (health == null) {
            return;
        }
        if (overcap <= 0) {
            if (health.getModifier(OVERCAP_HEALTH_UUID) != null) {
                health.removeModifier(OVERCAP_HEALTH_UUID);
            }
            return;
        }
        double bonus = Math.min(overcap * config.healthPerPoint, config.healthCap);
        double amount;
        EntityAttributeModifier.Operation operation;
        if (config.isHpMode()) {
            amount = bonus;
            operation = EntityAttributeModifier.Operation.ADDITION;
        } else {
            amount = bonus / 100.0;
            operation = EntityAttributeModifier.Operation.MULTIPLY_TOTAL;
        }
        EntityAttributeModifier current = health.getModifier(OVERCAP_HEALTH_UUID);
        if (current != null && current.getValue() == amount && current.getOperation() == operation) {
            return; // 已存在且数值正确
        }
        health.removeModifier(OVERCAP_HEALTH_UUID);
        if (amount > 0) {
            health.addPersistentModifier(new EntityAttributeModifier(
                    OVERCAP_HEALTH_UUID, "bmcvp_armor_overcap_health", amount, operation));
        }
    }

    /** 升级成功后立即刷新（由 RelicService.tryUpgrade 成功分支调用）。 */
    public static void onUpgradeApplied(ServerPlayerEntity player) {
        refreshPlayer(player);
    }
}
