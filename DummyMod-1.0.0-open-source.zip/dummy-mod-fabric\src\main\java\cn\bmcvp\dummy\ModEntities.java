package cn.bmcvp.dummy;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** 训练木桩实体注册。 */
public final class ModEntities {
    public static final EntityType<TrainingDummyEntity> TRAINING_DUMMY = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(TrainingDummyMod.MODID, "training_dummy"),
            EntityType.Builder.<TrainingDummyEntity>create(TrainingDummyEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.9f, 1.9f).build("training_dummy"));

    private ModEntities() {
    }

    public static void initialize() {
        // 触发静态注册
    }
}
