package cn.bmcvp.dummy;

import java.lang.reflect.Field;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

/**
 * 训练木桩（Forge）：9999 最大生命，每秒自动回满；不移动、不攻击、不可被推动，用于测试伤害数值。
 * 生成指令：/dummy（权限 2，仅游戏内玩家可用）。
 *
 * <p>注意：1.20.1 原版 generic.max_health 属性钳制上限为 1024，
 * 必须先用反射抬高该钳制才能真正达到 9999 生命。</p>
 */
public class TrainingDummyEntity extends Mob {
    public static final double MAX_HEALTH = 9999.0;
    /** 自动回满间隔：20 tick = 1 秒。 */
    private static final int REGEN_INTERVAL_TICKS = 20;

    private static boolean maxHealthCapRaised;

    public TrainingDummyEntity(EntityType<? extends Mob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    /** Forge MOD 总线事件：注册木桩属性（在模组构造器中 addListener 挂载）。 */
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TRAINING_DUMMY.get(), createAttributes().build());
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ATTACK_DAMAGE, 0.0);
    }

    /** 抬高 generic.max_health 属性上限（1024 → 99999），使 9999 生命不被钳制。惰性执行、幂等。 */
    public static void ensureMaxHealthCapRaised() {
        if (maxHealthCapRaised) {
            return;
        }
        maxHealthCapRaised = true;
        try {
            if (Attributes.MAX_HEALTH instanceof RangedAttribute ranged) {
                for (Field field : RangedAttribute.class.getDeclaredFields()) {
                    if (field.getType() != double.class) {
                        continue;
                    }
                    field.setAccessible(true);
                    double value = field.getDouble(ranged);
                    if (value >= 1023.0 && value <= 1025.0) {
                        field.setDouble(ranged, 99999.0);
                        return;
                    }
                }
            }
        } catch (Exception ignored) {
            // 抬升失败时木桩最大生命受原版 1024 钳制，不影响游戏
        }
    }

    @Override
    protected void registerGoals() {
        // 无 AI：不移动、不攻击
    }

    @Override
    public boolean isPersistenceRequired() {
        return true; // 不会自然消失
    }

    @Override
    public boolean isPushable() {
        return false; // 不可被推动 / 击退免疫（属性也给了 1.0 抗性）
    }

    @Override
    public void tick() {
        super.tick();
        // 每秒自动回满
        if (!this.level().isClientSide && this.level().getGameTime() % REGEN_INTERVAL_TICKS == 0
                && this.getHealth() < this.getMaxHealth()) {
            this.setHealth(this.getMaxHealth());
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        float before = this.getHealth();
        boolean damaged = super.hurt(source, amount);
        if (damaged && source.getEntity() instanceof ServerPlayer player) {
            // 用实际扣血差值上报（兼容秒杀/骨裂等在伤害入口被改写的伤害）
            float actual = before - this.getHealth();
            player.displayClientMessage(Component.literal(String.format(
                    "§e[木桩] §c-%.1f §eHP（剩余 §a%.0f§e）", actual, this.getHealth())), true);
        }
        return damaged;
    }
}
