package cn.bmcvp.dummy;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * 训练木桩独立 mod（Fabric）：指令 /dummy（权限 2）在玩家面前 2 格生成
 * 9999 HP、每秒自动回满、无 AI、不可推动的训练木桩。
 */
public class TrainingDummyMod implements ModInitializer {
    public static final String MODID = "dummy_mod";

    @Override
    public void onInitialize() {
        ModEntities.initialize();
        FabricDefaultAttributeRegistry.register(ModEntities.TRAINING_DUMMY, TrainingDummyEntity.createAttributes());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("dummy")
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(context -> spawnDummy(context))));
    }

    /** 生成训练木桩：玩家面朝方向前 2 格，9999 HP 每秒自动回满。 */
    private static int spawnDummy(CommandContext<ServerCommandSource> context) {
        ServerPlayerEntity player;
        try {
            player = context.getSource().getPlayer();
        } catch (Exception error) {
            context.getSource().sendError(Text.literal("该命令只能由游戏内玩家执行。"));
            return 0;
        }
        TrainingDummyEntity.ensureMaxHealthCapRaised();
        TrainingDummyEntity dummy = new TrainingDummyEntity(ModEntities.TRAINING_DUMMY, player.getServerWorld());
        Vec3d look = player.getRotationVector();
        dummy.refreshPositionAndAngles(player.getX() + look.x * 2.0, player.getY() + 1.0,
                player.getZ() + look.z * 2.0, player.getYaw(), 0.0F);
        dummy.setHealth(dummy.getMaxHealth());
        player.getServerWorld().spawnEntity(dummy);
        context.getSource().sendFeedback(
                () -> Text.literal("已生成训练木桩（9999 HP，每秒自动回满；造成伤害会在动作栏显示数值）"), false);
        return 1;
    }
}
