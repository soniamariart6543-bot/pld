package cn.bmcvp.dummy.client;

import cn.bmcvp.dummy.TrainingDummyEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;

/**
 * 训练木桩渲染：渲染一个放大 2 倍的干草捆（干草块物品模型），作为靶子外观。
 */
public class TrainingDummyRenderer extends EntityRenderer<TrainingDummyEntity> {
    /** 占位贴图（木桩本体用干草捆物品模型渲染，此贴图仅用于满足抽象方法）。 */
    private static final Identifier TEXTURE = new Identifier("minecraft", "textures/block/hay_block_side.png");

    public TrainingDummyRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(TrainingDummyEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(TrainingDummyEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
        matrices.push();
        // 放大 2 倍并抬高，形成一个约 2 格高的靶子
        matrices.scale(2.0f, 2.0f, 2.0f);
        matrices.translate(0.0, 0.25, 0.0);
        ItemRenderer itemRenderer = MinecraftClient.getInstance().getItemRenderer();
        itemRenderer.renderItem(new ItemStack(Items.HAY_BLOCK), ModelTransformationMode.NONE, light,
                OverlayTexture.DEFAULT_UV, matrices, vertexConsumers, entity.getWorld(), entity.getId());
        matrices.pop();
    }
}
