package cn.bmcvp.dummy;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * 训练木桩独立 mod（Forge）：指令 /dummy（权限 2）在玩家面前 2 格生成
 * 9999 HP、每秒自动回满、无 AI、不可推动的训练木桩。
 */
@Mod(TrainingDummyMod.MODID)
public final class TrainingDummyMod {
    public static final String MODID = "dummy_mod";

    // FMLJavaModLoadingContext.get() 虽被标记移除，但无参构造器是 47.3.22 验证可用的稳定方式
    @SuppressWarnings("removal")
    public TrainingDummyMod() {
        ModEntities.REGISTER.register(FMLJavaModLoadingContext.get().getModEventBus());
        FMLJavaModLoadingContext.get().getModEventBus().addListener(TrainingDummyEntity::onAttributeCreate);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dummy")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnDummy(context)));
    }

    /** 生成训练木桩：玩家面朝方向前 2 格，9999 HP 每秒自动回满。 */
    private static int spawnDummy(CommandContext<CommandSourceStack> context) {
        ServerPlayer player;
        try {
            player = context.getSource().getPlayerOrException();
        } catch (Exception error) {
            context.getSource().sendFailure(Component.literal("该命令只能由游戏内玩家执行。"));
            return 0;
        }
        TrainingDummyEntity.ensureMaxHealthCapRaised();
        TrainingDummyEntity dummy = new TrainingDummyEntity(ModEntities.TRAINING_DUMMY.get(), player.serverLevel());
        Vec3 look = player.getLookAngle();
        dummy.moveTo(player.getX() + look.x * 2.0, player.getY() + 1.0,
                player.getZ() + look.z * 2.0, player.getYRot(), 0.0F);
        dummy.setHealth(dummy.getMaxHealth());
        player.serverLevel().addFreshEntity(dummy);
        context.getSource().sendSuccess(
                () -> Component.literal("已生成训练木桩（9999 HP，每秒自动回满；造成伤害会在动作栏显示数值）"), false);
        return 1;
    }
}
