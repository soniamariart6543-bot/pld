package cn.bmcvp.dummy;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 训练木桩实体注册（Forge）。 */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> REGISTER =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TrainingDummyMod.MODID);

    public static final RegistryObject<EntityType<TrainingDummyEntity>> TRAINING_DUMMY = REGISTER.register(
            "training_dummy",
            () -> EntityType.Builder.<TrainingDummyEntity>of(TrainingDummyEntity::new, MobCategory.MISC)
                    .sized(0.9f, 1.9f).build("training_dummy"));

    private ModEntities() {
    }
}
