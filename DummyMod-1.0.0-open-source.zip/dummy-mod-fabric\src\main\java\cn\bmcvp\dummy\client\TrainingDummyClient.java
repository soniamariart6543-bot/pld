package cn.bmcvp.dummy.client;

import cn.bmcvp.dummy.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class TrainingDummyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.TRAINING_DUMMY, TrainingDummyRenderer::new);
    }
}
