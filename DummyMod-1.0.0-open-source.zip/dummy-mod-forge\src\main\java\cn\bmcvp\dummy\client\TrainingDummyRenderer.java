package cn.bmcvp.dummy.client;

import cn.bmcvp.dummy.TrainingDummyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * 训练木桩渲染（Forge）：渲染一个放大 2 倍的干草捆（干草块物品模型），作为靶子外观。
 */
public class TrainingDummyRenderer extends EntityRenderer<TrainingDummyEntity> {
    /** 占位贴图（木桩本体用干草捆物品模型渲染，此贴图仅用于满足抽象方法）。 */
    private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/block/hay_block_side.png");

    public TrainingDummyRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(TrainingDummyEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(TrainingDummyEntity entity, float yaw, float tickDelta, PoseStack matrices,
                       MultiBufferSource bufferSource, int light) {
        super.render(entity, yaw, tickDelta, matrices, bufferSource, light);
        matrices.pushPose();
        // 放大 2 倍并抬高，形成一个约 2 格高的靶子
        matrices.scale(2.0f, 2.0f, 2.0f);
        matrices.translate(0.0, 0.25, 0.0);
        Minecraft.getInstance().getItemRenderer().renderStatic(
                new ItemStack(Items.HAY_BLOCK), ItemDisplayContext.NONE, light, OverlayTexture.NO_OVERLAY,
                matrices, bufferSource, entity.level(), entity.getId());
        matrices.popPose();
    }
}
