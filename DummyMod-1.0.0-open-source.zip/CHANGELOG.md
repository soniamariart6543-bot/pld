# DummyMod — 更新日志（Changelog）

> 版本路线：1.0.0 ｜ Fabric + Forge 双加载器 ｜ Minecraft 1.20.1

---

## 1.0.0（最新）

### ✨ 新功能

- **训练木桩实体**：9999 最大生命、每秒自动回满、无 AI（不移动不攻击）、不可被推动、不会自然消失
- **真 9999 血**：1.20.1 原版 `generic.max_health` 属性钳制上限为 1024，本 mod 通过反射将该钳制抬高至 99999，实现真正 9999 生命
- **`/dummy` 指令**（权限 2）：在玩家面朝方向前 2 格生成木桩，一次一条
- **伤害数字显示**：玩家对木桩造成伤害时，动作栏实时显示实际扣血与剩余生命（兼容秒杀、骨裂等伤害入口改写）
- **干草捆外观**：放大 2 倍的干草捆物品模型渲染，作为靶子外观
- **双平台同源**：Fabric 与 Forge 各自独立工程，同一套逻辑、同一指令、同一体验

### 📦 发布

- 预构建产物：`DummyMod-1.0.0.jar`（Fabric）/ `DummyMod-1.0.0-forge.jar`（Forge）

---

## English

### 1.0.0 (latest)

**New features**

- **Training dummy entity**: 9999 max HP, auto full-heal every second, no AI (no movement / no attacks), un-pushable, persistent
- **True 9999 HP**: vanilla 1.20.1 clamps `generic.max_health` to 1024; this mod raises the clamp to 99999 via reflection for a real 9999 HP
- **`/dummy` command** (permission level 2): spawns the dummy 2 blocks in front of the player
- **Damage readout**: the attacker's action bar shows the actual damage dealt and remaining HP (compatible with damage re-writes such as instant-kill / bone-crack)
- **Hay-bale look**: renders a 2x scaled hay block item model as the target
- **Same logic on both loaders**: separate Fabric and Forge projects, identical behavior and command

**Release**

- Prebuilt artifacts: `DummyMod-1.0.0.jar` (Fabric) / `DummyMod-1.0.0-forge.jar` (Forge)
