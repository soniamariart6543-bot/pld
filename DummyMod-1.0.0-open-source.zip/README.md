# DummyMod — 训练木桩 / Training Dummy

Minecraft 1.20.1 独立训练木桩 mod（**Fabric + Forge 双平台**）：
9999 最大生命、每秒自动回满、无 AI、不可推动，用于测试伤害数值（法杖、骨头、附魔等）。

Standalone training-dummy mod for Minecraft 1.20.1 (Fabric & Forge):
9999 max HP, auto full-heal every second, no AI, un-pushable — built for damage testing.

---

## 功能特性 / Features

- **9999 最大生命**：代码反射抬高 1.20.1 原版 `generic.max_health` 的 1024 钳制上限，实现真 9999 血
- **每秒自动回满**：掉血后 1 秒内自动恢复满血
- **无 AI / 不移动 / 不攻击 / 不可推动 / 不自然消失**：纯粹的伤害靶子
- **伤害数字显示**：玩家对它造成伤害时，动作栏实时显示 `[木桩] -12.5 HP（剩余 9986）`
- **干草捆外观**：放大 2 倍的干草捆模型，靶子既视感
- **`/dummy` 指令**：在玩家面朝方向前 2 格生成

- 9999 max HP: raises the vanilla 1.20.1 `generic.max_health` clamp (1024) via reflection for a true 9999 HP
- Auto full-heal every second
- No AI / no movement / no attacks / un-pushable / persistent: a pure damage target
- Damage readout: the attacker's action bar shows `[Dummy] -12.5 HP (9986 left)` on each hit
- Hay-bale look: a 2x scaled hay block model
- `/dummy` command: spawns it 2 blocks in front of the player

## 使用 / Usage

游戏内（需要权限等级 2：单人开作弊或服务器 OP）执行：

```
/dummy
```

- 生成位置：玩家面朝方向前 2 格
- 指令帮助：`/dummy` 无子命令

In-game command (permission level 2 — cheats enabled in singleplayer, or OP on a server):

```
/dummy
```

- Spawns 2 blocks in front of the player, facing the player

## 构建 / Building

环境要求：JDK 17、Gradle 8.x（无需 gradle wrapper，直接使用系统 gradle）。

Requirements: JDK 17, Gradle 8.x (no wrapper — use a system Gradle).

```bash
# Fabric
cd dummy-mod-fabric
gradle build
# 产物 / artifact: build/libs/dummy_mod-<version>.jar

# Forge
cd dummy-mod-forge
gradle build
# 产物 / artifact: build/libs/dummy_mod_forge-<version>.jar
```

预构建产物见 `releases/`（Prebuilt jars are in `releases/`）。

## 目录结构 / Structure

```
DummyMod-1.0.0-src/
├── README.md           本说明 / this readme
├── CHANGELOG.md        更新日志（中英）/ changelog (CN & EN)
├── LICENSE             MIT 协议 / MIT license
├── releases/           预构建 jar / prebuilt jars
├── dummy-mod-fabric/   Fabric 工程 / Fabric project
└── dummy-mod-forge/    Forge 工程 / Forge project
```

## 开源协议 / License

[MIT](LICENSE) © 2026 遗物团队
