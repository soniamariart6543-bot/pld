package cn.bmcvp.relic;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 战利品骨头的吸血逻辑：根据攻击伤害回血，溢出转为临时血量（最多 50% 基础生命值），
 * 临时血持续 8 秒，再次攻击刷新持续时间。
 */
public final class LifestealHandler {
    private static final int TEMP_HP_TICKS = 160; // 8 秒
    private static final Map<ServerPlayerEntity, Long> ABSORPTION_EXPIRY = new WeakHashMap<>();

    public static void initialize() {
        // 伤害应用前记录，延迟到伤害应用后回血
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (amount > 0 && source.getAttacker() instanceof ServerPlayerEntity player && entity != player) {
                ItemStack stack = player.getMainHandStack();
                if (RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
                    int level = RelicService.value(stack, "fortune");
                    if (level > 0 && player.getServer() != null) {
                        player.getServer().execute(() -> applyLifesteal(player, amount, level));
                    }
                }
            }
            return true;
        });

        // 临时血量到期清除
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long now = server.getTicks();
            ABSORPTION_EXPIRY.entrySet().removeIf(entry -> {
                if (entry.getValue() <= now) {
                    ServerPlayerEntity player = entry.getKey();
                    if (player != null && !player.isRemoved()) {
                        player.setAbsorptionAmount(0.0f);
                    }
                    return true;
                }
                return false;
            });
        });
    }

    /** 法杖吸血入口（供 WandSkillHandler 调用）：按吸血等级回血 + 溢出转临时血。 */
    public static void applyWandLifesteal(ServerPlayerEntity player, float damage, int level) {
        applyLifesteal(player, damage, level);
    }

    private static void applyLifesteal(ServerPlayerEntity player, float damage, int level) {
        float percent = RelicService.lifestealPercent(level);
        float lifesteal = damage * percent;
        if (lifesteal <= 0) {
            return;
        }
        float before = player.getHealth();
        player.heal(lifesteal);
        float healed = player.getHealth() - before;
        float overflow = lifesteal - healed;
        if (overflow > 0) {
            float maxAbsorption = player.getMaxHealth() * 0.5f;
            float newAbsorption = Math.min(player.getAbsorptionAmount() + overflow, maxAbsorption);
            player.setAbsorptionAmount(newAbsorption);
            // 刷新临时血持续时间
            ABSORPTION_EXPIRY.put(player, player.getServer().getTicks() + (long) TEMP_HP_TICKS);
        }
    }
}
