package cn.bmcvp.relic;

import com.mojang.brigadier.context.CommandContext;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class BmcvpRelicUpgrades implements ModInitializer {
    public static final String MODID = "bmcvp_relic_upgrades";
    public static final Identifier UPGRADE = new Identifier(MODID, "upgrade");
    public static final Identifier RESULT = new Identifier(MODID, "result");
    public static final Identifier GRANT = new Identifier(MODID, "grant");
    public static final Identifier WAND_SWING = new Identifier(MODID, "wand_swing");
    public static final Identifier WAND_SWITCH = new Identifier(MODID, "wand_switch");
    public static final int PACKET_STRING_MAX_LENGTH = 64;

    // 唯一性标记：每个遗物物品独立记录，已发放过则不再重复发放
    private static final String PICKAXE_GRANTED = "bmcvp_relic_pickaxe_granted";
    private static final String BONE_GRANTED = "bmcvp_relic_bone_granted";
    private static final String BONE_ARMOR_GRANTED = "bmcvp_relic_bone_armor_granted";
    private static final String GUIDE_GRANTED = "bmcvp_relic_guide_granted";
    private static final String VISITED_NETHER = "bmcvp_relic_visited_nether";

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModEffects.initialize();
        LifestealHandler.initialize();
        ArmorOvercapHandler.initialize();
        BoneSkillHandler.initialize();
        ArmorSkillHandler.initialize();
        PickaxeSkillHandler.initialize();
        WandSkillHandler.initialize();
        RelicEntities.initialize();

        // 客户端 -> 服务器：升级请求
        ServerPlayNetworking.registerGlobalReceiver(UPGRADE, (server, player, handler, buf, responseSender) -> {
            String id = buf.readString(PACKET_STRING_MAX_LENGTH);
            int slot = buf.readInt();
            server.execute(() -> {
                String result = RelicService.tryUpgrade(player, id, slot);
                if (ServerPlayNetworking.canSend(player, RESULT)) {
                    String networkResult = result.length() <= PACKET_STRING_MAX_LENGTH
                            ? result : result.substring(0, 63) + "…";
                    ServerPlayNetworking.send(player, RESULT,
                            PacketByteBufs.create().writeString(networkResult, PACKET_STRING_MAX_LENGTH));
                }
            });
        });

        // 客户端 -> 服务器：创造模式发放请求（服务端校验 creativeMode）
        ServerPlayNetworking.registerGlobalReceiver(GRANT, (server, player, handler, buf, responseSender) -> {
            String relic = buf.readString(PACKET_STRING_MAX_LENGTH);
            server.execute(() -> grantCreative(player, relic));
        });

        // 客户端 -> 服务器：法杖空挥（左键无目标时释放火球）
        ServerPlayNetworking.registerGlobalReceiver(WAND_SWING, (server, player, handler, buf, responseSender) ->
                server.execute(() -> WandSkillHandler.fireSwing(player)));

        // 客户端 -> 服务器：骨头 ⇄ 法杖切换（物品本体互换）
        ServerPlayNetworking.registerGlobalReceiver(WAND_SWITCH, (server, player, handler, buf, responseSender) ->
                server.execute(() -> {
                    String result = RelicService.switchRelic(player);
                    if (ServerPlayNetworking.canSend(player, RESULT)) {
                        String networkResult = result.length() <= PACKET_STRING_MAX_LENGTH
                                ? result : result.substring(0, 63) + "…";
                        ServerPlayNetworking.send(player, RESULT,
                                PacketByteBufs.create().writeString(networkResult, PACKET_STRING_MAX_LENGTH));
                    }
                }));


        // 开局：逐个检测背包/手上是否已有遗物，缺失才发放，并打独立标记
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            server.execute(() -> grantStarterRelics(player));
        });

        // 首次进入下界：解锁骨甲并发放
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            if (destination.getRegistryKey() == World.NETHER) {
                grantNetherArmor(player);
            }
        });

        // 命令：/relic grant <all|pickaxe|bone|armor|bone_armor>
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("relic")
                        .requires(source -> source.hasPermissionLevel(2))
                        .then(CommandManager.literal("grant")
                                .executes(context -> grant(context, "all"))
                                .then(CommandManager.literal("all").executes(context -> grant(context, "all")))
                                .then(CommandManager.literal("pickaxe").executes(context -> grant(context, "pickaxe")))
                                .then(CommandManager.literal("bone").executes(context -> grant(context, "bone")))
                                .then(CommandManager.literal("bone_armor").executes(context -> grant(context, "bone_armor"))))));
    }

    /** 开局遗物：镐、骨头分别独立检测、独立发放。 */
    private static void grantStarterRelics(ServerPlayerEntity player) {
        if (!player.getCommandTags().contains(PICKAXE_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.PICKAXE)) {
                deliverRelics(player, List.of(RelicService.initialPickaxe()));
                player.sendMessage(Text.literal("[遗物成长] 已发放：无尽铁镐"), false);
            }
            player.addCommandTag(PICKAXE_GRANTED);
        }
        if (!player.getCommandTags().contains(BONE_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE)) {
                deliverRelics(player, List.of(RelicService.initialBone()));
                player.sendMessage(Text.literal("[遗物成长] 已发放：战利品骨头"), false);
            }
            player.addCommandTag(BONE_GRANTED);
        }
        if (!player.getCommandTags().contains(GUIDE_GRANTED)) {
            deliverRelics(player, List.of(RelicService.initialGuideBook()));
            player.sendMessage(Text.literal("[遗物成长] 已发放：骨与火教程书"), false);
            player.addCommandTag(GUIDE_GRANTED);
        }
    }

    /** 创造模式发放（服务器权威，仅创造玩家可调用）。骨甲发放同时解锁地狱标记以便穿戴。 */
    private static void grantCreative(ServerPlayerEntity player, String section) {
        if (!player.getAbilities().creativeMode) {
            return;
        }
        List<ItemStack> relics = switch (section) {
            case "pickaxe" -> List.of(RelicService.initialPickaxe());
            case "bone" -> List.of(RelicService.initialBone());
            case "guide" -> List.of(RelicService.initialGuideBook());
            case "wand" -> List.of(RelicService.initialWand());
            case "bone_armor" -> {
                player.addCommandTag(VISITED_NETHER);
                yield RelicService.initialBoneArmor();
            }
            default -> RelicService.initialAllRelics();
        };
        deliverRelics(player, relics);
        player.sendMessage(Text.literal("[遗物成长] 创造模式已发放对应遗物"), false);
    }

    /** 首次进入下界：解锁骨甲并发放一套。 */
    private static void grantNetherArmor(ServerPlayerEntity player) {
        if (!player.getCommandTags().contains(VISITED_NETHER)) {
            player.addCommandTag(VISITED_NETHER);
        }
        if (!player.getCommandTags().contains(BONE_ARMOR_GRANTED)) {
            if (!RelicService.anyRelic(player, UpgradeDefinition.RelicType.BONE_ARMOR)) {
                deliverRelics(player, RelicService.initialBoneArmor());
                player.sendMessage(Text.literal("[遗物成长] 首次进入地狱，已发放：遗物骨甲一套"), false);
            }
            player.addCommandTag(BONE_ARMOR_GRANTED);
        }
    }

    private static int grant(CommandContext<ServerCommandSource> context, String section) {
        ServerPlayerEntity player;
        try {
            player = context.getSource().getPlayer();
        } catch (Exception error) {
            context.getSource().sendError(Text.literal("该命令只能由游戏内玩家执行。"));
            return 0;
        }
        List<ItemStack> relics = switch (section) {
            case "pickaxe" -> List.of(RelicService.initialPickaxe());
            case "bone" -> List.of(RelicService.initialBone());
            case "bone_armor" -> RelicService.initialBoneArmor();
            default -> RelicService.initialAllRelics();
        };
        int dropped = deliverRelics(player, relics);
        String suffix = dropped == 0 ? "" : "（其中 " + dropped + " 件已掉落）";
        context.getSource().sendFeedback(
                () -> Text.literal("已发放 " + relics.size() + " 件" + sectionName(section) + "遗物。" + suffix), false);
        return relics.size();
    }

    private static int deliverRelics(ServerPlayerEntity player, List<ItemStack> relics) {
        int dropped = 0;
        for (ItemStack relic : relics) {
            player.getInventory().insertStack(relic);
            if (!relic.isEmpty()) {
                player.dropItem(relic, false);
                dropped++;
            }
        }
        player.getInventory().markDirty();
        return dropped;
    }

    private static String sectionName(String section) {
        return switch (section) {
            case "pickaxe" -> "无尽铁镐";
            case "bone" -> "战利品骨头";
            case "bone_armor" -> "遗物骨甲";
            default -> "开局";
        };
    }
}
