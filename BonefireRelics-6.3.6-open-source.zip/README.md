# Bonefire Relics（遗物成长）

Minecraft 1.20.1 服务端权威遗物升级模组（**Fabric + Forge 双平台**）。
开局自动发放无尽铁镐、战利品骨头与骨与火教程书；首次进入下界解锁遗物骨甲；升级树、技能、护甲超限转化全部由服务器权威结算。

A server-authoritative relic upgrade mod for Minecraft 1.20.1 (Fabric & Forge).
Relics are granted on join (endless pickaxe, trophy bone, guide book); the bone armor set unlocks on first entering the Nether. All upgrades, skills and armor-overcap conversion are validated server-side.

---

## 功能特性 / Features

- **无尽铁镐**：7 级材质路线（铁 → 钻石 → 下界合金 → 高级下界合金四级），效率 II–V、时运 II–X，技能「补给」（每挖 150 方块获得补给 5 秒）
- **战利品骨头**：伤害 D1–D41、火焰附加 II（1.2% 秒杀 999）、抢夺 II–X、吸血 I–X，技能「骨火」（每 3 次命中对附近怪物造成范围魔法伤害）、骨裂（攻击力≥20 附加 8% 当前生命）
- **遗物骨甲**：3 阶铸体（骨 / 钻石 / 下界合金），保护 I–V、韧性 II–X、荆棘 II–III、护甲值 +1~50、保护家族（火焰/爆炸/弹射物），技能「骨甲护体」（高额受击触发抗性+生命恢复）
- **护甲超限转化**：穿戴 ≥2 件骨甲且全身护甲超阈值后，每点 = 全面减伤 + 最大生命（`config/bmcvp_relic_armor_overcap.json` 可调）
- **魔法法杖**：与骨头一体两面可随时切换，法术强度 0→30、吸血 1→10、爆炸 1→10，左键沿视线直线发射火球（基础 10 + 强度×1，命中 AOE 魔法伤害）
- **防丢弃 / 防销毁**：遗物无法用 Q 丢出，免疫火焰/岩浆/爆炸（虚空除外）
- **教程书「骨与火」**：开局发放，右键查看完整玩法
- **指令 `/relic grant <all|pickaxe|bone|bone_armor>`**（权限 2）

- **Endless pickaxe**: 7-tier material line (iron → diamond → netherite → 4 advanced netherite tiers), Efficiency II–V, Fortune II–X, skill "Supply" (5s of Supply every 150 blocks mined)
- **Trophy bone**: damage D1–D41, Fire Aspect II (1.2% instant-kill for 999), Looting II–X, Lifesteal I–X, skill "Bonefire" (AOE magic damage to nearby mobs every 3 hits), "Bone Crack" (≥20 attack adds 8% of target's current HP)
- **Relic bone armor**: 3 casting tiers (bone / diamond / netherite), Protection I–V, Toughness II–X, Thorns II–III, Armor +1~50, protection family (fire / blast / projectile), skill "Bone Ward" (Resistance + Regeneration on heavy damage)
- **Armor overcap conversion**: with ≥2 bone-armor pieces and total armor above the threshold, every extra point grants damage reduction + max health (tunable in `config/bmcvp_relic_armor_overcap.json`)
- **Magic wand**: two forms of the trophy bone (switch anytime), Spell Power 0→30, Lifesteal 1→10, Explosion 1→10; left-click fires a straight-line fireball along your sight (base 10 + spell×1, AOE magic damage on hit)
- **Drop/destroy protection**: relics cannot be dropped with Q and are immune to fire/lava/explosions (void excluded)
- **Guide book "Bone and Fire"**: granted at spawn; right-click for the full manual
- **Command `/relic grant <all|pickaxe|bone|bone_armor>`** (permission level 2)

## 构建 / Building

环境要求：JDK 17、Gradle 8.x（两个工程均使用系统 gradle，无 wrapper）。

Requirements: JDK 17, Gradle 8.x (both projects use a system Gradle, no wrapper).

```bash
# Fabric
cd relic-upgrades
gradle build
# 产物 / artifact: build/libs/bonefire_relics-<version>.jar

# Forge
cd relic-upgrades-forge
gradle build
# 产物 / artifact: build/libs/bonefire_relics_forge-<version>.jar
```

预构建产物见 `releases/`（Prebuilt jars are in `releases/`）。

## 目录结构 / Structure

```
BonefireRelics-6.3.6-src/
├── README.md           本说明 / this readme
├── 更新日志.md          更新日志（中英）/ changelog (CN & EN)
├── LICENSE             MIT 协议 / MIT license
├── .gitignore          构建产物忽略 / build-artifact ignore
├── releases/           预构建 jar / prebuilt jars
├── relic-upgrades/     Fabric 工程 / Fabric project
└── relic-upgrades-forge/  Forge 工程 / Forge project
```

## 开源协议 / License

[MIT](LICENSE) © 2026 遗物团队
