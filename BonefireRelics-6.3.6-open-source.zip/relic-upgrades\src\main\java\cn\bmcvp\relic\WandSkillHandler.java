package cn.bmcvp.relic;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.spell_power.api.SpellPower;
import net.spell_power.api.SpellSchools;

/**
 * 魔法法杖攻击（v6.3.5+）：左键点击即释放直线火球，沿视线方向飞行。
 * <ul>
 *   <li>无索敌：纯粹沿玩家视线方向直线飞行，每次点击左键都释放；</li>
 *   <li>命中任意实体生物（非玩家）即爆炸（不破坏方块），AOE 魔法伤害扩散周围怪物；</li>
 *   <li>基础 10 点魔法伤害 + 法术强度×1（一点提升一点伤害）；</li>
 *   <li>爆炸伤害 = 5 + 爆炸等级×0.5（上限 10 点）；连击/火罚/吸血同前。</li>
 * </ul>
 */
public final class WandSkillHandler {
    public static final float BASE_DAMAGE = 10.0f;
    public static final float DAMAGE_PER_SPELL = 1.0f;
    public static final int FIRE_PUNISH_SPELL = 15;
    public static final float FIRE_PUNISH_PERCENT = 0.05f;
    /** 直线发射速度（格/tick）：与 RelicFireballEntity.SPEED 保持一致。 */
    public static final float LAUNCH_SPEED = 2.0f;

    private WandSkillHandler() {
    }

    /** 左键触发入口：每次点击沿视线方向释放一个直线火球。 */
    public static void fireSwing(ServerPlayerEntity player) {
        fire(player);
    }

    public static void initialize() {
        // 法杖不做近战：持法杖时取消近战伤害；火球由左键点击（WAND_SWING 包）触发。
        // 保留 MAGIC/INDIRECT_MAGIC 放行，避免取消火球自身的魔法伤害。
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((target, source, amount) -> {
            if (amount <= 0) {
                return true;
            }
            if (!(source.getAttacker() instanceof ServerPlayerEntity player)) {
                return true;
            }
            if (target == player || target.isRemoved()) {
                return true;
            }
            if (source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC)) {
                return true;
            }
            ItemStack stack = player.getMainHandStack();
            if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
                return true;
            }
            return false; // 取消法杖近战伤害
        });
    }

    /**
     * 直线发射（如同丢出物品 / 弩箭射击）：沿玩家视线方向以标准抛射物发射机制投出，
     * divergence=0 无随机散布，配合 RelicFireballEntity 的速度保持实现完全直线飞行。
     */
    private static void fire(ServerPlayerEntity player) {
        ItemStack stack = player.getMainHandStack();
        // 服务端权威校验：换手 / 空手不再发射（兼防空 NBT 崩溃）
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
            return;
        }
        int spell = RelicService.value(stack, "spell");
        int explosion = RelicService.value(stack, "explosion");
        ServerWorld world = player.getServerWorld();
        // 适配 Spell Power：火球伤害 = 基础 + 法杖等级加成 + 火系法术强度 × 2.5（含暴击/波动）
        float damage = BASE_DAMAGE + spell * DAMAGE_PER_SPELL
                + (float) (SpellPower.getSpellPower(SpellSchools.FIRE, player).randomValue() * 2.5);
        RelicFireballEntity fb = new RelicFireballEntity(world, player, damage, spell, explosion);
        // 标准抛射物发射（与雪球 / 末影珍珠 / 弩箭同一机制）：视线方向，divergence=0 → 完全直线
        fb.setVelocity(player, player.getPitch(), player.getYaw(), 0.0F, LAUNCH_SPEED, 0.0F);
        world.spawnEntity(fb);
        // 发射音效（弩箭射击感）
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    /** 供火球实体命中后调用：按法杖吸血等级回血。 */
    public static void lifestealFrom(ServerPlayerEntity player, float damage) {
        ItemStack stack = player.getMainHandStack();
        int level = RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)
                ? RelicService.value(stack, "wfortune") : 0;
        if (level <= 0) {
            return;
        }
        LifestealHandler.applyWandLifesteal(player, damage, level);
    }
}
