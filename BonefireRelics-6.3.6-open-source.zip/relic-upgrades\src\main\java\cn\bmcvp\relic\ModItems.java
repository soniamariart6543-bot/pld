package cn.bmcvp.relic;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * 遗物 mod 的全部物品注册。
 *
 * <p>镐子材料共 7 级（tier 0..6）；防具仅保留骨甲一线，材质 3 阶（骨 → 钻石骨甲 → 下界合金骨甲）。</p>
 */
public final class ModItems {
    public static final String MOD_ID = "bmcvp_relic_upgrades";

    // =====================================================================
    // 自定义工具材质：高级下界合金四级（属性在下界合金基础上逐级增强）
    // =====================================================================
    private static final ToolMaterial NETHERITE_IRON = toolMaterial(4, 2400, 10.0f, 5.0f, 15, Items.NETHERITE_INGOT);
    private static final ToolMaterial NETHERITE_GOLD = toolMaterial(4, 2600, 11.0f, 5.5f, 18, Items.NETHERITE_INGOT);
    private static final ToolMaterial NETHERITE_EMERALD = toolMaterial(5, 3000, 12.0f, 6.0f, 20, Items.NETHERITE_INGOT);
    private static final ToolMaterial NETHERITE_DIAMOND = toolMaterial(5, 3600, 13.0f, 7.0f, 22, Items.NETHERITE_INGOT);

    private static ToolMaterial toolMaterial(int miningLevel, int durability, float speed, float attack, int enchantability, Item repairItem) {
        return new ToolMaterial() {
            @Override public int getDurability() { return durability; }
            @Override public float getMiningSpeedMultiplier() { return speed; }
            @Override public float getAttackDamage() { return attack; }
            @Override public int getMiningLevel() { return miningLevel; }
            @Override public int getEnchantability() { return enchantability; }
            @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(repairItem); }
        };
    }

    // =====================================================================
    // 初始骨甲材质：防御对标锁链铁甲（头盔2/胸甲6/护腿5/靴子2），耐久同铁甲
    // =====================================================================
    private static final ArmorMaterial BONE_ARMOR = new ArmorMaterial() {
        @Override public int getDurability(ArmorItem.Type type) {
            return switch (type) {
                case HELMET -> 165;
                case CHESTPLATE -> 240;
                case LEGGINGS -> 225;
                case BOOTS -> 195;
            };
        }
        @Override public int getProtection(ArmorItem.Type type) {
            return switch (type) {
                case HELMET -> 2;
                case CHESTPLATE -> 6;
                case LEGGINGS -> 5;
                case BOOTS -> 2;
            };
        }
        @Override public int getEnchantability() { return 25; }
        @Override public SoundEvent getEquipSound() { return SoundEvents.ITEM_ARMOR_EQUIP_GENERIC; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.BONE); }
        @Override public String getName() { return "iron"; }
        @Override public float getToughness() { return 0.0f; }
        @Override public float getKnockbackResistance() { return 0.0f; }
    };

    // =====================================================================
    // 物品字段
    // =====================================================================
    // ---- 战利品骨头 ----
    public static final Item RELIC_BONE = register("relic_bone", new RelicBoneItem());

    // ---- 教程书：骨与火 ----
    public static final Item RELIC_GUIDE_BOOK = register("relic_guide_book", new GuideBookItem());

    // ---- 魔法法杖（木棍 + 青蓝宝石，与骨头一体两面）----
    public static final Item MAGIC_WAND = register("magic_wand",
            new SwordItem(ToolMaterials.IRON, 3, -2.0f, new Item.Settings().fireproof()));


    // ---- 镐：原生三级 ----
    public static final Item RELIC_IRON_PICKAXE = pickaxe("relic_iron_pickaxe", ToolMaterials.IRON, false);
    public static final Item RELIC_DIAMOND_PICKAXE = pickaxe("relic_diamond_pickaxe", ToolMaterials.DIAMOND, false);
    public static final Item RELIC_NETHERITE_PICKAXE = pickaxe("relic_netherite_pickaxe", ToolMaterials.NETHERITE, true);

    // ---- 镐：高级下界合金四级（对标 Advanced Netherite）----
    public static final Item RELIC_NETHERITE_IRON_PICKAXE = pickaxe("relic_netherite_iron_pickaxe", NETHERITE_IRON, true);
    public static final Item RELIC_NETHERITE_GOLD_PICKAXE = pickaxe("relic_netherite_gold_pickaxe", NETHERITE_GOLD, true);
    public static final Item RELIC_NETHERITE_EMERALD_PICKAXE = pickaxe("relic_netherite_emerald_pickaxe", NETHERITE_EMERALD, true);
    public static final Item RELIC_NETHERITE_DIAMOND_PICKAXE = pickaxe("relic_netherite_diamond_pickaxe", NETHERITE_DIAMOND, true);

    // ---- 骨甲：tier 0（骨，锁链铁甲）----
    public static final Item RELIC_BONE_HELMET = boneArmor("relic_bone_helmet", BONE_ARMOR, ArmorItem.Type.HELMET);
    public static final Item RELIC_BONE_CHESTPLATE = boneArmor("relic_bone_chestplate", BONE_ARMOR, ArmorItem.Type.CHESTPLATE);
    public static final Item RELIC_BONE_LEGGINGS = boneArmor("relic_bone_leggings", BONE_ARMOR, ArmorItem.Type.LEGGINGS);
    public static final Item RELIC_BONE_BOOTS = boneArmor("relic_bone_boots", BONE_ARMOR, ArmorItem.Type.BOOTS);

    // ---- 骨甲：tier 1（钻石骨甲）----
    public static final Item RELIC_BONE_DIAMOND_HELMET = boneArmor("relic_bone_diamond_helmet", ArmorMaterials.DIAMOND, ArmorItem.Type.HELMET);
    public static final Item RELIC_BONE_DIAMOND_CHESTPLATE = boneArmor("relic_bone_diamond_chestplate", ArmorMaterials.DIAMOND, ArmorItem.Type.CHESTPLATE);
    public static final Item RELIC_BONE_DIAMOND_LEGGINGS = boneArmor("relic_bone_diamond_leggings", ArmorMaterials.DIAMOND, ArmorItem.Type.LEGGINGS);
    public static final Item RELIC_BONE_DIAMOND_BOOTS = boneArmor("relic_bone_diamond_boots", ArmorMaterials.DIAMOND, ArmorItem.Type.BOOTS);

    // ---- 骨甲：tier 2（下界合金骨甲）----
    public static final Item RELIC_BONE_NETHERITE_HELMET = boneArmor("relic_bone_netherite_helmet", ArmorMaterials.NETHERITE, ArmorItem.Type.HELMET);
    public static final Item RELIC_BONE_NETHERITE_CHESTPLATE = boneArmor("relic_bone_netherite_chestplate", ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE);
    public static final Item RELIC_BONE_NETHERITE_LEGGINGS = boneArmor("relic_bone_netherite_leggings", ArmorMaterials.NETHERITE, ArmorItem.Type.LEGGINGS);
    public static final Item RELIC_BONE_NETHERITE_BOOTS = boneArmor("relic_bone_netherite_boots", ArmorMaterials.NETHERITE, ArmorItem.Type.BOOTS);

    private ModItems() {
    }

    private static Item pickaxe(String path, ToolMaterial material, boolean fireproof) {
        // 遗物一律防火（配合防销毁机制）
        Item.Settings settings = new Item.Settings().fireproof();
        return register(path, new PickaxeItem(material, 1, -2.8f, settings));
    }

    private static Item boneArmor(String path, ArmorMaterial material, ArmorItem.Type type) {
        return register(path, new RelicBoneArmorItem(material, type, new Item.Settings().fireproof()));
    }

    private static Item register(String path, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MOD_ID, path), item);
    }

    public static void initialize() {
    }
}
