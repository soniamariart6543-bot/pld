package cn.bmcvp.relic;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 魔法法杖攻击（v6.3.5+，Forge）：左键点击即释放直线火球，沿视线方向飞行。
 * <ul>
 *   <li>无索敌：纯粹沿玩家视线方向直线飞行，每次点击左键都释放；</li>
 *   <li>命中任意实体生物（非玩家）即爆炸（不破坏方块），AOE 魔法伤害扩散周围怪物；</li>
 *   <li>基础 10 点魔法伤害 + 法术强度×1（一点提升一点伤害）；</li>
 *   <li>爆炸伤害 = 5 + 爆炸等级×0.5（上限 10 点）；连击/火罚/吸血同前。</li>
 * </ul>
 */
public final class WandSkillHandler {
    public static final float BASE_DAMAGE = 10.0f;
    public static final float DAMAGE_PER_SPELL = 1.0f;
    public static final int FIRE_PUNISH_SPELL = 15;
    public static final float FIRE_PUNISH_PERCENT = 0.05f;
    /** 直线发射速度（格/tick）：与 RelicFireballEntity.SPEED 保持一致。 */
    public static final float LAUNCH_SPEED = 2.0f;

    private WandSkillHandler() {
    }

    /** 左键触发入口：每次点击沿视线方向释放一个直线火球。 */
    public static void fireSwing(ServerPlayer player) {
        fire(player);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target == player || !target.isAlive()) {
            return;
        }
        if (event.getSource().is(DamageTypes.MAGIC) || event.getSource().is(DamageTypes.INDIRECT_MAGIC)) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
            return;
        }
        event.setCanceled(true); // 取消法杖近战伤害
    }

    /**
     * 直线发射（如同丢出物品 / 弩箭射击）：沿玩家视线方向以标准抛射物发射机制投出，
     * inaccuracy=0 无随机散布，配合 RelicFireballEntity 的速度保持实现完全直线飞行。
     */
    private static void fire(ServerPlayer player) {
        ItemStack stack = player.getMainHandItem();
        // 服务端权威校验：换手 / 空手不再发射（兼防空 NBT 崩溃）
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)) {
            return;
        }
        int spell = RelicService.value(stack, "spell");
        int explosion = RelicService.value(stack, "explosion");
        ServerLevel level = player.serverLevel();
        float damage = BASE_DAMAGE + spell * DAMAGE_PER_SPELL;
        RelicFireballEntity fb = new RelicFireballEntity(level, player, damage, spell, explosion);
        // 标准抛射物发射（与雪球 / 末影珍珠 / 弩箭同一机制）：视线方向，inaccuracy=0 → 完全直线
        fb.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, LAUNCH_SPEED, 0.0F);
        level.addFreshEntity(fb);
        // 发射音效（弩箭射击感）
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    /** 供火球实体命中后调用：按法杖吸血等级回血。 */
    public static void lifestealFrom(ServerPlayer player, float damage) {
        ItemStack stack = player.getMainHandItem();
        int level = RelicService.isRelic(stack, UpgradeDefinition.RelicType.WAND)
                ? RelicService.value(stack, "wfortune") : 0;
        if (level <= 0) {
            return;
        }
        LifestealHandler.applyWandLifesteal(player, damage, level);
    }
}
