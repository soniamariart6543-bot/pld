package cn.bmcvp.relic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.ExplosiveProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.spell_power.api.SpellPower;
import net.spell_power.api.SpellSchools;
import java.util.List;

/**
 * 遗物法杖直线火球（v6.3.5+）：完全直线飞行，指哪儿打哪儿。
 * 命中任意实体生物（非发射者）即爆炸：AOE 魔法伤害扩散到目标周围怪物，不破坏方块。
 * 渲染：relic_fireball.png（火球贴图）。
 */
public class RelicFireballEntity extends ExplosiveProjectileEntity {
    /** 发射速度（格/tick）：与 WandSkillHandler.LAUNCH_SPEED 保持一致。 */
    public static final double SPEED = 2.0;
    private static final int MAX_LIFE = 120;        // 120 tick × 2.0 格/tick = 240 格射程
    private static final double EXPLOSION_RADIUS = 3.0; // 爆炸扩散半径

    private ServerPlayerEntity owner;
    private float baseDamage;
    private int spell;
    private int explosion;
    private int life = MAX_LIFE;

    public RelicFireballEntity(EntityType<? extends ExplosiveProjectileEntity> type, World world) {
        super(type, world);
    }

    /** 直线发射：速度由发射方（WandSkillHandler）按标准抛射物发射机制设置，本类只负责恒定直线飞行。 */
    public RelicFireballEntity(World world, ServerPlayerEntity owner, float baseDamage, int spell, int explosion) {
        super(RelicEntities.RELIC_FIREBALL, world);
        this.owner = owner;
        this.baseDamage = baseDamage;
        this.spell = spell;
        this.explosion = explosion;
        this.setPos(owner.getX(), owner.getEyeY(), owner.getZ());
        this.setNoGravity(true);
    }

    @Override
    public void tick() {
        // 完全直线：不重定向速度，保持初始方向
        super.tick();
        // 抵消原版抛射物阻力（每 tick ×0.9）：把速度归一化回发射速度，实现恒定速度直线飞行
        Vec3d v = this.getVelocity();
        double len = v.length();
        if (len > 1.0E-4) {
            this.setVelocity(v.multiply(SPEED / len));
        }
        if (this.getWorld() instanceof ServerWorld sw) {
            Vec3d p = this.getPos();
            sw.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
            sw.spawnParticles(ParticleTypes.SMALL_FLAME, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
        }
        if (--life <= 0) {
            discard();
        }
    }

    /** 命中任意实体生物（非发射者）即触发爆炸。 */
    @Override
    protected boolean canHit(Entity entity) {
        return entity instanceof LivingEntity le && le != owner && le.isAlive();
    }

    /** 命中生物：对目标造成法伤，并在目标位置产生爆炸（AOE 魔法伤害扩散周围怪物，不破坏方块）。 */
    @Override
    protected void onEntityHit(EntityHitResult hitResult) {
        if (!(hitResult.getEntity() instanceof LivingEntity hit) || owner == null) {
            this.discard();
            return;
        }
        explodeAt(hit);
        this.discard();
    }

    /** 撞墙：直接消失（不爆炸、不破坏方块）。 */
    @Override
    protected void onBlockHit(BlockHitResult hitResult) {
        this.discard();
    }

    /**
     * 爆炸结算：目标受法伤（基础 10 + 法术强度，+火罚+连击+吸血）；
     * 目标位置产生爆炸视觉（粒子+声音，不破坏方块），对周围 3 格内怪物造成爆炸 AOE 魔法伤害（5 + 爆炸等级×0.5）。
     */
    private void explodeAt(LivingEntity hit) {
        if (owner == null) {
            return;
        }
        ServerWorld sw = this.getWorld() instanceof ServerWorld s ? s : null;
        Vec3d center = hit.getPos().add(0, hit.getHeight() / 2, 0);

        // 1) 直接命中目标：法伤结算（火罚 + 连击 + 吸血）
        DamageSource source = owner.getDamageSources().indirectMagic(owner, owner);
        float dmg = baseDamage;
        if (spell >= WandSkillHandler.FIRE_PUNISH_SPELL) {
            dmg += hit.getHealth() * WandSkillHandler.FIRE_PUNISH_PERCENT;
        }
        // 法术暴击体系：基础暴击率 25%，暴击伤害 150%
        if (owner.getRandom().nextFloat() < 0.25f) {
            dmg *= 1.5f;
        }
        hit.damage(source, dmg);
        WandSkillHandler.lifestealFrom(owner, dmg);
        // 连击
        float chance = Math.min(0.10f + spell * 0.01f, 0.30f);
        if (this.getWorld().random.nextFloat() < chance && hit.isAlive()) {
            hit.damage(source, dmg);
            WandSkillHandler.lifestealFrom(owner, dmg);
        }

        // 2) 爆炸视觉：粒子 + 声音（不破坏方块）
        if (sw != null) {
            sw.spawnParticles(ParticleTypes.EXPLOSION, center.x, center.y, center.z, 1, 0.0, 0.0, 0.0, 0.0);
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
            sw.spawnParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
            sw.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_GENERIC_EXPLODE,
                    SoundCategory.BLOCKS, 1.0F, 1.0F);
        }

        // 3) 爆炸 AOE：对周围 3 格内怪物造成爆炸魔法伤害（扩散到目标周围的怪）
        if (explosion > 0 && sw != null) {
            // 适配 Spell Power：AOE 爆炸伤害附加火系法术强度 × 2.5
            float boom = (float) (5 + explosion * 0.5)
                    + (float) (SpellPower.getSpellPower(SpellSchools.FIRE, owner).randomValue() * 2.5);
            Box box = new Box(center.x - EXPLOSION_RADIUS, center.y - EXPLOSION_RADIUS, center.z - EXPLOSION_RADIUS, center.x + EXPLOSION_RADIUS, center.y + EXPLOSION_RADIUS, center.z + EXPLOSION_RADIUS);
            List<LivingEntity> nearby = sw.getEntitiesByClass(LivingEntity.class, box,
                    e -> e != owner && e.isAlive() && e instanceof net.minecraft.entity.mob.HostileEntity);
            DamageSource boomSource = owner.getDamageSources().indirectMagic(owner, owner);
            for (LivingEntity e : nearby) {
                // 法术暴击体系：每个目标独立判定 25% 暴击，暴击伤害 150%
                float actual = boom;
                if (owner.getRandom().nextFloat() < 0.25f) {
                    actual *= 1.5f;
                }
                e.damage(boomSource, actual);
                WandSkillHandler.lifestealFrom(owner, actual);
            }
        }
    }

    @Override
    public boolean hasNoGravity() {
        return true;
    }
}
