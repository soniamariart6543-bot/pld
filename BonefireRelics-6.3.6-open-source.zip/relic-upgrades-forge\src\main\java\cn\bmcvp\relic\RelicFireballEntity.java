package cn.bmcvp.relic;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/**
 * 遗物法杖直线火球（v6.3.5+，Forge）：完全直线飞行，指哪儿打哪儿。
 * 命中任意实体生物（非发射者）即爆炸：AOE 魔法伤害扩散到目标周围怪物，不破坏方块。
 * 渲染：relic_fireball.png（火球贴图）。
 */
public class RelicFireballEntity extends AbstractHurtingProjectile {
    /** 发射速度（格/tick）：与 WandSkillHandler.LAUNCH_SPEED 保持一致。 */
    public static final double SPEED = 2.0;
    private static final int MAX_LIFE = 120;        // 120 tick × 2.0 格/tick = 240 格射程
    private static final double EXPLOSION_RADIUS = 3.0;

    private ServerPlayer owner;
    private float baseDamage;
    private int spell;
    private int explosion;
    private int life = MAX_LIFE;

    public RelicFireballEntity(EntityType<? extends AbstractHurtingProjectile> type, Level level) {
        super(type, level);
    }

    /** 直线发射：速度由发射方（WandSkillHandler）按标准抛射物发射机制设置，本类只负责恒定直线飞行。 */
    public RelicFireballEntity(Level level, ServerPlayer owner, float baseDamage, int spell, int explosion) {
        super(RelicEntities.RELIC_FIREBALL.get(), level);
        this.owner = owner;
        this.baseDamage = baseDamage;
        this.spell = spell;
        this.explosion = explosion;
        this.setPos(owner.getX(), owner.getEyeY(), owner.getZ());
        this.setNoGravity(true);
    }

    @Override
    public void tick() {
        // 完全直线：不重定向速度，保持初始方向
        super.tick();
        // 抵消原版抛射物阻力（每 tick ×0.9）：把速度归一化回发射速度，实现恒定速度直线飞行
        Vec3 v = this.getDeltaMovement();
        double len = v.length();
        if (len > 1.0E-4) {
            this.setDeltaMovement(v.scale(SPEED / len));
        }
        if (this.level() instanceof ServerLevel sl) {
            Vec3 p = this.position();
            sl.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
            sl.sendParticles(ParticleTypes.SMALL_FLAME, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
        }
        if (--life <= 0) {
            discard();
        }
    }

    /** 命中任意实体生物（非发射者）即触发爆炸。 */
    @Override
    protected boolean canHitEntity(Entity entity) {
        return entity instanceof LivingEntity le && le != owner && le.isAlive();
    }

    /** 命中生物：对目标造成法伤，并在目标位置产生爆炸（AOE 魔法伤害扩散周围怪物，不破坏方块）。 */
    @Override
    protected void onHitEntity(EntityHitResult hitResult) {
        if (!(hitResult.getEntity() instanceof LivingEntity hit) || owner == null) {
            this.discard();
            return;
        }
        explodeAt(hit);
        this.discard();
    }

    /** 撞墙：直接消失（不爆炸、不破坏方块）。 */
    @Override
    protected void onHitBlock(BlockHitResult hitResult) {
        this.discard();
    }

    /** 爆炸结算：目标受法伤（基础 10 + 法术强度，+火罚+连击+吸血）；对周围 3 格内怪物造成爆炸 AOE 魔法伤害。 */
    private void explodeAt(LivingEntity hit) {
        if (owner == null) {
            return;
        }
        ServerLevel sl = this.level() instanceof ServerLevel s ? s : null;
        Vec3 center = hit.position().add(0, hit.getBbHeight() / 2, 0);

        // 1) 直接命中目标：法伤结算（火罚 + 连击 + 吸血）
        DamageSource source = owner.damageSources().indirectMagic(owner, owner);
        float dmg = baseDamage;
        if (spell >= WandSkillHandler.FIRE_PUNISH_SPELL) {
            dmg += hit.getHealth() * WandSkillHandler.FIRE_PUNISH_PERCENT;
        }
        hit.hurt(source, dmg);
        WandSkillHandler.lifestealFrom(owner, dmg);
        float chance = Math.min(0.10f + spell * 0.01f, 0.30f);
        if (this.random.nextFloat() < chance && hit.isAlive()) {
            hit.hurt(source, dmg);
            WandSkillHandler.lifestealFrom(owner, dmg);
        }

        // 2) 爆炸视觉：粒子 + 声音（不破坏方块）
        if (sl != null) {
            sl.sendParticles(ParticleTypes.EXPLOSION, center.x, center.y, center.z, 1, 0.0, 0.0, 0.0, 0.0);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 16, 1.2, 1.2, 1.2, 0.02);
            sl.sendParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 24, 1.5, 1.5, 1.5, 0.05);
            sl.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.0F, 1.0F);
        }

        // 3) 爆炸 AOE：对周围 3 格内怪物造成爆炸魔法伤害（扩散到目标周围的怪）
        if (explosion > 0 && sl != null) {
            float boom = (float) (5 + explosion * 0.5);
            AABB box = new AABB(center.x - EXPLOSION_RADIUS, center.y - EXPLOSION_RADIUS, center.z - EXPLOSION_RADIUS,
                    center.x + EXPLOSION_RADIUS, center.y + EXPLOSION_RADIUS, center.z + EXPLOSION_RADIUS);
            List<LivingEntity> nearby = sl.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e != owner && e.isAlive() && e instanceof Monster);
            DamageSource boomSource = owner.damageSources().indirectMagic(owner, owner);
            for (LivingEntity e : nearby) {
                e.hurt(boomSource, boom);
                WandSkillHandler.lifestealFrom(owner, boom);
            }
        }
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }
}
