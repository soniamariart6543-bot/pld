package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 战利品骨头技能「骨火」（v6.2，Forge）：每攻击命中 3 次触发一次，
 * 对当前命中目标 + 附近最近的至多 3 只怪物造成 8 点范围魔法伤害，并播放火焰粒子。
 * 全部服务端权威；技能自身的魔法伤害不计入命中计数，避免无限触发。
 */
public final class BoneSkillHandler {
    public static final int HITS_PER_CAST = 3;
    public static final double SKILL_RADIUS = 6.0;
    public static final float BASE_SKILL_DAMAGE = 8.0f;
    public static final float DAMAGE_PER_BONE_LEVEL = 1.0f;
    public static final float MAX_SKILL_DAMAGE = 20.0f;
    /** 秒杀：火焰附加 II 的骨头攻击时 1.2% 概率将本次伤害提升至 999。 */
    public static final float INSTANT_KILL_CHANCE = 0.012f;
    public static final float INSTANT_KILL_DAMAGE = 999.0f;
    /** 骨裂：触发攻击力阈值（9 + 伤害等级）与附加目标当前生命值百分比。 */
    public static final int BONE_CRACK_ATTACK_THRESHOLD = 20;
    public static final float BONE_CRACK_PERCENT = 0.08f;
    private static final int MAX_TARGETS = 3;
    private static final Map<ServerPlayer, Integer> HIT_COUNTS = new WeakHashMap<>();
    /** 技能施放中重入保护：技能自身造成的伤害不再进入命中计数（防无限递归）。 */
    private static boolean castingSkill;

    private BoneSkillHandler() {
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target == player || !target.isAlive()) {
            return;
        }
        // 技能自身的魔法伤害不计入命中，防止触发循环（indirectMagic 为 INDIRECT_MAGIC 类型）
        if (castingSkill || event.getSource().is(DamageTypes.MAGIC) || event.getSource().is(DamageTypes.INDIRECT_MAGIC)) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            return;
        }
        int hits = HIT_COUNTS.merge(player, 1, Integer::sum);
        if (hits >= HITS_PER_CAST) {
            HIT_COUNTS.put(player, 0);
            trigger(player, target);
        }
    }

    /** 秒杀（护甲结算前）：火焰附加 II 的骨头攻击时 1.2% 概率将本次伤害提升至 999。 */
    // HIGH 优先级：先于吸血等监听器设置伤害，保证其他监听器读取到 999 而非原始值
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target == player || target instanceof Player || !target.isAlive()) {
            return;
        }
        // 骨火技能自身的魔法伤害不触发秒杀
        if (castingSkill || event.getSource().is(DamageTypes.MAGIC) || event.getSource().is(DamageTypes.INDIRECT_MAGIC)) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)) {
            return;
        }
        // 秒杀：火焰附加 II + 1.2% 概率 -> 999（先于骨裂判定）
        if (RelicService.value(stack, "fire") == 2 && player.getRandom().nextFloat() < INSTANT_KILL_CHANCE) {
            event.setAmount(INSTANT_KILL_DAMAGE);
            if (target.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.FLAME,
                        target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                        40, 0.6, 0.5, 0.6, 0.1);
            }
            return;
        }
        // 骨裂（v6.3.4）：攻击力（9+伤害等级）>= 20 后，每次攻击附加 8% 目标当前生命值伤害
        if (9 + RelicService.value(stack, "damage") >= BONE_CRACK_ATTACK_THRESHOLD) {
            event.setAmount(event.getAmount() + target.getHealth() * BONE_CRACK_PERCENT);
        }
    }

    /** 触发骨火：选取最近至多 3 只怪物（无其他怪物时打当前目标），造成 8 点魔法伤害并播放火焰粒子。 */
    private static void trigger(ServerPlayer player, LivingEntity hitTarget) {
        ServerLevel level = player.serverLevel();
        List<LivingEntity> candidates = new ArrayList<>();
        if (hitTarget instanceof Monster) {
            candidates.add(hitTarget);
        }
        AABB box = hitTarget.getBoundingBox().inflate(SKILL_RADIUS);
        for (Entity entity : level.getEntitiesOfClass(Monster.class, box, (Monster e) -> e != hitTarget && e.isAlive())) {
            candidates.add((LivingEntity) entity);
        }
        if (candidates.isEmpty()) {
            // 附近没有怪物：只打当前命中目标
            candidates.add(hitTarget);
        }
        candidates.sort(Comparator.comparingDouble(e -> e.distanceToSqr(hitTarget)));
        int count = Math.min(MAX_TARGETS, candidates.size());
        float skillDamage = currentSkillDamage(player);
        DamageSource source = player.damageSources().indirectMagic(player, player);
        castingSkill = true;
        try {
            for (int i = 0; i < count; i++) {
                LivingEntity target = candidates.get(i);
                target.hurt(source, skillDamage);
                level.sendParticles(ParticleTypes.FLAME,
                        target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                        24, 0.5, 0.4, 0.5, 0.05);
            }
        } finally {
            castingSkill = false;
        }
    }

    /** 骨火伤害成长：基础 8 点 + 骨头伤害等级（攻击力-9）每级 +1，上限 20 点。 */
    private static float currentSkillDamage(ServerPlayer player) {
        ItemStack stack = player.getMainHandItem();
        int damageLevel = RelicService.isRelic(stack, UpgradeDefinition.RelicType.BONE)
                ? RelicService.value(stack, "damage") : 0;
        return Math.min(BASE_SKILL_DAMAGE + damageLevel * DAMAGE_PER_BONE_LEVEL, MAX_SKILL_DAMAGE);
    }
}
