package cn.bmcvp.relic;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Forge SimpleChannel 网络：升级请求 / 创造发放请求 / 结果回执。 */
public final class RelicNetworking {
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BmcvpRelicUpgradesMod.MODID, "main"),
            () -> "1", "1"::equals, "1"::equals);

    private static int nextId;

    private RelicNetworking() {
    }

    public static void register() {
        CHANNEL.registerMessage(nextId++, UpgradeRequestPacket.class,
                UpgradeRequestPacket::encode, UpgradeRequestPacket::decode, UpgradeRequestPacket::handle);
        CHANNEL.registerMessage(nextId++, GrantRequestPacket.class,
                GrantRequestPacket::encode, GrantRequestPacket::decode, GrantRequestPacket::handle);
        CHANNEL.registerMessage(nextId++, ResultPacket.class,
                ResultPacket::encode, ResultPacket::decode, ResultPacket::handle);
        CHANNEL.registerMessage(nextId++, WandSwingPacket.class,
                WandSwingPacket::encode, WandSwingPacket::decode, WandSwingPacket::handle);
        CHANNEL.registerMessage(nextId++, WandSwitchPacket.class,
                WandSwitchPacket::encode, WandSwitchPacket::decode, WandSwitchPacket::handle);
    }

    public static void sendToServer(Object packet) {
        CHANNEL.sendToServer(packet);
    }

    public static void sendToPlayer(ServerPlayer player, Object packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    /** 客户端 → 服务端：升级请求（路线 id + 骨甲部位槽位）。 */
    public record UpgradeRequestPacket(String id, int slot) {
        public static void encode(UpgradeRequestPacket packet, FriendlyByteBuf buf) {
            buf.writeUtf(packet.id(), BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH);
            buf.writeInt(packet.slot());
        }

        public static UpgradeRequestPacket decode(FriendlyByteBuf buf) {
            return new UpgradeRequestPacket(buf.readUtf(BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH), buf.readInt());
        }

        public static void handle(UpgradeRequestPacket packet, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) {
                    return;
                }
                String result = RelicService.tryUpgrade(player, packet.id(), packet.slot());
                RelicNetworking.sendToPlayer(player, new ResultPacket(result));
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /** 客户端 → 服务端：创造模式发放请求（pickaxe / bone / bone_armor）。 */
    public record GrantRequestPacket(String relic) {
        public static void encode(GrantRequestPacket packet, FriendlyByteBuf buf) {
            buf.writeUtf(packet.relic(), BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH);
        }

        public static GrantRequestPacket decode(FriendlyByteBuf buf) {
            return new GrantRequestPacket(buf.readUtf(BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH));
        }

        public static void handle(GrantRequestPacket packet, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) {
                    return;
                }
                BmcvpRelicUpgradesMod.grantCreative(player, packet.relic());
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /** 客户端 → 服务端：法杖空挥（左键无目标时释放火球）。 */
    public record WandSwingPacket() {
        public static void encode(WandSwingPacket packet, FriendlyByteBuf buf) {
        }

        public static WandSwingPacket decode(FriendlyByteBuf buf) {
            return new WandSwingPacket();
        }

        public static void handle(WandSwingPacket packet, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) {
                    return;
                }
                WandSkillHandler.fireSwing(player);
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /** 客户端 → 服务端：骨头 ⇄ 法杖切换（物品本体互换）。 */
    public record WandSwitchPacket() {
        public static void encode(WandSwitchPacket packet, FriendlyByteBuf buf) {
        }

        public static WandSwitchPacket decode(FriendlyByteBuf buf) {
            return new WandSwitchPacket();
        }

        public static void handle(WandSwitchPacket packet, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) {
                    return;
                }
                String result = RelicService.switchRelic(player);
                RelicNetworking.sendToPlayer(player, new ResultPacket(result));
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /** 服务端 → 客户端：升级结果文本。 */
    public record ResultPacket(String message) {
        public static void encode(ResultPacket packet, FriendlyByteBuf buf) {
            buf.writeUtf(packet.message(), BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH);
        }

        public static ResultPacket decode(FriendlyByteBuf buf) {
            return new ResultPacket(buf.readUtf(BmcvpRelicUpgradesMod.PACKET_STRING_MAX_LENGTH));
        }

        public static void handle(ResultPacket packet, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                if (ctx.get().getDirection().getReceptionSide().isClient()) {
                    cn.bmcvp.relic.client.RelicUpgradeScreen.receiveServerResult(packet.message());
                }
            });
            ctx.get().setPacketHandled(true);
        }
    }
}
