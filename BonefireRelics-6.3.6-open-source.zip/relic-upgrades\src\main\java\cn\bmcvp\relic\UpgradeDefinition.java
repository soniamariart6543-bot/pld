package cn.bmcvp.relic;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/**
 * 升级树定义（纯数据）。服务器与客户端共用，用于驱动升级界面与服务器校验。
 *
 * <p>记录字段在多类遗物间语义复用（-1 表示「不检查 / 不修改」）：</p>
 * <ul>
 *   <li>{@code materialTier}：镐 / 金属甲的材料等级（tier 0..6）</li>
 *   <li>{@code efficiency}：镐的效率 / 护甲的保护</li>
 *   <li>{@code fortune}：镐的时运 / 护甲的韧性</li>
 *   <li>{@code fireAspect}：骨头的火焰附加 / 护甲的荆棘</li>
 *   <li>{@code looting}：骨头的抢夺 / 护甲的保护家族附魔类型（0=无,1=火焰,2=爆炸,3=弹射物）</li>
 *   <li>{@code boneDamage}：骨头的伤害阶段 / 护甲的保护家族附魔等级</li>
 * </ul>
 */
public record UpgradeDefinition(String id, String title, RelicType relic, List<Cost> costs,
                                int experienceLevels, Requirement requirement, Effect effect) {

    /** 材料路线唯一标识（镐 7 级）。 */
    public static final int PICKAXE_TIER_MAX = 6;

    private static Cost c(Item item, int count) {
        // 材料全部减半（最低保留 1 个）
        return new Cost(item, Math.max(1, count / 2));
    }

    private static Requirement r(int tier, int efficiency, int fortune, int fire, int looting, int damage) {
        return new Requirement(tier, efficiency, fortune, fire, looting, damage, -1, -1);
    }

    private static Requirement r(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor) {
        return new Requirement(tier, efficiency, fortune, fire, looting, damage, armor, -1);
    }

    /** 8 参前置：额外携带爆炸（explosion）槽，用于法杖爆炸属性升级。 */
    private static Requirement r8(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor, int explosion) {
        return new Requirement(tier, efficiency, fortune, fire, looting, damage, armor, explosion);
    }

    private static Effect x(int tier, int efficiency, int fortune, int fire, int looting, int damage) {
        return new Effect(tier, efficiency, fortune, fire, looting, damage, -1, -1);
    }

    private static Effect x(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor) {
        return new Effect(tier, efficiency, fortune, fire, looting, damage, armor, -1);
    }

    /** 8 参效果：额外携带爆炸（explosion）槽，用于法杖爆炸属性升级。 */
    private static Effect x8(int tier, int efficiency, int fortune, int fire, int looting, int damage, int armor, int explosion) {
        return new Effect(tier, efficiency, fortune, fire, looting, damage, armor, explosion);
    }

    private static String roman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    // =====================================================================
    // 辅助：镐 / 骨甲 的材质升级
    // =====================================================================
    private static UpgradeDefinition pickaxeMaterial(String id, String title, int from, int to, int experience, List<Cost> costs) {
        return new UpgradeDefinition(id, title, RelicType.PICKAXE, costs, experience,
                r(from, -1, -1, -1, -1, -1), x(to, -1, -1, -1, -1, -1));
    }

    private static UpgradeDefinition boneArmorMaterial(String id, String title, int from, int to, int experience, List<Cost> costs) {
        return new UpgradeDefinition(id, title, RelicType.BONE_ARMOR, costs, experience,
                r(from, -1, -1, -1, -1, -1), x(to, -1, -1, -1, -1, -1));
    }

    // =====================================================================
    // 护甲属性升级生成器（金属甲 / 骨甲共用，仅 RelicType 与 id 前缀不同）
    // =====================================================================
    private static void addArmorAttributes(List<UpgradeDefinition> routes, RelicType type, String prefix, String titlePrefix) {
        // 保护（Protection）1 → 5，对标镐的效率线
        int[] protExp = {4, 8, 14, 22};
        for (int level = 2; level <= 5; level++) {
            int cost = 16 << (level - 2);
            routes.add(new UpgradeDefinition(prefix + "prot" + level, titlePrefix + "保护 " + roman(level), type,
                    List.of(c(Items.LAPIS_LAZULI, cost), c(Items.REDSTONE, cost), c(Items.IRON_NUGGET, cost * 2)),
                    protExp[level - 2],
                    r(-1, level - 1, -1, -1, -1, -1), x(-1, level, -1, -1, -1, -1)));
        }
        // 韧性（Toughness）1 → 10，对标镐的时运线
        int[] toughExp = {6, 12, 18, 24};
        List<List<Cost>> toughCosts = List.of(
                List.of(c(Items.LAPIS_LAZULI, 10), c(Items.EMERALD, 4), c(Items.DIAMOND, 1)),
                List.of(c(Items.LAPIS_LAZULI, 20), c(Items.EMERALD, 8), c(Items.DIAMOND, 2)),
                List.of(c(Items.LAPIS_LAZULI, 40), c(Items.EMERALD, 16), c(Items.DIAMOND, 4)),
                List.of(c(Items.LAPIS_LAZULI, 80), c(Items.EMERALD, 32), c(Items.DIAMOND, 8)));
        for (int level = 2; level <= 10; level++) {
            int index = Math.min(level, 5) - 2;
            routes.add(new UpgradeDefinition(prefix + "tough" + level, titlePrefix + "韧性 " + roman(level), type,
                    toughCosts.get(index), toughExp[index],
                    r(-1, -1, level - 1, -1, -1, -1), x(-1, -1, level, -1, -1, -1)));
        }
        // 荆棘（Thorns）1 → 3
        routes.add(new UpgradeDefinition(prefix + "thorn2", titlePrefix + "荆棘 II", type,
                List.of(c(Items.LAPIS_LAZULI, 32), c(Items.LEATHER, 16), c(Items.BLAZE_POWDER, 8)),
                8, r(-1, -1, -1, 1, -1, -1), x(-1, -1, -1, 2, -1, -1)));
        routes.add(new UpgradeDefinition(prefix + "thorn3", titlePrefix + "荆棘 III", type,
                List.of(c(Items.LAPIS_LAZULI, 64), c(Items.LEATHER, 32), c(Items.BLAZE_POWDER, 16)),
                16, r(-1, -1, -1, 2, -1, -1), x(-1, -1, -1, 3, -1, -1)));
        // 护甲值（Armor）0 → 50，每级 +1 护甲值，每 10 级一档成本
        int[] armorExp = {4, 6, 8, 10, 12};
        List<List<Cost>> armorCosts = List.of(
                List.of(c(Items.LAPIS_LAZULI, 8), c(Items.EMERALD, 4), c(Items.DIAMOND, 1)),
                List.of(c(Items.LAPIS_LAZULI, 16), c(Items.EMERALD, 8), c(Items.DIAMOND, 2)),
                List.of(c(Items.LAPIS_LAZULI, 32), c(Items.EMERALD, 16), c(Items.DIAMOND, 4)),
                List.of(c(Items.LAPIS_LAZULI, 64), c(Items.EMERALD, 32), c(Items.DIAMOND, 8)),
                List.of(c(Items.LAPIS_LAZULI, 128), c(Items.EMERALD, 64), c(Items.DIAMOND, 16)));
        for (int level = 1; level <= 50; level++) {
            int costIndex = (level - 1) / 10;
            routes.add(new UpgradeDefinition(prefix + "armor" + level, titlePrefix + "护甲值 +" + level, type,
                    armorCosts.get(costIndex), armorExp[costIndex],
                    r(-1, -1, -1, -1, -1, -1, level - 1), x(-1, -1, -1, -1, -1, -1, level)));
        }
        // 保护家族附魔（火焰 / 爆炸 / 弹射物 三选一，最高 5 级）
        addProtectionFamily(routes, type, prefix, titlePrefix, 1, "fp", "火焰保护");
        addProtectionFamily(routes, type, prefix, titlePrefix, 2, "bp", "爆炸保护");
        addProtectionFamily(routes, type, prefix, titlePrefix, 3, "pp", "弹射物保护");
    }

    private static void addProtectionFamily(List<UpgradeDefinition> routes, RelicType type, String prefix,
                                            String titlePrefix, int ptype, String key, String name) {
        int[] exp = {5, 8, 11, 14, 17};
        for (int level = 1; level <= 5; level++) {
            int cost = 8 << (level - 1);
            // 第一级（I）无需材料，仅消耗经验；后续各级按成本表收取
            List<Cost> costs = level == 1
                    ? List.of()
                    : List.of(c(Items.LAPIS_LAZULI, cost), c(Items.GOLD_INGOT, cost / 2), c(Items.RABBIT_FOOT, level));
            routes.add(new UpgradeDefinition(prefix + key + level, titlePrefix + name + " " + roman(level), type,
                    costs, exp[level - 1],
                    // 前置：仅校验 plevel（boneDamage 槽）= level-1；ptype 由界面层限制，服务器以等级锁定家族
                    r(-1, -1, -1, -1, -1, level - 1),
                    x(-1, -1, -1, -1, ptype, level)));
        }
    }

    public static List<UpgradeDefinition> all() {
        return Catalog.ALL;
    }

    public static UpgradeDefinition byId(String id) {
        return all().stream().filter(route -> route.id.equals(id)).findFirst().orElse(null);
    }

    public enum RelicType {
        PICKAXE,
        BONE,
        BONE_ARMOR,
        WAND
    }

    public record Requirement(int materialTier, int efficiency, int fortune, int fireAspect, int looting, int boneDamage, int armor, int explosion) {
    }

    public record Effect(int materialTier, int efficiency, int fortune, int fireAspect, int looting, int boneDamage, int armor, int explosion) {
    }

    public record Cost(Item item, int count) {
    }

    private static final class Catalog {
        private static final List<UpgradeDefinition> ALL = create();

        private Catalog() {
        }

        private static List<UpgradeDefinition> create() {
            ArrayList<UpgradeDefinition> routes = new ArrayList<>();

            // ================= 镐：材料路线（7 级） =================
            routes.add(pickaxeMaterial("m1", "材质 M1：钻石覆层", 0, 1, 8,
                    List.of(c(Items.DIAMOND, 6), c(Items.IRON_INGOT, 32), c(Items.OBSIDIAN, 8), c(Items.AMETHYST_SHARD, 16))));
            routes.add(pickaxeMaterial("m2", "材质 M2：下界合金铸体", 1, 2, 18,
                    List.of(c(Items.NETHERITE_INGOT, 1), c(Items.ANCIENT_DEBRIS, 4), c(Items.DIAMOND, 12),
                            c(Items.BLAZE_ROD, 8), c(Items.MAGMA_CREAM, 16), c(Items.ECHO_SHARD, 1))));
            routes.add(pickaxeMaterial("m3", "材质 M3：下界合金·铁", 2, 3, 24,
                    List.of(c(Items.NETHERITE_INGOT, 2), c(Items.IRON_BLOCK, 16), c(Items.GOLD_INGOT, 16), c(Items.NETHERITE_SCRAP, 4))));
            routes.add(pickaxeMaterial("m4", "材质 M4：下界合金·金", 3, 4, 28,
                    List.of(c(Items.NETHERITE_INGOT, 4), c(Items.GOLD_BLOCK, 16), c(Items.EMERALD, 16), c(Items.NETHERITE_SCRAP, 8))));
            routes.add(pickaxeMaterial("m5", "材质 M5：下界合金·绿宝石", 4, 5, 30,
                    List.of(c(Items.NETHERITE_INGOT, 8), c(Items.EMERALD_BLOCK, 16), c(Items.DIAMOND_BLOCK, 8), c(Items.NETHERITE_BLOCK, 1))));
            routes.add(pickaxeMaterial("m6", "材质 M6：下界合金·钻石", 5, 6, 30,
                    List.of(c(Items.NETHERITE_INGOT, 16), c(Items.DIAMOND_BLOCK, 16), c(Items.NETHERITE_BLOCK, 4),
                            c(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, 1))));

            // ================= 镐：效率 / 时运 =================
            routes.add(new UpgradeDefinition("eff2", "效率 II", RelicType.PICKAXE,
                    List.of(c(Items.LAPIS_LAZULI, 16), c(Items.REDSTONE, 16), c(Items.IRON_NUGGET, 32)), 4,
                    r(-1, 1, -1, -1, -1, -1), x(-1, 2, -1, -1, -1, -1)));
            routes.add(new UpgradeDefinition("eff3", "效率 III", RelicType.PICKAXE,
                    List.of(c(Items.LAPIS_LAZULI, 32), c(Items.REDSTONE, 32), c(Items.IRON_NUGGET, 64)), 8,
                    r(-1, 2, -1, -1, -1, -1), x(-1, 3, -1, -1, -1, -1)));
            routes.add(new UpgradeDefinition("eff4", "效率 IV", RelicType.PICKAXE,
                    List.of(c(Items.LAPIS_LAZULI, 64), c(Items.REDSTONE, 64), c(Items.IRON_NUGGET, 128)), 14,
                    r(-1, 3, -1, -1, -1, -1), x(-1, 4, -1, -1, -1, -1)));
            routes.add(new UpgradeDefinition("eff5", "效率 V", RelicType.PICKAXE,
                    List.of(c(Items.LAPIS_LAZULI, 128), c(Items.REDSTONE, 128), c(Items.IRON_NUGGET, 256)), 22,
                    r(-1, 4, -1, -1, -1, -1), x(-1, 5, -1, -1, -1, -1)));

            List<List<Cost>> fortuneCosts = List.of(
                    List.of(c(Items.LAPIS_LAZULI, 10), c(Items.EMERALD, 4), c(Items.DIAMOND, 1)),
                    List.of(c(Items.LAPIS_LAZULI, 20), c(Items.EMERALD, 8), c(Items.DIAMOND, 2)),
                    List.of(c(Items.LAPIS_LAZULI, 40), c(Items.EMERALD, 16), c(Items.DIAMOND, 4)),
                    List.of(c(Items.LAPIS_LAZULI, 80), c(Items.EMERALD, 32), c(Items.DIAMOND, 8)));
            int[] fortuneExperience = {6, 12, 18, 24};
            for (int level = 2; level <= 10; level++) {
                int index = Math.min(level, 5) - 2;
                routes.add(new UpgradeDefinition("fortune" + level, "时运 " + roman(level), RelicType.PICKAXE,
                        fortuneCosts.get(index), fortuneExperience[index],
                        r(-1, -1, level - 1, -1, -1, -1), x(-1, -1, level, -1, -1, -1)));
            }

            // ================= 骨头：伤害 / 火焰 / 抢夺 =================
            routes.add(new UpgradeDefinition("d1", "伤害 D1：主手 +10", RelicType.BONE,
                    List.of(c(Items.ROTTEN_FLESH, 64), c(Items.STRING, 32)), 5,
                    r(-1, -1, -1, -1, -1, 0), x(-1, -1, -1, -1, -1, 1)));
            routes.add(new UpgradeDefinition("d2", "伤害 D2：主手 +11", RelicType.BONE,
                    List.of(c(Items.ROTTEN_FLESH, 128), c(Items.SPIDER_EYE, 32), c(Items.FERMENTED_SPIDER_EYE, 8)), 11,
                    r(-1, -1, -1, -1, -1, 1), x(-1, -1, -1, -1, -1, 2)));
            routes.add(new UpgradeDefinition("d3", "伤害 D3：主手 +12", RelicType.BONE,
                    List.of(c(Items.GUNPOWDER, 64), c(Items.SLIME_BALL, 32), c(Items.PHANTOM_MEMBRANE, 8)), 20,
                    r(-1, -1, -1, -1, -1, 2), x(-1, -1, -1, -1, -1, 3)));
            List<Cost> dragonBoneFormula = List.of(c(Items.BONE, 256), c(Items.ROTTEN_FLESH, 256),
                    c(Items.BLAZE_POWDER, 64), c(Items.DRAGON_BREATH, 8));
            for (int stage = 4; stage <= 41; stage++) {
                int bonusDamage = 9 + stage;
                routes.add(new UpgradeDefinition("d" + stage, "伤害 D" + stage + "：主手 +" + bonusDamage, RelicType.BONE,
                        dragonBoneFormula, 30,
                        r(-1, -1, -1, -1, -1, stage - 1), x(-1, -1, -1, -1, -1, stage)));
            }
            routes.add(new UpgradeDefinition("fire2", "火焰附加 II", RelicType.BONE,
                    List.of(c(Items.LAPIS_LAZULI, 32), c(Items.LEATHER, 16), c(Items.BLAZE_POWDER, 8)), 8,
                    r(-1, -1, -1, 1, -1, -1), x(-1, -1, -1, 2, -1, -1)));
            List<List<Cost>> lootCosts = List.of(
                    List.of(c(Items.LAPIS_LAZULI, 32), c(Items.EMERALD, 16), c(Items.RABBIT_FOOT, 4)),
                    List.of(c(Items.LAPIS_LAZULI, 64), c(Items.EMERALD, 32), c(Items.RABBIT_FOOT, 8)),
                    List.of(c(Items.LAPIS_LAZULI, 128), c(Items.EMERALD, 64), c(Items.RABBIT_FOOT, 16)),
                    List.of(c(Items.LAPIS_LAZULI, 256), c(Items.EMERALD, 128), c(Items.RABBIT_FOOT, 32)));
            int[] lootExperience = {8, 16, 24, 30};
            for (int level = 2; level <= 10; level++) {
                int index = Math.min(level, 5) - 2;
                routes.add(new UpgradeDefinition("loot" + level, "抢夺 " + roman(level), RelicType.BONE,
                        lootCosts.get(index), lootExperience[index],
                        r(-1, -1, -1, -1, level - 1, -1), x(-1, -1, -1, -1, level, -1)));
            }

            // 吸血（Lifesteal）0 → 10，用 fortune 槽存储；每 2 级一档成本
            int[] lsExp = {6, 10, 14, 18, 22};
            List<List<Cost>> lsCosts = List.of(
                    List.of(c(Items.LAPIS_LAZULI, 16), c(Items.GOLD_INGOT, 8), c(Items.DIAMOND, 1)),
                    List.of(c(Items.LAPIS_LAZULI, 32), c(Items.GOLD_INGOT, 16), c(Items.DIAMOND, 2)),
                    List.of(c(Items.LAPIS_LAZULI, 64), c(Items.GOLD_INGOT, 32), c(Items.DIAMOND, 4)),
                    List.of(c(Items.LAPIS_LAZULI, 128), c(Items.GOLD_INGOT, 64), c(Items.DIAMOND, 8)),
                    List.of(c(Items.LAPIS_LAZULI, 256), c(Items.GOLD_INGOT, 128), c(Items.DIAMOND, 16)));
            for (int level = 1; level <= 10; level++) {
                int costIndex = (level - 1) / 2;
                routes.add(new UpgradeDefinition("lifesteal" + level, "吸血 " + roman(level), RelicType.BONE,
                        lsCosts.get(costIndex), lsExp[costIndex],
                        r(-1, -1, level - 1, -1, -1, -1), x(-1, -1, level, -1, -1, -1)));
            }

            // ================= 骨甲：材质（3 阶）+ 属性 =================
            routes.add(boneArmorMaterial("bam1", "材质 B1：钻石骨甲（护甲值 +5）", 0, 1, 8,
                    List.of(c(Items.DIAMOND, 6), c(Items.IRON_INGOT, 32), c(Items.OBSIDIAN, 8))));
            routes.add(boneArmorMaterial("bam2", "材质 B2：下界合金骨甲（护甲值 +5）", 1, 2, 18,
                    List.of(c(Items.NETHERITE_INGOT, 1), c(Items.ANCIENT_DEBRIS, 4), c(Items.DIAMOND, 12), c(Items.BLAZE_ROD, 8))));
            addArmorAttributes(routes, RelicType.BONE_ARMOR, "ba_", "骨甲·");

            // ================= 魔法法杖：法术强度（0→30）+ 吸血（1→10，与骨棒同曲线） =================
            // 材料机制与骨头相同：法术强度前 12 级分档递进，13 点后材料固定不再变动。
            // 法术强度存 armor 槽（升级为法杖时写入 NBT "spell"）；吸血存 fortune 槽。
            int[] spellExp = {5, 11, 20, 30};
            List<List<Cost>> spellCosts = List.of(
                    List.of(c(Items.BLAZE_POWDER, 32), c(Items.GLOWSTONE_DUST, 16)),
                    List.of(c(Items.BLAZE_POWDER, 64), c(Items.GLOWSTONE_DUST, 32), c(Items.GHAST_TEAR, 8)),
                    List.of(c(Items.MAGMA_CREAM, 64), c(Items.ENDER_PEARL, 16), c(Items.BLAZE_ROD, 32)));
            List<Cost> spellFixed = List.of(c(Items.BLAZE_POWDER, 128), c(Items.GLOWSTONE_DUST, 64), c(Items.ENDER_PEARL, 16));
            for (int level = 1; level <= 30; level++) {
                int costIndex = level <= 12 ? (level - 1) / 4 : 3;
                routes.add(new UpgradeDefinition("spell" + level, "法术强度 +" + level, RelicType.WAND,
                        level <= 12 ? spellCosts.get(costIndex) : spellFixed,
                        costIndex >= 3 ? 30 : spellExp[costIndex],
                        r(-1, -1, -1, -1, -1, -1, level - 1), x(-1, -1, -1, -1, -1, -1, level)));
            }
            // 法杖吸血（1→10）：与骨头吸血同曲线（fortune 槽），每 2 级一档成本
            int[] wlsExp = {6, 10, 14, 18, 22};
            List<List<Cost>> wlsCosts = List.of(
                    List.of(c(Items.LAPIS_LAZULI, 16), c(Items.GOLD_INGOT, 8), c(Items.DIAMOND, 1)),
                    List.of(c(Items.LAPIS_LAZULI, 32), c(Items.GOLD_INGOT, 16), c(Items.DIAMOND, 2)),
                    List.of(c(Items.LAPIS_LAZULI, 64), c(Items.GOLD_INGOT, 32), c(Items.DIAMOND, 4)),
                    List.of(c(Items.LAPIS_LAZULI, 128), c(Items.GOLD_INGOT, 64), c(Items.DIAMOND, 8)),
                    List.of(c(Items.LAPIS_LAZULI, 256), c(Items.GOLD_INGOT, 128), c(Items.DIAMOND, 16)));
            for (int level = 1; level <= 10; level++) {
                int costIndex = (level - 1) / 2;
                routes.add(new UpgradeDefinition("wlifesteal" + level, "吸血 " + roman(level), RelicType.WAND,
                        wlsCosts.get(costIndex), wlsExp[costIndex],
                        r(-1, -1, level - 1, -1, -1, -1), x(-1, -1, level, -1, -1, -1)));
            }
            // 法杖爆炸（0→10）：命中爆炸 AOE 魔法伤害 = 5 + 等级×0.5（上限 10 点），存 NBT "explosion"
            int[] explExp = {6, 10, 14, 18, 22, 26, 30, 34, 38, 42};
            List<List<Cost>> explCosts = List.of(
                    List.of(c(Items.GUNPOWDER, 16), c(Items.BLAZE_POWDER, 8)),
                    List.of(c(Items.GUNPOWDER, 32), c(Items.BLAZE_POWDER, 16), c(Items.GHAST_TEAR, 4)),
                    List.of(c(Items.GUNPOWDER, 64), c(Items.MAGMA_CREAM, 16), c(Items.ENDER_PEARL, 8)),
                    List.of(c(Items.GUNPOWDER, 128), c(Items.MAGMA_CREAM, 32), c(Items.ENDER_PEARL, 16)),
                    List.of(c(Items.GUNPOWDER, 256), c(Items.MAGMA_CREAM, 64), c(Items.ENDER_PEARL, 32)));
            for (int level = 1; level <= 10; level++) {
                int costIndex = (level - 1) / 2;
                routes.add(new UpgradeDefinition("expl" + level, "爆炸 " + roman(level), RelicType.WAND,
                        explCosts.get(costIndex), explExp[costIndex],
                        r8(-1, -1, -1, -1, -1, -1, -1, level - 1),
                        x8(-1, -1, -1, -1, -1, -1, -1, level)));
            }

            return List.copyOf(routes);
        }
    }
}
