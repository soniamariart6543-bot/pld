﻿# ghrelease.ps1 - GitHub repo / release lookup without guessing URLs (ASCII only)
#
# Why: github.com and raw.githubusercontent.com time out from this machine. api.github.com works
# directly and is fast, so resolve the facts there first instead of trying several URLs.
#
# Usage:
#   powershell -File ghrelease.ps1 -Repo owner/name                 # latest release + recent tags
#   powershell -File ghrelease.ps1 -Repo owner/name -All            # list recent releases
#   powershell -File ghrelease.ps1 -Repo owner/name -SinceDays 3    # only releases older than N days
#   powershell -File ghrelease.ps1 -Repo owner/name -Path <file>    # print working raw URLs for a file
#   powershell -File ghrelease.ps1 -Repo owner/name -Asset <name>   # print working download URLs
param(
    [Parameter(Mandatory=$true)][string]$Repo,
    [switch]$All,
    [int]$SinceDays = 0,
    [string]$Path,
    [string]$Asset
)
$ErrorActionPreference = 'Stop'
$headers = @{ 'User-Agent' = 'dsh-ghrelease'; 'Accept' = 'application/vnd.github+json' }

function Get-Json([string]$url) {
    try { return Invoke-RestMethod -Uri $url -TimeoutSec 20 -Headers $headers }
    catch { Write-Host ('API FAIL ' + $url + ' -> ' + $_.Exception.Message); exit 1 }
}

function Days-Ago([string]$iso) {
    if (-not $iso) { return $null }
    try { return [int]((Get-Date).ToUniversalTime() - ([datetime]$iso).ToUniversalTime()).TotalDays } catch { return $null }
}

$info = Get-Json ('https://api.github.com/repos/' + $Repo)
Write-Host ('repo      : ' + $info.full_name + '  ' + $info.description)
Write-Host ('default   : ' + $info.default_branch + '   stars ' + $info.stargazers_count + '   pushed ' + ([datetime]$info.pushed_at).ToUniversalTime().ToString('yyyy-MM-dd'))
Write-Host ('tarball   : https://ghfast.top/https://github.com/' + $info.full_name + '/archive/refs/heads/' + $info.default_branch + '.tar.gz')

if ($Path) {
    $clean = $Path.TrimStart('/')
    Write-Host ''
    Write-Host ('raw URL candidates for ' + $clean + ' (first one that answers wins):')
    Write-Host ('  https://raw.githubusercontent.com/' + $info.full_name + '/' + $info.default_branch + '/' + $clean)
    Write-Host ('  https://ghfast.top/https://raw.githubusercontent.com/' + $info.full_name + '/' + $info.default_branch + '/' + $clean)
    Write-Host ('  https://gh-proxy.com/https://raw.githubusercontent.com/' + $info.full_name + '/' + $info.default_branch + '/' + $clean)
    Write-Host ('  https://cdn.jsdelivr.net/gh/' + $info.full_name + '@' + $info.default_branch + '/' + $clean)
    Write-Host 'or simply: pwsh -File C:\Users\Lenovo\.dsh\ghfetch.ps1 -Url <first candidate> -Out <file>'
}

if ($Asset) {
    Write-Host ''
    Write-Host ('asset URL candidates for ' + $Asset + ':')
    Write-Host ('  https://ghfast.top/https://github.com/' + $info.full_name + '/releases/latest/download/' + $Asset)
    Write-Host ('  https://gh-proxy.com/https://github.com/' + $info.full_name + '/releases/latest/download/' + $Asset)
}

Write-Host ''
if ($All) {
    $releases = Get-Json ('https://api.github.com/repos/' + $Repo + '/releases?per_page=10')
} else {
    $one = Get-Json ('https://api.github.com/repos/' + $Repo + '/releases/latest')
    $releases = @($one)
}
foreach ($rel in $releases) {
    $age = Days-Ago $rel.published_at
    $flag = ''
    if ($null -ne $age -and $age -lt 3) { $flag = '   <-- younger than 3 days: observation window, do not install' }
    if ($rel.prerelease) { $flag = ($flag + '   [pre-release]') }
    Write-Host ('release   : ' + $rel.tag_name + '   published ' + ([datetime]$rel.published_at).ToUniversalTime().ToString('yyyy-MM-dd') + '  (' + $age + ' d ago)' + $flag)
    if ($rel.assets -and $rel.assets.Count -gt 0) {
        foreach ($a in $rel.assets) { Write-Host ('    asset : ' + $a.name + '   ' + [int]($a.size / 1024) + ' KB   https://ghfast.top/' + $a.browser_download_url) }
    }
    if ($rel.tarball_url) { Write-Host ('    source: https://ghfast.top/' + $rel.tarball_url) }
}
