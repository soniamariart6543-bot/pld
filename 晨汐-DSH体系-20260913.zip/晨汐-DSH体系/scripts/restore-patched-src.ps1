﻿# restore-patched-src.ps1  (ASCII only - do not add non-ASCII text to this file)
# Re-applies the local (hand-made) patches to the DSH web profile after a
# `pnpm install` / plugin upgrade / reinstall has overwritten them.
#
# Covered artifacts:
#   1. dsh-routing-suite/lib/index.js            <- habit-aware router + 0.1.5 Session shim
#   2. routing-suite preset agent.cordis.yml     <- prefix/suffix persona + work-discipline block
# Both are also registered as pnpm patches (profiles\web\patches\*.patch), this script is the
# manual fallback when pnpm patch application is skipped.
#
# Safe to re-run: every step is idempotent and reports what it changed.
$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Lenovo\.dsh'
$src  = Join-Path $root 'patched-src\dsh-routing-suite'
$nm   = Join-Path $root 'profiles\web\node_modules\dsh-routing-suite'

if (-not (Test-Path $src)) { throw "master copies missing: $src" }

$changed = @()

# 1) plugin entry + anchor module
$stamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
foreach ($f in @('index.js', 'anchor.mjs')) {
    $s = Join-Path $src ('lib\' + $f)
    $d = Join-Path $nm ('lib\' + $f)
    if (-not (Test-Path $s)) { $changed += ('WARN: master copy missing for lib/' + $f); continue }
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path (Split-Path $d) -Force | Out-Null
        Copy-Item -LiteralPath $s -Destination $d -Force
        $changed += ('lib/' + $f + ' (was missing)')
    } else {
        $a = (Get-FileHash -LiteralPath $s -Algorithm SHA256).Hash
        $b = (Get-FileHash -LiteralPath $d -Algorithm SHA256).Hash
        if ($a -ne $b) {
            Copy-Item -LiteralPath $d -Destination ($d + '.pre-restore-' + $stamp) -Force
            Copy-Item -LiteralPath $s -Destination $d -Force
            $changed += ('lib/' + $f + ' (overwritten, old copy kept as .pre-restore-' + $stamp + ')')
        }
    }
}

# 2) plugin-side preset file
$srcPreset = Join-Path $src 'agent.cordis.yml'
$dstPreset = Join-Path $nm 'preset\routing-suite\agent.cordis.yml'
if (Test-Path $dstPreset) {
    $a = (Get-FileHash -LiteralPath $srcPreset -Algorithm SHA256).Hash
    $b = (Get-FileHash -LiteralPath $dstPreset -Algorithm SHA256).Hash
    if ($a -ne $b) {
        Copy-Item -LiteralPath $dstPreset -Destination ($dstPreset + '.pre-restore') -Force
        Copy-Item -LiteralPath $srcPreset -Destination $dstPreset -Force
        $changed += 'preset/routing-suite/agent.cordis.yml'
    }
} else { $changed += 'WARN: preset file not found: ' + $dstPreset }

# 3) user-root preset (takes precedence for the routing-suite preset)
$userPreset = Join-Path $root '.agent-presets\routing-suite\agent.cordis.yml'
if (Test-Path $userPreset) {
    $a = (Get-FileHash -LiteralPath $srcPreset -Algorithm SHA256).Hash
    $b = (Get-FileHash -LiteralPath $userPreset -Algorithm SHA256).Hash
    if ($a -ne $b) {
        Copy-Item -LiteralPath $userPreset -Destination ($userPreset + '.pre-restore') -Force
        Copy-Item -LiteralPath $srcPreset -Destination $userPreset -Force
        $changed += 'user-root .agent-presets/routing-suite/agent.cordis.yml'
    }
} else { $changed += 'WARN: user preset not found: ' + $userPreset }

if ($changed.Count -eq 0) { 'restore-patched-src: nothing to do - all artifacts already match the masters' }
else { 'restore-patched-src: re-applied -> '; $changed | ForEach-Object { '  - ' + $_ } ; 'NOTE: run "dsh web" restart afterwards for the plugin entry to take effect.' }
