﻿# restart-and-verify.ps1  (ASCII only)
# Restarts the DSH web instance so the patched routing plugin is loaded, then
# verifies the plugin actually came up and reports the classifier dry-run.
# Results are appended to ~/.dsh/logs/routing-verify.txt
$ErrorActionPreference = 'Continue'
$root = 'C:\Users\Lenovo\.dsh'
$out = Join-Path $root 'logs\routing-verify.txt'
function W($line) { $line | Out-File -FilePath $out -Append -Encoding UTF8 }
function Say($line) { Write-Host $line; W $line }

W ''
Say ('=== restart+verify ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' ===')
$plugin = Join-Path $root 'profiles\web\node_modules\dsh-routing-suite\lib\index.js'
Say ('plugin mtime : ' + (Get-Item -LiteralPath $plugin).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
Say ('plugin sha16 : ' + (Get-FileHash -LiteralPath $plugin -Algorithm SHA256).Hash.Substring(0, 16).ToUpper())

# 1) restart
Say '--- restarting via restart-dsh.ps1 ---'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'restart-dsh.ps1') | ForEach-Object { Say ('  ' + $_) }

# 2) wait for the port
$alive = $false
for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 2
    $c = Get-NetTCPConnection -LocalPort 3080 -State Listen -ErrorAction SilentlyContinue
    if ($c) { $alive = $true; break }
}
Say ('port 3080 listening: ' + $alive + ' (after ' + (($i + 1) * 2) + 's)')
if (-not $alive) { Say 'ABORT: new instance never came up - check ~/.dsh\logs\boot-failure.txt'; return }

# 3) which process/version is serving now
$pids = (Get-NetTCPConnection -LocalPort 3080 -State Listen -ErrorAction SilentlyContinue).OwningProcess
foreach ($p in ($pids | Select-Object -Unique)) {
    $pr = Get-CimInstance Win32_Process -Filter ("ProcessId = " + $p)
    Say ('pid ' + $p + ' started ' + $pr.CreationDate.ToString('yyyy-MM-dd HH:mm:ss'))
    if ($pr.CommandLine -match '(_npx\\[0-9a-f]+)') { Say ('  launcher dir: ' + $Matches[1]) }
}
Start-Sleep -Seconds 5

# 4) plugin route + classifier dry-run (needs the launch token cookie)
$token = $null
$console = Join-Path $root 'logs\dsh-web-console.log'
if (Test-Path $console) {
    $m = Select-String -LiteralPath $console -Pattern 'token=([A-Za-z0-9_\-\.]+)' -AllMatches |
         Select-Object -Last 1
    if ($m) { $token = $m.Matches[$m.Matches.Count - 1].Groups[1].Value }
}
Say ('launch token found: ' + [bool]$token)
if ($token) {
    try {
        $null = Invoke-WebRequest -Uri ('http://127.0.0.1:3080/?token=' + $token) -SessionVariable sess -TimeoutSec 20 -UseBasicParsing
        foreach ($q in @('status', 'classify?text=' + [uri]::EscapeDataString('遗物mod 7.1.3 裂地没生效'))) {
            try {
                $r = Invoke-WebRequest -Uri ('http://127.0.0.1:3080/routing-suite/api/' + $q) -WebSession $sess -TimeoutSec 20 -UseBasicParsing
                Say ('GET /routing-suite/api/' + $q + ' -> ' + $r.StatusCode)
                Say ('  ' + ($r.Content -replace "`r?`n", ' '))
            } catch { Say ('GET /routing-suite/api/' + $q + ' -> ' + $_.Exception.Message) }
        }
    } catch { Say ('token exchange failed: ' + $_.Exception.Message) }
}
Say '--- plugin errors in the fresh console log (should be none) ---'
if (Test-Path $console) {
    $errs = Select-String -LiteralPath $console -Pattern 'routing-suite' | Select-Object -Last 8
    if ($errs) { $errs | ForEach-Object { Say ('  ' + $_.Line.Trim()) } } else { Say '  (no routing-suite mentions)' }
}
Say '=== done ==='
