﻿# make-pnpm-patch.ps1  (ASCII only - do not add non-ASCII text to this file)
#
# Regenerates a pnpm patch for dsh-routing-suite from:
#   pristine = the npm tarball dsh-routing-suite@0.1.2  (downloaded on demand)
#   patched  = C:\Users\Lenovo\.dsh\patched-src\dsh-routing-suite\lib\*.{js,mjs}
#
# Why this exists: the pnpm patch must apply cleanly after any pnpm install/update, so it has to be
# regenerated from the TRUE pristine package every time the master copies change. Rebuilding it from the
# current node_modules is wrong (that copy is already patched), and a stale/empty patch file silently
# breaks the next `pnpm install`.
#
# Usage: powershell -File make-pnpm-patch.ps1 [-Verify]
#   -Verify : also copy the result into node_modules and syntax-check the module in node.
$ErrorActionPreference = 'Stop'
$dsh      = 'C:\Users\Lenovo\.dsh'
$profile_ = Join-Path $dsh 'profiles\web'
$master   = Join-Path $dsh 'patched-src\dsh-routing-suite\lib'
$pkg      = 'dsh-routing-suite'
$version  = '0.1.2'
$patchOut = Join-Path $profile_ ('patches\' + $pkg + '@' + $version + '.patch')

$work = Join-Path $env:TEMP '_mkpatch_work'
if (Test-Path $work) { Remove-Item -LiteralPath $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null

# 1) pristine tarball from npm (the only trustworthy source of the original file)
Write-Host '[1] fetching pristine tarball from npm ...'
Push-Location $work
# npm writes its notices to stderr; with ErrorActionPreference=Stop PowerShell 5.1 turns that into a
# terminating NativeCommandError, so relax it for this one call.
$eap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$packOut = & npm pack ($pkg + '@' + $version) 2>&1 | Out-String
$ErrorActionPreference = $eap
Pop-Location
$tgz = Get-ChildItem $work -Filter '*.tgz' | Select-Object -First 1
if (-not $tgz) { throw ('npm pack produced no tarball: ' + ($packOut -join ' ')) }
tar -xzf $tgz.FullName -C $work
$pristineLib = Join-Path $work 'package\lib'
if (-not (Test-Path $pristineLib)) { throw 'pristine lib folder missing after extract' }

# 2) git repo: mirror the PACKAGE ROOT (files live under lib/), commit pristine, then overwrite.
#    The repo root MUST equal the package root: pnpm applies a patch relative to the package folder, so
#    paths have to read "lib/index.js". A repo rooted at lib/ yields "a/index.js" and pnpm then dies with
#    "index.js: No such file or directory" - real incident 2026-09-13: the self-check passed anyway because
#    the check step used the same wrong convention, while the registered patch was unusable.
$repo = Join-Path $work 'repo'
$repoLib = Join-Path $repo 'lib'
New-Item -ItemType Directory -Path $repoLib -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $pristineLib 'index.js') -Destination (Join-Path $repoLib 'index.js') -Force
git -C $repo init -q
git -C $repo config core.autocrlf false
git -C $repo add -A
git -C $repo -c user.email=patch@local -c user.name=patch commit -qm pristine

foreach ($f in (Get-ChildItem $master -File)) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $repoLib $f.Name) -Force
}
git -C $repo add -A

# 3) write the patch WITHOUT a BOM and with LF endings (git apply rejects anything else)
$tmpPatch = Join-Path $work 'new.patch'
git -C $repo --no-pager diff --cached --no-color --unified=3 --src-prefix=a/ --dst-prefix=b/ |
    Out-File -LiteralPath $tmpPatch -Encoding utf8
$text = [System.IO.File]::ReadAllText($tmpPatch, [System.Text.Encoding]::UTF8)
if ($text.Length -gt 0 -and [int]$text[0] -eq 0xFEFF) { $text = $text.Substring(1) }
$text = $text.Replace("`r`n", "`n")
if ($text.Trim().Length -eq 0) { throw 'generated patch is empty - refusing to overwrite the registered patch' }
[System.IO.File]::WriteAllText($patchOut, $text, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ('[2] patch written: ' + $patchOut + '  (' + (Get-Item $patchOut).Length + ' bytes)')
(Select-String -LiteralPath $patchOut -Pattern '^diff ' | ForEach-Object { '      ' + $_.Line })

# 4) prove it applies to a fresh pristine PACKAGE copy and reproduces EVERY master file
$chk = Join-Path $work 'check'
$chkLib = Join-Path $chk 'lib'
New-Item -ItemType Directory -Path $chkLib -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $pristineLib 'index.js') -Destination (Join-Path $chkLib 'index.js') -Force
git -C $chk init -q
git -C $chk config core.autocrlf false
git -C $chk apply $patchOut
if ($LASTEXITCODE -ne 0) { throw 'patch does not apply to the pristine package - check the master copies' }
$ok = $true
foreach ($f in (Get-ChildItem $master -File)) {
    $a = (Get-FileHash (Join-Path $chkLib $f.Name) -Algorithm SHA256).Hash
    $b = (Get-FileHash $f.FullName -Algorithm SHA256).Hash
    if ($a -ne $b) { $ok = $false; Write-Host ('      MISMATCH after apply: lib/' + $f.Name) }
}
Write-Host ('[3] applies cleanly; applied files match the masters: ' + $ok)
if (-not $ok) { throw 'applied result differs from the master copy' }

if ($Verify) {
    Write-Host ('[4] deploying masters into node_modules and syntax-checking (Verify=' + $Verify + ') ...')
    $nm = Join-Path $profile_ ('node_modules\' + $pkg + '\lib')
    foreach ($f in (Get-ChildItem $master -File)) {
        Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $nm $f.Name) -Force
    }
    & node --check (Join-Path $nm 'index.js')
    if ($LASTEXITCODE -ne 0) { throw 'node --check failed on the deployed index.js' }
    Write-Host '    node --check OK (note: restart dsh web for the running instance to load it)'
}

Remove-Item -LiteralPath $work -Recurse -Force
Write-Host 'done.'
