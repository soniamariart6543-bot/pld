﻿param([Parameter(Mandatory=$true)][string]$Path)
# UTF-8 BOM fixer for .ps1 files.
# Why: PowerShell 5.1 parses .ps1 by the platform default (GBK) unless a BOM is present.
# The edit/write tools save UTF-8 WITHOUT BOM, so any edit to a Chinese .ps1 breaks it.
# Run this right after editing any .ps1 that contains non-ASCII text.
$p = (Resolve-Path -LiteralPath $Path).Path
$bytes = [System.IO.File]::ReadAllBytes($p)
$hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191)
$text = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
[System.IO.File]::WriteAllText($p, $text, (New-Object System.Text.UTF8Encoding($true)))
if ($hasBom) { "BOM already present - rewritten anyway: $p" } else { "BOM added: $p" }
