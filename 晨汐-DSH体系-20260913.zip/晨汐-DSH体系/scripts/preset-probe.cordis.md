# preset-probe.cordis.md — 预设挂载校验探针（2026-09-13 建）

> 用途：验证 `~/.dsh/.agent-presets/` 下的用户预设**真的能挂载**（不是"形状看起来对"）。
> 为什么需要：2026-09-10 core 0.1.5-rc.1 把 `dsh-persona` 的 `text:` 改成 `prefix:`/`suffix:`，
> 用户预设不随内核迁移 → 预设挂载失败 → 智能路由模式与**所有用该预设的微信 IM 会话**每轮报
> `INTERNAL_UNKNOWN`。`[12] preset 形状体检`只能查形状，这里查真实挂载。

## 怎么用（两步，约 20 秒）

1. `cordis_define`，`plugin.kind = "new"`，`idPrefix = "preset"`，把下面 `code.host` 原样粘进去：
2. 用返回的 `pluginId`/`packageId` 调 `cordis_run`（`mode: "run"`），然后调用新工具
   `preset_mount_check`（可不带参数＝只查 user 预设；带 `{"id":"routing-suite"}` 查单个）。

输出示例（2026-09-13 实测）：

```
- minecraft [user] -> MOUNT OK
- routing-suite [user] -> MOUNT OK
```

失败会给出**精确拒绝原因**（例如 `invalid config: $.prefix missing required value`），
按原因改 `agent.cordis.yml` 即可。

⚠️ 动态插件只活在**当前进程**：重启 `dsh web` 后工具消失，重跑上面两步即可。
（磁盘上的持久防线是自检脚本的 `[12]`，两者互补：`[12]` 每天自动跑，本探针在改过预设后手动确认。）

## code.host（原样粘贴）

```js
return {
  name: 'preset-mount-probe',
  inject: ['agentPresets'],
  apply(ctx) {
    harness.registerTool(ctx, harness.defineTool({
      name: 'preset_mount_check',
      description: 'Mount-validate agent presets by id (or all user presets). Reports per preset: mount ok / exact rejection reason. Leaves no session behind.',
      parameters: {
        id: { type: 'string', description: 'Preset id; omit to check every user preset in the roster.' },
      },
      output: {
        schema: { type: 'string' },
        render(_args, value) { return [{ type: 'text', text: value }] },
      },
      async execute(args) {
        const lines = []
        const ids = []
        try {
          const roster = await ctx.agentPresets.list()
          const rows = Array.isArray(roster) ? roster : []
          for (const row of rows) {
            if (typeof args.id === 'string' && args.id.length > 0 && row.id !== args.id) continue
            if (typeof args.id !== 'string' && row.trust !== 'user') continue
            ids.push({ id: row.id, trust: row.trust, broken: row.broken ?? null })
          }
        } catch (error) {
          return 'roster read failed: ' + (error && error.message ? error.message : String(error))
        }
        if (ids.length === 0) return 'no matching preset found'
        for (const row of ids) {
          let verdict = ''
          try {
            await ctx.agentPresets.standingKeyFor(row.id)
            verdict = 'MOUNT OK'
          } catch (error) {
            verdict = 'MOUNT FAILED: ' + (error && error.message ? error.message : String(error))
          }
          lines.push('- ' + row.id + ' [' + row.trust + '] -> ' + verdict + (row.broken ? '  (roster broken: ' + row.broken + ')' : ''))
        }
        return lines.join('\n')
      },
    }))
  },
}
```
