﻿# fix-openclaw-persona.ps1 - re-apply the PERSONA_SECTION compatibility shim to the
# @lynsucceed/dsh-openclaw-persona plugin after it is reinstalled or updated.
#
# Why this exists: dsh-system-prompt 0.1.5-rc.1 renamed the export
#   PERSONA_SECTION ("deployment:persona", order 0)
# to PERSONA_PREFIX_SECTION ("deployment:persona-prefix", order 0) + PERSONA_SUFFIX_SECTION.
# persona 0.1.1 (latest on npm) still does `import { PERSONA_SECTION }`, which is a
# hard ESM link error.  The loader treats one bad import as a failed plugin TREE,
# so `dsh web` refuses to boot at all - and the autostart launcher cannot open the
# GUI.  A `pnpm install` / plugin update in profiles\web restores the broken file,
# so re-run this script afterwards.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File fix-openclaw-persona.ps1
#   ... -Profile web            target another profile
#   ... -Path <index.js>        operate on a specific file (testing)
#   ... -DryRun                 report only, write nothing
# ASCII only on purpose (started by powershell.exe -File).
param(
    [string]$Profile = 'web',
    [string]$Path,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'

$oldLine = 'import { PERSONA_SECTION } from "@deepseek-ai/dsh-system-prompt";'
$newBlock = @'
import * as dshSystemPrompt from "@deepseek-ai/dsh-system-prompt";
// Local compatibility shim (not part of upstream 0.1.1):
// dsh-system-prompt <= 0.1.0-rc.x exported `PERSONA_SECTION` ("deployment:persona",
// order 0). 0.1.5-rc.1 split that slot into PERSONA_PREFIX_SECTION (order 0) and
// PERSONA_SUFFIX_SECTION. Resolve whichever the host provides so one file works on
// both cores; the prefix is the direct successor of the old persona slot.
const PERSONA_SECTION = dshSystemPrompt.PERSONA_SECTION ?? dshSystemPrompt.PERSONA_PREFIX_SECTION ?? "deployment:persona-prefix";
'@

if (-not $Path) {
    $Path = Join-Path $env:USERPROFILE ('.dsh\profiles\' + $Profile + '\node_modules\@lynsucceed\dsh-openclaw-persona\lib\index.js')
}
if (-not (Test-Path $Path)) { Write-Host ('[fix-persona] not found: ' + $Path); exit 1 }

$text = Get-Content -Raw -Path $Path
if ($text -like '*PERSONA_PREFIX_SECTION*') {
    Write-Host ('[fix-persona] already patched, nothing to do: ' + $Path)
    exit 0
}
if ($text -notlike ('*' + $oldLine + '*')) {
    Write-Host ('[fix-persona] unexpected content (no PERSONA_SECTION import) - inspect by hand: ' + $Path)
    exit 1
}
if ($DryRun) {
    Write-Host ('[fix-persona] DRY RUN - would replace the PERSONA_SECTION import in ' + $Path)
    exit 0
}

$bak = $Path + '.orig'
if (-not (Test-Path $bak)) { Copy-Item $Path $bak -Force }
$newText = $text.Replace($oldLine, $newBlock.TrimEnd())
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($Path, $newText, $utf8NoBom)
Write-Host ('[fix-persona] patched: ' + $Path)
Write-Host ('[fix-persona] original kept at: ' + $bak)
exit 0
