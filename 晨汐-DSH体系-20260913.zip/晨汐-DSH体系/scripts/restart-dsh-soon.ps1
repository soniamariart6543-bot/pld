﻿# restart-dsh-soon.ps1 - delayed, fully detached restart of the DSH web GUI.
#
# Used when the running agent (which lives inside the very process being replaced)
# must finish its reply first: the caller spawns this via Win32_Process.Create so
# it is NOT a child of the DSH process and survives the kill in restart-dsh.ps1.
#
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File restart-dsh-soon.ps1 [-DelaySec 30]
# ASCII only on purpose (started by powershell.exe -File).
param([int]$DelaySec = 30)

$log = 'C:\Users\Lenovo\.dsh\logs\restart.log'
function W([string]$m) { Add-Content -Path $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [soon] ' + $m) -Encoding UTF8 }

W ('detached restart scheduled in ' + $DelaySec + 's')
Start-Sleep -Seconds $DelaySec
W 'delay elapsed - handing over to restart-dsh.ps1'
& powershell -NoProfile -ExecutionPolicy Bypass -File 'C:\Users\Lenovo\.dsh\restart-dsh.ps1'
W 'restart-dsh.ps1 returned'
