// check-plugin-compat.mjs - static compatibility probe for a dsh profile.
//
// What it does: for every plugin in <profile>/package.json, scan the installed
// package for `import { a, b } from "@deepseek-ai/<pkg>"` statements, resolve the
// target from the plugin's own location, then verify each named export really
// exists.  This is exactly the failure class that killed the 2026-09-10 boot
// (openclaw-persona imported PERSONA_SECTION after core renamed it): a missing
// named export is a hard ESM link error and takes the WHOLE plugin tree down.
//
// Usage:
//   node check-plugin-compat.mjs [profileDir]
// Exit code 0 = no missing named exports, 1 = at least one mismatch.
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const profileDir = process.argv[2] ?? 'C:\\Users\\Lenovo\\.dsh\\profiles\\web';
const pkg = JSON.parse(readFileSync(join(profileDir, 'package.json'), 'utf8'));
const deps = Object.keys(pkg.dependencies ?? {});

const importRe = /import\s*\{([^}]*)\}\s*from\s*["']([^"']+)["']/g;

function walk(dir, out = [], depth = 0) {
  if (depth > 6 || !existsSync(dir)) return out;
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, out, depth + 1);
    else if (e.name.endsWith('.js') || e.name.endsWith('.mjs')) out.push(p);
  }
  return out;
}

function names(list) {
  return list.split(',').map((s) => s.trim()).filter(Boolean)
    .map((s) => s.split(/\s+as\s+/)[0].trim()).filter(Boolean);
}

const resolveCache = new Map();
async function loadModule(spec, fromDir) {
  const key = spec + '\u0000' + fromDir;
  if (resolveCache.has(key)) return resolveCache.get(key);
  let result;
  try {
    const { createRequire } = await import('node:module');
    const req = createRequire(join(fromDir, 'noop.js'));
    const file = req.resolve(spec);
    result = { ns: await import(pathToFileURL(file).href), file };
  } catch (err) {
    result = { error: String(err && err.message ? err.message : err).split('\n')[0] };
  }
  resolveCache.set(key, result);
  return result;
}

let mismatches = 0;
let checked = 0;
const rows = [];

for (const dep of deps) {
  const dir = join(profileDir, 'node_modules', dep);
  if (!existsSync(dir)) { rows.push(`  ${dep}: NOT INSTALLED`); continue; }
  let ver = '?';
  try { ver = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')).version; } catch {}
  const problems = [];
  const seen = new Set();
  for (const file of walk(dir)) {
    let src;
    try { src = readFileSync(file, 'utf8'); } catch { continue; }
    if (!src.includes('@deepseek-ai/')) continue;
    for (const m of src.matchAll(importRe)) {
      const spec = m[2];
      if (!spec.startsWith('@deepseek-ai/')) continue;
      const wanted = names(m[1]);
      if (!wanted.length) continue;
      const mod = await loadModule(spec, dirname(file));
      if (mod.error) {
        const k = dep + '|' + spec + '|unresolved';
        if (!seen.has(k)) { seen.add(k); problems.push(`?  ${spec} not resolvable offline (host-provided?) - ${mod.error}`); }
        continue;
      }
      for (const n of wanted) {
        checked++;
        const k = dep + '|' + spec + '|' + n;
        if (seen.has(k)) continue;
        seen.add(k);
        if (!(n in mod.ns)) { mismatches++; problems.push(`X  MISSING EXPORT ${n} <- ${spec}  (${file.replace(dir, '.')})`); }
      }
    }
  }
  rows.push(problems.length ? `  ${dep}@${ver}\n    ` + problems.join('\n    ') : `  ${dep}@${ver}: ok`);
}

console.log(`profile: ${profileDir}`);
console.log(`named exports checked: ${checked}, mismatches: ${mismatches}`);
console.log(rows.join('\n'));
process.exit(mismatches ? 1 : 0);
