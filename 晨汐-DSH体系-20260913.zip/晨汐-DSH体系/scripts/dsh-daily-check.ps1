﻿# dsh-daily-check.ps1 - DSH self-check (daily / startup).  Pure-cmdlet, PS 5.1 safe.
# Usage:
#   powershell -File dsh-daily-check.ps1                  -> check only, writes report
#   powershell -File dsh-daily-check.ps1 -Startup         -> same (called by autostart, quiet)
#   powershell -File dsh-daily-check.ps1 -Apply           -> check + pull latest DSH to npx cache
#   powershell -File dsh-daily-check.ps1 -Apply -ApplyPlugins -> also update profile plugins
# Reports: C:\Users\Lenovo\.dsh\logs\dsh-check-latest.txt + dsh-check-<yyyyMMdd>.txt
param(
    [switch]$Apply,
    [switch]$ApplyPlugins,
    [switch]$Startup,
    [switch]$Quiet
)
$ErrorActionPreference = 'SilentlyContinue'
$dshHome = 'C:\Users\Lenovo\.dsh'
$logDir  = Join-Path $dshHome 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$report = @()

function Say([string]$line) {
    if (-not $Quiet) { Write-Host $line }
    $script:report += $line
}
function Get-JsonVersion([string]$path) {
    if (-not (Test-Path $path)) { return $null }
    try { $j = (Get-Content -Raw -Path $path) | ConvertFrom-Json; return $j.version } catch { return $null }
}
function Get-NpmLatest([string]$name) {
    try {
        $u = 'https://registry.npmjs.org/' + ($name -replace '/', '%2F')
        $r = Invoke-RestMethod -Uri $u -TimeoutSec 8
        return [string]$r.'dist-tags'.latest
    } catch { return $null }
}
function Get-NpmAgeDays([string]$pkg, [string]$version) {
    # How old is that release? Feeds the stability gate: the rule is "notify -> inspect ->
    # only a build older than 3 days may be proposed". Silent null on failure.
    try {
        $u = 'https://registry.npmjs.org/' + ($pkg -replace '/', '%2F')
        $r = Invoke-RestMethod -Uri $u -TimeoutSec 8
        $t = $r.time.$version
        if (-not $t) { return $null }
        return [math]::Round(((Get-Date).ToUniversalTime() - ([datetime]$t).ToUniversalTime()).TotalDays, 2)
    } catch { return $null }
}
function Get-VerKey([string]$v) {
    if (-not $v) { return -1 }
    $core = ($v -split '-')[0]
    $p = $core -split '\.'
    while ($p.Count -lt 3) { $p += '0' }
    return ([int]$p[0] * 1000000) + ([int]$p[1] * 1000) + [int]$p[2]
}
function Get-PortAlive([int]$port) {
    try {
        $null = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $port) -TimeoutSec 4 -UseBasicParsing
        return $true
    } catch {
        if ($_.Exception.Response -ne $null) { return $true }
        return $false
    }
}

$now = Get-Date
Say ('# DSH daily check  ' + $now.ToString('yyyy-MM-dd HH:mm:ss'))
Say ('startup=' + [bool]$Startup + '  apply=' + [bool]$Apply + '  applyPlugins=' + [bool]$ApplyPlugins)

# 1) DSH runtime copies on disk (start-dsh.ps1 picks: newest npx cache -> global npm -> profiles)
$runningPkg = Join-Path $dshHome 'profiles\node_modules\@deepseek-ai\dsh\package.json'
$runningVer = Get-JsonVersion $runningPkg
$globalPkg = Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\package.json'
$globalVer = Get-JsonVersion $globalPkg
Say ''
Say '[1] DSH runtime copies'
Say ('    profiles = ' + $runningVer)
if (Test-Path $runningPkg) { Say ('    profiles mtime = ' + (Get-Item $runningPkg).LastWriteTime) }
else { Say '    profiles package.json NOT FOUND' }
Say ('    global npm = ' + $globalVer)

# 2) npx cache versions
$npxRoot = 'C:\Users\Lenovo\AppData\Local\npm-cache\_npx'
$cached = @()
$bestCached = $null
$bestKey = -1
if (Test-Path $npxRoot) {
    Get-ChildItem $npxRoot -Directory | ForEach-Object {
        $p = Join-Path $_.FullName 'node_modules\@deepseek-ai\dsh\package.json'
        $v = Get-JsonVersion $p
        if ($v) {
            $cached += $v
            $k = Get-VerKey $v
            if ($k -gt $bestKey) { $bestKey = $k; $bestCached = $v }
        }
    }
}
Say ''
Say '[2] npx cache versions'
Say ('    cached  = ' + (($cached | Sort-Object -Unique) -join ','))
Say ('    launcher will start = ' + $bestCached)
# the effective runtime is the npx-cache pick, not the profiles copy - report that
if ($bestCached) { $runningVer = $bestCached }

# 3) npm registry latest (+ stability gate: never chase the newest blindly)
$latestDsh = Get-NpmLatest '@deepseek-ai/dsh'
Say ''
Say '[3] npm registry latest'
Say ('    @deepseek-ai/dsh latest = ' + $latestDsh)
if ($runningVer -and $latestDsh) {
    if ($runningVer -eq $latestDsh) { Say '    => UP TO DATE' }
    else { Say ('    => UPDATE AVAILABLE (' + $runningVer + ' -> ' + $latestDsh + ')') }
}
if ($latestDsh) {
    try {
        $meta = Invoke-RestMethod -Uri 'https://registry.npmjs.org/@deepseek-ai%2Fdsh' -TimeoutSec 10
        $pub = $meta.time.$latestDsh
        if ($pub) {
            $ageDays = [int]((Get-Date).ToUniversalTime() - ([datetime]$pub).ToUniversalTime()).TotalDays
            Say ('    published = ' + $pub + '  (' + $ageDays + ' days ago)')
            if ($ageDays -lt 3) { Say '    => OBSERVATION WINDOW (<3 days): do NOT install yet' }
            elseif ($latestDsh -match 'alpha|beta|rc') { Say '    => pre-release channel: install only with explicit user approval' }
            else { Say '    => STABLE CANDIDATE (release + >=3 days): propose to user, do not auto-install' }
        }
    } catch { Say '    (publish time unavailable)' }
}

# 4) profile plugins
Say ''
Say '[4] profile plugins (profiles\web\package.json)'
$webPkg = Join-Path $dshHome 'profiles\web\package.json'
$outdated = 0
if (Test-Path $webPkg) {
    $wp = (Get-Content -Raw -Path $webPkg) | ConvertFrom-Json
    foreach ($prop in $wp.dependencies.PSObject.Properties) {
        $name = $prop.Name
        $spec = [string]$prop.Value
        if ($spec -like 'http*') { Say ('    ' + $name + ' = git source (skip)'); continue }
        $local = $spec -replace '[\^~]', ''
        $lat = Get-NpmLatest $name
        if ($lat -and $local -ne $lat) {
            $age = Get-NpmAgeDays $name $lat
            $gate = 'age unknown'
            if ($null -ne $age) {
                if ($age -ge 3) { $gate = 'ready (>=3d)' } else { $gate = 'WAIT (<3d observation window)' }
            }
            Say ('    [OUTDATED] ' + $name + '  local=' + $local + '  latest=' + $lat + '  latest published ' + $age + ' d ago -> ' + $gate)
            $outdated++
        } else {
            $shown = 'n/a'
            if ($lat) { $shown = $lat }
            Say ('    ok  ' + $name + '  local=' + $local + '  latest=' + $shown)
        }
    }
} else { Say '    web package.json not found' }
Say ('    outdated plugins = ' + $outdated)

# 4b) plugin scan - compatibility (named exports vs the CURRENT core) + bundle integrity.
#     Daily-worthy because this is the failure class that killed the 2026-09-10 boot:
#     one plugin importing an export the core renamed makes the WHOLE plugin tree
#     fail to load, and dsh web will not start at all.
$webDir = Join-Path $dshHome 'profiles\web'
$compat = Join-Path $dshHome 'check-plugin-compat.mjs'
Say ''
Say '[4b] plugin scan (compatibility + bundle integrity)'
if (Test-Path $compat) {
    $nodeExe = 'D:\node\node.exe'
    if (-not (Test-Path $nodeExe)) { $nodeExe = 'node' }
    $scan = @(& $nodeExe $compat $webDir 2>&1)
    foreach ($l in @($scan | Select-Object -First 3)) { Say ('    ' + $l) }
    $bad = @($scan | Where-Object { $_ -match 'MISSING EXPORT|NOT INSTALLED|not resolvable' })
    if ($bad.Count -eq 0) { Say '    => every plugin import resolves against this core' }
    else { foreach ($l in $bad) { Say ('    !! ' + $l.Trim()) } }
} else {
    Say ('    compat scanner not found: ' + $compat)
}
# every declared bundle must be resolvable, or the loader cannot build the tree.
# Core bundles (@deepseek-ai/*) come from the DSH install / the hoisted profiles
# store, only third-party bundles live in the profile's own node_modules.
if ($wp -and $wp.dsh.profile.bundles) {
    $bundles = @($wp.dsh.profile.bundles)
    $searchBases = @(
        (Join-Path $webDir 'node_modules'),
        (Join-Path $dshHome 'profiles\node_modules'),
        (Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\node_modules')
    )
    $missingBundle = @()
    foreach ($b in $bundles) {
        $leaf = $b -replace '/', '\'
        $found = $false
        foreach ($base in $searchBases) { if ($base -and (Test-Path (Join-Path $base $leaf))) { $found = $true; break } }
        if (-not $found) { $missingBundle += $b }
    }
    Say ('    declared bundles = ' + $bundles.Count + '   unresolvable = ' + $missingBundle.Count)
    foreach ($b in $missingBundle) { Say ('    !! bundle not resolvable: ' + $b) }
}

# 5) model list (look for newer model such as v4.1)
Say ''
Say '[5] DeepSeek model list (pi-ai provider data)'
$modelJson = Join-Path $dshHome 'profiles\node_modules\@earendil-works\pi-ai\dist\providers\data\deepseek.json'
if (Test-Path $modelJson) {
    $txt = Get-Content -Raw -Path $modelJson
    $ids = @()
    $m = $txt | Select-String -Pattern '"id":"([^"]+)"' -AllMatches
    foreach ($hit in $m.Matches) { $ids += $hit.Groups[1].Value }
    Say ('    models = ' + (($ids | Sort-Object -Unique) -join ', '))
    if ($txt -match 'v4\.1|4\.1-') { Say '    => NEW MODEL (v4.1 series) PRESENT' }
    else { Say '    => no v4.1 entry yet' }
} else { Say '    model data not found' }

# 6) autostart + port
Say ''
Say '[6] autostart / service'
$run = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'DSH Web' -ErrorAction SilentlyContinue).'DSH Web'
Say ('    HKCU Run "DSH Web" = ' + $run)
Say ('    port 3080 alive = ' + (Get-PortAlive 3080))

# 7) boot safety: quarantined plugin rows + last launcher boot failure
Say ''
Say '[7] boot safety (dsh-safe / launcher)'
$qFile = Join-Path $dshHome 'dsh-safe\quarantine.json'
$qCount = 0
$qNames = @()
if (Test-Path $qFile) {
    try {
        $qj = (Get-Content -Raw -Path $qFile) | ConvertFrom-Json
        if ($qj.profiles) {
            foreach ($p in $qj.profiles.PSObject.Properties) {
                foreach ($e in @($p.Value)) { $qCount++; $qNames += ($p.Name + ':' + $e.id) }
            }
        }
    } catch { }
}
Say ('    dsh-safe quarantined rows = ' + $qCount)
if ($qCount -gt 0) { Say ('      ' + ($qNames -join ', ') + '   (restore: dsh-safe restore --profile <name> --all)') }
$failFile = Join-Path $logDir 'boot-failure.txt'
if (Test-Path $failFile) {
    Say '    boot-failure.txt PRESENT - last autostart could not serve dsh web:'
    foreach ($l in @(Get-Content -Path $failFile -TotalCount 6)) { Say ('      ' + $l) }
} else {
    Say '    boot-failure.txt = none (last autostart booted cleanly)'
}
# compatibility shim for the one plugin that hard-crashes the 0.1.5-rc.1 loader
$personaIdx = Join-Path $dshHome 'profiles\web\node_modules\@lynsucceed\dsh-openclaw-persona\lib\index.js'
if (Test-Path $personaIdx) {
    $ptxt = Get-Content -Raw -Path $personaIdx
    if ($ptxt -like '*PERSONA_PREFIX_SECTION*') { Say '    openclaw-persona shim = present (0.1.5-rc.1 compatible)' }
    else { Say '    openclaw-persona shim = MISSING -> run C:\Users\Lenovo\.dsh\fix-openclaw-persona.ps1 (dsh web cannot boot without it)' }
}

# 8) time check (local vs network clock) - the anchor for "what day is it"
Say ''
Say '[8] time check'
$localNow = Get-Date
$netDate = $null
try {
    $resp = Invoke-WebRequest -Uri 'https://www.baidu.com' -TimeoutSec 8 -UseBasicParsing -Method Head
    if ($resp.Headers.Date) { $netDate = [datetime]::Parse($resp.Headers.Date) }
} catch { }
if ($netDate) {
    $drift = [int][math]::Round(($netDate.ToUniversalTime() - $localNow.ToUniversalTime()).TotalSeconds)
    Say ('    local   = ' + $localNow.ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $localNow.DayOfWeek)
    Say ('    network = ' + $netDate.ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss') + ' UTC')
    Say ('    drift   = ' + $drift + ' s')
    if ([math]::Abs($drift) -gt 120) { Say '    => DRIFT > 120s: ask user to run "w32tm /resync" as admin' }
    else { Say '    => time OK (use this date as the conversation anchor)' }
} else { Say '    network time unavailable - local clock is the anchor' }

# 9) calendar refresh (CN statutory holidays) - rewritten daily
Say ''
Say '[9] calendar refresh'
$calDir = Join-Path $dshHome 'calendar'
if (-not (Test-Path $calDir)) { New-Item -ItemType Directory -Path $calDir -Force | Out-Null }
try {
    $calYear = (Get-Date).Year
    $calRaw = Invoke-RestMethod -Uri ('https://timor.tech/api/holiday/year/' + $calYear) -TimeoutSec 20 -Headers @{'User-Agent' = 'Mozilla/5.0'}
    if ($calRaw.code -eq 0) {
        $calItems = @()
        foreach ($prop in $calRaw.holiday.PSObject.Properties) {
            $val = $prop.Value
            $dt = [datetime]::ParseExact(($calYear.ToString() + '-' + $prop.Name), 'yyyy-MM-dd', $null)
            $calItems += [pscustomobject]@{ Date = $dt; IsOff = [bool]$val.holiday; Name = [string]$val.name }
        }
        $calItems = $calItems | Sort-Object Date
        $calToday = (Get-Date).Date
        $calNext = ($calItems | Where-Object { $_.IsOff -and $_.Date -ge $calToday } | Select-Object -First 1)
        $calLines = @()
        $calLines += '# 昀晞的日历（自动生成）'
        $calLines += ''
        $calLines += ('> 数据源: timor.tech 中国法定节假日 · 生成时间 ' + (Get-Date).ToString('yyyy-MM-dd HH:mm') + ' · 每日自检自动刷新')
        $calLines += ''
        $calLines += '## 今天'
        $calLines += ('- ' + $calToday.ToString('yyyy-MM-dd') + ' ' + $calToday.DayOfWeek)
        if ($calNext) { $calLines += ('- 距离下一个休息日（' + $calNext.Name + ' ' + $calNext.Date.ToString('MM-dd') + '）还有 ' + [int]($calNext.Date - $calToday).TotalDays + ' 天') }
        $calLines += ''
        $calLines += '## 未来 60 天：放假'
        $off60 = $calItems | Where-Object { $_.IsOff -and $_.Date -ge $calToday -and $_.Date -le $calToday.AddDays(60) }
        if ($off60) { foreach ($i in $off60) { $calLines += ('- ' + $i.Date.ToString('MM-dd') + ' ' + $i.Date.DayOfWeek + '  ' + $i.Name) } } else { $calLines += '- （无）' }
        $calLines += ''
        $calLines += '## 未来 60 天：补班'
        $wk60 = $calItems | Where-Object { -not $_.IsOff -and $_.Date -ge $calToday -and $_.Date -le $calToday.AddDays(60) }
        if ($wk60) { foreach ($i in $wk60) { $calLines += ('- ' + $i.Date.ToString('MM-dd') + ' ' + $i.Date.DayOfWeek + '  ' + $i.Name) } } else { $calLines += '- （无）' }
        $calLines += ''
        $calLines += ('## ' + $calYear + ' 年剩余全部放假')
        $restOff = $calItems | Where-Object { $_.IsOff -and $_.Date -ge $calToday }
        if ($restOff) { foreach ($i in $restOff) { $calLines += ('- ' + $i.Date.ToString('MM-dd') + ' ' + $i.Date.DayOfWeek + '  ' + $i.Name) } } else { $calLines += '- （无）' }
        # --- custom nodes: preserved across every refresh -------------------
        # Source of truth: calendar\custom.json  = [{ "date":"2026-10-15", "title":"...", "note":"..." }]
        # A manually edited "## 自定义节点" block in calendar.md is imported too, so
        # hand-edits survive. (Before 2026-09-13 the refresh blanked this section.)
        $calCustom = @{}
        $customJson = Join-Path $calDir 'custom.json'
        if (-not (Test-Path $customJson)) { $customJson = Join-Path $calDir 'custom-nodes.json' }
        if (Test-Path $customJson) {
            try {
                # explicit UTF-8 on both reads: Get-Content -Raw uses the platform
                # default (GBK) and would mangle Chinese titles / section headers.
                $cj = [System.IO.File]::ReadAllText($customJson, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
                foreach ($n in $cj) {
                    if ($n.date) { $calCustom[[string]$n.date] = [pscustomobject]@{ Title = [string]$n.title; Note = [string]$n.note } }
                }
            } catch { Say ('    custom.json unreadable: ' + $_.Exception.Message) }
        }
        $calMdPath = Join-Path $calDir 'calendar.md'
        if (Test-Path $calMdPath) {
            $inSec = $false
            foreach ($ln in ([System.IO.File]::ReadAllText($calMdPath, [System.Text.Encoding]::UTF8) -split "`r?`n")) {
                if ($ln -like '## *自定义节点*') { $inSec = $true; continue }
                if ($inSec -and $ln -like '## *') { $inSec = $false }
                if (-not $inSec) { continue }
                if ($ln -match '^\s*-\s*(\d{4}-\d{2}-\d{2})\s+(.+?)\s*$') {
                    $d = $Matches[1]; $rest = $Matches[2].Trim()
                    if ($rest -like '*待填*' -or $rest -eq '') { continue }
                    $note = ''
                    $mi = $rest.IndexOf(' - ')
                    if ($mi -ge 0) { $note = $rest.Substring($mi + 3).Trim(); $rest = $rest.Substring(0, $mi).Trim() }
                    if (-not $calCustom.ContainsKey($d)) {
                        $calCustom[$d] = [pscustomobject]@{ Title = $rest; Note = $note }
                    }
                }
            }
        }
        $calLines += ''
        $calLines += '## 自定义节点（学期/考试/项目里程碑）'
        $calLines += '> 由 calendar\custom.json 或本区块手工内容自动保留；格式 "- YYYY-MM-DD 标题 - 备注"'
        if ($calCustom.Count -gt 0) {
            $cdays = @()
            foreach ($k in ($calCustom.Keys | Sort-Object)) {
                if ($k -notmatch '^\d{4}-\d{2}-\d{2}$') { continue }
                $cdays += [pscustomobject]@{ Date = [datetime]::ParseExact($k, 'yyyy-MM-dd', $null); Nodes = $calCustom[$k] }
            }
            foreach ($cd in $cdays) {
                $line = '- ' + $cd.Date.ToString('yyyy-MM-dd') + ' ' + $cd.Date.DayOfWeek + '  ' + $cd.Nodes.Title
                if ($cd.Nodes.Note) { $line += ' - ' + $cd.Nodes.Note }
                $calLines += $line
            }
        } else {
            $calLines += '- （暂无：在 calendar\custom.json 里加 {"date":"2026-10-15","title":"考试周","note":"..."} 即可）'
        }
        $calLines | Set-Content -Path $calMdPath -Encoding UTF8
        $calRaw | ConvertTo-Json -Depth 6 | Set-Content -Path (Join-Path $calDir ($calYear.ToString() + '-holidays.json')) -Encoding UTF8
        Say ('    refreshed: ' + (Join-Path $calDir 'calendar.md'))
        Say ('    today = ' + $calToday.ToString('yyyy-MM-dd') + ' ' + $calToday.DayOfWeek)
        if ($calNext) { Say ('    next off-day: ' + $calNext.Name + ' ' + $calNext.Date.ToString('MM-dd') + ' (in ' + [int]($calNext.Date - $calToday).TotalDays + ' days)') }
    } else { Say '    calendar API returned non-zero code' }
} catch { Say ('    calendar refresh failed: ' + $_.Exception.Message) }

# 10) GitHub channels - keep the fallback chain honest
Say ''
Say '[10] GitHub channels'
$g0 = Get-Date
try { $null = Invoke-WebRequest -Uri 'https://api.github.com' -TimeoutSec 8 -UseBasicParsing; Say ('    api.github.com OK (' + [int]((Get-Date) - $g0).TotalMilliseconds + ' ms)') } catch { Say '    api.github.com FAIL' }
$g0 = Get-Date
try { $null = Invoke-WebRequest -Uri 'https://gh-proxy.com/https://raw.githubusercontent.com/NateScarlet/holiday-cn/master/README.md' -TimeoutSec 10 -UseBasicParsing; Say ('    gh-proxy.com OK (' + [int]((Get-Date) - $g0).TotalMilliseconds + ' ms)') } catch { Say '    gh-proxy.com FAIL' }
$g0 = Get-Date
try { $null = Invoke-WebRequest -Uri 'https://ghfast.top/https://raw.githubusercontent.com/NateScarlet/holiday-cn/master/README.md' -TimeoutSec 10 -UseBasicParsing; Say ('    ghfast.top OK (' + [int]((Get-Date) - $g0).TotalMilliseconds + ' ms)') } catch { Say '    ghfast.top FAIL' }
Say '    note: github.com / raw.* direct is blocked here; use ghfetch.ps1 or a mirror prefix'

# 11) script health: PowerShell 5.1 parses .ps1 as GBK unless a UTF-8 BOM is
#     present, so any Chinese .ps1 written by the edit/write tools breaks.
#     Lives here because it is exactly the "it silently did nothing" failure.
Say ''
Say '[11] script health (UTF-8 BOM for non-ASCII .ps1)'
$badBom = @()
foreach ($sf in (Get-ChildItem (Join-Path $dshHome '*.ps1'))) {
    $sb = [System.IO.File]::ReadAllBytes($sf.FullName)
    $sBom = ($sb.Length -ge 3 -and $sb[0] -eq 239 -and $sb[1] -eq 187 -and $sb[2] -eq 191)
    $sNonAscii = $false
    foreach ($sc in ($sf.Name.ToCharArray())) { if ([int]$sc -gt 127) { $sNonAscii = $true } }
    if ($sNonAscii -and -not $sBom) { $badBom += $sf.Name }
}
if ($badBom.Count -eq 0) { Say '    all non-ASCII .ps1 have BOM - OK' }
else {
    Say ('    MISSING BOM (' + $badBom.Count + '): ' + ($badBom -join ', '))
    Say '    -> fix: powershell -File C:\Users\Lenovo\.dsh\fix-ps1-bom.ps1 -Path <script>'
}

# 11b) chenxi growth zone - how much has 晨汐 actually grown (entries / today / size / roots intact)
Say ''
Say '[11b] chenxi growth'
$growthAudit = 'C:\Users\Lenovo\.dsh\.agent-presets\chenxi\growth-audit.ps1'
if (Test-Path $growthAudit) {
    # growth-audit.ps1 prints its own lines; quiet mode only signals failure, so ask for the report
    $gout = & powershell -NoProfile -ExecutionPolicy Bypass -File $growthAudit 2>&1
    foreach ($gl in $gout) { Say ('    ' + $gl) }
} else { Say '    growth-audit.ps1 not found (chenxi growth zone missing)' }


# 12) agent preset format lint. User presets under ~/.dsh/.agent-presets do NOT migrate with a core
#     upgrade: when @deepseek-ai/dsh-persona moved from `text:` to `prefix:`/`suffix:`, every preset
#     using the old field failed to mount, which killed the routing-suite preset AND every WeChat IM
#     session pinned to it (INTERNAL_UNKNOWN on every turn). This catches the shape offline; the live
#     mount check is a plugin that calls agentPresets.standingKeyFor(id) (see make-pnpm-patch notes).
Say ''
Say '[12] agent preset lint'
$presetRoot = Join-Path $dshHome '.agent-presets'
if (Test-Path $presetRoot) {
    $presetIssues = 0
    foreach ($pd in (Get-ChildItem $presetRoot -Directory)) {
        $yml = Join-Path $pd.FullName 'agent.cordis.yml'
        $meta = Join-Path $pd.FullName 'preset.yml'
        if (-not (Test-Path $yml)) { Say ('    ' + $pd.Name + ': MISSING agent.cordis.yml'); $presetIssues++; continue }
        $raw = [System.IO.File]::ReadAllText($yml, [System.Text.Encoding]::UTF8)
        $flags = @()
        if (-not (Test-Path $meta)) { $flags += 'no preset.yml (picker shows the bare directory name)' }
        if ($raw -match '(?m)^\s*text:\s') { $flags += 'legacy persona field "text:" -> must be prefix:/suffix: (mount fails on core 0.1.5-rc.1+)' }
        if (($raw -match 'dsh-persona') -and ($raw -notmatch '(?m)^\s*prefix:\s*[|>]')) { $flags += 'persona row without a prefix: block' }
        if ($raw -notmatch '(?m)^\s*- id:\s*\S') { $flags += 'no plugin rows found (loader dialect?)' }
        if ($flags.Count -eq 0) { Say ('    ' + $pd.Name + ': shape ok') }
        else { foreach ($f in $flags) { Say ('    ' + $pd.Name + ': ' + $f) }; $presetIssues++ }
    }
    if ($presetIssues -eq 0) { Say '    all presets look mountable by shape' } else { Say ('    presets needing attention: ' + $presetIssues) }
} else { Say '    no user preset root found' }

# write reports
$stamp = $now.ToString('yyyyMMdd')
$latestPath = Join-Path $logDir 'dsh-check-latest.txt'
$dailyPath  = Join-Path $logDir ('dsh-check-' + $stamp + '.txt')
Set-Content -Path $latestPath -Value $report -Encoding UTF8
Set-Content -Path $dailyPath  -Value $report -Encoding UTF8
Say ''
Say ('report written: ' + $latestPath)

# optional apply
if ($Apply) {
    $bkDir = Join-Path $logDir 'backups'
    if (-not (Test-Path $bkDir)) { New-Item -ItemType Directory -Path $bkDir -Force | Out-Null }
    $ts = $now.ToString('yyyyMMdd-HHmmss')
    Say ''
    Say '[A1] pulling latest DSH into npx cache (running instance untouched)'
    if (Test-Path $webPkg) { Copy-Item $webPkg (Join-Path $bkDir ('web-package-' + $ts + '.json')) -Force }
    $lock = Join-Path $dshHome 'profiles\web\pnpm-lock.yaml'
    if (Test-Path $lock) { Copy-Item $lock (Join-Path $bkDir ('pnpm-lock-' + $ts + '.yaml')) -Force }
    $verOut = & npx --yes '@deepseek-ai/dsh@latest' --version 2>&1
    Say ('    npx @latest --version => ' + ($verOut -join ' '))
    Say '    NOTE: to actually switch, close current DSH then run: npx @deepseek-ai/dsh@latest web'
    if ($ApplyPlugins) {
        Say ''
        Say '[A2] updating profile plugins (pnpm update in profiles\web)'
        Push-Location (Join-Path $dshHome 'profiles\web')
        $pout = & pnpm update 2>&1
        Pop-Location
        Say ($pout -join "`r`n")
    }
    Set-Content -Path $latestPath -Value $report -Encoding UTF8
    Set-Content -Path $dailyPath  -Value $report -Encoding UTF8
}
exit 0
