' DSH Web launcher (autostart/desktop). ASCII only - encoding-safe.
Set shell = CreateObject("WScript.Shell")
shell.Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""C:\Users\Lenovo\.dsh\start-dsh.ps1""", 0, False