﻿# ghfetch.ps1 - GitHub fetch with mirror fallback (for DSH sessions)
# Usage:
#   pwsh -File ghfetch.ps1 -Url <github-url>                 -> print body to stdout
#   pwsh -File ghfetch.ps1 -Url <github-url> -Out <file>     -> save to file
# Chain: direct (api.github.com only) -> ghfast.top -> gh-proxy.com -> jsdelivr (raw only)
# 2026-09-09 probe: github.com & raw.githubusercontent.com time out (blocked);
# api.github.com OK; mirrors OK (gh-proxy ~0.6s, ghfast ~1.0s, jsdelivr ~2.6s).
param(
    [Parameter(Mandatory=$true)][string]$Url,
    [string]$Out,
    [switch]$Quiet
)
$ErrorActionPreference = 'Stop'
$timeout = 8

function Get-Once([string]$u) {
    try {
        $p = @{ Uri = $u; Method = 'Get'; TimeoutSec = $timeout; MaximumRedirection = 5; UseBasicParsing = $true; ErrorAction = 'Stop' }
        if ($Out) { $p['OutFile'] = $Out }
        Invoke-WebRequest @p
        return $true
    } catch {
        return $false
    }
}

# Build candidate list
$cands = New-Object System.Collections.ArrayList
if ($Url -like 'https://api.github.com/*') {
    [void]$cands.Add($Url)
} else {
    # raw file
    if ($Url -like 'https://raw.githubusercontent.com/*') {
        [void]$cands.Add('https://ghfast.top/' + $Url)
        [void]$cands.Add('https://gh-proxy.com/' + $Url)
        # jsdelivr transform: raw.githubusercontent.com/u/r/branch/path -> cdn.jsdelivr.net/gh/u/r@branch/path
        if ($Url -match '^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$') {
            [void]$cands.Add('https://cdn.jsdelivr.net/gh/' + $Matches[1] + '/' + $Matches[2] + '@' + $Matches[3] + '/' + $Matches[4])
        }
    } elseif ($Url -like 'https://github.com/*') {
        # release asset or archive via proxy
        if ($Url -match 'releases/download|archive/') {
            [void]$cands.Add('https://ghfast.top/' + $Url)
            [void]$cands.Add('https://gh-proxy.com/' + $Url)
        } else {
            # normal github.com page: print guidance, try proxy page anyway
            [void]$cands.Add('https://ghfast.top/' + $Url)
        }
    } else {
        [void]$cands.Add($Url)
    }
}

foreach ($c in $cands) {
    if (-not $Quiet) { Write-Host ('try: ' + $c) }
    if (Get-Once $c) {
        if (-not $Quiet) { Write-Host 'OK' }
        exit 0
    }
}
Write-Host 'ALL MIRRORS FAILED (or resource 404/not found)'
exit 1
