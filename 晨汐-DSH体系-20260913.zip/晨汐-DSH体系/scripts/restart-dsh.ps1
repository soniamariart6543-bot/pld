﻿# restart-dsh.ps1 - stop the running DSH web instance and relaunch it.
#
# Two run modes:
#   (default)  operator / GUI entry point: re-launch yourself DETACHED (Win32_Process.Create),
#              then exit at once, so the real work runs outside the tree that is about to be killed.
#   -Detached  the actual worker: stop whatever listens on the port, wait for it to be released,
#              then hand over to start-dsh.ps1 (which picks the newest DSH build).
#
# WHY THE DETACH (2026-09-13 incident): started as a child of the DSH process, this script used to
# kill its own ancestor with Stop-Process -Force, which killed the whole tree including itself.
# restart.log stopped right after "stopped" and port 3080 stayed down until something else started
# the launcher two minutes later. A process created with Win32_Process.Create has no parent in that
# tree and survives (verified by a standalone kill test).
#
# WHY NO "already answering -> do nothing" SHORTCUT (2026-09-13, second incident): the old guard
# treated ANY HTTP answer as "the instance is alive" and dropped the restart request silently. A
# hung instance, a stale listener, or anything else parked on the port could therefore make the
# restart a no-op. The worker now always owns the port: it waits a grace period for the listener to
# leave on its own, then force-stops it, then relaunches.
#
# A restart-in-progress marker is kept under logs\: start-dsh.ps1 removes it, and uses its presence
# to relaunch instead of just opening the browser, so a hand-started launcher also completes a
# restart this script left half-done.
#
# NOTE: keep this file ASCII. It is started by powershell.exe -File (PS 5.1), where a
# UTF-8-without-BOM file containing non-ASCII would be mis-decoded.
param(
    [int]$Port = 3080,
    [switch]$Detached
)
$ErrorActionPreference = 'Continue'
$root   = 'C:\Users\Lenovo\.dsh'
$log    = Join-Path $root 'logs\restart.log'
$marker = Join-Path $root 'logs\restart-in-progress.txt'
function W([string]$m) { Add-Content -Path $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $m) -Encoding UTF8 }

function Listeners([int]$p) {
    $ids = @()
    try {
        $ids = @(Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
    } catch {
        try { $ids = @(netstat -ano | Select-String (':' + $p) | Where-Object { $_.Line -match 'LISTENING' } | ForEach-Object { ($_.Line -split '\s+')[-1] } | Sort-Object -Unique) } catch { $ids = @() }
    }
    $out = @()
    foreach ($id in $ids) { if ($id -and $id -ne '0' -and $id -ne '4') { $out += $id } }
    return $out
}

if (-not $Detached) {
    $self = $PSCommandPath
    Set-Content -Path $marker -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' restart of port ' + $Port + ' requested') -Encoding UTF8
    W ('restart requested for port ' + $Port + ' - re-launching myself detached')
    $cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $self + '" -Detached -Port ' + $Port
    try {
        $null = ([wmiclass]'Win32_Process').Create($cmd)
        W 'detached worker created - exiting the attached process now'
    } catch {
        W ('detach failed: ' + $_.Exception.Message + ' - falling back to an in-process restart')
        & powershell -NoProfile -ExecutionPolicy Bypass -File $self -Detached -Port $Port
    }
    exit 0
}

# ---- detached worker: independent of the instance being restarted ----
W ('=== detached worker (port ' + $Port + ') ===')

# 1) give the current instance a moment to leave on its own (it may already be shutting down),
#    then stop whatever still owns the port.
$grace = 0
while ($grace -lt 10) {
    if ((Listeners $Port).Count -eq 0) { break }
    Start-Sleep -Seconds 1
    $grace++
}
W ('owned-by-others check: waited ' + $grace + 's, listeners now = ' + ((Listeners $Port) -join ','))

foreach ($procId in (Listeners $Port)) {
    $name = 'unknown'
    try { $name = (Get-Process -Id $procId -ErrorAction Stop).ProcessName } catch { }
    W ('stopping pid ' + $procId + ' (' + $name + ')')
    try { Stop-Process -Id $procId -Force -ErrorAction Stop; W '  stopped' } catch { W ('  stop failed: ' + $_.Exception.Message) }
}

# 2) wait for the port to be released
$t = 0
while ($t -lt 25) {
    if ((Listeners $Port).Count -eq 0) { break }
    Start-Sleep -Seconds 1
    $t++
}
W ('port free after ' + $t + 's (listeners = ' + ((Listeners $Port) -join ',') + ')')

# 3) relaunch (start-dsh.ps1 picks the newest DSH build, and clears the marker)
Start-Sleep -Seconds 2
W 'invoking start-dsh.ps1'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'start-dsh.ps1')
W 'start-dsh.ps1 returned'
if ($Port -eq 3080) { Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue }
W '=== restart finished ==='
