﻿# DSH Web launcher - logs to ~/.dsh/logs/autostart.log
# 2026-09-10 rewrite (ASCII only on purpose):
#   - single-instance lock: HKCU Run and the desktop shortcut can fire within
#     seconds of each other; without the lock both start a server and the second
#     dies with EADDRINUSE (seen in dsh-web-console.err.log at 15:39:38).
#   - candidate chain with a health gate: newest npx-cache build -> global npm
#     install -> profiles runtime. A build that cannot boot no longer bricks
#     autostart; the launcher falls through to the next one.
#   - boot failures are snapshotted to ~/.dsh/logs/boot-failure.txt so the daily
#     check / next session can see WHY the GUI did not come up.
# NOTE: keep this file ASCII. It is started by powershell.exe -File (PS 5.1),
# where a UTF-8-without-BOM file containing non-ASCII would be mis-decoded.
$ErrorActionPreference = 'SilentlyContinue'
$logDir = 'C:\Users\Lenovo\.dsh\logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$logFile = Join-Path $logDir 'autostart.log'
$failFile = Join-Path $logDir 'boot-failure.txt'
function Write-Log($msg) { $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $msg; Add-Content -Path $logFile -Value $line -Encoding UTF8 }

$mutex = New-Object System.Threading.Mutex($false, 'Global\DshWebAutostart')
$owned = $false
try { $owned = $mutex.WaitOne(0) } catch { $owned = $true }   # abandoned mutex = previous launcher died
if (-not $owned) { Write-Log 'another launcher holds the lock - exiting'; exit 0 }

Write-Log '=== launcher invoked ==='
Remove-Item $failFile -Force -ErrorAction SilentlyContinue
# A restart that died halfway leaves this marker. Its presence means "the instance was supposed to
# be replaced": if nothing is answering, relaunch instead of treating it as a normal start.
$restartMarker = Join-Path $logDir 'restart-in-progress.txt'
$pendingRestart = Test-Path $restartMarker
if ($pendingRestart) { Write-Log 'restart-in-progress marker present - completing an interrupted restart' }
Remove-Item $restartMarker -Force -ErrorAction SilentlyContinue

# version key helper for picking the newest DSH build (PS 5.1 safe)
function Get-VerKey([string]$v) {
  $core = ($v -split '-')[0]
  $p = $core -split '\.'
  while ($p.Count -lt 3) { $p += '0' }
  return ([int]$p[0] * 1000000) + ([int]$p[1] * 1000) + [int]$p[2]
}

$port = 3080
$url  = 'http://127.0.0.1:' + $port

# 200 (page) or 401 (the harness browser-trust fence) both mean DSH is answering.
function Test-DshAlive([int]$p) {
  try {
    $r = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $p + '/') -TimeoutSec 5 -UseBasicParsing
    if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { return $true }
  } catch {
    if ($_.Exception.Response -ne $null) {
      $sc = [int]$_.Exception.Response.StatusCode
      if ($sc -ge 200 -and $sc -lt 500) { return $true }
    }
  }
  return $false
}

function Get-DshCandidates {
  # Plain arrays only: this script is started with powershell.exe -File, where
  # heavier .NET helpers have silently failed on this machine before.
  $out = @()
  $found = @()
  $npxRoot = 'C:\Users\Lenovo\AppData\Local\npm-cache\_npx'
  if (Test-Path $npxRoot) {
    foreach ($dir in (Get-ChildItem $npxRoot -Directory)) {
      $candPkg = Join-Path $dir.FullName 'node_modules\@deepseek-ai\dsh\package.json'
      $candBin = Join-Path $dir.FullName 'node_modules\@deepseek-ai\dsh\lib\bin.js'
      if ((Test-Path $candPkg) -and (Test-Path $candBin)) {
        $v = ((Get-Content -Raw $candPkg) | ConvertFrom-Json).version
        $found += [pscustomobject]@{ Path = $candBin; Label = ('npx ' + $v); Key = (Get-VerKey $v); Mtime = $dir.LastWriteTime }
      }
    }
  }
  # deterministic order: highest version first, then newest cache dir
  foreach ($f in @($found | Sort-Object -Property Key, Mtime -Descending)) { $out += $f }
  # stable fallbacks, so a broken/evicted npx build cannot brick autostart
  $fallbacks = @(
    (Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\lib\bin.js'),
    'C:\Users\Lenovo\.dsh\profiles\node_modules\@deepseek-ai\dsh\lib\bin.js'
  )
  foreach ($b in $fallbacks) {
    if (Test-Path $b) {
      $exists = $false
      foreach ($o in $out) { if ($o.Path -eq $b) { $exists = $true } }
      if (-not $exists) { $out += [pscustomobject]@{ Path = $b; Label = 'fallback'; Key = -1; Mtime = (Get-Item $b).LastWriteTime } }
    }
  }
  return $out
}

$node = 'D:\node\node.exe'
if (-not (Test-Path $node)) { $node = 'node' }
$stdout = Join-Path $logDir 'dsh-web-console.log'
$stderr = Join-Path $logDir 'dsh-web-console.err.log'

if ((Test-DshAlive $port) -and -not $pendingRestart) {
  Write-Log 'dsh already listening - opening browser'
  Start-Process $url
} else {
  if ($pendingRestart) { Write-Log 'instance is down after an interrupted restart - starting a fresh one' }
  $up = $false
  foreach ($c in (Get-DshCandidates)) {
    Write-Log ('trying ' + $c.Label + ' -> ' + $c.Path)
    $proc = Start-Process -FilePath $node -ArgumentList @($c.Path, 'web') -WorkingDirectory 'C:\Users\Lenovo' -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    Write-Log ('node pid=' + $proc.Id)
    $started = Get-Date
    while (((Get-Date) - $started).TotalSeconds -lt 90 -and -not (Test-DshAlive $port)) {
      Start-Sleep -Milliseconds 1000
      if ($proc.HasExited) { break }
    }
    $elapsed = [int]((Get-Date) - $started).TotalSeconds
    if (Test-DshAlive $port) {
      Write-Log ('dsh web up after ' + $elapsed + 's using ' + $c.Label)
      Start-Process $url
      $up = $true
      break
    }
    $exited = $proc.HasExited
    Write-Log ('candidate failed: ' + $c.Label + ' (exited=' + $exited + ', waited=' + $elapsed + 's)')
    if (-not $exited) {
      try { Stop-Process -Id $proc.Id -Force -ErrorAction Stop } catch { Write-Log ('  could not stop pid ' + $proc.Id + ': ' + $_.Exception.Message) }
    }
    # Start-Process pipes the child's stdio through the parent, so the redirect
    # files lag the exit by a moment - wait before reading the failure reason.
    Start-Sleep -Seconds 3
    $tail = ''
    if (Test-Path $stderr) { $tail = ((Get-Content $stderr -Tail 30 -ErrorAction SilentlyContinue) -join "`r`n") }
    if (-not $tail -and (Test-Path $stdout)) { $tail = ((Get-Content $stdout -Tail 15 -ErrorAction SilentlyContinue) -join "`r`n") }
    if ($tail) {
      Set-Content -Path $failFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  failed candidate: ' + $c.Label + ' (' + $c.Path + ')  node-pid=' + $proc.Id + '  exited=' + $exited + "`r`n" + $tail) -Encoding UTF8
    }
  }
  if (-not $up) {
    Write-Log 'FAILED: no candidate served dsh web; see boot-failure.txt'
    if (-not (Test-Path $failFile)) { Set-Content -Path $failFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  no dsh candidate produced a listening web UI') -Encoding UTF8 }
    # Last resort: dsh-safe wraps `dsh`, turns the failing plugin row into
    # `disabled: true` and retries.  That is the only automatic recovery when the
    # plugin tree itself is broken (all candidates share one profile), i.e. the
    # 2026-09-10 persona/0.1.5-rc.1 boot failure.  Without this the GUI stays
    # dead until somebody runs a terminal command by hand.
    $safeCmd = Join-Path $env:APPDATA 'npm\dsh-safe.cmd'
    if (Test-Path $safeCmd) {
      Write-Log 'escalating to dsh-safe (auto-quarantine + retry)'
      $sp = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', $safeCmd, 'web') -WorkingDirectory 'C:\Users\Lenovo' -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
      $started = Get-Date
      while (((Get-Date) - $started).TotalSeconds -lt 180 -and -not (Test-DshAlive $port)) {
        Start-Sleep -Milliseconds 1000
        if ($sp.HasExited) { break }
      }
      if (Test-DshAlive $port) {
        Write-Log ('dsh web up via dsh-safe after ' + [int]((Get-Date) - $started).TotalSeconds + 's')
        Start-Process $url
        $up = $true
      } else {
        Write-Log 'dsh-safe could not bring dsh web up either - manual intervention needed'
      }
    } else {
      Write-Log ('dsh-safe not found at ' + $safeCmd + ' - no automatic recovery available')
    }
  }
}

# Daily self-check (once per day, background, check-only - never auto-updates)
# Report lands in ~/.dsh/logs/dsh-check-latest.txt ; assistant reads it on first chat of the day.
$today = Get-Date -Format 'yyyyMMdd'
$checkDone = Join-Path $logDir ('dsh-check-' + $today + '.txt')
if (-not (Test-Path $checkDone)) {
  Write-Log 'spawning daily check (background)'
  Start-Process -FilePath 'powershell' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File','C:\Users\Lenovo\.dsh\dsh-daily-check.ps1','-Startup','-Quiet') -WindowStyle Hidden
} else {
  Write-Log 'daily check already done today - skip'
}

try { $mutex.ReleaseMutex() } catch { }
Write-Log '=== launcher finished ==='
