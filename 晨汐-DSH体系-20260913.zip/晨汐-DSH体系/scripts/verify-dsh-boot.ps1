﻿# verify-dsh-boot.ps1 - boot a THROWAWAY dsh web instance on a spare port and report
# whether the whole plugin tree loads, without touching the live instance (3080).
#
# Why: one bad plugin import kills the entire loader tree, so "does a second
# instance come up on another port" is the fastest full-tree compatibility test.
# The openclaw-persona HTTP route doubles as a "plugins are really mounted" probe.
#
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File verify-dsh-boot.ps1 [-Port 3081] [-TimeoutSec 90]
# Exit 0 = tree loaded and serving, 1 = failed (stderr tail printed).
param(
    [int]$Port = 3081,
    [int]$TimeoutSec = 90,
    [string]$Bin
)
$ErrorActionPreference = 'SilentlyContinue'
if (-not $Bin) {
    # same preference order as start-dsh.ps1: newest npx cache build
    $npxRoot = 'C:\Users\Lenovo\AppData\Local\npm-cache\_npx'
    $best = $null; $bestKey = -1
    foreach ($d in (Get-ChildItem $npxRoot -Directory -ErrorAction SilentlyContinue)) {
        $pkg = Join-Path $d.FullName 'node_modules\@deepseek-ai\dsh\package.json'
        $bin = Join-Path $d.FullName 'node_modules\@deepseek-ai\dsh\lib\bin.js'
        if ((Test-Path $pkg) -and (Test-Path $bin)) {
            $core = (((Get-Content -Raw $pkg) | ConvertFrom-Json).version -split '-')[0]
            $p = $core -split '\.'
            while ($p.Count -lt 3) { $p += '0' }
            $k = ([int]$p[0] * 1000000) + ([int]$p[1] * 1000) + [int]$p[2]
            if ($k -gt $bestKey) { $bestKey = $k; $best = $bin }
        }
    }
    if (-not $best) { $best = Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\lib\bin.js' }
    $Bin = $best
}
$node = 'D:\node\node.exe'
if (-not (Test-Path $node)) { $node = 'node' }
$out = Join-Path $env:TEMP ('dshverify-' + $Port + '.out.log')
$err = Join-Path $env:TEMP ('dshverify-' + $Port + '.err.log')
Remove-Item $out, $err -Force -ErrorAction SilentlyContinue

Write-Host ('[verify] bin  = ' + $Bin)
$proc = Start-Process -FilePath $node -ArgumentList @($Bin, 'web', '--port', $Port, '--no-open') -WorkingDirectory 'C:\Users\Lenovo' -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
Write-Host ('[verify] pid  = ' + $proc.Id)

$started = Get-Date
$up = $false
while (((Get-Date) - $started).TotalSeconds -lt $TimeoutSec) {
    Start-Sleep -Milliseconds 1000
    try {
        $r = Invoke-WebRequest ('http://127.0.0.1:' + $Port + '/api/openclaw-persona/files') -TimeoutSec 3 -UseBasicParsing
        if ($r.StatusCode -eq 200) { $up = $true; break }
    } catch { }
    if ($proc.HasExited) { break }
}
$secs = [int]((Get-Date) - $started).TotalSeconds

if ($up) {
    Write-Host ('[verify] OK - plugin tree loaded, persona route 200 after ' + $secs + 's')
} else {
    Write-Host ('[verify] FAILED after ' + $secs + 's (exited=' + $proc.HasExited + ')')
    Start-Sleep -Seconds 3
    Write-Host '--- stderr tail ---'
    Get-Content $err -Tail 25 -ErrorAction SilentlyContinue
    Write-Host '--- stdout tail ---'
    Get-Content $out -Tail 10 -ErrorAction SilentlyContinue
}
if (-not $proc.HasExited) { try { Stop-Process -Id $proc.Id -Force -ErrorAction Stop } catch { } }
Write-Host '[verify] test instance stopped'
if ($up) { exit 0 } else { exit 1 }
