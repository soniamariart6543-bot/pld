﻿# e2e-restart-test.ps1 - proves the 2026-09-13 restart fix on a throwaway port (default 3099).
# ASCII only (PS 5.1 -File safe). Never touches port 3080.
#
# Reproduces the failure that motivated the fix: the restart is started as a CHILD process, then the
# whole caller tree is force-killed mid-restart. Before the fix restart.log stopped right after
# "stopped" and the port stayed down (2026-09-13 22:01:28). Now a detached worker must finish the job.
param([int]$Port = 3099)
$root   = 'C:\Users\Lenovo\.dsh'
$log    = Join-Path $root 'logs\restart.log'
$node   = 'D:\node\node.exe'
if (-not (Test-Path $node)) { $node = 'node' }

function Port-Up([int]$p) {
    try { $r = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $p + '/') -TimeoutSec 3 -UseBasicParsing; return ($r.StatusCode -eq 200) }
    catch { if ($_.Exception.Response -ne $null) { return $true } ; return $false }
}

$before = @(Get-Content $log -ErrorAction SilentlyContinue).Count
Write-Host ('[1] port ' + $Port + ' up before setup? ' + (Port-Up $Port))

# --- a real listener process on the test port (this is what the worker must stop) ---
$dummy = Start-Process -FilePath $node -ArgumentList @((Join-Path $root 'test-assets\dummy-http.mjs'), $Port) -PassThru -WindowStyle Hidden
Start-Sleep -Seconds 3
$dummyPid = $dummy.Id
Write-Host ('[2] dummy listener pid=' + $dummyPid + '  port up now? ' + (Port-Up $Port))
if (-not (Port-Up $Port)) { Write-Host 'ABORT: dummy listener is not answering'; Stop-Process -Id $dummyPid -Force -ErrorAction SilentlyContinue; exit 1 }

# --- start the restart from a child process, exactly like the GUI path does ---
$restarter = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $root 'restart-dsh.ps1'),'-Port',$Port) -PassThru -WindowStyle Hidden
Write-Host ('[3] restarter child pid=' + $restarter.Id + ' (it detaches itself, then exits)')
Start-Sleep -Seconds 6

# --- kill the caller tree: this is the accident that killed the old script mid-restart ---
$killed = $false
try { Stop-Process -Id $restarter.Id -Force -ErrorAction Stop; $killed = $true } catch { }
if (-not $killed) { Write-Host '[4] restarter already exited on its own (expected: it detaches then exits)' } else { Write-Host '[4] restarter tree force-killed' }

Write-Host '[5] waiting for the detached worker to finish...'
Start-Sleep -Seconds 50
$stillUp = Port-Up $Port
Write-Host ('[6] test port still up after the detached worker ran? ' + $stillUp + '   (false = the worker really stopped it)')
$dummyGone = -not (Get-Process -Id $dummyPid -ErrorAction SilentlyContinue)
Write-Host ('[7] dummy listener process gone? ' + $dummyGone)

Write-Host '[8] restart.log entries from this test:'
@(Get-Content $log -ErrorAction SilentlyContinue) | Select-Object -Skip $before | ForEach-Object { Write-Host ('    ' + $_) }

# --- early-exit path: with nothing listening, a new request should again spawn a worker ---
$mark = @(Get-Content $log -ErrorAction SilentlyContinue).Count
$again = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $root 'restart-dsh.ps1'),'-Port',$Port) -PassThru -WindowStyle Hidden
$again.WaitForExit(20000) | Out-Null
Start-Sleep -Seconds 2
Write-Host '[9] second request (nothing listening) -> log:'
@(Get-Content $log -ErrorAction SilentlyContinue) | Select-Object -Skip $mark | ForEach-Object { Write-Host ('    ' + $_) }

# --- cleanup: whatever the worker left, plus any leftover dummy ---
foreach ($p in @($dummyPid)) { if (Get-Process -Id $p -ErrorAction SilentlyContinue) { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue; Write-Host ('[cleanup] stopped leftover dummy pid ' + $p) } }
$leftovers = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*dummy-http.mjs*' })
foreach ($lo in $leftovers) { Stop-Process -Id $lo.ProcessId -Force -ErrorAction SilentlyContinue; Write-Host ('[cleanup] stopped leftover dummy pid ' + $lo.ProcessId) }
Write-Host ('[cleanup] port 3080 untouched; markers used only by port 3080. marker present now: ' + (Test-Path (Join-Path $root 'logs\restart-in-progress.txt')))
