# 本机 DSH 环境 · 会话交接备忘（2026-09-08 由长会话整理）

> 用途：新会话开场/涉及环境配置时先读本文件，快速调出“这台机器上的 DeepSeek Harness”装了什么、约定什么、坑在哪。
> 配套人格规则：见 ~/.dsh/persona/SOUL.md 行为准则与 MEMORY.md。

## 1) 安装形态
- DSH Web GUI：由 `npx @deepseek-ai/dsh web` 启动，host profile = `C:\Users\Lenovo\.dsh\profiles\web`
- 全局 Persona 文件（五件套，侧边栏 Custom Persona 可编辑）：`C:\Users\Lenovo\.dsh\persona\{SOUL,IDENTITY,USER,MEMORY,TOOLS}.md`（SOUL→IDENTITY→USER→MEMORY→TOOLS 顺序注入人格）
- 已装插件（web profile bundles，共 15 层）：openclaw-persona、dsh-im、dsh-context、dsh-plugin-manager、dsh-routing-suite、dsh-tools、dsh-vision-router、dsh-whale-widget、dsh-zagens-office、dsh-office-tools、minecraft-dev、dsh-web-fetch-playwright（另 base+web-app）

## 2) 关键约定
- **文档输出**：交付文档默认生成标准 .docx（office_schema/office_write/office_edit/office_read，引擎 ~/.zagens-pro/bin/zagens-office.exe v0.12.0）；中间 .md 草稿用毕即删。
- **第一行规则**：人格设定下每次输出第一行 = `Ciallo～(∠・ω< )⌒★`（改 SOUL.md 可移除）。
- 语气：活泼俏皮+雨雾底色（缪尔赛思气质启发，非扮演）。

## 3) 识图（Vision Router）
- 视觉后端链：智谱优先 `glm-4v-flash` → `glm-4.1v-thinking-flash` → OVH 匿名兜底。
- 智谱 Key：存 `~/.dsh/.credentials.yaml` → `refs.ZHIPU_API_KEY`（勿明文外传）。
- 配置位置：profile 补丁 `~/.dsh/profiles/web/cordis.patch.yml`（vision-router 段）。
- 用法：发图前点输入框旁「👁 识图」成 `识图 ✓`。

## 4) 上网防拦（web_fetch）
- `dsh-web-fetch-playwright`：web_fetch 走真实浏览器（Edge），SPA/CF 挑战页更稳。
- 设置：`~/.dsh/settings.yaml` → `web-fetch-playwright`（local backend + Edge 路径）。

## 5) MC 模组 / Java 开发
- `minecraft-dev` 已装（Fabric/Forge/NeoForge/Paper/Spigot，mc_gradle 运行器、四大代理技能：mc_plan/skeleton/content/verify）。本会话还挂载了 fabric/forge/neoforge/paper/spigot/java/major-mods 等技能目录。

## 6) 开机自启（已修复，坑！）
- 入口：注册表 HKCU Run「DSH Web」→ `wscript C:\Users\Lenovo\.dsh\start-dsh-web-hidden.vbs`（必须纯 ASCII，别写中文注释）
- 启动器：`C:\Users\Lenovo\.dsh\start-dsh.ps1`（**2026-09-10 重写，纯 ASCII**）
  - 3080 已就绪（HTTP 200/401 均算活着）→ 直接开浏览器；否则按候选链启动：npx 缓存最新版 → 全局 npm → profiles，逐个健康检查（每个最多 90s），失败自动换下一个
  - 启动器互斥锁 `Global\DshWebAutostart`：HKCU 自启与桌面快捷方式同时触发时不再双开抢端口（历史 EADDRINUSE 就是这个）
  - 全部候选失败 → 兜底 `dsh-safe web`（自动把导致崩溃的插件行置 disabled 后重试）＝「插件与新 core 不兼容、整树起不来」的唯一自动恢复路径
  - 失败原因快照 `~/.dsh/logs/boot-failure.txt`；每日自检 [7] 会汇报
  - 原脚本备份：`start-dsh.ps1.bak-pre-fix-20260910`
- ⚠️ 历史坑：文件名 `open-dsh-web.ps1` 会被安全软件定点删除（写一次删一次），**不要再创建该文件名**；日志在 `~/.dsh/logs/autostart.log` 与 `dsh-web-console*.log`
- **重启通道**：优先用 `C:\Users\Lenovo\.dsh\restart-dsh.ps1`（先杀掉 3080 监听进程 → 等端口释放 → 调用 start-dsh.ps1，即上面那条带锁+候选链的路）。
  ⚠️ GUI 里 dsh-tools 的「重启」按钮走的是插件自己生成的 `profiles\web\plugins-data\dsh-tools-restart-launcher.ps1`，
  它只 `Start-Process` 直接起 `profiles` 那份旧副本、且不等端口释放（有 EADDRINUSE 风险）——**按钮起不来时改用 restart-dsh.ps1**。
- 桌面快捷方式：`C:\Users\Lenovo\Desktop\DeepSeek Harness.lnk` → start-dsh.ps1

## 7) 微信 IM 通道（全能对话入口）
- 手机端经微信 IM 插件与 DSH 对话（用户看不到本机文件）：**微信会话 = 全能对话框**，
  遗物mod 需求/规划、学术、生活、健康、情感、数码等各类话题都会从微信发来
  （2026-09-08 昀晞明示，勿只当「遗物mod 专用通道」）。
- 遗物mod 跨端协作：微信端提需求 → 登记 `D:\DeepSeek\遗物mod\日志\需求池-跨端.txt` →
  电脑端按编号开发闭环；微信端汇报需自带完整快照（对齐颗粒度）。

## 8) GitHub 抓取备忘（2026-09-09 实测）
- 本机直连 github.com / raw.githubusercontent.com **超时**（连接被阻断）；api.github.com **可用**。
- 会话内抓 GitHub 时用镜像回退（勿裸抓 raw/页面）：
  工具 `pwsh C:\Users\Lenovo\.dsh\ghfetch.ps1 -Url <url> [-Out <file>]`
  回退链：ghfast.top → gh-proxy.com → cdn.jsdelivr.net/gh（raw 专用）
  实测：gh-proxy ≈0.6s / ghfast ≈1.0s / jsdelivr ≈2.6s
- web_fetch（playwright 后端）无内置代理/镜像配置字段；DSH 插件市场无 GitHub 加速插件。

## 9) DSH 自检 / 更新（2026-09-10 昀晞要求）
- 脚本：`C:\Users\Lenovo\.dsh\dsh-daily-check.ps1`（**纯 cmdlet 写法、PS 5.1 兼容**；
  勿用 ArrayList + `[System.IO.File]::WriteAllText` 等 .NET 静态调用——在 `-File` 下静默失效）
- 检查项：运行版 DSH（`~/.dsh/profiles/node_modules/@deepseek-ai/dsh`）、npx 缓存版、
  npm registry 最新版、profile 插件是否过期、pi-ai 模型清单是否出现 v4.1、自启项 + 3080 端口
  （2026-09-10 起：[1][2] 改为分别报 profiles/全局/npx 副本并标注「launcher 实际会启动的版本」；
  新增 [4b] 插件扫描 = 兼容体检（每个插件的 `@deepseek-ai/*` 命名导出在本内核是否都存在）
  + 声明 bundle 是否可解析（核心 bundle 从 DSH 安装/profiles 提升库解析，别只看 profile\web\node_modules，
  否则 core 自带项会误报不可解析）；
  新增 [7] boot safety = dsh-safe 隔离条数 + `boot-failure.txt` + persona 兼容 shim 是否还在）
- 报告：`~/.dsh/logs/dsh-check-latest.txt` 与 `dsh-check-<yyyyMMdd>.txt`
- 参数：默认只检查；`-Apply` 拉取最新 DSH 到 npx 缓存（不动运行实例，先备份 package/lock）；
  `-ApplyPlugins` 连插件一起 `pnpm update`（有兼容风险，且受 pnpm 24h 供应链延迟限制）
- 开机自启：`start-dsh.ps1` 每天首次启动后台跑一次检查（只检查、不更新；当天已有报告则跳过）
- **会话规则**：每天首次对话（或涉及 DSH/本机环境）→ 先读 `dsh-check-latest.txt`；
  若报告不是今天的 → 跑一次脚本，再向昀晞汇报「DSH 版本 / 插件过期数 / 模型清单」状态
- **插件扫描必须汇报（2026-09-10 昀晞追加要求，落点＝会话窗口）**：每天首次对话除了版本/过期/模型，
  **必须**把插件扫描结果按固定格式报一遍：
  「插件扫描：兼容体检 X 个导出 / Y 个不匹配（列不匹配项）· 声明 bundle N 个 / 不可解析 M 个 ·
   dsh-safe 隔离 K 条 · persona 兼容层 在/不在」；出现异常先报异常 + 修复动作，再报其余。
  单独跑扫描：`node C:\Users\Lenovo\.dsh\check-plugin-compat.mjs [profileDir]`（exit≠0 表示有不匹配）。
- 更新切换：关闭当前 DSH → `npx @deepseek-ai/dsh@latest web`（新版进 npx 缓存）
- **启动选版（2026-09-10 起）**：`start-dsh.ps1` 会自动挑 **npx 缓存中版本最高**的 DSH 启动
  （无缓存则回退 `profiles` 旧路径）→ 所以升级流程 = 「`-Apply` 拉取最新」+「重启 DSH」即生效；
  原脚本备份：`start-dsh.ps1.bak-20260910` / `.bak2-20260910`
- 模型（如 v4.1）：**无需安装**，API 侧提供，DSH 组件（pi-ai 数据）更新后自动出现在模型清单

## 10) 待办/提醒（下回新会话可主动续）
- 重启 dsh web 后验证：autostart.log、插件加载（zagens-office / office-tools / minecraft-dev / web-fetch-playwright 均已入 bundles，重启即生效）
- 识图智谱链与 playwright 抓取尚未在重启后端到端实测
- 压缩插件 compaction-basic / command-compact 已于 2026-09-08 启用（profile 补丁 `disabled: false`；默认 80% 阈值自动压缩、溢出恢复、`/compact` 命令可用）
  （2026-09-10 曾被误禁，已恢复；见第 11 节）

## 11) 插件兼容事故与修复（2026-09-10，务必知其所以然）
- **事故**：DSH core 0.1.2-rc.1 → 0.1.5-rc.1 升级后 `dsh web` 整树加载失败、GUI 起不来：
  `@lynsucceed/dsh-openclaw-persona@0.1.1`（npm 最新就是它）仍 `import { PERSONA_SECTION } from "@deepseek-ai/dsh-system-prompt"`，
  而 0.1.5-rc.1 把该导出改名为 `PERSONA_PREFIX_SECTION` / `PERSONA_SUFFIX_SECTION`
  （前缀仍是 order 0 ＝ 原 persona 槽位的直接继任者）。加载器把「一个插件 import 失败」判为整树失败 →
  任何 dsh 副本（npx 缓存/全局 npm/profiles）都起不来，因为它们共用同一个 web profile。
- **dsh-safe**（`@hyzyn/dsh-safe`，全局命令）：崩溃时把 persona 插件行自动置 `disabled: true`，GUI 才恢复；
  台账 `~/.dsh/dsh-safe/quarantine.json`。它只在**手动/显式调用**时生效，`dsh web` 本身不带保险。
- **修复（已完成）**：给插件就地打兼容层（`profiles\web\node_modules\@lynsucceed\dsh-openclaw-persona\lib\index.js` 顶部
  `const PERSONA_SECTION = sp.PERSONA_SECTION ?? sp.PERSONA_PREFIX_SECTION ?? "deployment:persona-prefix"`），新旧 core 通吃；
  原文件备份 `lib\index.js.orig-0.1.1`。**已升级为 pnpm 官方补丁**（见第 12 节）：`patches\@lynsucceed__dsh-openclaw-persona@0.1.1.patch`
  注册在 `pnpm-workspace.yaml` → `patchedDependencies`，任何 `pnpm install/update` 都会自动重放，不再需要手动修复；
  `C:\Users\Lenovo\.dsh\fix-openclaw-persona.ps1`（幂等，可 `-DryRun`）保留作应急。每日自检 [7] 会检查 shim 是否还在。
- **顺带清掉的误伤**：`cordis.patch.yml` 里为救急写的 `- id: "*" disabled: true`（通配符**不受支持**，只是「已全禁」的错觉）
  连同 dsh-fix 三条 disabled，把 vision-router(识图) / compaction-basic(自动压缩) / command-compact(/compact) 一起误禁了；
  已全部删除并恢复 `disabled: false`。**教训：写 disabled 前先确认真因，别整片进「安全模式」。**
- **可复用验证法（不动线上实例）**：空闲端口起第二实例做全树验证——
  `node <dsh>\lib\bin.js web --port 3081 --no-open`，再探 `http://127.0.0.1:3081/api/openclaw-persona/files`（200 ＝ 插件已挂载）；
  客户端插件清单可在带 token 的首页 HTML 里 grep 插件名。本次即用此法确认 persona + vision-router 均已回归。
  ⚠️ 注意：launcher 传的 `web` 不带 `--port`，端口来自 profile 配置（3080）——测试实例必须显式加 `--port`。

## 12) 插件升级记录（2026-09-10，昀晞要求「升级插件并且确认适配」）
- **升级结果**（每个都过了「导入导出体检 + 3081 全树启动 + 客户端清单」三重验证）：

  | 插件 | 前 → 后 |
  | --- | --- |
  | dsh-tools | 1.1.1 → **1.1.2**（已到最新） |
  | dsh-vision-router | 2.1.3 → **2.1.5**（用户放行白名单） |
  | @xmanrui/dsh-im | 4.13.0 → **4.18.1**（用户放行白名单） |
  | dsh-context | 0.44.0 → **0.47.0** |
  | minecraft-dev | 0.7.0（0.7.1 发布未满 1h，等过隔离期再升） |

- **供应链延迟（新知识点）**：pnpm 12 默认隔离「发布未满 **24 小时**」的版本（本机没显式配置 `minimumReleaseAge`，是默认行为）。
  要装新发布版本 → 在 `profiles\web\pnpm-workspace.yaml` 的 `minimumReleaseAgeExclude` 加一行 `包名@版本`。
  已放行：`dsh-vision-router@2.1.5`、`@xmanrui/dsh-im@4.18.1`；待放行：`dsh-context@0.49.0`、`minecraft-dev@0.7.1`。
  ⚠️ `dsh-daily-check.ps1 -ApplyPlugins` 走 `pnpm update`，同样受这道门限制，会**静默停在允许的版本**——报告里仍显示 OUTDATED 是正常的。
- **persona 兼容层已改成 pnpm 官方补丁**：`profiles\web\patches\@lynsucceed__dsh-openclaw-persona@0.1.1.patch`，
  注册在 `pnpm-workspace.yaml` → `patchedDependencies`；**每次 `pnpm install/update` 自动重放**（已实测：升级过程中被 pnpm 重建 node_modules 后自动恢复）。
- **可复用验证脚本（新增）**：
  - `C:\Users\Lenovo\.dsh\check-plugin-compat.mjs` —— 静态体检：扫每个插件里的
    `import { … } from "@deepseek-ai/*"`，逐个核对新内核是否真的导出这些名字（＝本次事故的失败类型）。
    当前 12 个插件 / 30 个导出全部 ok；**换内核后先跑它，能在启动前抓出同类不兼容**。
  - `C:\Users\Lenovo\.dsh\verify-dsh-boot.ps1 [-Port 3081]` —— 空端口起第二实例做全树启动验证，不动 3080 线上实例。
- **升级后必须重启才生效**：线上实例仍持有旧的内存模块，而客户端 bundle 是按请求从磁盘读的，
  「旧宿主 + 新 bundle」混用有风险 → **升级完先重启 dsh web，再刷新页面**。
- 备份：`~\.dsh\logs\backups\plugin-upgrade-20260910-160521\`（package.json / pnpm-lock.yaml / cordis.patch.yml / persona 补丁后的 index.js）。

## 13) agent-preset 兼容事故与修复（2026-09-10 傍晚，微信 IM + 智能路由同时失灵的真因）★
- **症状**：① 手机微信端每轮回「任务未完成，暂时无法确定原因…错误码：INTERNAL_UNKNOWN；参考号：MF-xxxxxxxx」；② GUI 里「智能路由模式」点选无效/不生效。
- **真因（同一根）**：`~/.dsh/.agent-presets/` 下的**用户自定义 preset 不随 DSH 内核升级**。core **0.1.5-rc.1** 起 `@deepseek-ai/dsh-persona` 配置字段由 `text:` 改为 **`prefix` / `suffix`**；旧的 `text:` 写法让整个 preset 挂载失败：
  `agent-presets: preset "routing-suite" failed to mount: … persona … $.prefix missing required value (…\.agent-presets\routing-suite\agent.cordis.yml)`
  → 微信那条会话（`session-d8fa7006…`，`agentPreset: routing-suite`）每轮都起不来 → dsh-im 收到 `harness-turn-failed` → 映射成 INTERNAL_UNKNOWN 兜底文案（**不是**微信平台/网络问题，也不是模型问题）。
- **已修复（含备份）**：
  - `~/.dsh/.agent-presets/routing-suite/agent.cordis.yml`：`text:` → `prefix:` + `suffix: Your working directory is {{cwd}}.`
  - `~/.dsh/.agent-presets/minecraft/agent.cordis.yml`（同病，人格正文在 prefix、`{{cwd}}` 由 suffix 注入）
  - 备份：同目录 `*.bak-20260910-1635`。
- **验证方法（可复用）**：空端口 3081 起第二实例 → `GET /?token=<启动 token>` 换签名 cookie → `POST /api/session/create`，body `{"type":"client-request","rpcId":"p","method":"session/create","payload":{"args":{"request":{"agentPreset":"<id>"}}}}`；返回 `ok:true` 即 preset 可挂载。修复后实测 `routing-suite` / `minecraft` / `standard` 三个都 `ok:true`。启动 token 在 `~/.dsh/logs/dsh-web-console.log`。
- ⚠️ **注意事项**：验证用的第二实例**也会把微信机器人（dsh-im）挂上**，验证完务必立刻停掉实例，避免与 3080 抢消息；本次验证留下的空会话（`session-3dd51b7a…`、`session-aade0daa…`、`session-bbfc921e…`、`session-2f157601…`、`session-aac8aa15…`）均为空白测试会话，可在 GUI 里忽略/归档。
- **下次内核升级后第一件事**：跑 `check-plugin-compat.mjs`（插件导出）+ 本节的 preset 挂载探针（用户 preset 的 schema）——两类失败都在「启动前/会话创建时」可当场抓出来。

## 14) 智能路由第二处失灵的修复（2026-09-10 晚间，需重启生效）★
- **两个 bug 是独立的**：① preset 挂载失败（第 13 节，已修，**无需重启**）；② `dsh-routing-suite@0.1.2` 与 core 0.1.5-rc.1 的 **Session API 不兼容**。
- **不可兼容点（源码级证据）**：插件用 `session.events` 数组做两件事——取首条用户消息做任务分类、读 `agent-preset/selected` 判断 preset；
  而 0.1.5-rc.1 的 `Session` 类**没有 `events` 字段**（只有 `log` / `eventAt()` / `snapshotEvents()` / `ownEvents()`）。
  → `firstUserText()` 恒为空 → `classifyTask()` 恒为 `neutral` → 永远不注入路由指引；探针实测：hook 正常触发、`preset="routing-suite"`、`mode=neutral`，sections 里从无 `routing-suite-guidance`。
- **修复（已做）**：
  - 就地补 `sessionEvents(session)` 兼容 shim（`Array.isArray(session.events)` → `session.snapshotEvents()` → `session.ownEvents()` → `session.eventsSnapshot`），`firstUserText()` 与 `selectedPreset()` 都改走它；
  - 文件：`profiles\web\node_modules\dsh-routing-suite\lib\index.js`（原件备份 `.bak-probe-20260910`；修复版快照 `.fixed-20260910`）；
  - 已升级为 **pnpm 官方补丁**：`profiles\web\patches\dsh-routing-suite@0.1.2.patch`，注册进 `pnpm-workspace.yaml → patchedDependencies`（`pnpm install --lockfile-only` 通过），换内核/重装依赖后自动重放。
- **验证**：空端口 3081 实例 + 一条「修复报错…先检查日志」任务 → 会话 `system/message` 里出现 `Routing guidance: this is a maintenance or investigation task…`（第 1 条 system 消息为旧快照，第 2 条才含指引，属正常）。
- ⚠️ **必须重启 `dsh web` 才生效**：3080 线上实例（pid 4020，16:14:02 启动）加载的是**修复前的插件代码**，内存里不会自动热更；重启后再开「智能路由模式」验证。
- 微信 IM 侧：preset 修复无需重启，可直接发消息验证；若仍失败，先看 `integrations\dsh-weixin\accounts\...\state.json` 时间戳。
- 本轮验证遗留空白测试会话（可忽略/归档）：`session-297dceb2…`、`session-8c04401e…`、`session-905a7ca6…`、`session-bc385d58…` 等。

## 15) 重启记录与「下回开工第一件事」（2026-09-10 晚间）
- 本次重启原因 = 让第 14 节的路由插件修复生效（preset 修复本来就已生效）。重启走 `restart-dsh.ps1`（带锁 + 候选链，会自动挑 npx 缓存里最高版本的 DSH）。
- **下回开工验证清单（按顺序）**：① 读本节 + 第 13/14 节；② 开「智能路由模式」跑一条「修复/排查类」任务 → 看是否按「先查根因」风格行事（或直接在会话日志里 grep `Routing guidance`）；③ 微信端发一句 → `INTERNAL_UNKNOWN` 应消失；④ 跑 `dsh-daily-check.ps1` 汇报版本/插件/扫描；⑤ 顺手确认 `pnpm-workspace.yaml` 里两条 `patchedDependencies`（persona + routing-suite）都还在。
- 若重启后智能路由仍不注入：先确认**磁盘上的 `lib/index.js` 含 `sessionEvents(` 兼容 shim**，再确认 `dsh web` 进程启动时间晚于文件修改时间（`Get-CimInstance Win32_Process`），最后才怀疑别处。

## 16) MITE 遗物整合包（2026-09-12，独立可玩包 + 错误总账）★
- **交付物**
  - 独立整包目录：`D:\DeepSeek\遗物打破\`（自带 `jre\` Java17、`PCL启动器.exe`、`开始游戏.bat`、`.minecraft\`）
  - 分发 zip：`D:\DeepSeek\遗物打破-独立整合包.zip`（233MB，**条目正斜杠规范版**）＋ 桌面同名一份
  - 工作实例（被整包抽料）：`D:\DeepSeek\整合包\versions\1.6.4-MITE-FML\`
  - 模组工程：`D:\DeepSeek\遗物mod\MITE\relic-mite`（fml-loom；产物 `relic-mite-0.1.0.jar`，SHA16 0237BB1F607BA100）
  - 可复用脚本：`遗物mod\MITE\{smoke-test, build-pack, verify-pack, zip-pack}.ps1`
- **模组功能（MITE 1.6.4 + FishModLoader 3.4.2）**：无尽铁镐 / 骨斧 / 骨甲四件套；开局自动发 6 件；死亡不掉落（含穿在身上）；命令 `/relic status|test|give`；无升级系统
- **待昀晞实机验证**：开局发放 / 死亡不掉落 / 观感（骨斧仍是占位贴图）
- **错误总账（本会话全部错误，含真因与证据）**：`D:\DeepSeek\遗物mod\日志\总账-本会话错误与修复-20260912.txt`
  另有两条已写入长期记忆：`persona\MEMORY.md`（错误总账·最该记住的十条）、`persona\TOOLS.md`（工具链踩坑总账 + MITE 开发备忘）
- **最该先记住的三条硬坑**（详见总账 B1 / E1 / E3）：
  1. MITE `ServerPlayer.onDeath` **不调 super** → 死亡相关 mixin 挂 EntityPlayer 会"混入成功但零效果"
  2. 给人/PCL 的 zip **条目名必须 `/`**（.NET `CreateFromDirectory` 会写 `\` → PCL 报「文件结构不匹配」）
  3. jlink 精简 JRE **必须带 `java.compiler`**（否则 MixinExtras 启动即 `NoClassDefFoundError`）
- **素材源**：曾用某第三方 MITE 整合包（含 R196 客户端，作贴图/音效来源）——**2026-09-12 按昀晞要求已全部清理**（源包 + 提取 jar + 派生资源包 + 语言音效 + 注入贴图）

## 17) 习惯 / 日历 / 防跑偏三件套 + 每日自检升级（2026-09-13）★
- **新增文件**
  - `~/.dsh\habits.md` —— 昀晞使用习惯与执行纪律（开场锚定 5 步、跨端协作、取证优先、交付偏好、红线、更新策略、每日必报内容）
  - `~/.dsh\anti-drift.md` —— 跑偏根因蒸馏（10 条真因 → 对应防线）+ 开场前/任务中/收尾前检查清单 + 可复用资产清单
  - `~/.dsh\calendar\calendar.md`、`2026-holidays.json`、`2026-cn-holidays.ics` —— 日历（数据源 timor.tech，每日自检自动刷新）；锚定日 2026-09-13 周日，下一休息日＝中秋节 09-25
- **`dsh-daily-check.ps1` 升级段落**
  - `[3]` 增加**稳定性闸门**：查 registry `time.<版本>` 发布天数 → <3 天＝观察期（不装）；rc/alpha/beta＝需昀晞明示同意；release 且 ≥3 天＝可提议。**任何情况都不自动安装**
  - `[8]` 校时：百度 HTTP `Date` 头对比本机，\|drift\|>120s 提示 `w32tm /resync`；会话日期锚定以它为准
  - `[9]` 日历刷新：timor.tech → `calendar.md`（今天 / 未来 60 天放假与补班 / 自定义节点占位）
  - `[10]` GitHub 通道探针：api.github.com、gh-proxy.com、ghfast.top 逐一测速，并提示直连被墙
  - 实测（2026-09-13 21:32）：drift 0s、日历刷新 OK、三条通道全 OK；报告落 `~/.dsh\logs\dsh-check-latest.txt`
- ⚠️ **BOM 陷阱再犯**：`edit` 工具写回 `.ps1` 会丢 BOM → PowerShell 5.1 按 GBK 解析中文脚本直接语法错。
  已做工具：`~/.dsh\fix-ps1-bom.ps1 -Path <脚本>`（改完 .ps1 立刻跑一次）

## 18) 路由插件组改造：习惯感知路由（2026-09-13）★
- **分类器 2 类 → 6 类 + 习惯附注**（`profiles\web\node_modules\dsh-routing-suite\lib\index.js`；母本 `~/.dsh\patched-src\dsh-routing-suite\`）
  优先级：`evidence-first`（排障＝先日志/探针取证）→ `doc-deliver`（交付 .docx）→ `direct`（实现/创作）→ `project-anchor`（遗物mod/整合包＝先核日期+读 README/日志+版本号铁律+发布顺序）→ `env-ops`（DSH/插件＝先读当日自检+更新策略）→ `inspect-first`（通用维护）
  附注（可叠加）：project（收尾清理）/ doc（.docx、草稿即删）/ ops（改动需重启才生效）/ github（用 `ghfetch.ps1` 或镜像前缀，别猜链接）
- **Config 新增**：`scope: all|preset`（**默认 all**＝本 profile 所有会话都注入；要恢复旧行为改 `preset`）、`strategy` 可钉死单一模式
- **新增干跑接口**：`GET /routing-suite/api/classify?text=...`（不必重启即可验证分类）；`/status` 增加 scope / modes
- **pnpm 补丁已重新生成**：`patches\dsh-routing-suite@0.1.2.patch`（273 行、纯 LF、`git apply --check` exit 0）
- **preset 纪律块**：`~/.dsh\.agent-presets\routing-suite\agent.cordis.yml` **与** 插件自带 `preset\routing-suite\agent.cordis.yml` 都注入 8 条工作纪律；
  插件自带副本原先仍是坏的 `text:` 字段（旧版遗留地雷），已改成 `prefix/suffix`；两份 YAML 均解析验证（16 行、prefix 有、suffixBlock 有、无 legacy text）
- ⚠️ **仍需重启 `dsh web`** 才加载新分类器（插件入口启动时加载；preset 纪律对新会话即生效）

## 19) 本轮事故与教训（2026-09-13）
- **通配符误伤**：`Get-ChildItem -Filter 'index.js.*'` 在 Windows 上连 `index.js` 本体与 `index.js.map` 一并匹配 → 清理"备份"时把插件主文件移走，`lib\` 一度只剩 client.js。
  已从母本还原（SHA16 `B5EF4340FBF108E9`，import 8 导出正常）。**教训：动 node_modules 里的文件不许用通配符，逐个 `-LiteralPath`。**
- **新增还原脚本**：`~/.dsh\restore-patched-src.ps1`（重装/升级覆盖后就地重放 `lib/index.js` + 两个 preset 文件，幂等，ASCII-only 免 BOM 坑）

## 20) 路由插件组 v2：习惯锚定注入 + github 模式 + 日历持久化（2026-09-13 晚）★
- **插件升级（`patched-src\dsh-routing-suite\lib\` 是母本，改完必须重生成 pnpm 补丁）**
  - 新增 `lib/anchor.mjs`：**习惯锚定**注入。每轮 system prompt 里加一条 `habit-anchor` 段（order 9）：
    今天日期（权威，不必再猜/再查）+ 当日自检摘要（版本/扫描/隔离/persona shim/时钟漂移/github 通道）
    + 日历摘要 + 待更新插件及观察期 + 纪律提醒。文件 mtime 变了或超过 `anchorTtlMs`(默认 60s) 才重读，per-repo 解析。
  - 分类器新增 **第 7 模式 `github`**（排在 env-ops 之前）：命中 github/仓库/镜像/拉取/release 等 →
    注入 API 优先 + `ghrelease.ps1`/`ghfetch.ps1` 的取证式指引，杜绝「猜链接 → 超时 → 重试」。
  - `DIRECT_PATTERNS` 补 `做个|搞个|弄个|帮我弄|整理|规划`；Config 新增 `anchor`(默认 true) 与 `anchorTtlMs`。
  - **补丁工作流（重要）**：`powershell -File C:\Users\Lenovo\.dsh\make-pnpm-patch.ps1 -Verify`
    —— 从 npm 拉 pristine tarball → git 仓库 diff → 写 `patches\dsh-routing-suite@0.1.2.patch`（无 BOM/LF）
    → 校验能干净 apply 且结果与母本哈希一致 → 部署进 node_modules + `node --check`。
    ⚠️ **教训**：手工重生成补丁时曾把补丁文件写成 0 字节（pristine 树里混进了 `index.new.js`，
    生成出空 diff 并把旧补丁覆盖掉）→ 以后一律走这个脚本，不许手搓。
- **新增 `~/.dsh\ghrelease.ps1`**：`-Repo owner/name [-All] [-SinceDays N] [-Path <file>] [-Asset <name>]`
  走 api.github.com 打印仓库元数据 / release 标签 + **发布时间与天数**（<3 天标观察期）/ 可用的 raw 与 asset 镜像 URL。
- **日历改为可持久化**：`calendar\custom.json`（`[{date,title,note}]`）为真源；`calendar.md` 的「自定义节点」
  手工内容也会被导入并保留（此前每次刷新都被清空）。`dsh-daily-check.ps1` 读该 JSON/md 时**必须显式 UTF-8**
  （`Get-Content -Raw` 按 GBK 读 → 中文乱码 → JSON 解析失败，本次真踩）。
- **自检脚本新增**：`[11] 脚本 BOM 体检`（非 ASCII 的 .ps1 缺 BOM → PS 5.1 会按 GBK 解析，静默失效；
  `restart-and-verify.ps1` 本次即中招，已用 `fix-ps1-bom.ps1` 补回）；
  `[12] agent preset 形状体检`（legacy `text:` 字段 / persona 缺 `prefix:` 块 / 缺 preset.yml → 直接点名）；
  `[4]` 过期插件现在带**发布时间与观察期判定**（ready ≥3d / WAIT <3d）。
- **预设挂载验证（可复现）**：见 `~/.dsh\preset-probe.cordis.md`（十几行代码 + 两步操作）。
  动态插件 `preset-1` 的 `preset_mount_check` 工具 → 调 `agentPresets.standingKeyFor(id)` 逐个 mount 校验，不留测试会话。
  实测 2026-09-13：`minecraft` MOUNT OK、`routing-suite` MOUNT OK。
  ⚠️ 动态插件只活在当前进程：**重启 `dsh web` 后工具消失**，按该 md 重新 define+run 即可（约 20 秒）。
- ✅ **已完成重启并验证（2026-09-13 21:51）**：3080 上的实例为重启后新进程，`/routing-suite/api/status`
  返回 7 个模式（含 `github`），`/classify?text=从 github 拉最新 release` → `github`（线上实例跑的是新代码）。
- ✅ **重启已完成并验证（2026-09-13 21:51，line 243）**：anchor 与 github 模式均已随新进程生效。
  ⚠️ 但**本会话窗口是在重启前建立的**，其 system prompt 在上一次装配时还没带锚定段；开个新会话即可看到习惯锚定注入。
- ⚠️ **重启 `dsh web` 会让所有动态 Cordis 插件消失**（含 `preset_mount_check`），需要时按 `preset-probe.cordis.md` 重建。

## 21) 晨汐 agent 预设（2026-09-13 晚，已成为新会话默认）★
- **新增预设**：`~/.dsh\.agent-presets\chenxi\`（`agent.cordis.yml` + `preset.yml`）
  - 来源＝官方 `standard` 的全能力行（18 行：persona / agent-instructions / pwsh + fs + search + skills /
    planning / compaction / delegation / ask-user / todo / web / present），只把 persona 换成晨汐：
    简体中文、称用户「昀晞」、自称「我」、雨雾底色 + 先出结果后解释 + 先取证 + 文档出 .docx +
    指向 `~/.dsh/persona/*`、`habits.md`、`anti-drift.md`、`session-handover.md`。
  - `preset.yml`：`name: 晨汐`、`order: 2`（排在「标准模式」后）。
  - 字段形状与内核一致（`prefix:`/`suffix:`，**不是** legacy `text:`）→ 升级内核时要重跑 `[12]` 与挂载探针。
- **已设为默认**：`~/.dsh\settings.yaml` → `agent-presets.default: chenxi`（原来 = `cordis`）。
  ⚠️ 影响：**新会话**默认用晨汐（不再默认 cordis 组合创作模式）；单个会话仍可在模式菜单即时切换；
   想恢复原状就把该值改回 `cordis`（或 `standard`）。老会话保持自己的 preset 不变。
- **验证证据（三连）**：
  1. YAML 解析：`preset.yml` name=晨汐 order=2；`agent.cordis.yml` 18 行、persona.prefix 含中文、无 legacy `text`；
  2. mount 校验：动态插件 `preset_mount_check {"id":"chenxi"}` → **MOUNT OK**；
  3. 真会话：HTTP RPC `session/create {agentPreset:"chenxi"}` → `ok:true`，返回 `session-9b9ac172…`。
- **清理**：验证会话 `session-9b9ac172…` 已用 `workspace/archiveSession` 归档（blank，0 轮对话）；
  同一调用顺带把 09-10/09-13 遗留的空测试会话一起归档了（≥6 个）。RPC 参数名用 `{"request": {...}}` 这一层即可。
- **本机 RPC 探针可复用**：`GET /?token=<启动 token>`（token 见 `logs\dsh-web-console.log`，取最后一个）
  → 用 `Set-Cookie` 里的 `dsh-auth-*` cookie → `POST /api/<ns>/<method>`，body
  `{"type":"client-request","rpcId":"x","method":"<ns>/<method>","payload":{"args":{...}}}`。
  shell 里可直接用 `fetch`（Node 24 有全局 fetch + `getSetCookie()`），比 PowerShell 的 -SessionVariable 省事。
  ⚠️ 正常业务不要用它建会话——会真的产生会话记录。

## 22) 晨汐执行标准与文档标准（2026-09-13 晚，标准文件 + 微信端统一身份）★
- **新增两份标准（随预设走，改预设不会被内核升级冲掉）**
  - `~/.dsh\.agent-presets\chenxi\standards\execution.md` —— 执行标准：请求分诊表 / 默认循环
    **Think → Act → Observe → Verify** / todo 与长任务外部记忆 / 验证与验收（构建≠可用、判定类先探针、反向自查）/
    错误恢复（同路径失败 ≤2 次换策略、卡住就上报）/ 停止与升级条件 / 红线（不改没让改的、版本号铁律、不跟随最新、不替用户做大决定、收尾清理）。
    来源＝本机 `anti-drift.md` 血泪 + 公开 agent 工程实践蒸馏（Anthropic《Building Effective Agents》2026-03 版：
    agent loop、workflow 模式、上下文工程、错误恢复、停止条件、"简单优先、复杂度必须由 eval 证明"）。
  - `~/.dsh\.agent-presets\chenxi\standards\document.md` —— 文档标准：报告结构（封面/摘要/目录/引言/理论/设计/结果/结论/参考文献/附录）、
    论文 IMRaD 各节该写什么、中文行文规范（标题层次序数 一、→（一）→1.→（1）、术语一致、数字与单位、图表题注位置）、
    **参考文献 GB/T 7714—2025**（2026-07-01 实施，替代 2015 版：新增 `[PP]` 预印本 / `[DS]` 数据集 / `[A]` 档案 / `[CM]` 地图，
    术语 DOI→永久标识符 PID，核心原则"先判文献本体类型，再补 OL 载体标识，在线资源不一律写 [EB/OL]"，
    日期统一 YYYY-MM-DD，网页/预印本必须写引用日期）、以及 **Office 交付 SOP + 交付前检查清单**。
  - **写入顺序（write-then-edit，已写进预设）**：先骨架 → 逐节填充 → 全文通读改 → 套格式导出 → **读回抽查**；不允许一口气写完不回头看。
- **预设接线**：`chenxi/agent.cordis.yml` 的 persona prefix 已指向这两份文件，并点明"按任务读对应那份，别即兴发挥"。
  验证：YAML 解析 18 行、prefix 2220 字符、无 legacy `text`、含两份标准引用；`preset_mount_check chenxi` → **MOUNT OK**。
- **微信端身份统一**：`integrations\dsh-weixin\workspaces.json` 的 `agentPresets[botId]` 由 `routing-suite` 改为 **`chenxi`**
  （备份 `workspaces.json.bak-20260913-2200`）。理由：路由指引本来就是插件按 `scope: all` 全局注入，微信端不需要靠 preset 拿路由；
  而晨汐人格只写在 chenxi 预设里 → 换过去手机端才有统一人格。
  ⚠️ **可能需要重启 `dsh web`** 让 dsh-im 重新读取该映射（未重启前新消息仍走旧 preset）；重启后发一句验证即可。
  2026-09-13 22:03 的重启已完成，映射已在磁盘上，手机端发一句即可确认。

## 23) ★重启链路事故与修复（2026-09-13，昀晞报「重启失败了」）——已端到端验证
- **现象**：22:01:27 发起重启，`logs\restart.log` 停在 `stopping pid 75176 (node)` / `stopped` 就断了，
  3080 一直到 22:03:39 才起来（那 2 分钟 GUI 打不开）。
- **真因（两层，都已修）**
  1. **自杀式重启**：`restart-dsh.ps1` 被 DSH 进程树内的调用者启动（GUI 重启按钮 → 生成式 launcher → 本脚本），
     脚本里 `Stop-Process -Force` 杀掉的正是自己的祖先进程 → **整棵树连带自己一起死**，所以日志停在 "stopped"。
  2. **静默丢弃（第二个坑）**：入口原来有一道「已经在应答 → 直接退出」的守卫，而它把**任何 HTTP 响应**都当作
     "实例活着"，且用**错误端口**的探测结果做判断 → 真实重启请求被默默丢掉。实测在测试口复现：连续三次
     "already answering ... restart not needed"，监听器纹丝不动。
- **修复（`restart-dsh.ps1` 重写 + `start-dsh.ps1` 配合）**
  1. 入口（无参数）先写 marker，再用 **`([wmiclass]'Win32_Process').Create(...)` 把自己以 `-Detached` 复活**，
     然后立刻退出 → 真正干活的进程**不在被杀的进程树里**，杀祖先杀不到它。
  2. 工作者（`-Detached`）：给旧实例 **10s 体面退出** → 仍占端口则 `Stop-Process -Force` → 等端口释放（≤25s）→
     交给 `start-dsh.ps1`（由它挑最高版本内核）。
  3. **删掉"已经在应答就退出"的守卫**（不再有静默丢弃路径）。
  4. `start-dsh.ps1` 启动时读/删 `logs\restart-in-progress.txt`：marker 在且端口没人应答 → 视为
     "上次重启被打断"，**直接补齐启动**而不是只开浏览器；marker 在但实例活着 → 清掉继续。
- **端到端验证（复现事故序列）**：`e2e-restart-test.ps1 -Port 3099` → 注入真实监听器 → 以**子进程**方式启动
  `restart-dsh.ps1` → 立刻强杀调用树 → 分离工作者完成「等待 → 杀 77468 → 端口释放 → 调 start-dsh.ps1 → finish」，
  监听器真被停掉、端口真释放；第二次请求（无监听器）也正常再次起工作者。**3080 线上实例全程未受影响**。
- **备份**：`restart-dsh.ps1.bak-20260913-2210`、`start-dsh.ps1.bak-20260913-2210`（修复前版本）。
- **可复用测试**：`e2e-restart-test.ps1` + `test-assets\dummy-http.mjs`（都是 ASCII，安全，不碰 3080）。
- **教训（已并入排障铁律）**：① "杀自己祖先的脚本"必须**先脱离进程树**再动手；
  ② **gating 逻辑里任何"看起来是成功/健康"的宽松判断，都可能把真实请求变成静默 no-op**；
  ③ 端口占用/健康判断**不要跨端口复用**。

## 24) 晨汐自我成长机制（2026-09-13，昀晞要「能力可以自我成长」）★
- **三层模型（写进预设，新会话即生效）**
  | 层 | 文件 | 谁能改 |
  |---|---|---|
  | ROOTS 根 | `growth\ROOTS.md`（身份/红线/昀晞约定） | **只有昀晞**；晨汐只能读、引用、出"改根申请单" |
  | GROWTH 成长区 | `growth\growth-protocol.md`、`growth\日志.md`、`growth\能力清单.md`、`standards\*.md` 的新增条目 | **晨汐可自助追加** |
  | COMPOSITION 骨架 | `agent.cordis.yml` / `preset.yml` / 工具集 / 模型 / 作用域 | **动之前必须先问昀晞** |
- **成长协议要点**（`growth-protocol.md`）：什么值得记（重犯的错 / 被昀晞纠正 / 踩出的事实 / 可复用流程 / 新能力）；
  写入规则（**追加优先**、改动前备份到 `growth\backup\`、每条带证据、一次一事、可回滚、30 天或 +40 条做一次合并）；
  必问事项（改根、改骨架、删除既有标准、放宽红线、扩自主范围、昀晞数据的对外行为）；
  会话结束若有成长要**在回复末尾一行汇报**「成长：+N 条（文件）」。
- **自我审计**：`~/.dsh\.agent-presets\chenxi\growth-audit.ps1`（条目数 / 今日新增 / 行数体积 / 最后修改 / ROOTS 完整性），
  已接进每日自检 **`[11b] chenxi growth`**。实测：4 个文件、3 条成长、今日 +3、无超限。
  ⚠️ 写这个脚本时又踩一次**"脚本里带中文路径 + PS 5.1 按 GBK 解析"**：`Join-Path $root '日志.md'` 解析不到文件 →
  改成**按内容识别成长日志**（找含 `- [YYYY-MM-DD]` 条目的 .md），脚本内不再出现任何中文路径字面量。
- **预设接线**：`chenxi/agent.cordis.yml` 的 persona 增加 "Self-growth" 段（四条路径 + 三层路由规则 + 可见性要求）；
  验证：YAML 解析 18 行、prefix 3438 字符、含 growth-protocol / ROOTS / 日志 / 能力清单四处引用、无 legacy `text`。
- **当前成长记录（种子 3 条，均带证据）**：重启脚本自杀+静默丢弃、GB/T 7714—2025 换代、日历自定义节点被清空。
- **能力清单**（`growth\能力清单.md`）已收录：环境运维 8 项、GitHub 2 项、人格标准 5 项、插件运行时 5 项、待验证 3 项。

## 25) 待验证清单（2026-09-13 收尾时）
- **微信端身份**：`workspaces.json` 已把 bot 预设改为 `chenxi`（22:03 已重启），**待手机端实发一条确认**人格与路由都在。
- **minecraft-dev 0.7.2**：2026-09-14 过 3 天观察期 → 可提议升级（备份 → 放行 → 安装 → 重启 → 自检）。
- **`dsh-context` 最新版变为 0.51.1（2026-09-13 发布，<3 天）**：仍处观察期，不装。
- **MITE 骨斧占位贴图**：待昀晞实机确认观感后再决定是否补材质。

## 26) 补丁路径 bug 修复 + 一条交互坑（2026-09-13 深夜，晨汐主会话补）
- 🔴 **`make-pnpm-patch.ps1` 曾生成过一版不可用补丁**：它把 pristine 与母本**铺在仓库根**（`Copy-Item … $repo\index.js`），
  于是 diff 出来是 `a/index.js` / `a/anchor.mjs` —— **少了 `lib/` 前缀**。而 pnpm 是按**包根**应用补丁的，
  `git apply` 直接报 `index.js: No such file or directory`；更糟的是脚本自带的"应用校验"用的是**同一套错约定**，
  所以**自检通过、注册补丁其实报废**（21:50:16 那版即此）。→ 教训：校验必须换个独立路径口径（引入 pristine tarball 之外的第二方口径最稳）。
  - 修法：仓库根＝包根，文件落 `lib/`（`$repoLib`）；校验步骤改成 `$chk\lib\` 并**逐个文件**比对母本哈希（不再只看 index.js）。
  - 实测（修复后 `-Verify`）：patch **25884B**、含 `diff --git a/lib/anchor.mjs`（new file）+ `a/lib/index.js`、
    「applies cleanly; applied files match the masters: **True**」、`node --check` OK。
- **还原脚本扩展**：`restore-patched-src.ps1` 现在同时重放 `lib/index.js` + `lib/anchor.mjs`（此前只管 index.js）。
- ⚠️ **交互坑（昀晞实测）**：`ask_user_question` 的**选项框在她客户端渲染不出来**（她回"看不到选项"）。
  → 以后提问一律写在**正文**里、用 1/2/3 列给她回数字即可，**别用那个控件**。
- 归档复核：21:37 我把 `archivedSessionIds` 清空（备份 `logs\backups\workspace\workspace.json.bak-20260913-213748`，
  释放清单 `logs\unarchived-20260913.txt`）；22 点后另一路又收进 17 条（含当晚新建的空会话）。
  **核心只实现 `archiveSession`、没有取消归档 API** → 想放出来只能改 `workspace.json` + 重启宿主重载。

## 27) 预设去冗杂 → 规则改由插件注入 + 成长机制三修（2026-09-13 深夜）★
- **晨汐预设瘦身 87%**：`chenxi/agent.cordis.yml` 的 persona `prefix` 由 **3438 → 451 字符**（只留身份/语气/边界 + 文件指针），
  纪律文字**不再写死在预设里**；字段仍是 `prefix`/`suffix`（无 legacy `text:`），18 行不变。
  → 三层拆开：**人格＝文本（preset，短）· 机制＝插件（代码，可测试）· 知识＝文件（standards/growth）**。
- **新增 `lib/rules.mjs`（dsh-routing-suite，本地补丁）**：把「干活规则 + 标准文件指针」做成**代码注入的独立 prompt 段**
  `personal-rules`（order 8，每轮注入，1088 字符 / 18 行），Config 新增 `rules: true`。
  与 anchor（order 9）· guidance（order 10）叠加不冲突。**实测**：重启后本会话系统提示里已出现该段。
- **补丁已重生成并校验**：`patches/dsh-routing-suite@0.1.2.patch` **30374 B**，含新文件 `lib/rules.mjs`
  （头部 `diff --git a/lib/rules.mjs` + `a/lib/index.js` + `a/lib/anchor.mjs` → 路径口径已是 §26 修好的那种）；
  `make-pnpm-patch.ps1 -Verify` 报「applies cleanly; applied files match the masters: True」+ `node --check` OK。
  母本与 node_modules SHA16 三方一致：index.js `5194639FBABB94BD` / anchor.mjs `8FFA182DD7F39248` / rules.mjs `67CFF1B94A943E7E`。
- **成长审计口径修正**：`growth-audit.ps1` 改为**内容识别**（成长日志＝含 `- [YYYY-MM-DD]` 条目的 md；能力清单＝状态行最多的表），
  中文标签用**码点构造**（脚本内保持纯 ASCII）。现在输出：`entries total: 5 / added today: +5 / capability rows: 20（已验证 20 / 待验证 0）`。
  ⚠️ 顺手又踩一次「PS 5.1 读 .ps1 按 GBK → 中文路径/过滤器失配」——**脚本里不要出现任何非 ASCII 字面量**。
- **回滚演练已做（协议第一次实战）**：备份 `growth/backup/growth-protocol.md.20260913-222944.bak` → 故意改坏 → 还原，
  结果**逐字节一致 = True**、占位内容消失。协议里的"可回滚"不再是纸面承诺。

## 28) 回合结束钩子（end-of-turn check）上线（2026-09-13 深夜）★
- **事件选择（先查后写）**：`Event.listEvents` 里有 **`agent/turn-stopping`**（mode: serial，"回合即将关闭：模型不再欠回复"）；
  它在**下一轮 system-prompt 组装之前**触发 → 天然的"每次对话结束前自动检查"挂点。
- **新增 `lib/check.mjs`（dsh-routing-suite 本地补丁）**：三个导出
  - `checkTurnEnd({dshHome, sessionId, cwd, now})`：结束时扫两件事——① 成长日志 mtime 是否比上次记录新（30 分钟内算"新闻"）→ 挂 `pending.growth`；
    ② 工作区 **浅扫一层 + 一层子目录**，发现 12h 内的 `.docx/.pptx/.xlsx/.pdf` 且不在 `seenPaths` → 挂 `pending.artifact`。
  - `buildCheckReminder({dshHome})`：把挂账渲染成**一次性**提示（读后立即清空 pending），order 7 注入。
  - `applyCheckToAssembly(assembled, reminder)`：只在该轮有挂账时插入 `turn-end-check` 段；**无挂账即完全静默、零 token**。
- **状态文件**：`~/.dsh/logs/turn-end-check.json`（`{checkedAt, seenGrowthMtimeMs, seenPaths[], pending{}, lastReminderAt}`）
  —— 落盘所以**重启不丢**（不会被"重新挂一遍"骚扰）。
- **Config 两个独立开关**：`turnCheck: true`（是否做检查）、`checkReminder: true`（是否注入提示）；想"只检查不打扰"→ 关后者。
- **功能实测（真跑，非纸面）**：模拟一次 turn-stopping → `pending = {growth, artifact:[两个文件]}` → reminder 3 行 →
  再读一次 `null（已消费）` → `applyCheckToAssembly` 后 sections = `base, turn-end-check`。
- **补丁重生成并校验**：`dsh-routing-suite@0.1.2.patch` **39204 B**，含 `lib/{anchor,check,rules}.mjs` + `lib/index.js`；
  `make-pnpm-patch.ps1 -Verify` → 「applies cleanly; applied files match the masters: True」。
  母本与 node_modules SHA16 四方一致：index.js `B11ACE4DC454C933` / anchor.mjs `8FFA182DD7F39248` / rules.mjs `67CFF1B94A943E7E` / check.mjs `14B3162A036AADA1`。
- **上线**：22:38:01 重启完成（`restart.log` 一路到 `=== restart finished ===`），3080 pid 75220，api/status 200。
- **已知的首次行为（不是 bug）**：`seenPaths` 之前只在探针里初始化过，所以上机后**第一次**检查会把工作区现存交付文件各提一次；
  消费掉即不再提（我自己的回复也已把这几个文件交过了）。
- ⚠️ **顺带又验一次"Get-Content 不可信"**：用 `Get-Content` 看状态文件里的中文路径是乱码，改
  `[System.IO.File]::ReadAllText(..., UTF8)` 复读**完全正常** → 钩子写的是 UTF-8，乱码是 PowerShell 5.1 的读法问题。


