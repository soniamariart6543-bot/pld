# 晨汐 DSH 体系 · 部署包

> 2026-09-13 打包 · 昀晞 的 DeepSeek Harness 定制体系
> 目的：换电脑 / 重装时，不用从零再讲一遍规矩 —— 把人格、记忆、行事机制、脚本一次装回去。

---

## 一、这套体系是什么

三层结构，各有归属，**别互相串**：

| 层 | 装什么 | 放哪儿 | 生效方式 |
|---|---|---|---|
| **人格层** | 她是誰、怎么说话、红线 | `persona/*.md` → 被 persona 插件注入系统提示 | 改 md 下一条消息生效 |
| **机制层** | 行事规则、今日锚点、回合结束自检 | `plugins/dsh-routing-suite`（补丁）| 改代码需重启 `dsh web` |
| **知识层** | 长期记忆、踩坑总账、标准、成长记录 | `knowledge/`、`agent-presets/chenxi/` | 按需读，不常驻提示词 |

**设计原则（重要，别破坏）**：
1. 常驻提示词只放**人格 + 索引**（当前约 10 KB）。全文一律进 `knowledge/`，靠触发词按需读。
   —— 2026-09-13 实测：persona 五件套全量注入时 41 KB，改成「人格 + 索引」后 10 KB，省 75%。
2. 流程规矩**写成代码**（插件注入），不写进人格文本。人格文本是文档，会漂移、会跟标准打架。
3. 每条规则都能追溯到一次真实事故（见 `knowledge/TOOLS-full.md`）。

## 二、目录说明

```
晨汐-DSH体系/
├─ README.md               ← 本文件：总览 + 部署 + 维护约定
├─ DEPLOY.md               ← 新电脑从零部署的详细步骤与验证清单
├─ THIRD-PARTY.md          ← 第三方插件清单（包名/版本/来源/安装命令）
├─ MANIFEST.json           ← 全部文件的 SHA256 清单
├─ deploy/
│   └─ install-chenxi.ps1  ← 一键部署脚本（复制 + 路径改写 + 打印插件命令）
├─ persona/                ← SOUL / IDENTITY / USER / MEMORY索引 / TOOLS速查（常驻注入）
├─ knowledge/              ← 记忆全文：MEMORY-full / TOOLS-full / habits / anti-drift
├─ agent-presets/chenxi/   ← 预设本体（agent.cordis.yml）+ standards/（执行·文档标准）+ growth/（成长机制）
├─ plugins/
│   ├─ dsh-routing-suite/  ← 自研机制源码（基座 + anchor/rules/check）
│   └─ patches/            ← 两个自研 pnpm 补丁
├─ profile/                ← profile 模板：package.json / cordis.patch.yml / pnpm-workspace.yaml / settings.yaml
├─ scripts/                ← 全部运维脚本（自检 / 重启 / 补丁 / GitHub 取物 …）
├─ calendar/               ← 日历（自定义节点 custom.json 不会被刷新覆盖）
└─ archive/                ← 历史交接备忘（46 KB，项目大事记，可删）
```

## 三、快速部署（新电脑）

**前置**：Node ≥ 22.19、pnpm、Windows（脚本是 PowerShell 5.1 兼容写法）。

```powershell
# 1) 先装 DSH 并跑一次（生成 ~/.dsh）
npx deepseek-harness@0.1.5-rc.1 web        # 起得来就 Ctrl+C 关掉

# 2) 解压本包，进包根执行一键部署
powershell -NoProfile -ExecutionPolicy Bypass -File deploy\install-chenxi.ps1

# 3) 按提示装第三方插件（THIRD-PARTY.md 有完整清单）
cd $env:USERPROFILE\.dsh\profiles\web
pnpm add @lynsucceed/dsh-openclaw-persona@0.1.1 dsh-routing-suite@0.1.2 dsh-context dsh-tools `
         dsh-office-tools dsh-plugin-manager dsh-vision-router dsh-web-fetch-playwright `
         dsh-whale-widget minecraft-dev @xmanrui/dsh-im
pnpm add https://codeload.github.com/didclawapp-ai/DSH-Office/tar.gz/refs/heads/main
pnpm install

# 4) 填密钥（本包不含任何密钥）
notepad $env:USERPROFILE\.dsh\.credentials.yaml     # DEEPSEEK_API_KEY / ZHIPU_API_KEY / 微信 token

# 5) 重启并验证
powershell -File $env:USERPROFILE\.dsh\restart-dsh.ps1
node $env:USERPROFILE\.dsh\check-plugin-compat.mjs
```

细则、验证清单与坑位见 `DEPLOY.md`。

## 四、维护约定（照做，别凭手感）

- **更新**：先通知 → 检视（发布天数 / 渠道 / 兼容扫描）→ 稳定 → **她同意** → 才安装。
  发布不满 3 天的版本不装；rc / beta 要她明说。
- **禁止擅自升版本号**：遗物mod 等项目的版本号只能由她指定（写死在 `knowledge/MEMORY-full.md`）。
- **改代码顺序**：改前备份 → 改后验证 → 批量替换后反向自查（曾因自引用递归把服务端 tick 崩掉）。
- **改插件源码**：只改 `patched-src\<包>\lib\`，然后跑 `make-pnpm-patch.ps1 -Verify` 重新生成补丁
  （千万**不要**直接改 `node_modules`，那会在下次 `pnpm install` 时被抹掉）。
- **升级被打了补丁的包**：补丁是按版本生成的，升 `dsh-routing-suite` 必须重做补丁；
  升 `@lynsucceed/dsh-openclaw-persona` 要确认兼容补丁是否还需要（内核改回原导出名后就不需要了）。
- **成长机制**：新教训 / 新流程 / 新能力 → 追加 `agent-presets\chenxi\growth\日志.md`（带证据），
  并在回复末行报一句；`ROOTS.md` 只有昀晞本人能改。
- **收尾清理**：调试探针、临时目录、草稿用完即删；每次清理后在回复里列出删了什么。
- **文档交付**：默认出标准 `.docx`（zagens-office），中间 `.md` 用完即删。

## 五、验证这套包是否装对了（30 秒版）

1. 新开会话问一句「今天几号，我的自检怎么样」→ 应能准确报日期 + DSH 版本 + 插件扫描结果（说明锚点在跑）。
2. 让它输出任何内容 → 第一行必须是 `Ciallo～(∠・ω< )⌒★`（说明 persona 注入成功）。
3. 问「我的遗物mod 版本号铁律是什么」→ 它应去读 `knowledge/MEMORY-full.md` 再答（说明知识层按需读通了）。
4. 跑 `node check-plugin-compat.mjs` → 应为 `mismatches: 0`。

## 六、不打包的东西（有意为之）

- `.credentials.yaml`（密钥）、`sessions/`（会话记录）、`logs/`、`attachments/`、`node_modules/`
- 项目数据（遗物mod、整合包等，在 `D:\DeepSeek` 另有备份）
- `~/.dsh/persona/.backup/` 历史备份（本机保留，别人的机器不需要）
