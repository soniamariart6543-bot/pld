﻿# growth-audit.ps1 - self-audit for the chenxi growth zone.
# Reports, from the FILES themselves (never from a hard-coded filename):
#   growth log   -> dated entries + how many were added today
#   capability list -> how many rows are already verified / still pending
#   every file   -> lines, KB, last write time
# and warns when a file passes the consolidation threshold (200 lines / 15 KB) or ROOTS is missing.
# ASCII-only source: a script opened by powershell.exe -File must not carry non-ASCII literals,
# so files are identified by CONTENT, and the Chinese labels are built from code points.
# Usage: powershell -File growth-audit.ps1 [-Quiet]
param([switch]$Quiet)
$root = 'C:\Users\Lenovo\.dsh\.agent-presets\chenxi\growth'
if (-not (Test-Path $root)) { if (-not $Quiet) { Write-Output '    growth zone missing' }; exit 0 }

$today = Get-Date -Format 'yyyy-MM-dd'

# Non-ASCII labels built from code points (keeps this source file pure ASCII):
#   'growth log'           = 20599 38271 26085 24535   (ri zhi)
#   'capability inventory' = 33021 21147 28165 21333
#   'verified'             = 24050 39564 35777
#   'pending'              = 24453 39564 35777
$L_LOG = [string]::new([char[]](0x65E5, 0x5FD7))
$L_CAP = [string]::new([char[]](0x80FD, 0x529B, 0x6E05, 0x5355))
$L_OK  = [string]::new([char[]](0x5DF2, 0x9A8C, 0x8BC1))
$L_PEND = [string]::new([char[]](0x5F85, 0x9A8C, 0x8BC1))

$logFile = $null      # the file holding dated entries
$logEntries = 0
$logToday = 0
$capFile = $null      # the file holding the capability table
$capRows = 0
$capOk = 0
$capPending = 0
$files = @()

foreach ($f in (Get-ChildItem -LiteralPath $root -File -Filter *.md | Sort-Object Name)) {
    $txt = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
    $lines = $txt -split "`r?`n"
    $entries = 0
    $todayCount = 0
    foreach ($ln in $lines) {
        if ($ln -match '^\s*-\s*\[(\d{4}-\d{2}-\d{2})\]') {
            $entries++
            if ($Matches[1] -eq $today) { $todayCount++ }
        }
    }
    if ($entries -gt 0 -and -not $logFile) { $logFile = $f; $logEntries = $entries; $logToday = $todayCount }

    # capability table rows: pipe rows whose last cell is a status (OK / PENDING).
    # Several files carry status tables (the protocol has an action table too), so the
    # inventory is the file with the MOST status rows - that is the capability list.
    $rows = 0
    $ok = 0
    $pend = 0
    if (Test-Path -LiteralPath (Join-Path $root 'ROOTS.md')) {
        foreach ($ln in $lines) {
            if ($ln -notmatch '^\s*\|') { continue }
            if ($ln -match [regex]::Escape($L_OK) -or $ln -match [regex]::Escape($L_PEND)) {
                $rows++
                if ($ln -match [regex]::Escape($L_OK)) { $ok++ } else { $pend++ }
            }
        }
    }
    if ($rows -gt $capRows) { $capFile = $f; $capRows = $rows; $capOk = $ok; $capPending = $pend }

    $files += [pscustomobject]@{
        Name = $f.Name
        Entries = $entries
        Today = $todayCount
        Lines = $lines.Count
        KB = [math]::Round($f.Length / 1024, 1)
        Mtime = $f.LastWriteTime
    }
}

if (-not $Quiet) {
    foreach ($x in $files) {
        $tag = ''
        if ($logFile -and $x.Name -eq $logFile.Name) { $tag = '  <- ' + $L_LOG }
        elseif ($capFile -and $x.Name -eq $capFile.Name) { $tag = '  <- ' + $L_CAP }
        Write-Output ('    ' + $x.Name + ': ' + $x.Entries + ' dated, +' + $x.Today + ' today, ' + $x.Lines + ' lines, ' + $x.KB + ' KB, ' + $x.Mtime.ToString('yyyy-MM-dd HH:mm') + $tag)
    }
    $logMeta = 'n/a'
    if ($logFile) { $logMeta = $logFile.Name + ' (modified ' + $logFile.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + ')' }
    Write-Output ('    growth log: ' + $logMeta)
    Write-Output ('    entries total: ' + $logEntries + '   added today: +' + $logToday)
    if ($capFile) { Write-Output ('    capability rows: ' + $capRows + '  (' + $L_OK + ' ' + $capOk + ' / ' + $L_PEND + ' ' + $capPending + ')') }
    if ($logToday -eq 0) { Write-Output '    (no new entry today - normal if nothing new was learned)' }

    $over = @()
    foreach ($x in $files) { if ($x.Lines -gt 200 -or $x.KB -gt 15) { $over += $x.Name } }
    if ($over.Count -gt 0) { Write-Output ('    CONSOLIDATE (over 200 lines / 15 KB): ' + ($over -join ', ')) }
    if ($logEntries -ge 40) { Write-Output '    >40 entries: time for a merge pass (see growth-protocol.md section 6)' }

    $roots = Get-Item -LiteralPath (Join-Path $root 'ROOTS.md') -ErrorAction SilentlyContinue
    if ($roots) {
        Write-Output ('    ROOTS.md last modified ' + $roots.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + ' (only the user may change it)')
    } else { Write-Output '    WARN: ROOTS.md missing' }
}
exit 0
