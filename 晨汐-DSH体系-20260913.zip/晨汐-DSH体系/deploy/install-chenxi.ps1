﻿# install-chenxi.ps1 -- deploy the 晨汐 DSH system onto this machine.
#
# Run this AFTER DSH itself is installed and has been started once (so that
# ~/.dsh exists). It copies persona / knowledge / preset / scripts into the
# DSH home, rewrites this pack's author-machine paths, drops the profile
# templates in place, and prints the exact commands for the third-party
# plugins (they are downloaded by pnpm/npm, they are NOT bundled).
#
# Usage (from the unpacked pack root):
#   powershell -NoProfile -ExecutionPolicy Bypass -File deploy\install-chenxi.ps1
#   powershell ... -File deploy\install-chenxi.ps1 -DshHome 'D:\dsh-home'
#   powershell ... -File deploy\install-chenxi.ps1 -DryRun
#   powershell ... -File deploy\install-chenxi.ps1 -PackUser 'SomeoneElse'
#
# NOTE: this file must stay UTF-8 *with BOM* (Windows PowerShell 5.1 reads .ps1
# as ANSI/GBK otherwise and the Chinese text below breaks the parser).

param(
    [string]$DshHome  = (Join-Path $env:USERPROFILE '.dsh'),
    [string]$PackUser = 'Lenovo',
    [string]$ToolsRoot = $env:USERPROFILE,
    [switch]$DryRun,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$packRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $DshHome ("_chenxi-backup-" + $stamp)
$profileDir = Join-Path $DshHome 'profiles\web'

function Say([string]$m) { Write-Host $m }
function Step([string]$m) { Write-Host (''); Write-Host ('== ' + $m) }

Say ('pack root : ' + $packRoot)
Say ('dsh home  : ' + $DshHome)
Say ('tools root: ' + $ToolsRoot)
Say ('dry run   : ' + [bool]$DryRun)

# 1) sanity: the DSH home must exist (created by the first `dsh web` run)
if (-not (Test-Path -LiteralPath $DshHome)) {
    Say ''
    Say 'STOP: the DSH home folder does not exist yet.'
    Say 'Install DSH first and start it once, e.g.  npx deepseek-harness web'
    Say 'then run this script again.'
    exit 1
}

# 2) back up anything we are about to touch
Step 'backing up existing files that this pack overwrites'
$targets = @('persona', 'knowledge', '.agent-presets\chenxi', 'session-handover.md', 'profiles\web\package.json', 'profiles\web\pnpm-workspace.yaml', 'profiles\web\cordis.patch.yml')
$existing = @()
foreach ($rel in $targets) {
    if (Test-Path -LiteralPath (Join-Path $DshHome $rel)) { $existing += $rel }
}
if ($existing.Count -eq 0) {
    Say '  nothing to back up (fresh install)'
} elseif ($DryRun) {
    Say ('  would back up: ' + ($existing -join ', '))
} else {
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    foreach ($rel in $existing) {
        $src = Join-Path $DshHome $rel
        $dst = Join-Path $backup $rel
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        if ((Get-Item -LiteralPath $src).PSIsContainer) {
            Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
        } else {
            Copy-Item -LiteralPath $src -Destination $dst -Force
        }
    }
    Say ('  backup written to ' + $backup)
}

# 3) copy the pack payload into the DSH home
Step 'copying persona / knowledge / preset / scripts'
$map = @(
    @{ from = 'persona';                       to = 'persona' },
    @{ from = 'knowledge';                     to = 'knowledge' },
    @{ from = 'agent-presets\chenxi';          to = '.agent-presets\chenxi' },
    @{ from = 'plugins\dsh-routing-suite';     to = 'patched-src\dsh-routing-suite' },
    @{ from = 'plugins\patches';               to = 'profiles\web\patches' },
    @{ from = 'calendar';                      to = 'calendar' },
    @{ from = 'archive\session-handover.md';   to = 'session-handover.md' }
)
foreach ($m in $map) {
    $src = Join-Path $packRoot $m.from
    $dst = Join-Path $DshHome $m.to
    Say ('  ' + $m.from + '  ->  ' + $dst)
    if ($DryRun) { continue }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    if (Test-Path -LiteralPath $src -PathType Container) {
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force
    } else {
        Copy-Item -LiteralPath $src -Destination $dst -Force
    }
}
# loose helper scripts live at the DSH home root
foreach ($s in (Get-ChildItem -LiteralPath (Join-Path $packRoot 'scripts') -File)) {
    Say ('  scripts\' + $s.Name + '  ->  ' + $DshHome)
    if (-not $DryRun) { Copy-Item -LiteralPath $s.FullName -Destination (Join-Path $DshHome $s.Name) -Force }
}
if (-not $DryRun) {
    Copy-Item -LiteralPath (Join-Path $packRoot 'scripts\preset-probe.cordis.md') -Destination (Join-Path $DshHome '.agent-presets\preset-probe.cordis.md') -Force
}

# 3b) profile templates: never clobber a live profile
Step 'profile templates'
New-Item -ItemType Directory -Force -Path $profileDir | Out-Null
$profSrc = Join-Path $packRoot 'profile'
$tplDir = Join-Path $profileDir '_chenxi-template'
if (-not $DryRun) { New-Item -ItemType Directory -Force -Path $tplDir | Out-Null }
foreach ($tpl in (Get-ChildItem -LiteralPath $profSrc -File)) {
    $live = Join-Path $profileDir $tpl.Name
    $side = Join-Path $tplDir $tpl.Name
    if (-not $DryRun) { Copy-Item -LiteralPath $tpl.FullName -Destination $side -Force }
    $hadLive = Test-Path -LiteralPath $live
    if (-not $hadLive -and -not $DryRun) {
        Copy-Item -LiteralPath $tpl.FullName -Destination $live -Force
        Say ('  ' + $tpl.Name + '  ->  profile (no existing file, installed)')
    } else {
        Say ('  ' + $tpl.Name + '  ->  profile\_chenxi-template\  (live file kept; merge by hand)')
    }
}

# 4) rewrite this pack's author-machine absolute paths
Step ('rewriting paths  C:\Users\' + $PackUser + '  ->  ' + $ToolsRoot + '   (DSH home -> ' + $DshHome + ')')
$oldDshBwd = 'C:\Users\' + $PackUser + '\.dsh'
$oldDshFwd = 'C:/Users/' + $PackUser + '/.dsh'
$oldUser   = 'C:\Users\' + $PackUser
$oldUserF  = 'C:/Users/' + $PackUser
$textExt = @('.ps1', '.mjs', '.js', '.json', '.yml', '.yaml', '.md', '.vbs', '.txt', '.cmd', '.bat')
$changed = @()
$scanned = Get-ChildItem -LiteralPath $DshHome -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $textExt -contains $_.Extension -and $_.FullName -notlike '*\node_modules\*' -and $_.FullName -notlike '*\_chenxi-backup-*\*' }
foreach ($f in $scanned) {
    $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
    if ($text.IndexOf($oldUser) -lt 0 -and $text.IndexOf($oldUserF) -lt 0) { continue }
    # order matters: the DSH home first (it is longer), then whatever is left of the user root
    $new = $text.Replace($oldDshBwd, $DshHome).Replace($oldDshFwd, ($DshHome -replace '\\', '/'))
    $new = $new.Replace($oldUser, $ToolsRoot).Replace($oldUserF, ($ToolsRoot -replace '\\', '/'))
    if ($new -eq $text) { continue }
    $changed += $f.Name
    if (-not $DryRun) {
        $enc = New-Object System.Text.UTF8Encoding($hasBom)
        [System.IO.File]::WriteAllText($f.FullName, $new, $enc)
    }
}
Say ('  files rewritten: ' + $changed.Count + '  (' + (($changed | Select-Object -First 8) -join ', ') + ')')
Say '  NOTE: toolchain paths inside those scripts (JDK / Gradle / Git under the old user root)'
Say ('        were pointed at "' + $ToolsRoot + '". If this machine keeps them elsewhere,')
Say '        edit the paths at the top of:  dsh-daily-check.ps1, start-dsh.ps1, verify-dsh-boot.ps1'

# 5) third-party plugins: print the commands, do not guess-install anything
Step 'third-party plugins (installed by pnpm, NOT bundled in this pack)'
$pluginsMd = Join-Path $packRoot 'THIRD-PARTY.md'
if (Test-Path -LiteralPath $pluginsMd) { Say ('  full list + sources: ' + $pluginsMd) }
Say '  run these in the DSH profile folder:'
Say ('    cd ' + $profileDir)
Say '    pnpm add @lynsucceed/dsh-openclaw-persona@0.1.1 @xmanrui/dsh-im dsh-context dsh-office-tools dsh-plugin-manager dsh-tools dsh-vision-router dsh-web-fetch-playwright dsh-whale-widget minecraft-dev'
Say '    pnpm add dsh-routing-suite@0.1.2'
Say '    # zagens-office comes from git:'
Say '    pnpm add https://codeload.github.com/didclawapp-ai/DSH-Office/tar.gz/refs/heads/main'
Say '  then:  pnpm install     (patches\ is already in place, pnpm applies it automatically)'

# 6) what is left to do by hand
Step 'next steps'
Say '  1. your API keys:  ~/.dsh/.credentials.yaml   (this pack contains NO secrets)'
Say '  2. restart the GUI:  powershell -File restart-dsh.ps1'
Say '  3. verify:           node check-plugin-compat.mjs'
Say '  4. first chat of the day runs dsh-daily-check.ps1 and reports the health summary'
Say ''
Say 'done.'
