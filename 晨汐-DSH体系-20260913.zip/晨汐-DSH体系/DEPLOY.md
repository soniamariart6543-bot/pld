# DEPLOY.md · 新电脑从零部署（详细版）

> 目标：一台干净的 Windows 电脑，从没装过 DSH，装完后新会话里就是「晨汐」——
> 知道称呼、知道规矩、有记忆、有自检、有成长机制。
> 本机实测环境：Windows 11 / Node 22.x / pnpm 11.x / DSH 0.1.5-rc.1 / PowerShell 5.1。

---

## 步骤 0 · 检查前置

```powershell
node -v          # 需要 >= 22.19.0
pnpm -v          # 没有就 npm i -g pnpm
$PSVersionTable.PSVersion   # 5.1 即可（本包脚本就是按 5.1 写的）
```

## 步骤 1 · 安装并首次启动 DSH

```powershell
npx deepseek-harness@0.1.5-rc.1 web
```

- 看到 `http://127.0.0.1:3080` 能打开、能发一句话，就算成功；然后关掉进程。
- 这一步会生成 `%USERPROFILE%\.dsh\`（下称 **DSH 家目录**），后面所有东西都往这里放。
- 如果启动失败：先看 `~/.dsh/logs/` 下的日志，不要盲目重装。

## 步骤 2 · 解压本包并一键部署

```powershell
Expand-Archive -LiteralPath .\晨汐-DSH体系.zip -DestinationPath . -Force
cd .\晨汐-DSH体系
powershell -NoProfile -ExecutionPolicy Bypass -File deploy\install-chenxi.ps1
```

脚本会做四件事（都可 `-DryRun` 预演）：

1. **备份**已有的 `persona/`、`knowledge/`、`.agent-presets/chenxi/` 到 `~/.dsh/_chenxi-backup-<时间戳>/`；
2. **复制** persona / knowledge / 预设 / 脚本 / 日历 / 补丁到 DSH 家目录；
3. **改写路径**：把包内写死的 `C:\Users\Lenovo\.dsh` 换成这台机器的 DSH 家目录
   （`-DshHome` 可指定别处；改写时按原文件的 BOM 状态写回，避免 `.ps1` 变乱码）；
4. **打印**第三方插件安装命令（不代你装，避免版本漂移时静默装错）。

> 两个可选参数（按需）：
> - `-DshHome 'D:\dsh-home'`：家目录不在默认位置时用（该目录必须先由 DSH 自己生成过一次）。
> - `-ToolsRoot 'D:\tools'`：包内脚本里写死的 JDK / Gradle / Git 安装位置
>   （原来是 `C:\Users\Lenovo\.dsh-java`、`.dsh-gradle`、`.dsh-git`）会被指到这个前缀，
>   默认 = 本机 `%USERPROFILE%`。装完若工具链不在那儿，改这三个脚本顶部的常量：
>   `dsh-daily-check.ps1`、`start-dsh.ps1`、`verify-dsh-boot.ps1`。
> - `-PackUser 'OldName'`：包不是从 `Lenovo` 那台机器打的时才需要。

## 步骤 3 · 装第三方插件

去 `~/.dsh/profiles/web`（profile 目录）：

```powershell
cd $env:USERPROFILE\.dsh\profiles\web

# 3.1 用本包提供的 profile 模板（已含 bundles 列表与 patchedDependencies）
copy ..\..\晨汐-DSH体系\profile\package.json       .\package.json
copy ..\..\晨汐-DSH体系\profile\pnpm-workspace.yaml .\pnpm-workspace.yaml
copy ..\..\晨汐-DSH体系\profile\cordis.patch.yml    .\cordis.patch.yml

# 3.2 装依赖（补丁文件已在 patches\ 里，pnpm install 会自动应用）
pnpm install
```

如果 `pnpm install` 报某个包版本不存在（上游删了旧版），就单独装最新版，然后：

- `dsh-routing-suite` 装了别的版本 → 我们的补丁会**应用失败**，此时要么装回 `0.1.2`，
  要么按 `README.md`「维护约定」重做补丁（`make-pnpm-patch.ps1` 会从 npm 拉 pristine 版本对比）。
- 其它插件版本新一点通常无妨。

也可以绕过模板逐个装（适合想自己挑版本的场合）：

```powershell
dsh plugin --profile web add @lynsucceed/dsh-openclaw-persona dsh-routing-suite dsh-context `
    dsh-tools dsh-office-tools dsh-plugin-manager dsh-vision-router dsh-web-fetch-playwright `
    dsh-whale-widget minecraft-dev @xmanrui/dsh-im
```
（之后要手动把 `patchedDependencies` 两行加进 `pnpm-workspace.yaml`，否则自研机制不生效。）

## 步骤 4 · 密钥与模型

本包**不含任何密钥**，必须自己填 `~/.dsh/.credentials.yaml`：

```yaml
ZHIPU_API_KEY: ...        # 识图（dsh-vision-router 走 glm-4v-flash）
DEEPSEEK_API_KEY: ...     # 主模型
DSH_WEIXIN_BOT_TOKEN_<id>: ...   # 只有用微信通道才需要
```

默认模型写在 `~/.dsh/settings.yaml`（`agent-default-model`）；默认人格预设是 `chenxi`
（`agent-presets.default: chenxi`）。想恢复出厂默认就改成 `cordis`。

## 步骤 5 · 重启并验证

```powershell
powershell -File $env:USERPROFILE\.dsh\restart-dsh.ps1
```

**四道验证（按顺序做，任何一条不过就别继续）**：

| # | 操作 | 期望 |
|---|---|---|
| 1 | 浏览器开 `http://127.0.0.1:3080`，发一句话 | 正常应答，且**第一行**是 `Ciallo～(∠・ω< )⌒★` |
| 2 | 运行 `node ~/.dsh/check-plugin-compat.mjs` | `mismatches: 0`、`unresolvable: 0` |
| 3 | 看 `~/.dsh/logs/dsh-check-latest.txt` | 有今天的自检报告（版本 / 过期插件 / 插件扫描 / 预设 lint） |
| 4 | 问它「我的遗物mod 版本号铁律是什么」 | 它会去读 `knowledge/MEMORY-full.md` 再答，而不是瞎猜 |

第 4 条是**知识层是否打通**的关键验证：答对内容且说明「读了 MEMORY-full.md」= 体系完整。

## 步骤 6 · 开机自检（可选）

把每日自检挂进登录启动（本机是用计划任务/启动项跑的）：

```powershell
# 手动跑一次看结果
powershell -File $env:USERPROFILE\.dsh\dsh-daily-check.ps1
# 不想真装东西时：只检查不更新（脚本默认就是只检查）
```

## 常见坑（都是真踩过的）

| 症状 | 原因 | 处理 |
|---|---|---|
| 脚本报 `Unexpected token` / 中文乱码 | `.ps1` 丢了 UTF-8 BOM，被 PowerShell 按 GBK 解析 | `powershell -File fix-ps1-bom.ps1`（本包自带） |
| 插件加载了但没效果 | 改了 `node_modules` 却被 `pnpm install` 覆盖 | 改 `patched-src\` 后跑 `make-pnpm-patch.ps1 -Verify` |
| 新会话人格没生效 | 人格插件没装 / preset 没选 | 确认 `@lynsucceed/dsh-openclaw-persona` 在 bundles 里；模式菜单选「晨汐」 |
| 预设点了没反应、微信每轮都失败 | 旧 preset 用了废弃字段 `text:` | 内核 0.1.5 起必须用 `prefix:` / `suffix:`（本包 preset 已是新写法） |
| `dsh web` 整个起不来 | 某个插件 import 的内核导出不存在 | `node check-plugin-compat.mjs` 找出不匹配项，先禁用该插件 |
| 补丁应用失败 | 包版本和补丁不匹配 | 装回补丁对应的版本（当前 `dsh-routing-suite@0.1.2`） |
| 重启后网页打不开 | 重启卡在中间态 | `restart-dsh.ps1` 会写 `logs\restart-in-progress.txt`；跑 `start-dsh.ps1` 把它补完 |

## 卸载 / 回滚

- 部署脚本每次都会留 `~/.dsh/_chenxi-backup-<时间戳>/`，把里面的东西拷回去即可回到部署前。
- 只想关掉自研机制（保留人格）：`settings.yaml` 里或 profile patch 里把 `dsh-routing-suite` 禁用即可。
- 只想关掉 persona 注入：把 `agent-presets.default` 改回 `cordis`。
