# 晨汐 DSH 体系 · 第三方插件清单（不含自研部分）

> 本包**只自带自研内容**（人格 / 知识库 / 预设 / 脚本 / 补丁）。下面这些插件是别人写的，
> 部署时用 pnpm / npm 从上游拉取，不要从本包里找。
> 版本是本机 2026-09-13 实测在跑的版本；更新策略见根目录 `README.md`「维护约定」。

## 一、DSH 内核（必需）

| 包 | 版本 | 说明 |
|---|---|---|
| `@deepseek-ai/dsh-base`、`@deepseek-ai/dsh-web-app` 等 `@deepseek-ai/*` | 0.1.5-rc.1 | DeepSeek Harness 官方内核与 Web 前端 |
| 安装方式 | — | `npx deepseek-harness@<版本> web`（首次运行会生成 `~/.dsh`） |

## 二、第三方插件（按用途）

| 插件 | 本机版本 | 作用 | 来源 |
|---|---|---|---|
| `@lynsucceed/dsh-openclaw-persona` | 0.1.1 | **体系基石**：把 `~/.dsh/persona/` 下 SOUL/IDENTITY/USER/MEMORY/TOOLS 五个 md 拼接注入系统提示，改 md 即改人格 | npm 包 `@lynsucceed/dsh-openclaw-persona`（作者 lynsucceed） |
| `dsh-routing-suite` | 0.1.2 | 智能路由基座；**我们在它上面打了自己的补丁**（见「自研部分」） | npm `dsh-routing-suite` · https://github.com/dragonbaba/dsh-routing-suite |
| `@xmanrui/dsh-im` | 4.18.1 | 微信 IM 通道（手机端当对话框用） | https://github.com/xmanrui/dsh-im |
| `dsh-context` | 0.47.0 | 上下文 / 会话信息增强 | https://github.com/bowenliang123/dsh-context |
| `dsh-tools` | 1.1.2 | 通用工具集 | https://github.com/LoKiGGo/dsh-tools |
| `dsh-office-tools` | 1.0.0 | Word/Excel/PPT 工具（与 zagens-office 配合） | https://github.com/kw78/dsh-office-tools |
| `dsh-zagens-office` | git main | Office 文档引擎后端（zagens-office） | https://github.com/didclawapp-ai/DSH-Office |
| `dsh-plugin-manager` | 0.1.0 | 插件管理器（Web UI） | https://github.com/hrhgit/deepseek-harness-plugin-manager |
| `dsh-vision-router` | 2.1.5 | 识图（本机走智谱 GLM-4V） | https://github.com/ysr666/dsh-vision-router |
| `dsh-web-fetch-playwright` | 0.2.7 | 用真实浏览器抓网页（绕反爬） | https://github.com/chendefine/dsh-web-fetch-playwright |
| `dsh-whale-widget` | 0.2.10 | 余额小鲸鱼挂件 | https://github.com/MeteorNOX/DeepSeek-Balance-Whale-Widget |
| `minecraft-dev` | 0.7.0 | Minecraft 开发技能（scaffold / gradle / 校验） | https://github.com/sikadi233-hub/minecraft-dev |

## 三、一键安装命令

在 DSH profile 目录（`~/.dsh/profiles/web`）里执行：

```powershell
pnpm add @lynsucceed/dsh-openclaw-persona@0.1.1
pnpm add dsh-routing-suite@0.1.2 dsh-context dsh-tools dsh-office-tools dsh-plugin-manager
pnpm add dsh-vision-router dsh-web-fetch-playwright dsh-whale-widget minecraft-dev
pnpm add @xmanrui/dsh-im
pnpm add https://codeload.github.com/didclawapp-ai/DSH-Office/tar.gz/refs/heads/main
pnpm install
```

> 注意版本漂移：上面是本机实测版本，不代表都还有旧版可装；装到更新的版本一般也能跑，
> 但 `dsh-routing-suite` 必须**保持 0.1.2**——我们的补丁文件就是按 0.1.2 生成的
> （`plugins\patches\dsh-routing-suite@0.1.2.patch`）。升级它需要重做补丁（见 README「维护约定」）。

## 四、自研部分（本包自带，见 `plugins/` 与其余目录）

- `plugins\dsh-routing-suite\`：打补丁后的完整源码（基座 + 我们的机制）
  - `lib\anchor.mjs` 每轮注入「今日锚点」（日期 / 自检摘要 / 日历 / 待更新插件）
  - `lib\rules.mjs` 每轮注入「行事规则 + 标准文件指针」
  - `lib\check.mjs` 回合结束自检（成长日志 / 待交付文件），下轮一次性提醒
  - `lib\index.js` 路由分类 + 上述三项挂载、内置状态查询接口
- `plugins\patches\dsh-routing-suite@0.1.2.patch`：可复现补丁（pnpm `patchedDependencies`）
- `plugins\patches\@lynsucceed__dsh-openclaw-persona@0.1.1.patch`：给 persona 插件打的兼容补丁
  （内核 0.1.5 起 `PERSONA_SECTION` 导出改名，不打这个补丁插件会被 dsh-safe 隔离）
- `persona\` `knowledge\` `agent-presets\` `scripts\`：全部自研
