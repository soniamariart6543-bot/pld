# MEMORY.md — 长期记忆

> 2026-09-07 由既有 AI 记忆库（memory/*.md，最早创建于 2026-08-01）整理归纳而来，尽量保留原表述。
> 重要信息已同步至 USER.md（关于用户）与 TOOLS.md（设备 / 工具备忘）。
> **新会话开场规则**：涉及本机环境/插件/延续话题时先读 `C:\Users\Lenovo\.dsh\session-handover.md`（交接备忘，2026-09-08 建）。

---

## 学业 · 湖南工程学院

- 工商管理专业本科，预计 **2027-06-30** 毕业
- 修读/修读过：公司治理、企业管理信息系统、质量管理（含 Minitab 分析）、技术经济学、机械制造基础、高等数学、中国历史地理鉴赏、SPSS 实验课；**高等数学曾重修**
- 学术视角：涉及「公司治理以股东利益为核心」
- 关注或了解：餐饮数字化、企业管理信息系统开发方法、信息系统规划方法等企业信息化主题
- 日语：正在学习，参加过 JLPT（日本语能力测试）
- 研究/问卷主题：**「AI 推荐与大学生冲动消费」**

## 健康

- 长期关注体重管理与身体健康；曾咨询体重下降、腹泻、牙龈出血、头晕、睡眠多梦和乳糖不耐受等问题
- **有哮喘病史**
- 注意：健康问题存在持续、反复咨询的模式

## 游戏 · Minecraft（Java 版）

- 偏好**原版增强（Vanilla+）轻量探索型整合包**：喜欢遗迹探索、新生物群系、战斗拓展
- **反感**冗杂任务系统及冗余模组堆砌
- 参考整合包：Better MC Fabric（BMC2），链接见 TOOLS.md
- 具体指令语法与模组开发的可复用订正约束，已沉淀在 TOOLS.md

## 使用模式 / 习惯

- 遇到学术或生活问题，倾向**直接向 AI 提问**获取即时解答，而非先自行搜索
- 会请 AI 分析聊天记录、协助撰写情感或人际关系中的表达性文字
- 健康与数码问题存在跨会话、跨 AI 反复咨询/迁移；数码硬件持续关注升级（游戏本、迷你主机、外接显示器）
- 有通过游戏「搬砖」赚零花钱（约月入 400 元级别）的意愿或实践；也关注学生线上兼职
- **微信 IM 通道（手机端）=「全能对话框」**（2026-09-08 昀晞明示）：不只遗物mod 与开发，学术、生活、健康、情感、数码等需求都会从微信发来；微信端看不到本机文件，汇报需自带完整快照（对齐颗粒度），需求原文须留存（遗物mod 需求登记见 `D:\DeepSeek\遗物mod\日志\需求池-跨端.txt`）
- **DSH 每日自检（2026-09-10 昀晞要求）**：每天首次对话（或涉及本机环境）先读 `~/.dsh/logs/dsh-check-latest.txt`（不是今天的就先跑 `C:\Users\Lenovo\.dsh\dsh-daily-check.ps1`），汇报「DSH 版本 vs 最新 / 插件过期 / 模型清单」；开机自启每天自动跑一次（只检查不更新）；更新需昀晞同意后用 `-Apply`（拉 DSH 最新）或 `-ApplyPlugins`（插件，有风险）
- **插件扫描必须汇报（2026-09-10 昀晞追加要求）**：每日自检已加入 `[4b] 插件扫描`（插件兼容体检 —— 逐个核对每个插件的 `import { … } from "@deepseek-ai/*"` 在当前内核是否真的存在 + 声明 bundle 是否可解析；这正是 2026-09-10 让 `dsh web` 整个起不来的失败类型）。
  规则：**每天首次对话时，除版本/过期/模型外，必须把插件扫描结果一并汇报给昀晞**，格式固定为——
  「插件扫描：兼容体检 X 个导出 / Y 个不匹配（列不匹配项）· 声明 bundle N 个 / 不可解析 M 个 · dsh-safe 隔离 K 条 · persona 兼容层 在/不在」；
  有异常（不匹配 / 不可解析 / 隔离>0 / 兼容层缺失）时**先报异常并给出修复动作**，再报其余；报告落点＝会话窗口（昀晞 2026-09-10 选定，不做额外推送）。
  工具：`C:\Users\Lenovo\.dsh\check-plugin-compat.mjs`（可单独跑）、`C:\Users\Lenovo\.dsh\verify-dsh-boot.ps1`（空端口 3081 全树启动验证，不动线上实例）

## DSH 本机环境 · 兼容性经验（2026-09-10 实测）

- **Agent Preset 用的是「用户根」文件，内核升级不会自动迁移**：自定义模式目录 `C:\Users\Lenovo\.dsh\.agent-presets\<id>\agent.cordis.yml` 属于用户配置，**不随 DSH 升级**。
  - 🔴 **铁律（兼容坑）**：core **0.1.5-rc.1** 起 `@deepseek-ai/dsh-persona` 的配置**改为 `prefix` / `suffix`**（可分别用 `{{model}}`、`{{cwd}}`）；旧字段 **`text:` 已废弃**。
    旧 preset 会以「`$.prefix missing required value`」**整个 preset 挂载失败** → 该模式在模式菜单里点选无效，且**任何使用该 preset 的会话（含微信 IM 会话）每轮都失败**。
    修复：把旧 `text:` 行改名成 `prefix:`，并补一行 `suffix: Your working directory is {{cwd}}.`；备份后缀 `.bak-<yyyyMMdd-HHmm>`。
  - 受影响并已修：`routing-suite`（智能路由模式）、`minecraft`（Minecraft 专家）。
  - 诊断路径（可复用）：`session/create` RPC 传 `{"args":{"request":{"agentPreset":"<id>"}}}`，返回 `agent-preset/invalid` 即挂载失败，并直接给出 YAML 行号。
- **微信 IM 报「任务未完成…错误码：INTERNAL_UNKNOWN；参考号：MF-xxxxxxxx」的读法（dsh-im 源码映射，非微信平台故障）**：
  - 该文案＝插件 `src/channels/shared/message-failure.mjs` 的兜底；`INTERNAL_UNKNOWN` 由 host 回合失败码 **`harness-turn-failed`** 映射而来（`harnessTurnError()`：`turn/end.reason.kind = error`）。
  - 👉 排查顺序：先看**该微信会话用的 agentPreset 是否还能挂载**（本次真因就是 routing-suite 挂载失败），再看模型/凭据，最后才怀疑网络。
  - 微信账号状态：`~/.dsh/integrations/dsh-weixin/accounts/<botId>/state.json`（含 `sessions` 映射、`recentOutboundMessages` 与时间戳）；配置 `config.json` / `workspaces.json`（含 workspace、agentPresets、models）。
- **HTTP 单发 RPC 探针（不动 GUI）**：`GET /?token=<启动 token>` 换签名 cookie → `POST /api/<namespace>/<method>`，body `{"type":"client-request","rpcId":"…","method":"…","payload":{"args":{…}}}`；session 命名空间是 `session`（`session/list`、`session/create`…）。启动 token 见 `~/.dsh/logs/dsh-web-console.log`。
  - 空端口第二实例可全程验证 preset/插件（`verify-dsh-boot.ps1`）；**注意 3081 实例也会把微信机器人挂上**，验证完立即停。

## 值得铭记的经验（已验证）

- 整合包与模组方案**不能只凭名称或理论兼容性**：应先确认目标游戏版本、加载器、整合包版本与中文支持；构建成功不等于可用，仍需实机启动并验证核心功能；兼容问题以用户实际报错与测试结果为准修复
- Minecraft 指令/模组交付的具体订正约束（语法格式、UI-only 改动、平行升级路线等）见 TOOLS.md
- **代码问题排查顺序（2026-09-09 昀晞）**：涉及代码的问题**先查看日志与代码**（报错/日志 → 相关源码实际行为），**之后才做推测**；不凭经验、命名或理论先下结论
- **文档交付（2026-09-09 昀晞重申）**：要产出文本文档之类的内容时**优先生成 Word(.docx)** 交付，不默认给 .md 或纯文本

### 2026-09-12 错误总账 · 最该记住的十一条（全量见 `D:\DeepSeek\遗物mod\日志\总账-本会话错误与修复-20260912.txt`）
1. **Mixin 挂父类方法可能永远不触发**：MITE `ServerPlayer.onDeath` 覆写后**不调 super**（自己调 dropAllItems），挂 `EntityPlayer.onDeath` 日志显示"混入成功"却零效果 → 必须 javap 确认子类是否覆写且不调 super
2. **MITE「不可损坏」不能用 `setMaxDamage(0)`**：`isDamageable()` = `instanceof IDamageableItem`，setMaxDamage ≤0 直接报错返回 → 用大正数
3. **凭空塞进 MITE 的物品必须补 `setLowestCraftingDifficultyToProduce`**，否则 CraftingManager 启动报 ERROR
4. **死亡流程是一段代码不是一个瞬间**：摘除/发还之间要有冷却，否则同帧被掉落逻辑再丢一次
5. **1.6.x：贴图在 jar 内，语言/音效在 `assets\virtual\legacy`**（原包 assets **没有 objects 目录**）；1.6.4 **没有 resourcePacks 选项**，补贴图只能注入 jar
6. **1.6.4-MITE-HDS 的 45MB 包是服务端包**（无 client Main），dev 客户端 jar 才 5.94MB；fml-loom 需手动放 `1.6.4-MITE.jar` 到 loom 缓存
7. **FML 按工作目录扫描 `mods/`**（不是 --gameDir）；硬依赖无候选会直接**禁用** mod
8. **给别人/PCL 用的 zip，条目名必须正斜杠**：.NET `CreateFromDirectory` 在 Windows 写反斜杠 → PCL 报「文件结构不匹配」（TOOLS.md 早有此条，仍再犯一次）
9. **jlink 精简 JRE 必须带 `java.compiler`**，否则 MixinExtras 初始化 `NoClassDefFoundError: javax/annotation/processing/Messager`；`jdk.scripting.nashorn` 在 Temurin 17 已移除
10. **本机日志是 GBK**（JVM 按平台默认写），按 UTF-8 读会得到假阴性；脚本 .ps1 反过来必须存 **UTF-8 + BOM**（否则 PowerShell 按 GBK 解析中文脚本直接语法错）
11. **MITE 缺自带资源包 ≠ 崩溃，而是"静默拒绝"**：只在 `<gameDir>\resourcepacks\` 找固定名 `MITE Resource Pack 1.6.4.zip`（或同名文件夹），缺了就 `GuiMainMenu` **把单人游戏按钮置灰**+主菜单红字（2026-09-12 昀晞截图实测"打不开"）。修复＝从真 MITE jar 抽 `sound/**`+`records/**` 合成该包（脚本 `遗物mod\MITE\build-mite-respack.ps1`）→ 日志变为 `Reloading ResourceManager: Default, MITE Resource Pack 1.6.4.zip` 且 SoundsMITE 零缺件

## 初识 / 迁移记录

- 2026-08-01：既有记忆库最早条目建立
- 2026-09-07：整理并入本 Persona（USER.md / SOUL.md / TOOLS.md 同步更新）
- 2026-09-07（同日续）：人格蒸馏至「雨雾与星光」版（缪尔赛思语气词/意象 + 活泼×底色分层，见 IDENTITY.md / SOUL.md；已考据：其原型意象是水/雨/露/雾/泡影，「孤星」是她 2023-05-01 随《孤星》活动实装、象征孤独底色的意境词，非台词原句）；确立「文档默认 .docx 标准输出、.md 用毕即删」约定；安装 dsh-office-tools 与 minecraft-dev（重启 web profile 后生效）

---

## 【遗物mod / Bonefire Relics 项目档案】★触发词：用户说「遗物mod」即自动调出
- **单人团队**（仅昀晞本人）；Minecraft 1.20.1 Fabric 遗物成长模组，游戏实例为本机整合包 `D:\DeepSeek\整合包`（Prominence II CN 3.9.2，mods 内运行 BonefireRelics + DummyMod 假人）。
- **新会话自动召回动作**：读取 `D:\DeepSeek\遗物mod\README.md`（总览与最新状态）→ `发布流程-约定.txt` → `日志\` 最新文档（差异清单/构建报告/移植进度/改动记录）。工作区顶层仅 `整合包` 与 `遗物mod` 两目录，保持整洁。
- ⏰ **开场锚定规则（2026-09-09 昀晞）**：每次遗物mod/本机环境/跨端对话开工前——
  ① `pwsh Get-Date` 核对**真实日期**（勿凭记忆推断，曾跨日未察）；② 读 README +
  日志最新改动记录，输出「日期 + 项目进度快照」（当前版本/SHA/待实机项）再进入工作。
- **源码资产**：`源码\7.0.0`（yarn 命名可构建基线，fabric+forge）；`源码\7.1.1`（intermediary 逆编译参考源码——⚠️发行 jar 的 class_XXXX 是 Fabric **intermediary** 命名，非 Mojang 混淆；MANIFEST 自标 Fabric-Mapping-Namespace: intermediary，loader 运行时重映射）；`源码\归档`（6.3.3/6.3.6/6.3.8 历史开源）；`工程\bonefire-relics-fabric`（主开发工程，自 7.0.0 搭建，**进行中目标：按差异清单 P2-P6 升级为 7.1.1 命名源码**）。
- 2026-09-07 成果：①「骨甲装备中升级」修复完成并已发布测试；② **7.1.1 intermediary javac 直编译链路验证成功**（零 loom/remap，产物 `版本\BonefireRelics-7.1.1-改.jar`，171 条目≈原版 170，报告 `日志\构建报告-7.1.1-obf.txt`）；③ 发布规则与备份习惯（替换前留 *.原版备份 / *.dev备份）；④ 差异盘点完成（7.1.1=34 共有类+11 新增：秘法核心系统 ArcaneCore*5、mixin×4、spell_engine 联动×2；资源+13）。
- 环境：JDK17 `C:\Users\Lenovo\.dsh-java\jdk-17.0.20.1+1`、Gradle8.8 `C:\Users\Lenovo\.dsh-gradle\gradle-8.8`、Git2.47 `C:\Users\Lenovo\.dsh-git`（均入用户 PATH/JAVA_HOME/GRADLE_HOME）。
- ⚠️ **版本号铁律（2026-09-08 昀晞）**：发布/迭代**不得擅自升版本号**；沿用当前版本构建（覆盖前备份），升版仅由昀晞明示。
- **MITE 精简版支线（2026-09-12）**：1.6.4 + FishModLoader 上的「只有物品 + 开局发放 + 死亡不掉落」遗物 mod（无升级系统）
  - 工程 `遗物mod\MITE\relic-mite`（fml-loom）；产物 `relic-mite-0.1.0.jar`（SHA16 0237BB1F607BA100）
  - 物品：无尽铁镐/骨斧/骨甲四件套；命令 `/relic status|test|give`；开局自动发 6 件，死亡不掉落（穿身上的骨甲同理）
  - 工作实例 `整合包\versions\1.6.4-MITE-FML\`；**独立整包 `D:\DeepSeek\遗物打破\`**（自带 jre17、PCL启动器、`开始游戏.bat`）
    + 分发 zip `D:\DeepSeek\遗物打破-独立整合包.zip`（233MB，条目正斜杠规范版；桌面也有一份）
  - 素材源：曾用某第三方 MITE 整合包内的 R196 客户端（贴图/音效来源）——**2026-09-12 按昀晞要求已全部清理**（源 zip、提取 jar、派生资源包、语言音效、注入贴图均已删）
  - **待昀晞实机验证**：开局发放 / 死亡不掉落 / 观感（骨斧仍为占位贴图）
  - 全部错误与修复见 `日志\总账-本会话错误与修复-20260912.txt`；坑位铁律见 TOOLS.md「MITE 开发备忘」

_此篇将随岁月渐长，时时增补。_

## 🔴 排障铁律（昀晞 2026-09-13 定：先日志、再探针）
- **遇到任何"没生效 / 没反应"的问题，第一步必须是查日志，不许先猜、不许盲改代码。**
  取证顺序：`logs\latest.log`（含 `latest.log` 首行确认**本次启动时间**）→ `crash-reports\*` → 探针输出文件。
  同时核对：**实例 jar 的 sha16 + 写入时间** vs **会话启动时间**（证明"跑的到底是不是新版本"）。
  典型误判：改了代码却没部署 / 部署了但客户端没重启 / 玩家身上根本没有该物品。
- **判定类问题一律先装探针**：把关键判定结果与状态（槽位键名、物品 id、开关值）打成一行日志，
  只在内容变化时输出（避免刷屏）。探针是临时的，问题定位后**立即移除**（见收尾清理铁律）。
- 已固化的探针样例：`VoidHeartHandler` 的 `[VOIDHEART-DIAG]`（ownsHeart / isWorn / 饰品栏全部槽位键值与物品 id）、
  `RelicProbe` 的 `[PROBE]`/`[INIT]`/`[DIFF]`（遗物审计）、`FusionCinematic` 的 `[FUSION]`、章节的 `[BONEFIRE]`。
- **批量替换代码必须查上下文**：曾把 `isHeartStack()` 内部那行也替换成自调用 → 无限递归 → `StackOverflowError` 崩服务端 tick
  （2026-09-13 事故）。批量改完必须做反向自查（本例：javap 反汇编确认 0 自调用）。
- **同一实例的 jar 不要同时挂两个部署任务**（曾并发写同一文件 → 任务报"校验失败"、桌面包被打脏）。
  部署前先确认没有在跑的其他部署任务，且**游戏进程确已退出**。