# TOOLS.md — 工具 / 环境备忘

> Skills 定义工具「怎么用」；本文件记录用户环境特有的细节与可复用技术约束。

## 设备

- **当前电脑：** Lenovo 拯救者 Y7000P 2021（RTX 3050 Ti 版本）
- **键盘：** 狼蛛 F2088 Pro 机械键盘
- 关注/可能升级：迷你主机、外接显示器（数码建议要性价比与具体参数对比）

## Office / 文档输出（Word / PPT / Excel / PDF）

- 引擎：**zagens-office**（缺失时自动下载到 `~/.zagens-pro/bin`）；工具：office_schema / office_write / office_edit / office_read
- **交付约定：默认产出标准 .docx 等 Office 文档**，方便用户查看；中间 .md / 草稿用毕即删
- **更新日志铁律（昀晞 2026-09-09）**：遗物mod 更新日志**单独文件夹** `D:\DeepSeek\遗物mod\更新日志\`，一律**标准 Word(.docx)** 交付（不写 .txt/.md）；发布时同步产出 docx 更新日志。
- **docx 交付防坑 SOP（昀晞 2026-09-09 定稿，实测校准）**：
  1. **主路线**：`office_write` 产出（整个文档 JSON 放 `input`：`title` + `blocks[]`；block 的 type/字段一律按 `office_schema` write-docx 契约拼写，不自创键名）
  2. **写后必验**：`office_read`（docx `text`/`outline`）抽查正文——**只剩标题无正文 = 静默丢弃，立即转兜底，不交付**
  3. **先看 warnings[]**：契约对未知 block 是 skip + warnings，**不会 ok=false**；交付前必须确认无 unknown/unsupported 警告
  4. **路径边界**：`word_create`/`word_update` 与 office_* 只认 **session workspace 内**路径（web 会话工作区现为 `D:\DeepSeek`）；微信/其它会话工作区不同，勿假设可跨区写
  5. **兜底（落 workspace 外或引擎抽风）**：`write` 落 `word/document.xml` + `[Content_Types].xml` + `_rels/.rels` → pwsh `System.IO.Compression.ZipArchive` 打包 .docx，**条目名一律 `/` 正斜杠**（zip 规范），产物仍标准合规
  6. 实测记录：2026-09-09 zagens-office v0.12.0 于 `D:\DeepSeek` 写 docx（title+中文 paragraphs）blocks 正常、warnings 空——日常交付先走主路线，失败再兜底

## 统计分析 / 数据处理

- **SPSS**：完成 SPSS 实验课与实验报告等统计分析作业
- **Minitab**：质量管理分析（含课程中的 Minitab 分析）
- **Python**：具备或有数据处理需求

## Minecraft（Java 版）备忘

- 参考整合包：Better MC Fabric（BMC2）
  https://www.curseforge.com/minecraft/modpacks/better-mc-fabric-bmc2
- 目标版本/加载器/中文支持需先核实，并以实机启动结果为准

### 指令语法 · 可复用订正约束

- 新版组件语法指令：优先用用户已确认可运行的格式校验括号层级与组件结构
- 可重复消耗品：use_remainder 返回的物品也需递归保留相同组件；有限层嵌套只支持有限次数，真正无限循环应采用数据包或函数实现
- attribute_modifiers 直接接修饰器列表；属性使用 minecraft:attack_damage，数值不加引号，修饰器 id 使用带命名空间的格式
- Minecraft Java 1.20.1 旧 NBT 数据包攻击属性：优先采用用户验证可运行的 AttributeModifiers 结构（AttributeName:"generic.attack_damage"、Name:"generic.attack_damage"、Operation:0、指定 UUID 数组、Slot:"mainhand"）；不要自行替换 Name 或 UUID 写法

### 模组开发 · 可复用订正约束

- 图标与建模贴近原版像素风，避免 AI 插画感；可借鉴原版拓展模组的可读性和材质成长逻辑，但应作原创修改
- 交付不能止于源码或静态检查：产物完成后再次进行资源验证、优化、代码复核，以及图标和建模审查
- 删除自制贴图 = 删除全部自制贴图、图标和阶段模型覆盖；优先复用目标版本的原版资源
- 用户明确说明调整的是 UI 时，仅修改界面呈现与交互，不擅自改变既有服务端升级路线、材料、经验、前置条件或安全校验
- 多属性升级系统采用**平行独立路线**：每项属性只依赖自身上一等级，不受其他属性等级限制；材料与经验足够时可自由选择当前属性升级
- 沉淀长期开发过程：提炼已验证的关键路线与流程，删除历史废案和无关扩展

## 其他

- TTS：暂无已配置的声线偏好（需要时补充）
- 兼职/零花钱：游戏「搬砖」约月入 400 元级别；关注学生线上兼职

---

## 源码存档铁律（昀晞 2026-09-09）
- 凡 bonefire-relics-fabric 每次 gradlew build/发布前：先快照 src\main\java（+resources）到
  工程\.src-archive\src-<yyyyMMdd-HHmmss>-<说明>\，避免事故无法回滚。

## 实机验证默认动作（昀晞 2026-09-09）
- 凡遗物mod/整合包实机功能问题：先自动读双实例 logs\latest.log（Prominence II Hasturian Era (Chi / 1.20.1-Fabric 0.19.5），抓 bonefire/Exception/mixin 关键词，再答复。

## 收尾清理铁律（昀晞 2026-09-10）
- **完成工作后必须清理现场**，不把垃圾留给用户：
  1. **调试探针**：排查用的日志打印/临时 mixin 在问题解决后立即移除（保持生产日志干净）
  2. **临时目录/缓存**：反编译/解包用的 `_*_tmp`、javap 转储、解压缓存等一律删除
  3. **快照**：`工程\.src-archive\` 只保留最近 10 个左右；被后续版本取代的中间快照（尤其"改错了又撤回"的）删除
  4. **实例旧备份**：整合包 mods 里散落的 `.prev*` / `.pre*前` 备份统一归档到 `遗物mod\版本\备份\<实例名>\`，不在 mods 里堆着
  5. 清理后在回复里**列出删了什么/归档了什么**，让昀晞心里有数

## 部署安全规则（昀晞 2026-09-10 事故后新增）
- 往实例 `mods\` 替换 jar 前，**必须确认真 MC 进程已退出**：仅按进程名 java/javaw 会误判（Gradle 守护进程也是 java），要看命令行特征（fabric-loader / -Djava.class.path / PCL / 实例路径）或游戏窗口；实例 `session.lock` 时间可辅助判断。
- 原因：游戏运行中/刚替换就启动，会读到 jar 条目为 null 的竞态 → 表现为 `Not a JSON object: null`、`ZipException invalid LOC header`，严重时**打不开存档**（2026-09-09、2026-09-10 两次事故同源）。

## 遗物mod（Bonefire Relics）工程备忘
- 目录：`D:\DeepSeek\遗物mod`（版本/源码/工程/日志/更新日志/DummyMod + README.md + 发布流程-约定.txt）；`更新日志\` = 发布用更新日志（.docx，2026-09-09 起单独存放）
- 构建：`工程\bonefire-relics-fabric` 内 `gradlew.bat build`（JAVA_HOME=Temurin17；依赖守卫式指向整合包 spell jar）
- 发布顺序：构建 → 发布到 `版本\` → 替换整合包 mods 同名 jar（先备份 `*.原版备份`/`*.dev备份`）→ 重启 MC 实测，实机结果为准
- 命名空间铁律：发行 jar 与 `源码\7.1.1` = Fabric **intermediary**（class_XXXX/method_XXXX 即其表现），**不是** Mojang 混淆；dev 工程 = yarn 命名；转写中间命名→yarn 时以 7.0.0 源码为 API 命名词典
- 历史坑：Windows PowerShell 中文/UTF-8（写 Groovy/JSON 需无 BOM、读文件用 UTF-8 显式）；本地依赖路径勿自创括号（以 build.gradle 原字符串为准）

_随相处增补：常用目录 / 工作区位置 / 项目约定 / 偏好设置等。_

---

## 工具链踩坑总账（2026-09-12 实测，全部真发生过）
- **写 .ps1 脚本文件必须 UTF-8 + BOM**：本机 PowerShell 读 .ps1 按平台默认（GBK），无 BOM 的中文脚本会整段语法报错
  （典型：`Unexpected token '...'`、`Missing argument in parameter list`、`字符串缺少终止符`）。**edit 工具写回后会丢 BOM，改完脚本要重新补**。
- 反过来，**写 .java / .json / .groovy 必须无 BOM**：`Set-Content -Encoding UTF8` 会带 BOM → javac 报 `非法字符: '\ufeff'`；
  统一用 `[System.IO.File]::WriteAllText($p,$t,(New-Object System.Text.UTF8Encoding($false)))`。
- **游戏日志是 GBK 编码**（JVM 按平台默认写 stdout）：按 UTF-8 读会得到"中文全丢"的假阴性。
  读日志用「先 UTF-8 试，出现 U+FFFD 再按 GBK(936) 读」的助手函数；自己起的进程可加 `-Dfile.encoding=UTF-8` 一劳永逸。
- **ZIP 条目名一律正斜杠**：.NET `ZipFile.CreateFromDirectory` 在 Windows 写 `\`，违反 ZIP 规范 →
  PCL 等严格解析器报「文件结构不匹配」（2026-09-09 记过一次，2026-09-12 打整合包又踩一次）。手写 `CreateEntry` + `.Replace('\','/')`。
- **`New-Object` 类型带参用 `-ArgumentList` 写法**（位置参数形式曾返回 null：`$zip` 为 null → 后续全崩）。
- PowerShell 细节：`$args` 是自动变量（别当自己的参数数组名，改 `$jvmArgs`）；`"$log.err"` 会被当属性访问（写 `"${log}.err"`）；
  含 `[ ]` 的路径必须 `-LiteralPath`；`Remove-Item` 逗号分隔多路径会解析报错（逐个删）。
- **jlink 精简 JRE 的模块表**：必须含 `java.compiler`（否则 MixinExtras 初始化
  `NoClassDefFoundError: javax/annotation/processing/Messager`）；Temurin 17 已**移除** `jdk.scripting.nashorn`（写进模块表直接 not found）；
  可用集合：`java.base,java.compiler,java.desktop,java.logging,java.management,java.naming,java.scripting,java.sql,java.xml,java.instrument,jdk.unsupported,jdk.zipfs,jdk.charsets,jdk.crypto.ec,jdk.localedata`（≈91MB）。
- Gradle 控制台中文乱码：`JAVA_TOOL_OPTIONS=-Dfile.encoding=UTF-8` + `[Console]::OutputEncoding=[Text.Encoding]::UTF8`，输出落文件再用 read/grep 看。
- JSON 一律 `[System.IO.File]::ReadAllText(path)` 起手（`ConvertFrom-Json` 接脏编码管道会把文件写坏过）。
- GitHub：直连 API/资产 CDN 常被拦，`https://ghfast.top/https://github.com/...` 镜像拉 release 资产可用。

## MITE（Minecraft 1.6.4 + FishModLoader）开发备忘（2026-09-12 建成）
- **工程**：`D:\DeepSeek\遗物mod\MITE\relic-mite`（fml-loom 0.1 / Gradle 8.5 / Java 17 / MCP 名映射）
  可复用脚本：`smoke-test.ps1`（CLI 冒烟：加载→混入→注册）、`build-pack.ps1`（建独立包）、`verify-pack.ps1`（sha1+独立启动校验）、`zip-pack.ps1`（规范 zip）
- **实例/整包**：工作实例 `整合包\versions\1.6.4-MITE-FML\`；独立包 `D:\DeepSeek\遗物打破\`（+桌面 zip）
- **坑位铁律**：
  1. FML **按 CWD 扫描 `mods/`**（不是 --gameDir）→ jar 同时放版本目录与游戏根
  2. `ServerPlayer.onDeath(DamageSource)` **不调用 super**（自己在方法体里 `dropAllItems()`）→ 死亡相关注入必须挂 ServerPlayer
  3. `Item.setMaxDamage(0)` 会被拒（`isDamageable()` = `instanceof IDamageableItem`）→「无尽」用大正数
  4. 无合成表物品必须 `setLowestCraftingDifficultyToProduce(float)`，否则 CraftingManager 启动报 ERROR
  5. 1.6.x：**贴图在 jar 里，语言/音效在 `assets\virtual\legacy`**；无 `resourcePacks` 选项 → 补资源只能注入 jar
  6. HDS 45MB 包 = **服务端包**；客户端用 maven-releases 的 dev jar（5.94MB，含 `client/main/Main.class`）；fml-loom 需手动放 `1.6.4-MITE.jar` 到 `~\.gradle\caches\fml-loom\1.6.4-MITE\`
  7. 软依赖别写成硬依赖（`HARD_DEP_NO_CANDIDATE` 会直接**禁用** mod）
  8. MITE API 与别处不同名：`ICommandSender.sendChatToPlayer(ChatMessageComponent.createFromText(...))`（无 addChatMessage）
  9. **MITE 只认固定名的资源包**：`atv` 构造器在 `<gameDir>\resourcepacks\` 找
     `MITE Resource Pack 1.6.4.zip`（或同名文件夹）→ 赋 `atv.MITE_resource_pack`；
     找不到就 `GuiMainMenu` **禁用单人游戏按钮** + 主菜单红字（不崩溃，静默拒绝＝"打不开"），
     `SoundsMITE.load()` 也会报 needs to be loaded；缺这个包音效全无。
     → 合成脚本 `遗物mod\MITE\build-mite-respack.ps1`（真 MITE jar 的 `sound/**`+`records/**`+pack.mcmeta，12.65MB）
     → 第三方 MITE 整合包的 `resourcepacks/` 通常也是空的，**这是通病**，接手时先查它
  10. **`<gameDir>` 会因 PCL「版本隔离」而变化**：隔离开 → gameDir = `versions\<ver>\`（日志落在
     `versions\<ver>\logs\latest.log`、存档落在 `versions\<ver>\MITE\saves\1.6.4\`）；隔离关 → `.minecraft\`。
     凡按 gameDir 定位的资源（MITE 资源包、saves、MITE/reference）**两处都放**最稳；
     判断真实 gameDir 的最快办法＝看最新日志/新生成文件落在哪，别按"标准 .minecraft"推断。
- **逆向定位法（本会话救场多次）**：`~\.gradle\caches\fml-loom\1.6.4-MITE\...\mappings.tiny`（official↔named）+ `javap -p -c` 看真实字节码，
  比凭经验/命名推断可靠得多（例：确认"子类是否调 super"、`setMaxDamage` 的 `ifgt` 分支、`isDamageable` 的 instanceof）

### 重复 mod id 的实测行为（2026-09-12，Elysium Days）
- Elysium 里同时存在 `fabric-api-0.92.12+1.20.1.jar` 与 `fabric-api-0.92.2+1.20.1.jar`（同 id），
  **不能想当然认为"loader 会用高版本"**：读 `logs\latest.log` 的 mod 列表（本次在第 156 行）实测绑定的是
  `- fabric-api 0.92.2+1.20.1` —— 也就是**较旧的那个**，新 jar 完全没被加载。
- 结论：清理重复 id 前**必须先在日志里确认哪个版本真正在跑**，再决定删谁（本次按昀晞决定删掉未被加载的 0.92.12，
  归档到 `遗物mod\版本\备份\<实例名>\`，运行状态与之前完全一致）。
- 顺带：Modrinth 上 slug `player-animator` 返回 **404**（KosmX 该库只在 CurseForge/GitHub）；
  按名字兜底搜索会命中的 `mob-player-animator`（id=`mobplayeranimator`，自己 depends player-animator>=1）
  是**另一个附加模组**，不是它的升级版——查最新版时别被同名带偏。
## 🔴 排障铁律（昀晞 2026-09-13 定：先日志、再探针）
- **遇到任何"没生效 / 没反应"的问题，第一步必须是查日志，不许先猜、不许盲改代码。**
  取证顺序：`logs\latest.log`（含 `latest.log` 首行确认**本次启动时间**）→ `crash-reports\*` → 探针输出文件。
  同时核对：**实例 jar 的 sha16 + 写入时间** vs **会话启动时间**（证明"跑的到底是不是新版本"）。
  典型误判：改了代码却没部署 / 部署了但客户端没重启 / 玩家身上根本没有该物品。
- **判定类问题一律先装探针**：把关键判定结果与状态（槽位键名、物品 id、开关值）打成一行日志，
  只在内容变化时输出（避免刷屏）。探针是临时的，问题定位后**立即移除**（见收尾清理铁律）。
- 已固化的探针样例：`VoidHeartHandler` 的 `[VOIDHEART-DIAG]`（ownsHeart / isWorn / 饰品栏全部槽位键值与物品 id）、
  `RelicProbe` 的 `[PROBE]`/`[INIT]`/`[DIFF]`（遗物审计）、`FusionCinematic` 的 `[FUSION]`、章节的 `[BONEFIRE]`。
- **批量替换代码必须查上下文**：曾把 `isHeartStack()` 内部那行也替换成自调用 → 无限递归 → `StackOverflowError` 崩服务端 tick
  （2026-09-13 事故）。批量改完必须做反向自查（本例：javap 反汇编确认 0 自调用）。
- **同一实例的 jar 不要同时挂两个部署任务**（曾并发写同一文件 → 任务报"校验失败"、桌面包被打脏）。
  部署前先确认没有在跑的其他部署任务，且**游戏进程确已退出**。
- **本机 pwsh 工具跑的是 Windows PowerShell 5.1**（实测 5.1.22621）：`Get-Content` 读 **UTF-8 无 BOM** 文件会按 GBK 解码 → 中文整段乱码。
  判定「中文有没有写坏」一律用 `[System.IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)` 或 `New-Object Text.UTF8Encoding($false,$true)` 严格解码后再下结论；`Select-String` 与 `read` 工具可靠，**`Get-Content` 不可靠**（2026-09-13 读 growth\日志.md 时差点误判为文件损坏）。
