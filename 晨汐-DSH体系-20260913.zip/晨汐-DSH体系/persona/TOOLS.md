# TOOLS.md — 工具 / 环境备忘（速查）

> **全文一字未删**，已移到 `~/.dsh/knowledge/TOOLS-full.md`（16 KB：指令语法约束、MITE 备忘、工具链踩坑总账、遗物mod 工程约定）。
> 常驻只留最常踩的几条；要细节就打开全文，别凭印象。

## 常驻速查

- **机器：** Lenovo 拯救者 Y7000P 2021（RTX 3050 Ti）；键盘 狼蛛 F2088 Pro；关注迷你主机 / 外接显示器
- **Office 交付：** 引擎 zagens-office，工具 office_schema → office_write / office_edit / office_read；交付默认标准 `.docx`
- **统计：** SPSS（实验课 / 实验报告）、Minitab（质量管理）、Python
- **工具链铁律（踩了就疼）：**
  - `.ps1` 必须 **UTF-8 + BOM**；`.java` / `.json` / `.groovy` 必须**无 BOM**
  - 游戏日志是 **GBK**（按 UTF-8 读＝假阴性）；本机 pwsh 是 **5.1**，`Get-Content` 读 UTF-8 无 BOM 会乱码 → 用 `[System.IO.File]::ReadAllText($p,[Text.Encoding]::UTF8)`
  - ZIP 条目名一律 **正斜杠**；含 `[ ]` 的路径用 `-LiteralPath`
  - `New-Object` 带参用 `-ArgumentList`；`$args` 是自动变量别当自己的参数名
- **遗物mod 工程：** `D:\DeepSeek\遗物mod`（版本 / 源码 / 工程 / 日志 / 更新日志 / DummyMod）；构建 `工程\bonefire-relics-fabric` 内 `gradlew.bat build`（Temurin 17）
- **收尾清理铁律：** 删探针 / 临时目录 / 草稿，并在回复里列出清理清单
- **更新铁律：** 先通知 → 检视 → 稳定 → 同意 → 才安装；< 3 天观察期不装，rc / beta 需她明示
- **GitHub 取物：** `api.github.com` 拿事实 → `ghrelease.ps1` / `ghfetch.ps1` 拿文件；不许猜 URL 裸抓

## 什么时候去读 TOOLS-full.md

- Minecraft 指令语法 / 模组开发订正约束 → §Minecraft
- MITE（1.6.4 + FishModLoader：CWD 扫 mods / ServerPlayer.onDeath / 资源包静默拒绝 / 版本隔离）→ §MITE 开发备忘
- jlink 精简 JRE、Gradle 中文乱码、JSON 读取、GitHub 镜像 → §工具链踩坑总账
- 部署安全、源码存档、实机验证默认动作 → 文末各节铁律
