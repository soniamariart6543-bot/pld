﻿# 昀晞的日历（自动生成）

> 数据源: timor.tech 中国法定节假日 · 生成时间 2026-09-13 22:27 · 每日自检自动刷新

## 今天
- 2026-09-13 Sunday
- 距离下一个休息日（中秋节 09-25）还有 12 天

## 未来 60 天：放假
- 09-25 Friday  中秋节
- 09-26 Saturday  中秋节
- 09-27 Sunday  中秋节
- 10-01 Thursday  国庆节
- 10-02 Friday  国庆节
- 10-03 Saturday  国庆节
- 10-04 Sunday  国庆节
- 10-05 Monday  国庆节
- 10-06 Tuesday  国庆节
- 10-07 Wednesday  国庆节

## 未来 60 天：补班
- 09-20 Sunday  中秋节前补班
- 10-10 Saturday  国庆节后补班

## 2026 年剩余全部放假
- 09-25 Friday  中秋节
- 09-26 Saturday  中秋节
- 09-27 Sunday  中秋节
- 10-01 Thursday  国庆节
- 10-02 Friday  国庆节
- 10-03 Saturday  国庆节
- 10-04 Sunday  国庆节
- 10-05 Monday  国庆节
- 10-06 Tuesday  国庆节
- 10-07 Wednesday  国庆节

## 自定义节点（学期/考试/项目里程碑）
> 由 calendar\custom.json 或本区块手工内容自动保留；格式 "- YYYY-MM-DD 标题 - 备注"
- 2026-09-20 Sunday  中秋节前补班（上课） - 记得带实验报告
- 2026-11-01 Sunday  Sunday  Sunday  Sunday  Sunday  Sunday  Sunday  手改测试节点 - 从 md 导入
- 2026-12-20 Sunday  期末考试周（预估） - 日期以教务处为准
- 2027-06-30 Wednesday  预计毕业
