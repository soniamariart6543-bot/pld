/* 雾读 · 功能实装批次 D：P1-10 无障碍语义（aria / role）
   思路：与其手改 65 个按钮（改漏一处就白搭），不如在启动时统一“补语义”，
   并对动态生成的节点（答题选项、词表行、弹层）挂 MutationObserver 持续补齐。
   用法：node tools/feat-d-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

P('D1 无障碍补语义函数',
`  /* ---------------- 事件绑定 ---------------- */
  function bindGlobal() {`,
`  /* ==========================================================
     P1-10 无障碍：把「能用眼睛看懂」的界面补上语义
     静态按钮 / 输入框用可见文本兜底；动态生成的节点（选项、词表、
     弹层）由 MutationObserver 持续补齐 —— 手改 65 个按钮改漏一处就白搭。
     ========================================================== */
  function a11yLabel(el) {
    var t = (el.textContent || '').replace(/\\s+/g, ' ').trim();
    if (t) return t.slice(0, 40);
    return el.getAttribute('title') || el.id || el.className || '按钮';
  }
  function applyA11y(root) {
    if (!root || !root.querySelectorAll) return;
    var add = 0;
    Array.prototype.forEach.call(root.querySelectorAll('button:not([aria-label])'), function (b) {
      b.setAttribute('aria-label', a11yLabel(b));
      if (b.tagName === 'BUTTON' && !b.getAttribute('type')) b.setAttribute('type', 'button');
      if (b.disabled) b.setAttribute('aria-disabled', 'true');
      add++;
    });
    Array.prototype.forEach.call(root.querySelectorAll('input:not([aria-label]),textarea:not([aria-label]),select:not([aria-label])'), function (i) {
      i.setAttribute('aria-label', i.getAttribute('placeholder') || i.getAttribute('title') || i.id || '输入框');
      add++;
    });
    // 容器语义：选项组 / 列表 / 字母输入槽 / 进度条
    Array.prototype.forEach.call(root.querySelectorAll('.opt-grid:not([role])'), function (g) {
      g.setAttribute('role', 'group'); g.setAttribute('aria-label', '选项');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.word-list:not([role]),.list-plain:not([role])'), function (l) {
      l.setAttribute('role', 'list');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.spell-wrap:not([role])'), function (x) {
      x.setAttribute('role', 'textbox'); x.setAttribute('aria-label', '按字母填空');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.bar:not([role])'), function (x) {
      x.setAttribute('role', 'progressbar'); x.setAttribute('aria-label', '进度');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.wbx-kind:not([role]),.mode-card:not([aria-pressed])'), function (x) {
      x.setAttribute('role', 'button');
      x.setAttribute('aria-pressed', x.classList.contains('on') ? 'true' : 'false');
    });
    return add;
  }
  var _a11yOn = false;
  function a11yInit() {
    if (_a11yOn) return;
    _a11yOn = true;
    applyA11y(document);
    // 状态区：屏幕阅读器要能听到 toast 与提示条
    var ts = document.getElementById('toast');
    if (ts) { ts.setAttribute('role', 'status'); ts.setAttribute('aria-live', 'polite'); }
    // 动态节点：答题选项、词表、弹层都是运行时生成的，必须持续补
    if (window.MutationObserver) {
      var pend = null;
      var mo = new MutationObserver(function () {
        if (pend) return;
        pend = setTimeout(function () { pend = null; applyA11y(document); }, 120);
      });
      mo.observe(document.body, { childList: true, subtree: true });
    }
  }

  /* ---------------- 事件绑定 ---------------- */
  function bindGlobal() {`);

P('D2 启动时初始化',
`  function boot() {
    buildWordBank();
    bindGlobal();`,
`  function boot() {
    buildWordBank();
    a11yInit();          // P1-10：先把静态语义补齐（动态节点由 MutationObserver 跟）
    bindGlobal();`);

const bak = APP + '.bak-feat-d-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1）'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
