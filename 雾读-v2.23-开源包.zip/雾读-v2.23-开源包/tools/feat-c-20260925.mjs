/* 雾读 · 功能实装批次 C：P2-3 专注结算回写今日任务 / P2-4 错题打印单
   用法：node tools/feat-c-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

/* P2-3：今日任务里补一条「专注」——专注结算后能与计划闭环 */
P('P2-3 今日任务加专注项',
`    var tasks = [
      { k: '复习到期词', cur: Math.min(todayDue, (stats[todayStr()] && stats[todayStr()].answered) || 0), goal: todayDue, view: 'quiz' },
      { k: '学习新词', cur: Math.min(todayNewDone, newTarget), goal: newTarget, view: 'quiz' }`,
`    var focusGoal = settings.focusGoal || 50;
    var focusDone = focusTodayMinutes();
    var tasks = [
      { k: '复习到期词', cur: Math.min(todayDue, (stats[todayStr()] && stats[todayStr()].answered) || 0), goal: todayDue, view: 'quiz' },
      { k: '学习新词', cur: Math.min(todayNewDone, newTarget), goal: newTarget, view: 'quiz' },
      // P2-3：专注也进今日任务 —— 之前专注只写「专注记录」，与计划/首页的今日任务各算各的
      { k: '专注时长', cur: Math.min(focusDone, focusGoal), goal: focusGoal, view: 'focus' }`);

/* P2-3：专注结算时把「今日任务」的完成情况一起报出来 */
P('P2-3 结算文案带回写',
`    go('focus');
    toast(finished ? '专注完成，休息一下' : '这段专注已记录');`,
`    // P2-3：结算时顺手报一句今日任务的完成度，让「专注」和「今天该做的事」连上
    var t2 = (stats[todayStr()] && stats[todayStr()].answered) || 0;
    var focusGoalNow = settings.focusGoal || 50;
    var head = finished ? '专注完成，休息一下' : '这段专注已记录';
    toast(head + ' · 今日专注 ' + todayMin + '′ / ' + focusGoalNow + '′' + (todayMin >= focusGoalNow ? ' ✅' : ''));
    go('focus');
    renderHome();   // 首页今日任务跟着刷新（无缝，不切页）`);

/* P2-4：错题打印单 */
P('P2-4 打印单函数',
`  /* 从单词详情退回词表（窄屏的「上一页」） */`,
`  /* P2-4 错题打印单：把错词排成「左侧词 + 右侧手写横线」的单页，浏览器打印即可带走。
     纯本地生成，不联网、不引第三方库；打印完那个窗口自己关掉。 */
  function printWrongSheet(kind) {
    var ws = kind ? wrongWordsOf(kind) : wrongWords();
    if (!ws.length) { toast('错题本是空的，先去做几道题'); return; }
    var rows = ws.slice(0, 200).map(function (w, i) {
      var r = progress[w.w] || {};
      var kinds = ERR_KINDS.filter(function (e) { return e.k !== 'hot' && errCount(r, e.k) > 0; })
        .map(function (e) { return e.name; }).join('/');
      return '<tr>' +
        '<td class="n">' + (i + 1) + '</td>' +
        '<td class="cn">' + esc(w.cn) + '</td>' +
        '<td class="blank"></td>' +
        '<td class="tag">' + esc((w.pos || '') + (kinds ? ' · ' + kinds : '')) + '</td>' +
        '</tr>';
    }).join('');
    var html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">' +
      '<title>雾读 · 错题打印单 ' + todayStr() + '</title><style>' +
      'body{font:13px/1.6 "Microsoft YaHei",system-ui;margin:18px;color:#111}' +
      'h1{font-size:17px;margin:0 0 4px}.meta{color:#666;font-size:12px;margin-bottom:12px}' +
      'table{width:100%;border-collapse:collapse}' +
      'th,td{border-bottom:1px solid #ddd;padding:9px 6px;text-align:left;vertical-align:middle}' +
      'th{background:#f3f6fa;font-size:12px;color:#444}' +
      '.n{width:34px;color:#888}.cn{width:38%}.blank{width:34%;border-bottom:1px solid #999}' +
      '.tag{width:22%;color:#888;font-size:11px}' +
      '@media print{body{margin:10mm}.no-print{display:none}}' +
      '</style></head><body>' +
      '<h1>雾读 · 错题打印单</h1>' +
      '<div class="meta">' + todayStr() + ' · 共 ' + ws.length + ' 个词' +
      (ws.length > 200 ? '（只印前 200 个）' : '') + ' · 右侧横线留给自己手写，写完再对答案</div>' +
      '<table><thead><tr><th>#</th><th>中文释义</th><th>写出英文</th><th>词性 / 错因</th></tr></thead><tbody>' +
      rows + '</tbody></table>' +
      '<div class="no-print" style="margin-top:16px"><button onclick="window.print()">打印 / 存 PDF</button></div>' +
      '</body></html>';
    var w2 = window.open('', '_blank');
    if (!w2) { toast('浏览器拦了新窗口 —— 允许弹出窗口后重试'); return; }
    w2.document.write(html);
    w2.document.close();
    toast('打印单已生成 · 共 ' + ws.length + ' 个词');
  }

  /* 从单词详情退回词表（窄屏的「上一页」） */`);

/* P2-4：错题本页加打印按钮的绑定 */
P('P2-4 错题本入口',
`    var pb = $('#wrongPractice');
    if (pb) {
      pb.textContent = list.length ? ('开始复习这一类 · ' + Math.min(30, list.length) + ' 个') : '这一类暂时没有错词';
      pb.disabled = !list.length;
    }`,
`    var pb = $('#wrongPractice');
    if (pb) {
      pb.textContent = list.length ? ('开始复习这一类 · ' + Math.min(30, list.length) + ' 个') : '这一类暂时没有错词';
      pb.disabled = !list.length;
    }
    // P2-4：把当前这一类（或全部）排成可打印的手写单
    var pr = $('#wrongPrint');
    if (pr) pr.onclick = function () { printWrongSheet(wrongKind === 'all' ? null : wrongKind); };`);

const bak = APP + '.bak-feat-c-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1）'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
