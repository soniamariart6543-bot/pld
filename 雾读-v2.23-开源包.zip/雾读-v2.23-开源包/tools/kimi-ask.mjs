/* 雾读 · Kimi 对话脚本（把问题清单发给 Kimi，完整往来落盘本地）
 *
 * 用法:
 *   node tools/kimi-ask.mjs                  # 默认：把两份清单 + 施工提示词发给 kimi-k2.7-code
 *   node tools/kimi-ask.mjs --model kimi-k3  # 换模型
 *   node tools/kimi-ask.mjs --dry            # 只组装不发送（预览提示词）
 *
 * 凭据: 从 ~/.dsh/.credentials.yaml 的 refs.KIMI_API_KEY 读（不写在脚本里）
 * 落盘: docs/kimi-对话记录-YYYYMMDD-HHmmss.md（完整请求 + 完整响应）
 *
 * ⚠ 本机 WinINET 代理指向 127.0.0.1:7897 且该端口无监听 —— Moonshot 国内直连可达，
 *   脚本用 undici 的 dispatcher 直连，不受系统代理影响。
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// ---------- 读凭据（只读 refs.KIMI_API_KEY，不打印值） ----------
function readKey() {
  const p = path.join(os.homedir(), '.dsh', '.credentials.yaml');
  const txt = fs.readFileSync(p, 'utf8');
  const m = txt.match(/^\s*KIMI_API_KEY\s*:\s*(\S+)\s*$/m);
  if (!m) throw new Error('未在 ~/.dsh/.credentials.yaml 的 refs 里找到 KIMI_API_KEY');
  return m[1];
}

// ---------- 读项目文件 ----------
const R = (rel) => {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return `【缺失：${rel}】`;
  return fs.readFileSync(p, 'utf8');
};

// ---------- 命令行参数 ----------
const args = process.argv.slice(2);
const MODEL = (() => { const i = args.indexOf('--model'); return i >= 0 ? args[i + 1] : 'kimi-k2.7-code'; })();
const DRY = args.includes('--dry');
const WITH_SRC = args.includes('--src');   // 带源码片段

// ---------- 按行号抽源码片段 ----------
function sliceLines(rel, from, to) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return `【缺失：${rel}】`;
  const lines = fs.readFileSync(p, 'utf8').split('\n');
  const out = [];
  for (let i = from; i <= to && i <= lines.length; i++) {
    out.push(String(i).padStart(5) + ': ' + lines[i - 1]);
  }
  return out.join('\n');
}
function findFnRange(rel, fnName) {
  const src = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  const startIdx = src.indexOf(`function ${fnName}(`);
  if (startIdx < 0) return null;
  const before = src.slice(0, startIdx);
  const startLine = before.split('\n').length;
  // 从函数起点花括号配平找结尾
  let d = 0, started = false, endIdx = -1;
  for (let j = startIdx; j < src.length; j++) {
    if (src[j] === '{') { d++; started = true; }
    else if (src[j] === '}') { d--; if (started && d === 0) { endIdx = j; break; } }
  }
  const endLine = endIdx < 0 ? startLine : src.slice(0, endIdx).split('\n').length;
  return { startLine, endLine };
}

// ---------- 组装系统提示词 ----------
const SYSTEM = `你是一位资深前端工程师，正在为一个真实在用的个人项目做代码优化与缺陷修正。

【项目的硬约束 —— 违反则方案作废】
- 纯前端单页应用：无构建工具、无 npm 依赖、无框架、无 TypeScript、无模块化 import/export。
- app.js 是单个 IIFE（约 5200 行，2 空格缩进），靠全局作用域协作。禁止拆分文件。
- 禁止引入任何第三方库 / polyfill。
- 数据持久化只用 localStorage + 已有的 IndexedDB 封装（store.js）；无后端、无网络请求。
- 目标运行环境是安卓手机 WebView（打包 APK）+ 移动端浏览器。桌面只是调试。
- 这份代码已经在线使用，有真实学习数据。任何会破坏已有数据的改动必须先说明迁移方案。

【工作方式 —— 请严格照做】
- 先读代码再回答。每个结论给出【文件 + 行号 + 原代码片段】；找不到就明说「未找到」。
- 只输出「定位 + 原代码 + 改后代码」的最小 diff，不要重写整个文件。
- 每个改动先说明：会影响哪些已有功能（回归风险点）。
- 如果我给你的描述与你在代码里看到的不一致，以代码为准，并明确指出我哪里说错了。
- 不确定的地方标「未验证推测」，不要用「应该 / 大概 / 可能」蒙混。
- 宁少勿假：报 3 个真问题比 20 个猜测有价值得多。

【你可以看到的材料】
- 项目里有一份「问题清单」，记录了待修的具体缺陷（含行号与根因）。
- 还有一份「自检清单」，记录了已跑过的校验与剩余项。
- 请以这两份清单为**任务入口**，逐个给出最小修复方案。`;

// ---------- 组装用户消息（把两份清单内嵌） ----------
const problemList = R('问题清单.md');
const selfCheckList = R('自检清单.md');
const readmeHead = R('README.md').split('\n').slice(0, 40).join('\n');

// startFocus / endFocus 的范围（当前磁盘行号）
const fnRange = findFnRange('assets/js/app.js', 'startFocus');
const fnStart = fnRange ? fnRange.startLine : 3403;
const fnEnd = fnRange ? fnRange.endLine : 3670;

const USER = `下面是这个项目的现状材料。请阅读后，按「问题清单」里的条目逐条给出修复方案。

════════════════════════════════════════
【材料一】问题清单（待修） —— 这是任务入口，请逐条处理
════════════════════════════════════════
${problemList}

════════════════════════════════════════
【材料二】自检清单 —— 已跑过的校验与剩余项
════════════════════════════════════════
${selfCheckList}

════════════════════════════════════════
【材料三】README 开头（项目结构速览，节选前 40 行）
════════════════════════════════════════
${readmeHead}
${WITH_SRC ? `

════════════════════════════════════════
【材料四】你上轮点名要的源码片段（app.js，当前磁盘版本）
════════════════════════════════════════

> 说明：磁盘 app.js = 5186 行 / SHA256 \`6C2B44A8D5442501…\`（已含 L1346 与 L4283 两处修复，尚未进包）。
> 下面的行号是**当前磁盘行号**，与旧清单里的行号可能有少量偏移，请以我这里给的为准。

### 4.1 P1-1 的上下文（app.js L2420–L2447）

\`\`\`javascript
${sliceLines('assets/js/app.js', 2420, 2447)}
\`\`\`

### 4.2 startFocus 函数完整实现（app.js L${fnStart}–L${fnEnd}）

\`\`\`javascript
${sliceLines('assets/js/app.js', fnStart, fnEnd)}
\`\`\`

### 4.3 focusTick 计时核心（app.js L3464–L3514，每 1 秒被 setInterval 调用）

\`\`\`javascript
${sliceLines('assets/js/app.js', 3464, 3514)}
\`\`\`

### 4.4 endFocus 函数完整实现（app.js L3671–L3730，含 clearInterval）

\`\`\`javascript
${sliceLines('assets/js/app.js', 3671, 3730)}
\`\`\`

### 4.5 其它相关函数的行号索引（便于你定位，不展开全文）

| 函数 | 行号 |
|---|---|
| \`renderFocus\` | L3351 |
| \`logSession\` | L3384 |
| \`startFocus\` | L3403–${fnEnd} |
| \`focusTick\` | L3464–L3514 |
| \`updateFocusBar\` | L3515 |
| \`endFocus\` | L3671 |
` : ''}

════════════════════════════════════════
【请你输出】
════════════════════════════════════════

请按下面的结构回答，**不要省略任何一条**：

## 一、对问题清单的复核
逐条看问题清单里的每一项（你反馈的问题 1-6、P1-1、已改未进包的 2 处、自检发现的 P1/P2/P3），
告诉我：
- 这条描述是否清晰到可以直接动手？不清晰的，指出**缺什么信息**。
- 有没有你从清单内容里就看出的**矛盾或可疑之处**？（例如：同一条在不同地方说法不一致）

## 二、优先级排序
把待修项按「先修哪个」排序，给出理由。判据：影响面 × 修复成本 × 是否阻塞使用。

## 三、逐条修复方案
对**优先级最高的前 3 条**，各给出：
1. 定位（文件 + 行号）
2. 原代码片段
3. 改后代码（最小 diff，要求可直接照抄应用）
4. 回归风险点（改完要重点测什么）
5. 验证方法（怎么确认修好了）

## 四、清单里我看不出、但你需要知道的
列出为了给出准确方案，你还需要我提供哪些材料。

【注意】
- ${WITH_SRC ? '材料四已给出你上轮点名要的两处源码，P1-1 与 E2 都应给出**可直接照抄的精确 diff**。' : '我现在只给你清单，没有给你 app.js 源码。凡需要看实现才能确定的，请明确说「需要 app.js 第 X 行附近的源码」，不要猜。'}
- 不要输出完整的 app.js 或任何整份文件。
- 涉及行号时，请用材料四里给的**当前磁盘行号**。`;

// ---------- 发送 ----------
async function main() {
  const key = readKey();

  console.log('模型:', MODEL);
  console.log('系统提示词:', SYSTEM.length, '字符');
  console.log('用户消息:', USER.length, '字符');
  console.log('  其中 问题清单:', problemList.length, '字符 /', problemList.split('\n').length, '行');
  console.log('  其中 自检清单:', selfCheckList.length, '字符 /', selfCheckList.split('\n').length, '行');

  if (DRY) {
    const out = path.join(ROOT, 'docs', 'kimi-预览-提示词.md');
    fs.writeFileSync(out, `# Kimi 提示词预览\n\n## 系统提示词\n\n\`\`\`\n${SYSTEM}\n\`\`\`\n\n## 用户消息\n\n\`\`\`\n${USER}\n\`\`\`\n`, 'utf8');
    console.log('\n[dry] 已写出预览:', out);
    return;
  }

  const t0 = Date.now();
  const res = await fetch('https://api.moonshot.cn/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: USER },
      ],
      max_tokens: 8192,
      // ★ kimi-k2.7-code / kimi-k2.7-code-highspeed 只接受 temperature: 1
      //   （实测报错：invalid temperature: only 1 is allowed for this model）
      //   想用其他 temperature 请换 kimi-k3 / kimi-k2.6
      temperature: 1,
    }),
  });
  const ms = Date.now() - t0;
  const j = await res.json();

  if (j.error) {
    console.error('\n✗ API 返回错误:', JSON.stringify(j.error));
    process.exit(1);
  }

  const reply = j.choices?.[0]?.message?.content || '';
  const reasoning = j.choices?.[0]?.message?.reasoning_content || '';

  console.log(`\n✓ HTTP ${res.status} · ${ms} ms · 回复 ${reply.length} 字符`);
  if (j.usage) console.log('  tokens:', JSON.stringify(j.usage));

  // ---------- 落盘 ----------
  const ts = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const stamp = `${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(ts.getDate())}-${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}`;
  const outDir = path.join(ROOT, 'docs');
  fs.mkdirSync(outDir, { recursive: true });
  const out = path.join(outDir, `kimi-对话记录-${stamp}.md`);

  const body = `# Kimi 对话记录 · ${stamp}

> 模型：\`${MODEL}\`　HTTP ${res.status}　耗时 ${ms} ms
> 用量：\`${JSON.stringify(j.usage || {})}\`
> 附件：\`问题清单.md\`（${problemList.length} 字符 / ${problemList.split('\n').length} 行）· \`自检清单.md\`（${selfCheckList.length} 字符 / ${selfCheckList.split('\n').length} 行）

---

## 一、发给 Kimi 的系统提示词

\`\`\`text
${SYSTEM}
\`\`\`

---

## 二、发给 Kimi 的用户消息（含两份清单全文）

\`\`\`text
${USER}
\`\`\`

---

## 三、Kimi 的回复

${reasoning ? `### 思考过程（reasoning_content）\n\n\`\`\`text\n${reasoning}\n\`\`\`\n\n### 正文\n\n` : ''}${reply}

---

*本文件由 \`tools/kimi-ask.mjs\` 自动生成；完整保留了请求与响应，可回溯。*
`;

  fs.writeFileSync(out, body, 'utf8');
  console.log('\n✓ 对话记录已落盘:', out);
  console.log('  ' + fs.statSync(out).size + ' B');
}

main().catch((e) => { console.error('✗', e.message); process.exit(1); });
