/* 雾读 · 按《代码自检报告》修第二批（F1 F5 M3 M5 M7 F2）
   用法：node tools/fix-selfcheck-2-20260925.mjs   （写前备份，每处命中数必须为 1） */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';
import path from 'path';

const ROOT = 'D:\\DeepSeek\\项目\\四六级单词';
const APP = path.join(ROOT, 'assets', 'js', 'app.js');
const NAT = path.join(ROOT, 'assets', 'js', 'native.js');
const REAL = path.join(ROOT, 'assets', 'js', 'data', 'real.js');

const patches = [
  /* F1 翻译采分点：只比原形 → 误报漏译 */
  [APP, 'F1 keywordHit 词形归一',
`  function keywordHit(text, w) {
    var t = ' ' + normalizeAns(text) + ' ', key = normalizeAns(w);
    if (t.indexOf(' ' + key) >= 0) return true;
    return variantForms(key).some(function (v) { return t.indexOf(' ' + v) >= 0; });
  }`,
`  function keywordHit(text, w) {
    var t = ' ' + normalizeAns(text) + ' ', key = normalizeAns(w);
    if (!key) return false;
    if (t.indexOf(' ' + key) >= 0) return true;
    // 自检 F1：只比原形会把正确表达判成「漏译」—— economies 对 economy、well-known 对 known 都该算命中
    var forms = variantForms(key).concat(stems(key), stems(norm(key)));
    if (forms.some(function (v) { return v && t.indexOf(' ' + v) >= 0; })) return true;
    // 连字符 / 空格互换（well-known ↔ well known），再按词逐个做词形比对（复数、单三、过去式）
    var flat = (' ' + t + ' ').replace(/-/g, ' ').replace(/\\s+/g, ' ');
    var keyFlat = key.replace(/-/g, ' ');
    if (flat.indexOf(' ' + keyFlat + ' ') >= 0) return true;
    if (keyFlat.indexOf(' ') < 0) {
      var ks = stems(keyFlat);
      var toks = flat.split(' ');
      for (var i = 0; i < toks.length; i++) {
        if (!toks[i]) continue;
        if (ks.indexOf(toks[i]) >= 0) return true;
        if (stems(toks[i]).indexOf(keyFlat) >= 0) return true;
      }
    }
    return false;
  }`],

  /* F5 恢复默认：整对象替换会丢掉专注强硬模式与专注目标 */
  [APP, 'F5 defaultSettings 补字段',
`      plan: null,
      maxReview: 60,
      remind: true,
      remindAt: '20:00'
    };`,
`      plan: null,
      maxReview: 60,
      // 自检 F5：「恢复默认」是整对象替换 —— 这几项原来不在默认里，一点就把专注强硬模式/目标静默关掉
      focusHard: false,
      focusGoal: 50,
      voice: 'us',
      remind: true,
      remindAt: '20:00'
    };`],

  /* M3 文案：dueWeek 是「今天起 7 天」，不是自然周 */
  [APP, 'M3 负载文案',
`      loadBits.push('本周共 ' + c.dueWeek + ' 词');`,
`      loadBits.push('未来 7 天共 ' + c.dueWeek + ' 词');`],

  /* M5 镜像键清单：含不存在的 write.v1，漏了 quiz.v1 */
  [NAT, 'M5 镜像键清单',
`      var keys = ['wudu.progress.v1', 'wudu.settings.v1', 'wudu.stats.v1', 'wudu.grammar.v1',
        'wudu.translate.v1', 'wudu.write.v1', 'wudu.focus.v1', 'wudu.adapt.v1', 'wudu.checkin.v1'];`,
`      // 自检 M5：原清单里有根本不存在的 wudu.write.v1，却漏了 wudu.quiz.v1（断点续学的进度）
      var keys = ['wudu.progress.v1', 'wudu.settings.v1', 'wudu.stats.v1', 'wudu.grammar.v1',
        'wudu.translate.v1', 'wudu.focus.v1', 'wudu.quiz.v1', 'wudu.adapt.v1', 'wudu.checkin.v1'];`],

  /* M7 镜像写入失败被完全吞掉 */
  [NAT, 'M7 镜像失败留痕',
`      try {
        if (value === null || value === undefined) quiet(S.remove({ key: 'wudu:' + key }));
        else quiet(S.set({ key: 'wudu:' + key, value: String(value) }));
      } catch (e) {}`,
`      try {
        if (value === null || value === undefined) quiet(S.remove({ key: 'wudu:' + key }));
        else quiet(S.set({ key: 'wudu:' + key, value: String(value) }));
      } catch (e) {
        // 自检 M7：镜像写失败原先一点痕迹都没有，而界面正承诺「清缓存不丢进度」—— 至少留个日志
        try { console.warn('[雾读] 原生镜像写入失败', key, e && e.message); } catch (_) {}
      }`]
];

let fails = 0;
for (const [file, name, from, to] of patches) {
  let s = fs.readFileSync(file, 'utf8');
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1），跳过'); fails++; continue; }
  const bak = file + '.bak-fix2-20260925';
  if (!fs.existsSync(bak)) fs.copyFileSync(file, bak);
  fs.writeFileSync(file, s.replace(from, to), 'utf8');
  console.log('✓ ' + name);
}

/* F2 真题数据自相矛盾：answer 写 volumes，题库里只有 volume，解析却说「需变复数」 */
{
  let s = fs.readFileSync(REAL, 'utf8');
  const hits = (s.match(/answer: "volumes"/g) || []).length;
  if (hits === 1) {
    const bak = REAL + '.bak-fix2-20260925';
    if (!fs.existsSync(bak)) fs.copyFileSync(REAL, bak);
    s = s.replace('answer: "volumes"', 'answer: "volume"');
    fs.writeFileSync(REAL, s, 'utf8');
    console.log('✓ F2 real.js answer volumes → volume');
  } else {
    console.log('✗ F2：answer: "volumes" 命中 ' + hits + ' 次，跳过'); fails++;
  }
}

if (fails) { console.log('\n有 ' + fails + ' 处未命中 —— 请核对基线。'); process.exit(1); }
console.log('\n全部写入完成。');
