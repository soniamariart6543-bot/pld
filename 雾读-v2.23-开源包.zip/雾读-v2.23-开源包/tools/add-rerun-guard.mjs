/* 雾读 · 给历史批次脚本补「重跑守卫」
 * 背景（2026-09-25 流程自检发现）：feat-a~e 与 fix-selfcheck×4 这批一次性脚本都是
 *   readFileSync → 字符串替换 → writeFileSync 全文件重写，**没有幂等判断**。
 *   它们已经应用过了，若有人再跑一次（比如接手时以为没做），内容会被重复插入
 *   —— feat-f 实测过同类问题：重跑会多加 11 组 role / 22 个 aria。
 * 做法：在每个脚本的头部注释块之后插入一小段守卫；配合 tools/.applied/ 下的标记文件，
 *   已应用的批次再跑会被拦下（要真重跑加 --force）。
 * 幂等：本脚本自身重复运行不会重复插入（按关键字判定）。
 * 用法：node tools/add-rerun-guard.mjs [--dry]
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const TOOLS = path.join(ROOT, 'tools');
const APPLIED = path.join(TOOLS, '.applied');
const DRY = process.argv.includes('--dry');

const TARGETS = [
  'feat-a-20260925.mjs', 'feat-b-20260925.mjs', 'feat-c-20260925.mjs',
  'feat-d-20260925.mjs', 'feat-e-20260925.mjs',
  'fix-selfcheck-20260925.mjs', 'fix-selfcheck-2-20260925.mjs',
  'fix-selfcheck-3-20260925.mjs', 'fix-selfcheck-4-20260925.mjs'
];

const GUARD = `
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}
`;

if (!DRY) fs.mkdirSync(APPLIED, { recursive: true });

let added = 0, skipped = 0, flagged = 0;
for (const name of TARGETS) {
  const fp = path.join(TOOLS, name);
  if (!fs.existsSync(fp)) { console.log('  · 缺文件，跳过：' + name); continue; }

  // 标记文件（本批次确实已应用）
  const flag = path.join(APPLIED, name + '.done');
  if (!fs.existsSync(flag)) {
    if (!DRY) fs.writeFileSync(flag, 'applied 2026-09-25 (flow self-check backfill)\n', 'utf8');
    flagged++;
  }

  let src = fs.readFileSync(fp, 'utf8');
  if (src.includes('重跑守卫')) { console.log('  ✓ 已有守卫，跳过：' + name); skipped++; continue; }

  const end = src.indexOf('*/');
  if (end < 0) { console.log('  ⚠ 找不到头部注释块，未改：' + name); continue; }
  const at = end + 2;
  src = src.slice(0, at) + GUARD + src.slice(at);
  if (!DRY) fs.writeFileSync(fp, src, 'utf8');
  console.log('  + 已加守卫：' + name);
  added++;
}

console.log('\n汇总：加守卫 ' + added + ' 个 · 已有跳过 ' + skipped + ' 个 · 新建标记 ' + flagged + ' 个');
console.log('标记目录：' + path.relative(ROOT, APPLIED));
if (DRY) console.log('（--dry：未写盘）');
