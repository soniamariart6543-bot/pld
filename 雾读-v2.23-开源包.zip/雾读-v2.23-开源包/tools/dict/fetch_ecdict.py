#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""备份方案：从 ECDICT（开源英汉词典库）直接取 CET4 / CET6 全量词表。

ECDICT 的 stardict.csv 每行字段：
    word, phonetic, definition, translation, pos, collins, oxford, tag, bnc, frq, exchange, detail, audio
其中 tag 列形如 "zk gk cet4 cet6 ky toefl"，据此筛出四六级词。

产物：tools/dict/out/ecdict-cet4.json、ecdict-cet6.json
"""
import csv
import io
import json
import os
import re
import sys
import time
import urllib.request
import zipfile

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
CACHE = os.path.join(HERE, "cache")
os.makedirs(OUT, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)

TARGETS = [
    ("https://ghproxy.net/https://github.com/skywind3000/ECDICT/releases/download/1.0.28/ecdict-stardict-28.zip", "zip"),
    ("https://github.moeyy.xyz/https://github.com/skywind3000/ECDICT/releases/download/1.0.28/ecdict-stardict-28.zip", "zip"),
    ("https://github.com/skywind3000/ECDICT/releases/download/1.0.28/ecdict-stardict-28.zip", "zip"),
    ("https://cdn.jsdelivr.net/gh/skywind3000/ECDICT@master/ecdict.csv", "csv"),
]


def fetch(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def main():
    blob, kind, used = None, None, None
    for url, k in TARGETS:
        t = time.time()
        try:
            blob = fetch(url)
            kind, used = k, url
            print("下载成功 %s  (%.1f MB, %.0fs)" % (url[:70], len(blob) / 1048576, time.time() - t))
            break
        except Exception as e:
            print("失败 %s → %s" % (url[:70], e))
    if blob is None:
        print("所有源都失败")
        return 1

    raw = blob
    if kind == "zip" or blob[:2] == b"PK":
        zf = zipfile.ZipFile(io.BytesIO(blob))
        name = [n for n in zf.namelist() if n.lower().endswith("stardict.csv")]
        if not name:
            name = [n for n in zf.namelist() if n.lower().endswith(".csv")]
        print("压缩包内：%s" % name[:3])
        raw = zf.read(name[0])

    text = raw.decode("utf-8", "ignore")
    rd = csv.reader(io.StringIO(text))
    header = next(rd)
    idx = {h.strip(): i for i, h in enumerate(header)}
    need = ["word", "phonetic", "translation", "pos", "tag", "frq", "bnc", "collins"]
    if "word" not in idx or "tag" not in idx:
        print("字段不对：%s" % header)
        return 1

    def col(row, key):
        i = idx.get(key, -1)
        return row[i].strip() if 0 <= i < len(row) else ""

    c4, c6, n = [], [], 0
    for row in rd:
        n += 1
        if len(row) < 3:
            continue
        tags = col(row, "tag").split()
        w = col(row, "word")
        if not w or not re.match(r"^[A-Za-z][A-Za-z\-']*$", w):
            continue
        in4, in6 = "cet4" in tags, "cet6" in tags
        if not (in4 or in6):
            continue
        cn = col(row, "translation").replace("\\n", "；").replace("\n", "；")
        cn = re.sub(r"；{2,}", "；", cn).strip("； ")
        if not cn:
            continue
        rec = {
            "w": w.lower(),
            "ph": col(row, "phonetic"),
            "pos": col(row, "pos").split("/")[0][:12],
            "cn": cn[:180],
            "ex": [],
        }
        try:
            frq = int(col(row, "frq") or 0)
        except Exception:
            frq = 0
        rec["_frq"] = frq
        (c4 if in4 else c6).append(rec)

    print("扫描 %d 行 → CET4 %d 条 / CET6 %d 条" % (n, len(c4), len(c6)))
    for name, rows in (("ecdict-cet4.json", c4), ("ecdict-cet6.json", c6)):
        with io.open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False)
        print("  写入 out/%s" % name)

    with io.open(os.path.join(OUT, "ecdict-source.txt"), "w", encoding="utf-8") as f:
        f.write("source=%s\nkind=%s\nrows=%d\ncet4=%d\ncet6=%d\n" % (used, kind, n, len(c4), len(c6)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
