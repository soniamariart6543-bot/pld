# -*- coding: utf-8 -*-
"""
雾读 · CET4/CET6 词表产物验收自检（可复跑）

检查项：
  1) JSON 可解析 + 条数（<3000 视为不达标，退出码 1）
  2) 抽查词命中与中文释义
  3) 乱码（\ufffd）与"无中文释义"条目
  4) 音标 / 词性 / 例句覆盖率、例句条数分布
  5) 结构合规（字段恰为 w/ph/pos/cn/ex，无多余键）
  6) CET4 x CET6 重叠与并集

用法: python tools/dict/verify_cet.py
"""
import sys, io, os, json, re, collections

sys.stdout.reconfigure(encoding="utf-8")

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
FILES = {"CET4": "raw-cet4.json", "CET6": "raw-cet6.json"}
PROBE = ["abandon", "maintain", "sufficient", "hypothesis", "controversial"]
CJK = re.compile(r"[\u4e00-\u9fff]")
KEYS = {"w", "ph", "pos", "cn", "ex"}

fail = []
loaded = {}

for level, name in FILES.items():
    p = os.path.join(OUT, name)
    print("=" * 74)
    if not os.path.exists(p):
        print(f"[FAIL] 缺文件 {p}")
        fail.append(name)
        continue
    with io.open(p, encoding="utf-8") as f:
        d = json.load(f)                       # 可解析性
    loaded[level] = d
    n = len(d)
    print(f"{name}: 可解析 OK, {n} 条, {os.path.getsize(p)} B")
    if n < 3000:
        print("   [FAIL] 条数 < 3000")
        fail.append(name)

    # 结构合规
    bad_keys = sum(1 for r in d if set(r) != KEYS)
    types_bad = sum(1 for r in d if not isinstance(r["ex"], list)
                    or any(set(e) != {"en", "cn"} for e in r["ex"]))
    # 乱码 / 无中文
    mojibake = [r["w"] for r in d if "\ufffd" in r["cn"]]
    no_cjk = [r["w"] for r in d if not CJK.search(r["cn"])]
    dup = [w for w, c in collections.Counter(r["w"] for r in d).items() if c > 1]

    ph = sum(1 for r in d if r["ph"])
    pos = sum(1 for r in d if r["pos"])
    ex = sum(1 for r in d if r["ex"])
    excn = sum(1 for r in d if r["ex"] and r["ex"][0].get("cn"))
    exs = collections.Counter(len(r["ex"]) for r in d)

    print(f"   结构: 多余/缺失键 {bad_keys} 条, ex 格式异常 {types_bad} 条, 重复词 {len(dup)} 个")
    print(f"   中文: 乱码 {len(mojibake)} 条, 无中文释义 {len(no_cjk)} 条")
    print(f"   完整度: 音标 {ph/n*100:.1f}% | 词性 {pos/n*100:.1f}% | 例句 {ex/n*100:.1f}% | "
          f"例句带中文 {excn/n*100:.1f}%")
    print(f"   例句条数分布: {dict(sorted(exs.items()))}")

    idx = {r["w"]: r for r in d}
    print(f"   抽查({level}):")
    for w in PROBE:
        r = idx.get(w)
        if not r:
            print(f"      - {w:14s} 未命中（若为 hypothesis 属正常：六级词）")
            continue
        e = r["ex"][0] if r["ex"] else {}
        print(f"      + {w:14s} {r['ph']:20s} {r['pos']:8s} {r['cn'][:42]}")
        if e:
            print(f"         例: {e.get('en','')[:56]} | {e.get('cn','')[:32]}")

    if mojibake or no_cjk or bad_keys or types_bad or dup:
        fail.append(name + "-内容")

if len(loaded) == 2:
    a, b = {r["w"] for r in loaded["CET4"]}, {r["w"] for r in loaded["CET6"]}
    print("=" * 74)
    print(f"CET4={len(a)}  CET6={len(b)}  交集={len(a & b)}  并集={len(a | b)}")
    five = set(PROBE)
    print(f"5 词抽查（并集口径）: {sorted(five - (a | b)) or '全部命中'}")

print("=" * 74)
if fail:
    print("FAIL:", fail)
    sys.exit(1)
print("ALL CHECKS PASSED")
