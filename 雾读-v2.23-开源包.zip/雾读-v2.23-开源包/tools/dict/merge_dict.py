#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把「现有精编词」与「抓取的全量词表」合并成 assets/js/data/cet4.js / cet6.js。

规则：
  · 现有 310 个精编词（带搭配/语法/例句）原样保留，一个字不改；
  · 抓来的词补字段：w / ph 音标 / pos 词性 / cn 释义（freq 默认 3，其余留空）；
  · 同一个词同时出现在 CET4 与 CET6 → level 记为 "cet4,cet6"，收在 cet4.js 里；
  · 词表按词形字母序排列，去重；释义里的引号与反斜杠会转义。

用法：
    python tools/dict/merge_dict.py            # 合并并写回 assets/js/data/
    python tools/dict/merge_dict.py --dry-run  # 只看统计，不写文件
"""
import argparse
import io
import json
import os
import re
import shutil
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
DATA = os.path.join(ROOT, "assets", "js", "data")
OUT = os.path.join(HERE, "out")
BACKUP = os.path.join(ROOT, "_backup", time.strftime("%Y%m%d-full-dict"))

POS_RE = re.compile(r"^\s*((?:[a-z]+\.\s*){1,3})", re.I)
POS_FIX = {"a.": "adj.", "ad.": "adv.", "adv": "adv.", "n": "n.", "v": "v.", "adj": "adj.", "prep": "prep.", "conj": "conj."}


def clean_cn(cn):
    """把原始释义清洗成人读得顺的样子：
       去领域标注 [法]/[医]、去重复词性、逗号统一成中文分号、压缩空白。"""
    cn = (cn or "").replace("\\n", "；").replace("\n", "；")
    cn = re.sub(r"\[[^\]]{1,8}\]", "", cn)
    cn = re.sub(r"；(?:\s*[a-z]{1,5}\.\s*)+", "；", cn)      # 分号后重复的词性
    cn = re.sub(r"^\s*(?:[a-z]{1,5}\.\s*)+", "", cn)         # 开头的词性（pos 字段已单独存）
    cn = cn.replace(", ", "；").replace("，", "；").replace(",", "；")
    cn = re.sub(r"；{2,}", "；", cn)
    cn = re.sub(r"\s{2,}", " ", cn)
    # 义项去重（抓来的释义常出现「充分的；足够的；充分的；足够的」这类重复）
    segs, seen = [], set()
    for s in cn.split("；"):
        s = s.strip()
        if not s or s in seen:
            continue
        seen.add(s)
        segs.append(s)
    return "；".join(segs)


def load(p, dft=None):
    try:
        with io.open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print("  读取失败 %s (%s)" % (os.path.basename(p), e))
        return dft if dft is not None else []


def split_pos(cn, pos=""):
    cn = (cn or "").strip().replace("\n", " ")
    cn = re.sub(r"\s{2,}", " ", cn)
    pos = (pos or "").strip()
    if not pos:
        m = POS_RE.match(cn)
        if m:
            pos = m.group(1).strip()
            cn = cn[len(m.group(1)):].strip()
    pos = POS_FIX.get(pos.lower(), pos)
    return pos, cn


def clean_ph(ph):
    ph = (ph or "").strip()
    if not ph:
        return ""
    if not ph.startswith("/"):
        ph = "/" + ph.strip("/") + "/"
    return ph


def freq_star(rec):
    """人读得出的频率星级：ECDICT 的 frq（越大越常见）/ 抓取表自带的 freq。"""
    if isinstance(rec.get("freq"), int) and 1 <= rec["freq"] <= 5:
        return rec["freq"]
    f = rec.get("_frq") or 0
    try:
        f = int(f)
    except Exception:
        f = 0
    if f >= 10000:
        return 5
    if f >= 5000:
        return 4
    if f >= 1500:
        return 3
    if f >= 300:
        return 2
    return 1


def norm(rec):
    """把任意来源的一条词规整成统一字段。"""
    w = (rec.get("w") or rec.get("word") or "").strip()
    if not w or " " in w:                       # 只收单词（短语后面单独滤）
        return None
    if not re.match(r"^[A-Za-z][A-Za-z\-']*$", w):
        return None
    pos, cn = split_pos(rec.get("cn") or rec.get("trans") or "", rec.get("pos"))
    if not cn:
        return None
    return {
        "w": w.lower(),
        "ph": clean_ph(rec.get("ph") or rec.get("phonetic")),
        "pos": pos,
        "cn": clean_cn(cn),
        "ex": rec.get("ex") or [],
    }


def index_by_word(rows):
    out = {}
    for r in rows:
        n = norm(r)
        if not n:
            continue
        cur = out.get(n["w"])
        if not cur:
            out[n["w"]] = n
            continue
        # 已有条目：补齐空缺字段，释义更长的优先
        if not cur["ph"] and n["ph"]:
            cur["ph"] = n["ph"]
        if not cur["pos"] and n["pos"]:
            cur["pos"] = n["pos"]
        if len(n["cn"]) > len(cur["cn"]):
            cur["cn"] = n["cn"]
        if not cur["ex"] and n["ex"]:
            cur["ex"] = n["ex"]
    return out


def js_value(v):
    return json.dumps(v, ensure_ascii=False)


def render(file_var, rows):
    lines = ["window.%s = [" % file_var]
    for i, r in enumerate(rows):
        lines.append("  {")
        lines.append('    w: %s,' % js_value(r["w"]))
        lines.append('    ph: %s,' % js_value(r.get("ph", "")))
        lines.append('    pos: %s,' % js_value(r.get("pos", "")))
        lines.append('    cn: %s,' % js_value(r.get("cn", "")))
        lines.append('    level: %s,' % js_value(r.get("level", "")))
        lines.append('    freq: %d,' % int(r.get("freq", 3)))
        lines.append('    colloc: %s,' % js_value(r.get("colloc", [])))
        lines.append('    note: %s,' % js_value(r.get("note", "")))
        lines.append('    ex: %s' % js_value(r.get("ex", [])))
        lines.append("  }" + ("," if i < len(rows) - 1 else ""))
    lines.append("];")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cur4 = load(os.path.join(OUT, "cur-cet4.json"))
    cur6 = load(os.path.join(OUT, "cur-cet6.json"))
    raw4 = load(os.path.join(OUT, "raw-cet4.json")) + load(os.path.join(OUT, "ecdict-cet4.json"))
    raw6 = load(os.path.join(OUT, "raw-cet6.json")) + load(os.path.join(OUT, "ecdict-cet6.json"))
    print("现有精编：cet4 %d / cet6 %d ｜ 抓取：cet4 %d / cet6 %d" % (len(cur4), len(cur6), len(raw4), len(raw6)))
    if not raw4 and not raw6:
        print("没有抓到全量词表（tools/dict/out/raw-*.json 为空），先跑抓取。")
        return 1

    old = {}
    for r in cur4 + cur6:                      # 现有词，最高优先级
        old[r["w"].lower()] = r

    R4 = index_by_word(raw4)
    R6 = index_by_word(raw6)

    both = [w for w in R4 if w in R6]
    only6 = [w for w in R6 if w not in R4]

    out4, out6 = [], []
    for w, r in R4.items():
        keep = old.get(w)
        row = dict(keep) if keep else dict(r)
        row.setdefault("ph", r["ph"])
        row["level"] = "cet4,cet6" if w in R6 else "cet4"
        row["freq"] = freq_star(row) if not keep else keep.get("freq", freq_star(row))
        row.setdefault("colloc", [])
        row.setdefault("note", "")
        row.setdefault("ex", r["ex"] if not keep else keep.get("ex", []))
        out4.append(row)
    # 现有词里属于 cet4 但抓取表没覆盖的，也要留下
    for w, keep in old.items():
        if w not in R4 and w not in R6 and str(keep.get("level", "")).startswith("cet4"):
            out4.append(keep)
    for w in only6:
        keep = old.get(w)
        row = dict(keep) if keep else dict(R6[w])
        row.setdefault("ph", R6[w]["ph"])
        row["level"] = "cet6"
        row.setdefault("freq", 3)
        row.setdefault("colloc", [])
        row.setdefault("note", "")
        row.setdefault("ex", R6[w]["ex"] if not keep else keep.get("ex", []))
        out6.append(row)
    for w, keep in old.items():
        if w not in R4 and w not in R6 and str(keep.get("level", "")).startswith("cet6"):
            out6.append(keep)

    out4.sort(key=lambda r: r["w"])
    out6.sort(key=lambda r: r["w"])
    print("合并结果：cet4 %d 条（其中 %d 条同时属六级）｜ cet6 %d 条" % (len(out4), len(both), len(out6)))
    print("现有精编保留：%d 条；新增：%d + %d 条" % (
        len(old), len(out4) - len([r for r in out4 if r["w"] in old]), len(out6) - len([r for r in out6 if r["w"] in old])))
    noex = len([r for r in out4 + out6 if not r.get("ex")])
    noph = len([r for r in out4 + out6 if not r.get("ph")])
    print("字段完整度：无例句 %d 条 · 无音标 %d 条" % (noex, noph))

    if args.dry_run:
        print("dry-run：未写文件")
        return 0

    os.makedirs(BACKUP, exist_ok=True)
    for f in ("cet4.js", "cet6.js"):
        src = os.path.join(DATA, f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(BACKUP, f))
    with io.open(os.path.join(DATA, "cet4.js"), "w", encoding="utf-8", newline="\n") as f:
        f.write(render("CET4_WORDS", out4))
    with io.open(os.path.join(DATA, "cet6.js"), "w", encoding="utf-8", newline="\n") as f:
        f.write(render("CET6_WORDS", out6))
    print("已写回 assets/js/data/cet4.js、cet6.js；原文件备份在 %s" % os.path.relpath(BACKUP, ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
