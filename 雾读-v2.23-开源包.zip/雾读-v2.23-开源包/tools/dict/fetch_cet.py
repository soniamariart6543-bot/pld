# -*- coding: utf-8 -*-
"""
雾读 · CET4/CET6 全量词表原始数据抓取脚本（可复跑，幂等）

产物:
  tools/dict/out/raw-cet4.json
  tools/dict/out/raw-cet6.json
  tools/dict/out/SOURCE-REPORT.md

数据源（自动多镜像 + 重试 + 断点续传，缓存于 tools/dict/cache/）:
  A. skywind3000/ECDICT  ecdict.csv        —— word/phonetic/translation/tag，tag 含 cet4/cet6 定"大纲身份"
  B. kajweb/dict         book/*.zip        —— 扇贝格式 JSONL，含 usphone/ukphone/trans/例句(英+中)
  C. KyleBing/english-vocabulary json/*.json —— word/translations[{translation,type}]（补漏释义与词性）

用法:
  python tools/dict/fetch_cet.py            # 全流程（缺什么下什么）
  python tools/dict/fetch_cet.py --offline  # 只用缓存，不联网
  python tools/dict/fetch_cet.py --stats    # 只打印现有产物统计
"""
import sys, io, os, csv, json, zipfile, subprocess, time, re, argparse

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")
OUT = os.path.join(HERE, "out")
RAW = "https://raw.githubusercontent.com"
MIRRORS = [
    "https://gh-proxy.com/" + RAW,
    "https://ghfast.top/" + RAW,
    RAW,
    "https://gitclone.com/github.com",  # 特殊：/user/repo/raw/branch/path
]

ECDICT = dict(user="skywind3000", repo="ECDICT", branch="master", path="ecdict.csv",
              size=65933428, dest="ecdict.csv")
KAJWEB_FILES = [
    "1521164649209_CET4_1.zip", "1521164635506_CET4_2.zip", "1521164643060_CET4_3.zip",
    "1523620217431_CET4luan_1.zip", "1524052539052_CET4luan_2.zip",
    "1521164668667_CET6_1.zip", "1524052554766_CET6_2.zip", "1521164633851_CET6_3.zip",
    "1521164660466_CET6luan_1.zip",
]
KYLEBING = [("3-CET4-顺序.json", "kb_cet4.json"), ("4-CET6-顺序.json", "kb_cet6.json")]

POS_MAP = {
    "n": "n.", "v": "v.", "vt": "vt.", "vi": "vi.", "adj": "adj.", "a": "adj.",
    "adv": "adv.", "prep": "prep.", "conj": "conj.", "pron": "pron.", "art": "art.",
    "num": "num.", "int": "int.", "interj": "int.", "aux": "aux.", "abbr": "abbr.",
    "u": "n.", "c": "n.", "ad": "adv.", "prep./adv.": "prep.",
}
POS_ORDER = ["n.", "v.", "vt.", "vi.", "adj.", "adv.", "prep.", "conj.", "pron.",
             "art.", "num.", "int.", "aux.", "abbr."]


def log(*a):
    print(*a, flush=True)


# ---------------------------------------------------------------- download
def mirror_urls(user, repo, branch, path, raw_path=None):
    urls = []
    for m in MIRRORS:
        if m.endswith("github.com"):
            urls.append(f"{m}/{user}/{repo}/raw/{branch}/{path}")
        else:
            urls.append(f"{m}/{user}/{repo}/{branch}/{path}")
    return urls


def curl_fetch(url, dest, timeout=600, resume=True):
    """用 curl.exe 下载（支持续传）。返回 (ok, msg)。"""
    cmd = ["curl.exe", "-sS", "-L", "--max-time", str(timeout), "-o", dest,
           "-w", "%{http_code} %{size_download}"]
    if resume and os.path.exists(dest) and os.path.getsize(dest) > 0:
        cmd += ["-C", "-"]
    cmd.append(url)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 30)
        out = (p.stdout or "").strip() + " " + (p.stderr or "").strip()
        code = (p.stdout or "").strip().split(" ")[0] if p.stdout else "000"
        return code == "200" or code == "206", out.strip()
    except Exception as e:
        return False, f"EXC {e}"


def ensure(user, repo, branch, path, dest, expect_size=None, tries=3, offline=False):
    """确保本地有 dest；多镜像 + 重试 + 续传。"""
    full = os.path.join(CACHE, dest)
    if expect_size and os.path.exists(full) and os.path.getsize(full) >= expect_size:
        return full, "cache-hit"
    if os.path.exists(full) and os.path.getsize(full) > 1000 and not expect_size:
        return full, "cache-hit"
    if offline:
        return (full if os.path.exists(full) else None), "offline-missing"

    urls = mirror_urls(user, repo, branch, path)
    last = ""
    for t in range(tries):
        for u in urls:
            ok, msg = curl_fetch(u, full)
            size = os.path.getsize(full) if os.path.exists(full) else 0
            last = f"{u.split('/')[2]} {msg} size={size}"
            if ok and (expect_size is None or size >= expect_size):
                return full, f"ok {last}"
            if ok and expect_size and size < expect_size:
                continue  # 换个镜像续传
            log(f"    [retry] {last}")
            time.sleep(1)
    size = os.path.getsize(full) if os.path.exists(full) else 0
    return (full if size > 1000 else None), f"partial/FAIL {last}"


# ---------------------------------------------------------------- parsers
POS_RE = re.compile(r"^\s*([a-zA-Z]{1,6})\.\s*")


def norm_pos(tokens):
    got = []
    for t in tokens:
        t = (t or "").strip().lower().rstrip(".")
        t = POS_MAP.get(t, "")
        if t and t not in got:
            got.append(t)
    got.sort(key=lambda x: POS_ORDER.index(x) if x in POS_ORDER else 99)
    return "/".join(got)


def pos_from_translation(trans):
    """从 ECDICT translation 的 'vt. 放弃...' 前缀提取词性。"""
    toks = []
    for line in (trans or "").split("\n"):
        m = POS_RE.match(line)
        if m:
            toks.append(m.group(1))
    return norm_pos(toks)


def clean_cn(trans):
    if not trans:
        return ""
    t = trans.replace("\r", "")
    t = re.sub(r"\s*\n\s*", " ", t).strip()
    t = re.sub(r"\s{2,}", " ", t)
    return t


def wrap_ph(p):
    if not p:
        return ""
    p = p.strip()
    if not p:
        return ""
    if p.startswith("/") and p.endswith("/"):
        return p
    return "/" + p.strip("/") + "/"


def load_ecdict(path):
    """返回 {word: {...}} 只保留 tag 含 cet4/cet6 的行。"""
    res = {}
    with io.open(path, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            w = (row.get("word") or "").strip().lower()
            if not w or not re.fullmatch(r"[a-z][a-z\-'’ ]{0,40}", w):
                continue
            tags = set((row.get("tag") or "").split())
            if "cet4" not in tags and "cet6" not in tags:
                continue
            trans = clean_cn(row.get("translation"))
            res[w] = dict(
                w=w, ph=wrap_ph(row.get("phonetic")), cn=trans,
                pos=norm_pos([row.get("pos")]) or pos_from_translation(row.get("translation")),
                cet4="cet4" in tags, cet6="cet6" in tags, ex=[],
                src="ECDICT",
            )
    return res


def load_kajweb(zip_path):
    """解析扇贝格式 JSONL（每行一词）。返回 {word: entry}。"""
    res = {}
    with zipfile.ZipFile(zip_path) as zf:
        name = [n for n in zf.namelist() if n.lower().endswith(".json")][0]
        raw = zf.read(name).decode("utf-8", errors="replace")
    for line in raw.split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            o = json.loads(line)
        except Exception:
            continue
        wnode = o.get("content", {}).get("word", {})
        head = (wnode.get("wordHead") or o.get("headWord") or "").strip().lower()
        if not head:
            continue
        c = wnode.get("content", {}) or {}
        trans = c.get("trans") or []
        cn_parts, pos_toks = [], []
        for t in trans:
            cn = clean_cn(t.get("tranCn") or t.get("tranOther") or "")
            if cn:
                cn_parts.append(cn)
            pos_toks.append(t.get("pos") or "")
        sents = (c.get("sentence", {}) or {}).get("sentences") or []
        ex = []
        for s in sents[:2]:
            en = (s.get("sContent") or "").strip()
            cn = (s.get("sCn") or "").strip()
            if en:
                ex.append({"en": en, "cn": cn})
        ph = c.get("usphone") or c.get("ukphone") or c.get("phone") or ""
        res[head] = dict(
            w=head, ph=wrap_ph(ph), cn="；".join(cn_parts[:4]),
            pos=norm_pos(pos_toks), ex=ex, src="kajweb",
        )
    return res


def load_kylebing(path):
    """返回 {word: {cn, pos}}。同一 word 多条记录会合并（不覆盖，避免丢义项）。"""
    res = {}
    raw = json.load(io.open(path, encoding="utf-8"))
    for it in raw:
        w = (it.get("word") or "").strip().lower()
        if not w:
            continue
        trs = it.get("translations") or []
        cn = "；".join(clean_cn(t.get("translation")) for t in trs if t.get("translation"))
        toks = [t.get("type") for t in trs]
        cur = res.setdefault(w, dict(cn="", _pos=[]))
        if cn and cn not in cur["cn"]:
            cur["cn"] = (cur["cn"] + "；" + cn).strip("；")
        cur["_pos"].extend(toks)
    for v in res.values():
        v["pos"] = norm_pos(v.pop("_pos"))
    return res


# ---------------------------------------------------------------- merge
def merge(level, ec, kaj, kb, kaj_extra=None):
    """level: 'cet4'/'cet6'。ec=ECDICT全部词(已带标签)，kaj={w:entry}，kb={w:{cn,pos}}。"""
    words = set()
    for w, e in ec.items():
        if e[level]:
            words.add(w)
    words |= set(kb.keys())
    words |= set(kaj.keys())
    if kaj_extra:
        words |= set(kaj_extra.keys())

    out = []
    for w in sorted(words):
        e = ec.get(w)
        k = kaj.get(w) or (kaj_extra or {}).get(w) or {}
        b = kb.get(w) or {}
        cn = (e or {}).get("cn") or k.get("cn") or b.get("cn") or ""
        if not cn:
            continue
        pos = (e or {}).get("pos") or k.get("pos") or b.get("pos") or ""
        ph = k.get("ph") or (e or {}).get("ph") or ""
        ex = k.get("ex") or []
        srcs = []
        if e: srcs.append("ECDICT")
        if k: srcs.append("kajweb")
        if b: srcs.append("kylebing")
        out.append(dict(w=w, ph=ph, pos=pos, cn=clean_cn(cn), ex=ex, _src="+".join(srcs)))
    return out


def write_json(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    clean = [{k: r[k] for k in ("w", "ph", "pos", "cn", "ex")} for r in rows]
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(clean, f, ensure_ascii=False, indent=0)
    return clean


def ratio(rows, key):
    if not rows:
        return 0.0
    n = sum(1 for r in rows if r.get(key))
    if key == "ex":
        n = sum(1 for r in rows if r.get("ex"))
    return n / len(rows) * 100


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--stats", action="store_true")
    args = ap.parse_args()

    os.makedirs(CACHE, exist_ok=True)
    os.makedirs(OUT, exist_ok=True)

    if args.stats:
        for n in ("raw-cet4.json", "raw-cet6.json"):
            p = os.path.join(OUT, n)
            if os.path.exists(p):
                d = json.load(io.open(p, encoding="utf-8"))
                log(f"{n}: {len(d)} 条  音标 {ratio(d,'ph'):.1f}%  词性 {ratio(d,'pos'):.1f}%  "
                    f"例句 {ratio(d,'ex'):.1f}%")
        return

    failures = []

    # 1) ECDICT
    log("[1/4] ECDICT ...")
    ec_path, msg = ensure(ECDICT["user"], ECDICT["repo"], ECDICT["branch"], ECDICT["path"],
                          ECDICT["dest"], expect_size=ECDICT["size"], offline=args.offline)
    log("      ", msg)
    if not ec_path:
        failures.append("ECDICT ecdict.csv 下载失败 -> " + msg)
    ec = load_ecdict(ec_path) if ec_path else {}
    log(f"       ECDICT cet4/cet6 词条 = {len(ec)}")

    # 2) kajweb 词书
    log("[2/4] kajweb/dict 词书 zip ...")
    kaj4, kaj6 = {}, {}
    for fn in KAJWEB_FILES:
        p, msg = ensure("kajweb", "dict", "master", f"book/{fn}", fn, offline=args.offline)
        if not p:
            failures.append(f"kajweb {fn} -> {msg}")
            log(f"       FAIL {fn}: {msg}")
            continue
        try:
            d = load_kajweb(p)
            tgt = kaj4 if "CET4" in fn.upper() else kaj6
            before = len(tgt)
            for w, e in d.items():
                if w not in tgt or (not tgt[w]["ex"] and e["ex"]):
                    tgt[w] = e
            log(f"       {fn}: {len(d)} 词 (+{len(tgt)-before})")
        except Exception as ex:
            failures.append(f"kajweb {fn} 解析失败: {ex}")
    log(f"       kajweb 合并后 CET4={len(kaj4)} CET6={len(kaj6)}")

    # 3) KyleBing
    log("[3/4] KyleBing english-vocabulary ...")
    kb4, kb6 = {}, {}
    for src_name, dest in KYLEBING:
        p, msg = ensure("KyleBing", "english-vocabulary", "master", f"json/{src_name}", dest,
                        offline=args.offline)
        if not p:
            failures.append(f"KyleBing {src_name} -> {msg}")
            log(f"       FAIL {src_name}: {msg}")
            continue
        try:
            d = load_kylebing(p)
            (kb4 if "CET4" in src_name else kb6).update(d)
            log(f"       {src_name}: {len(d)} 词")
        except Exception as ex:
            failures.append(f"KyleBing {src_name} 解析失败: {ex}")

    # 4) 合并输出
    log("[4/4] 合并输出 ...")
    rows4 = merge("cet4", ec, kaj4, kb4)
    rows6 = merge("cet6", ec, kaj6, kb6)

    # 两表互补：同一个词在任一表里有例句/音标，另一方缺失就借用
    idx4, idx6 = {r["w"]: r for r in rows4}, {r["w"]: r for r in rows6}
    filled = 0
    for rows, other in ((rows4, idx6), (rows6, idx4)):
        for r in rows:
            o = other.get(r["w"])
            if not o:
                continue
            if not r["ex"] and o["ex"]:
                r["ex"] = o["ex"]
                filled += 1
            if not r["ph"] and o["ph"]:
                r["ph"] = o["ph"]
    log(f"       跨表互补例句 {filled} 条")

    write_json(os.path.join(OUT, "raw-cet4.json"), rows4)
    write_json(os.path.join(OUT, "raw-cet6.json"), rows6)

    for name, rows in (("CET4", rows4), ("CET6", rows6)):
        log(f"  raw-{name.lower()}.json : {len(rows)} 条 | 音标 {ratio(rows,'ph'):.1f}% | "
            f"词性 {ratio(rows,'pos'):.1f}% | 例句 {ratio(rows,'ex'):.1f}%")

    # 抽查
    probes = ["abandon", "maintain", "sufficient", "hypothesis", "controversial"]
    allw = {r["w"] for r in rows4} | {r["w"] for r in rows6}
    miss = [p for p in probes if p not in allw]
    log("  抽查:", "OK 全部命中" if not miss else f"缺失 {miss}")

    if failures:
        log("\n  !! 未完成的源:")
        for f in failures:
            log("    -", f)
    log("\nDONE")


if __name__ == "__main__":
    main()
