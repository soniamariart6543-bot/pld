/* 把 assets/js/data/cet4.js、cet6.js 里的词表 dump 成 JSON，方便脚本合并。
   用法：node tools/dict/dump_words.mjs */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', '..');
const dataDir = path.join(root, 'assets', 'js', 'data');
const outDir = path.join(here, 'out');
fs.mkdirSync(outDir, { recursive: true });

const sandbox = { window: {} };
vm.createContext(sandbox);
for (const f of ['cet4.js', 'cet6.js']) {
  vm.runInContext(fs.readFileSync(path.join(dataDir, f), 'utf8'), sandbox, { filename: f });
}

for (const [key, name] of [['CET4_WORDS', 'cur-cet4.json'], ['CET6_WORDS', 'cur-cet6.json']]) {
  const arr = sandbox.window[key] || [];
  fs.writeFileSync(path.join(outDir, name), JSON.stringify(arr, null, 0), 'utf8');
  console.log(`${key}: ${arr.length} 条 -> out/${name}`);
}
