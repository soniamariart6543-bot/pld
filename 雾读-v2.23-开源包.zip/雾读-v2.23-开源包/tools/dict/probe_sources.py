#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""探测可用的 CET 词表数据源（只读，不落盘）。"""
import json
import sys
import time
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

URLS = {
    "qwerty-CET4": "https://raw.githubusercontent.com/Kaiyiwing/qwerty-learner/master/public/dicts/CET4_1.json",
    "qwerty-CET6": "https://raw.githubusercontent.com/Kaiyiwing/qwerty-learner/master/public/dicts/CET6_1.json",
    "kajweb-CET4": "https://raw.githubusercontent.com/kajweb/dict/master/CET4luan_1.json",
    "kajweb-CET6": "https://raw.githubusercontent.com/kajweb/dict/master/CET6_1.json",
}

for k, u in URLS.items():
    t = time.time()
    try:
        req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = r.read()
        print("%-12s OK   %8.1f KB   %.1fs" % (k, len(data) / 1024, time.time() - t))
        try:
            j = json.loads(data.decode("utf-8"))
            print("             条数=%d | 首条字段=%s" % (len(j), list(j[0].keys())[:10]))
            s = json.dumps(j[0], ensure_ascii=False)
            print("             样例=%s" % s[:260])
        except Exception as e:
            print("             非 JSON: %s | head=%r" % (e, data[:100]))
    except Exception as e:
        print("%-12s FAIL %s" % (k, e))
