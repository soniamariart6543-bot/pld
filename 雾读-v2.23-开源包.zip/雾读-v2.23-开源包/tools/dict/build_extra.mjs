#!/usr/bin/env node
/**
 * 雾读 · P0-1 内容补齐（第一批：用法说明模板 + 语料搭配抽取）
 * ---------------------------------------------------------------
 * 口径（见 docs/功能对照与优化清单.md §3.5 P0-1）：
 *   ⚠ 搭配抽检结论（2026-09-25 实测）：无词性标注的窗口共现+LLR，13 条里只有约 6 条正确（46%），
 *     低于清单定的 85% 合格线 → **本批默认不发布搭配**，只发布用法说明；搭配留待句法分析方案。
 *   · note（用法说明）→ 模板优先，零生成风险
 *   · colloc（搭配）  → 本地统计抽取，窗口 ±4，最少共现 5，LLR ≥ 10.83
 *   · 语料 = 词库自带例句（约 10–15 万词）＋ 可选外部语料文件（tools/dict/corpus/*.txt）
 *   · 不引入 Tatoeba、不抓商业词典；产出带 license 字段
 *
 * 用法：
 *   node tools/dict/build_extra.mjs              # 全量
 *   node tools/dict/build_extra.mjs --limit 300  # 只做前 300 个待补词（抽检用）
 *   node tools/dict/build_extra.mjs --max-freq 3 # 只做 freq>=3 的（第一批 2070 词）
 */
import fs from 'fs';
import path from 'path';
import vm from 'vm';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..');
const OUT_DIR = path.join(ROOT, 'tools', 'dict', 'out');
const CORPUS_DIR = path.join(ROOT, 'tools', 'dict', 'corpus');
const DATA_DIR = path.join(ROOT, 'assets', 'js', 'data');

const argv = process.argv.slice(2);
function argNum(name, dft) {
  const i = argv.indexOf(name);
  if (i < 0) return dft;
  const v = parseInt(argv[i + 1], 10);
  return Number.isFinite(v) ? v : dft;
}
const LIMIT = argNum('--limit', 0);
const MIN_FREQ = argNum('--min-freq', 0);
const WITH_COLLOC = argv.indexOf('--with-colloc') >= 0;
const OUT_NAME = (() => {
  const i = argv.indexOf('--out');
  return i >= 0 && argv[i + 1] ? argv[i + 1] : 'extra-01.js';
})();

/* ---------------- 1. 载入词库 ---------------- */
function loadBank(file, key) {
  const src = fs.readFileSync(path.join(DATA_DIR, file), 'utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(src, sandbox);
  const arr = sandbox.window[key];
  if (!Array.isArray(arr)) throw new Error(file + ' 里没有 ' + key);
  return arr;
}
const cet4 = loadBank('cet4.js', 'CET4_WORDS');
const cet6 = loadBank('cet6.js', 'CET6_WORDS');
const all = cet4.concat(cet6);
console.log(`载入词库：CET4 ${cet4.length} + CET6 ${cet6.length} = ${all.length}`);

/* ---------------- 2. 语料 ---------------- */
// 自带例句全量入语料；另外收 tools/dict/corpus/*.txt（公版书等，可选）
const corpusTokens = [];
function feed(text) {
  const toks = String(text || '')
    .toLowerCase()
    .replace(/[^a-z'\- ]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  for (const t of toks) corpusTokens.push(t);
}
let exCount = 0;
for (const w of all) {
  (w.ex || []).forEach((e) => { feed(e.en); exCount++; });
}
let extFiles = 0;
if (fs.existsSync(CORPUS_DIR)) {
  for (const f of fs.readdirSync(CORPUS_DIR)) {
    if (!/\.(txt|text)$/i.test(f)) continue;
    feed(fs.readFileSync(path.join(CORPUS_DIR, f), 'utf8'));
    extFiles++;
  }
}
const corpusSize = corpusTokens.length;
console.log(`语料：例句 ${exCount} 条（${corpusSize} token）＋ 外部语料 ${extFiles} 个文件`);
if (corpusSize < 100000) {
  console.log(`⚠ 语料偏小（${corpusSize} token < 100k）——搭配只能覆盖最高频的词，属预期行为`);
}

/* ---------------- 3. 共现统计（窗口 ±4） ---------------- */
const STOP = new Set(('the a an and or but if of to in on at by for with from as is are was were be been being ' +
  'this that these those it its he she they them his her their we you your i me my our not no do does did ' +
  'have has had will would can could may might must shall should there here when where which who whom whose ' +
  'than then so such very more most much many some any all both each other another one two three').split(/\s+/));

const POS_PREP = new Set(['of', 'in', 'on', 'at', 'by', 'for', 'with', 'from', 'to', 'into', 'upon', 'about', 'against', 'among', 'between', 'through', 'without', 'within', 'toward', 'towards', 'over', 'under', 'after', 'before', 'during', 'beyond', 'despite', 'except', 'besides']);
const POS_ADV = new Set(['up', 'down', 'out', 'off', 'away', 'back', 'forward', 'apart', 'together', 'aside', 'ahead']);

// 全语料词频（LLR 的 2×2 列联表必须用真实频次，否则虚词会冲上来）
const freq = new Map();
for (let i = 0; i < corpusSize; i++) {
  const t = corpusTokens[i];
  freq.set(t, (freq.get(t) || 0) + 1);
}
// 记录每个词的左右窗口 token（只对需要统计的词建索引，省内存）
const AUX = new Set(['should','would','could','can','may','might','must','will','shall','do','does','did','have','has','had','be','is','are','was','were','been','being','get','got']);
const need = new Set();
for (const w of all) {
  const k0 = String(w.w).toLowerCase();
  if ((!w.colloc || !w.colloc.length) && !AUX.has(k0)) need.add(k0);
}
const co = new Map();  // head -> Map(partner -> count)
const headTotal = new Map();
const WORD_SET = new Set(all.map((w) => String(w.w).toLowerCase()));

for (let i = 0; i < corpusSize; i++) {
  const t = corpusTokens[i];
  if (!need.has(t)) continue;
  headTotal.set(t, (headTotal.get(t) || 0) + 1);
  let m = co.get(t);
  if (!m) { m = new Map(); co.set(t, m); }
  const lo = Math.max(0, i - 4), hi = Math.min(corpusSize - 1, i + 4);
  for (let j = lo; j <= hi; j++) {
    if (j === i) continue;
    const p = corpusTokens[j];
    if (!p || p === t || STOP.has(p)) continue;
    if (p.length < 2) continue;
    m.set(p, (m.get(p) || 0) + 1);
  }
}

// LLR（2x2 列联表，Dunning）
function llr(k11, k12, k21, k22) {
  const n = k11 + k12 + k21 + k22;
  if (!n) return 0;
  const f = (k, kr, kc) => {
    if (k <= 0) return 0;
    const e = (kr * kc) / n;
    return k * Math.log(k / e);
  };
  const r1 = k11 + k12, r2 = k21 + k22, c1 = k11 + k21, c2 = k12 + k22;
  return 2 * (f(k11, r1, c1) + f(k12, r1, c2) + f(k21, r2, c1) + f(k22, r2, c2));
}

const MIN_CO = 3, MIN_LLR = 10.83, MAX_OUT = 3;
function collocOf(head, allowColloc) {
  if (!allowColloc) return [];
  const m = co.get(head);
  if (!m) return [];
  const total = headTotal.get(head) || 0;
  if (total < MIN_CO) return [];
  const rows = [];
  for (const [p, k] of m) {
    if (k < MIN_CO) continue;
    const fp = freq.get(p) || 0;
    // 标准 2×2：k11 共现 / k12 头词出现但 p 不在窗口 / k21 p 出现但头词不在窗口 / k22 其余
    const k11 = k, k12 = total - k, k21 = Math.max(0, fp - k);
    const k22 = Math.max(0, corpusSize - k11 - k12 - k21);
    const score = llr(k11, k12, k21, k22);
    if (score < MIN_LLR) continue;
    const type = POS_PREP.has(p) ? 'prep' : POS_ADV.has(p) ? 'adv' : 'word';
    // ⚠ 只保留「介词 / 副词」搭配。
    // 实测（2026-09-25）：无词性标注的窗口共现 + LLR 会把偶然高频共现当成搭配
    // （abide agree / array outdated / alternate include 这种），错得比「没有」更糟。
    // 介词/副词搭配在语言学上只需共现即可靠（depend on、give up），因此只收这一类；
    // 实词搭配（如 heavy rain）需要句法分析，本轮不做。
    if (type === 'word') continue;
    rows.push({ p, k, score, type });
  }
  rows.sort((a, b) => b.score - a.score);
  // 介词 / 副词搭配优先（可考性最高），再补实词搭配；同一头词最多 3 条
  const prep = rows.filter((r) => r.type !== 'word');
  const wordy = rows.filter((r) => r.type === 'word');
  return prep.concat(wordy).slice(0, MAX_OUT)
    .map((r) => ({ phrase: r.p, n: r.k, score: Math.round(r.score * 10) / 10 }));
}

/* ---------------- 4. 用法说明模板 ---------------- */
// 按词性 + 是否及物 + 高频搭配套模板（清单口径：模板零错误，好过小模型的「机械但可能错」）
// ⚠ 判定顺序有讲究：不能写 p.includes('v') —— 'adv' 里也含 v，会把副词误判成动词
function posOf(w) {
  const p = String(w.pos || '').toLowerCase().trim();
  if (!p) return '';
  if (p.indexOf('adv') === 0 || /\badv\b|adverb/.test(p)) return 'adv';
  if (p.indexOf('adj') === 0 || /\badj\b|adjective/.test(p)) return 'adj';
  if (p.indexOf('prep') === 0 || /\bprep\b|preposition/.test(p)) return 'prep';
  if (p.indexOf('conj') === 0 || /\bconj\b|conjunction/.test(p)) return 'conj';
  if (p.indexOf('pron') === 0 || /\bpron\b|pronoun/.test(p)) return 'pron';
  if (/\bv\b|\bvt\b|\bvi\b|verb/.test(p) || p.indexOf('v') === 0) return 'v';
  if (/\bn\b|noun/.test(p) || p.indexOf('n') === 0) return 'n';
  return '';
}
const IRREG_PAST = /(^|,)\s*(?:v|vt|vi)\b/;

function noteOf(w, collocs) {
  const pos = posOf(w);
  const cn = String(w.cn || '').split(/[；;，,]/)[0].trim();
  const preps = collocs.filter((c) => POS_PREP.has(c.phrase)).map((c) => c.phrase);
  const advs = collocs.filter((c) => POS_ADV.has(c.phrase)).map((c) => c.phrase);
  const bits = [];
  if (pos === 'v') {
    bits.push(`动词，常用义「${cn}」`);
    if (preps.length) bits.push(`常与介词 ${preps.map((p) => '**' + p + '**').join(' / ')} 连用，注意搭配固定，不要按中文直译换介词`);
    else bits.push('及物用法直接跟宾语；不及物时注意是否需要补介词');
    if (advs.length) bits.push(`常见副词搭配：${advs.map((a) => '**' + a + '**').join(' / ')}`);
  } else if (pos === 'adj') {
    bits.push(`形容词，常用义「${cn}」`);
    if (preps.length) bits.push(`作表语时常接 ${preps.map((p) => '**' + p + '**').join(' / ')}（如 be ~ ' + preps[0] + '）`);
    else bits.push('可作定语或表语；作表语时后面接的介词要按固定搭配记');
  } else if (pos === 'n') {
    bits.push(`名词，常用义「${cn}」`);
    bits.push('注意可数性：写作时先判断能否加 a/an 与复数，抽象名词多用不可数形式');
    if (preps.length) bits.push(`常见介词搭配：${preps.map((p) => '**' + p + '**').join(' / ')}`);
  } else if (pos === 'adv') {
    bits.push(`副词，常用义「${cn}」；位置一般在实义动词之后、形容词之前`);
  } else if (pos === 'prep') {
    bits.push(`介词，常用义「${cn}」；后面必须接名词或动名词，不能直接跟句子`);
  } else if (pos === 'conj') {
    bits.push(`连词，常用义「${cn}」；注意连接的两部分必须结构对称`);
  } else {
    bits.push(`常用义「${cn}」`);
    bits.push('注意词性在不同句子里可能变化，判断时先看它在句中作什么成分');
  }
  return bits.join('；') + '。';
}

/* ---------------- 5. 生成 ---------------- */
let todo = all.filter((w) => (!w.colloc || !w.colloc.length) && (!w.note || !String(w.note).trim()));
if (MIN_FREQ) todo = todo.filter((w) => (w.freq || 1) >= MIN_FREQ);
todo.sort((a, b) => (b.freq || 1) - (a.freq || 1));
if (LIMIT > 0) todo = todo.slice(0, LIMIT);
console.log(`待补词条：${todo.length}（freq≥${MIN_FREQ || 1}${LIMIT ? '，取前 ' + LIMIT : ''}）`);

const bag = {};
let withColloc = 0, withNote = 0;
for (const w of todo) {
  const key = String(w.w).toLowerCase();
  const pos0 = posOf(w);
  // 搭配方案本轮不发布（见文件头注释）；加 --with-colloc 才输出，供后续调优验证
  const collocs = WITH_COLLOC ? collocOf(key, pos0 === 'v') : [];
  const rec = {};
  if (collocs.length) { rec.colloc = collocs.map((c) => ({ phrase: key + ' ' + c.phrase, n: c.n, score: c.score })); withColloc++; }
  const note = noteOf(w, collocs);
  if (note) { rec.note = note; withNote++; }
  rec.license = 'generated:template+local-stat; corpus=self-examples';
  bag[key] = rec;
}
console.log(`生成：搭配 ${withColloc} 条 / 用法说明 ${withNote} 条`);

const header = `/* 雾读 · 内容补齐批次（自动生成，勿手改）
 * 生成脚本：tools/dict/build_extra.mjs
 * 来源：用法说明＝词性模板（零生成风险）；搭配＝词库自带例句本地统计（窗口 ±4，共现≥5，LLR≥${MIN_LLR}）
 * 许可：仅用自有例句统计，无第三方词典内容
 * 词条数：${Object.keys(bag).length}
 */
`;
const lines = [header, 'window.EXTRA_NOTES = window.EXTRA_NOTES || {};', 'Object.assign(window.EXTRA_NOTES, {'];
const keys = Object.keys(bag);
keys.forEach((k, i) => {
  lines.push('  ' + JSON.stringify(k) + ': ' + JSON.stringify(bag[k]) + (i === keys.length - 1 ? '' : ','));
});
lines.push('});', '');
const outPath = path.join(DATA_DIR, OUT_NAME);
fs.writeFileSync(outPath, lines.join('\n'), 'utf8');
const st = fs.statSync(outPath);
console.log(`已写出 ${outPath}（${(st.size / 1024).toFixed(1)} KB）`);
