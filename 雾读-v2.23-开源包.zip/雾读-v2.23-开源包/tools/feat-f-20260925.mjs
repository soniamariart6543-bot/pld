/* 雾读 · 批次 F：P1-10 无障碍 aria 全量（静态层）
 * 背景：清单实测「index.html 仅 1 个 aria-*、1 个 role，而按钮有 71 个」。
 *       app.js 里的 applyA11y() 只是运行时兜底（照抄可见文本），图标按钮与
 *       开关类按钮语义仍含糊，且静态审计看不见。
 * 本脚本只做**静态层**：按钮 / 输入框 / 导航 / 翻页 tab / 视图区补语义。
 * 动态节点（选项、词表、字母槽）由 app.js 的 applyA11y 负责 —— 见同批改动。
 * 幂等：已存在 aria-label 的元素跳过；重复运行不会叠加。
 * 用法：node tools/feat-f-20260925.mjs [--dry]
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const HTML = path.join(ROOT, 'index.html');
const DRY = process.argv.includes('--dry');

/* ---------- 语义表：按「特征」给按钮定名，不照抄可见文本 ---------- */
const VIEW_LABEL = {
  home: '开学', dict: '词典', quiz: '默写', real: '真题', listening: '听力',
  grammar: '语法', translate: '翻译', write: '写作', focus: '专注',
  wrong: '错题本', plan: '计划', report: '学习报告', settings: '设置'
};
const DIR_LABEL = {
  cn2en: '打字填写', en2cn: '四选一认词', listen: '听音拼写',
  mix: '混合随机', excloze: '例句填空', exlisten: '例句听写'
};
const TASK_LABEL = {
  'quiz-cn2en': '默写 · 打字填写', 'quiz-en2cn': '认词 · 四选一',
  grammar: '语法专项', real: '真题训练', translate: '翻译训练', write: '写作训练'
};
/* id → aria-label（覆盖全部带可见文本但语义可以更准的按钮） */
const ID_LABEL = {
  ckBtn: '今日打卡',
  dictSearchBtn: '搜索单词',
  quizBack1: '返回作答方式选择',
  quizStart: '开始默写',
  quizSetupBack: '返回默写设置',
  quizQuit: '结束本轮默写',
  focusBack1: '返回专注内容选择',
  focusStart: '开始专注',
  wrongQBtn: '搜索错题',
  wrongClear: '把已掌握的词移出错题本',
  wrongPrint: '打印手写复习单',
  wrongBack1: '返回错题本总览',
  wrongQ2Clear: '清空这一类里的搜索',
  wrongPractice: '复习这一类错题',
  wrongBack2: '返回错题列表',
  planReset: '计划恢复默认',
  planGen: '生成训练计划',
  setSave: '保存计划设置',
  setReset: '设置恢复默认',
  ttsBtn: '朗读开关',
  buzzBtn: '震动开关',
  setVoice: '发音口音（美音 / 英音）切换',
  setHard: '专注强硬模式开关',
  remindBtn: '每日提醒开关',
  themeBtn: '切换夜间 / 日间主题',
  setExport: '导出全部数据备份',
  setWrongCsv: '导出错词本 CSV',
  setImport: '选择要导入的备份文件',
  setCopyPack: '复制打包数据',
  setPasteImport: '粘贴导入数据',
  setWipe: '清空全部数据',
  breakSkip: '长按三秒跳过休息',
  fbPause: '暂停专注',
  fbStop: '结束专注'
};
/* 开关类按钮：状态由 JS 用 aria-pressed 同步（文本会变，label 保持稳定） */
const TOGGLE_IDS = new Set(['ttsBtn', 'buzzBtn', 'setVoice', 'setHard', 'remindBtn', 'themeBtn']);

function attr(tag, name) {
  const m = tag.match(new RegExp('\\s' + name + '="([^"]*)"'));
  return m ? m[1] : '';
}
function labelFor(tag, inner) {
  const id = attr(tag, 'id');
  if (id && ID_LABEL[id]) return ID_LABEL[id];
  const dv = attr(tag, 'data-view');
  if (dv && VIEW_LABEL[dv]) return '切换到' + VIEW_LABEL[dv];
  const dg = attr(tag, 'data-go');
  if (dg && VIEW_LABEL[dg]) return '打开' + VIEW_LABEL[dg];
  const dir = attr(tag, 'data-dir');
  if (dir && DIR_LABEL[dir]) return '作答方式：' + DIR_LABEL[dir];
  const task = attr(tag, 'data-task');
  if (task && TASK_LABEL[task]) return '专注内容：' + TASK_LABEL[task];
  // 翻页 tab 由 tablist 单独处理
  const text = inner.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  return text ? text.slice(0, 40) : '按钮';
}

let html = fs.readFileSync(HTML, 'utf8');
const before = {
  aria: (html.match(/aria-/g) || []).length,
  role: (html.match(/\brole=/g) || []).length,
  btn: (html.match(/<button\b/g) || []).length
};

/* 1) 按钮：<button ...> 内联文本 </button> */
let btnAdd = 0;
html = html.replace(/<button\b([^>]*)>([\s\S]*?)<\/button>/g, (full, tagAttr, inner) => {
  if (/\saria-label=/.test(tagAttr)) return full;
  if (/\sclass="[^"]*\bpg-tab\b/.test(tagAttr)) return full;   // 2) 里补
  const label = labelFor(tagAttr, inner);
  const id = attr(tagAttr, 'id');
  const extra = (id && TOGGLE_IDS.has(id)) ? ' aria-pressed="false"' : '';
  btnAdd++;
  return '<button' + tagAttr + ' aria-label="' + label.replace(/"/g, '&quot;') + '"' + extra + '>' + inner + '</button>';
});

/* 2) 翻页 tab：容器 tablist，按钮 tab + aria-selected */
let tabAdd = 0;
html = html.replace(/<div class="pg-bar"([^>]*)>([\s\S]*?)<\/div>/g, (full, barAttr, inner) => {
  const barLabel = (attr(barAttr, 'id') === 'homeTabs') ? '开学页分页' :
    (attr(barAttr, 'id') === 'setTabs') ? '设置页分页' : '页面分页';
  const newInner = inner.replace(/<button class="pg-tab([^"]*)"([^>]*)>([\s\S]*?)<\/button>/g,
    (bFull, cls, bAttr, txt) => {
      // 幂等：已经补过 role 的 tab 原样返回（漏了这句会让每次重跑都翻倍加 aria）
      if (/\brole=/.test(bAttr)) return bFull;
      const on = /\bon\b/.test(cls);
      tabAdd++;
      return '<button class="pg-tab' + cls + '"' + bAttr + ' role="tab" aria-selected="' + (on ? 'true' : 'false') +
        '" aria-label="查看' + txt.trim() + '">' + txt + '</button>';
    });
  const newAttr = /role=/.test(barAttr) ? barAttr : barAttr + ' role="tablist" aria-label="' + barLabel + '"';
  return '<div class="pg-bar"' + newAttr + '>' + newInner + '</div>';
});

/* 3) 翻页面板：tabpanel */
html = html.replace(/<div class="pg-panel([^"]*)"([^>]*)>/g, (full, cls, rest) => {
  if (/role=/.test(rest)) return full;
  return '<div class="pg-panel' + cls + '"' + rest + ' role="tabpanel">';
});

/* 4) 侧栏导航 */
html = html.replace(/<nav class="nav" id="nav">/, '<nav class="nav" id="nav" aria-label="主导航">');

/* 5) 视图区：region + 名称 */
html = html.replace(/<section class="view([^"]*)" id="view-([a-z]+)">/g, (full, cls, key) => {
  const name = VIEW_LABEL[key] || key;
  return '<section class="view' + cls + '" id="view-' + key + '" role="region" aria-label="' + name + '">';
});

/* 6) 输入控件：label 优先取同行的 .set-label 文本，其次 placeholder / 语义表 */
const INPUT_LABEL = {
  dictSearch: '搜索单词或中文释义', quizDir: '作答方向', quizScope: '默写词库范围',
  quizCount: '本轮题量', focusMinutes: '专注时长', focusHide: '专注时隐藏内容',
  focusBreak: '专注休息时长', focusFull: '全屏方式', focusGoal: '每日专注目标（分钟）',
  wrongQ: '搜索错题', wrongQ2: '在这一类里搜索', planLevel: '考试级别', planDate: '考试日期',
  planMinutes: '每日可投入分钟', planRest: '每周休息天数', setLevel: '考试级别',
  setDate: '考试日期', setMinutes: '每日可投入分钟', setRest: '每周休息天数',
  setMaxReview: '每日复习上限', ttsRate: '朗读语速', remindAt: '每日提醒时间',
  setImportFile: '选择备份文件'
};
let inputAdd = 0;
html = html.replace(/<(input|select|textarea)\b([^>]*)>/g, (full, tag, rest) => {
  if (/aria-label=|type="hidden"/.test(rest)) return full;
  const id = attr(rest, 'id');
  const ph = attr(rest, 'placeholder');
  const label = INPUT_LABEL[id] || ph || '输入框';
  inputAdd++;
  return '<' + tag + rest + ' aria-label="' + label.replace(/"/g, '&quot;') + '">';
});

/* 7) 进度条 / 状态条冗余语义（静态可见的那几根） */
html = html.replace(/<div class="bar"([^>]*)>/g, (full, rest) =>
  /role=/.test(rest) ? full : '<div class="bar"' + rest + ' role="progressbar" aria-label="进度">');

const after = {
  aria: (html.match(/aria-/g) || []).length,
  role: (html.match(/\brole=/g) || []).length,
  btn: (html.match(/<button\b/g) || []).length
};

console.log('按钮补语义      ', btnAdd);
console.log('翻页 tab 补语义 ', tabAdd);
console.log('输入控件补语义  ', inputAdd);
console.log('aria-* :', before.aria, '→', after.aria);
console.log('role=  :', before.role, '→', after.role);
console.log('按钮总数 :', after.btn);

if (DRY) { console.log('（--dry：未写盘）'); process.exit(0); }
fs.writeFileSync(HTML, html, 'utf8');
console.log('已写回', path.relative(ROOT, HTML));
