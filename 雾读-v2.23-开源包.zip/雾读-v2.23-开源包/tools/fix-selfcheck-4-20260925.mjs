/* 雾读 · 按《代码自检报告》修第四批（G1–G4 / N1–N4 / B2 补充）
   用法：node tools/fix-selfcheck-4-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

/* G4 进度分母漂移：回炉会把 queue 撑大，分母改用「原定题量」 */
P('G4 进度分母固定为计划题量',
`    $('#quizProgress').textContent = (q.pos + 1) + ' / ' + q.queue.length;`,
`    // 自检 G4：答错回炉会把 queue 撑大 —— 分母必须锁定「本轮计划题量」，否则第 1 题答错就变成 3 / 22
    var doneN = Math.min(q.answered || 0, q.planned || q.queue.length);
    var totalN = q.planned || q.queue.length;
    $('#quizProgress').textContent = doneN + ' / ' + totalN;`);

P('G4 进度条同口径',
`    $('#quizBar').style.width = ((q.pos + 1) / q.queue.length * 100) + '%';
    saveQuizSession();   // 断点续学：每答一题就把进度落盘（P0-9）`,
`    $('#quizBar').style.width = Math.min(100, (doneN / totalN * 100)) + '%';
    saveQuizSession();   // 断点续学：每答一题就把进度落盘（P0-9）`);

P('G4 finish 里累计已答数',
`    var q = quiz, item = q.queue[q.pos];
    if (correct) q.right++; else q.wrong++;`,
`    var q = quiz, item = q.queue[q.pos];
    q.answered = (q.answered || 0) + 1;   // 自检 G4：进度分子（与 planned 配套）
    if (correct) q.right++; else q.wrong++;`);

P('G4 结算页口径说明',
`    var total = q.right + q.wrong;
    var rate = total ? Math.round(q.right / total * 100) : 0;`,
`    var total = q.right + q.wrong;
    var rate = total ? Math.round(q.right / total * 100) : 0;
    var plannedN = q.planned || total;
    var requeued = Math.max(0, total - plannedN);   // 自检 G4：多出来的是错题回炉，明说比让用户困惑好`);

P('G4 结算文案带计划题量',
`      '<div class="muted small" style="margin-top:6px">共 ' + total + ' 题 · 答对 ' + q.right + ' · 答错 ' + q.wrong + '</div>' +`,
`      '<div class="muted small" style="margin-top:6px">本轮 ' + plannedN + ' 题' +
        (requeued ? '（含错题回炉 ' + requeued + ' 次）' : '') +
        ' · 答对 ' + q.right + ' · 答错 ' + q.wrong + '</div>' +`);

/* G2 结果页「回到设置」后沉浸态残留：侧栏一直隐藏 */
P('G2 回设置时退出沉浸态',
`    $('#quizBack').onclick = function () {
      $('#quizResult').style.display = 'none';
      $('#quizSetup').style.display = 'block';
    };`,
`    $('#quizBack').onclick = function () {
      $('#quizResult').style.display = 'none';
      $('#quizSetup').style.display = 'block';
      document.body.classList.remove('quizzing');   // 自检 G2：不回退沉浸态会让侧栏/底栏一直藏着，像页面坏了
    };`);

/* G1 休息段没有自己的记录 + G3 休息遮罩状态漂移 */
P('G1 休息段也记账',
`  // 结束休息（natural=true 表示自然到点）
  function skipBreak(natural) {
    var f = focusState;
    if (!f.on || f.phase !== 'break') return;
    f.phase = 'work';`,
`  // 结束休息（natural=true 表示自然到点）
  function skipBreak(natural) {
    var f = focusState;
    if (!f.on || f.phase !== 'break') return;
    // 自检 G1：休息段原来完全不记账，于是「休息 5 分钟」在专注记录里凭空消失；
    // 这里补一条 phase='break' 的记录（completed 按是否自然到点），并重设基线
    try {
      if ((f.total - f.left) >= 30) logSession(f, !!natural);
    } catch (e) {}
    f.phase = 'work';`);

P('G3 休息遮罩状态同步',
`  function focusTick() {
    var f = focusState;
    if (!f.on || f.paused) return;
    f.left--;`,
`  // 自检 G3：休息遮罩（body.on-break）必须与 phase 严格一致 —— 任何路径漏加/漏删都会出现「计时条在动、锁屏没了」
  function syncBreakMask() {
    var f = focusState;
    var should = !!(f && f.on && f.phase === 'break');
    document.body.classList.toggle('on-break', should);
    if (!should && $('#breakMask')) { try { document.body.classList.remove('on-break'); } catch (e) {} }
  }

  function focusTick() {
    var f = focusState;
    if (!f.on || f.paused) { syncBreakMask(); return; }
    f.left--;
    syncBreakMask();`);

/* B2 补充：词库为空时不该打开硬门（否则一张空白遮罩，既不能答也不能退） */
P('B2 硬门空词护栏',
`  function openHardGate() {`,
`  function openHardGate() {
    // 自检 B2：词库为空时 pickHardWords 返回空数组 → 弹层里什么都没有，用户被卡死
    if (!WORDS.length) { toast('词库还没加载好，稍后再试'); return; }`);

/* N1 单字母词提示重复首尾 */
P('N1/N2 提示按位对齐',
`  function hintOf(word, level) {
    if (level === 0) return word[0] + ' ' + '_ '.repeat(word.length - 1);
    if (level === 1) return word.slice(0, Math.ceil(word.length / 2)) + ' ' + '_ '.repeat(word.length - Math.ceil(word.length / 2));
    return word[0] + ' ' + word.slice(1, -1).replace(/[a-z]/g, '_') + ' ' + word[word.length - 1];
  }`,
`  // 提示：返回与单词**等长**的串，'_' 表示未揭示。
  // 自检 N1/N2：旧版用空格占位，调用方还要 replace(/\\s+/g,'') 去掉 —— 一是单字母词会输出 "a  a"，
  // 二是去掉空格后索引整体错位（self-made 会少揭示一个字母）。
  function hintOf(word, level) {
    var w = String(word || ''), n = w.length, out = [];
    for (var i = 0; i < n; i++) out.push('_');
    if (!n) return '';
    if (n === 1) { out[0] = w[0]; return out.join(''); }        // 单字母词：直接给出来，不重复首尾
    if (level <= 0) { out[0] = w[0]; }
    else if (level === 1) { var k = Math.ceil(n / 2); for (var j = 0; j < k; j++) out[j] = w[j]; }
    else { out[0] = w[0]; out[n - 1] = w[n - 1]; }
    return out.join('');
  }`);

P('N1/N2 调用方不再去空格',
`        var hint = hintOf(w.w, hintLevel).replace(/\\s+/g, '');     // 'p_____'`,
`        var hint = hintOf(w.w, hintLevel);     // 与单词等长：'_' = 未揭示（自检 N2）`);

P('N4 提示到头别再承诺更多',
`        toast('提示已填进横线 · 再点一次给更多');`,
`        // 自检 N4：hintLevel 封顶 2，到头了就别再承诺「再点给更多」
        toast(hintLevel >= 2 ? '提示已给到头（首字母与末字母）' : '提示已填进横线 · 再点一次给更多');`);

/* N3 超长输入静默截断：限定输入长度，避免「看着都填对了却判错」 */
P('N3 输入长度上限',
`        '<input class="spell-input" id="quizInput" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done">' +`,
`        '<input class="spell-input" id="quizInput" maxlength="' + (w.w.length + 2) + '" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done">' +`);

const bak = APP + '.bak-fix4-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1），跳过'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
