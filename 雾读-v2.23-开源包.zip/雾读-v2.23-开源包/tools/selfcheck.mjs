#!/usr/bin/env node
/* 雾读 · 静态自检器（tools/selfcheck.mjs）
 *
 * 目的：在人工逐个点测之前，先把「机器一眼能看出」的问题全部揪出来。
 * 覆盖：① HTML 标签配对 ② 重复 id ③ 悬空 DOM 引用（$('#x') 指向不存在的元素）
 *      ④ 重复函数定义 ⑤ 调用了但未定义的本地函数 ⑥ 引用了不存在的 window 全局
 *      ⑦ 用了但 CSS 里没定义的 class ⑧ script 加载顺序
 *
 * 用法：node tools/selfcheck.mjs        （在项目根目录执行）
 * 只读：不修改任何文件。
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const read = (p) => { try { return fs.readFileSync(path.join(ROOT, p), 'utf8'); } catch { return null; } };

const html = read('index.html');
const keepLines = (s) => s.replace(/[^\n]/g, '');   // 保留换行，保证行号保真
/* app.js 也要先剥注释：注释里的示例代码（如 .pg-bar(…)）会被误当成函数调用 */
const app = (read('assets/js/app.js') || '')
  .replace(/\/\*[\s\S]*?\*\//g, keepLines)
  .replace(/(^|[^:'"\\])\/\/[^\n]*/g, (mm, p1) => p1 + keepLines(mm.slice(p1.length)));
const css = read('assets/css/style.css');
const native = read('assets/js/native.js');
if (!html || !app) { console.error('找不到 index.html 或 assets/js/app.js（请在项目根目录运行）'); process.exit(1); }

const out = [];
const add = (level, title, detail) => out.push({ level, title, detail });

/* ---------- 0) 预处理：剥掉注释与脚本内容 ----------
 * 关键：HTML 注释里可能出现 </div> 字样（例如记录历史修复的说明注释），
 * 直接计数会把注释里的标签也算进去 → 误报。必须先剥离。 */
const htmlRaw = html;
const htmlClean = htmlRaw
  .replace(/<!--[\s\S]*?-->/g, keepLines)                                  // 注释（可能含 </div> 字样）
  .replace(/<script[\s\S]*?<\/script>/gi, keepLines)                       // 脚本内容
  .replace(/<style[\s\S]*?<\/style>/gi, keepLines)
  /* favicon 用了 data:image/svg+xml 内嵌 <svg>，属性值里的 <> 会干扰标签扫描 → 先剥掉这些 void 元素。
     分级处理：link 的 data URI 内含 >，必须整行贪婪；img/meta 属性里不会有 >，用精确匹配
     （img 常与 </div> 同行，整行贪婪会把后面的 </div> 一起吃掉 → 造成假的「少一个闭合」）。 */
  .replace(/<link\b[^\n]*>/gi, keepLines)
  .replace(/<meta\b[^>]*>/gi, keepLines)
  .replace(/<img\b[^>]*>/gi, keepLines);

/* ---------- ① HTML 标签配对 ---------- */
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const stack = [];
const tagRe = /<\/?([a-zA-Z][a-zA-Z0-9]*)\b[^>]*?(\/?)>/g;
let m;
let tagIssues = 0;
while ((m = tagRe.exec(htmlClean))) {
  const full = m[0], name = m[1].toLowerCase(), selfClose = m[2] === '/';
  if (VOID.has(name) || selfClose) continue;
  const line = htmlClean.slice(0, m.index).split('\n').length;
  if (full.startsWith('</')) {
    if (!stack.length) { add('严重', `多余的闭合标签 </${name}>`, `index.html L${line}`); tagIssues++; continue; }
    const top = stack.pop();
    if (top.name !== name) {
      add('严重', `标签不匹配：<${top.name}>（L${top.line}）被 </${name}>（L${line}）闭合`, 'index.html'); tagIssues++;
    }
  } else {
    stack.push({ name, line });
  }
}
stack.forEach(s => { add('严重', `未闭合的 <${s.name}>`, `index.html L${s.line}`); tagIssues++; });
if (!tagIssues) add('通过', 'HTML 标签配对', '剥除注释与脚本后，全部闭合且匹配');
// 附：div 计数交叉校验
{
  const o = (htmlClean.match(/<div\b/g) || []).length, c = (htmlClean.match(/<\/div>/g) || []).length;
  if (o !== c) add('严重', `div 数量不平衡：开 ${o} / 闭 ${c}`, 'index.html（剥注释后）');
}

/* ---------- 收集 id / class ---------- */
const collectIds = (src) => {
  const ids = new Set(); let x;
  const re = /\bid\s*=\s*"([A-Za-z][\w-]*)"/g;
  while ((x = re.exec(src))) ids.add(x[1]);
  return ids;
};
const staticIds = collectIds(htmlClean);
const dynamicIds = collectIds(app);            // JS 里拼 HTML 时写下的字面 id
// 还有一类：JS 运行时给创建出来的元素赋 id（如 host.id = 'quizResume'）
{
  const re = /\.id\s*=\s*'([A-Za-z][\w-]*)'/g; let x;
  while ((x = re.exec(app))) dynamicIds.add(x[1]);
}
const dynPrefixes = [];                        // id="xxx' + ... 这种动态拼接
{
  const re = /\bid\s*=\s*"([A-Za-z][\w-]*)'\s*\+/g; let x;
  while ((x = re.exec(app))) dynPrefixes.push(x[1]);
}
const idsInHtml = [...staticIds];

/* ---------- ② 重复 id ---------- */
{
  const seen = {}; let dup = 0;
  const re = /\bid\s*=\s*"([A-Za-z][\w-]*)"/g; let x;
  while ((x = re.exec(html))) { seen[x[1]] = (seen[x[1]] || 0) + 1; }
  Object.entries(seen).forEach(([k, v]) => { if (v > 1) { add('严重', `HTML 中有重复 id：${k} ×${v}`, 'index.html'); dup++; } });
  if (!dup) add('通过', 'id 唯一性', `${idsInHtml.length} 个 id，无重复`);
}

/* ---------- ③ 悬空 DOM 引用 ---------- */
const refs = [];
{
  const push = (id, line) => { if (id && /^[A-Za-z][\w-]*$/.test(id)) refs.push({ id, line }); };
  const scans = [
    [/\$\(\s*'#([A-Za-z][\w-]*)'\s*\)/g, app],      // $('#xxx')
    [/getElementById\(\s*'([A-Za-z][\w-]*)'\s*\)/g, app],
  ];
  scans.forEach(([re, src]) => { let x; while ((x = re.exec(src))) push(x[1], src.slice(0, x.index).split('\n').length); });
  // $$('#a, #b') 这类逗号选择器
  const multi = /\$\$\(\s*'([^']+)'\s*\)/g; let x;
  while ((x = multi.exec(app))) {
    x[1].split(',').map(s => s.trim()).forEach(sel => {
      const h = sel.match(/^#([A-Za-z][\w-]*)/); if (h) push(h[1], app.slice(0, x.index).split('\n').length);
    });
  }
}
{
  const missing = [], soft = [];
  const seen = new Set();
  // JS 里出现过的字符串字面量（说明该 id 是由 JS 动态创建 / 以参数传入的）
  const idLiterals = new Set();
  { const re = /'([A-Za-z][\w-]*)'/g; let x; while ((x = re.exec(app))) idLiterals.add(x[1]); }
  refs.forEach(({ id, line }) => {
    if (seen.has(id)) return;
    seen.add(id);
    if (staticIds.has(id) || dynamicIds.has(id)) return;
    if (dynPrefixes.some(p => id.startsWith(p))) return;
    if (idLiterals.has(id)) { soft.push({ id, line }); return; }   // 由 JS 拼出来的元素
    missing.push({ id, line });
  });
  if (missing.length) missing.forEach(o => add('严重', `悬空 DOM 引用：#${o.id}`, `app.js L${o.line} —— index.html 与 JS 动态生成的 HTML 里都没有这个 id（请确认代码里有空值保护）`));
  if (soft.length) soft.forEach(o => add('提示', `动态创建的元素：#${o.id}`, `app.js L${o.line} —— 该 id 在 JS 里以字面量出现，属运行时生成，非悬空`));
  if (!missing.length) add('通过', 'DOM 引用完整性', `${seen.size} 个 id 引用全部能找到元素或由 JS 创建`);
}

/* ---------- ④ 重复函数定义 ---------- */
{
  const defs = {};
  const re = /^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/gm; let x;
  while ((x = re.exec(app))) {
    const line = app.slice(0, x.index).split('\n').length;
    (defs[x[1]] = defs[x[1]] || []).push(line);
  }
  const dups = Object.entries(defs).filter(([, v]) => v.length > 1);
  if (dups.length) dups.forEach(([k, v]) => add('严重', `重复定义函数：${k}`, `app.js L${v.join(' / L')} —— 后者会覆盖前者`));
  else add('通过', '函数定义唯一性', `${Object.keys(defs).length} 个函数，无重名覆盖`);
}

/* ---------- ⑤ 调用了但未定义的本地函数 ---------- */
{
  const defined = new Set();
  // 先剥掉字符串字面量（等长空格替换，行号不错位）：否则 CSS 选择器里的 `:not(`
  // 会被当成函数调用，报成假的 ReferenceError（P1-10 加 aria 后实测踩到）。
  const code = app
    .replace(/'(?:[^'\\\n]|\\.)*'/g, (m) => "'" + ' '.repeat(Math.max(0, m.length - 2)) + "'")
    .replace(/"(?:[^"\\\n]|\\.)*"/g, (m) => '"' + ' '.repeat(Math.max(0, m.length - 2)) + '"');
  const reDef = /(?:^|\s)function\s+([A-Za-z_$][\w$]*)\s*\(/g; let x;
  while ((x = reDef.exec(code))) defined.add(x[1]);
  const reVar = /(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:function|\()/g;
  while ((x = reVar.exec(code))) defined.add(x[1]);
  const builtins = new Set(['if','for','while','switch','catch','return','typeof','function','new','delete','void','in','of','do','else','finally','case','default','break','continue','yield','await','try','var','let','const','String','Number','Boolean','Array','Object','JSON','Math','Date','parseInt','parseFloat','isNaN','setTimeout','setInterval','clearTimeout','clearInterval','encodeURIComponent','decodeURIComponent','alert','confirm','prompt','console','RegExp','Error','Promise','Set','Map','require','fetch','requestAnimationFrame','structuredClone','queueMicrotask']);
  const called = new Map();
  const reCall = /(?:^|[^\w.$])([a-z_$][\w$]*)\s*\(/g;
  while ((x = reCall.exec(code))) {
    const n = x[1];
    if (builtins.has(n)) continue;
    const line = code.slice(0, x.index).split('\n').length;
    if (!called.has(n)) called.set(n, line);
  }
  const undef = [...called.entries()].filter(([n]) => !defined.has(n));
  if (undef.length) undef.forEach(([n, l]) => add('疑似', `可能未定义的函数调用：${n}()`, `app.js L${l} —— 若它不是别处注入/全局提供，运行时会 ReferenceError`));
  else add('通过', '函数调用完整性', '所有被调用的本地函数都有定义');
}

/* ---------- ⑥ window 全局引用 vs 数据文件提供 ---------- */
{
  const provided = new Set();
  const dataDir = path.join(ROOT, 'assets/js/data');
  let files = [];
  try { files = fs.readdirSync(dataDir).filter(f => f.endsWith('.js')); } catch {}
  files.forEach(f => {
    const t = read('assets/js/data/' + f) || '';
    let x;
    const re1 = /window\.([A-Z][\w]*)\s*=/g;
    while ((x = re1.exec(t))) provided.add(x[1]);
    const re2 = /window\['([A-Z][\w]*)'\]\s*=/g;      // window['WUDU_AUDIO'] = ... 形式
    while ((x = re2.exec(t))) provided.add(x[1]);
  });
  // 音频索引不在 data/ 下，单独算
  ['assets/js/audio-index.js', 'assets/js/audio-index-uk.js'].forEach(p => {
    const t = read(p); if (!t) return;
    let x;
    const re = /window\.([A-Z][\w]*)\s*=|window\['([A-Z][\w]*)'\]\s*=/g;
    while ((x = re.exec(t))) provided.add(x[1] || x[2]);
  });
  // 同级的运行库同理：native.js 提供 WUDU_NATIVE、store.js 提供 WUDU_STORE（P1-8）、
  // audio-packs.js 提供 WUDU_AUDIO_PACKS（P0-5 音频分包清单）
  ['assets/js/native.js', 'assets/js/store.js', 'assets/js/audio-packs.js'].forEach(p => {
    const t = read(p); if (!t) return;
    let x;
    const re = /window\.([A-Z][\w]*)\s*=|window\['([A-Z][\w]*)'\]\s*=/g;
    while ((x = re.exec(t))) provided.add(x[1] || x[2]);
  });
  ['Capacitor'].forEach(n => provided.add(n));
  const used = new Map();
  let x; const re = /window\.([A-Z][\w]*)/g;
  while ((x = re.exec(app))) {
    const n = x[1];
    if (!used.has(n)) used.set(n, app.slice(0, x.index).split('\n').length);
  }
  const unknown = [...used.entries()].filter(([n]) => !provided.has(n) && !['WUDU_NATIVE', 'localStorage', 'sessionStorage', 'location', 'document', 'navigator', 'addEventListener', 'innerWidth', 'innerHeight', 'scrollTo', 'open', 'setTimeout', 'matchMedia', 'getComputedStyle', 'Audio', 'Blob', 'URL', 'FileReader', 'speechSynthesis', 'Fullscreen', 'MutationObserver', 'indexedDB', 'crypto', 'performance', 'requestIdleCallback', 'CSS'].includes(n));
  if (unknown.length) unknown.forEach(([n, l]) => add('疑似', `引用了数据文件未提供的全局：window.${n}`, `app.js L${l}`));
  else add('通过', '全局数据引用', `数据文件提供 ${provided.size} 个全局，引用全部有来源`);
}

/* ---------- ⑦ 用了但 CSS 没定义的 class ---------- */
{
  const defined = new Set();
  let x; const reCss = /\.(-?[A-Za-z_][\w-]*)/g;
  while ((x = reCss.exec(css))) defined.add(x[1]);
  const used = new Set();
  const scan = (src) => { let y; const re = /class\s*=\s*"([^"]+)"/g; while ((y = re.exec(src))) y[1].split(/\s+/).forEach(c => c && used.add(c)); };
  scan(html); scan(app);
  const missing = [...used].filter(c => !defined.has(c) && !c.includes("'") && !/^[A-Z]/.test(c) === false);
  const reallyMissing = missing.filter(c => /^[a-z][\w-]*$/.test(c));
  if (reallyMissing.length) add('瑕疵', `用了但 style.css 未定义的 class ×${reallyMissing.length}`, reallyMissing.slice(0, 40).join(' · '));
  else add('通过', 'CSS class 完整性', '所有使用的小写 class 都有定义');
}

/* ---------- ⑧ script 加载顺序 ---------- */
{
  const order = [];
  let x; const re = /<script src="([^"]+)"><\/script>/g;
  while ((x = re.exec(html))) order.push(x[1]);
  const appIdx = order.indexOf('assets/js/app.js');
  const nativeIdx = order.indexOf('assets/js/native.js');
  const extraIdx = order.filter(s => s.includes('extra-')).map(s => order.indexOf(s));
  const problems = [];
  if (appIdx === -1) problems.push('app.js 未被引入');
  if (nativeIdx > appIdx) problems.push('native.js 在 app.js 之后加载');
  extraIdx.forEach(i => { if (i > appIdx) problems.push(`${order[i]} 在 app.js 之后加载（合并逻辑可能读不到）`); });
  const dataIdx = order.filter((s, i) => s.includes('/data/') && i > appIdx);
  if (dataIdx.length) problems.push(`数据文件在 app.js 之后加载：${dataIdx.join(', ')}`);
  if (problems.length) problems.forEach(p => add('严重', '脚本加载顺序问题', p));
  else add('通过', '脚本加载顺序', `${order.length} 个脚本，数据与 native 均在 app.js 之前`);
}

/* ---------- 输出 ---------- */
const order = { 严重: 0, 疑似: 1, 瑕疵: 2, 提示: 2, 通过: 3 };
out.sort((a, b) => (order[a.level] ?? 9) - (order[b.level] ?? 9));
const icon = { 严重: '✗', 疑似: '?', 瑕疵: '·', 提示: 'i', 通过: '✓' };
console.log('\n=== 雾读静态自检报告 ===\n');
out.forEach(o => console.log(`${icon[o.level]} [${o.level}] ${o.title}\n    ${o.detail}\n`));
const fail = out.filter(o => o.level === '严重').length;
const sus = out.filter(o => o.level === '疑似').length;
console.log(`—— 汇总：严重 ${fail} · 疑似 ${sus} · 瑕疵 ${out.filter(o => o.level === '瑕疵').length} · 通过 ${out.filter(o => o.level === '通过').length} ——\n`);
process.exit(fail ? 1 : 0);
