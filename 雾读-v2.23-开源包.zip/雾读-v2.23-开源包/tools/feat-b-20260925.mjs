/* 雾读 · 功能实装批次 B：P1-6 例句级题型（例句填空 excloze / 例句听写 exlisten）
   用法：node tools/feat-b-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

/* 1) 选池：例句型题目只挑「有例句」的词 */
P('B1 选池过滤',
`    var pool = opts.words || pickPool(level, scope);
    if (!pool.length) { toast('这个条件下没有可练的词，换个来源试试'); return; }`,
`    var pool = opts.words || pickPool(level, scope);
    // P1-6：例句级题型必须挑有例句的词，否则出不来题
    if (dir === 'excloze' || dir === 'exlisten') {
      pool = pool.filter(function (w) { return w.ex && w.ex.length; });
      if (!pool.length) { toast('这些词里没有带例句的，换个来源试试'); return; }
    }
    if (!pool.length) { toast('这个条件下没有可练的词，换个来源试试'); return; }`);

/* 2) 组卷：每题随手挑一条例句带进队列 */
P('B2 队列带例句',
`      queue: pool.map(function (w) {
        var d = dir;
        if (dir === 'mix') d = (Math.random() < prof.hardBias) ? 'cn2en' : 'en2cn';
        return { w: w, dir: d, streak: 0, need: 1, loops: 0, t0: 0 };
      }),`,
`      queue: pool.map(function (w) {
        var d = dir;
        if (dir === 'mix') d = (Math.random() < prof.hardBias) ? 'cn2en' : 'en2cn';
        var ex = null;
        if (w.ex && w.ex.length) ex = w.ex[Math.floor(Math.random() * w.ex.length)];
        return { w: w, dir: d, ex: ex, streak: 0, need: 1, loops: 0, t0: 0 };
      }),`);

/* 3) 模式标签 */
P('B3 模式标签',
`    $('#quizModeTag').textContent = isEn2Cn ? '认词 · 英→中' : (isListen ? '听写 · 听音拼写' : '默写 · 中→英');`,
`    $('#quizModeTag').textContent = isEn2Cn ? '认词 · 英→中'
      : (isListen ? '听写 · 听音拼写'
      : (item.dir === 'excloze' ? '例句填空' : (item.dir === 'exlisten' ? '例句听写' : '默写 · 中→英')));`);

/* 4) 题干：例句填空 / 例句听写 */
P('B4 例句题干',
`      body.innerHTML =
        '<div class="quiz-sub">' + (isListen ? '听发音，把这个单词写出来' : '写出对应的英语单词') + '</div>' +
        (isListen
          ? '<div class="quiz-prompt"><button class="spk-btn lg" id="quizReplay" title="再听一遍">🔊</button>' +
            '<div class="small muted" style="margin-top:8px">点喇叭再听一遍 · 音源在本机，离线也能练</div></div>'
          : '<div class="quiz-prompt cn">' + esc(w.cn) + '</div>') +`,
`      var exItem = item.ex || null;
      var promptHtml;
      if (item.dir === 'excloze' && exItem) {
        // 例句填空：把目标词挖空，剩下的语境都给你
        promptHtml = '<div class="quiz-sub">把横线处的词补出来</div>' +
          '<div class="quiz-prompt cn" style="font-size:19px;line-height:1.65">' + esc(blankSentence(exItem.en, w.w)) + '</div>' +
          (exItem.cn ? '<div class="small muted" style="margin-top:6px">' + esc(exItem.cn) + '</div>' : '');
      } else if (item.dir === 'exlisten' && exItem) {
        // 例句听写：只放整句发音 + 中文翻译，让耳朵和拼写一起用
        promptHtml = '<div class="quiz-sub">听整句发音，写出句中那个词</div>' +
          '<div class="quiz-prompt"><button class="spk-btn lg" id="quizReplay" title="再听一遍">🔊</button>' +
          '<div class="small muted" style="margin-top:8px">点喇叭再听一遍 · 音源在本机，离线也能练</div></div>' +
          (exItem.cn ? '<div class="small muted" style="margin-top:6px">' + esc(exItem.cn) + '</div>' : '');
      } else {
        promptHtml = '<div class="quiz-sub">' + (isListen ? '听发音，把这个单词写出来' : '写出对应的英语单词') + '</div>' +
          (isListen
            ? '<div class="quiz-prompt"><button class="spk-btn lg" id="quizReplay" title="再听一遍">🔊</button>' +
              '<div class="small muted" style="margin-top:8px">点喇叭再听一遍 · 音源在本机，离线也能练</div></div>'
            : '<div class="quiz-prompt cn">' + esc(w.cn) + '</div>');
      }
      body.innerHTML =
        promptHtml +`);

/* 5) 例句听写：自动播一遍 + 绑重播按钮 */
P('B5 例句听写自动播',
`      setTimeout(focusIn, 80);`,
`      setTimeout(focusIn, 80);
      // 例句听写：进来先自动播一遍，喇叭可重播
      if (item.dir === 'exlisten' && exItem) {
        setTimeout(function () { speak(exItem.en); }, 260);
        var rp = $('#quizReplay');
        if (rp) rp.onclick = function (ev) { ev.preventDefault(); speak(exItem.en); };
      }`);

/* 6) 挖空工具 */
P('B6 挖空函数',
`  function hintOf(word, level) {`,
`  // 把例句里的目标词挖成横线（P1-6）：容忍复数与常见词形变化，找不到就退化成整词替换
  function blankSentence(en, word) {
    var s = String(en || '');
    var w = String(word || '');
    if (!w) return s;
    var esc2 = w.replace(/[.*+?^\${}()|[\\]\\\\]/g, '\\\\$&');
    var re = new RegExp('\\\\b' + esc2 + '(?:s|es|ed|d|ing|ies)?\\\\b', 'gi');
    var hit = false;
    var out = s.replace(re, function () { hit = true; return '______'; });
    if (hit) return out;
    return s.replace(new RegExp(esc2, 'i'), '______');
  }

  function hintOf(word, level) {`);

const bak = APP + '.bak-feat-b-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1）'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
