/* 雾读 · 功能实装批次 E：P1-4 多端互通（不碰网络，只走剪贴板/文件）
   设计取舍：清单原方案里的「局域网直传（手机连本机 8899）」需要把服务绑到局域网地址，
   与安全红线「绝不公网暴露 / 只绑 127.0.0.1」冲突，且要额外一次性 code 校验 —— 故本轮不做。
   改用「备份文本 ⇄ 剪贴板」通路：手机复制 → 微信发给自己 → 电脑粘贴导入，全程离线、零暴露面。
   用法：node tools/feat-e-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

/* 1) 抽出「打包」逻辑，导出/复制共用 */
P('E1 抽出打包函数',
`    var sExp = $('#setExport');
    if (sExp) sExp.onclick = function () {
      try {
        // 自检 D2：备份必须含全部本地键 —— 语法 / 翻译 / 专注 / 未完成会话原先漏了，导入后静默消失
        var pack = {
          app: 'wudu', at: todayStr(),
          progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin,
          grammar: load('wudu.grammar.v1', {}), translate: load('wudu.translate.v1', {}),
          focus: load('wudu.focus.v1', []), quiz: load('wudu.quiz.v1', null)
        };`,
`    // P1-4：打包逻辑独立出来 —— 「导出文件」与「复制备份文本」用同一份，避免两边字段跑偏
    function buildPack() {
      return {
        app: 'wudu', at: todayStr(), v: 2,
        progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin,
        grammar: load('wudu.grammar.v1', {}), translate: load('wudu.translate.v1', {}),
        focus: load('wudu.focus.v1', []), quiz: load('wudu.quiz.v1', null)
      };
    }
    // 导入校验与落地（文件导入 / 剪贴板导入共用）—— 自检 D1/C3 的守卫都在这里
    function applyPack(o, done) {
      var isObj = function (x) { return !!x && typeof x === 'object' && !Array.isArray(x); };
      if (!isObj(o) || !isObj(o.progress) || !isObj(o.stats) || !isObj(o.settings)) {
        toast('导入失败：缺少必要字段（progress / stats / settings）');
        return false;
      }
      try {
        localStorage.setItem('wudu.preimport', JSON.stringify({
          at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
        }));
      } catch (e) {}
      progress = o.progress;
      stats = o.stats;
      adapt = isObj(o.adapt) ? o.adapt : { mode: 'auto', recent: [] };
      checkin = sanitizeCheckin(isObj(o.checkin) ? o.checkin : { days: [] });
      settings = Object.assign(defaultSettings(), o.settings);
      if (isObj(o.grammar)) save('wudu.grammar.v1', o.grammar);
      if (isObj(o.translate)) save('wudu.translate.v1', o.translate);
      if (Array.isArray(o.focus)) save('wudu.focus.v1', o.focus);
      try {
        renderHome(); renderPlan(); renderSettings();
        saveAll();
        if (done) done();
      } catch (e) {
        toast('导入完成，但页面渲染出错：' + e.message + '（已留导入前快照）');
      }
      return true;
    }

    var sExp = $('#setExport');
    if (sExp) sExp.onclick = function () {
      try {
        var pack = buildPack();`);

/* 2) 复制到剪贴板 */
P('E2 复制备份文本',
`    var sImp = $('#setImport'), sImpF = $('#setImportFile');`,
`    // P1-4：把备份文本塞进剪贴板（手机端「发给自己」就这么走）
    var sCopy = $('#setCopyPack');
    if (sCopy) sCopy.onclick = function () {
      var txt;
      try { txt = JSON.stringify(buildPack()); }
      catch (e) { toast('打包失败：' + e.message); return; }
      var okTip = '已复制备份文本 · 粘到微信发给自己，电脑端「从剪贴板导入」就能接上';
      var fallback = function () {
        try {
          var ta = document.createElement('textarea');
          ta.value = txt;
          ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.select();
          var ok = document.execCommand('copy');
          ta.remove();
          toast(ok ? okTip : '这个环境不让复制 —— 改用「导出」存文件');
        } catch (e) { toast('复制失败，改用「导出」存文件'); }
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(function () { toast(okTip); }, fallback);
      } else fallback();
    };

    // P1-4：从剪贴板导入（电脑上复制好，手机上粘）
    var sPaste = $('#setPasteImport');
    if (sPaste) sPaste.onclick = function () {
      var go2 = function (txt) {
        var o = null;
        try { o = JSON.parse(String(txt || '').trim()); }
        catch (e) { toast('剪贴板里不是备份文本（JSON 解析失败）'); return; }
        applyPack(o, function () { toast('已从剪贴板导入学习数据'); });
      };
      if (navigator.clipboard && navigator.clipboard.readText) {
        navigator.clipboard.readText().then(go2, function () {
          var t = window.prompt('浏览器不让直接读剪贴板 —— 把备份文本粘到这里：', '');
          if (t) go2(t);
        });
      } else {
        var t2 = window.prompt('把备份文本粘到这里：', '');
        if (t2) go2(t2);
      }
    };

    var sImp = $('#setImport'), sImpF = $('#setImportFile');`);

/* 3) 文件导入改用共用守卫 */
P('E3 文件导入走共用函数',
`          var o = null;
          try { o = JSON.parse(String(fr.result)); }
          catch (e) { toast('导入失败：这不是有效的 JSON 文件'); return; }
          if (!o || typeof o !== 'object' || Array.isArray(o)) { toast('导入失败：内容不是备份格式'); return; }
          var isObj = function (x) { return !!x && typeof x === 'object' && !Array.isArray(x); };
          // 自检 D1：旧版只要字段是「真值」就覆盖 —— {"progress":{}} 会把整份进度清空并立刻落盘
          if (!isObj(o.progress) || !isObj(o.stats) || !isObj(o.settings)) {
            toast('导入失败：备份缺少必要字段（progress / stats / settings）');
            return;
          }
          // 先把现状留一份，导错了还能捞回来（自检 D1）
          try {
            localStorage.setItem('wudu.preimport', JSON.stringify({
              at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
            }));
          } catch (e) {}
          progress = o.progress;
          stats = o.stats;
          adapt = isObj(o.adapt) ? o.adapt : { mode: 'auto', recent: [] };
          checkin = sanitizeCheckin(isObj(o.checkin) ? o.checkin : { days: [] });
          // 自检 C3：导入的 settings 缺 examDate 之类的字段会让首页直接抛错 —— 用默认值补全
          settings = Object.assign(defaultSettings(), o.settings);
          if (isObj(o.grammar)) save('wudu.grammar.v1', o.grammar);
          if (isObj(o.translate)) save('wudu.translate.v1', o.translate);
          if (Array.isArray(o.focus)) save('wudu.focus.v1', o.focus);
          try {
            renderHome(); renderPlan(); renderSettings();
            saveAll();   // 自检 C3：落盘移到渲染成功之后，避免「报错但数据已被覆盖」
            toast('已导入学习数据');
          } catch (e) {
            toast('导入完成，但页面渲染出错：' + e.message + '（已留一份导入前快照）');
          }`,
`          var o = null;
          try { o = JSON.parse(String(fr.result)); }
          catch (e) { toast('导入失败：这不是有效的 JSON 文件'); return; }
          // P1-4：校验与落地统一走 applyPack（与剪贴板导入同一套守卫）
          applyPack(o, function () { toast('已导入学习数据'); });`);

const bak = APP + '.bak-feat-e-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1）'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
