#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""雾读 · 英音音源生成（P1-5）
---------------------------------------------------------------
只为「高频词」生成一套 en-GB 音源，供「英/美音切换」用（不是全量，控制安装包体积）。
输入：tools/audio/uk-words.json —— 由 node 从词库导出，形如 [{"w":"abandon","freq":3}, ...]
输出：assets/audio/w-uk/<word>.mp3  +  assets/js/audio-index-uk.js
用法：python tools/audio/gen_audio_uk.py [--concurrency 20] [--limit N]
"""
import argparse
import asyncio
import json
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
AUD = os.path.join(ROOT, "assets", "audio", "w-uk")
LIST = os.path.join(ROOT, "tools", "audio", "uk-words.json")
INDEX = os.path.join(ROOT, "assets", "js", "audio-index-uk.js")

VOICE_UK = "en-GB-SoniaNeural"
RATE = "-10%"


async def synth(text, out, sem):
    import edge_tts
    async with sem:
        for attempt in range(3):
            try:
                com = edge_tts.Communicate(text, VOICE_UK, rate=RATE)
                await com.save(out)
                if os.path.exists(out) and os.path.getsize(out) > 700:
                    return True
            except Exception as e:
                if attempt == 2:
                    print("  ! 合成失败 %r: %s" % (text[:40], e))
                await asyncio.sleep(1.2 * (attempt + 1))
        return False


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--concurrency", type=int, default=20)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    if not os.path.exists(LIST):
        print("缺少词表：%s" % LIST)
        return 1
    with open(LIST, "r", encoding="utf-8") as f:
        words = json.load(f)
    if args.limit:
        words = words[: args.limit]

    os.makedirs(AUD, exist_ok=True)
    sem = asyncio.Semaphore(args.concurrency)
    todo = [w["w"] for w in words
            if not (os.path.exists(os.path.join(AUD, w["w"] + ".mp3"))
                    and os.path.getsize(os.path.join(AUD, w["w"] + ".mp3")) > 700)]
    print("英音音源：待生成 %d / 总计 %d" % (len(todo), len(words)))

    done, ok = 0, 0
    async def run(w):
        nonlocal done, ok
        p = os.path.join(AUD, w + ".mp3")
        r = await synth(w, p, sem)
        done += 1
        if r:
            ok += 1
        if done % 100 == 0:
            print("  进度 %d / %d（成功 %d）" % (done, len(todo), ok))

    await asyncio.gather(*[run(w) for w in todo])

    # 写索引（只收真实存在的文件）
    m = {}
    for w in words:
        p = os.path.join(AUD, w["w"] + ".mp3")
        if os.path.exists(p) and os.path.getsize(p) > 700:
            m[w["w"]] = "assets/audio/w-uk/%s.mp3" % w["w"]
    body = ("/* 自动生成，勿手改 —— 英音（en-GB）音源索引，由 tools/audio/gen_audio_uk.py 产出\n"
            "   只在设置里切到「英音」时使用；缺词自动回落美音。 */\n"
            "window.WUDU_AUDIO_UK = ")
    body += json.dumps({"words": m}, ensure_ascii=False, separators=(",", ":"))
    body += ";\n"
    with open(INDEX, "w", encoding="utf-8") as f:
        f.write(body)
    size = sum(os.path.getsize(os.path.join(AUD, n)) for n in os.listdir(AUD)
               if n.endswith(".mp3"))
    print("完成：成功 %d / 待生成 %d；索引 %d 条；体积 %.1f MB" % (ok, len(todo), len(m), size / 1048576))
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
