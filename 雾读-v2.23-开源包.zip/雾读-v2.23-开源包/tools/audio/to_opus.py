#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""雾读 · 音源转 Opus（清单 P0-5：安装包不继续膨胀）
------------------------------------------------------------------
现状：mp3 共 336 MB（词 7153 + 例句 9576 + 听力 110 + 英音 2378 + 逐句 95），
      APK 体积几乎全由音频构成。实测样本：32 kbps 单声道 Opus 约为原体积的 57%。
做法：**不动原 mp3**，另生成一套 .opus 到同名目录（w→w-o / e→e-o / l→l-o / w-uk→w-uk-o），
      全部转完后再原子替换索引文件（audio-index*.js 的路径后缀）；
      回滚＝把索引换回 mp3 版本（备份 .bak-mp3-<日期>），mp3 原文件一直在。
用法：python tools/audio/to_opus.py [--jobs 8] [--bitrate 32k] [--limit N]
"""
import argparse
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
AUD = os.path.join(ROOT, "assets", "audio")
FFMPEG = r"D:\DeepSeek\tools\ffmpeg\ffmpeg.exe"
IDX = os.path.join(ROOT, "assets", "js", "audio-index.js")
IDX_UK = os.path.join(ROOT, "assets", "js", "audio-index-uk.js")
PAIRS = [("w", "w-o"), ("e", "e-o"), ("l", "l-o"), ("w-uk", "w-uk-o")]


def convert(job):
    src, dst, br = job
    if not os.path.exists(src):
        return (False, 0, 0)
    if os.path.exists(dst) and os.path.getsize(dst) > 200 and os.path.getmtime(dst) >= os.path.getmtime(src):
        return (True, os.path.getsize(src), os.path.getsize(dst))
    try:
        r = subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", src,
                            "-c:a", "libopus", "-b:a", br, "-ac", "1", "-application", "voip", dst],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if r.returncode == 0 and os.path.exists(dst) and os.path.getsize(dst) > 200:
            return (True, os.path.getsize(src), os.path.getsize(dst))
    except Exception as e:
        print("  ! 失败 %s: %s" % (os.path.basename(src), e))
    return (False, 0, 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--bitrate", default="32k")
    ap.add_argument("--limit", type=int, default=0, help="每个目录只转前 N 个（试跑用）")
    ap.add_argument("--no-index", action="store_true", help="只转文件，不改索引")
    args = ap.parse_args()

    jobs = []
    for src_dir, dst_dir in PAIRS:
        sd = os.path.join(AUD, src_dir)
        if not os.path.isdir(sd):
            continue
        dd = os.path.join(AUD, dst_dir)
        os.makedirs(dd, exist_ok=True)
        files = [f for f in sorted(os.listdir(sd)) if f.lower().endswith(".mp3")]
        if args.limit:
            files = files[: args.limit]
        for f in files:
            jobs.append((os.path.join(sd, f), os.path.join(dd, f[:-4] + ".opus"), args.bitrate))
        print("  %s → %s：%d 个" % (src_dir, dst_dir, len(files)))

    print("共 %d 个待转，并发 %d，码率 %s" % (len(jobs), args.jobs, args.bitrate))
    done = ok = 0
    orig = new = 0
    with ThreadPoolExecutor(max_workers=args.jobs) as ex:
        for success, o, n in ex.map(convert, jobs):
            done += 1
            if success:
                ok += 1
                orig += o
                new += n
            if done % 500 == 0:
                print("  进度 %d / %d（成功 %d）" % (done, len(jobs), ok))
    print("转换完成：成功 %d / %d；%.1f MB → %.1f MB（%.0f%%）"
          % (ok, len(jobs), orig / 1048576, new / 1048576, (new / orig * 100) if orig else 0))

    if args.no_index or ok == 0:
        print("按要求未改索引")
        return 0

    # 原子替换索引里的扩展名（只在对应 .opus 真实存在时才换）
    for path, dirs in ((IDX, {"w": "w-o", "e": "e-o", "l": "l-o"}), (IDX_UK, {"w-uk": "w-uk-o"})):
        if not os.path.exists(path):
            continue
        txt = open(path, encoding="utf-8").read()
        m = re.search(r"(\{.*\})", txt, re.S)
        if not m:
            continue
        data = json.loads(m.group(1))
        changed = 0

        def fix(rel):
            nonlocal changed
            if not rel or not rel.endswith(".mp3"):
                return rel
            for src_dir, dst_dir in dirs.items():
                if rel.startswith("assets/audio/%s/" % src_dir):
                    cand = rel.replace("assets/audio/%s/" % src_dir, "assets/audio/%s/" % dst_dir)[:-4] + ".opus"
                    if os.path.exists(os.path.join(ROOT, cand.replace("/", os.sep))):
                        changed += 1
                        return cand
            return rel

        for key in ("words", "listen", "lines"):
            mp = data.get(key)
            if isinstance(mp, dict):
                for k in list(mp.keys()):
                    mp[k] = fix(mp[k])
        if changed:
            bak = path + ".bak-mp3-20260925"
            if not os.path.exists(bak):
                open(bak, "w", encoding="utf-8").write(txt)
            head = txt[: m.start(1)]
            open(path, "w", encoding="utf-8").write(head + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n")
            print("  索引已更新：%s（换了 %d 条，备份 %s）" % (os.path.basename(path), changed, os.path.basename(bak)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
