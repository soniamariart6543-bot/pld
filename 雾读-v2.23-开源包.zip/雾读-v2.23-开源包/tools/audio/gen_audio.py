#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""雾读 · 离线音源生成器
=================================================================
把词库单词与听力原文合成为 mp3，随 APK 一起打包 ——
手机上不再依赖系统 TTS 引擎（国产 ROM 常把引擎精简掉，表现就是
「这个环境不支持朗读」）。

用法：
    python tools/audio/gen_audio.py --only words --limit 5     # 试跑 5 个词
    python tools/audio/gen_audio.py                            # 全量（词 + 听力）

产物：
    assets/audio/w/<slug>.mp3      每个单词一条
    assets/audio/l/<id>.mp3        每套听力一段（按 speaker 顺序拼接）
    assets/js/audio-index.js       文本 → 音频路径 的索引（给 speak() 查表）
"""
import argparse
import asyncio
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA = os.path.join(ROOT, "assets", "js", "data")
AUD = os.path.join(ROOT, "assets", "audio")
FFMPEG = r"D:\DeepSeek\tools\ffmpeg\ffmpeg.exe"
VOICE_EN = "en-US-AriaNeural"     # 神经语音，比系统 SAPI 自然得多
RATE = "-10%"                     # 稍慢：听清单词的每个音节
CONCURRENCY = 20


def ok_file(p):
    """已经生成好的音频（体积太小的多半是中断留下的半截文件，要重做）。"""
    return os.path.exists(p) and os.path.getsize(p) > 700


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", str(s).lower()).strip("-")


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def words():
    """从 cet4.js / cet6.js 里按顺序取词，去重保序。"""
    out = []
    for fn in ("cet4.js", "cet6.js"):
        src = read(os.path.join(DATA, fn))
        for m in re.finditer(r'\n\s*w:\s*"([^"]+)"', src):
            w = m.group(1).strip()
            if w and w not in out:
                out.append(w)
    return out


def entries(path):
    """按词条切分 cet4.js / cet6.js，取回 词形 → 例句英文列表。"""
    src = read(path)
    parts = re.split(r'\n  \{\n    w: "', src)
    out = []
    for p in parts[1:]:
        w = p.split('"', 1)[0].strip()
        ens = [e.replace('\\"', '"').replace("\\\\", "\\")
               for e in re.findall(r'"?en"?\s*:\s*"((?:[^"\\]|\\.)*)"', p)]
        if w:
            out.append((w, ens))
    return out


def listening():
    """从 listening.js 取每套题的 id 与 script 句子列表。
    （原文里是 `{ speaker: "N", text: "..." },` —— speaker 与 text 在同一行）"""
    src = read(os.path.join(DATA, "listening.js"))
    sets = []
    blocks = re.split(r'\n\s*\{\s*\n\s*id:\s*"', src)
    for b in blocks[1:]:
        sid = b.split('"', 1)[0]
        texts = re.findall(r'speaker:\s*"([^"]*)",\s*text:\s*"((?:[^"\\]|\\.)*)"', b)
        if texts:
            sets.append((sid, [t[1].replace('\\"', '"').replace("\\\\", "\\") for t in texts]))
    return sets


async def synth(text, out, sem, voice=VOICE_EN, rate=RATE):
    import edge_tts
    async with sem:
        for attempt in range(3):
            try:
                com = edge_tts.Communicate(text, voice, rate=rate)
                await com.save(out)
                if os.path.exists(out) and os.path.getsize(out) > 700:
                    return True
            except Exception as e:
                if attempt == 2:
                    print("  ! 合成失败 %r: %s" % (text[:40], e))
                await asyncio.sleep(1.2 * (attempt + 1))
        return False


def concat(parts, out):
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % p.replace("\\", "/"))
        listfile = f.name
    try:
        subprocess.run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", listfile,
                        "-c", "copy", out], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    finally:
        os.unlink(listfile)
    return os.path.exists(out) and os.path.getsize(out) > 1000


def write_index(word_map, listen_map, line_map=None):
    path = os.path.join(ROOT, "assets", "js", "audio-index.js")
    body = ("/* 自动生成，勿手改 —— 由 tools/audio/gen_audio.py 产出\n"
            "   文本 → 本地音频路径；speak() 会先查这张表，命中就播本机音源，\n"
            "   不依赖系统 TTS 引擎。lines 是听力逐句（键 'id|序号'）。 */\n"
            "window.WUDU_AUDIO = ")
    body += json.dumps({"words": word_map, "listen": listen_map, "lines": line_map or {}},
                       ensure_ascii=False, separators=(",", ":"))
    body += ";\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(body)
    return path


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["words", "listen", "examples", "both"], default="both")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--force", action="store_true", help="已存在的也重做")
    ap.add_argument("--shard", default="", help="分片跑：i/N（第 i 片，共 N 片），用于多进程并行")
    ap.add_argument("--concurrency", type=int, default=0, help="覆盖默认并发数")
    ap.add_argument("--no-index", action="store_true", help="不写索引（分片跑时用，最后由主进程统一写）")
    args = ap.parse_args()

    shard_i, shard_n = 1, 1
    if args.shard and "/" in args.shard:
        a, b = args.shard.split("/", 1)
        shard_i, shard_n = max(1, int(a)), max(1, int(b))

    def cut(items):
        """按分片取自己那一段（取模切分，四片大小均匀）。"""
        if shard_n <= 1:
            return items
        return [x for i, x in enumerate(items) if i % shard_n == shard_i - 1]

    def maybe_index():
        if not args.no_index:
            write_index(word_map, listen_map, line_map)

    os.makedirs(os.path.join(AUD, "w"), exist_ok=True)
    os.makedirs(os.path.join(AUD, "l"), exist_ok=True)
    os.makedirs(os.path.join(AUD, "e"), exist_ok=True)      # 例句目录：少了这个，写入全部失败（曾经空转四片）
    sem = asyncio.Semaphore(args.concurrency or CONCURRENCY)
    word_map, listen_map, line_map = {}, {}, {}

    # 旧索引里已有的映射先读进来，避免只跑一部分时丢索引
    old = os.path.join(ROOT, "assets", "js", "audio-index.js")
    if os.path.exists(old) and args.limit == 0:
        try:
            txt = read(old)
            j = json.loads(txt[txt.index("{"): txt.rindex("}") + 1])
            word_map.update(j.get("words") or {})
            listen_map.update(j.get("listen") or {})
            line_map.update(j.get("lines") or {})
        except Exception:
            pass

    if args.only in ("words", "both"):
        ws = words()
        if args.limit:
            ws = ws[: args.limit]
        ws = cut(ws)
        print("单词音源：%d 个（分片 %d/%d）" % (len(ws), shard_i, shard_n))
        todo = []
        for w in ws:
            rel = "assets/audio/w/%s.mp3" % slug(w)
            full = os.path.join(ROOT, rel)
            word_map[w] = rel
            if args.force or not ok_file(full):
                todo.append((w, full))
        print("  需合成 %d（其余已存在）" % len(todo))
        done = 0
        for i in range(0, len(todo), 30):
            batch = todo[i: i + 30]
            res = await asyncio.gather(*[synth(w, p, sem) for w, p in batch])
            done += sum(1 for r in res if r)
            print("  进度 %d/%d" % (min(i + 30, len(todo)), len(todo)))
        maybe_index()   # 这一阶段跑完就落索引，不用等后面两阶段

    if args.only in ("listen", "both"):
        sets = listening()
        if args.limit:
            sets = sets[: args.limit]
        print("听力音源：%d 套" % len(sets))
        for n, (sid, lines) in enumerate(sets, 1):
            rel = "assets/audio/l/%s.mp3" % sid
            full = os.path.join(ROOT, rel)
            listen_map[sid] = rel
            parts = []
            # 逐句音源：听力页「点某一句单独重听」也要能离线播
            for k, line in enumerate(lines):
                lrel = "assets/audio/l/%s-%02d.mp3" % (sid, k)
                lp = os.path.join(ROOT, lrel)
                line_map["%s|%d" % (sid, k)] = lrel
                if args.force or not ok_file(lp):
                    await synth(line, lp, sem)
                if ok_file(lp):
                    parts.append(lp)
            if not args.force and ok_file(full) and len(parts) == len(lines):
                continue                            # 整段与逐句都齐了
            if len(parts) == len(lines) and concat(parts, full):
                print("  [%d/%d] %s ← %d 句（整段+逐句）, %.0f KB" % (
                    n, len(sets), sid, len(parts), os.path.getsize(full) / 1024))
            else:
                print("  [%d/%d] %s ← 只补到 %d/%d 句" % (n, len(sets), sid, len(parts), len(lines)))
                if len(parts) != len(lines):
                    listen_map.pop(sid, None)

    if args.only in ("examples", "both"):
        pairs = []
        for fn in ("cet4.js", "cet6.js"):
            pairs += entries(os.path.join(DATA, fn))
        pairs = cut(pairs)          # 例句同样按分片切，四片各跑一段互不重复
        seen, todo = set(), []
        for w, ens in pairs:
            for en in ens:
                key = en.strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                digest = hashlib.md5(key.encode("utf-8")).hexdigest()[:8]
                rel = "assets/audio/e/%s-%s.mp3" % (slug(key)[:48], digest)
                full = os.path.join(ROOT, rel)
                word_map[key] = rel        # 例句与单词共用一张表：点🔊听到的就是这一句
                if args.force or not ok_file(full):
                    todo.append((key, full))
        print("例句音源：%d 句（需合成 %d）" % (len(seen), len(todo)))
        for i in range(0, len(todo), 30):
            batch = todo[i: i + 30]
            await asyncio.gather(*[synth(t, p, sem) for t, p in batch])
            print("  进度 %d/%d" % (min(i + 30, len(todo)), len(todo)))
        maybe_index()

    maybe_index()
    wav = len([1 for v in word_map.values() if os.path.exists(os.path.join(ROOT, v))])
    lav = len([1 for v in listen_map.values() if os.path.exists(os.path.join(ROOT, v))])
    size = 0
    for base, _, files in os.walk(AUD):
        for f in files:
            size += os.path.getsize(os.path.join(base, f))
    print("索引：%s%s" % (os.path.relpath(os.path.join(ROOT, "assets", "js", "audio-index.js"), ROOT),
                        "（--no-index 分片模式，未写入）" if args.no_index else ""))
    print("可用音源：单词 %d / 听力 %d · 合计 %.1f MB" % (wav, lav, size / 1048576))


if __name__ == "__main__":
    asyncio.run(main())
