/* 雾读 · 功能实装批次 A：P1-5 英美音 / P1-2 词根词缀 / P2-1 成就徽章 / P2-6 词汇量快测
   用法：node tools/feat-a-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
const P = (n, a, b) => patches.push([n, a, b]);

/* ---------------- P1-5 英美音 ---------------- */
P('P1-5 英音索引查询',
`  function localWord(text) {
    var A = audioIndex();
    if (!A) return null;
    var k = String(text == null ? '' : text).trim();
    return A.words[k] || A.words[k.toLowerCase()] || null;
  }`,
`  function localWord(text) {
    var A = audioIndex();
    if (!A) return null;
    var k = String(text == null ? '' : text).trim();
    return A.words[k] || A.words[k.toLowerCase()] || null;
  }
  // 英音索引（P1-5）：只覆盖高频词 2378 条，查不到就回落美音
  function localWordUK(text) {
    var A = window.WUDU_AUDIO_UK;
    if (!A || !A.words) return null;
    var k = String(text == null ? '' : text).trim();
    return A.words[k] || A.words[k.toLowerCase()] || null;
  }
  function hasUKAudio() {
    var A = window.WUDU_AUDIO_UK;
    return !!(A && A.words && Object.keys(A.words).length);
  }`);

P('P1-5 speak 按口音选索引',
`      var rel = localWord(text);
      if (rel) {
        var got = playLocal(rel, opt);
        if (got) return got;
      }`,
`      // 设置里选了英音就先查英音索引，查不到自动回落美音（P1-5）
      var rel = (settings && settings.voice === 'uk') ? (localWordUK(text) || localWord(text)) : localWord(text);
      if (rel) {
        var got = playLocal(rel, opt);
        if (got) return got;
      }`);

P('P1-5 设置项显示',
`    if ($('#ttsBtn')) $('#ttsBtn').textContent = tts.enabled ? '🔊 开' : '🔇 关';`,
`    if ($('#ttsBtn')) $('#ttsBtn').textContent = tts.enabled ? '🔊 开' : '🔇 关';
    if ($('#setVoice')) {
      $('#setVoice').textContent = (settings.voice === 'uk') ? '🇬🇧 英音' : '🇺🇸 美音';
      $('#setVoice').disabled = !hasUKAudio();
      if (!hasUKAudio()) $('#setVoice').title = '本机没有英音音源';
    }`);

P('P1-5 设置项点击绑定',
`    var rt2 = $('#ttsRate');
    if (rt2) rt2.oninput = function () {`,
`    var voiceBtn = $('#setVoice');
    if (voiceBtn) voiceBtn.onclick = function () {
      settings.voice = (settings.voice === 'uk') ? 'us' : 'uk';
      saveAll(); renderSettings();
      toast(settings.voice === 'uk' ? '已切到英音（高频词 2378 条，其余自动用美音）' : '已切回美音');
      var w = (dictState.picked) || 'welcome';
      speak(w === 'welcome' ? 'welcome' : w);   // 立刻试听一句，免得不知道有没有生效
    };
    var rt2 = $('#ttsRate');
    if (rt2) rt2.oninput = function () {`);

/* ---------------- P1-2 词根词缀面板 ---------------- */
P('P1-2 词根面板渲染函数',
`  function renderWordDetail(word, hostSel, noBack) {`,
`  // 词根词缀面板（P1-2）：数据来自 assets/js/data/{roots,word-split}.js
  // 收录原则是「不确定就不写」，所以查不到是常态 —— 查不到就整块不出现，不硬凑。
  function rootPanelHtml(word) {
    var split = (window.WORD_SPLIT || {})[word];
    if (!split || !split.parts || !split.parts.length) return '';
    var rootKey = split.root;
    var root = rootKey ? (window.WORD_ROOTS || {})[rootKey] : null;
    var typeName = { root: '词根', prefix: '前缀', suffix: '后缀' };
    var html = '<div class="wd-block"><h4>词根词缀 <span class="tag small muted">结构记忆，比死记省力</span></h4>';
    html += '<div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:8px">' +
      split.parts.map(function (p) {
        var seg = String(p).split(':');
        var key = String(seg[0] || '').trim();
        var mean = String(seg[1] || '').trim();
        var isRoot = key === rootKey;
        return '<span class="chip' + (isRoot ? ' on' : '') + '" style="cursor:default">' +
          esc(key) + (mean ? ' · ' + esc(mean) : '') + (isRoot ? ' ★' : '') + '</span>';
      }).join('') + '</div>';
    if (root) {
      html += '<div class="small muted">' + esc(typeName[root.type] || '词根') + ' <b>' + esc(rootKey) + '</b> —— ' +
        esc(root.meaning || '') + (root.origin ? '（' + esc(root.origin) + '）' : '') + '</div>';
      if (root.examples && root.examples.length) {
        html += '<div class="small muted" style="margin-top:4px">同族常见：' + root.examples.slice(0, 6).map(function (e) {
          return (BY_WORD[e] ? '<a href="#" data-wd="' + esc(e) + '">' + esc(e) + '</a>' : esc(e));
        }).join(' · ') + '</div>';
      }
    }
    var fam = (split.family || []).filter(function (x) { return BY_WORD[x] && x !== word; });
    if (fam.length) {
      html += '<div class="small muted" style="margin-top:4px">同根词：' + fam.map(function (x) {
        return '<a href="#" data-wd="' + esc(x) + '">' + esc(x) + '</a>';
      }).join(' · ') + '</div>';
    }
    html += '</div>';
    return html;
  }

  function renderWordDetail(word, hostSel, noBack) {`);

P('P1-2 详情里插入面板 + 词内跳转',
`      (w.note ? '<div class="wd-block"><h4>语法与用法</h4><div>' + esc(w.note) + '</div></div>' : '') +`,
`      (w.note ? '<div class="wd-block"><h4>语法与用法</h4><div>' + esc(w.note) + '</div></div>' : '') +
      rootPanelHtml(word) +`);

P('P1-2 同根词可点击跳转',
`    var bk = $('#wdBack');
    if (bk) bk.onclick = closeWordDetail;`,
`    var bk = $('#wdBack');
    if (bk) bk.onclick = closeWordDetail;
    // 词根面板里的同根词 / 同族词可以直接点进那个词的详情
    $$('[data-wd]').forEach(function (a) {
      a.onclick = function (ev) {
        ev.preventDefault();
        var t = a.dataset.wd;
        if (!BY_WORD[t]) return;
        dictState.picked = t;
        dictState.detailOpen = true;
        renderWordDetail(t, hostSel, noBack);
      };
    });`);

/* ---------------- P2-1 成就徽章 + P2-6 词汇量快测（都挂报告页） ---------------- */
P('P2-1/P2-6 宿主与徽章',
`    // 最该补的词
    var weak = WORDS.filter(function (w) {`,
`    renderReportExtra();

    // 最该补的词
    var weak = WORDS.filter(function (w) {`);

P('P2-1/P2-6 渲染函数本体',
`  /* ---------------- 事件绑定 ---------------- */
  function bindGlobal() {`,
`  /* ==========================================================
     报告页附加区：成就徽章（P2-1）+ 词汇量快测（P2-6）
     两者都塞在「概览」面板里 #reportWeak 之后，不另开页面（少一层跳转）
     ========================================================== */
  var BADGE_KIND_NAME = {
    streak: '连续学习', mastered: '已掌握词数', answered: '累计答题',
    focus: '累计专注', wrongFixed: '错词转掌握', accuracy: '单日正确率'
  };
  function badgeMetrics() {
    var c = counts();
    var answered = 0, bestAcc = 0;
    Object.keys(stats).forEach(function (d) {
      var st = stats[d] || {};
      answered += st.answered || 0;
      if ((st.answered || 0) >= 20) {
        var acc = Math.round((st.right || 0) / st.answered * 100);
        if (acc > bestAcc) bestAcc = acc;
      }
    });
    var focusMin = 0;
    (focusLog || []).forEach(function (x) { focusMin += x.minutes || 0; });
    var fixed = 0;
    Object.keys(progress).forEach(function (w) {
      var r = progress[w];
      if (r && (r.wrong || 0) > 0 && r.s >= MASTER_STAGE) fixed++;
    });
    return { streak: streak(), mastered: c.mastered, answered: answered, focus: focusMin, wrongFixed: fixed, accuracy: bestAcc };
  }
  function badgeDone(b, m) {
    if (b.kind === 'accuracy') {
      // 正确率类还要满足「当日至少答 minAnswered 题」，避免 1 题 100% 就发奖
      return m.accuracy >= b.need;
    }
    return (m[b.kind] || 0) >= b.need;
  }
  function renderBadges(host) {
    var list = window.WUDU_BADGES || [];
    if (!list.length) { host.innerHTML = ''; return; }
    var m = badgeMetrics();
    var got = list.filter(function (b) { return badgeDone(b, m); });
    var soon = list.filter(function (b) { return !badgeDone(b, m); })
      .sort(function (a, b) { return (m[b.kind] || 0) / b.need - (m[a.kind] || 0) / a.need; }).slice(0, 4);
    host.innerHTML = '<div class="card" style="margin-top:12px"><div class="spread" style="align-items:baseline">' +
      '<div class="card-title" style="margin:0">成就徽章 <span class="tag small muted">纯本地 · 没有排行榜</span></div>' +
      '<span class="badge ' + (got.length ? 'good' : '') + '">' + got.length + ' / ' + list.length + '</span></div>' +
      '<div class="row" style="flex-wrap:wrap;gap:8px;margin-top:8px">' +
      list.map(function (b) {
        var ok = badgeDone(b, m);
        return '<span class="chip' + (ok ? ' on' : '') + '" style="cursor:default;opacity:' + (ok ? 1 : .45) + '" title="' +
          esc(b.desc) + '">' + b.icon + ' ' + esc(b.name) + '</span>';
      }).join('') + '</div>' +
      (soon.length ? '<div class="flow-note" style="margin-top:8px">快拿到的：' +
        soon.map(function (b) {
          return esc(b.name) + '（' + esc(BADGE_KIND_NAME[b.kind] || '') + ' ' + (m[b.kind] || 0) + ' / ' + b.need + '）';
        }).join(' · ') + '</div>' : '<div class="flow-note" style="margin-top:8px">全部到手 —— 剩下的时间留给真题吧。</div>') +
      '</div>';
  }

  var vocabState = null;
  function vocabTiers() { return ((window.VOCAB_TEST || {}).tiers) || []; }
  function renderVocabTest(host) {
    var tiers = vocabTiers();
    if (!tiers.length) { host.innerHTML = ''; return; }
    if (!vocabState || vocabState.phase === 'idle') {
      host.innerHTML = '<div class="card" style="margin-top:12px"><div class="card-title">词汇量快测 <span class="tag small muted">3 分钟 · 90 题分层抽样</span></div>' +
        '<div class="small muted">按词频分三层抽题（四级核心 / 四级其余 / 六级），按各层正确率折算总量。结果只作参考，不写进学习记录。</div>' +
        '<div class="row" style="margin-top:10px"><button class="btn primary" id="vtStart">开始快测</button></div></div>';
      var b = document.getElementById('vtStart');
      if (b) b.onclick = function () {
        vocabState = { phase: 'run', ti: 0, qi: 0, hit: {}, total: 0, right: 0 };
        renderReportExtra();
      };
      return;
    }
    if (vocabState.phase === 'run') {
      var t = tiers[vocabState.ti];
      if (!t) { vocabState.phase = 'done'; renderReportExtra(); return; }
      var it = t.items[vocabState.qi];
      if (!it) { vocabState.ti++; vocabState.qi = 0; renderReportExtra(); return; }
      var doneN = Object.keys(vocabState.hit).reduce(function (a, k) { return a + vocabState.hit[k].n; }, 0);
      var totalN = tiers.reduce(function (a, x) { return a + x.items.length; }, 0);
      host.innerHTML = '<div class="card" style="margin-top:12px"><div class="spread" style="align-items:baseline">' +
        '<div class="card-title" style="margin:0">词汇量快测 · ' + esc(t.name) + '</div>' +
        '<span class="badge">' + (doneN + 1) + ' / ' + totalN + '</span></div>' +
        '<div class="quiz-prompt" style="font-size:26px;margin:10px 0 4px">' + esc(it.w) + '</div>' +
        '<div class="small muted">选出它最合适的中文释义</div>' +
        '<div class="opt-grid" style="margin-top:12px">' +
        it.options.map(function (o, i) {
          return '<button class="opt" data-vt="' + i + '">' + esc(o) + '</button>';
        }).join('') + '</div>' +
        '<div class="row" style="margin-top:10px"><button class="btn ghost sm" id="vtQuit">结束并看结果</button></div></div>';
      $$('#reportExtra [data-vt]').forEach(function (b) {
        b.onclick = function () {
          var pick = parseInt(b.dataset.vt, 10);
          var ok = pick === it.answer;
          if (!vocabState.hit[t.key]) vocabState.hit[t.key] = { n: 0, right: 0, size: t.size };
          vocabState.hit[t.key].n++;
          if (ok) { vocabState.hit[t.key].right++; vocabState.right++; }
          vocabState.total++;
          b.classList.add(ok ? 'ok' : 'no');
          setTimeout(function () { vocabState.qi++; renderReportExtra(); }, 220);
        };
      });
      var q = document.getElementById('vtQuit');
      if (q) q.onclick = function () { vocabState.phase = 'done'; renderReportExtra(); };
      return;
    }
    // done：按层折算总量
    var est = 0, rows = [];
    tiers.forEach(function (t) {
      var h = vocabState.hit[t.key];
      if (!h || !h.n) { rows.push('<div class="rpt-row"><span class="lbl">' + esc(t.name) + '</span><span class="val">未测</span></div>'); return; }
      var rate = h.right / h.n;
      var estN = Math.round(rate * t.size);
      est += estN;
      rows.push('<div class="rpt-row"><span class="lbl">' + esc(t.name) + '</span>' +
        '<span class="val">' + h.right + ' / ' + h.n + ' 对 · 折算 ' + estN + ' 词</span></div>');
    });
    host.innerHTML = '<div class="card" style="margin-top:12px"><div class="card-title">词汇量估算结果</div>' +
      '<div class="big">约 ' + est + ' <span class="small muted">词</span></div>' +
      rows.join('') +
      '<div class="flow-note" style="margin-top:8px">算法：各层正确率 × 该层词数后求和，是抽样估计不是精算；测的题越多越准。</div>' +
      '<div class="row" style="margin-top:10px"><button class="btn" id="vtAgain">再测一次</button></div></div>';
    var ag = document.getElementById('vtAgain');
    if (ag) ag.onclick = function () { vocabState = { phase: 'idle' }; renderReportExtra(); };
  }
  function renderReportExtra() {
    var anchor = document.getElementById('reportWeak');
    if (!anchor || !anchor.parentNode) return;
    var host = document.getElementById('reportExtra');
    if (!host) {
      host = document.createElement('div');
      host.id = 'reportExtra';
      anchor.parentNode.insertBefore(host, anchor.nextSibling);
    }
    renderBadges(host);
    var vt = document.createElement('div');
    host.appendChild(vt);
    renderVocabTest(vt);
  }

  /* ---------------- 事件绑定 ---------------- */
  function bindGlobal() {`);

const bak = APP + '.bak-feat-a-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1）'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
