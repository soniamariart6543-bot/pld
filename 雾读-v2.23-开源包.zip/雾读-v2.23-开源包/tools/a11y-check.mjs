/* 雾读 · 无障碍（P1-10）静态校验器
 * 用法：node tools/a11y-check.mjs
 * 退出码：0 全过 / 1 有缺口
 * 查什么：
 *   1. index.html 每个 <button> 是否有 aria-label（pg-tab 走 tablist 也算过）
 *   2. 每个可见 <input>/<select>/<textarea> 是否有 aria-label
 *   3. index.html 是否有 role="tablist" / tabpanel / region / 主导航
 *   4. style.css 的形状冗余（对错不只靠颜色）与 .opt 的 ok/no 类是否对得上
 *   5. app.js 的运行时兜底 applyA11y 是否仍在，且覆盖 .opt / .spell-wrap
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'assets/css/style.css'), 'utf8');
const js = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');

const problems = [], notes = [];
function chk(cond, msg) { if (!cond) problems.push(msg); else notes.push('✓ ' + msg); }

/* 1. 按钮 */
let btnAll = 0, btnMiss = [];
const btnRe = /<button\b([^>]*)>/g;
for (let m; (m = btnRe.exec(html));) {
  btnAll++;
  if (!/aria-label=/.test(m[1])) btnMiss.push(m[1].trim().slice(0, 70));
}
chk(btnAll > 0, 'index.html 按钮数 ' + btnAll);
chk(btnMiss.length === 0, '全部按钮都有 aria-label' + (btnMiss.length ? '（缺 ' + btnMiss.length + '：' + btnMiss.join(' | ') + '）' : ''));

/* 2. 输入控件 */
let inpAll = 0, inpMiss = [];
const inpRe = /<(input|select|textarea)\b([^>]*)>/g;
for (let m; (m = inpRe.exec(html));) {
  if (/type="hidden"/.test(m[2])) continue;
  inpAll++;
  if (!/aria-label=/.test(m[2])) inpMiss.push(m[1] + ' ' + m[2].trim().slice(0, 60));
}
chk(inpMiss.length === 0, '全部可见输入控件都有 aria-label（共 ' + inpAll + '）' + (inpMiss.length ? '（缺：' + inpMiss.join(' | ') + '）' : ''));

/* 3. 结构语义 */
chk(/role="tablist"/.test(html), '有 role="tablist" 的翻页容器');
chk((html.match(/role="tab"/g) || []).length >= 8, '翻页 tab 有 role="tab"（' + (html.match(/role="tab"/g) || []).length + ' 个）');
chk(/aria-selected=/.test(html), '翻页 tab 带 aria-selected');
chk(/role="tabpanel"/.test(html), '翻页面板带 role="tabpanel"');
chk(/<nav class="nav"[^>]*aria-label=/.test(html), '侧栏导航有 aria-label');
chk((html.match(/role="region"/g) || []).length >= 12, '视图区带 role="region"（' + (html.match(/role="region"/g) || []).length + ' 个）');
chk(/role="progressbar"/.test(html), '进度条带 role="progressbar"');
chk(/id="storeWarn" role="alert"/.test(html), '存储告警区是 role="alert"');

/* 4. 形状冗余：CSS 规则必须与 JS 实际加的类一致 */
chk(/\.opt\.ok::before|\.opt\.ok::after/.test(css), 'CSS 给「答对」选项加了形状（::before）');
chk(/\.opt\.no::before|\.opt\.no::after/.test(css), 'CSS 给「答错」选项加了形状（::before）');
const jsOk = /classList\.add\('ok'\)/.test(js), jsNo = /classList\.add\('no'\)/.test(js);
chk(jsOk && jsNo, 'app.js 实际用的是 ok / no 类（' + (jsOk ? 'ok✓' : 'ok✗') + ' ' + (jsNo ? 'no✓' : 'no✗') + '）');
const orphan = [...css.matchAll(/\.opt\.(on|bad)::before/g)].map((x) => x[0]);
if (orphan.length) problems.push('CSS 残留孤儿规则：' + orphan.join('、') + '（app.js 不再产出这些类）');

/* 5. 运行时兜底 */
chk(/function applyA11y\(/.test(js), 'app.js 有 applyA11y 运行时兜底');
chk(/MutationObserver/.test(js), '动态节点有 MutationObserver 持续补齐');
chk(/querySelectorAll\('\.opt'\)/.test(js) && /'选项：' \+ base/.test(js), '动态选项补语义（含对错状态）');
chk(/\.spell-wrap/.test(js), '字母输入槽有 role/label');

/* 6. 状态同步 */
chk(/aria-selected/.test(js), 'app.js 切页时同步 aria-selected');
chk(/aria-current/.test(js), 'app.js 同步导航 aria-current');
chk(/aria-pressed/.test(js), 'app.js 同步开关 aria-pressed');

console.log('=== 雾读无障碍静态校验（P1-10） ===');
notes.forEach((n) => console.log('  ' + n));
if (problems.length) {
  console.log('\n缺口 ' + problems.length + ' 项：');
  problems.forEach((p) => console.log('  ✗ ' + p));
  process.exit(1);
}
console.log('\n全部通过：' + notes.length + ' 项检查');
