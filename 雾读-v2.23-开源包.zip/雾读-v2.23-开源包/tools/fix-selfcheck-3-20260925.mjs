/* 雾读 · 按《代码自检报告》修第三批（F6 草稿被读取 / M2 写作字数口径 / M4 打卡幂等 / M6 计划失效）
   用法：node tools/fix-selfcheck-3-20260925.mjs */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';
import path from 'path';

const APP = 'D:\\DeepSeek\\项目\\四六级单词\\assets\\js\\app.js';
let s = fs.readFileSync(APP, 'utf8');
const patches = [];
function P(name, from, to) { patches.push([name, from, to]); }

/* M6 计划快照永不失效：考试日/级别/预算一变就该重算 */
P('M6 计划失效判据',
`  function daySchedule(plan, n) {`,
`  // 自检 M6：settings.plan 是「生成时的快照」—— 考试日、级别、每日预算任何一项变了都不该继续沿用
  function planStale() {
    var p = settings.plan;
    if (!p || !p.phases || !p.phases.length) return true;
    if (p.examDate !== settings.examDate) return true;
    if (p.level !== settings.level) return true;
    if (Number(p.minutes) !== Number(settings.minutes)) return true;
    if (diffDays(todayStr(), p.examDate) < 0) return true;   // 考试日已过：三个阶段全部过期
    return false;
  }
  function ensurePlan() {
    if (planStale()) {
      settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
      try { save(LS_SETTINGS, settings); } catch (e) {}
    }
    return settings.plan;
  }

  function daySchedule(plan, n) {`);

P('M6 首页用 ensurePlan',
`    var plan = settings.plan || planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);`,
`    var plan = ensurePlan();`);

P('M6 计划页用 ensurePlan',
`    if (!settings.plan) settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);`,
`    ensurePlan();`);

/* M4 打卡幂等：跨标签页重复写入时去重 */
P('M4 打卡去重',
`    a.days.push(todayStr());
    save(LS_CHECKIN, checkin);`,
`    a.days.push(todayStr());
    a.days = a.days.filter(function (d, i, arr) { return arr.indexOf(d) === i; });   // 自检 M4：多标签页并发时去重
    save(LS_CHECKIN, checkin);`);

/* M2 写作字数口径：提示写 160-200，判定下限却是 150 —— 官方要求六级 150-200 */
P('M2 六级写作下限',
`    var range = t.level === 'cet6' ? '160-200' : '120-180';`,
`    var range = t.level === 'cet6' ? '150-200' : '120-180';   // 自检 M2：与体检判定的下限保持一致`);

P('M2 真题写作占位文案',
`        '<textarea class="input" id="writeInput" rows="8" placeholder="按提纲写 120-160 词，写完再看范文。"></textarea>' +`,
`        '<textarea class="input" id="writeInput" rows="8" placeholder="按提纲写够字数（四级 120-180 / 六级 150-200 词），写完再看范文与自检。"></textarea>' +`);

/* F6 真题翻译：草稿原来从不被读取，写完切页就没了 */
P('F6 真题翻译读草稿',
`        if (p.type === '翻译') {
          fb.innerHTML = '<div class="sep"></div>' +
            '<div class="card-title">参考译文</div><div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.reference || '') + '</div>' +`,
`        if (p.type === '翻译') {
          // 自检 F6：草稿框原来从不被读取，写完切页即丢 —— 现在先把你写的渲染出来，再做关键词覆盖自检
          var mine = String((($('#transInput') || {}).value) || '').trim();
          var draft = '';
          if (mine) {
            var kws = p.keyWords || [];
            var hit = kws.filter(function (k) { return keywordHit(mine, k.w); });
            var nWords = (mine.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            draft = '<div class="sep"></div><div class="card-title">你的译文 <span class="tag small muted">' + nWords + ' 个英文词</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(mine) + '</div>' +
              (kws.length ? '<div class="spread small" style="margin-top:8px"><span>采分点覆盖 <b>' + hit.length + ' / ' + kws.length + '</b></span>' +
                '<span class="muted">本地规则，只查关键词是否出现</span></div><div style="margin-top:6px">' +
                kws.map(function (k) {
                  var ok = keywordHit(mine, k.w);
                  return '<span class="badge ' + (ok ? 'good' : 'bad') + '" style="margin:3px 6px 3px 0">' + (ok ? '✓ ' : '✗ ') + esc(k.w) + ' · ' + esc(k.cn) + '</span>';
                }).join('') + '</div>' : '');
          }
          fb.innerHTML = draft + '<div class="sep"></div>' +
            '<div class="card-title">参考译文</div><div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.reference || '') + '</div>' +`);

/* F6 真题写作：草稿同样被丢弃 */
P('F6 真题写作读草稿',
`        } else {
          fb.innerHTML = '<div class="sep"></div><div class="card-title">范文</div>' +
            '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.sample || '') + '</div>' +`,
`        } else {
          // 自检 F6：写作草稿同样从未被读取 —— 先给词数与连接词覆盖的本地体检，再看范文
          var myW = String((($('#writeInput') || {}).value) || '').trim();
          var wDraft = '';
          if (myW) {
            var nw = (myW.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            var connAll = (WKIT && WKIT.connectors) || {};
            var connHit = Object.keys(connAll).filter(function (k) {
              return (connAll[k] || []).some(function (w) { return myW.toLowerCase().indexOf(String(w).toLowerCase()) >= 0; });
            });
            var paras = myW.split(/\\n\\s*\\n/).filter(function (x) { return x.trim(); }).length;
            wDraft = '<div class="sep"></div><div class="card-title">你的草稿 <span class="tag small muted">' + nw + ' 词 · ' + paras + ' 段</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(myW) + '</div>' +
              '<div class="flow-note" style="margin-top:8px">连接词覆盖 ' + connHit.length + ' / ' + Object.keys(connAll).length +
              ' 类（' + (connHit.length ? connHit.join('、') : '一类都没用上') + '）；完整版体检请到「写作训练」页。</div>';
          }
          fb.innerHTML = wDraft + '<div class="sep"></div><div class="card-title">范文</div>' +
            '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.sample || '') + '</div>' +`);

const bak = APP + '.bak-fix3-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(APP, bak);
let fails = 0;
for (const [name, from, to] of patches) {
  const n = s.split(from).length - 1;
  if (n !== 1) { console.log('✗ ' + name + '：命中 ' + n + ' 次（要求 1），跳过'); fails++; continue; }
  s = s.replace(from, to);
  console.log('✓ ' + name);
}
if (fails) { console.log('\n有 ' + fails + ' 处未命中，未写盘。'); process.exit(1); }
fs.writeFileSync(APP, s, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
