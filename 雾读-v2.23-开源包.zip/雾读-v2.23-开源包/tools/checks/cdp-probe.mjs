/* 雾读 · 用 CDP 跑页面探针（headless 的 --virtual-time-budget 不等真实异步 IO，
   会把 IndexedDB / fetch 这类操作半路截断，所以这里直接连 DevTools 协议等结果）。
   用法：node tools/checks/cdp-probe.mjs <url> [waitMs] [selector]
   例：  node tools/checks/cdp-probe.mjs http://127.0.0.1:8902/tools/checks/feat-f-audit.html 9000 "#out"
*/
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const URL_ARG = process.argv[2];
const WAIT = parseInt(process.argv[3] || '9000', 10);
const SEL = process.argv[4] || '#out';
if (!URL_ARG) { console.error('用法: node tools/checks/cdp-probe.mjs <url> [waitMs] [selector]'); process.exit(2); }

const EDGE_CANDIDATES = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
];
const EDGE = EDGE_CANDIDATES.find((p) => fs.existsSync(p));
if (!EDGE) { console.error('找不到 msedge.exe'); process.exit(2); }

const PORT = 9333;
const PROFILE = path.join(os.tmpdir(), 'wudu-cdp-' + Date.now());
fs.mkdirSync(PROFILE, { recursive: true });

const child = spawn(EDGE, [
  '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--remote-debugging-port=' + PORT, '--user-data-dir=' + PROFILE, 'about:blank'
], { stdio: 'ignore' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let wsUrl = null;
for (let i = 0; i < 40; i++) {
  await sleep(300);
  try {
    const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
    const page = list.find((t) => t.type === 'page');
    if (page && page.webSocketDebuggerUrl) { wsUrl = page.webSocketDebuggerUrl; break; }
  } catch (e) { /* 还没起来 */ }
}
if (!wsUrl) { try { child.kill(); } catch (e) {} console.error('CDP 未就绪'); process.exit(3); }

const ws = new WebSocket(wsUrl);
let id = 0;
const pending = new Map();
function cmd(method, params) {
  const mid = ++id;
  return new Promise((res, rej) => {
    pending.set(mid, { res, rej });
    ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
  });
}
await new Promise((r) => { ws.onopen = r; });
ws.onmessage = (ev) => {
  let m = null;
  try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.id && pending.has(m.id)) {
    const p = pending.get(m.id); pending.delete(m.id);
    if (m.error) p.rej(new Error(m.error.message)); else p.res(m.result);
  }
};

await cmd('Page.enable');
await cmd('Runtime.enable');
await cmd('Page.navigate', { url: URL_ARG });
await sleep(WAIT);

const expr = 'var e=document.querySelector(' + JSON.stringify(SEL) + '); e?e.textContent:(document.title||"(空)")';
const out = await cmd('Runtime.evaluate', { expression: expr, returnByValue: true });
console.log(out.result && out.result.value ? out.result.value : '(无输出)');

try { ws.close(); } catch (e) {}
try { child.kill(); } catch (e) {}
await sleep(300);
try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) {}
process.exit(0);
