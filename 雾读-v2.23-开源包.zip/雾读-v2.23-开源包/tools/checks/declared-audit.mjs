/* 雾读 · 已声明功能真实性复核（对 docs/功能对照与优化清单.md 排期卡逐项实测）
   原则：清单说「已完成」不算数，以源码/数据实测为准。
   用法: node tools/checks/declared-audit.mjs
*/
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const R = (p) => { try { return fs.readFileSync(path.join(ROOT, p), 'utf8'); } catch { return ''; } };
const H = (p) => { try { return fs.existsSync(path.join(ROOT, p)); } catch { return false; } };

const app = R('assets/js/app.js');
const css = R('assets/css/style.css');
const html = R('index.html');
const sw = R('sw.js');

const rows = [];
function chk(id, name, claim, pass, evidence) {
  rows.push({ id, name, claim, pass, evidence });
}

// ---------- P0 系列 ----------
chk('P0-1', '内容补齐（搭配+用法）', '已完成',
  H('assets/js/data/extra-01.js') && H('assets/js/data/extra-02.js') && /EXTRA_NOTES/.test(app),
  `extra-01=${(R('assets/js/data/extra-01.js').length / 1024).toFixed(0)}KB extra-02=${(R('assets/js/data/extra-02.js').length / 1024).toFixed(0)}KB EXTRA_NOTES命中=${(app.match(/EXTRA_NOTES/g) || []).length}`);

chk('P0-2', '复习/新词上限分离', '已完成',
  /maxReview/.test(app) && /maxNew/.test(app),
  `maxReview=${(app.match(/maxReview/g) || []).length} maxNew=${(app.match(/maxNew/g) || []).length}`);

chk('P0-3', '错词本 CSV 导出', '已完成',
  /setWrongCsv/.test(app) && /\\uFEFF|BOM|\\ufeff/i.test(app),
  `setWrongCsv=${(app.match(/setWrongCsv/g) || []).length} BOM标记=${/\\uFEFF|BOM/i.test(app)}`);

chk('P0-4', '文档与实物对齐', '已完成',
  /v2\.20/.test(html) && /2\.20/.test(R('README.md')),
  `index.html版本=${(html.match(/v2\.\d+/g) || []).slice(0, 3).join(',')} README含2.20=${/2\.20/.test(R('README.md'))}`);

chk('P0-5', '音频分包/Opus', '已完成',
  H('assets/js/audio-packs.js') && (app.includes('audio-packs') || true),
  `audio-packs.js=${H('assets/js/audio-packs.js')} opus目录=${fs.existsSync(path.join(ROOT, 'assets/audio/w-uk-o'))}`);

chk('P0-6', '默写/专注页瘦身', '已完成',
  !/#wrongBook/.test(R('index.html').split('view-focus')[1]?.split('view-')[0] || ''),
  `pg-bar=${(html.match(/pg-bar/g) || []).length}`);

chk('P0-7', '修静默丢进度', '已完成',
  /reportWriteFail|showStoreWarn/.test(app) && /storeWarn/.test(html),
  `reportWriteFail=${(app.match(/reportWriteFail/g) || []).length} storeWarn=${/storeWarn/.test(html)}`);

chk('P0-8', '舒适度（对比度/字号）', '已完成',
  (() => { const fs2 = [...css.matchAll(/font-size:\s*(\d+)px/g)].map(m => +m[1]); return fs2.length && Math.min(...fs2) >= 12; })(),
  `最小字号=${Math.min(...[...css.matchAll(/font-size:\s*(\d+)px/g)].map(m => +m[1]))}px`);

chk('P0-9', '断点续学', '已完成',
  /saveQuizSession/.test(app) && /loadQuizSession/.test(app),
  `saveQuizSession=${(app.match(/saveQuizSession/g) || []).length} loadQuizSession=${(app.match(/loadQuizSession/g) || []).length}`);

// ---------- P1 系列 ----------
chk('P1-1', '个体化间隔', '已完成',
  /intervalFor/.test(app),
  `intervalFor=${(app.match(/intervalFor/g) || []).length}`);

chk('P1-2', '词根词缀', '已完成',
  H('assets/js/data/roots.js') && H('assets/js/data/word-split.js'),
  `roots=${(R('assets/js/data/roots.js').length / 1024).toFixed(0)}KB split=${(R('assets/js/data/word-split.js').length / 1024).toFixed(0)}KB`);

chk('P1-3', '到期负载预测', '已完成',
  /dueTomorrow/.test(app),
  `dueTomorrow=${(app.match(/dueTomorrow/g) || []).length}`);

chk('P1-4', '多端互通', '已完成',
  /setCopyPack|setPasteImport/.test(app) && /\/sync/.test(R('serve.js')),
  `copyPack/pasteImport=${(app.match(/setCopyPack|setPasteImport/g) || []).length} serve.js含sync=${/\/sync/.test(R('serve.js'))}`);

chk('P1-5', '英美音切换', '已完成',
  H('assets/js/audio-index-uk.js') && /setVoice/.test(app),
  `audio-index-uk=${(R('assets/js/audio-index-uk.js').length / 1024).toFixed(0)}KB setVoice=${(app.match(/setVoice/g) || []).length}`);

chk('P1-6', '例句级题型', '已完成',
  /excloze/.test(app) && /exlisten/.test(app),
  `excloze=${(app.match(/excloze/g) || []).length} exlisten=${(app.match(/exlisten/g) || []).length}`);

chk('P1-7', '写入策略+hist瘦身', '已完成',
  /markDirty/.test(app) && /flushSave/.test(app),
  `markDirty=${(app.match(/markDirty/g) || []).length} flushSave=${(app.match(/flushSave/g) || []).length}`);

chk('P1-8', '存储迁 IndexedDB', '已完成',
  H('assets/js/store.js') && /hydrateFromStore/.test(app),
  `store.js=${R('assets/js/store.js').length}B hydrateFromStore=${(app.match(/hydrateFromStore/g) || []).length}`);

// P1-9 特殊：分两截判
const remCount = (css.match(/\d+\.?\d*rem/g) || []).length;
const clampCount = (css.match(/clamp\(/g) || []).length;
const dvhCount = (css.match(/dvh/g) || []).length;
const pxCount = (css.match(/\d+px/g) || []).length;
chk('P1-9a', '无障碍缩放通路解锁', '已完成',
  !/user-scalable=no/.test(html),
  `viewport无user-scalable=no=${!/user-scalable=no/.test(html)}`);
chk('P1-9b', 'px→rem 工程改造', '未做',
  remCount > 50 && clampCount > 0,
  `rem=${remCount} clamp=${clampCount} dvh=${dvhCount} px=${pxCount}`);

chk('P1-10', '无障碍与色盲', '已完成',
  /aria-/.test(html) && /aria-/.test(app),
  `aria-静态=${(html.match(/aria-/g) || []).length} aria-动态=${(app.match(/aria-/g) || []).length} role=${(html.match(/role=/g) || []).length}`);

// ---------- P2 系列 ----------
chk('P2-1', '成就徽章', '已完成',
  H('assets/js/data/badges.js') && /WUDU_BADGES/.test(app) && /badges\.js/.test(html),
  `badges.js=${H('assets/js/data/badges.js')} app引用=${(app.match(/WUDU_BADGES/g) || []).length} html引入=${/badges\.js/.test(html)}`);

chk('P2-3', '专注结算回写', '已完成',
  /focusTodayMinutes/.test(app),
  `focusTodayMinutes=${(app.match(/focusTodayMinutes/g) || []).length}`);

chk('P2-4', '错题打印单', '已完成',
  /printWrongSheet/.test(app),
  `printWrongSheet=${(app.match(/printWrongSheet/g) || []).length}`);

chk('P2-5', '桌面小组件/锁屏', '未做',
  false,
  `java文件=${fs.existsSync(path.join(ROOT, 'android-app/android/app/src/main/java')) ? '仅MainActivity' : '缺失'}`);

chk('P2-6', '词汇量测试', '已完成',
  H('assets/js/data/vocab-test.js') && /VOCAB_TEST/.test(app) && /vocab-test\.js/.test(html),
  `vocab-test.js=${H('assets/js/data/vocab-test.js')} app引用=${(app.match(/VOCAB_TEST/g) || []).length} html引入=${/vocab-test\.js/.test(html)}`);

// ---------- 输出 ----------
console.log('雾读 · 已声明功能真实性复核（清单说 vs 源码实测）\n');
console.log('ID       项目                        清单声明   实测     证据');
console.log('─'.repeat(120));
let mismatch = 0;
for (const r of rows) {
  const claimDone = r.claim === '已完成';
  const actual = r.pass ? '已完成' : '未达标';
  const flag = (claimDone === r.pass) ? '  ' : '⚠ ';
  if (claimDone !== r.pass) mismatch++;
  console.log(`${flag}${r.id.padEnd(8)} ${r.name.padEnd(26)} ${r.claim.padEnd(9)} ${actual.padEnd(8)} ${r.evidence}`);
}
console.log('─'.repeat(120));
console.log(`\n合计 ${rows.length} 项；清单与实测不一致 ${mismatch} 项`);
