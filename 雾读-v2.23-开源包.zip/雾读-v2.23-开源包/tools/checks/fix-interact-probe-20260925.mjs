/* fix-interact-probe-20260925.mjs
   词典从「一排筛选 chip」改成「六个分类页签」之后，interact-probe 的 ① 节还在找 #dictFilter，
   于是 4 项全挂（不是产品坏了，是探针没跟上）。
   改法：① 节改成「点 CET-4 页签」的路子；listWords 支持指定词表容器；metaCount 不再需要。
   每处替换要求「恰好命中 1 次」。
   用法：node tools/checks/fix-interact-probe-20260925.mjs [--dry]
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const F = 'tools/checks/interact-probe.html';

const HELPERS_OLD = `function listWords(d) { return qa(d, '#dictList .word-item .w').map(txt); }
// 真实结果数只写在 #dictMeta 里：列表最多印 300 条，两边都会被截断，条数不能当判据
function metaCount(d) {
  var m = q(d, '#dictMeta');
  var mm = m ? /结果\\s*(\\d+)\\s*词/.exec(m.textContent) : null;
  return mm ? parseInt(mm[1], 10) : -1;
}`;
const HELPERS_NEW = `// 2026-09-25：词典改成六个分类页签，每个分类一个词表容器 —— 取值时要指明是哪一个
function listWords(d, sel) { return qa(d, (sel || '#dictListAll') + ' .word-item .w').map(txt); }`;

const SEC1_OLD = `    log('=== ① 词典筛选条：点「CET-4」，词表必须真的过滤');
    var all = listWords(d);
    var metaAll = metaCount(d);
    var chip4 = q(d, '#dictFilter [data-f="cet4"]');
    ok(!!chip4, '筛选条有「CET-4」');
    if (chip4) { chip4.click(); await sleep(700); }
    var cet4 = listWords(d);
    // 2026-09-25 修判据：原来比「渲染出的条数」，但「全部」与「CET-4」都超过列表 300 条上限，
    // 两边都截断成 300 → 假失败。改读 #dictMeta 里的真实结果数，再核对级别标记。
    var metaCet4 = metaCount(d);
    ok(metaCet4 > 0 && metaCet4 !== metaAll,
      '点「CET-4」后结果数真的变了（筛选生效）', metaAll + ' → ' + metaCet4 + ' 词（列表各印前 300 条）');
    var lvBadges = qa(d, '#dictList .word-item').slice(0, 8).map(function (it) {
      var b = it.querySelector('.badge');
      return b ? txt(b) : '';
    });
    ok(lvBadges.length > 0 && lvBadges.every(function (b) { return b.indexOf('CET') >= 0; }),
      '筛出来的词条级别标记确实都是 CET 词', lvBadges.join(' / '));
    var chipOn = q(d, '#dictFilter [data-f="cet4"].on');
    ok(!!chipOn, '被点的筛选项高亮（.on）');
    var chipAll = q(d, '#dictFilter [data-f="all"]');
    if (chipAll) { chipAll.click(); await sleep(600); }
    ok(listWords(d).length === all.length, '点回「全部」后恢复原条数', listWords(d).length + ' 条');`;

const SEC1_NEW = `    log('=== ① 词典分类页签：点「CET-4」，词表必须真的换成四级词');
    var all = listWords(d, '#dictListAll');
    var chip4 = q(d, '#dictTabs .pg-tab[data-pg="cet4"]');
    ok(!!chip4, '页签里有「CET-4」');
    if (chip4) { chip4.click(); await sleep(800); }
    var cet4 = listWords(d, '#dictListCet4');
    ok(cet4.length > 0, '四级页渲染出自己的词表', cet4.length + ' 条（列表上限 300）');
    var lvBadges = qa(d, '#dictListCet4 .word-item').slice(0, 8).map(function (it) {
      var b = it.querySelector('.badge');
      return b ? txt(b) : '';
    });
    ok(lvBadges.length > 0 && lvBadges.every(function (b) { return b.indexOf('CET') >= 0; }),
      '四级页的词条级别标记确实都是 CET 词', lvBadges.join(' / '));
    var t4 = q(d, '#dictTabs .pg-tab[data-pg="cet4"]');
    ok(!!(t4 && t4.classList.contains('on')), '被点的页签高亮（.on）');
    var chipAll = q(d, '#dictTabs .pg-tab[data-pg="all"]');
    if (chipAll) { chipAll.click(); await sleep(700); }
    ok(listWords(d, '#dictListAll').length === all.length, '点回「全部」后条数恢复',
      listWords(d, '#dictListAll').length + ' 条');`;

const EDITS = [
  { name: 'listWords 带容器参数 / 去掉 metaCount', find: HELPERS_OLD, repl: HELPERS_NEW },
  { name: '① 节改分类页签版', find: SEC1_OLD, repl: SEC1_NEW },
];

let src = fs.readFileSync(F, 'utf8');
let failed = 0;
for (const e of EDITS) {
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  src = src.split(e.find).join(e.repl);
  console.log('\u2713 ' + e.name);
}
if (failed) { console.log('\n未写盘。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
fs.writeFileSync(F, src, 'utf8');
console.log('已写回 ' + F);
const left = (src.match(/dictFilter|dictMeta|metaCount/g) || []).length;
console.log('残留旧引用：' + left + (left === 0 ? '（干净）' : ' ← 还有！'));
