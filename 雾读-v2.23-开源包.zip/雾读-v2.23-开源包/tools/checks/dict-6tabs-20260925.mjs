/* dict-6tabs-20260925.mjs
   昀晞 2026-09-25 定稿的词典结构（「像骨甲升级 UI 那样一层层的」）：
     · 顶层六个平级页签 = 六个功能各自一页：全部 / CET-4 / CET-6 / 收藏 / 已学 / 错词
     · 搜索框只放在「全部」页
     · 搜索 → 弹出**整屏一层**（带「← 返回」）显示结果
     · 点词 → 再弹一层看词条
   每处替换要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/dict-6tabs-20260925.mjs [--dry]   （cwd = 项目根）
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');

/* ---------------- index.html ---------------- */
const HTML_OLD = `        <div class="chip-row" id="dictFilter"></div>
      </div>

      <!-- 词典三段式（2026-09-25 昀晞：词典也要模块化分页，每个功能一页）：
           查词（搜索 + 结果列表）→ 词条（单词的完整详情）→ 真题（关键词在真题里的命中） -->
      <div class="pg-bar" id="dictTabs" role="tablist" aria-label="词典分页">
        <button class="pg-tab on" data-pg="search" role="tab" aria-selected="true" aria-label="搜索查词">🔍 查词</button>
        <button class="pg-tab" data-pg="detail" role="tab" aria-selected="false" aria-label="查看词条">📖 词条</button>
        <button class="pg-tab" data-pg="paper" role="tab" aria-selected="false" aria-label="查看真题命中">📄 真题</button>
      </div>

      <div class="pg-panel on" data-pg-panel="search">
        <div class="search-wrap">
          <div class="search-box">
            <input class="input" id="dictSearch" placeholder="搜索单词 / 中文释义 / 搭配 / 例句…（如 abandon、放弃、give up）" autocomplete="off" aria-label="搜索单词或中文释义">
            <button class="btn" id="dictSearchBtn" aria-label="搜索单词">搜索</button>
          </div>
          <div class="flow-note" id="dictMeta"></div>
        </div>
        <div class="card" style="padding:10px">
          <div class="word-list" id="dictList"></div>
        </div>
      </div>

      <div class="pg-panel" data-pg-panel="detail">
        <div class="card word-detail" id="dictDetail">
          <div class="empty">在「查词」页选一个词，或直接搜索。</div>
        </div>
      </div>

      <div class="pg-panel" data-pg-panel="paper">
        <div class="card" id="dictPaperHits"></div>
      </div>`;

const HTML_NEW = `      </div>

      <!-- 词典：六个功能各自一页（昀晞 2026-09-25「像骨甲升级 UI 那样一层层的」）——
           顶层页签＝分类词表；搜索只在「全部」页；搜索与词条各自弹出整屏一层，带「← 返回」 -->
      <div class="pg-bar" id="dictTabs" role="tablist" aria-label="词典分类">
        <button class="pg-tab on" data-pg="all" role="tab" aria-selected="true" aria-label="查看全部词">📚 全部</button>
        <button class="pg-tab" data-pg="cet4" role="tab" aria-selected="false" aria-label="查看四级词">🎯 CET-4</button>
        <button class="pg-tab" data-pg="cet6" role="tab" aria-selected="false" aria-label="查看六级词">🎯 CET-6</button>
        <button class="pg-tab" data-pg="star" role="tab" aria-selected="false" aria-label="查看收藏词">★ 收藏</button>
        <button class="pg-tab" data-pg="learned" role="tab" aria-selected="false" aria-label="查看已学词">✓ 已学</button>
        <button class="pg-tab" data-pg="wrong" role="tab" aria-selected="false" aria-label="查看错词">✗ 错词</button>
      </div>

      <div class="pg-panel on" data-pg-panel="all">
        <div class="search-wrap">
          <div class="search-box">
            <input class="input" id="dictSearch" placeholder="搜索单词 / 中文释义 / 搭配 / 例句…（如 abandon、放弃、give up）" autocomplete="off" aria-label="搜索单词或中文释义">
            <button class="btn" id="dictSearchBtn" aria-label="搜索单词">搜索</button>
          </div>
        </div>
        <div class="card" style="padding:10px">
          <div class="word-list" id="dictListAll"></div>
        </div>
      </div>

      <div class="pg-panel" data-pg-panel="cet4"><div class="card" style="padding:10px"><div class="word-list" id="dictListCet4"></div></div></div>
      <div class="pg-panel" data-pg-panel="cet6"><div class="card" style="padding:10px"><div class="word-list" id="dictListCet6"></div></div></div>
      <div class="pg-panel" data-pg-panel="star"><div class="card" style="padding:10px"><div class="word-list" id="dictListStar"></div></div></div>
      <div class="pg-panel" data-pg-panel="learned"><div class="card" style="padding:10px"><div class="word-list" id="dictListLearned"></div></div></div>
      <div class="pg-panel" data-pg-panel="wrong"><div class="card" style="padding:10px"><div class="word-list" id="dictListWrong"></div></div></div>

      <!-- 弹出层 1：搜索结果（整屏一层） -->
      <div class="dict-layer" id="dictSearchLayer" hidden>
        <div class="dict-layer-head">
          <button class="btn sm ghost" id="dictSearchBack" aria-label="返回词典">← 返回</button>
          <b id="dictSearchTitle">搜索结果</b>
        </div>
        <div class="card" style="padding:10px"><div class="word-list" id="dictListSearch"></div></div>
        <div class="card" id="dictPaperHits" style="margin-top:12px"></div>
      </div>

      <!-- 弹出层 2：词条详情（再一层） -->
      <div class="dict-layer" id="dictWordLayer" hidden>
        <div class="dict-layer-head">
          <button class="btn sm ghost" id="dictWordBack" aria-label="返回上一页">← 返回</button>
          <b>词条</b>
        </div>
        <div class="card word-detail" id="dictDetail"></div>
      </div>`;

/* ---------------- app.js ---------------- */
const JS_SEARCH_OLD = `  /* 搜索入口：搜索时自动把分类切回「全部」，避免被筛选条件挡住结果 */
  function runDictSearch(q) {
    dictState.q = q;
    if (String(q || '').trim()) dictState.level = 'all';
    renderDict();
  }

  function renderDict() {
    var filters = [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6'], ['star', '收藏'], ['learned', '已学'], ['wrong', '错词']];
    $('#dictFilter').innerHTML = filters.map(function (f) {
      return '<button class="chip' + (dictState.level === f[0] ? ' on' : '') + '" data-f="' + f[0] + '">' + f[1] + '</button>';
    }).join('');

    var scored = WORDS.map(function (w) { return { w: w, sc: dictScore(w, dictState.q) }; })
      .filter(function (x) {
        var w = x.w;
        if (dictState.level === 'cet4' || dictState.level === 'cet6') {
          if (String(w.level).split(',').indexOf(dictState.level) < 0) return false;   // 双级词两边都要出现
        }
        if (dictState.level === 'learned') { if (!progress[w.w] || !progress[w.w].seen) return false; }
        if (dictState.level === 'star') { if (!progress[w.w] || !progress[w.w].star) return false; }
        if (dictState.level === 'wrong') { if (!progress[w.w] || !progress[w.w].wrong) return false; }
        return x.sc > 0;
      });
    if (dictState.q) scored.sort(function (a, b) { return b.sc - a.sc; });
    var scoreOf = {};
    scored.forEach(function (x) { scoreOf[x.w.w] = x.sc; });
    var list = scored.map(function (x) { return x.w; });

    $('#dictMeta').textContent = '结果 ' + list.length + ' 词' +
      (dictState.q ? '（关键词「' + dictState.q + '」· 按相关度排序，最贴合的在最上面）' : '') +
      ' · 全库共 ' + WORDS.length + ' 词' +
      (list.length > 300 ? ' · 列表只显示前 300 条，直接搜更快' : '');

    var show = list.slice(0, 300);
    $('#dictList').innerHTML = show.length ? show.map(function (w) {
      var r = pRec(w.w);
      var mark = r ? (r.s >= MASTER_STAGE ? ' <span class="badge good">已掌握</span>' : (r.wrong ? ' <span class="badge bad">错过</span>' : '')) : '';
      return '<div class="word-item' + (dictState.picked === w.w ? ' on' : '') + '" data-w="' + w.w + '">' +
        '<span><span class="w">' + hi(w.w, dictState.q) + '</span> <span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span>' + mark +
        (dictState.q && scoreOf[w.w] ? ' <span class="badge due">' + hitLabel(scoreOf[w.w]) + '</span>' : '') + '</span>' +
        '<span class="c">' + hi(w.cn, dictState.q) + '</span></div>';
    }).join('') : '<div class="empty">没有符合条件的词。搜「放弃」「abandon」或搭配试一试。</div>';

    // 分页（2026-09-25 昀晞：词典也要模块化分页，每个功能一页）——
    // 「查词」页管搜索与结果列表，「词条」页管详情，不再靠宽/窄屏两套显示逻辑。
    var wide = window.innerWidth >= 901;
    if (wide && !dictState.picked && show.length) dictState.picked = show[0].w;
    if (dictState.picked) renderWordDetail(dictState.picked);
    else $('#dictDetail').innerHTML = '<div class="empty">在「查词」页选一个词，或直接搜索。</div>';
    renderPaperHits(dictState.q);
  }`;

const JS_SEARCH_NEW = `  /* ---------------- 词典：六个功能各自一页 + 两层弹出 ----------------
     昀晞 2026-09-25 定稿：
       · 顶层页签即分类（全部 / CET-4 / CET-6 / 收藏 / 已学 / 错词），一页一个词表
       · 搜索框只在「全部」页
       · 搜索 → 弹整屏一层（#dictSearchLayer）看结果
       · 点词 → 再弹一层（#dictWordLayer）看词条
     分类靠页签而不是靠一排 chip：切页=换列表，不再在同一页里叠筛选条件。 */
  var DICT_LIST_ID = {
    all: '#dictListAll', cet4: '#dictListCet4', cet6: '#dictListCet6',
    star: '#dictListStar', learned: '#dictListLearned', wrong: '#dictListWrong'
  };
  var DICT_EMPTY = {
    all: '词库是空的（不应该发生，报一下）',
    cet4: '四级词还没载入',
    cet6: '六级词还没载入',
    star: '还没有收藏的词 —— 打开任意词条，点「☆ 收藏」就会出现在这里',
    learned: '还没有学过的词 —— 去默写或真题里走一轮，这里就有内容了',
    wrong: '错词本是空的 —— 保持住'
  };

  function dictMatch(level, w) {
    if (level === 'cet4' || level === 'cet6') return String(w.level).split(',').indexOf(level) >= 0;  // 双级词两边都出现
    if (level === 'learned') return !!(progress[w.w] && progress[w.w].seen);
    if (level === 'star') return !!(progress[w.w] && progress[w.w].star);
    if (level === 'wrong') return !!(progress[w.w] && progress[w.w].wrong);
    return true;
  }

  /* 渲染某一类的词表，返回**真实命中总数**（列表最多印 300 条，条数不能当判据） */
  function renderDictList(level, hostSel, q) {
    var host = $(hostSel);
    if (!host) return 0;
    var kw = String(q || '').trim();
    var scoreOf = {};
    var list = WORDS.filter(function (w) { return dictMatch(level, w); })
      .filter(function (w) { var sc = dictScore(w, kw); if (sc <= 0) return false; scoreOf[w.w] = sc; return true; });
    if (kw) list.sort(function (a, b) { return scoreOf[b.w] - scoreOf[a.w]; });
    var show = list.slice(0, 300);
    host.innerHTML = show.length ? show.map(function (w) {
      var r = pRec(w.w);
      var mark = r ? (r.s >= MASTER_STAGE ? ' <span class="badge good">已掌握</span>' : (r.wrong ? ' <span class="badge bad">错过</span>' : '')) : '';
      return '<div class="word-item' + (dictState.picked === w.w ? ' on' : '') + '" data-w="' + w.w + '">' +
        '<span><span class="w">' + hi(w.w, kw) + '</span> <span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span>' + mark +
        (kw && scoreOf[w.w] ? ' <span class="badge due">' + hitLabel(scoreOf[w.w]) + '</span>' : '') + '</span>' +
        '<span class="c">' + hi(w.cn, kw) + '</span></div>';
    }).join('') : '<div class="empty">' + (kw ? '没有符合条件的词 —— 换个说法、或用搭配（give up）再试。' : (DICT_EMPTY[level] || '这里还没有词')) + '</div>';
    return list.length;
  }

  /* 词典主页：只渲染当前页签那一类 */
  function renderDict() {
    var level = pgCurrent('#dictTabs') || 'all';
    if (DICT_LIST_ID[level]) {
      dictState.level = level;
      renderDictList(level, DICT_LIST_ID[level], '');
    }
    return level;
  }

  /* 弹出层：搜索层 / 词条层 —— 整屏一层，顶部带「← 返回」 */
  function openDictLayer(sel) {
    var el = $(sel);
    if (!el) return;
    el.hidden = false;
    try { el.scrollTop = 0; } catch (e) {}
  }
  function closeDictLayer(sel) {
    var el = $(sel);
    if (el) el.hidden = true;
  }
  function anyDictLayerOpen() {
    var a = $('#dictSearchLayer'), b = $('#dictWordLayer');
    return !!((a && !a.hidden) || (b && !b.hidden));
  }

  /* 搜索入口（只有「全部」页有搜索框）：弹出搜索结果层 */
  function runDictSearch(q) {
    var kw = String(q || '').trim();
    if (!kw) { toast('先输入要查的词或中文'); return; }
    dictState.q = kw;
    var n = renderDictList('all', '#dictListSearch', kw);
    var title = $('#dictSearchTitle');
    if (title) title.textContent = '「' + kw + '」· ' + n + ' 条结果' + (n > 300 ? '（列表印前 300 条）' : '');
    renderPaperHits(kw);
    openDictLayer('#dictSearchLayer');
  }`;

const JS_PAPER_OLD = `    // 2026-09-25 分页化：真题命中成了独立一页，不再用 display 控制显隐
    if (kw.length < 2) {
      host.innerHTML = '<div class="empty">在「查词」页搜一个词，这里会列出它在历年真题里的出现位置。</div>';
      return;
    }`;
const JS_PAPER_NEW = `    // 2026-09-25：真题命中挂在搜索结果层里，跟着关键词走
    if (kw.length < 2) {
      host.innerHTML = '';
      return;
    }`;

const JS_ROOTWORD_OLD = `        if (!hostSel) pgGo('#dictTabs', 'detail');   // 词典页里点同根词 → 直接切到「词条」页`;
const JS_ROOTWORD_NEW = `        if (!hostSel) openDictLayer('#dictWordLayer');   // 词典页里点同根词 → 就在词条层里换词`;

const JS_CLOSE_OLD = `  /* 从「词条」页退回「查词」页（页签化之后的返回） */
  function closeWordDetail() {
    dictState.detailOpen = false;
    pgGo('#dictTabs', 'search');
    resetScroll();
  }`;
const JS_CLOSE_NEW = `  /* 关掉词条层，回到下面那一层（可能是搜索层，也可能是词典主页） */
  function closeWordDetail() {
    dictState.detailOpen = false;
    closeDictLayer('#dictWordLayer');
    resetScroll();
  }`;

const JS_BACK_OLD = `    if (cur === 'dict' && pgCurrent('#dictTabs') === 'detail') { closeWordDetail(); return 'handled'; }`;
const JS_BACK_NEW = `    if (cur === 'dict' && anyDictLayerOpen()) {          // 词典：先关层，再谈其他
      if ($('#dictWordLayer') && !$('#dictWordLayer').hidden) closeWordDetail();
      else closeDictLayer('#dictSearchLayer');
      return 'handled';
    }`;

const JS_BIND_OLD = `    $('#dictFilter').addEventListener('click', function (e) {
      var c = e.target.closest('[data-f]'); if (!c) return;
      dictState.level = c.dataset.f; renderDict();
    });
    $('#dictList').addEventListener('click', function (e) {
      var it = e.target.closest('.word-item'); if (!it) return;
      dictState.picked = it.dataset.w;
      dictState.detailOpen = true;
      renderDict();
      pgGo('#dictTabs', 'detail');            // 点词 → 直接切到「词条」页
      resetScroll();
    });`;
const JS_BIND_NEW = `    // 切页签 → 重渲染那一类（bindPg 已经把 .on 切好，这里只管内容）
    $('#dictTabs').addEventListener('click', function (e) {
      if (!e.target.closest('[data-pg]')) return;
      renderDict();
    });
    // 点词 → 弹词条层。委托到整个词典区，主页表与搜索结果表共用一套逻辑。
    $('#view-dict').addEventListener('click', function (e) {
      var it = e.target.closest('.word-item'); if (!it || !it.dataset.w) return;
      dictState.picked = it.dataset.w;
      dictState.detailOpen = true;
      renderWordDetail(it.dataset.w);
      openDictLayer('#dictWordLayer');
    });
    var dsb = $('#dictSearchBack');
    if (dsb) dsb.onclick = function () { closeDictLayer('#dictSearchLayer'); };
    var dwb = $('#dictWordBack');
    if (dwb) dwb.onclick = closeWordDetail;`;

/* ---------------- style.css ---------------- */
const CSS_OLD = `.word-list { max-height: 68vh; overflow: auto; padding-right: 4px; }`;
const CSS_NEW = `/* 词典弹出层（昀晞 2026-09-25：搜索与词条各弹整屏一层，顶部带「← 返回」） */
.dict-layer {
  position: fixed; left: 0; right: 0; top: 0; bottom: 0; z-index: 60;
  background: var(--bg); overflow: auto; padding: 12px 14px 28px;
}
.dict-layer[hidden] { display: none; }
.dict-layer-head { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.dict-layer-head b { font-size: 15px; }

.word-list { max-height: 68vh; overflow: auto; padding-right: 4px; }`;

const EDITS = [
  { file: 'index.html', name: '词典六页签 + 两层弹出（结构）', find: HTML_OLD, repl: HTML_NEW },
  { file: 'assets/js/app.js', name: '词典渲染与搜索（实现）', find: JS_SEARCH_OLD, repl: JS_SEARCH_NEW },
  { file: 'assets/js/app.js', name: '真题命中改挂搜索层', find: JS_PAPER_OLD, repl: JS_PAPER_NEW },
  { file: 'assets/js/app.js', name: '同根词点击走层', find: JS_ROOTWORD_OLD, repl: JS_ROOTWORD_NEW },
  { file: 'assets/js/app.js', name: 'closeWordDetail 关层', find: JS_CLOSE_OLD, repl: JS_CLOSE_NEW },
  { file: 'assets/js/app.js', name: '安卓返回键先关层', find: JS_BACK_OLD, repl: JS_BACK_NEW },
  { file: 'assets/js/app.js', name: '事件绑定：页签重渲染 + 点词弹层', find: JS_BIND_OLD, repl: JS_BIND_NEW },
  { file: 'assets/css/style.css', name: '弹出层样式', find: CSS_OLD, repl: CSS_NEW },
];

let failed = 0;
const cache = new Map();
function read(f) { if (!cache.has(f)) cache.set(f, fs.readFileSync(f, 'utf8')); return cache.get(f); }

for (const e of EDITS) {
  const src = read(e.file);
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 [' + e.file + '] ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  cache.set(e.file, src.split(e.find).join(e.repl));
  console.log('\u2713 [' + e.file + '] ' + e.name);
}

if (failed) { console.log('\n有 ' + failed + ' 处不满足条件，未写任何文件。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
for (const [f, s] of cache) { fs.writeFileSync(f, s, 'utf8'); console.log('已写回 ' + f); }

const js = fs.readFileSync('assets/js/app.js', 'utf8');
const html = fs.readFileSync('index.html', 'utf8');
console.log('\n残留旧引用：dictFilter=' + (js.match(/dictFilter/g) || []).length +
  ' · #dictList（旧 id）=' + (js.match(/'#dictList'/g) || []).length +
  ' · dictMeta=' + (js.match(/dictMeta/g) || []).length);
console.log('index.html 里 dictFilter=' + (html.match(/dictFilter/g) || []).length +
  ' · dictTabs 页签数=' + (html.match(/id="dictTabs"[\s\S]*?<\/div>/)[0].match(/pg-tab/g) || []).length);
