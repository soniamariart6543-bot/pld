/* fix-a11y-tabs-20260925.mjs
   背景：T6 全站多页化新增了 6 个分页条（realTabs / lsTabs / grammarTabs / trTabs / wrTabs / planTabs），
   共 13 个 .pg-tab，漏了 aria-label —— a11y-check.mjs 的「全部按钮都有 aria-label」判定因此报缺口。
   本脚本按原有页签的风格（「查看XX」「进入XX」）补上，且只动能匹配到映射表的页签，不动其余。
   用法：node tools/checks/fix-a11y-tabs-20260925.mjs [--dry]   （cwd = 项目根）
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const FILE = 'index.html';

// 页签可见文字 → aria-label（按原有 L74 起「查看今日/查看进度」的措辞风格）
const MAP = {
  '📚 选卷': '选择试卷',
  '✍ 作答': '进入作答',
  '🎧 听材料': '进入听力',
  '✍ 答题': '进入答题',
  '📄 原文': '查看原文',
  '📚 选题': '选择题库',
  '✍ 写作': '进入写作',
  '⚙ 设置': '打开设置',
  '📊 计划': '查看学习计划',
};

const src = fs.readFileSync(FILE, 'utf8');
let changed = 0;
const skipped = [];

const out = src.replace(
  /<button class="pg-tab([^"]*)"([^>]*)>([^<]+)<\/button>/g,
  (m, cls, attrs, text) => {
    if (/aria-label/.test(attrs)) return m;          // 已有 aria-label：不动
    const label = MAP[text.trim()];
    if (!label) { skipped.push(text.trim()); return m; }  // 映射表没有：不动，只记下
    changed++;
    return '<button class="pg-tab' + cls + '"' + attrs + ' aria-label="' + label + '">' + text + '</button>';
  }
);

console.log('待补 aria-label 的页签：' + changed + ' 个');
if (skipped.length) console.log('未在映射表中、原样保留：' + [...new Set(skipped)].join(' / '));

if (DRY) {
  console.log('（--dry：未写盘）');
} else if (changed === 0) {
  console.log('没有可改的，未写盘。');
} else {
  fs.writeFileSync(FILE, out, 'utf8');
  const after = fs.readFileSync(FILE, 'utf8');
  const total = (after.match(/class="pg-tab/g) || []).length;
  const withLabel = (after.match(/class="pg-tab[^>]*aria-label/g) || []).length;
  console.log('已写回 ' + FILE);
  console.log('写后统计：pg-tab 共 ' + total + ' 个，其中带 aria-label ' + withLabel + ' 个');
}
