/* 雾读 · 判定函数 judge() 真实用例回归
   方法：不从 app.js 抄一份，而是把原函数（含其依赖）抽出来实跑，测的是线上逻辑。
   用法：cd 项目\四六级单词 && node tools/checks/judge-cases.mjs
   产出于 2026-09-25（T056 步骤②遗留的「判定函数需人工确认」项，本次落实为可复跑用例） */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const ROOT = path.resolve(import.meta.dirname, '..', '..');
const SRC = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');

function grab(name) {
  const i = SRC.indexOf('function ' + name + '(');
  if (i < 0) return '';
  let d = 0, k = SRC.indexOf('{', i);
  for (; k < SRC.length; k++) {
    if (SRC[k] === '{') d++;
    else if (SRC[k] === '}') { d--; if (d === 0) { k++; break; } }
  }
  return SRC.slice(i, k);
}

// 注意：norm 是 judge 的内部依赖（app.js L181 `function norm(s)`）——
// 漏抽它会让**所有**用例抛 "norm is not defined"，看着像 9 个产品缺陷，其实是探针缺陷。
const DEPS = ['norm', 'stems', 'normalizeAns', 'looseEq', 'lev', 'variantForms', 'judge'];
const tmp = path.join(ROOT, '_tmp_judge.cjs');
let code = '';
for (const n of DEPS) {
  const f = grab(n);
  if (!f) { console.error('抽取失败：' + n); process.exit(2); }
  code += f + '\n';
}
// 自证检测方法有效：必须有 5 个函数且能返回结果
code += 'module.exports={judge,normalizeAns,variantForms,looseEq,lev};';
fs.writeFileSync(tmp, code);
const require = createRequire(import.meta.url);
let M;
try { M = require(tmp); } finally { fs.unlinkSync(tmp); }
if (typeof M.judge !== 'function') { console.error('judge 抽取后不可调用 → 检测方法无效'); process.exit(2); }

// exp：true=应判对 / false=应判错 / null=口径待定（只记录当前行为，不计入通过失败）
// 2026-09-25 实测修正：原两条写 exp=true、注释假设「d=1」，但 receive→recieve 是**相邻换位**，
// 标准 Levenshtein 距离是 2（不是 1），所以按「差一字母算接近」的口径必然判错。
// 这是**判分口径**问题不是 bug：要判对就得放宽规则，交昀晞定，故标 null。
const CASES = [
  ['colour', 'color', true, '英式拼写变体'],
  ['cities', 'city', true, '复数'],
  ['study', 'study', true, '完全一致'],
  // 口径已定（昀晞 2026-09-25 拍板）：经典换位错**算错** —— 「背单词的目的就是拼对」。
  // 背景：receive→recieve 是相邻换位，标准 Levenshtein 距离是 2（不是 1），
  // 按「词长≥5 差一字母算接近」的口径必然判错；此前的用例注释把它当成 d=1 才写成期望「对」。
  ['recieve', 'receive', false, '经典换位错（lev=2，口径=算错）'],
  ['recievee', 'receive', false, '换位+后缀多加（lev=3）'],
  ['recievingxyz', 'receive', false, '差距过大应判错'],
  ['', 'word', false, '空输入'],
  ['  Word  ', 'word', true, '首尾空格'],
  ['analyse', 'analyze', true, '英美变体2'],
  ['economies', 'economy', true, '复数+词干'],
  ['sheep', 'sheep', true, '单复数同形'],
  ['abandon', 'abandonment', false, '派生词不应判对'],
  ['ECONOMY', 'economy', true, '全大写'],
  ['e c o n o m y', 'economy', true, '中间夹空格'],
];

let pass = 0, fail = 0, pending = 0;
for (const [inp, ans, exp, desc] of CASES) {
  let r;
  try { r = M.judge(inp, ans); }
  catch (e) {
    // 自证环节：依赖没抽全会抛 "xxx is not defined" —— 那是**探针**的问题，不是产品的问题。
    // 必须区分开，否则会像上一版那样把「探针漏抽依赖」报成 9 个用例失败。
    if (/is not defined/.test(e.message)) {
      console.error('\n✗ 探针缺依赖：' + e.message);
      console.error('  → 把该函数名补进本文件顶部的 DEPS 数组（这是探针缺陷，不等于产品缺陷）');
      process.exit(2);
    }
    console.log('异常 ' + desc + '：' + e.message); fail++; continue;
  }
  if (exp === null) {
    pending++;
    console.log('? ' + desc.padEnd(16, '　') +
      ' judge("' + inp + '","' + ans + '") → ok=' + r.ok + ' kind=' + r.kind + ' dist=' + r.dist +
      '（口径待定，不计入）');
    continue;
  }
  const ok = r.ok === exp;
  if (ok) pass++; else fail++;
  console.log((ok ? '✓' : '✗') + ' ' + desc.padEnd(16, '　') +
    ' judge("' + inp + '","' + ans + '") → ok=' + r.ok + ' kind=' + r.kind + ' dist=' + r.dist +
    '（期望' + (exp ? '对' : '错') + '）');
}
console.log('\n—— 判定用例 ' + pass + ' 通过 / ' + fail + ' 失败 / ' + pending + ' 待定 ——');
console.log('RESULT: ' + (fail ? fail + ' FAILED' : 'ALL PASS') + (pending ? '（另有 ' + pending + ' 条口径待定）' : ''));
process.exit(fail ? 1 : 0);
