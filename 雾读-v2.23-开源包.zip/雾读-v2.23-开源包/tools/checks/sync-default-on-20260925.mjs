/* sync-default-on-20260925.mjs
   昀晞 2026-09-25：「局域网改一下，电脑网页与APP分开，我要求可以直接在html沟通数据」+「只改网页」
   → 追问后选定：**默认就能互通（把同步做顺）**。APP 一行不动，只改网页侧。

   做三件事：
     ① serve.js 的 /sync 端点**默认开**（原来要 --sync），--no-sync 可关。
     ② /sync/ping 对**本机来源**（127.0.0.1 / ::1）额外回配对码 —— 电脑上打开的网页自动拿到，
        不用再手输；局域网里的手机拿不到码，仍按原流程手填（安全边界不放宽）。
     ③ 网页设置页：新增「🔁 一键互传」（先拉后推，一步到位），配对码输入框降级成兜底。

   每处替换要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/sync-default-on-20260925.mjs [--dry]
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const S = 'serve.js', H = 'index.html', J = 'assets/js/app.js';

/* ---------- serve.js ---------- */
const S1_OLD = `   用法：node serve.js [端口] [--sync] [--lan]
     --sync  打开多端互通端点 /sync（清单 P1-4），默认关闭
     --lan   把监听地址从 127.0.0.1 扩到本机局域网 IP（**绝不绑 0.0.0.0**），
             开了这个手机才能连过来；务必只在可信 Wi-Fi 下用`;
const S1_NEW = `   用法：node serve.js [端口] [--lan] [--no-sync]
     --lan      把监听地址从 127.0.0.1 扩到本机局域网 IP（**绝不绑 0.0.0.0**），
                开了这个手机才能连过来；务必只在可信 Wi-Fi 下用
     --no-sync  关掉多端互通端点 /sync（**默认是开的**：绑 127.0.0.1 时外面本来就进不来，
                绑局域网时仍要配对码才能读写）`;

const S2_OLD = `const SYNC_ON = process.argv.includes('--sync');`;
const S2_NEW = `const SYNC_ON = !process.argv.includes('--no-sync');   // 2026-09-25 昀晞「默认就能互通」：默认开，--no-sync 关`;

const S3_OLD = `/* ---------- P1-4 多端互通端点（默认关，--sync 才开） ----------`;
const S3_NEW = `/* ---------- P1-4 多端互通端点（2026-09-25 起默认开，--no-sync 关） ----------`;

const S4_OLD = `  if (urlPath === '/sync/ping') {
    sendJSON(res, 200, { on: SYNC_ON, host: HOST, port: PORT });
    return;
  }`;
const S4_NEW = `  if (urlPath === '/sync/ping') {
    // 2026-09-25 昀晞「默认就能互通」：电脑上打开的网页自动拿到配对码，省掉手输这一步。
    // 只回给**本机来源**（127.0.0.1 / ::1）—— 局域网里的手机拿不到码，仍要按原流程手填。
    const ip = String((req.socket && req.socket.remoteAddress) || '');
    const fromLocal = ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
    const out = { on: SYNC_ON, host: HOST, port: PORT };
    if (SYNC_ON && fromLocal) out.code = PAIR_CODE;
    sendJSON(res, 200, out);
    return;
  }`;

const S5_OLD = `  if (SYNC_ON) console.log('跨端同步已开 · 配对码：' + PAIR_CODE + '（只写在控制台，不落盘）');
  if (LAN_ON) {
    console.log('⚠ 局域网模式：同一 Wi-Fi 下手机可以打开上面这个地址（务必只在可信 Wi-Fi 下用）');
  } else {
    console.log('（仅本机可访问；要让手机连过来加 --lan，要开跨端同步加 --sync）');
  }`;
const S5_NEW = `  if (SYNC_ON) console.log('多端互通已开 · 配对码：' + PAIR_CODE + '（电脑上打开的网页会自动带上，不用手输；只写在控制台，不落盘）');
  else console.log('多端互通已关（--no-sync）');
  if (LAN_ON) {
    console.log('⚠ 局域网模式：同一 Wi-Fi 下手机可以打开上面这个地址（务必只在可信 Wi-Fi 下用）');
  } else {
    console.log('（仅本机可访问；要让手机连过来加 --lan）');
  }`;

/* ---------- index.html ---------- */
const H1_OLD = `        <!-- P1-4 多端互通（局域网直传）：电脑上 node serve.js 8899 --sync --lan，手机连同一个 Wi-Fi 打开电脑给的地址 -->
        <div class="set-row" id="setSyncBox">
          <span class="set-label">局域网直传<small>电脑上跑 <code>node serve.js 8899 --sync --lan</code>，手机用电脑给的地址打开本页，两边就能对传（走局域网，不碰公网）</small></span>
          <span class="row" style="gap:6px">
            <button class="btn sm" id="setSyncPush" aria-label="把本机数据上传到电脑">⬆ 传到电脑</button>
            <button class="btn sm" id="setSyncPull" aria-label="从电脑拉取并合并数据">⬇ 从电脑取</button>
          </span>
        </div>
        <div class="set-row">
          <span class="set-label">配对码<small>电脑控制台启动时打印的 6 位数字，每次启动都不一样</small></span>
          <input class="input" id="setSyncCode" inputmode="numeric" maxlength="6" placeholder="6 位数字" style="max-width:140px" aria-label="同步配对码">
        </div>`;
const H1_NEW = `        <!-- P1-4 多端互通（局域网直传）：电脑上 node serve.js 8899 --lan，手机连同一个 Wi-Fi 打开电脑给的地址。
             2026-09-25 昀晞：默认就能互通 —— 电脑上打开的网页配对码自动带上，点一下「一键互传」即可。 -->
        <div class="set-row" id="setSyncBox">
          <span class="set-label">多端互通<small>电脑上跑 <code>node serve.js 8899 --lan</code>，手机连同一 Wi-Fi 打开电脑给的地址 —— 点「🔁 一键互传」就把两边进度并在了一起（走局域网，不碰公网）</small></span>
          <span class="row" style="gap:6px">
            <button class="btn sm primary" id="setSyncBoth" aria-label="与另一端互传并合并数据">🔁 一键互传</button>
            <button class="btn sm" id="setSyncPush" aria-label="只把本机数据上传">⬆ 只上传</button>
            <button class="btn sm" id="setSyncPull" aria-label="只从电脑拉取并合并">⬇ 只拉取</button>
          </span>
        </div>
        <div class="set-row">
          <span class="set-label">配对码<small>电脑上打开的网页会自动带上，<b>通常不用填</b>；只有在手机浏览器里访问时才需要照控制台那 6 位填一次</small></span>
          <input class="input" id="setSyncCode" inputmode="numeric" maxlength="6" placeholder="自动" style="max-width:140px" aria-label="同步配对码">
        </div>`;

/* ---------- app.js ---------- */
const J1_OLD = `    /* ---------- P1-4 局域网直传（同源、不碰公网） ----------
       电脑上：node serve.js 8899 --sync --lan → 控制台给出配对码；
       手机用电脑给的局域网地址打开本页（同一 Wi-Fi），两边同源就能对传。
       合并策略：同一个词谁学得更晚用谁的 —— 不做整包覆盖，免得新进度被旧包冲掉。 */
    function syncCode() {
      var c = $('#setSyncCode');
      return c ? String(c.value || '').trim() : '';
    }`;
const J1_NEW = `    /* ---------- P1-4 多端互通（局域网直传，同源、不碰公网） ----------
       2026-09-25 昀晞「默认就能互通」：
         · 电脑上：node serve.js 8899 --lan（/sync 端点默认开）
         · 电脑上打开的网页，服务端会把配对码自动告诉它（只回给本机来源）→ 不用手输
         · 手机连同一 Wi-Fi 打开电脑给的地址，点「🔁 一键互传」即可
       合并策略：同一个词谁学得更晚用谁的 —— 不做整包覆盖，免得新进度被旧包冲掉。 */
    var syncAutoCode = '';   // 服务端自动给的配对码（只在本机来源时会给）
    function syncCode() {
      var c = $('#setSyncCode');
      var typed = c ? String(c.value || '').trim() : '';
      return typed || syncAutoCode;   // 手输的优先（手机端），其次用自动拿到的（电脑端）
    }`;

const J2_OLD = `        .then(function (j) {
          if (!host) return;
          if (j && j.on) syncNote('电脑端同步已开（' + j.host + ':' + j.port + '）—— 填上控制台打印的配对码就能对传');
          else if (j) syncNote('电脑端跑着服务但没开同步：启动时加 --sync');
          else syncNote('这台设备不是从电脑端服务打开的（手机要和电脑同一 Wi-Fi，并用电脑给的地址打开本页）');
        })`;
const J2_NEW = `        .then(function (j) {
          if (!host) return;
          if (j && j.on) {
            if (j.code) {
              // 本机来源：服务端把配对码直接给了 —— 填进框里看得见、可改，也当成默认码用
              syncAutoCode = String(j.code);
              var cEl = $('#setSyncCode');
              if (cEl && !cEl.value) cEl.value = syncAutoCode;
              syncNote('已连上电脑端（' + j.host + ':' + j.port + '）· 配对码已自动带上，点「🔁 一键互传」就行');
            } else {
              syncNote('电脑端同步已开（' + j.host + ':' + j.port + '）—— 填上控制台打印的配对码就能对传');
            }
          } else if (j) syncNote('电脑端跑着服务但同步被关了：启动时去掉 --no-sync');
          else syncNote('这台设备不是从电脑端服务打开的（手机要和电脑同一 Wi-Fi，并用电脑给的地址打开本页）');
        })`;

const J3_OLD = `    var sPush = $('#setSyncPush'), sPull = $('#setSyncPull');`;
const J3_NEW = `    /* 一键互传：先拉（把另一端的进度并进来）再推（把合并后的整包发回去），
       省掉「先点取、再点传」两步。合并仍走 mergeIntoPack 的「谁学得晚用谁」。 */
    var sBoth = $('#setSyncBoth');
    if (sBoth) sBoth.onclick = function () {
      if (!syncCode()) { toast('还没拿到配对码 —— 确认电脑端服务开着，或手动填控制台那 6 位'); return; }
      toast('正在与另一端互传…');
      syncCall('/sync/latest').then(function (j) {
        var pack = null;
        try { pack = JSON.parse(j.data); } catch (e) { throw new Error('文件不是合法 JSON'); }
        var r = mergeIntoPack(pack) || { fresh: 0, merged: 0 };
        saveAll();
        return syncCall('/sync/put', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(buildPack())
        }).then(function (p) {
          renderHome(); renderPlan(); renderSettings();
          syncNote('互传完成：并入 ' + r.fresh + ' 新词 / 更新 ' + r.merged + ' 词，再把本机 ' + p.words + ' 条推了回去');
          toast('已互传');
        });
      }).catch(function (e) {
        syncNote('互传失败：' + e.message, true);
        toast('互传失败：' + e.message);
      });
    };
    var sPush = $('#setSyncPush'), sPull = $('#setSyncPull');`;

const EDITS = [
  { file: S, name: 'serve.js 用法注释', find: S1_OLD, repl: S1_NEW },
  { file: S, name: 'SYNC 默认开', find: S2_OLD, repl: S2_NEW },
  { file: S, name: '端点段注释', find: S3_OLD, repl: S3_NEW },
  { file: S, name: 'ping 对本机回配对码', find: S4_OLD, repl: S4_NEW },
  { file: S, name: '启动提示', find: S5_OLD, repl: S5_NEW },
  { file: H, name: '设置页同步区 + 一键互传按钮', find: H1_OLD, repl: H1_NEW },
  { file: J, name: 'syncCode 支持自动码', find: J1_OLD, repl: J1_NEW },
  { file: J, name: 'syncProbe 自动记码', find: J2_OLD, repl: J2_NEW },
  { file: J, name: '一键互传处理', find: J3_OLD, repl: J3_NEW },
];

let failed = 0;
const cache = new Map();
function read(f) { if (!cache.has(f)) cache.set(f, fs.readFileSync(f, 'utf8')); return cache.get(f); }

for (const e of EDITS) {
  const src = read(e.file);
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 [' + e.file + '] ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  cache.set(e.file, src.split(e.find).join(e.repl));
  console.log('\u2713 [' + e.file + '] ' + e.name);
}
if (failed) { console.log('\n有 ' + failed + ' 处不满足条件，未写任何文件。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
for (const [f, s] of cache) { fs.writeFileSync(f, s, 'utf8'); console.log('已写回 ' + f); }

const js = fs.readFileSync(J, 'utf8');
const sv = fs.readFileSync(S, 'utf8');
console.log('\n残留检查：--sync（旧参数）=' + (sv.match(/includes\('--sync'\)/g) || []).length +
  ' · setSyncBoth=' + (js.match(/setSyncBoth/g) || []).length +
  ' · syncAutoCode=' + (js.match(/syncAutoCode/g) || []).length);
