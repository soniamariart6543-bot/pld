#!/usr/bin/env node
/**
 * dollar-audit.mjs —— 静态扫「$() 当 $$() 用」的同类缺陷
 *
 * 背景：本项目 `$` = document.querySelector（返回单个元素或 null），
 *       `$$` = 数组版 querySelectorAll。历史上出现过两次把 `$('[data-x]')`
 *       当数组用（`.forEach`）导致 `Cannot read properties of null`，
 *       把后面整段按钮绑定/事件注册全部中断（静默失效，只有控制台报错）。
 *
 * 本脚本扫两类：
 *   A. 直接链式：$(...) 后面紧跟 .forEach/.map/.filter/.slice/.find/.some/.every/.length/[i]
 *   B. 变量传递：var x = $('...') 之后 x 上调用上述数组方法（同文件内粗匹配）
 *
 * 退出码：0 = 干净；1 = 有命中（真缺陷）；2 = 脚本自身读不到文件（区分探针故障与产品缺陷）
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const target = resolve(here, '../../assets/js/app.js');

let src;
try {
  src = readFileSync(target, 'utf8');
} catch (e) {
  console.error(`[探针故障] 读不到 ${target}: ${e.message}`);
  process.exit(2);
}

const lines = src.split(/\r?\n/);
const ARRAY_METHODS = ['forEach', 'map', 'filter', 'slice', 'find', 'findIndex', 'some', 'every', 'reduce', 'includes', 'join', 'indexOf'];
const hits = [];

function codeOnly(line) { return line.replace(/\/\/.*$/, ''); }

// ---- A. 直接链式 ----
const chainRe = new RegExp(`(^|[^$\\w])\\$\\(([^)]*)\\)\\s*\\.\\s*(${ARRAY_METHODS.join('|')})\\b`);
for (let i = 0; i < lines.length; i++) {
  const m = codeOnly(lines[i]).match(chainRe);
  if (m) hits.push({ kind: 'A·直接链式', line: i + 1, text: lines[i].trim() });
}

// ---- B. 变量传递 ----
// 收紧判据：只有声明行的选择器"可能匹配多个元素"（非 #id 开头）时才追这个变量，
// 否则 `var t = $('#x')` 后面任何 `t.indexOf(...)` 都会被误报成"数组方法误用"。
const binds = new Map(); // 变量名 -> 行号
const bindRe = /(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*\$\('([^']*)'\)/;
for (let i = 0; i < lines.length; i++) {
  const m = codeOnly(lines[i]).match(bindRe);
  if (m && !m[2].startsWith('#')) binds.set(m[1], i + 1);
}
for (const [name, declLine] of binds) {
  const useRe = new RegExp(`\\b${name}\\s*\\.\\s*(${ARRAY_METHODS.join('|')})\\b`);
  for (let i = 0; i < lines.length; i++) {
    if (i + 1 === declLine) continue;
    if (useRe.test(lines[i])) {
      hits.push({ kind: 'B·变量传递', line: i + 1, decl: declLine, text: lines[i].trim() });
      break; // 每个变量只报第一次
    }
  }
}

// ---- C. 单选择器选择器是否本该多元素（提示级，非缺陷） ----
// 只提示：`$('[data-...]')` / `$('.class')` 这类"看起来会是集合"的选择器被绑定成单元素后
// 又没做 null 判断的（可能是静默失效，但不算必崩）
const softHits = [];
for (let i = 0; i < lines.length; i++) {
  const m = codeOnly(lines[i]).match(/(^|[^$\w])\$\(\s*'(?!\#)([^']*\[data-[^']*|[^']*\.[a-z][\w-]*)'\s*\)/);
  if (m) softHits.push({ line: i + 1, selector: m[2], text: lines[i].trim() });
}

console.log(`扫描目标：${target}`);
console.log(`总行数：${lines.length}`);
console.log(`\n=== A/B 类：$ 当 $$ 用（真缺陷） ===`);
if (hits.length === 0) {
  console.log('  无命中 ✅');
} else {
  for (const h of hits) {
    console.log(`  [${h.kind}] L${h.line}${h.decl ? ` (变量声明于 L${h.decl})` : ''}`);
    console.log(`    ${h.text}`);
  }
}
console.log(`\n=== C 类：非 #id 选择器用单元素 $（提示，需人工判断是否本应取集合） ===`);
console.log(`  共 ${softHits.length} 处`);
for (const h of softHits.slice(0, 40)) {
  console.log(`  L${h.line}  $('${h.selector}')`);
}
if (softHits.length > 40) console.log(`  … 其余 ${softHits.length - 40} 处省略`);

// ---- D. $ 引用的 id 全站都不存在 → 必然 null → 必然抛错（真缺陷级） ----
// 判据：app.js 里 `$('#xxx')` 的 xxx，在 index.html 的 id="xxx" 或 app.js 自己拼的
// 模板串 id="xxx" 里都找不到 —— 说明这个元素根本不会被渲染出来，取它就是 null。
// 这是本项目最贵 bug 的根因形态（一个 null 抛错 → 后面整段绑定静默中断）。
const rootDir = resolve(here, '../..');
let html = '';
for (const f of ['index.html', 'assets/js/app.js']) {
  try { html += readFileSync(resolve(rootDir, f), 'utf8'); } catch { /* ignore */ }
}
const declared = new Set();
for (const m of html.matchAll(/\bid\s*=\s*["']([^"']+)["']/g)) declared.add(m[1]);
// 还允许 `id="' + x + '"` 这种变量拼接：收集其变量名做前缀匹配，凡以该变量结尾的 id 都算"动态"
const dynVars = new Set();
for (const m of src.matchAll(/\bid\s*=\s*['"]\s*['"]\s*\+\s*([A-Za-z_$][\w$]*)/g)) dynVars.add(m[1]);
const dynPrefix = new Set();
for (const m of src.matchAll(/\bid\s*=\s*['"]([A-Za-z0-9_-]+)['"]\s*\+\s*([A-Za-z_$][\w$]*)/g)) dynPrefix.add(m[1]);

const dHits = [];
const seenId = new Map();
const ID_RE = /(^|[^$\w])\$\(\s*['"]#([A-Za-z0-9_-]+)['"]\s*\)/g;
for (let i = 0; i < lines.length; i++) {
  const code = lines[i].replace(/\/\/.*$/, '');
  for (const m of code.matchAll(ID_RE)) {
    const id = m[2];
    if (declared.has(id)) continue;
    // 动态 id：`#fb' + i` 之类带变量的选择器不在此正则内；这里只判断纯静态 id
    const isDynLike = [...dynPrefix].some((p) => id.startsWith(p)) || [...dynVars].some((v) => id.includes(v));
    if (isDynLike) continue;
    if (seenId.has(id)) continue;
    seenId.set(id, i + 1);
    dHits.push({ line: i + 1, id, text: lines[i].trim() });
  }
}

console.log(`\n=== D 类：#id 在全站（index.html + app.js）都不存在 → 必然 null ===`);
console.log(`  共 ${dHits.length} 处`);
for (const h of dHits) console.log(`  L${h.line}  #${h.id}   ${h.text.slice(0, 110)}`);

// ---- 探针自证：确保检测方法本身有效（本项目踩过两次"探针失灵当成产品缺陷"的坑） ----
if (process.argv.includes('--selftest')) {
  const fakeSrc = [
    "var a = $('#__definitely_missing_id__');",
    'var b = $("#__also_missing__");',
    "var c = $('#dictDetail');",
    "var d = $('#qfb' + i);",
  ].join('\n');
  const fakeLines = fakeSrc.split('\n');
  const found = [];
  for (const line of fakeLines) {
    for (const m of line.matchAll(ID_RE)) {
      if (declared.has(m[2])) continue;
      if ([...dynPrefix].some((p) => m[2].startsWith(p))) continue;
      found.push(m[2]);
    }
  }
  const expect = ['__definitely_missing_id__', '__also_missing__'];
  const pass = JSON.stringify(found) === JSON.stringify(expect);
  console.log(`\n=== 探针自证 ===`);
  console.log(`  合成样本应报 2 处（单引号 / 双引号各一）、放过 2 处（dictDetail 真实存在 · #qfb'+i 动态拼接）`);
  console.log(`  实际报出：${JSON.stringify(found)}`);
  console.log(`  判定：${pass ? '✅ 检测方法有效 —— D 类 0 处是可信的' : '❌ 检测方法失灵 —— 上面的 0 处不可信'}`);
  if (!pass) process.exit(2);
}

console.log(`\n结论：A/B 真缺陷 ${hits.length} 处 · C 提示 ${softHits.length} 处 · D 必然 null ${dHits.length} 处`);
process.exit(hits.length === 0 && dHits.length === 0 ? 0 : 1);
