/* shot-quiz.mjs —— 给默写页拍张图，用来肉眼确认「一条输入线」长什么样。
   用法：node tools/checks/shot-quiz.mjs <url> <outPng> [typedText]
   说明：headless Edge + CDP，先进 #quiz、点开始，再往输入线里灌几个字母，然后截图。 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const URL_ARG = process.argv[2] || 'http://127.0.0.1:8899/index.html';
const OUT = process.argv[3] || path.join(os.tmpdir(), 'wudu-quiz.png');
const TYPED = process.argv[4] || '';

const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
if (!EDGE) { console.error('找不到 msedge.exe'); process.exit(2); }

const PORT = 9334;
const PROFILE = path.join(os.tmpdir(), 'wudu-shot-' + Date.now());
fs.mkdirSync(PROFILE, { recursive: true });

const child = spawn(EDGE, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--remote-debugging-port=' + PORT, '--user-data-dir=' + PROFILE, '--window-size=390,760', 'about:blank'],
  { stdio: 'ignore' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let wsUrl = null;
for (let i = 0; i < 40; i++) {
  await sleep(300);
  try {
    const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
    const page = list.find((t) => t.type === 'page');
    if (page && page.webSocketDebuggerUrl) { wsUrl = page.webSocketDebuggerUrl; break; }
  } catch (e) { /* 还没起来 */ }
}
if (!wsUrl) { try { child.kill(); } catch (e) {} console.error('CDP 未就绪'); process.exit(3); }

const ws = new WebSocket(wsUrl);
let id = 0;
const pending = new Map();
function cmd(method, params) {
  const mid = ++id;
  return new Promise((res, rej) => { pending.set(mid, { res, rej }); ws.send(JSON.stringify({ id: mid, method, params: params || {} })); });
}
await new Promise((r) => { ws.onopen = r; });
ws.onmessage = (ev) => {
  let m = null;
  try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); if (m.error) p.rej(new Error(m.error.message)); else p.res(m.result); }
};

await cmd('Page.enable');
await cmd('Runtime.enable');
await cmd('Emulation.setDeviceMetricsOverride', { width: 390, height: 760, deviceScaleFactor: 2, mobile: true });
await cmd('Page.navigate', { url: URL_ARG });
await sleep(2500);

// 进默写、开一轮、灌字
const script = `(function(){
  location.hash = '#quiz';
  var s = document.querySelector('#quizStart');
  if (s) s.click();
  return 'clicked';
})()`;
await cmd('Runtime.evaluate', { expression: script });
await sleep(2200);

if (TYPED) {
  await cmd('Runtime.evaluate', { expression:
    `(function(){ var i = document.querySelector('#quizInput'); if (i) { i.value = ${JSON.stringify(TYPED)}; i.focus(); } return i ? i.value : 'no-input'; })()` });
  await sleep(600);
}

const info = await cmd('Runtime.evaluate', { expression:
  `(function(){
     var i = document.querySelector('#quizInput');
     if (!i) return 'no #quizInput';
     var r = i.getBoundingClientRect(), st = getComputedStyle(i);
     return JSON.stringify({
       存在: true, 可见文案: i.value, 宽高: [Math.round(r.width), Math.round(r.height)],
       下边框: st.borderBottomWidth + ' ' + st.borderBottomColor, 字号: st.fontSize,
       不透明度: st.opacity, 是否是槽模式: !!document.querySelector('.spell-slot'),
       槽数量: document.querySelectorAll('.spell-slot').length
     });
   })()`, returnByValue: true });
console.log('输入线实测：' + (info.result && info.result.value));

const shot = await cmd('Page.captureScreenshot', { format: 'png' });
fs.writeFileSync(OUT, Buffer.from(shot.data, 'base64'));
console.log('截图已存：' + OUT);

try { ws.close(); } catch (e) {}
try { child.kill(); } catch (e) {}
await sleep(300);
try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) {}
process.exit(0);
