/* 雾读 · 三路模块审查（T056 步骤②）
   路① 答题与专注：抽原函数实跑判定逻辑
   路② 题库与渲染：index.html 的 id 与 app.js 的 $('#id') 做差集；渲染相关纯函数实跑
   路③ 数据层与设置：15 个数据文件在 vm 里加载审计 + store.js/native.js 检查
   用法: node tools/checks/mod-audit.mjs
*/
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const R = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');

const out = [];
const P = (s = '') => out.push(s);
let sev = 0, sus = 0, nit = 0;

function fail(label, detail) { sev++; P(`  ✗ [严重] ${label}${detail ? ' — ' + detail : ''}`); }
function warn(label, detail) { sus++; P(`  ⚠ [疑似] ${label}${detail ? ' — ' + detail : ''}`); }
function tip(label, detail) { nit++; P(`  · [瑕疵] ${label}${detail ? ' — ' + detail : ''}`); }
function ok(label) { P(`  ✓ ${label}`); }

const app = R('assets/js/app.js');
const html = R('index.html');

// ============ 路① 答题与专注 ============
P('=== 路① 答题与专注 ===');

// 1.1 从 app.js 抽出纯判定函数，在 vm 里实跑
function extractFn(src, name) {
  const re = new RegExp(`function\\s+${name}\\s*\\(`);
  const i = src.search(re);
  if (i < 0) return null;
  let d = 0, started = false;
  for (let j = i; j < src.length; j++) {
    const c = src[j];
    if (c === '{') { d++; started = true; }
    else if (c === '}') { d--; if (started && d === 0) return src.slice(i, j + 1); }
  }
  return null;
}

const sandbox = { console, Math, Date, JSON, String, Number, Array, Object, RegExp, parseInt, parseFloat, isNaN };
vm.createContext(sandbox);

// 找出所有 function 声明（app.js 是 IIFE + 缩进，必须允许前导空白）
const allFns = [...app.matchAll(/(?:^|\n)\s*function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map((m) => m[1]);
P(`  function 声明: ${allFns.length} 个`);

// 1.2 答题判定的关键函数存在性检查
// judge 是本项目实际的判定函数名（旧版候选表里漏了它，导致误报「未找到判定函数」）
const answerFns = ['judge', 'normalizeAnswer', 'isAnswerCorrect', 'checkAnswer', 'judgeAnswer', 'compareAnswer'];
const found = answerFns.filter((n) => app.includes(`function ${n}(`));
if (found.length) ok(`找到判定函数: ${found.join(', ')}`);
else warn('未找到明确命名的判定函数', '需人工确认判定逻辑落点');

// 1.3 专注页 timer 管理（E2 疑似项：重复点开始会丢旧 timer）
const timerSites = [...app.matchAll(/\b(setInterval|clearInterval|setTimeout|clearTimeout)\s*\(/g)].length;
P(`  计时器调用点: ${timerSites} 处`);
const focusTimerVars = [...app.matchAll(/(?:^|\s)(?:let|var|const)\s+(\w*[Tt]imer\w*)\s*=/g)].map((m) => m[1]);
if (focusTimerVars.length) P(`  计时器变量: ${[...new Set(focusTimerVars)].join(', ')}`);

// 检查 startFocus 是否防重入：要么先 clearInterval，要么首行 guard 直接 return
const startFocusIdx = app.search(/function\s+startFocus\s*\(/);
if (startFocusIdx >= 0) {
  const body = app.slice(startFocusIdx, startFocusIdx + 2000);
  if (/clearInterval/.test(body)) ok('startFocus 内含 clearInterval（不会丢旧 timer）');
  else if (/if\s*\(\s*focusState\.on\s*\)\s*\{\s*(?:toast\s*\(\s*['"][^'"]*['"]\s*\)\s*;\s*)?return\s*;?\s*\}/.test(body)) ok('startFocus 有重入保护（focusState.on 直接 return）');
  else warn('startFocus 内未见 clearInterval 或重入保护', 'E2 疑似项可能仍在');
} else {
  P('  未找到 startFocus 函数（专注页逻辑命名可能不同）');
}

// 1.4 输入框修复回归（§365 本轮修的）
if (app.includes('min-height: 56px') || /min-height:\s*56px/.test(R('assets/css/style.css'))) {
  ok('输入框可点区修复标志 min-height:56px 在');
} else {
  warn('未找到 min-height:56px', '§365 的输入框修复可能被回退');
}
const sk = (app.match(/skipQuestion/g) || []).length;
P(`  skipQuestion 出现 ${sk} 次（§365 基线 1 次）`);
const bd = (app.match(/bestD/g) || []).length;
P(`  bestD 出现 ${bd} 次（§365 基线 6 次）`);

// ============ 路② 题库与渲染 ============
P('');
P('=== 路② 题库与渲染 ===');

// 2.1 id 差集：index.html 定义的 id vs app.js 里引用的 $('#id')
// 注意 app.js 是 IIFE + 缩进，正则必须允许缩进；且大量 id 由 JS 动态注入 innerHTML
const htmlIds = new Set([...html.matchAll(/\bid\s*=\s*["']([^"']+)["']/g)].map((m) => m[1]));
const jsIds = new Set([...app.matchAll(/\$\(\s*['"]#([A-Za-z0-9_\-]+)['"]\s*\)/g)].map((m) => m[1]));
// 动态创建的 id：在 app.js 的字符串里以 id="xxx" 形式出现
const dynIds = new Set([...app.matchAll(/id\s*=\\?["']([A-Za-z0-9_\-]+)\\?["']/g)].map((m) => m[1]));
// 也被其它 js 动态创建
for (const f of ['assets/js/native.js', 'assets/js/store.js']) {
  const s = R(f);
  for (const m of s.matchAll(/id\s*=\\?["']([A-Za-z0-9_\-]+)\\?["']/g)) dynIds.add(m[1]);
}
P(`  index.html 定义 id: ${htmlIds.size} 个`);
P(`  app.js 引用 #id : ${jsIds.size} 个`);
P(`  动态注入 id     : ${dynIds.size} 个（JS innerHTML 创建）`);

const missing = [...jsIds].filter((x) => !htmlIds.has(x) && !dynIds.has(x));
if (missing.length) {
  fail(`引用的 id 既不在 index.html 也不由 JS 动态创建: ${missing.length} 个`, missing.join(', '));
} else {
  ok(`所有 $(\'#id\') 引用都有出处（静态 ${htmlIds.size} + 动态 ${dynIds.size} 覆盖，差集为空）`);
}
const unused = [...htmlIds].filter((x) => !jsIds.has(x));
P(`  index.html 有但 app.js 未用 $('#..') 引用的 id: ${unused.length} 个（可能由 querySelector/getElementById 使用，非缺陷）`);

// 2.2 是否用了别的引用方式
const qsCount = (app.match(/querySelector(?:All)?\s*\(/g) || []).length;
const gebiCount = (app.match(/getElementById\s*\(/g) || []).length;
P(`  querySelector(All): ${qsCount} 处 · getElementById: ${gebiCount} 处`);

// 2.3 渲染函数存在性
const renderFns = allFns.filter((n) => /^render|^draw|^paint|^update/i.test(n));
P(`  渲染类函数 ${renderFns.length} 个: ${renderFns.slice(0, 20).join(', ')}${renderFns.length > 20 ? ' …' : ''}`);

// 2.4 词库加载与分页
if (/quizSkip|selfSkip/.test(app)) ok('翻页标志 quizSkip/selfSkip 在（v2.20 新功能）');
else warn('未找到 quizSkip/selfSkip', 'v2.20 翻页功能可能缺失');

// ============ 路③ 数据层与设置 ============
P('');
P('=== 路③ 数据层与设置 ===');

const dataDir = path.join(ROOT, 'assets', 'js', 'data');
const files = fs.readdirSync(dataDir).filter((f) => f.endsWith('.js') && !f.includes('.bak'));
P(`  数据文件 ${files.length} 个: ${files.join(', ')}`);

let totalWords = 0;
const dataSandbox = { window: {}, globalThis: {}, console, Math, JSON, String, Number, Array, Object, RegExp, parseInt, parseFloat };
dataSandbox.globalThis = dataSandbox;
dataSandbox.window = dataSandbox;
vm.createContext(dataSandbox);

for (const f of files) {
  const src = fs.readFileSync(path.join(dataDir, f), 'utf8');
  try {
    vm.runInContext(src, dataSandbox, { filename: f, timeout: 15000 });
  } catch (e) {
    fail(`数据文件 ${f} 加载失败`, e.message.slice(0, 120));
  }
}

// 找出词库数组
const keys = Object.keys(dataSandbox).filter((k) => !['console', 'Math', 'JSON', 'String', 'Number', 'Array', 'Object', 'RegExp', 'parseInt', 'parseFloat', 'window', 'globalThis'].includes(k));
P(`  vm 加载后暴露变量 ${keys.length} 个: ${keys.slice(0, 25).join(', ')}`);

let arrays = 0, objs = 0;
const arrInfo = [];
for (const k of keys) {
  const v = dataSandbox[k];
  if (Array.isArray(v)) { arrays++; if (v.length > 50) arrInfo.push(`${k}(${v.length})`); totalWords += v.length; }
  else if (v && typeof v === 'object') objs++;
}
P(`  数组 ${arrays} 个 · 对象 ${objs} 个`);
if (arrInfo.length) P(`  大数组: ${arrInfo.join(', ')}`);

// 3.1 词条结构抽样校验
let badEntries = 0, checked = 0;
for (const k of keys) {
  const v = dataSandbox[k];
  if (!Array.isArray(v) || v.length < 50) continue;
  for (let i = 0; i < Math.min(v.length, 400); i++) {
    const e = v[i];
    if (e === null || typeof e !== 'object') { badEntries++; continue; }
    checked++;
    const hasW = e.w || e.word || e.en;
    if (!hasW) badEntries++;
  }
}
P(`  词条抽样 ${checked} 条，字段异常 ${badEntries} 条`);
if (badEntries === 0 && checked > 0) ok('词条结构抽样全部合法（都有 word 字段）');
else if (badEntries > 0) warn(`词条字段异常 ${badEntries} 条`, '需人工确认字段名规范');

// 3.2 store.js / native.js
const store = R('assets/js/store.js');
const native = R('assets/js/native.js');
P(`  store.js ${store.length} B · native.js ${native.length} B`);
if (/localStorage|indexedDB/i.test(store)) ok('store.js 使用 localStorage/indexedDB 持久化');
else warn('store.js 未见持久化 API');

// 3.3 audio-index 一致性
const auk = R('assets/js/audio-index-uk.js');
const au = R('assets/js/audio-index.js');
const ukWords = (auk.match(/"[a-zA-Z][\w\-']*"/g) || []).length;
P(`  audio-index-uk.js 条目 ~${ukWords} · audio-index.js ${au.length} B`);

P('');
P('=== 汇总 ===');
P(`  严重 ${sev} · 疑似 ${sus} · 瑕疵 ${nit}`);

// 不落盘草稿：结果只走 stdout
console.log(out.join('\n'));
