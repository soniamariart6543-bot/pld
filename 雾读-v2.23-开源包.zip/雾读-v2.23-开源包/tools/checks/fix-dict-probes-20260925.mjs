/* fix-dict-probes-20260925.mjs
   词典结构改版（六页签 + 两层弹出）之后，两个旧探针里对旧结构的假设要跟着改：
     1. dict-probe.html：搜索结果从 #dictList → #dictListSearch（结果落在弹出层里）；
        「收藏筛选 chip」→「收藏页签」，收藏词表在 #dictListStar。
     2. view-pager-probe.html：词典那一节原来断言「查词/词条/真题」三页签，
        现在改成六个分类页签的简版（细节交给 dict-tabs-probe 负责，避免重复）。
   每处替换要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/fix-dict-probes-20260925.mjs [--dry]
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');

const P1_OLD = `    var items = qa(d, '#dictList .word-item');
    ok(items.length > 0, '搜索结果有词条', items.length + ' 条');
    log('  · 筛选条：' + qa(d, '#dictFilter .chip').map(function (c) { return txt(c); }).join(' / '));`;
const P1_NEW = `    // 2026-09-25：搜索结果落在弹出层 #dictSearchLayer 的 #dictListSearch 里
    var items = qa(d, '#dictListSearch .word-item');
    ok(items.length > 0, '搜索结果有词条', items.length + ' 条');
    log('  · 分类页签：' + qa(d, '#dictTabs .pg-tab').map(function (c) { return txt(c); }).join(' / '));`;

const P2_OLD = `    /* ④ 切「收藏」筛选 */
    log('');
    log('=== ④ 切到「收藏」筛选');
    var chip = q(d, '#dictFilter [data-f="star"]');
    ok(!!chip, '筛选条里有「收藏」这一项');
    if (chip) chip.click();
    await sleep(800);
    var names = qa(d, '#dictList .word-item .w').map(function (e) { return txt(e); });`;
const P2_NEW = `    /* ④ 切到「收藏」页（2026-09-25：一排筛选 chip 改成六个分类页签） */
    log('');
    log('=== ④ 切到「收藏」页');
    var chip = q(d, '#dictTabs .pg-tab[data-pg="star"]');
    ok(!!chip, '页签里有「★ 收藏」这一项');
    if (chip) chip.click();
    await sleep(800);
    var names = qa(d, '#dictListStar .word-item .w').map(function (e) { return txt(e); });`;

const P3_OLD = `    /* ============ 六、词典：查词 / 词条 / 真题 ============ */
    ERRS.length = 0;
    log('=== 六、词典 view-dict：查词 → 词条 → 真题 ===');
    w.location.hash = '#dict';
    await sleep(1200);
    ok(!!q(d, '#view-dict'), '词典视图存在');
    ok(!!q(d, '#dictTabs'), '★ 分页条 #dictTabs 存在');
    var dtabs = qa(d, '#dictTabs .pg-tab').map(function (t) { return t.dataset.pg; });
    log('  · 页签：' + dtabs.join(' / '));
    ok(dtabs.length === 3 && dtabs.indexOf('search') >= 0 && dtabs.indexOf('detail') >= 0 && dtabs.indexOf('paper') >= 0,
       '页签为「查词/词条/真题」三页');
    ok(curKey(d, '#dictTabs') === 'search', '初始停在「查词」页', curKey(d, '#dictTabs'));
    var dpanels0 = onPanels(d, 'view-dict');
    ok(dpanels0.length === 1 && dpanels0[0] === 'search', '★ 同时只有一个面板可见', dpanels0.join(','));
    var si = q(d, '#dictSearch');
    if (si) {
      si.value = 'abandon';
      si.dispatchEvent(new w.Event('input', { bubbles: true }));
      var sb = q(d, '#dictSearchBtn');
      if (sb) sb.click();
      await sleep(900);
    }
    var ditems = qa(d, '#dictList .word-item');
    ok(ditems.length > 0, '查词页渲染出结果', ditems.length + ' 条');
    if (ditems.length) {
      ditems[0].click();
      await sleep(700);
      ok(curKey(d, '#dictTabs') === 'detail', '★ 点词后自动切到「词条」页', curKey(d, '#dictTabs'));
      var dpanels1 = onPanels(d, 'view-dict');
      ok(dpanels1.length === 1 && dpanels1[0] === 'detail', '★ 切页后查词面板已隐藏', dpanels1.join(','));
      var ddet = q(d, '#dictDetail');
      ok(!!(ddet && ddet.textContent.length > 20), '词条页有详情内容');
      var dbk = q(d, '#wdBack');
      ok(!!dbk, '词条页有返回按钮 #wdBack');
      if (dbk) {
        dbk.click();
        await sleep(600);
        ok(curKey(d, '#dictTabs') === 'search', '★ 点返回后回到「查词」页', curKey(d, '#dictTabs'));
      }
    }
    var dtabPaper = q(d, '#dictTabs .pg-tab[data-pg="paper"]');
    if (dtabPaper) {
      dtabPaper.click();
      await sleep(500);
      ok(curKey(d, '#dictTabs') === 'paper', '★ 点「真题」页签可切过去', curKey(d, '#dictTabs'));
      var dph = q(d, '#dictPaperHits');
      ok(!!(dph && dph.textContent.length > 5), '真题页有命中内容或空态提示');
    }
    log('  · 页面异常：' + (ERRS.length ? ERRS.join(' | ') : '无'));
    log('');

    /* ============ 七、页签可点动（防 E01 类事故）============ */`;

const P3_NEW = `    /* ============ 六、词典：六个功能各自一页（细节见 dict-tabs-probe）============ */
    ERRS.length = 0;
    log('=== 六、词典 view-dict：六个分类页签 ===');
    w.location.hash = '#dict';
    await sleep(1200);
    ok(!!q(d, '#view-dict'), '词典视图存在');
    ok(!!q(d, '#dictTabs'), '★ 分页条 #dictTabs 存在');
    var dtabs = qa(d, '#dictTabs .pg-tab').map(function (t) { return t.dataset.pg; });
    log('  · 页签：' + dtabs.join(' / '));
    ok(dtabs.length === 6, '页签共 6 个（全部 / CET-4 / CET-6 / 收藏 / 已学 / 错词）', dtabs.length + ' 个');
    ok(curKey(d, '#dictTabs') === 'all', '初始停在「全部」页', curKey(d, '#dictTabs'));
    var dpanels0 = onPanels(d, 'view-dict');
    ok(dpanels0.length === 1 && dpanels0[0] === 'all', '★ 同时只有一个面板可见', dpanels0.join(','));
    var dtabStar = q(d, '#dictTabs .pg-tab[data-pg="star"]');
    if (dtabStar) { dtabStar.click(); await sleep(600); }
    ok(curKey(d, '#dictTabs') === 'star', '★ 点「收藏」可切过去', curKey(d, '#dictTabs'));
    var dpanels1 = onPanels(d, 'view-dict');
    ok(dpanels1.length === 1 && dpanels1[0] === 'star', '★ 切页后别的面板已隐藏', dpanels1.join(','));
    ok(!!q(d, '[data-pg-panel="all"] #dictSearch'), '搜索框挂在「全部」页里');
    ok(!!q(d, '#dictSearchLayer') && !!q(d, '#dictWordLayer'), '搜索层与词条层都在（默认关着）');
    log('  · 页面异常：' + (ERRS.length ? ERRS.join(' | ') : '无'));
    log('');

    /* ============ 七、页签可点动（防 E01 类事故）============ */`;

const EDITS = [
  { file: 'tools/checks/dict-probe.html', name: '搜索结果落到弹出层', find: P1_OLD, repl: P1_NEW },
  { file: 'tools/checks/dict-probe.html', name: '收藏筛选 → 收藏页签', find: P2_OLD, repl: P2_NEW },
  { file: 'tools/checks/view-pager-probe.html', name: '词典节改六页签版', find: P3_OLD, repl: P3_NEW },
];

let failed = 0;
const cache = new Map();
function read(f) { if (!cache.has(f)) cache.set(f, fs.readFileSync(f, 'utf8')); return cache.get(f); }

for (const e of EDITS) {
  const src = read(e.file);
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 [' + e.file + '] ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  cache.set(e.file, src.split(e.find).join(e.repl));
  console.log('\u2713 [' + e.file + '] ' + e.name);
}
if (failed) { console.log('\n有 ' + failed + ' 处不满足条件，未写任何文件。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
for (const [f, s] of cache) { fs.writeFileSync(f, s, 'utf8'); console.log('已写回 ' + f); }

for (const f of ['tools/checks/dict-probe.html', 'tools/checks/view-pager-probe.html']) {
  const s = fs.readFileSync(f, 'utf8');
  console.log(f + ' 残留旧引用：dictFilter=' + (s.match(/dictFilter/g) || []).length + ' · #dictList（旧）=' + (s.match(/'#dictList '/g) || []).length);
}
