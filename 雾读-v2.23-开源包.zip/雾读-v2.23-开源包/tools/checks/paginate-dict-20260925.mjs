/* paginate-dict-20260925.mjs
   昀晞 2026-09-25：「词典模式每个功能做一页，单独互动、单独页面」+「以模块化分页模式全量执行」。
   词典原本是「搜索 + 列表 ⇄ 详情（靠宽/窄屏两套显示逻辑）」，现在拆成三段式页签：
     🔍 查词（搜索框 + 结果列表） / 📖 词条（单词语详情） / 📄 真题（关键词在真题里的命中）
   与听力三段式（lsTabs）同构。
   每处替换都要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/paginate-dict-20260925.mjs [--dry]   （cwd = 项目根）
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');

const HTML = `      <div class="search-wrap">
        <div class="search-box">
          <input class="input" id="dictSearch" placeholder="搜索单词 / 中文释义 / 搭配 / 例句…（如 abandon、放弃、give up）" autocomplete="off" aria-label="搜索单词或中文释义">
          <button class="btn" id="dictSearchBtn" aria-label="搜索单词">搜索</button>
        </div>
        <div class="flow-note" id="dictMeta"></div>
      </div>

      <div class="dict-layout" id="dictLayout">
        <div class="card" style="padding:10px">
          <div class="word-list" id="dictList"></div>
        </div>
        <div class="card word-detail" id="dictDetail">
          <div class="empty">在左侧选一个词，或直接搜索。</div>
        </div>
      </div>
      <div class="card" id="dictPaperHits" style="margin-top:12px;display:none"></div>`;

const HTML_NEW = `      <!-- 词典三段式（2026-09-25 昀晞：词典也要模块化分页，每个功能一页）：
           查词（搜索 + 结果列表）→ 词条（单词的完整详情）→ 真题（关键词在真题里的命中） -->
      <div class="pg-bar" id="dictTabs" role="tablist" aria-label="词典分页">
        <button class="pg-tab on" data-pg="search" role="tab" aria-selected="true" aria-label="搜索查词">🔍 查词</button>
        <button class="pg-tab" data-pg="detail" role="tab" aria-selected="false" aria-label="查看词条">📖 词条</button>
        <button class="pg-tab" data-pg="paper" role="tab" aria-selected="false" aria-label="查看真题命中">📄 真题</button>
      </div>

      <div class="pg-panel on" data-pg-panel="search">
        <div class="search-wrap">
          <div class="search-box">
            <input class="input" id="dictSearch" placeholder="搜索单词 / 中文释义 / 搭配 / 例句…（如 abandon、放弃、give up）" autocomplete="off" aria-label="搜索单词或中文释义">
            <button class="btn" id="dictSearchBtn" aria-label="搜索单词">搜索</button>
          </div>
          <div class="flow-note" id="dictMeta"></div>
        </div>
        <div class="card" style="padding:10px">
          <div class="word-list" id="dictList"></div>
        </div>
      </div>

      <div class="pg-panel" data-pg-panel="detail">
        <div class="card word-detail" id="dictDetail">
          <div class="empty">在「查词」页选一个词，或直接搜索。</div>
        </div>
      </div>

      <div class="pg-panel" data-pg-panel="paper">
        <div class="card" id="dictPaperHits"></div>
      </div>`;

const EDITS = [
  { file: 'index.html', name: '词典三段式页签 + 三个面板', find: HTML, repl: HTML_NEW },

  // —— 真题命中：不再靠 display 控制显隐（分页后它是独立一页）——
  { file: 'assets/js/app.js', name: '真题命中空态',
    find: `    if (kw.length < 2) { host.style.display = 'none'; host.innerHTML = ''; return; }
    var hits = paperHits(kw);
    host.style.display = 'block';`,
    repl: `    // 2026-09-25 分页化：真题命中成了独立一页，不再用 display 控制显隐
    if (kw.length < 2) {
      host.innerHTML = '<div class="empty">在「查词」页搜一个词，这里会列出它在历年真题里的出现位置。</div>';
      return;
    }
    var hits = paperHits(kw);` },

  // —— renderDict 尾部：去掉 dictLayout / detail-open 那套宽窄屏逻辑 ——
  { file: 'assets/js/app.js', name: 'renderDict 尾部去并排逻辑',
    find: `    // 列表 ⇄ 详情（对齐 Android 官方 list-detail 模式）：
    // 宽屏并排，窄屏点词进单独详情页 —— 不再让详情挤在词表下面一屏之外
    var layoutEl = $('#dictLayout');
    if (layoutEl) layoutEl.classList.toggle('detail-open', !!dictState.detailOpen);
    var wide = window.innerWidth >= 901;
    if (wide && !dictState.picked && show.length) dictState.picked = show[0].w;
    if (dictState.picked) renderWordDetail(dictState.picked);
    else $('#dictDetail').innerHTML = '<div class="empty">点任意一个词，看释义、搭配、例句与语法。</div>';`,
    repl: `    // 分页（2026-09-25 昀晞：词典也要模块化分页，每个功能一页）——
    // 「查词」页管搜索与结果列表，「词条」页管详情，不再靠宽/窄屏两套显示逻辑。
    var wide = window.innerWidth >= 901;
    if (wide && !dictState.picked && show.length) dictState.picked = show[0].w;
    if (dictState.picked) renderWordDetail(dictState.picked);
    else $('#dictDetail').innerHTML = '<div class="empty">在「查词」页选一个词，或直接搜索。</div>';` },

  // —— 词根面板里点同根词：切到「词条」页（带 hostSel 的外部调用不切）——
  { file: 'assets/js/app.js', name: '同根词点击切页',
    find: `        dictState.picked = t;
        dictState.detailOpen = true;
        renderWordDetail(t, hostSel, noBack);`,
    repl: `        dictState.picked = t;
        dictState.detailOpen = true;
        renderWordDetail(t, hostSel, noBack);
        if (!hostSel) pgGo('#dictTabs', 'detail');   // 词典页里点同根词 → 直接切到「词条」页` },

  // —— 返回：从「词条」页退回「查词」页 ——
  { file: 'assets/js/app.js', name: 'closeWordDetail 改走页签',
    find: `  /* 从单词详情退回词表（窄屏的「上一页」） */
  function closeWordDetail() {
    dictState.detailOpen = false;
    var el = $('#dictLayout');
    if (el) el.classList.remove('detail-open');
    resetScroll();
  }`,
    repl: `  /* 从「词条」页退回「查词」页（页签化之后的返回） */
  function closeWordDetail() {
    dictState.detailOpen = false;
    pgGo('#dictTabs', 'search');
    resetScroll();
  }` },

  // —— 列表点词：切到「词条」页 ——
  { file: 'assets/js/app.js', name: '列表点词切页',
    find: `      dictState.picked = it.dataset.w;
      dictState.detailOpen = true;            // 窄屏：切进单独详情页
      renderDict();
      resetScroll();`,
    repl: `      dictState.picked = it.dataset.w;
      dictState.detailOpen = true;
      renderDict();
      pgGo('#dictTabs', 'detail');            // 点词 → 直接切到「词条」页
      resetScroll();` },

  // —— 绑定页签 ——
  { file: 'assets/js/app.js', name: 'bindGlobal 绑定词典页签',
    find: `    bindPg('#planTabs');   // 计划分页（2026-09-25）：设置 / 计划`,
    repl: `    bindPg('#planTabs');   // 计划分页（2026-09-25）：设置 / 计划
    bindPg('#dictTabs');   // 词典分页（2026-09-25）：查词 / 词条 / 真题` },

  // —— 安卓返回键：词典在「词条」页时退回「查词」页 ——
  { file: 'assets/js/app.js', name: '返回键判断改走页签',
    find: `    if (cur === 'dict' && dictState.detailOpen) { closeWordDetail(); return 'handled'; }`,
    repl: `    if (cur === 'dict' && pgCurrent('#dictTabs') === 'detail') { closeWordDetail(); return 'handled'; }` },
];

let failed = 0;
const cache = new Map();
function read(f) { if (!cache.has(f)) cache.set(f, fs.readFileSync(f, 'utf8')); return cache.get(f); }

for (const e of EDITS) {
  const src = read(e.file);
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('✗ [' + e.file + '] ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  cache.set(e.file, src.split(e.find).join(e.repl));
  console.log('✓ [' + e.file + '] ' + e.name);
}

if (failed) { console.log('\n有 ' + failed + ' 处不满足条件，未写任何文件。'); process.exit(1); }

if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
for (const [f, s] of cache) { fs.writeFileSync(f, s, 'utf8'); console.log('已写回 ' + f); }

const js = fs.readFileSync('assets/js/app.js', 'utf8');
console.log('\n残留 dictLayout 引用：' + (js.match(/dictLayout/g) || []).length);
console.log('pg-bar 总数（index.html）：' + (fs.readFileSync('index.html', 'utf8').match(/class="pg-bar"/g) || []).length);
