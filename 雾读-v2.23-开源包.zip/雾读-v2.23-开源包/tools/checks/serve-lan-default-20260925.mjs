/* serve-lan-default-20260925.mjs
   昀晞 2026-09-25：「直接连接局域网就能操作，不要打开其他工具」。
   目标：默认就是局域网可用 —— 手机连同一 Wi-Fi 直接打开，电脑什么都不用配；
        服务本身由静默启动器 + 开机自启负责，她不用去开任何工具。
   做法：
     · LAN 默认开（`--local-only` 才缩回 127.0.0.1）；
     · **双绑**：在「具体的局域网 IP」与 `127.0.0.1` 上各起一个监听（同一端口两个地址）——
       手机能连、本机的探针照旧走 127.0.0.1；**绝不绑 0.0.0.0**（安全红线）。
   每处替换要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/serve-lan-default-20260925.mjs [--dry]
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const F = 'serve.js';

const E1_OLD = `   用法：node serve.js [端口] [--lan] [--no-sync]
     --lan      把监听地址从 127.0.0.1 扩到本机局域网 IP（**绝不绑 0.0.0.0**），
                开了这个手机才能连过来；务必只在可信 Wi-Fi 下用
     --no-sync  关掉多端互通端点 /sync（**默认是开的**：绑 127.0.0.1 时外面本来就进不来，
                绑局域网时仍要配对码才能读写）`;
const E1_NEW = `   用法：node serve.js [端口] [--local-only] [--no-sync]
     （2026-09-25 昀晞：默认就是「局域网可直接用」—— 不加任何参数，手机连同一 Wi-Fi 就能打开）
     --local-only  只绑 127.0.0.1（临时收紧、不给手机连时用）
     --no-sync     关掉多端互通端点 /sync（默认开）
     安全：**绝不绑 0.0.0.0** —— 只在「具体局域网 IP」与 127.0.0.1 上各起一个监听；
           来自局域网的写操作仍要配对码（连续错 20 次锁 5 分钟）。`;

const E2_OLD = `const LAN_ON = process.argv.includes('--lan');`;
const E2_NEW = `const LAN_ON = !process.argv.includes('--local-only');   // 2026-09-25：默认就开，--local-only 缩回本机`;

const E3_OLD = `http.createServer((req, res) => {`;
const E3_NEW = `function handleRequest(req, res) {`;

const E4_OLD = `}).listen(PORT, HOST, () => {
  console.log('雾读预览已启动：http://' + HOST + ':' + PORT + '/');
  if (SYNC_ON) console.log('多端互通已开 · 配对码：' + PAIR_CODE + '（电脑上打开的网页会自动带上，不用手输；只写在控制台，不落盘）');
  else console.log('多端互通已关（--no-sync）');
  if (LAN_ON) {
    console.log('⚠ 局域网模式：同一 Wi-Fi 下手机可以打开上面这个地址（务必只在可信 Wi-Fi 下用）');
  } else {
    console.log('（仅本机可访问；要让手机连过来加 --lan）');
  }
  console.log('按 Ctrl+C 停止');
});`;
const E4_NEW = `}

/* 2026-09-25 昀晞「直接连局域网就能操作、不要打开其他工具」：
   默认在**具体的局域网 IP**与 127.0.0.1 上各起一个监听（同端口、两个地址）——
   手机连同一 Wi-Fi 直接打开；本机与探针照旧走 127.0.0.1。**绝不绑 0.0.0.0**（安全红线）。 */
const LAN_BIND = LAN_ON ? lanAddress() : null;
const BINDS = (LAN_BIND && LAN_BIND !== '127.0.0.1') ? [LAN_BIND, '127.0.0.1'] : ['127.0.0.1'];
BINDS.forEach((bindHost, idx) => {
  http.createServer(handleRequest).listen(PORT, bindHost, () => {
    if (idx !== 0) return;                          // 启动信息只打一次
    console.log('雾读已启动');
    if (LAN_BIND) console.log('  手机（连同一 Wi-Fi）打开：http://' + LAN_BIND + ':' + PORT + '/');
    console.log('  本机打开：http://127.0.0.1:' + PORT + '/');
    if (SYNC_ON) console.log('  多端互通已开 · 配对码：' + PAIR_CODE + '（电脑上的网页会自动带上，不用手输）');
    else console.log('  多端互通已关（--no-sync）');
    console.log('按 Ctrl+C 停止');
  });
});`;

const EDITS = [
  { name: '用法注释', find: E1_OLD, repl: E1_NEW },
  { name: 'LAN 默认开', find: E2_OLD, repl: E2_NEW },
  { name: '请求处理改具名函数', find: E3_OLD, repl: E3_NEW },
  { name: '双绑监听 + 启动信息', find: E4_OLD, repl: E4_NEW },
];

let src = fs.readFileSync(F, 'utf8');
let failed = 0;
for (const e of EDITS) {
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  src = src.split(e.find).join(e.repl);
  console.log('\u2713 ' + e.name);
}
if (failed) { console.log('\n未写盘。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
fs.writeFileSync(F, src, 'utf8');
console.log('已写回 ' + F);
console.log('残留检查：0.0.0.0 =' + (src.match(/0\.0\.0\.0/g) || []).length + '（必须为 0）· handleRequest=' + (src.match(/handleRequest/g) || []).length);
