/* write-nocheck-20260925.mjs
   昀晞 2026-09-25：「作文模块的检测取消，就只提交不检测然后给范文 —— 离线检测作文这个软件做不到」。
   改法：
     · 写作训练页：两个按钮（提交体检 / 直接看范文）合并成一个「提交，看范文」；去掉 20 词门槛；
       本地体检函数 writingReport() 整块删除。
     · 真题纸笔模式的作文：去掉「连接词覆盖 N/M 类 + 完整版体检请到写作训练页」那段（否则成了死指向）。
     · 三处文案跟着改（写作页副标题 / 专注页任务描述 / 首页功能卡描述）。
   保留：范文、亮点表达、同义升级（writingAnswer）；「写作素材」工具页（连贯词表 / 中式英语纠正表）不受影响。
   每处替换要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/write-nocheck-20260925.mjs [--dry]
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const J = 'assets/js/app.js';
const H = 'index.html';

/* ---- 1. 写作训练页：按钮合并 ---- */
const BTN_OLD = `        '<textarea class="input" id="wrInput" rows="12" placeholder="按提纲写 ' + range + ' 词，写完点下面的按钮做体检。"></textarea>' +
        '<div class="row" style="margin-top:12px">' +
          '<button class="btn primary" id="wrCheck">提交体检</button>' +
          '<button class="btn ghost" id="wrReveal">直接看范文与亮点表达</button>' +
          '<span class="flow-note" id="wrLive"></span>' +
        '</div>' +`;
const BTN_NEW = `        '<textarea class="input" id="wrInput" rows="12" placeholder="按提纲写 ' + range + ' 词，写完点「提交」直接对范文。"></textarea>' +
        '<div class="row" style="margin-top:12px">' +
          '<button class="btn primary" id="wrCheck">提交，看范文</button>' +
          '<span class="flow-note" id="wrLive"></span>' +
        '</div>' +`;

/* ---- 2. 写作训练页：提交处理（不检测） ---- */
const ONCLICK_OLD = `    $('#wrCheck').onclick = function () {
      var txt = input.value;
      if (wcCount(txt) < 20) { toast('先写够 20 个词再看体检结果吧'); return; }
      $('#wrFeedback').innerHTML = writingReport(txt, t);
      countStudy();
    };
    $('#wrReveal').onclick = function () { $('#wrFeedback').innerHTML = writingAnswer(t); countStudy(); };`;
const ONCLICK_NEW = `    // 2026-09-25 昀晞：作文不做检测 —— 离线判不了语义，给个「体检报告」反而误导。
    // 提交＝把范文、亮点表达、同义升级摆出来，自己对照；没写也能点（当参考资料看）。
    $('#wrCheck').onclick = function () {
      $('#wrFeedback').innerHTML = writingAnswer(t);
      countStudy();
    };`;

/* ---- 3. 本地体检函数整块删除 ---- */
const REPORT_OLD = `  // 本地体检：只做能确定的事，不假装能判语义
  function writingReport(text, t) {
    var low = ' ' + String(text).toLowerCase() + ' ';
    var words = wcCount(text);
    var paras = splitParas(text);
    var sents = splitSentences(text);
    var lens = sents.map(function (s) { return wcCount(s); });
    var avg = lens.length ? Math.round(lens.reduce(function (a, b) { return a + b; }, 0) / lens.length) : 0;
    var sd = Math.round(stdev(lens));

    var lo = t.level === 'cet6' ? 150 : 120, hi = t.level === 'cet6' ? 200 : 180;
    var wcTag = words < lo ? '<span class="badge bad">不足（要求 ' + lo + '+）</span>'
      : (words > hi ? '<span class="badge">偏长（建议 ≤' + hi + '）</span>' : '<span class="badge good">达标</span>');

    var conn = WKIT.connectors || {}, connHit = [], connMiss = [];
    Object.keys(conn).forEach(function (k) {
      var hit = (conn[k] || []).filter(function (w) { return low.indexOf(' ' + w.toLowerCase()) >= 0; });
      if (hit.length) connHit.push(k); else connMiss.push(k);
    });

    var spell = [];
    Object.keys(WKIT.spellingMap || {}).forEach(function (bad) {
      var re = new RegExp('\\\\b' + bad.replace(/[.*+?^\${}()|[\\]\\\\]/g, '\\\\$&') + '\\\\b', 'i');
      if (re.test(text)) spell.push(bad + ' → ' + WKIT.spellingMap[bad]);
    });

    var ching = (WKIT.chinglish || []).filter(function (x) { return low.indexOf(String(x.pattern).toLowerCase()) >= 0; });
    var kws = t.keywords || [];
    var kwHit = kws.filter(function (k) { return low.indexOf(String(k).toLowerCase()) >= 0; });
    var upHit = (t.upgrades || []).filter(function (u) { return low.indexOf(String(u.to).toLowerCase()) >= 0; });

    var score = function (pct) { return '<div class="rv-row"><div class="rv-bar" style="flex:1;max-width:100%"><i style="width:' + pct + '%"></i></div></div>'; };
    var contentPct = kws.length ? Math.round(kwHit.length / kws.length * 100) : 100;
    var structPct = Math.round(connHit.length / 5 * 100);
    var accPct = Math.max(0, 100 - (spell.length * 12) - (ching.length * 15));
    var richPct = Math.min(100, Math.round(sd * 8) + upHit.length * 10);

    return '<div class="sep"></div>' +
      '<div class="card-title">体检报告 <span class="tag small muted">本地规则检查，不是官方评分</span></div>' +
      '<div class="grid c4">' +
        '<div class="stat"><div class="num">' + words + '</div><div class="lbl">总词数</div></div>' +
        '<div class="stat"><div class="num">' + paras.length + '</div><div class="lbl">段落数</div></div>' +
        '<div class="stat"><div class="num">' + sents.length + '</div><div class="lbl">句子数</div></div>' +
        '<div class="stat"><div class="num">' + avg + '</div><div class="lbl">平均句长</div></div>' +
      '</div>' +
      '<div style="margin-top:8px">词数 ' + words + ' ' + wcTag + ' · 句长标准差 ' + sd + '（越大句式越有变化）</div>' +

      '<div class="wd-block"><h4>① 内容完整性 ' + contentPct + '%</h4>' +
        '<div>话题词命中 ' + kwHit.length + ' / ' + kws.length + '：' +
        kws.map(function (k) {
          var ok = kwHit.indexOf(k) >= 0;
          return '<span class="badge ' + (ok ? 'good' : '') + '" style="margin:3px 4px 3px 0">' + (ok ? '✓ ' : '○ ') + esc(k) + '</span>';
        }).join('') + '</div>' + score(contentPct) + '</div>' +

      '<div class="wd-block"><h4>② 结构逻辑 ' + structPct + '%</h4>' +
        '<div>衔接词类别命中 ' + connHit.length + ' / 5' +
        (connMiss.length ? ' —— 还缺：' + connMiss.map(function (k) { return '<span class="badge bad" style="margin:2px">' + k + '</span>'; }).join('') : '') + '</div>' +
        score(structPct) + '</div>' +

      '<div class="wd-block"><h4>③ 语言准确性 ' + accPct + '%</h4>' +
        (spell.length ? '<div><span class="badge bad">拼写 ' + spell.length + ' 处</span></div><ul class="list-plain">' +
          spell.map(function (s) { return '<li>· ' + esc(s) + '</li>'; }).join('') + '</ul>' : '<div class="small muted">没查出常见拼写错误 ✓</div>') +
        (ching.length ? '<div style="margin-top:8px"><span class="badge bad">中式英语 ' + ching.length + ' 处</span></div><ul class="list-plain">' +
          ching.map(function (c) { return '<li>· ' + esc(c.pattern) + ' → ' + esc(c.suggest) + '</li>'; }).join('') + '</ul>' : '') +
        '<div class="flow-note">只查常见拼写表与中式英语模式，长句的语法错误查不出来 —— 这块得靠人看。</div>' + score(accPct) + '</div>' +

      '<div class="wd-block"><h4>④ 语言丰富度 ' + richPct + '%</h4>' +
        '<div>用到的高级表达 ' + upHit.length + ' 个：' +
        (upHit.length ? upHit.map(function (u) { return '<span class="badge good" style="margin:3px 4px 3px 0">' + esc(u.to) + '</span>'; }).join('')
          : '<span class="small muted">一个都没用上 —— 试试把 important 换成 significant 这类。</span>') + '</div>' +
        score(richPct) + '</div>' +
      writingAnswer(t);
  }`;
const REPORT_NEW = `  /* 2026-09-25 昀晞：本地作文体检整块删除（「离线检测作文这个软件做不到」）。
     原来那套「内容完整性 / 结构逻辑 / 语言准确性 / 语言丰富度」四项评分，本质是词表命中 + 拼写表匹配，
     给出的百分比会让人以为被评过 —— 现在只给范文与表达，由自己对照。
     如果将来要判分，应走真正的模型/服务，不要再捡回这套本地规则。 */`;

/* ---- 4. 写作列表页描述 ---- */
const LIST_OLD = `        '<span class="small muted">' + list.length + ' 个话题 · 写完自动体检（词数区间 · 段落句长 · 连接词覆盖 · 拼写与中式英语）</span>' +`;
const LIST_NEW = `        '<span class="small muted">' + list.length + ' 个话题 · 写完提交就能对范文 · 亮点表达 · 同义升级</span>' +`;

/* ---- 5. 真题纸笔模式的作文：去掉自检段 ---- */
const REAL_OLD = `            var nw = (myW.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            var connAll = (WKIT && WKIT.connectors) || {};
            var connHit = Object.keys(connAll).filter(function (k) {
              return (connAll[k] || []).some(function (w) { return myW.toLowerCase().indexOf(String(w).toLowerCase()) >= 0; });
            });
            var paras = myW.split(/\\n\\s*\\n/).filter(function (x) { return x.trim(); }).length;
            wDraft = '<div class="sep"></div><div class="card-title">你的草稿 <span class="tag small muted">' + nw + ' 词 · ' + paras + ' 段</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(myW) + '</div>' +
              '<div class="flow-note" style="margin-top:8px">连接词覆盖 ' + connHit.length + ' / ' + Object.keys(connAll).length +
              ' 类（' + (connHit.length ? connHit.join('、') : '一类都没用上') + '）；完整版体检请到「写作训练」页。</div>';`;
const REAL_NEW = `            // 2026-09-25：作文不再做检测，这里只回放草稿 + 给范文（原「连接词覆盖 + 完整版体检指引」已删）
            var nw = (myW.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            var paras = myW.split(/\\n\\s*\\n/).filter(function (x) { return x.trim(); }).length;
            wDraft = '<div class="sep"></div><div class="card-title">你的草稿 <span class="tag small muted">' + nw + ' 词 · ' + paras + ' 段</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(myW) + '</div>';`;

/* ---- 6/7. 文案 ---- */
const HTML_OLD = `          <h2>写作训练</h2>
          <p>写完自动体检：词数区间 · 段落句长 · 连接词覆盖 · 拼写与中式英语。</p>`;
const HTML_NEW = `          <h2>写作训练</h2>
          <p>写完提交，直接对范文、亮点表达与同义升级 —— 不做机器体检，靠自己对照。</p>`;

const FOCUS_OLD = `            <b>✒ 写作训练</b><span>写完整篇，再拿体检报告</span>`;
const FOCUS_NEW = `            <b>✒ 写作训练</b><span>写完整篇，再对范文</span>`;

const CARD_OLD = `      { v: 'write', icon: '✒', name: '写作训练', desc: '写完体检 · 范文对照' },`;
const CARD_NEW = `      { v: 'write', icon: '✒', name: '写作训练', desc: '写完对范文 · 亮点表达' },`;

const EDITS = [
  { file: J, name: '写作页按钮合并', find: BTN_OLD, repl: BTN_NEW },
  { file: J, name: '提交换成给范文', find: ONCLICK_OLD, repl: ONCLICK_NEW },
  { file: J, name: '本地体检函数删除', find: REPORT_OLD, repl: REPORT_NEW },
  { file: J, name: '写作列表描述', find: LIST_OLD, repl: LIST_NEW },
  { file: J, name: '真题作文去掉自检段', find: REAL_OLD, repl: REAL_NEW },
  { file: J, name: '首页功能卡描述', find: CARD_OLD, repl: CARD_NEW },
  { file: H, name: '写作页副标题', find: HTML_OLD, repl: HTML_NEW },
  { file: H, name: '专注页任务描述', find: FOCUS_OLD, repl: FOCUS_NEW },
];

let failed = 0;
const cache = new Map();
function read(f) { if (!cache.has(f)) cache.set(f, fs.readFileSync(f, 'utf8')); return cache.get(f); }

for (const e of EDITS) {
  const src = read(e.file);
  const n = src.split(e.find).length - 1;
  if (n !== 1) { console.log('\u2717 [' + e.file + '] ' + e.name + ' —— 命中 ' + n + ' 次（要求 1 次），中止'); failed++; continue; }
  cache.set(e.file, src.split(e.find).join(e.repl));
  console.log('\u2713 [' + e.file + '] ' + e.name);
}
if (failed) { console.log('\n有 ' + failed + ' 处不满足条件，未写任何文件。'); process.exit(1); }
if (DRY) { console.log('\n（--dry：未写盘）'); process.exit(0); }
for (const [f, s] of cache) { fs.writeFileSync(f, s, 'utf8'); console.log('已写回 ' + f); }

const js = fs.readFileSync(J, 'utf8');
const html = fs.readFileSync(H, 'utf8');
console.log('\n残留检查：writingReport=' + (js.match(/writingReport/g) || []).length +
  ' · wrReveal=' + (js.match(/wrReveal/g) || []).length +
  ' · 体检=' + ((js + html).match(/体检/g) || []).length +
  ' · 连接词覆盖=' + (js.match(/连接词覆盖/g) || []).length);
