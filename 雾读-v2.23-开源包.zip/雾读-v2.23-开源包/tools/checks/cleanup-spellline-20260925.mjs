/* cleanup-spellline-20260925.mjs
   昀晞 2026-09-25：「一条输入线」+「横线彻底删除」。
   本脚本把字母槽方案的残留整段删除 —— slotsHtml() / syncSlots() 两个函数、它们的全部调用点，
   以及硬核模式里那套「算离手指最近的槽」的定位代码。
   每处替换都要求「恰好命中 1 次」，不满足就整体中止、不写盘。
   用法：node tools/checks/cleanup-spellline-20260925.mjs [--dry]   （cwd = 项目根）
*/
import fs from 'node:fs';

const DRY = process.argv.includes('--dry');
const F = 'assets/js/app.js';
const raw = String.raw;

const EDITS = [
  {
    name: '默写：去掉字母槽容器拼接',
    find: raw`'<div class="spell-wrap" id="spellWrap">' + slotsHtml(w.w) +`,
    repl: raw`'<div class="spell-wrap" id="spellWrap">' +`,
  },
  {
    name: '默写：提示按钮里的槽同步',
    find: raw`        input.value = out.replace(/\s+$/, '');
        syncSlots(w.w, input.value);
        focusIn();`,
    repl: raw`        input.value = out.replace(/\s+$/, '');
        focusIn();`,
  },
  {
    name: '默写：两个函数定义（整段删）',
    find: raw`  /* 拼写输入：2026-09-25 昀晞 —— 「不要很多横线，就一条输入线，字跟着输入走」。
     原来是 slotsHtml() 生成 N 个字母槽、syncSlots() 把字符搬进槽里，再用一个透明输入层
     盖在上面接键盘；手机上视觉被横线切得很碎，而且要先点中细缝才聚焦。
     现在输入框自己可见、自己显示字（打字＝字跟着走），光标与逐位修改回归系统标准行为。
     这两个函数留成兼容壳，调用点不用动；硬核模式（#hardSlots）同理。 */
  function slotsHtml() { return ''; }
  function syncSlots() { /* 一条输入线：字由输入框自己显示，无需再同步到字母槽 */ }`,
    repl: raw`  /* 拼写输入：2026-09-25 昀晞 —— 「不要很多横线，就一条输入线」+「横线彻底删除」。
     原先的 slotsHtml()（生成 N 个字母槽）与 syncSlots()（把字符搬进槽里）已整体删除：
     输入框自己可见、自己显示字，光标与逐位修改全部交给系统原生行为。
     硬核模式（#hardInput）同样只保留一条输入线。 */`,
  },
  {
    name: '硬核：去掉字母槽容器拼接',
    find: raw`'<div class="spell-wrap" id="hardWrap">' + slotsHtml(w.w, 'hardSlots') +`,
    repl: raw`'<div class="spell-wrap" id="hardWrap">' +`,
  },
  {
    name: '硬核：答错后的槽重置',
    find: raw`      inp.value = '';
      syncSlots(w.w, '', 'hardSlots');
      buzz([70, 45, 70]);`,
    repl: raw`      inp.value = '';
      buzz([70, 45, 70]);`,
  },
];

let src = fs.readFileSync(F, 'utf8');
let failed = 0;

for (const e of EDITS) {
  const n = src.split(e.find).length - 1;
  if (n !== 1) {
    console.log('✗ ' + e.name + ' —— 命中 ' + n + ' 次（要求恰好 1 次），中止');
    failed++;
    continue;
  }
  src = src.split(e.find).join(e.repl);
  console.log('✓ ' + e.name);
}

if (failed) {
  console.log('\n有 ' + failed + ' 处不满足条件，未写盘。');
  process.exit(1);
}

const left = (src.match(/syncSlots|slotsHtml|spell-slot|hardSlots|spellSlots/g) || []).length;
console.log('\n清理后残留引用：' + left + (left === 0 ? '（干净）' : ' ← 还有残留！'));

if (DRY) { console.log('（--dry：未写盘）'); }
else { fs.writeFileSync(F, src, 'utf8'); console.log('已写回 ' + F); }
