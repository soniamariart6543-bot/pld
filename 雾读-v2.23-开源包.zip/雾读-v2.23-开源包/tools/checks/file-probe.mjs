/* file-probe.mjs —— 实测「双击 index.html（file:// 打开）能不能直接用」。
   背景（昀晞 2026-09-25）：「要求发给其他人用，任何环境都能运行」——
   别人电脑不一定装 Node，所以必须确认不依赖服务端也能跑。

   用法：node tools/checks/file-probe.mjs "file:///D:/DeepSeek/项目/四六级单词/index.html"
*/
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const URL_ARG = process.argv[2];
if (!URL_ARG) { console.error('用法: node tools/checks/file-probe.mjs <file:///.../index.html>'); process.exit(2); }

const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
if (!EDGE) { console.error('找不到 msedge.exe'); process.exit(2); }

const PORT = 9335;
const PROFILE = path.join(os.tmpdir(), 'wudu-file-' + Date.now());
fs.mkdirSync(PROFILE, { recursive: true });

const child = spawn(EDGE, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--remote-debugging-port=' + PORT, '--user-data-dir=' + PROFILE,
  '--allow-file-access-from-files=false',    // 刻意不开特权：模拟别人双击的真实环境
  'about:blank'], { stdio: 'ignore' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let wsUrl = null;
for (let i = 0; i < 40; i++) {
  await sleep(300);
  try {
    const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
    const page = list.find((t) => t.type === 'page');
    if (page && page.webSocketDebuggerUrl) { wsUrl = page.webSocketDebuggerUrl; break; }
  } catch (e) { /* 还没起来 */ }
}
if (!wsUrl) { try { child.kill(); } catch (e) {} console.error('CDP 未就绪'); process.exit(3); }

const ws = new WebSocket(wsUrl);
let id = 0;
const pending = new Map();
const consoleErrs = [];
function cmd(method, params) {
  const mid = ++id;
  return new Promise((res, rej) => { pending.set(mid, { res, rej }); ws.send(JSON.stringify({ id: mid, method, params: params || {} })); });
}
await new Promise((r) => { ws.onopen = r; });
ws.onmessage = (ev) => {
  let m = null;
  try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.method === 'Runtime.consoleAPICalled' && m.params && m.params.type === 'error') {
    consoleErrs.push((m.params.args || []).map((a) => a.value || a.description || '').join(' ').slice(0, 160));
  }
  if (m.method === 'Runtime.exceptionThrown') {
    const d = m.params && m.params.exceptionDetails;
    consoleErrs.push('[exception] ' + ((d && (d.text || (d.exception && d.exception.description))) || '').slice(0, 160));
  }
  if (m.id && pending.has(m.id)) {
    const p = pending.get(m.id); pending.delete(m.id);
    if (m.error) p.rej(new Error(m.error.message)); else p.res(m.result);
  }
};

await cmd('Page.enable');
await cmd('Runtime.enable');
await cmd('Page.navigate', { url: URL_ARG });
await sleep(6000);

const expr = `(async function(){
  var g = function(n){ return (typeof window[n] === 'undefined') ? 'undefined' : (window[n] && window[n].length !== undefined ? window[n].length : 'yes'); };
  var out = [];
  out.push('title        = ' + document.title);
  out.push('view-home    = ' + !!document.querySelector('#view-home'));
  out.push('脚本标签数    = ' + document.scripts.length);
  out.push('词库 CET4    = ' + g('CET4_WORDS'));
  out.push('词库 CET6    = ' + g('CET6_WORDS'));
  out.push('听力库       = ' + g('LISTENING_BANK'));
  out.push('真题库       = ' + g('REAL_PAPERS'));
  out.push('语法库       = ' + g('GRAMMAR_BANK'));
  out.push('原生桥       = ' + (window.WUDU_NATIVE ? 'yes' : 'no'));
  out.push('localStorage = ' + (function(){ try { localStorage.setItem('__probe','1'); localStorage.removeItem('__probe'); return '可写'; } catch(e){ return '不可用：' + e.name; } })());
  out.push('首页可渲染    = ' + (document.querySelector('#view-home') ? (document.querySelector('#view-home').textContent.length > 20 ? '有内容' : '空') : '无节点'));
  // 音频：file:// 下 <audio> 走媒体加载、不受 CORS 限制，应该能读到元数据（fetch 才会被拦）
  var audio = await new Promise(function(res){
    try {
      var a = new Audio();
      a.preload = 'auto';
      var done = false;
      var fin = function(v){ if (!done) { done = true; res(v); } };
      a.addEventListener('loadedmetadata', function(){ fin('可读（时长 ' + Math.round(a.duration) + ' 秒）'); });
      a.addEventListener('error', function(){ fin('失败 code=' + ((a.error && a.error.code) || '?')); });
      setTimeout(function(){ fin('超时 readyState=' + a.readyState); }, 5000);
      a.src = 'assets/audio/w-o/abandon.opus';
    } catch (e) { res('异常：' + e.message); }
  });
  out.push('音频 opus    = ' + audio);
  return out.join('\\n');
})()`;
const r = await cmd('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
console.log('=== file:// 打开实测 ===');
console.log(r.result && r.result.value ? r.result.value : '(无输出)');
console.log('');
console.log('=== 控制台报错 ===');
console.log(consoleErrs.length ? consoleErrs.slice(0, 8).join('\n') : '（无）');

try { ws.close(); } catch (e) {}
try { child.kill(); } catch (e) {}
await sleep(300);
try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) {}
process.exit(0);
