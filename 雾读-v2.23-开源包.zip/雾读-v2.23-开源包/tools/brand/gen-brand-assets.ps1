# Generate every brand asset for Wudu from the calligraphy logo recipe.
# ASCII-only so Windows PowerShell 5.1 parses it.
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path            # <root>\tools\brand
$root = Split-Path (Split-Path $here -Parent) -Parent              # <root>
$res  = Join-Path $root 'android-app\android\app\src\main\res'
$webBrand = Join-Path $root 'assets\brand'
$webIcons = Join-Path $root 'assets\icons'
$font = Join-Path $here 'fonts\MaShanZheng-Regular.ttf'

$wu = [string][char]0x96FE   # wu  (mist)
$du = [string][char]0x8BFB   # du  (read)

$pfc = New-Object System.Drawing.Text.PrivateFontCollection
$pfc.AddFontFile($font)
$fam = $pfc.Families[0]

function Ensure([string]$dir) { if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null } }

function New-LogoBitmap {
  param(
    [int]$Size,
    [string]$Bg1 = '#f4f8fc',
    [string]$Bg2 = '#e4f0f7',
    [string]$C1  = '#1f5f8f',
    [string]$C2  = '#2f9e8a',
    [double]$GlyphScale = 0.40,
    [double]$PosA = 0.335,
    [double]$PosB = 0.675,
    [switch]$Transparent,
    [switch]$Round
  )
  $bmp = New-Object System.Drawing.Bitmap $Size, $Size, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
  $g.Clear([System.Drawing.Color]::Transparent)

  $rect = New-Object System.Drawing.Rectangle 0, 0, $Size, $Size
  if ($Round) {
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddEllipse(0, 0, $Size, $Size)
    $g.SetClip($path)
  }
  if (-not $Transparent) {
    $b1 = [System.Drawing.ColorTranslator]::FromHtml($Bg1)
    $b2 = [System.Drawing.ColorTranslator]::FromHtml($Bg2)
    $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, $b1, $b2, 45
    $g.FillRectangle($bg, $rect); $bg.Dispose()
    $glow = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(26, 255, 255, 255))
    $g.FillEllipse($glow, [int](-$Size*0.15), [int](-$Size*0.15), [int]($Size*0.85), [int]($Size*0.85))
    $glow.Dispose()
  }

  $fs  = [int]($Size * $GlyphScale)
  $fnt = New-Object System.Drawing.Font $fam, $fs, ([System.Drawing.FontStyle]::Regular), ([System.Drawing.GraphicsUnit]::Pixel)
  $sf = New-Object System.Drawing.StringFormat
  $sf.Alignment = [System.Drawing.StringAlignment]::Center
  $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
  $ca = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml($C1))
  $cb = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml($C2))

  $ax = [int]($Size * $PosA); $ay = [int]($Size * $PosA)
  $boxA = New-Object System.Drawing.RectangleF ($ax - $Size/2), ($ay - $Size/2), $Size, $Size
  $g.DrawString($wu, $fnt, $ca, $boxA, $sf)

  $bx = [int]($Size * $PosB); $by = [int]($Size * $PosB)
  $boxB = New-Object System.Drawing.RectangleF ($bx - $Size/2), ($by - $Size/2), $Size, $Size
  $g.DrawString($du, $fnt, $cb, $boxB, $sf)

  $g.Dispose()
  return $bmp
}

function Save-Logo {
  param([hashtable]$Opts, [string]$OutPath)
  $bmp = New-LogoBitmap @Opts
  $dir = Split-Path $OutPath -Parent
  Ensure $dir
  $bmp.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Output ("  -> " + $OutPath.Replace($root, '.') + "  " + (Get-Item $OutPath).Length + " B")
}

Write-Output 'web / app-internal logos'
Save-Logo @{ Size = 1024 } (Join-Path $here 'logo-1024.png')
Save-Logo @{ Size = 512 }  (Join-Path $webBrand 'logo-512.png')
Save-Logo @{ Size = 256 }  (Join-Path $webBrand 'logo-256.png')
Save-Logo @{ Size = 128 }  (Join-Path $webBrand 'logo-128.png')
Save-Logo @{ Size = 96 }   (Join-Path $webBrand 'logo-96.png')

Write-Output 'pwa icons'
Save-Logo @{ Size = 180 } (Join-Path $webIcons 'icon-180.png')
Save-Logo @{ Size = 192 } (Join-Path $webIcons 'icon-192.png')
Save-Logo @{ Size = 512 } (Join-Path $webIcons 'icon-512.png')
Save-Logo @{ Size = 512; GlyphScale = 0.30; PosA = 0.36; PosB = 0.64 } (Join-Path $webIcons 'icon-maskable-512.png')

Write-Output 'android launcher icons'
$dens = [ordered]@{ mdpi = 48; hdpi = 72; xhdpi = 96; xxhdpi = 144; xxxhdpi = 192 }
$fgs  = [ordered]@{ mdpi = 108; hdpi = 162; xhdpi = 216; xxhdpi = 324; xxxhdpi = 432 }
foreach ($k in $dens.Keys) {
  $dir = Join-Path $res ("mipmap-" + $k); Ensure $dir
  Save-Logo @{ Size = $dens[$k] } (Join-Path $dir 'ic_launcher.png')
  Save-Logo @{ Size = $dens[$k]; Round = $true } (Join-Path $dir 'ic_launcher_round.png')
  Save-Logo @{ Size = $fgs[$k]; Transparent = $true; GlyphScale = 0.20; PosA = 0.34; PosB = 0.66 } (Join-Path $dir 'ic_launcher_foreground.png')
}

Write-Output 'android splash screens'
function Draw-Splash([string]$dir, [int]$w, [int]$h) {
  $d = Join-Path $res $dir; Ensure $d
  $out = Join-Path $d 'splash.png'
  $side = [int]([Math]::Min($w, $h) * 0.46)
  if ($side -lt 96) { $side = 96 }
  $bmp = New-Object System.Drawing.Bitmap $w, $h, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $rect = New-Object System.Drawing.Rectangle 0, 0, $w, $h
  $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect,
        ([System.Drawing.ColorTranslator]::FromHtml('#f4f8fc')),
        ([System.Drawing.ColorTranslator]::FromHtml('#dfedf6')), 90
  $g.FillRectangle($bg, $rect); $bg.Dispose()

  $logo = New-LogoBitmap -Size $side
  $g.DrawImage($logo, [int](($w - $side) / 2), [int](($h - $side) / 2), $side, $side)
  $logo.Dispose()
  $g.Dispose()
  $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Output ("  -> " + $dir + " " + $w + "x" + $h)
}
$ports = [ordered]@{ 'drawable-port-mdpi' = '320x480'; 'drawable-port-hdpi' = '480x800'; 'drawable-port-xhdpi' = '720x1280';
                     'drawable-port-xxhdpi' = '960x1600'; 'drawable-port-xxxhdpi' = '1280x1920' }
$lands = [ordered]@{ 'drawable-land-mdpi' = '480x320'; 'drawable-land-hdpi' = '800x480'; 'drawable-land-xhdpi' = '1280x720';
                     'drawable-land-xxhdpi' = '1600x960'; 'drawable-land-xxxhdpi' = '1920x1280' }
foreach ($k in $ports.Keys) { $wh = $ports[$k] -split 'x'; Draw-Splash $k ([int]$wh[0]) ([int]$wh[1]) }
foreach ($k in $lands.Keys) { $wh = $lands[$k] -split 'x'; Draw-Splash $k ([int]$wh[0]) ([int]$wh[1]) }
Ensure (Join-Path $res 'drawable')
Copy-Item (Join-Path $res 'drawable-land-mdpi\splash.png') (Join-Path $res 'drawable\splash.png') -Force
Write-Output '  -> drawable\splash.png (default)'
Write-Output 'DONE'
