# install-autostart.ps1  (ASCII only on purpose - Windows PowerShell 5.1 reads UTF-8 without BOM as ANSI)
#
# 2026-09-25: "LAN just works, do not open any other tool".
# Puts a shortcut in the per-user Startup folder so the wudu LAN service comes up
# automatically at logon (no console window, via wscript + the VBS launcher).
#
# Usage:
#   powershell -File tools\install-autostart.ps1            # install
#   powershell -File tools\install-autostart.ps1 -Remove    # uninstall
#   powershell -File tools\install-autostart.ps1 -Status    # show current state

param(
  [switch]$Remove,
  [switch]$Status
)

$ErrorActionPreference = 'Stop'

$root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent   # tools\ -> project root
if (-not (Test-Path (Join-Path $root 'serve.js'))) { $root = Split-Path $PSScriptRoot -Parent }
$vbs = Join-Path $root 'wudu-serve-hidden.vbs'
if (-not (Test-Path $vbs)) { $vbs = Join-Path $root (Get-ChildItem $root -Filter '*.vbs' | Select-Object -First 1).Name }

$startup = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $startup 'Wudu LAN service.lnk'

if ($Status) {
  Write-Output ("project root : " + $root)
  Write-Output ("launcher vbs : " + $vbs + "  (exists=" + (Test-Path $vbs) + ")")
  Write-Output ("startup link : " + $lnk + "  (exists=" + (Test-Path $lnk) + ")")
  $svc = Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*serve.js*' }
  if ($svc) { $svc | ForEach-Object { Write-Output ("running      : PID " + $_.ProcessId + "  " + $_.CommandLine) } }
  else { Write-Output "running      : (no serve.js process)" }
  return
}

if ($Remove) {
  if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Output ("removed: " + $lnk) }
  else { Write-Output "nothing to remove (link not present)" }
  return
}

if (-not (Test-Path $vbs)) { throw ("launcher not found under " + $root) }

$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
$s.Arguments = '"' + $vbs + '"'
$s.WorkingDirectory = $root
$s.Description = 'Wudu LAN service (silent)'
$s.WindowStyle = 7
$s.Save()

Write-Output ("installed: " + $lnk)
Write-Output "it will start automatically at next logon."
Write-Output "to start it right now, run:"
Write-Output ('  wscript.exe "' + $vbs + '"')
Write-Output "to undo: powershell -File tools\install-autostart.ps1 -Remove"
