/* 雾读 · 按《代码自检报告》修必修项（C1 C2 B B2 D1 D2 C3 C4 F3 F4）
   用法：node tools/fix-selfcheck-20260925.mjs
   写前备份 app.js；每处替换都核对命中数，全部恰好 1 次才写盘。 */
/* ---- 重跑守卫（2026-09-25 流程自检后补）----
   本脚本是全文件重写式的一次性补丁，**已经应用过了**；再跑一次会把同样的内容
   重复插进去。要重跑请先加 --force，并用 _backup\ 里的对应备份还原目标文件。 */
if (!process.argv.includes('--force')) {
  const { existsSync } = await import('node:fs');
  const __flag = new URL('./.applied/' + import.meta.url.split('/').pop() + '.done', import.meta.url);
  if (existsSync(__flag)) {
    console.log('[跳过] 本批次已应用过（标记：tools/.applied/' + import.meta.url.split('/').pop() + '.done）');
    console.log('       重跑会重复插入内容；确要重跑：先还原备份，然后 node tools/' + import.meta.url.split('/').pop() + ' --force');
    process.exit(0);
  }
}

import fs from 'fs';
import path from 'path';

const ROOT = path.resolve('D:\\DeepSeek\\项目\\四六级单词');
const F = path.join(ROOT, 'assets', 'js', 'app.js');
let src = fs.readFileSync(F, 'utf8');
const patches = [];
function P(name, from, to) { patches.push({ name, from, to }); }

/* C1 真题答错抛异常：$$() 返回数组，数组没有 classList */
P('C1 真题答错 classList',
  `          if (!ok) $$('#realRun .opt[data-q="' + qi + '"][data-o="' + q.answer + '"]').classList.add('ok');`,
  `          if (!ok) $$('#realRun .opt[data-q="' + qi + '"][data-o="' + q.answer + '"]').forEach(function (x) { x.classList.add('ok'); });`);

/* C2 #revealLong 无 null 保护（分页后非末页不存在）→ 抛异常且 resetScroll 不再执行 */
P('C2 revealLong 空值保护',
  `      $('#revealLong').onclick = function () {`,
  `      var rvLong = $('#revealLong');
      if (rvLong) rvLong.onclick = function () {`);

/* B focusLog 脏数据 → 首页/专注页整屏白且不可自愈 */
P('B focusLog 数组护栏',
  `  var focusLog = load('wudu.focus.v1', []);`,
  `  // 自检 B：一次脏数据（非数组 / 元素不是对象）会让首页与专注页整屏白且无法自愈 —— 读取即净化
  var focusLog = (function () {
    var v = load('wudu.focus.v1', []);
    if (!Array.isArray(v)) return [];
    return v.filter(function (x) { return x && typeof x === 'object' && typeof x.minutes === 'number'; });
  })();`);

/* B2 硬门弹层：词库为空时 st.words[st.i] 为 undefined → 空白卡死 */
P('B2 renderHardTask 空值保护',
  `    var st = hardState, body = $('#hardBody');
    if (!st || !body) return;
    var w = st.words[st.i];`,
  `    var st = hardState, body = $('#hardBody');
    if (!st || !body) return;
    if (!st.words || !st.words.length || !st.words[st.i]) {
      body.innerHTML = '<div class="empty">题目数据缺失 —— 返回后重新进入专注</div>';
      return;
    }
    var w = st.words[st.i];`);

/* F4 记忆阶段字段被污染 → due 变 NaN → 该词永久不再到期 */
P('F4 recordAnswer 数值净化',
  `    var r = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0 };
    r.seen++;`,
  `    var r = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0 };
    // 自检 F4：s 或 due 一旦被写坏，due 会变成 "NaN-NaN-NaN" 并持久化，该词此后永远不再到期
    r.s = Number(r.s) || 0;
    if (typeof r.due !== 'string' || r.due.indexOf('NaN') >= 0) r.due = todayStr();
    r.seen = (Number(r.seen) || 0) + 1;`);

/* D2 备份包漏四类数据 */
P('D2 导出补全键',
  `        var pack = { app: 'wudu', at: todayStr(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin };`,
  `        // 自检 D2：备份必须含全部本地键 —— 语法 / 翻译 / 专注 / 未完成会话原先漏了，导入后静默消失
        var pack = {
          app: 'wudu', at: todayStr(),
          progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin,
          grammar: load('wudu.grammar.v1', {}), translate: load('wudu.translate.v1', {}),
          focus: load('wudu.focus.v1', []), quiz: load('wudu.quiz.v1', null)
        };`);

/* D1 + C3 导入：只判真值 + 无默认补全 + 先落盘后渲染 */
P('D1/C3 导入校验与默认补全',
  `        fr.onload = function () {
          try {
            var o = JSON.parse(String(fr.result));
            if (o.progress) progress = o.progress;
            if (o.stats) stats = o.stats;
            if (o.settings) settings = o.settings;
            if (o.adapt) adapt = o.adapt;
            if (o.checkin) checkin = o.checkin;
            saveAll(); renderHome(); renderPlan(); renderSettings();
            toast('已导入学习数据');
          } catch (e) { toast('导入失败：文件格式不对'); }
        };`,
  `        fr.onload = function () {
          var o = null;
          try { o = JSON.parse(String(fr.result)); }
          catch (e) { toast('导入失败：这不是有效的 JSON 文件'); return; }
          if (!o || typeof o !== 'object' || Array.isArray(o)) { toast('导入失败：内容不是备份格式'); return; }
          var isObj = function (x) { return !!x && typeof x === 'object' && !Array.isArray(x); };
          // 自检 D1：旧版只要字段是「真值」就覆盖 —— {"progress":{}} 会把整份进度清空并立刻落盘
          if (!isObj(o.progress) || !isObj(o.stats) || !isObj(o.settings)) {
            toast('导入失败：备份缺少必要字段（progress / stats / settings）');
            return;
          }
          // 先把现状留一份，导错了还能捞回来（自检 D1）
          try {
            localStorage.setItem('wudu.preimport', JSON.stringify({
              at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
            }));
          } catch (e) {}
          progress = o.progress;
          stats = o.stats;
          adapt = isObj(o.adapt) ? o.adapt : { mode: 'auto', recent: [] };
          checkin = sanitizeCheckin(isObj(o.checkin) ? o.checkin : { days: [] });
          // 自检 C3：导入的 settings 缺 examDate 之类的字段会让首页直接抛错 —— 用默认值补全
          settings = Object.assign(defaultSettings(), o.settings);
          if (isObj(o.grammar)) save('wudu.grammar.v1', o.grammar);
          if (isObj(o.translate)) save('wudu.translate.v1', o.translate);
          if (Array.isArray(o.focus)) save('wudu.focus.v1', o.focus);
          try {
            renderHome(); renderPlan(); renderSettings();
            saveAll();   // 自检 C3：落盘移到渲染成功之后，避免「报错但数据已被覆盖」
            toast('已导入学习数据');
          } catch (e) {
            toast('导入完成，但页面渲染出错：' + e.message + '（已留一份导入前快照）');
          }
        };`);

/* F3 + D4 清空：漏清四键 + 不可逆 */
P('F3/D4 清空补全与快照',
  `    var sWipe = $('#setWipe');
    if (sWipe) sWipe.onclick = function () {
      if (!confirm('清空全部进度？词库记录、统计、打卡都会归零，且无法恢复。')) return;
      progress = {}; stats = {}; adapt = { mode: 'auto', recent: [] }; checkin = { days: [] };
      saveAll(); renderHome(); renderPlan(); renderSettings();
      toast('已清空，一切从头开始');
    };`,
  `    var sWipe = $('#setWipe');
    if (sWipe) sWipe.onclick = function () {
      if (!confirm('清空全部进度？词库记录、统计、打卡都会归零。\\n（会先存一份快照，误点可找回）')) return;
      // 自检 D4：清空前留快照（独立键、不进镜像），否则连后路一起清掉
      try {
        localStorage.setItem('wudu.prewipe', JSON.stringify({
          at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
        }));
      } catch (e) {}
      progress = {}; stats = {}; adapt = { mode: 'auto', recent: [] }; checkin = { days: [] };
      // 自检 F3：旧版漏清语法 / 翻译 / 专注 / 未完成会话 —— 清完报告页还显示旧数据，还会弹「继续上次」
      save('wudu.grammar.v1', {}); save('wudu.translate.v1', {}); save('wudu.focus.v1', []);
      grammarProg = {}; trProg = {}; focusLog = []; focusLast = '';
      clearQuizSession();
      saveAll(); renderHome(); renderPlan(); renderSettings();
      toast('已清空，一切从头开始');
    };`);

/* C4 打卡数据净化：导入 timestamp 数组会让首页崩 */
P('C4 打卡数据净化',
  `  var checkin  = load(LS_CHECKIN, null);`,
  `  // 自检 C4：days 里混进数字（常见的手写时间戳）会让首页 renderCheckin 抛错 —— 读取与导入都要过滤
  function sanitizeCheckin(x) {
    if (!x || typeof x !== 'object') return { days: [] };
    var days = Array.isArray(x.days) ? x.days : [];
    x.days = days.filter(function (d) { return typeof d === 'string' && /^\\d{4}-\\d{2}-\\d{2}$/.test(d); });
    return x;
  }
  var checkin  = sanitizeCheckin(load(LS_CHECKIN, null));`);

/* 逐条替换 + 核对 */
const bak = F + '.bak-selfcheck-20260925';
if (!fs.existsSync(bak)) fs.copyFileSync(F, bak);
let fail = 0;
for (const p of patches) {
  const n = src.split(p.from).length - 1;
  if (n !== 1) { console.log('✗ ' + p.name + '：命中 ' + n + ' 次（要求 1 次），跳过'); fail++; continue; }
  src = src.replace(p.from, p.to);
  console.log('✓ ' + p.name);
}
if (fail) { console.log('\n有 ' + fail + ' 处未命中，**未写盘**；请检查基线是否已变。'); process.exit(1); }
fs.writeFileSync(F, src, 'utf8');
console.log('\n已写入 app.js；备份：' + bak);
