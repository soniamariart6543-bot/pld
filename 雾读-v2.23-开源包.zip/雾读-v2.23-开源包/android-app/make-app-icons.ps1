# Generate Android launcher icons (all densities) for the Wudu app.
# ASCII-only so Windows PowerShell 5.1 parses it.
Add-Type -AssemblyName System.Drawing

$app = $PSScriptRoot
$res = Join-Path $app "android\app\src\main\res"
$glyph = [string][char]0x96FE     # the glyph shown on the icon

$sizes = [ordered]@{ mdpi = 48; hdpi = 72; xhdpi = 96; xxhdpi = 144; xxxhdpi = 192 }

function New-Canvas([int]$n, [string]$path, [bool]$round, [bool]$transparent, [double]$glyphRatio) {
  $bmp = New-Object System.Drawing.Bitmap($n, $n, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $gr = [System.Drawing.Graphics]::FromImage($bmp)
  $gr.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $gr.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
  $gr.Clear([System.Drawing.Color]::Transparent)

  $rect = New-Object System.Drawing.Rectangle(0, 0, $n, $n)
  if (-not $transparent) {
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
      $rect,
      [System.Drawing.Color]::FromArgb(47, 127, 184),
      [System.Drawing.Color]::FromArgb(70, 179, 154),
      45.0)
    if ($round) {
      $p = New-Object System.Drawing.Drawing2D.GraphicsPath
      $p.AddEllipse(0, 0, $n, $n)
      $gr.SetClip($p)
    }
    $gr.FillRectangle($brush, 0, 0, $n, $n)
    $gr.ResetClip()
    $brush.Dispose()
  }

  $fontSize = [float]($n * $glyphRatio)
  $font = New-Object System.Drawing.Font("Microsoft YaHei", $fontSize, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
  $fmt = New-Object System.Drawing.StringFormat
  $fmt.Alignment = [System.Drawing.StringAlignment]::Center
  $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
  $box = New-Object System.Drawing.RectangleF(0, 0, $n, $n)
  $color = if ($transparent) { [System.Drawing.Color]::White } else { [System.Drawing.Color]::White }
  $sb = New-Object System.Drawing.SolidBrush($color)
  $gr.DrawString($glyph, $font, $sb, $box, $fmt)

  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
  $gr.Dispose(); $bmp.Dispose(); $font.Dispose(); $sb.Dispose()
}

foreach ($k in $sizes.Keys) {
  $n = $sizes[$k]
  $dir = Join-Path $res "mipmap-$k"
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  New-Canvas -n $n -path (Join-Path $dir "ic_launcher.png")            -round $false -transparent $false -glyphRatio 0.56
  New-Canvas -n $n -path (Join-Path $dir "ic_launcher_round.png")      -round $true  -transparent $false -glyphRatio 0.52
  New-Canvas -n $n -path (Join-Path $dir "ic_launcher_foreground.png") -round $false -transparent $true  -glyphRatio 0.46
  Write-Output ("mipmap-$k : " + $n + "px ok")
}

# keep the adaptive-icon XML, but make its background the brand gradient colour
$bg = Join-Path $res "drawable\ic_launcher_background.xml"
if (Test-Path $bg) {
  Copy-Item $bg (Join-Path $app "_backup_ic_launcher_background.xml") -Force
  @'
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient
        android:angle="45"
        android:startColor="#2F7FB8"
        android:endColor="#46B39A"
        android:type="linear" />
</shape>
'@ | Set-Content -Path $bg -Encoding UTF8
  Write-Output "background xml replaced (backup kept)"
}
Write-Output "done"
