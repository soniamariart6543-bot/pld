# 雾读 · R8 / ProGuard 规则
# Capacitor 的桥与插件都靠反射调用，必须整包保留，否则 release 包启动即崩。

-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin class * { *; }
-keep class com.getcapacitor.plugin.** { *; }

# WebView 暴露给 JS 的接口
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Cordova 插件（capacitor-cordova-android-plugins 里若有）
-keep class org.apache.cordova.** { *; }

# 保留行号（崩溃栈能定位），但隐藏源文件名
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
