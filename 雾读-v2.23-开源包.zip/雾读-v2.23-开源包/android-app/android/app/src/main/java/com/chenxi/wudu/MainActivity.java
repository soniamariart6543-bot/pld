package com.chenxi.wudu;

import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1) 可访问性（清单 P1-9）：允许双指缩放，跟随系统字体大小。
        //    旧实现 setSupportZoom(false) + setTextZoom(100) 同时封死「双指缩放」与
        //    「系统文字缩放」两条通路，等同于 WCAG 2.2 SC 1.4.4（Resize Text, AA）失败。
        //    现在：内置缩放控件隐藏（不遮挡界面）但双指缩放可用；textZoom 不再写死，
        //    由系统字体设置决定，用户在「显示 → 字体大小」里放大即可整页放大。
        WebView webView = (getBridge() != null) ? getBridge().getWebView() : null;
        if (webView != null) {
            WebSettings s = webView.getSettings();
            s.setSupportZoom(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);   // 隐藏 ± 控件，保留手势
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
        }

        // 2) 返回键：交给页面逐层退（答题中 → 设置页 → 开学页），
        //    已在开学页时页面返回 "exit"，此时才真正退出；页面自己会提示「再按一次」。
        final WebView wv = webView;
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (wv == null) { finish(); return; }
                wv.evaluateJavascript(
                    "(window.__onBackKey ? window.__onBackKey() : 'exit')",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (value == null) { return; }
                            if (value.replace("\"", "").trim().contains("exit")) { finish(); }
                        }
                    });
            }
        });
    }
}
