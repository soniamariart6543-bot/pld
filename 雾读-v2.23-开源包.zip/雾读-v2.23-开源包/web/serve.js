/* 雾读 · 本地静态预览服务器（零依赖，仅监听 127.0.0.1）
   用法：node serve.js [端口] [--local-only] [--no-sync]
     （2026-09-25 昀晞：默认就是「局域网可直接用」—— 不加任何参数，手机连同一 Wi-Fi 就能打开）
     --local-only  只绑 127.0.0.1（临时收紧、不给手机连时用）
     --no-sync     关掉多端互通端点 /sync（默认开）
     安全：**绝不绑 0.0.0.0** —— 只在「具体局域网 IP」与 127.0.0.1 上各起一个监听；
           来自局域网的写操作仍要配对码（连续错 20 次锁 5 分钟）。
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const ROOT = __dirname;
const PORT = parseInt(process.argv[2] || '8899', 10);
const SYNC_ON = !process.argv.includes('--no-sync');   // 2026-09-25 昀晞「默认就能互通」：默认开，--no-sync 关
const LAN_ON = !process.argv.includes('--local-only');   // 2026-09-25：默认就开，--local-only 缩回本机

/* P1-4：局域网直传要显式开，且只绑「具体的那一个」局域网地址 —— 不是 0.0.0.0 */
function lanAddress() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const n of nets[name] || []) {
      if (n.family === 'IPv4' && !n.internal) return n.address;
    }
  }
  return null;
}
const HOST = LAN_ON ? (lanAddress() || '127.0.0.1') : '127.0.0.1';   // 安全红线：绝不绑定 0.0.0.0

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.md': 'text/plain; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.opus': 'audio/ogg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav',
  '.jks': 'application/octet-stream'
};

/* ---------- APK 构建进度接口 ----------
   只读工程内的构建目录，给进度页轮询用；不做任何写操作。 */
const BUILD_DIR = path.join(__dirname, 'android-app', 'android', 'app', 'build');
const APK_PATH = path.join(BUILD_DIR, 'outputs', 'apk', 'debug', 'app-debug.apk');
const BUILD_LOG = path.join(__dirname, 'android-app', 'android', 'build.log');
let statCache = { t: 0, data: null };

function tailLines(file, n) {
  try {
    const buf = fs.readFileSync(file, 'utf8');
    const lines = buf.split(/\r?\n/).filter((l) => l.trim().length);
    return lines.slice(-n);
  } catch (e) { return []; }
}

function scanDir(dir, acc) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return acc; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) scanDir(p, acc);
    else {
      if (e.name === '.npmkeep') continue;   // Capacitor 模板的占位文件，不算构建产出
      try { acc.files++; acc.bytes += fs.statSync(p).size; } catch (err) {}
      if (e.name.endsWith('.dex')) acc.dex++;
      if (e.name === 'app-debug.apk') acc.apk = p;
    }
  }
  return acc;
}

function buildStatus() {
  const now = Date.now();
  if (statCache.data && now - statCache.t < 2000) return statCache.data;
  const acc = scanDir(BUILD_DIR, { files: 0, bytes: 0, dex: 0, apk: null });
  let apkSize = 0, apkMtime = 0;
  if (acc.apk && fs.existsSync(acc.apk)) {
    const st = fs.statSync(acc.apk);
    apkSize = st.size; apkMtime = st.mtimeMs;
  }
  const phase = apkSize > 0 ? 'done'
    : (acc.dex > 0 ? 'packaging'
      : (acc.files > 0 ? 'compiling' : 'starting'));

  const logs = tailLines(BUILD_LOG, 60);
  const taskLines = logs.filter((l) => /^\s*> Task /.test(l));
  const failedLine = logs.filter((l) => /BUILD FAILED|FAILURE:|error:/i.test(l)).pop() || '';
  let logMtime = 0;
  try { logMtime = fs.statSync(BUILD_LOG).mtimeMs; } catch (e) {}

  const data = {
    ok: true,
    ts: now,
    phase: failedLine ? 'failed' : phase,
    buildFiles: acc.files,
    buildSizeMB: +(acc.bytes / 1048576).toFixed(2),
    dexFiles: acc.dex,
    apk: apkSize > 0 ? { sizeKB: Math.round(apkSize / 1024), mtime: apkMtime } : null,
    hasApk: apkSize > 0,
    lastTask: (taskLines[taskLines.length - 1] || '').trim(),
    taskCount: taskLines.length,
    failedLine: failedLine.slice(0, 200),
    logMtime: logMtime,
    log: logs.slice(-14)
  };
  statCache = { t: now, data: data };
  return data;
}


/* ---------- P1-4 多端互通端点（2026-09-25 起默认开，--no-sync 关） ----------
   场景：手机浏览器打开 http://<电脑局域网IP>:8899/ 用雾读 → 数据与电脑上是同一份；
        或者把手机上的导出包 POST 上来，电脑端再拉取合并。
   安全：① 只绑 127.0.0.1（--lan 才扩到具体局域网 IP，绝不 0.0.0.0）；
        ② 写操作要一次性配对码（启动时打印在控制台）；
        ③ 不发 CORS 头 —— 只有从本服务打开的页面（同源）能调，外来网页读不到；
        ④ 连续失败 20 次锁 5 分钟，挡暴力猜码。 */
const SYNC_DIR = path.join(__dirname, 'sync');
const SYNC_MAX = 32 * 1024 * 1024;   // 单份上限 32 MB
const SYNC_KEEP = 5;                 // 只留最近 5 份
const PAIR_CODE = String(Math.floor(100000 + Math.random() * 900000));
let syncFails = 0, syncLockUntil = 0;

function syncList() {
  try { return fs.readdirSync(SYNC_DIR).filter((f) => /^wudu-.*\.json$/.test(f)).sort(); }
  catch (e) { return []; }
}
function syncNewest() {
  const list = syncList();
  return list.length ? path.join(SYNC_DIR, list[list.length - 1]) : null;
}
function syncCodeOK(req, url) {
  const q = new URLSearchParams((url.split('?')[1] || ''));
  const given = req.headers['x-wudu-code'] || q.get('code') || '';
  return String(given) === PAIR_CODE;
}
function sendJSON(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req, cb) {
  let size = 0; const chunks = [];
  req.on('data', (c) => {
    size += c.length;
    if (size > SYNC_MAX) { req.destroy(); return; }
    chunks.push(c);
  });
  req.on('end', () => cb(Buffer.concat(chunks).toString('utf8')));
  req.on('error', () => cb(null));
}

function syncGuard(req, res, url) {
  if (Date.now() < syncLockUntil) { sendJSON(res, 429, { ok: false, err: '配对码错误次数过多，请等 5 分钟' }); return false; }
  if (syncCodeOK(req, url)) { syncFails = 0; return true; }
  syncFails++;
  if (syncFails >= 20) { syncLockUntil = Date.now() + 300000; syncFails = 0; }
  sendJSON(res, 403, { ok: false, err: '配对码不对（看电脑上 serve.js 控制台打印的那 6 位数字）' });
  return false;
}

function handleRequest(req, res) {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);

  /* ---- 多端互通（P1-4）：探测端点不需要码，只回答「开没开」 ---- */
  if (urlPath === '/sync/ping') {
    // 2026-09-25 昀晞「默认就能互通」：电脑上打开的网页自动拿到配对码，省掉手输这一步。
    // 只回给**本机来源**（127.0.0.1 / ::1）—— 局域网里的手机拿不到码，仍要按原流程手填。
    const ip = String((req.socket && req.socket.remoteAddress) || '');
    const fromLocal = ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
    const out = { on: SYNC_ON, host: HOST, port: PORT };
    if (SYNC_ON && fromLocal) out.code = PAIR_CODE;
    sendJSON(res, 200, out);
    return;
  }
  if (urlPath.indexOf('/sync') === 0) {
    if (!SYNC_ON) { sendJSON(res, 404, { ok: false, err: '本服务的同步端点没开（启动时加 --sync）' }); return; }
    if (urlPath === '/sync/info') {
      if (!syncGuard(req, res, req.url)) return;
      const list = syncList();
      sendJSON(res, 200, { ok: true, files: list, latest: list[list.length - 1] || null });
      return;
    }
    if (urlPath === '/sync/latest') {
      if (!syncGuard(req, res, req.url)) return;
      const f = syncNewest();
      if (!f) { sendJSON(res, 404, { ok: false, err: '电脑上还没有同步过来的数据' }); return; }
      sendJSON(res, 200, { ok: true, file: path.basename(f), data: fs.readFileSync(f, 'utf8') });
      return;
    }
    if (urlPath === '/sync/put' && req.method === 'POST') {
      if (!syncGuard(req, res, req.url)) return;
      readBody(req, (txt) => {
        if (!txt) { sendJSON(res, 400, { ok: false, err: '空请求体' }); return; }
        let obj = null;
        try { obj = JSON.parse(txt); } catch (e) { sendJSON(res, 400, { ok: false, err: '不是合法 JSON' }); return; }
        if (!obj || obj.app !== 'wudu' || typeof obj.progress !== 'object') {
          sendJSON(res, 400, { ok: false, err: '这不是雾读的备份包' });
          return;
        }
        try {
          fs.mkdirSync(SYNC_DIR, { recursive: true });
          const stamp = new Date().toISOString().replace(/[:.]/g, '-');
          const file = path.join(SYNC_DIR, 'wudu-' + stamp + '.json');
          fs.writeFileSync(file, txt, 'utf8');
          const list = syncList();
          list.slice(0, Math.max(0, list.length - SYNC_KEEP)).forEach((f) => {
            try { fs.unlinkSync(path.join(SYNC_DIR, f)); } catch (e) {}
          });
          console.log('[sync] 收到手机数据 → ' + path.basename(file) + '（' + Object.keys(obj.progress).length + ' 条进度）');
          sendJSON(res, 200, { ok: true, file: path.basename(file), words: Object.keys(obj.progress).length });
        } catch (e) { sendJSON(res, 500, { ok: false, err: String((e && e.message) || e) }); }
      });
      return;
    }
    sendJSON(res, 404, { ok: false, err: '未知的 sync 路径' });
    return;
  }

  if (urlPath === '/api/build-status') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(buildStatus()));
    return;
  }
  if (urlPath === '/api/apk') {
    const st = fs.existsSync(APK_PATH) ? fs.statSync(APK_PATH) : null;
    if (!st) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('APK 还没构建好'); return; }
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Length': st.size,
      'Content-Disposition': 'attachment; filename="wudu.apk"'
    });
    fs.createReadStream(APK_PATH).pipe(res);
    return;
  }
  if (urlPath === '/' || urlPath === '') urlPath = '/index.html';
  const filePath = path.join(ROOT, path.normalize(urlPath).replace(/^([/\\])+/, ''));
  if (!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('403'); return; }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404 Not Found: ' + urlPath); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
}

/* 2026-09-25 昀晞「直接连局域网就能操作、不要打开其他工具」：
   默认在**具体的局域网 IP**与 127.0.0.1 上各起一个监听（同端口、两个地址）——
   手机连同一 Wi-Fi 直接打开；本机与探针照旧走 127.0.0.1。**绝不绑 0.0.0.0**（安全红线）。 */
const LAN_BIND = LAN_ON ? lanAddress() : null;
const BINDS = (LAN_BIND && LAN_BIND !== '127.0.0.1') ? [LAN_BIND, '127.0.0.1'] : ['127.0.0.1'];
BINDS.forEach((bindHost, idx) => {
  http.createServer(handleRequest).listen(PORT, bindHost, () => {
    if (idx !== 0) return;                          // 启动信息只打一次
    console.log('雾读已启动');
    if (LAN_BIND) console.log('  手机（连同一 Wi-Fi）打开：http://' + LAN_BIND + ':' + PORT + '/');
    console.log('  本机打开：http://127.0.0.1:' + PORT + '/');
    if (SYNC_ON) console.log('  多端互通已开 · 配对码：' + PAIR_CODE + '（电脑上的网页会自动带上，不用手输）');
    else console.log('  多端互通已关（--no-sync）');
    console.log('按 Ctrl+C 停止');
  });
});
