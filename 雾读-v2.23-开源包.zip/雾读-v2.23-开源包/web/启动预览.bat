@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在启动雾读预览（仅本机 127.0.0.1:8899）...
start "" http://127.0.0.1:8899/
node serve.js 8899
pause
