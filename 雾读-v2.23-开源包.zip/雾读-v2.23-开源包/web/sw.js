/* 雾读 · Service Worker
   策略：静态资源「缓存优先 + 后台更新」（离线可用），不做任何网络上报。
   改了页面资源后想强制刷新：把下面的 CACHE 版本号 +1。 */
const CACHE = 'wudu-v30';

const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/css/style.css',
  './assets/js/app.js',
  './assets/js/store.js',
  './assets/js/data/cet4.js',
  './assets/js/data/cet6.js',
  './assets/js/data/real.js',
  './assets/js/data/real-cloze.js',
  './assets/js/data/real-reading.js',
  './assets/js/data/grammar.js',
  './assets/js/data/translate.js',
  './assets/js/data/translate-more.js',
  './assets/js/data/writing.js',
  './assets/js/data/writing-more.js',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((cache) => Promise.all(ASSETS.map((u) => cache.add(u).catch(() => {}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // 只处理本站资源，不发任何外部请求
  // SW 脚本自身与清单绝不能被缓存拦截，否则浏览器永远发现不了新版本
  if (url.pathname.endsWith('/sw.js') || url.pathname.endsWith('/manifest.webmanifest')) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const hit = await cache.match(req, { ignoreSearch: true });
    const network = fetch(req)
      .then((res) => {
        if (res && res.status === 200) cache.put(req, res.clone()).catch(() => {});
        return res;
      })
      .catch(() => null);
    if (hit) return hit;                              // 先给缓存，后台再更新
    const res = await network;
    if (res) return res;
    const shell = await cache.match('./index.html');
    return shell || Response.error();
  })());
});






