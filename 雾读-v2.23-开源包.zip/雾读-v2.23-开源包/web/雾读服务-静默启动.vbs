' Wudu LAN service - silent launcher (no console window).
' 2026-09-25: so the PC needs nothing opened by hand - double click this,
' or let it run at logon (see tools\install-autostart.ps1).
' ASCII only on purpose: wscript's script engine is happiest with ANSI/ASCII.
Option Explicit

Dim sh, fso, root, logDir, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

root = fso.GetParentFolderName(WScript.ScriptFullName)
logDir = root & "\logs"
If Not fso.FolderExists(logDir) Then fso.CreateFolder(logDir)

sh.CurrentDirectory = root

' 0 = hidden window, False = do not wait for it to finish
cmd = "cmd /c node serve.js 8899 >> """ & logDir & "\serve.log"" 2>&1"
sh.Run cmd, 0, False
