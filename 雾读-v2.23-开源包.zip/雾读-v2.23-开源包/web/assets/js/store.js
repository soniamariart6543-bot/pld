/* ============================================================
   雾读 · 存储层（清单 P1-8）
   ------------------------------------------------------------
   为什么换：`progress` 学满 7153 词时约 1.77 MB，每次落盘都要
   `JSON.stringify` + `localStorage.setItem` 同步写主线程，低端机会顿；
   且 localStorage 上限（Chromium 实测约 10 MiB/源）是硬天花板。
   IndexedDB 提供更大的配额与**异步**写入（不阻塞渲染）。

   本层的取舍 —— 「不丢数据」优先于「少写一份」：
     · 大键（progress / stats）**主存储 = IndexedDB**，异步写，不阻塞；
       同时在小体积时仍往 localStorage 写一份兼容副本（≤ COMPAT_LIMIT），
       这样「IDB 被系统清掉 / 换浏览器打开」时还有东西可读。
     · 体积超过上限的兼容副本就停写 —— 省下的正是最贵的那次同步序列化。
     · 启动仍然**同步**从 localStorage 读（首屏不能等异步），
       IDB 就绪后在后台水合；IDB 有数据且与内存不一致时才覆盖 + 重渲染。
     · IDB 不可用（隐私模式 / 老内核）→ 完全退回旧行为，功能不受影响。

   回滚：删掉本文件与 index.html 的 <script> 引用即可 —— app.js 会走 localStorage 分支。
   ============================================================ */
(function () {
  'use strict';

  var DB_NAME = 'wudu-store';
  var DB_VER = 1;
  var STORE = 'kv';
  var COMPAT_LIMIT = 512 * 1024;   // 兼容副本的体积上限（字节）：超过就不再同步写 localStorage

  var _db = null, _ok = false, _settled = false, _resolve = null;
  var ready = new Promise(function (r) { _resolve = r; });

  function settle(v) {
    if (_settled) return;
    _settled = true;
    _ok = !!v;
    _resolve(!!v);
  }

  function wrap(request) {
    return new Promise(function (res, rej) {
      request.onsuccess = function () { res(request.result); };
      request.onerror = function () { rej(request.error); };
    });
  }

  function open() {
    if (!window.indexedDB) { settle(false); return; }
    var r;
    try { r = window.indexedDB.open(DB_NAME, DB_VER); }
    catch (e) { settle(false); return; }
    r.onupgradeneeded = function () {
      var d = r.result;
      if (!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE);
    };
    r.onsuccess = function () { _db = r.result; settle(true); };
    r.onerror = function () { settle(false); };
    r.onblocked = function () { settle(false); };
    // 兜底：IDB 卡住（某些内核在隐私模式会一直挂着）时不能让应用等它
    setTimeout(function () { settle(!!_db); }, 3000);
  }

  function tx(mode, fn) {
    if (!_db) return Promise.reject(new Error('idb-unavailable'));
    try {
      var t = _db.transaction(STORE, mode);
      var st = t.objectStore(STORE);
      var out = fn(st);
      return out instanceof Promise ? out : Promise.resolve(out);
    } catch (e) { return Promise.reject(e); }
  }

  window.WUDU_STORE = {
    ready: ready,
    COMPAT_LIMIT: COMPAT_LIMIT,
    usable: function () { return _ok; },
    get: function (key) {
      return tx('readonly', function (st) { return wrap(st.get(key)); })
        .then(function (v) { return (v == null) ? null : v; });
    },
    put: function (key, str) {
      return tx('readwrite', function (st) { return wrap(st.put(str, key)); });
    },
    del: function (key) {
      return tx('readwrite', function (st) { return wrap(st.delete(key)); });
    },
    keys: function () {
      return tx('readonly', function (st) { return wrap(st.getAllKeys()); });
    },
    /* 把 localStorage 里现有的键搬进 IDB（只在 IDB 还没有该键时搬 —— 不覆盖较新的数据） */
    migrate: function (keyList) {
      return ready.then(function (ok) {
        if (!ok) return [];
        var moved = [];
        return Promise.all(keyList.map(function (k) {
          return window.WUDU_STORE.get(k).then(function (cur) {
            if (cur != null) return null;
            var ls = null;
            try { ls = window.localStorage.getItem(k); } catch (e) { ls = null; }
            if (ls == null) return null;
            return window.WUDU_STORE.put(k, ls).then(function () { moved.push(k); return k; });
          }).catch(function () { return null; });
        })).then(function () { return moved; });
      });
    }
  };

  open();
})();
