/* ============================================================
   雾读 · 四六级单词训练 —— 应用逻辑
   纯前端 · 无依赖 · 进度存 localStorage
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- 常量 ---------------- */
  var LS_PROGRESS = 'wudu.progress.v1';   // 单词记忆状态
  var LS_SETTINGS = 'wudu.settings.v1';   // 计划设置
  var LS_STATS    = 'wudu.stats.v1';      // 每日学习统计
  var LS_ADAPT    = 'wudu.adapt.v1';      // 自适应引擎：近期答题样本 + 档位
  var LS_CHECKIN  = 'wudu.checkin.v1';    // 打卡日历

  // 记忆曲线间隔（天）：阶段 0 为刚学，7 为长期记忆
  var INTERVALS = [0, 1, 2, 4, 7, 15, 30, 60];
  var MASTER_STAGE = 5;                   // 阶段 >= 5 视为已掌握

  var WORDS = [];
  var BY_WORD = {};
  // 真题模式的数据源 = 内置仿真题 + 抓取扩充题库（选词填空/阅读）+ 翻译库 + 写作库
  function allPapers() {
    var out = [];
    (window.REAL_PAPERS || []).forEach(function (p) { out.push(p); });
    (window.REAL_CLOZE || []).forEach(function (p) { out.push(p); });
    (window.REAL_READING || []).forEach(function (p) { out.push(p); });
    [].concat(window.TRANSLATION_BANK || [], window.TRANSLATION_MORE || []).forEach(function (p) {
      out.push({
        id: 'tr-' + p.id, level: p.level, year: p.year, type: '翻译',
        title: p.title, prompt: '将下面这段中文译成英语，注意时态统一与主谓一致。',
        source: p.source_text || p.source || '', reference: p.reference || '',
        points: p.scoring || [], keyWords: p.keyWords || [], verified: p.verified
      });
    });
    var wk = [].concat((window.WRITING_KIT && window.WRITING_KIT.topics) || [], window.WRITING_MORE || []);
    wk.forEach(function (t) {
      out.push({
        id: 'wr-' + t.id, level: t.level, year: t.year || '仿真', type: '写作',
        title: t.title, prompt: t.prompt, outline: t.outline || [],
        sample: t.sample || '', expressions: t.expressions || [],
        verified: t.verified, source: t.source || ''
      });
    });
    // 去重（按 id）
    var seen = {}, uniq = [];
    out.forEach(function (p) { if (p && p.id && !seen[p.id]) { seen[p.id] = 1; uniq.push(p); } });
    return uniq;
  }
  var PAPERS = allPapers();

  var progress = load(LS_PROGRESS, {});
  var settings = load(LS_SETTINGS, null);
  var stats    = load(LS_STATS, {});
  var adapt    = load(LS_ADAPT, null);
  // 自检 C4：days 里混进数字（常见的手写时间戳）会让首页 renderCheckin 抛错 —— 读取与导入都要过滤
  function sanitizeCheckin(x) {
    if (!x || typeof x !== 'object') return { days: [] };
    var days = Array.isArray(x.days) ? x.days : [];
    x.days = days.filter(function (d) { return typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d); });
    return x;
  }
  var checkin  = sanitizeCheckin(load(LS_CHECKIN, null));

  /* ---------------- 基础工具 ---------------- */
  function load(key, dft) {
    try { var s = localStorage.getItem(key); return s ? JSON.parse(s) : dft; }
    catch (e) { return dft; }
  }
  // 写入失败（配额 / 被拒）不再静默吞掉 —— 这是唯一会丢进度的隐患（清单 P0-7）
  var writeFail = null, saveWarned = false, _dirty = false, _saveTimer = null;
  function reportWriteFail(key, size, e) {
    var quota = false, nm = '', msg = '';
    try {
      nm = String((e && e.name) || ''); msg = String((e && e.message) || '');
      quota = nm === 'QuotaExceededError' || nm === 'NS_ERROR_DOM_QUOTA_REACHED' ||
              (e && (e.code === 22 || e.code === 1014)) || /quota|exceed|storage is full/i.test(nm + ' ' + msg);
    } catch (_) {}
    writeFail = { key: key, size: size, quota: quota, name: nm };
    try { console.warn('[雾读] 写入失败', key, size, nm, msg); } catch (_) {}
    showStoreWarn(quota);
  }
  function showStoreWarn(quota) {
    var host = document.getElementById('storeWarn');
    if (host) {
      host.style.display = 'block';
      host.innerHTML = '⚠ 本机存储写入失败（' + (quota ? '空间不足' : '被系统拒绝') + '）—— 进度可能没保存。' +
        '建议先「设置 → 应用 → 导出备份」留一份。' +
        '<button class="btn sm ghost" id="storeWarnGo" style="margin-left:8px">去导出</button>' +
        '<button class="btn sm ghost" id="storeWarnX">知道了</button>';
      var b1 = document.getElementById('storeWarnGo'), b2 = document.getElementById('storeWarnX');
      if (b1) b1.onclick = function () { go('settings'); };
      if (b2) b2.onclick = function () { host.style.display = 'none'; };
    }
    if (saveWarned) return;
    saveWarned = true;
    toast(quota ? '存储空间满了：进度可能存不下，请先导出备份' : '本机存储写入失败，建议先导出备份');
  }
  /* P1-8 存储分层：大键（progress / stats）主存储改 IndexedDB —— 异步写不阻塞主线程；
     小体积时仍同步写一份 localStorage 兼容副本（IDB 被系统清掉 / 换浏览器时兜底）。
     小键（settings / adapt / checkin）继续走 localStorage：它们只有几百字节，同步最省事。 */
  var IDB_KEYS = {};
  IDB_KEYS[LS_PROGRESS] = 1; IDB_KEYS[LS_STATS] = 1;
  function storeUsable() { return !!(window.WUDU_STORE && window.WUDU_STORE.usable()); }
  function save(key, val) {
    var s = null;
    try { s = JSON.stringify(val); }
    catch (e) { reportWriteFail(key, 0, e); return; }
    if (s == null) return;
    if (IDB_KEYS[key] && storeUsable()) {
      var p = window.WUDU_STORE.put(key, s);           // 主存储：IndexedDB（异步）
      if (p && p.catch) p.catch(function (e) { reportWriteFail(key, s.length, e); });
      if (s.length <= window.WUDU_STORE.COMPAT_LIMIT) { // 兼容副本：小才同步写，大 JSON 不阻塞
        try { localStorage.setItem(key, s); } catch (e) {}
      }
    } else {
      try { localStorage.setItem(key, s); }
      catch (e) { reportWriteFail(key, s.length, e); }
    }
    // 原生外壳：往 Android Preferences 再镜像一份 —— 清缓存 / 升级安装不丢进度
    if (window.WUDU_NATIVE && window.WUDU_NATIVE.isNative) window.WUDU_NATIVE.store(key, s);
  }
  // 写入策略：答题热路径不再「每题全量双写」，改为标脏 + 1.2 秒防抖；
  // 切页 / 页面隐藏 / 退出前强制落盘，保证不丢（清单 P1-7）
  function markDirty() {
    _dirty = true;
    invalidateCounts();          // P1-8：进度一变，counts 的缓存立刻作废（别让首页显示旧数字）
    if (_saveTimer) return;
    _saveTimer = setTimeout(function () { _saveTimer = null; flushSave(); }, 1200);
  }
  function flushSave() {
    if (!_dirty) return;
    _dirty = false;
    if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
    saveAll();
  }
  function saveAll() {
    invalidateCounts();          // 同步落盘路径（收藏 / 导入 / 清空 / 计划）同样让缓存作废
    save(LS_PROGRESS, progress); save(LS_SETTINGS, settings); save(LS_STATS, stats); save(LS_ADAPT, adapt); save(LS_CHECKIN, checkin);
  }
  window.addEventListener('pagehide', flushSave);
  window.addEventListener('beforeunload', flushSave);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { flushSave(); if (typeof saveQuizSession === 'function') saveQuizSession(); }
  });
  function $(sel) { return document.querySelector(sel); }
  function $$(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function todayStr(d) {
    d = d || new Date();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + m + '-' + day;
  }
  function addDays(dateStr, n) {
    var p = dateStr.split('-').map(Number);
    var d = new Date(p[0], p[1] - 1, p[2]);
    d.setDate(d.getDate() + n);
    return todayStr(d);
  }
  function diffDays(a, b) { // b - a 的天数
    var pa = a.split('-').map(Number), pb = b.split('-').map(Number);
    return Math.round((new Date(pb[0], pb[1] - 1, pb[2]) - new Date(pa[0], pa[1] - 1, pa[2])) / 86400000);
  }
  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('on');
    clearTimeout(t._tm); t._tm = setTimeout(function () { t.classList.remove('on'); }, 1900);
  }
  function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z]/g, ''); }
  // 词形归一：给出一个词的所有常见变形，用于「复数/词形吻合」判定
  function stems(s) {
    return [s, s.replace(/s$/, ''), s.replace(/es$/, ''), s.replace(/ies$/, 'y')];
  }
  // 宽松判定：容忍复数、大小写、拼写中的连字符
  function looseEq(a, b) {
    var x = norm(a), y = norm(b);
    if (!x || !y) return false;
    if (x === y) return true;
    var sx = stems(x), sy = stems(y);
    return sx.some(function (v) { return sy.indexOf(v) >= 0; });
  }

  /* ==========================================================
     答案归一化与宽松判分 —— 照搬成熟做法：
     墨墨「少量笔误不重罚」 + Anki 的逐字符三色对比 + Quizlet 申诉
     ========================================================== */
  function normalizeAns(s) {
    return String(s == null ? '' : s)
      .trim().toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')      // 去重音符号
      .replace(/[\u2018\u2019\u02bc`]/g, "'")
      .replace(/[\u2010-\u2015]/g, '-')                       // 统一各种连字符
      .replace(/[.!?,;:]+$/g, '')
      .replace(/\s+/g, ' ');
  }
  // 英美拼写变体：-ise/-ize、-our/-or、-re/-er、双写辅音
  function variantForms(w) {
    var out = [];
    [[/ise\b/g, 'ize'], [/ize\b/g, 'ise'], [/isation\b/g, 'ization'], [/ization\b/g, 'isation'],
     [/our\b/g, 'or'], [/or\b/g, 'our'], [/re\b/g, 'er'], [/er\b/g, 're'],
     [/lling\b/g, 'ling'], [/lled\b/g, 'led'], [/ller\b/g, 'ler']].forEach(function (p) {
      var v = w.replace(p[0], p[1]);
      if (v !== w && out.indexOf(v) < 0) out.push(v);
    });
    return out;
  }
  function lev(a, b) {
    var m = a.length, n = b.length, i, j;
    if (!m) return n; if (!n) return m;
    var prev = [], cur = [];
    for (j = 0; j <= n; j++) prev[j] = j;
    for (i = 1; i <= m; i++) {
      cur[0] = i;
      for (j = 1; j <= n; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      prev = cur.slice();
    }
    return prev[n];
  }
  // 判定：{ ok, kind: exact|plural|variant|near|wrong|empty, dist }
  function judge(input, answer) {
    var a = normalizeAns(input), b = normalizeAns(answer);
    if (!a) return { ok: false, kind: 'empty', dist: 99 };
    if (a === b) return { ok: true, kind: 'exact', dist: 0 };
    if (looseEq(a, b)) return { ok: true, kind: 'plural', dist: 0 };
    if (variantForms(b).indexOf(a) >= 0) return { ok: true, kind: 'variant', dist: 0 };
    var d = lev(a, b);
    if (b.length >= 5 && d <= 1) return { ok: true, kind: 'near', dist: d };  // 少量笔误不重罚
    return { ok: false, kind: 'wrong', dist: d };
  }
  var KIND_LABEL = {
    exact: '', plural: '数/词形吻合', variant: '英美拼写变体', near: '拼写接近（算对）',
    wrong: '拼写错误', empty: '未作答'
  };
  // 逐字符三色对比：绿=对，红=多打，灰=漏打
  function diffHtml(input, answer) {
    var a = normalizeAns(input), b = normalizeAns(answer);
    if (!a) return '<span class="d-miss">' + esc(b) + '</span>';
    var m = a.length, n = b.length, i, j, dp = [];
    for (i = 0; i <= m; i++) { dp[i] = []; for (j = 0; j <= n; j++) dp[i][j] = 0; }
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
    var out = [], x = m, y = n;
    while (x > 0 && y > 0) {
      if (a[x - 1] === b[y - 1]) { out.unshift('<span class="d-ok">' + esc(b[y - 1]) + '</span>'); x--; y--; }
      else if (dp[x - 1][y] >= dp[x][y - 1]) { out.unshift('<span class="d-bad">' + esc(a[x - 1]) + '</span>'); x--; }
      else { out.unshift('<span class="d-miss">' + esc(b[y - 1]) + '</span>'); y--; }
    }
    while (x > 0) { out.unshift('<span class="d-bad">' + esc(a[x - 1]) + '</span>'); x--; }
    while (y > 0) { out.unshift('<span class="d-miss">' + esc(b[y - 1]) + '</span>'); y--; }
    return out.join('');
  }

  /* ==========================================================
     朗读（TTS）—— 用系统语音合成，离线可用
     ========================================================== */
  /* ==========================================================
     朗读（TTS）
     · 网页 / 浏览器：Web Speech API
     · App（Capacitor WebView）：Android WebView 不支持 speechSynthesis，
       改走原生插件 @capacitor-community/text-to-speech（系统 TTS 引擎）
     ========================================================== */
  /* Capacitor 的原生桥是在页面加载「之后」注入的 —— 插件句柄必须用到时再取，
     不能在模块初始化时抓一次（那时 window.Capacitor 还不存在，会永远拿到 null，
     表现就是手机上一直提示「这个环境不支持朗读」）。 */
  var _ttsPlugin = null;
  function nativeTTS() {
    if (!_ttsPlugin) {
      try {
        if (window.Capacitor && typeof window.Capacitor.registerPlugin === 'function') {
          _ttsPlugin = window.Capacitor.registerPlugin('TextToSpeech');
          tts.native = !!_ttsPlugin;
        }
      } catch (e) { _ttsPlugin = null; }
    }
    return _ttsPlugin;
  }

  /* ============ 本机音源包（assets/audio/*.mp3） ============
     tools/audio/gen_audio.py 预先合成好、随 App 一起打包。
     朗读优先走它 —— 不依赖系统 TTS 引擎（国产 ROM 常把引擎精简掉，
     表现就是「这个环境不支持朗读」）。浏览器里同样有效。 */
  function audioIndex() {
    var A = window.WUDU_AUDIO;
    return (A && A.words) ? A : null;
  }
  function hasLocalAudio() {
    var A = audioIndex();
    return !!(A && (Object.keys(A.words).length || Object.keys(A.listen || {}).length));
  }
  /* P0-5 音频分包：APK 只带小包（单词 36 MB + 听力 5 MB + 英音 11 MB），
     例句音频约 127 MB 不随包走 —— 由 sync-www.ps1 在打包时重写 audio-packs.js。
     没有的包直接当「没有本地音源」，避免每次播放都撞一次 404（例句听写会一顿一顿）。 */
  function audioPacks() {
    var P = window.WUDU_AUDIO_PACKS;
    return P || { words: true, listen: true, uk: true, lines: true };
  }
  function packFor(rel) {
    var r = String(rel || '');
    if (r.indexOf('assets/audio/e/') === 0 || r.indexOf('assets/audio/e-o/') === 0) return 'lines';
    if (r.indexOf('assets/audio/l/') === 0 || r.indexOf('assets/audio/l-o/') === 0) return 'listen';
    if (r.indexOf('assets/audio/w-uk') === 0) return 'uk';
    if (r.indexOf('assets/audio/w') === 0) return 'words';
    return null;
  }
  function packOk(rel) {
    if (!rel) return false;
    var p = packFor(rel);
    return p ? audioPacks()[p] !== false : true;
  }
  function localWord(text) {
    var A = audioIndex();
    if (!A) return null;
    var k = String(text == null ? '' : text).trim();
    var rel = A.words[k] || A.words[k.toLowerCase()] || null;
    return packOk(rel) ? rel : null;
  }
  // 英音索引（P1-5）：只覆盖高频词 2378 条，查不到就回落美音
  function localWordUK(text) {
    var A = window.WUDU_AUDIO_UK;
    if (!A || !A.words) return null;
    var k = String(text == null ? '' : text).trim();
    var rel = A.words[k] || A.words[k.toLowerCase()] || null;
    return packOk(rel) ? rel : null;
  }
  function hasUKAudio() {
    var A = window.WUDU_AUDIO_UK;
    return !!(A && A.words && Object.keys(A.words).length) && audioPacks().uk !== false;
  }
  function localListen(id) {
    var A = audioIndex();
    var rel = (A && A.listen && A.listen[id]) || null;
    return packOk(rel) ? rel : null;
  }
  // 听力逐句（键 'id|序号'）—— 点某一句话单独重听时也要能离线播
  function localListenLine(id, i) {
    var A = window.WUDU_AUDIO;
    if (!A || !A.lines) return null;
    var rel = A.lines[id + '|' + i] || null;
    return packOk(rel) ? rel : null;
  }
  var _audioEl = null;
  function playLocal(rel, opt) {
    opt = opt || {};
    try {
      if (_audioEl) { try { _audioEl.pause(); } catch (e2) {} _audioEl = null; }
      var a = new Audio(rel);
      // P0-5 兜底：索引里写了、包里其实没有（分包后的例句音频）→ 立刻交给上层回退，
      // 别出现「点了喇叭、界面像在播、实际一点声音没有」这种静默失败
      a.onerror = function () { if (opt.onFail) opt.onFail(); };
      var r = (opt.rate || tts.rate) / 0.95;      // 音源按 0.95× 录的，跟着设置微调
      if (r && Math.abs(r - 1) > 0.02) a.playbackRate = Math.min(1.6, Math.max(0.6, r));
      if (opt.onEnd) a.onended = opt.onEnd;
      var pr = a.play();
      if (pr && pr.catch) pr.catch(function () { if (opt.onFail) opt.onFail(); });
      _audioEl = a;
      return { local: true, el: a };
    } catch (e) { return null; }
  }
  function stopLocal() {
    try { if (_audioEl) { _audioEl.pause(); _audioEl = null; } } catch (e) {}
  }

  var tts = {
    native: false,
    voices: [], en: null, zh: null, rate: 0.95, enabled: true, seqToken: 0
  };
  Object.defineProperty(tts, 'ok', {
    get: function () {
      return (typeof window !== 'undefined' && 'speechSynthesis' in window) || !!nativeTTS() || hasLocalAudio();
    }
  });
  var buzzOn = true;          // 震动开关（声音类反馈必须可关）
  function ttsInit() {
    if (nativeTTS() || !('speechSynthesis' in window)) return;
    function pick() {
      try { tts.voices = window.speechSynthesis.getVoices() || []; } catch (e) { tts.voices = []; }
      tts.en = tts.voices.filter(function (v) { return /^en[-_]?(US|GB|AU|CA)?/i.test(v.lang); })[0] || null;
      tts.zh = tts.voices.filter(function (v) { return /^zh/i.test(v.lang); })[0] || null;
    }
    pick();
    try { window.speechSynthesis.onvoiceschanged = pick; } catch (e) {}
  }
  function speak(text, opt) {
    opt = opt || {};
    text = String(text == null ? '' : text).trim();
    if (!text || !tts.enabled) return null;
    // ① 本机音源包优先 —— 离线、不挑系统、一定有声音
    if (!opt.forceTTS) {
      // 设置里选了英音就先查英音索引，查不到自动回落美音（P1-5）
      var rel = (settings && settings.voice === 'uk') ? (localWordUK(text) || localWord(text)) : localWord(text);
      if (rel) {
        // P0-5：分包后索引里可能还留着没随包走的例句音频 —— 真播放失败时回退 TTS
        var inner = {};
        for (var kk in opt) { if (Object.prototype.hasOwnProperty.call(opt, kk)) inner[kk] = opt[kk]; }
        inner.onFail = function () { speak(text, { forceTTS: true, lang: opt.lang, rate: opt.rate, queue: opt.queue, onEnd: opt.onEnd }); };
        var got = playLocal(rel, inner);
        if (got) return got;
      }
    }
    // ② 退回系统 TTS（原生插件 / 浏览器合成）
    if (!tts.ok) return null;
    var isZh = opt.lang ? /^zh/i.test(opt.lang) : /[\u4e00-\u9fa5]/.test(text);
    var plug = nativeTTS();
    if (plug) {
      try {
        if (!opt.queue) plug.stop().catch(function () {});
        plug.speak({
          text: text,
          lang: opt.lang || (isZh ? 'zh-CN' : 'en-US'),
          rate: opt.rate || tts.rate,
          pitch: 1, volume: 1, category: 'ambient'
        }).catch(function (err) {
          if (opt.onFail) opt.onFail(err); else toast('朗读失败：' + ((err && err.message) || '系统语音不可用'));
        });
        return { native: true };
      } catch (e) { return null; }
    }
    try {
      if (!opt.queue) window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = opt.lang || (isZh ? 'zh-CN' : 'en-US');
      u.rate = opt.rate || tts.rate;
      u.pitch = opt.pitch || 1;
      if (!isZh && tts.en) u.voice = tts.en;
      if (isZh && tts.zh) u.voice = tts.zh;
      window.speechSynthesis.speak(u);
      return u;
    } catch (e) { return null; }
  }
  function stopSpeak() {
    tts.seqToken = (tts.seqToken || 0) + 1;
    stopLocal();
    var plug = nativeTTS();
    try {
      if (plug) { plug.stop().catch(function () {}); return; }
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    } catch (e) {}
  }
  function speakSeq(lines, opt) {
    // 依次朗读（听力材料用）：lines = [{text, lang?, rate?, gap?}]
    if (!tts.enabled) { toast('朗读开关是关的 · 去「设置 → 播放与反馈」打开'); return; }
    if (!tts.ok) { toast('这个环境不支持朗读 · 手机端请装最新版 App'); return; }
    var plugSeq = nativeTTS();
    if (plugSeq) {
      stopSpeak();
      var token = tts.seqToken, i = 0;
      function step() {
        if (token !== tts.seqToken || i >= lines.length) return;
        var L = lines[i++];
        var zh = L.lang ? /^zh/i.test(L.lang) : /[\u4e00-\u9fa5]/.test(String(L.text));
        plugSeq.speak({
          text: String(L.text),
          lang: L.lang || (zh ? 'zh-CN' : 'en-US'),
          rate: L.rate || tts.rate, pitch: 1, volume: 1, category: 'ambient'
        }).then(function () { setTimeout(step, L.gap || 350); })
          .catch(function () { setTimeout(step, 300); });
      }
      step();
      return;
    }
    stopSpeak();
    var i = 0;
    function next() {
      if (i >= lines.length) return;
      var L = lines[i++];
      var u = speak(L.text, { lang: L.lang, rate: L.rate, queue: true });
      if (!u) { setTimeout(next, 300); return; }
      u.onend = function () { setTimeout(next, L.gap || 350); };
      u.onerror = function () { setTimeout(next, 300); };
    }
    next();
  }

  /* ---------------- 数据装载 ---------------- */
  function buildWordBank() {
    var raw = [].concat(window.CET4_WORDS || [], window.CET6_WORDS || []);
    var extra = window.EXTRA_NOTES || {};   // 内容补齐批次（清单 P0-1）：搭配 + 用法说明
    var seen = {};
    WORDS = [];
    raw.forEach(function (o) {
      if (!o || !o.w) return;
      var key = String(o.w).toLowerCase();
      o.w = key;
      o.level = o.level || 'cet4';
      if (seen[key]) {
        // 同一个词同时收在两套词书里：合并级别标记，而不是丢掉后一份
        var prev = seen[key];
        if (prev.level.split(',').indexOf(o.level) < 0) prev.level = prev.level + ',' + o.level;
        return;
      }
      // 补齐：原词条为空时才填，手写精修过的 310 条不动
      var ex = extra[key];
      if (ex) {
        if ((!o.colloc || !o.colloc.length) && ex.colloc && ex.colloc.length) o.colloc = ex.colloc;
        if ((!o.note || !String(o.note).trim()) && ex.note) o.note = ex.note;
      }
      seen[key] = o;
      WORDS.push(o);
      BY_WORD[key] = o;
    });
  }
  function bankOf(level) {
    if (!level) return WORDS;
    return WORDS.filter(function (w) { return String(w.level).split(',').indexOf(level) >= 0; });
  }
  // 级别标签：cet4 -> CET4 / cet6 -> CET6 / "cet4,cet6" -> CET4/6
  function lvlTag(l) { return String(l).toUpperCase().split(',').join('/').replace('CET4/CET6', 'CET4/6'); }
  function lvlCls(l) { return String(l).split(',').length > 1 ? 'cet46' : l; }

  /* ---------------- 记忆曲线（简化 SM-2） ---------------- */
  function pRec(w) { return progress[w] || null; }
  function isDue(w) {
    var r = pRec(w);
    if (!r) return false;
    return r.due <= todayStr();
  }
  // 错误形式（错因）：错题本按它分类 —— 只在答错时累加，答对不清零（历史留着看趋势）
  var ERR_KINDS = [
    { k: 'spell', icon: '✍', name: '拼写错误', hint: '认识它，但手写拼不对：多字母 / 少字母 / 顺序错' },
    { k: 'blank', icon: '💭', name: '想不起来', hint: '看过却没回忆起来，答案空着交卷' },
    { k: 'meaning', icon: '🔀', name: '词义认错', hint: '选择题选错了释义，多半是混了近义词' },
    { k: 'hot', icon: '🔁', name: '反复错', hint: '错过 2 次以上 —— 最该先补的一类' }
  ];
  var ERR_NAME = { spell: '拼写错误', blank: '想不起来', meaning: '词义认错' };
  // 个体化间隔（清单 P1-1 轻量版）：仍保留 8 阶表，叠加一个「个人记忆系数」——
  // 按该词历史正确率把间隔拉长或缩短；样本 <3 次不修，避免刚学就下结论。
  function intervalFor(r) {
    var base = Math.max(1, INTERVALS[r.s]);
    var tries = (r.right || 0) + (r.wrong || 0);
    if (tries < 3) return base;
    var acc = (r.right || 0) / tries;
    var k = acc >= 0.9 ? 1.25 : acc >= 0.75 ? 1 : acc >= 0.55 ? 0.8 : 0.6;
    return Math.max(1, Math.round(base * k));
  }
  function recordAnswer(word, correct, reason) {
    var r = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0 };
    // 自检 F4：s 或 due 一旦被写坏，due 会变成 "NaN-NaN-NaN" 并持久化，该词此后永远不再到期
    r.s = Number(r.s) || 0;
    if (typeof r.due !== 'string' || r.due.indexOf('NaN') >= 0) r.due = todayStr();
    r.seen = (Number(r.seen) || 0) + 1;
    if (!r.errs) r.errs = {};
    if (correct) {
      r.right++;
      r.s = Math.min(INTERVALS.length - 1, r.s + 1);
    } else {
      r.wrong++;
      var k = ERR_NAME[reason] ? reason : 'spell';
      r.errs[k] = (r.errs[k] || 0) + 1;
      r.lastErr = k;
      r.lastErrDate = todayStr();
      r.s = Math.max(0, r.s - 2);
    }
    r.due = addDays(todayStr(), intervalFor(r));
    r.last = todayStr();
    progress[word] = r;
    // 当日统计
    var d = stats[todayStr()] || { answered: 0, right: 0, wrong: 0, newWords: 0, papers: 0 };
    d.answered++; if (correct) d.right++; else d.wrong++;
    stats[todayStr()] = d;
    markDirty();   // 不立刻全量落盘，交给防抖（P1-7）
  }
  function markNew(word) {
    var d = stats[todayStr()] || { answered: 0, right: 0, wrong: 0, newWords: 0, papers: 0 };
    if (!progress[word] || !progress[word]._counted) {
      d.newWords = (d.newWords || 0) + 1;
      stats[todayStr()] = d;
      progress[word] = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0, hist: [] };
      progress[word]._counted = true;
    }
  }
  // 到期负载预测（清单 P1-3）：不只报「今天有多少」，还算明天与未来 7 天，并给预计用时。
  // 单题用时按最近 14 天实际答题速度推算，没有样本时退回 12 秒/题。
  function perItemSeconds() {
    var days = Object.keys(stats).sort().slice(-14);
    var answered = 0;
    days.forEach(function (d) { answered += (stats[d] && stats[d].answered) || 0; });
    var items = 0;
    (focusLog || []).forEach(function (x) { items += x.answered || 0; if (x.minutes) items += 0; });
    var mins = 0;
    (focusLog || []).forEach(function (x) { mins += x.minutes || 0; });
    if (items > 20 && mins > 0) return Math.max(4, Math.round(mins * 60 / items));
    return 12;
  }
  /* P1-8：counts() 要遍历整个 progress（学满 7000+ 词），而首页 / 报告页 / 提醒
     一屏里会连着调用好几次 —— 加一层结果缓存：写入点显式失效 + 1 秒时间兜底。
     缓存最多陈旧 1 秒，且任何改 progress 的地方都会 invalidateCounts()。 */
  var _countsCache = null;
  function invalidateCounts() { _countsCache = null; }
  function counts() {
    var stamp = Date.now();
    if (_countsCache && stamp - _countsCache.t < 1000) return _countsCache.val;
    var learned = 0, mastered = 0, wrongBook = 0, due = 0, dueTomorrow = 0, dueWeek = 0;
    var today = todayStr(), tomorrow = addDays(today, 1), weekEnd = addDays(today, 7);
    Object.keys(progress).forEach(function (w) {
      var r = progress[w];
      if (!r.seen) return;
      learned++;
      if (r.s >= MASTER_STAGE) mastered++;
      if (r.wrong > 0 && r.s < MASTER_STAGE) wrongBook++;
      if (r.due <= today) due++;
      else if (r.due === tomorrow) dueTomorrow++;
      if (r.due <= weekEnd) dueWeek++;
    });
    var sec = perItemSeconds();
    var out = {
      learned: learned, mastered: mastered, wrong: wrongBook, due: due,
      dueTomorrow: dueTomorrow, dueWeek: dueWeek, secPerItem: sec,
      dueMinutes: Math.round(due * sec / 60), tomorrowMinutes: Math.round(dueTomorrow * sec / 60)
    };
    _countsCache = { t: stamp, val: out };
    return out;
  }
  // 「约 12 分钟 · 60 词」这类人话（给首页与提醒用）
  function loadText(dueCount, minutes) {
    if (!dueCount) return '今天没有到期的词';
    return '今天 ' + dueCount + ' 词 · 约 ' + Math.max(1, minutes) + ' 分钟';
  }
  function streak() {
    var n = 0, d = todayStr();
    // 今天没学则从昨天开始数
    if (!stats[d] || !stats[d].answered) d = addDays(d, -1);
    while (stats[d] && stats[d].answered > 0) { n++; d = addDays(d, -1); }
    return n;
  }

  /* ---------------- 打卡（对齐 MOJiTest 的打卡日历） ---------------- */
  function ckData() {
    if (!checkin || typeof checkin !== 'object' || !Array.isArray(checkin.days)) checkin = { days: [] };
    return checkin;
  }
  function ckHas(dateStr) { return ckData().days.indexOf(dateStr) >= 0; }
  function ckStreak() {
    var a = ckData().days, d = todayStr(), n = 0;
    if (!ckHas(d)) d = addDays(d, -1);              // 今天还没打卡就从昨天数
    while (ckHas(d)) { n++; d = addDays(d, -1); }
    return n;
  }
  function ckToday() { return ckHas(todayStr()); }
  function doCheckin() {
    var a = ckData();
    if (ckToday()) { toast('今天已经打过卡啦'); return; }
    a.days.push(todayStr());
    a.days = a.days.filter(function (d, i, arr) { return arr.indexOf(d) === i; });   // 自检 M4：多标签页并发时去重
    save(LS_CHECKIN, checkin);
    renderCheckin();
    toast('打卡成功 · 连续 ' + ckStreak() + ' 天');
    if (window.navigator && navigator.vibrate && buzzOn) { try { navigator.vibrate(18); } catch (e) {} }
  }
  function renderCheckin() {
    var a = ckData();
    var btn = $('#ckBtn'), grid = $('#ckGrid');
    if (!btn || !grid) return;
    var done = ckToday();
    btn.textContent = done ? '已打卡 ✓' : '打卡';
    btn.classList.toggle('done', done);
    btn.disabled = done;
    $('#ckStreak').textContent = ckStreak();
    $('#ckTotal').textContent = a.days.length;
    var mon = todayStr().slice(0, 7);
    $('#ckMonth').textContent = a.days.filter(function (d) { return d.slice(0, 7) === mon; }).length;
    var st = stats[todayStr()];
    $('#ckToday').textContent = (st && st.answered) || 0;
    $('#ckNote').textContent = done
      ? ('今天 ' + todayStr() + ' 已记录，继续保持')
      : (ckStreak() > 0 ? '别断了这 ' + ckStreak() + ' 天的连续' : '今天还没打卡，点右边开始');
    // 近 7 天周条（对齐 MOJiTest 的打卡条：今天标「今」并高亮）
    var wkName = ['日', '一', '二', '三', '四', '五', '六'], cells = '';
    for (var i = 6; i >= 0; i--) {
      var d = addDays(todayStr(), -i);
      var dow = new Date(d.replace(/-/g, '/')).getDay();
      cells += '<div class="ck-day' + (ckHas(d) ? ' on' : '') + (i === 0 ? ' today' : '') + '">' +
        '<span class="ck-dow">' + (i === 0 ? '今' : wkName[dow]) + '</span>' +
        '<span class="ck-num">' + d.slice(8) + '</span></div>';
    }
    grid.innerHTML = cells;
  }

  /* ---------------- 设置 / 计划 ---------------- */
  function defaultExamDate() {
    // 默认取未来最近的 12 月第三个周六（四六级惯例）
    var now = new Date(), y = now.getFullYear();
    var cand = thirdSaturday(y, 11);
    if (cand <= todayStr()) cand = thirdSaturday(y + 1, 11);
    return cand;
  }
  function thirdSaturday(year, monthIdx) {
    var d = new Date(year, monthIdx, 1);
    var firstSat = 1 + ((6 - d.getDay()) + 7) % 7;
    return todayStr(new Date(year, monthIdx, firstSat + 14));
  }
  function defaultSettings() {
    return {
      level: 'cet4',
      examDate: defaultExamDate(),
      minutes: 40,
      restDays: 1,
      plan: null,
      maxReview: 60,
      // 自检 F5：「恢复默认」是整对象替换 —— 这几项原来不在默认里，一点就把专注强硬模式/目标静默关掉
      focusHard: false,
      focusGoal: 50,
      voice: 'us',
      remind: true,
      remindAt: '20:00'
    };
  }
  if (!settings) settings = defaultSettings();
  if (settings.remind === undefined) settings.remind = true;
  if (!settings.remindAt) settings.remindAt = '20:00';
  if (!settings.examDate) settings.examDate = defaultExamDate();

  /* ---------------- 学习难度自适应 ----------------
     依据「近三日答题样本」自动升降档，也可手动锁定。
     只取两个可观测量：**正确率** + **拼写题平均用时**（认词题是四选一，用时不可比，不计入）。
     样本 <12 一律走标准档 —— 不用几道题就下结论。
     三个旋钮：今日新词额度倍率 / 中→英拼写的出现概率 / 错题回炉轮数上限。 */
  var ADAPT_WINDOW_DAYS = 3, ADAPT_MAX_SAMPLE = 80, ADAPT_MIN_SAMPLE = 12;
  var ADAPT_MODES = {
    chill:  { name: '轻松档', newMul: 0.8,  hardBias: 0.3, loops: 2,
              desc: '新词额度 ×0.8 · 中→英拼写约占 30% · 错题回炉最多 2 轮' },
    normal: { name: '标准档', newMul: 1.0,  hardBias: 0.5, loops: 3,
              desc: '新词额度 ×1.0 · 中→英拼写约占 50% · 错题回炉最多 3 轮' },
    push:   { name: '挑战档', newMul: 1.25, hardBias: 0.75, loops: 4,
              desc: '新词额度 ×1.25 · 中→英拼写约占 75% · 错题回炉最多 4 轮' }
  };

  function adaptNorm() {
    if (!adapt || typeof adapt !== 'object' || Array.isArray(adapt)) adapt = { mode: 'auto', recent: [] };
    if (!adapt.mode) adapt.mode = 'auto';
    if (!Array.isArray(adapt.recent)) adapt.recent = [];
    return adapt;
  }
  function adaptTrim() {
    var a = adaptNorm(), keep = {}, i;
    for (i = 0; i < ADAPT_WINDOW_DAYS; i++) keep[addDays(todayStr(), -i)] = 1;
    a.recent = a.recent.filter(function (x) { return x && x.d && keep[x.d]; }).slice(-ADAPT_MAX_SAMPLE);
    return a;
  }
  function adaptSample() {
    var r = adaptTrim().recent;
    var n = r.length, ok = 0, msN = 0, msSum = 0;
    r.forEach(function (x) {
      if (x.ok) ok++;
      if (x.dir === 'cn2en' && x.ms > 0 && x.ms < 90000) { msN++; msSum += x.ms; }
    });
    return {
      n: n, right: ok, rate: n ? ok / n : 0,
      msN: msN,
      avgSec: msN ? Math.round(msSum / msN / 100) / 10 : null
    };
  }
  function adaptAutoKey(s) {
    if (s.n < ADAPT_MIN_SAMPLE) return 'normal';       // 冷启动：样本不足不下结论
    if (s.rate < 0.65) return 'chill';
    if (s.rate < 0.85) return 'normal';
    return (s.avgSec !== null && s.avgSec > 12) ? 'normal' : 'push';   // 正确率高但要慢慢想 → 留在标准档
  }
  function adaptProfile() {
    var a = adaptNorm(), s = adaptSample(), auto = adaptAutoKey(s);
    var key = (a.mode && a.mode !== 'auto') ? a.mode : auto;
    var base = ADAPT_MODES[key] || ADAPT_MODES.normal;
    return {
      key: key, name: base.name, newMul: base.newMul, hardBias: base.hardBias,
      loops: base.loops, desc: base.desc,
      autoKey: auto, mode: a.mode || 'auto', sample: s, coldStart: s.n < ADAPT_MIN_SAMPLE
    };
  }
  function logAdapt(ok, ms, dir) {
    var a = adaptNorm();
    a.recent.push({ d: todayStr(), ok: ok ? 1 : 0, ms: ms || 0, dir: dir || '' });
    adaptTrim(); save(LS_ADAPT, adapt);
  }
  function setAdaptMode(m) {
    var a = adaptNorm(); a.mode = m; save(LS_ADAPT, adapt);
  }
  function adaptBtn(m, label, cur) {
    return '<button class="btn' + (cur === m ? ' primary' : '') + '" data-adapt="' + m + '">' + esc(label) + '</button>';
  }

  /* 墨墨式动态任务量：不设固定每日新词量，额度 = 总预算 − 今日到期复习量
     复习多 → 新词自动缩；复习清零 → 新词额度回满。额度再乘自适应档位倍率。 */
  function dynamicToday(level, minutes) {
    var bank = bankOf(level);
    var due = bank.filter(function (w) { return isDue(w.w); }).length;
    var fresh = bank.filter(function (w) { return !progress[w.w] || !progress[w.w].seen; }).length;
    var SEC_REVIEW = 8, SEC_NEW = 25;
    var budgetWords = Math.max(0, Math.round(minutes * 60 / 18));   // 折合「词次」总容量
    var prof = adaptProfile();
    var newQuota = Math.max(0, budgetWords - due);
    newQuota = Math.min(newQuota, fresh);
    newQuota = Math.max(0, Math.min(fresh, Math.round(newQuota * prof.newMul)));   // 自适应倍率
    return {
      due: due,
      fresh: fresh,
      budgetWords: budgetWords,
      newQuota: newQuota,
      estMinutes: Math.round((due * SEC_REVIEW + newQuota * SEC_NEW) / 60),
      adapt: prof
    };
  }

  function planOf(level, examDate, minutes, restDays) {
    var bank = bankOf(level);
    var total = bank.length;
    var learned = bank.filter(function (w) { return progress[w.w] && progress[w.w].seen; }).length;
    var remain = Math.max(0, total - learned);
    var days = Math.max(1, diffDays(todayStr(), examDate));
    var effective = Math.max(1, Math.round(days * (7 - restDays) / 7));
    // 每个有效学习日要覆盖的新词（留 15% 缓冲），并受复习负担约束
    var perDayRaw = remain / effective;
    var perDay = Math.max(5, Math.ceil(perDayRaw * 1.15 / 5) * 5);   // 向上取整到 5 的倍数
    // 时间预算：新词约 25 秒，复习词约 8 秒
    var reviewLoad = Math.ceil(learned * 0.35);
    var estMinutes = Math.round((perDay * 25 + reviewLoad * 8) / 60);
    var warning = null;
    if (estMinutes > minutes) {
      var scale = minutes / estMinutes;
      var capped = Math.max(5, Math.floor(perDay * scale / 5) * 5);
      warning = '按每日 ' + minutes + ' 分钟预算，新词量已从 ' + perDay + ' 下调到 ' + capped +
                ' 个；若想按原速推进，每日需约 ' + estMinutes + ' 分钟。';
      perDay = capped;
    }
    // 三个阶段的日期切分
    var warm = Math.round(days * 0.5), build = Math.round(days * 0.85);
    var phases = [
      { name: '基础期 · 铺词量', from: todayStr(), to: addDays(todayStr(), warm),
        focus: '新词优先，把词书过一遍；每天完成 SRS 复习，暂不追真题正确率。',
        newPerDay: perDay, ratio: '新词 : 复习 ≈ 6 : 4' },
      { name: '强化期 · 进语境', from: addDays(todayStr(), warm + 1), to: addDays(todayStr(), build),
        focus: '新词收尾，把词汇放进真题语境里；每日 1 套选词填空或翻译，错词本优先清除。',
        newPerDay: Math.max(5, Math.round(perDay * 0.4)), ratio: '新词 : 复习 : 真题 ≈ 3 : 5 : 2' },
      { name: '冲刺期 · 只复习', from: addDays(todayStr(), build + 1), to: examDate,
        focus: '停止铺新词，全盘滚动复习 + 限时真题；只保留错词本与高频词。',
        newPerDay: 0, ratio: '复习 : 真题 ≈ 7 : 3' }
    ];
    return {
      level: level, examDate: examDate, minutes: minutes, restDays: restDays,
      days: days, effectiveDays: effective, total: total, learned: learned, remain: remain,
      newPerDay: perDay, estMinutes: estMinutes, warning: warning, phases: phases,
      created: todayStr()
    };
  }

  // 自检 M6：settings.plan 是「生成时的快照」—— 考试日、级别、每日预算任何一项变了都不该继续沿用
  function planStale() {
    var p = settings.plan;
    if (!p || !p.phases || !p.phases.length) return true;
    if (p.examDate !== settings.examDate) return true;
    if (p.level !== settings.level) return true;
    if (Number(p.minutes) !== Number(settings.minutes)) return true;
    if (diffDays(todayStr(), p.examDate) < 0) return true;   // 考试日已过：三个阶段全部过期
    return false;
  }
  function ensurePlan() {
    if (planStale()) {
      settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
      try { save(LS_SETTINGS, settings); } catch (e) {}
    }
    return settings.plan;
  }

  function daySchedule(plan, n) {
    // 生成未来 n 天的逐日任务
    var rows = [], d = todayStr(), learnedAcc = plan.learned;
    for (var i = 0; i < n; i++) {
      var phase = plan.phases.filter(function (p) { return d >= p.from && d <= p.to; })[0] || plan.phases[2];
      var isRest = (i % 7 === 6) && plan.restDays > 0;
      var nw = isRest ? 0 : phase.newPerDay;
      var rv = Math.ceil(learnedAcc * 0.35);
      if (isRest) rv = Math.ceil(rv * 0.5);
      rows.push({
        date: d, phase: phase.name, isRest: isRest,
        newWords: nw, review: rv,
        paper: phase.name.indexOf('冲刺') >= 0 ? (isRest ? 0 : 1) : (phase.name.indexOf('强化') >= 0 ? (isRest ? 0 : 1) : 0),
        minutes: Math.round((nw * 25 + rv * 8) / 60)
      });
      learnedAcc += nw;
      d = addDays(d, 1);
    }
    return rows;
  }

  /* ---------------- 多步流程（步骤栈） ----------------
     参考 iOS 导航规范（flow-multi-step）：多步流程用「路由栈」而不是一堆布尔开关／
     各写一套显隐 —— 返回、回起点、步骤指示都由同一份状态推导。 */
  var WIZ = {
    quiz: { steps: ['choose', 'config'], panels: { choose: '#quizStep1', config: '#quizStep2' } },
    focus: { steps: ['choose', 'time'], panels: { choose: '#focusStep1', time: '#focusStep2' } },
    wrong: {
      steps: ['overview', 'list', 'detail'], kind: 'pages',
      panels: { overview: '#wrongStep1', list: '#wrongStep2', detail: '#wrongStep3' }
    }
  };
  var wizPath = { quiz: ['choose'], focus: ['choose'], wrong: ['overview'] };

  function wizCur(view) {
    var p = wizPath[view] || [];
    return p.length ? p[p.length - 1] : (WIZ[view] ? WIZ[view].steps[0] : '');
  }
  function wizShow(view) {
    var w = WIZ[view]; if (!w) return;
    var cur = wizCur(view);
    Object.keys(w.panels).forEach(function (k) {
      var el = $(w.panels[k]);
      if (el) el.style.display = (k === cur) ? 'block' : 'none';
    });
    var host = $(w.panels[cur]);
    if (host) {
      var old = host.querySelector('.wiz-bar');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var i = w.steps.indexOf(cur);
      host.insertAdjacentHTML('afterbegin',
        '<div class="wiz-bar">' +
        w.steps.map(function (s, n) {
          return '<i class="wiz-dot' + (n === i ? ' on' : (n < i ? ' done' : '')) + '"></i>';
        }).join('') +
        '<span>第 ' + (i + 1) + ' / ' + w.steps.length + (w.kind === 'pages' ? ' 页' : ' 步') + '</span></div>');
    }
    resetScroll();   // 翻页同样复位视野（函数在下方定义，调用时会已就绪）
  }
  function wizReset(view) {
    if (!WIZ[view]) return;
    wizPath[view] = [WIZ[view].steps[0]];
    wizShow(view);
  }
  function wizPush(view, step) {
    var w = WIZ[view]; if (!w) return;
    var i = w.steps.indexOf(step);
    if (i < 0) return;
    wizPath[view] = w.steps.slice(0, i + 1);
    wizShow(view);
  }
  function wizPop(view) {
    var p = wizPath[view] || [];
    if (p.length > 1) { p.pop(); wizShow(view); return true; }
    return false;
  }

  /* ---------------- 导航 ---------------- */
  // 切页 / 翻页后把视野拉回顶部。
  // 注意时序：旧版在 render 之前就 window.scrollTo(0,0)，那时新页面的 DOM 高度还没重排，
  // 在手机上会被浏览器「恢复滚动位置」覆盖 —— 表现为切到新页后上面一大片空白、要往下翻才见到内容。
  // 现在改到渲染完成后（双 rAF + 一次定时兜底）再复位，并把几种可能的滚动容器都清一遍。
  function resetScroll() {
    var fire = function () {
      try { window.scrollTo(0, 0); } catch (e) {}
      var se = document.scrollingElement || document.documentElement;
      if (se) se.scrollTop = 0;
      var m = document.querySelector('.main');
      if (m) m.scrollTop = 0;
      var ac = document.querySelector('.app');
      if (ac) ac.scrollTop = 0;
    };
    fire();
    if (window.requestAnimationFrame) {
      requestAnimationFrame(function () { requestAnimationFrame(fire); });
    }
    setTimeout(fire, 60);
  }
  function go(view) {
    if (view !== 'quiz') document.body.classList.remove('quizzing');   // 离开默写就退出沉浸态
    flushSave();                                                       // 切页先落盘（P1-7）
    if (location.hash !== '#' + view) { try { history.replaceState(null, '', '#' + view); } catch (e) {} }
    $$('#nav button').forEach(function (b) {
      var on = b.dataset.view === view;
      b.classList.toggle('on', on);
      b.setAttribute('aria-current', on ? 'page' : 'false');   // 屏幕阅读器要能听到「当前在哪一页」（P1-10）
    });
    $$('.view').forEach(function (v) { v.classList.toggle('on', v.id === 'view-' + view); });
    if (view === 'home') renderHome();
    if (view === 'dict') renderDict();
    if (view === 'quiz') { renderQuizLevels(); wizReset('quiz'); }
    if (view === 'grammar') renderGrammarList();
    if (view === 'listening') renderLsList();
    if (view === 'translate') renderTrList();
    if (view === 'write') renderWrList();
    if (view === 'focus') { renderFocus(); wizReset('focus'); }
    if (view === 'wrong') { renderWrong(); wizReset('wrong'); }
    if (view === 'real') renderRealList();
    if (view === 'plan') renderPlan();
    if (view === 'settings') renderSettings();
    if (view === 'report') renderReport();
    resetScroll();                                                     // 渲染完再复位视野
  }

  /* ---------------- 总览 ---------------- */
  function renderHome() {
    renderHomeResume(true);   // 有未答完的卷子就在首页顶部提示（P0-9）
    var bank = bankOf(settings.level);
    var total = bank.length;
    var learned = bank.filter(function (w) { return progress[w.w] && progress[w.w].seen; }).length;
    var c = counts();
    var days = Math.max(0, diffDays(todayStr(), settings.examDate));
    var plan = ensurePlan();
    var todayDue = bank.filter(function (w) { return isDue(w.w); }).length;
    var dy = dynamicToday(settings.level, settings.minutes);
    var newTarget = Math.min(plan.newPerDay, dy.newQuota);
    var todayNewDone = (stats[todayStr()] && stats[todayStr()].newWords) || 0;

    $('#homeLevel').textContent = settings.level === 'cet6' ? 'CET-6' : 'CET-4';
    $('#homeDays').textContent = days;
    $('#homeExamDate').textContent = '考试日 ' + settings.examDate + '（' + '周' + '日一二三四五六'[new Date(settings.examDate.replace(/-/g, '/')).getDay()] + '）';
    $('#homeDue').textContent = todayDue;
    $('#homeNew').textContent = newTarget;
    var note = $('#homeNewNote');
    if (note) {
      // 到期负载预测（清单 P1-3）：今日/明日/本周 + 预计用时
      var loadBits = [loadText(c.due, c.dueMinutes)];
      if (c.dueTomorrow) loadBits.push('明天 ' + c.dueTomorrow + ' 词 · 约 ' + Math.max(1, c.tomorrowMinutes) + ' 分钟');
      loadBits.push('未来 7 天共 ' + c.dueWeek + ' 词');
      if (dy.newQuota < plan.newPerDay) loadBits.push('新词额度已从 ' + plan.newPerDay + ' 下调');
      note.textContent = loadBits.join(' · ');
    }

    $('#stLearned').textContent = c.learned;
    $('#stMastered').textContent = c.mastered;
    $('#stWrong').textContent = c.wrong;
    $('#stStreak').textContent = streak();
    renderCheckin();

    var pct = total ? Math.round(learned / total * 100) : 0;
    $('#homeRingPct').textContent = pct + '%';
    $('#homeRingTxt').textContent = learned + ' / ' + total + ' 词';
    var ring = $('#homeRing');
    ring.setAttribute('stroke-dashoffset', String(351.9 * (1 - pct / 100)));

    // 今日任务
    var focusGoal = settings.focusGoal || 50;
    var focusDone = focusTodayMinutes();
    var tasks = [
      { k: '复习到期词', cur: Math.min(todayDue, (stats[todayStr()] && stats[todayStr()].answered) || 0), goal: todayDue, view: 'quiz' },
      { k: '学习新词', cur: Math.min(todayNewDone, newTarget), goal: newTarget, view: 'quiz' },
      // P2-3：专注也进今日任务 —— 之前专注只写「专注记录」，与计划/首页的今日任务各算各的
      { k: '专注时长', cur: Math.min(focusDone, focusGoal), goal: focusGoal, view: 'focus' },
      { k: '真题语境', cur: (stats[todayStr()] && stats[todayStr()].papers) || 0, goal: (new Date(settings.examDate.replace(/-/g, '/')) - new Date() < 30 * 86400000) ? 1 : 0, view: 'real' }
    ].filter(function (t) { return t.goal > 0; });

    $('#homeTasks').innerHTML = tasks.map(function (t) {
      var done = t.cur >= t.goal;
      return '<div class="spread" style="padding:6px 0">' +
        '<span>' + (done ? '✅ ' : '◻️ ') + t.k + '</span>' +
        '<span class="small ' + (done ? '' : 'muted') + '">' + t.cur + ' / ' + t.goal + '</span></div>';
    }).join('') || '<div class="muted small">今天没有硬性任务，随便翻翻词典也算数。</div>';

    var sum = tasks.reduce(function (a, t) { return a + Math.min(1, t.cur / t.goal); }, 0);
    var rate = tasks.length ? Math.round(sum / tasks.length * 100) : 0;
    $('#homeTaskRate').textContent = rate + '%';
    $('#homeTaskBar').style.width = rate + '%';

    // 全部功能入口（「开学」页的核心）
    var modes = [
      { v: 'dict', icon: '▤', name: '词典模式', desc: '搜全库 · 音标/搭配/语法/例句' },
      { v: 'quiz', icon: '✎', name: '默写模式', desc: '点一下直接开始今日默写 · 错题回炉', quick: true },
      { v: 'grammar', icon: '◈', name: '语法模式', desc: '9 考点 · 90 题 · 五类题型' },
      { v: 'listening', icon: '🎧', name: '听力训练', desc: '语音朗读 · 听力理解题' },
      { v: 'translate', icon: '⇄', name: '翻译训练', desc: '先写后看 · 采分点自检' },
      { v: 'write', icon: '✒', name: '写作训练', desc: '写完对范文 · 亮点表达' },
      { v: 'real', icon: '▣', name: '真题模式', desc: '题库 ' + PAPERS.length + ' 套' },
      { v: 'focus', icon: '⏱', name: '专注模式', desc: '番茄钟 · 全屏 · 每日目标' },
      { v: 'report', icon: '▦', name: '学习报告', desc: '趋势 · 掌握度 · 薄弱词 · 下一步建议' },
      { v: 'plan', icon: '◔', name: '计划模式', desc: '按考试日倒推训练量' },
      { v: 'settings', icon: '⚙', name: '设置', desc: '计划 · 朗读 · 提醒 · 数据备份' }
    ];
    var mhost = $('#homeModes');
    if (mhost) {
      mhost.innerHTML = modes.map(function (m) {
        return '<button class="mode-tile" data-go="' + m.v + '"' + (m.quick ? ' data-quick="1"' : '') + '>' +
          '<span class="mt-ico">' + m.icon + '</span>' +
          '<span class="mt-body"><b>' + m.name + '</b><span>' + m.desc + '</span></span>' +
          '</button>';
      }).join('');
    }

    // 问候语
    var greet = $('#homeGreet');
    if (greet) {
      var h = new Date().getHours();
      var hello = h < 6 ? '夜深了，' : (h < 11 ? '早上好，' : (h < 14 ? '中午好，' : (h < 18 ? '下午好，' : '晚上好，')));
      greet.textContent = hello + '今天是 ' + todayStr() + ' · 距 ' + (settings.level === 'cet6' ? 'CET-6' : 'CET-4') + ' 还有 ' + days + ' 天。';
    }

    $('#homeQuick').innerHTML =
      '<button class="btn primary" data-go="quiz">✎ 开始默写</button>' +
      '<button class="btn" data-go="focus">⏱ 专注一段</button>' +
      '<button class="btn" data-go="dict">▤ 查词典</button>' +
      '<button class="btn" data-go="plan">◔ 看计划</button>';

    // 最近记录
    var dates = Object.keys(stats).sort().reverse().slice(0, 7);
    $('#homeRecent').innerHTML = dates.length ? '<ul class="list-plain">' + dates.map(function (d) {
      var s = stats[d];
      return '<li><b>' + d + '</b> · 答题 ' + s.answered + ' 题（✓' + s.right + ' / ✗' + s.wrong +
        '）· 新学 ' + (s.newWords || 0) + ' 词' + (s.papers ? ' · 真题 ' + s.papers + ' 套' : '') + '</li>';
    }).join('') + '</ul>' : '<div class="muted small">还没有学习记录，先从默写模式开始吧。</div>';

    $('#sideStat').innerHTML = '本级词库 <b>' + total + '</b> 词 · 已学 <b>' + learned + '</b><br>到期复习 <b>' + todayDue + '</b> · 掌握 <b>' + c.mastered + '</b>';
  }

  /* ---------------- 词典 ---------------- */
  var dictState = { q: '', level: 'all', picked: null, detailOpen: false };

  /* 检索相关度评分（0 = 不匹配）
     —— 分字段、分优先级，并按分数排序；短词（<3 字）不扫例句与语法说明，
     避免出现「搜 ad 命中 237 个词」这种等于没搜的结果。 */
  function dictScore(w, q) {
    var s = String(q || '').toLowerCase().trim();
    if (!s) return 1;
    var word = String(w.w || '').toLowerCase();
    var cn = String(w.cn || '');
    var short = s.length < 3;
    if (word === s) return 100;                       // 完全匹配
    if (word.indexOf(s) === 0) return 90;             // 词头相符（ad → adopt）
    if (cn.indexOf(s) >= 0) return 70;                // 中文释义命中
    if (short) return 0;                              // 短词到此为止
    if (word.indexOf(s) >= 0) return 60;              // 词形包含
    // 拼写相近（编辑距离 ≤2）：手抖打错、记不准也能找到 —— 这是「搜不到」最常见的场景
    if (/^[a-z]+$/.test(s) && s.length >= 4) {
      var d = lev(s, word);
      if (d > 0 && d <= 2 && Math.abs(s.length - word.length) <= 2) return 35;
    }
    var colloc = ((w.colloc || []).join(' ') + ' ' + (w.related || []).join(' ')).toLowerCase();
    if (colloc.indexOf(s) >= 0) return 40;            // 搭配 / 派生
    if (String(w.note || '').toLowerCase().indexOf(s) >= 0) return 25;   // 语法说明
    var ex = (w.ex || []).map(function (e) { return e.en + ' ' + e.cn; }).join(' ').toLowerCase();
    if (ex.indexOf(s) >= 0) return 10;                // 例句
    return 0;
  }
  function hitLabel(sc) {
    if (sc >= 100) return '完全匹配';
    if (sc >= 90) return '开头相符';
    if (sc >= 70) return '释义命中';
    if (sc >= 60) return '词形含';
    if (sc >= 40) return '搭配派生';
    if (sc >= 35) return '拼写相近';
    if (sc >= 25) return '语法说明';
    return '例句命中';
  }
  /* 命中高亮：先转义，再包 <mark>（不引入 XSS） */
  function hi(text, q) {
    var s = esc(text);
    var qq = String(q || '').trim();
    if (!qq) return s;
    try {
      var re = new RegExp('(' + qq.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
      return s.replace(re, '<mark>$1</mark>');
    } catch (e) { return s; }
  }

  /* 真题检索：题干 / 原文 / 选项 / 参考译文 / 范文 / 关键词 全都能搜 */
  function paperHits(q) {
    var s = String(q || '').toLowerCase().trim();
    if (s.length < 2) return [];
    return PAPERS.filter(function (p) {
      var hay = [p.title, p.year, p.type, p.prompt, p.source, p.reference, p.sample,
        (p.outline || []).join(' '), (p.keyWords || []).join(' '), (p.bank || []).join(' '),
        (p.questions || []).map(function (x) {
          return (x.q || '') + ' ' + (x.options || []).join(' ') + ' ' + (x.answer || '') + ' ' + (x.explain || '');
        }).join(' '),
        (p.passage || ''), (p.text || ''), (p.sentence || '')
      ].join(' ').toLowerCase();
      return hay.indexOf(s) >= 0;
    });
  }
  function renderPaperHits(q) {
    var host = $('#dictPaperHits');
    if (!host) return;
    var kw = String(q || '').trim();
    // 2026-09-25：真题命中挂在搜索结果层里，跟着关键词走
    if (kw.length < 2) {
      host.innerHTML = '';
      return;
    }
    var hits = paperHits(kw);
    host.innerHTML = '<div class="card-title">真题里也有「' + esc(kw) + '」 <span class="tag small muted">' + hits.length + ' 篇</span></div>' +
      (hits.length ? hits.slice(0, 8).map(function (p) {
        return '<div class="paper-item" data-phit="' + esc(p.id) + '">' +
          '<div><div style="font-weight:600">' + esc(p.title) + '</div>' +
          '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.type || '') + ' · ' + String(p.level || '').toUpperCase() + '</div></div>' +
          '<button class="btn sm">进入</button></div>';
      }).join('') : '<div class="muted small">真题里没出现这个词 —— 换英文原词或搭配再试。</div>');
    host.onclick = function (e) {
      var it = e.target.closest('[data-phit]'); if (!it) return;
      var id = it.dataset.phit;
      if (id.indexOf('tr-') === 0) { go('translate'); openTr(id.slice(3)); }
      else if (id.indexOf('wr-') === 0) { go('write'); openWr(id.slice(3)); }
      else { go('real'); openPaper(id); }
    };
  }

  /* ---------------- 词典：六个功能各自一页 + 两层弹出 ----------------
     昀晞 2026-09-25 定稿：
       · 顶层页签即分类（全部 / CET-4 / CET-6 / 收藏 / 已学 / 错词），一页一个词表
       · 搜索框只在「全部」页
       · 搜索 → 弹整屏一层（#dictSearchLayer）看结果
       · 点词 → 再弹一层（#dictWordLayer）看词条
     分类靠页签而不是靠一排 chip：切页=换列表，不再在同一页里叠筛选条件。 */
  var DICT_LIST_ID = {
    all: '#dictListAll', cet4: '#dictListCet4', cet6: '#dictListCet6',
    star: '#dictListStar', learned: '#dictListLearned', wrong: '#dictListWrong'
  };
  var DICT_EMPTY = {
    all: '词库是空的（不应该发生，报一下）',
    cet4: '四级词还没载入',
    cet6: '六级词还没载入',
    star: '还没有收藏的词 —— 打开任意词条，点「☆ 收藏」就会出现在这里',
    learned: '还没有学过的词 —— 去默写或真题里走一轮，这里就有内容了',
    wrong: '错词本是空的 —— 保持住'
  };

  function dictMatch(level, w) {
    if (level === 'cet4' || level === 'cet6') return String(w.level).split(',').indexOf(level) >= 0;  // 双级词两边都出现
    if (level === 'learned') return !!(progress[w.w] && progress[w.w].seen);
    if (level === 'star') return !!(progress[w.w] && progress[w.w].star);
    if (level === 'wrong') return !!(progress[w.w] && progress[w.w].wrong);
    return true;
  }

  /* 渲染某一类的词表，返回**真实命中总数**（列表最多印 300 条，条数不能当判据） */
  function renderDictList(level, hostSel, q) {
    var host = $(hostSel);
    if (!host) return 0;
    var kw = String(q || '').trim();
    var scoreOf = {};
    var list = WORDS.filter(function (w) { return dictMatch(level, w); })
      .filter(function (w) { var sc = dictScore(w, kw); if (sc <= 0) return false; scoreOf[w.w] = sc; return true; });
    if (kw) list.sort(function (a, b) { return scoreOf[b.w] - scoreOf[a.w]; });
    var show = list.slice(0, 300);
    host.innerHTML = show.length ? show.map(function (w) {
      var r = pRec(w.w);
      var mark = r ? (r.s >= MASTER_STAGE ? ' <span class="badge good">已掌握</span>' : (r.wrong ? ' <span class="badge bad">错过</span>' : '')) : '';
      return '<div class="word-item' + (dictState.picked === w.w ? ' on' : '') + '" data-w="' + w.w + '">' +
        '<span><span class="w">' + hi(w.w, kw) + '</span> <span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span>' + mark +
        (kw && scoreOf[w.w] ? ' <span class="badge due">' + hitLabel(scoreOf[w.w]) + '</span>' : '') + '</span>' +
        '<span class="c">' + hi(w.cn, kw) + '</span></div>';
    }).join('') : '<div class="empty">' + (kw ? '没有符合条件的词 —— 换个说法、或用搭配（give up）再试。' : (DICT_EMPTY[level] || '这里还没有词')) + '</div>';
    return list.length;
  }

  /* 词典主页：只渲染当前页签那一类 */
  function renderDict() {
    var level = pgCurrent('#dictTabs') || 'all';
    if (DICT_LIST_ID[level]) {
      dictState.level = level;
      renderDictList(level, DICT_LIST_ID[level], '');
    }
    return level;
  }

  /* 弹出层：搜索层 / 词条层 —— 整屏一层，顶部带「← 返回」 */
  function openDictLayer(sel) {
    var el = $(sel);
    if (!el) return;
    el.hidden = false;
    try { el.scrollTop = 0; } catch (e) {}
  }
  function closeDictLayer(sel) {
    var el = $(sel);
    if (el) el.hidden = true;
  }
  function anyDictLayerOpen() {
    var a = $('#dictSearchLayer'), b = $('#dictWordLayer');
    return !!((a && !a.hidden) || (b && !b.hidden));
  }

  /* 搜索入口（只有「全部」页有搜索框）：弹出搜索结果层 */
  function runDictSearch(q) {
    var kw = String(q || '').trim();
    if (!kw) { toast('先输入要查的词或中文'); return; }
    dictState.q = kw;
    var n = renderDictList('all', '#dictListSearch', kw);
    var title = $('#dictSearchTitle');
    if (title) title.textContent = '「' + kw + '」· ' + n + ' 条结果' + (n > 300 ? '（列表印前 300 条）' : '');
    renderPaperHits(kw);
    openDictLayer('#dictSearchLayer');
  }
  // 这个词答错的历史 —— 词典详情与错题本详情共用
  function errHistoryHtml(word) {
    var r = pRec(word);
    if (!r || !r.wrong) return '';
    var chips = ERR_KINDS.filter(function (e) { return e.k !== 'hot'; })
      .filter(function (e) { return errCount(r, e.k) > 0; })
      .map(function (e) { return '<span class="wbx-chip">' + e.icon + ' ' + e.name + ' ×' + errCount(r, e.k) + '</span>'; })
      .join('');
    return '<div class="wd-block"><h4>错误记录</h4><div>累计错 ' + r.wrong + ' 次 · 对 ' + r.right + ' 次' +
      (r.lastErr ? ' · 最近一次：' + (ERR_NAME[r.lastErr] || '拼写错误') + (r.lastErrDate ? '（' + r.lastErrDate + '）' : '') : '') +
      '</div>' + (chips ? '<div class="wbx-log">' + chips + '</div>' : '') + '</div>';
  }
  // 词根词缀面板（P1-2）：数据来自 assets/js/data/{roots,word-split}.js
  // 收录原则是「不确定就不写」，所以查不到是常态 —— 查不到就整块不出现，不硬凑。
  function rootPanelHtml(word) {
    var split = (window.WORD_SPLIT || {})[word];
    if (!split || !split.parts || !split.parts.length) return '';
    var rootKey = split.root;
    var root = rootKey ? (window.WORD_ROOTS || {})[rootKey] : null;
    var typeName = { root: '词根', prefix: '前缀', suffix: '后缀' };
    var html = '<div class="wd-block"><h4>词根词缀 <span class="tag small muted">结构记忆，比死记省力</span></h4>';
    html += '<div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:8px">' +
      split.parts.map(function (p) {
        var seg = String(p).split(':');
        var key = String(seg[0] || '').trim();
        var mean = String(seg[1] || '').trim();
        var isRoot = key === rootKey;
        return '<span class="chip' + (isRoot ? ' on' : '') + '" style="cursor:default">' +
          esc(key) + (mean ? ' · ' + esc(mean) : '') + (isRoot ? ' ★' : '') + '</span>';
      }).join('') + '</div>';
    if (root) {
      html += '<div class="small muted">' + esc(typeName[root.type] || '词根') + ' <b>' + esc(rootKey) + '</b> —— ' +
        esc(root.meaning || '') + (root.origin ? '（' + esc(root.origin) + '）' : '') + '</div>';
      if (root.examples && root.examples.length) {
        html += '<div class="small muted" style="margin-top:4px">同族常见：' + root.examples.slice(0, 6).map(function (e) {
          return (BY_WORD[e] ? '<a href="#" data-wd="' + esc(e) + '">' + esc(e) + '</a>' : esc(e));
        }).join(' · ') + '</div>';
      }
    }
    var fam = (split.family || []).filter(function (x) { return BY_WORD[x] && x !== word; });
    if (fam.length) {
      html += '<div class="small muted" style="margin-top:4px">同根词：' + fam.map(function (x) {
        return '<a href="#" data-wd="' + esc(x) + '">' + esc(x) + '</a>';
      }).join(' · ') + '</div>';
    }
    html += '</div>';
    return html;
  }

  function renderWordDetail(word, hostSel, noBack) {
    var w = BY_WORD[word];
    if (!w) return;
    var r = pRec(word);
    var dueTxt = r ? '下次复习 ' + r.due : '尚未学习';
    var html = (noBack ? '' : '<button class="btn sm ghost wd-back" id="wdBack">← 返回词表</button>') +
      '<div class="wd-head"><h3>' + esc(w.w) + '</h3>' +
      '<button class="spk-btn" data-say="' + esc(w.w) + '" title="朗读单词">🔊</button>' +
      '<span class="ph">' + esc(w.ph || '') + '</span>' +
      '<span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span>' +
      '<span class="badge">频率 ' + '★'.repeat(w.freq || 1) + '</span></div>' +
      '<div class="row small muted" style="margin-top:6px">' +
      '<span>词性 ' + esc(w.pos || '—') + '</span><span>·</span><span>' + dueTxt + '</span>' +
      (r ? '<span>·</span><span>已答 ' + r.seen + ' 次（✓' + r.right + ' / ✗' + r.wrong + '）</span>' : '') +
      '</div>' +
      errHistoryHtml(word) +
      '<div class="wd-block"><h4>释义</h4><div class="cn">' + esc(w.pos || '') + ' ' + esc(w.cn) + '</div></div>' +
      ((w.colloc && w.colloc.length) ? '<div class="wd-block"><h4>常见搭配</h4><ul>' +
        w.colloc.map(function (c) { return '<li>' + esc(c) + '</li>'; }).join('') + '</ul></div>' : '') +
      (w.note ? '<div class="wd-block"><h4>语法与用法</h4><div>' + esc(w.note) + '</div></div>' : '') +
      rootPanelHtml(word) +
      ((w.ex && w.ex.length) ? '<div class="wd-block"><h4>例句</h4>' + w.ex.map(function (e) {
        return '<div class="ex-sent"><button class="spk-btn sm" data-say="' + esc(e.en) + '" title="朗读例句">🔊</button>' +
          '<div class="en">' + esc(e.en) + '</div><div class="cn">' + esc(e.cn) + '</div></div>';
      }).join('') + '</div>' : '') +
      ((w.related && w.related.length) ? '<div class="wd-block"><h4>派生 / 相关</h4><ul>' +
        w.related.map(function (c) { return '<li>' + esc(c) + '</li>'; }).join('') + '</ul></div>' : '') +
      '<div class="row" style="margin-top:18px">' +
      '<button class="btn primary" id="wdPractice">✎ 立即默写这个词</button>' +
      '<button class="btn" id="wdStar">' + (r && r.star ? '★ 已收藏' : '☆ 收藏') + '</button>' +
      '<button class="btn" id="wdMark">标记为待复习</button></div>';
    var box = $(hostSel || '#dictDetail');
    box.innerHTML = html;
    box._word = word;
    var bk = $('#wdBack');
    if (bk) bk.onclick = closeWordDetail;
    // 词根面板里的同根词 / 同族词可以直接点进那个词的详情
    // 2026-09-25 修：原来写的是 `$('[data-wd]')` —— `$` 是 querySelector（返回单个元素或 null），
    // 没有该元素时是 null，`null.forEach` 直接抛 TypeError，**把本函数后面三个按钮的绑定
    // （立即默写 / 收藏 / 标记为待复习）整段中断** —— 表现就是「词典里收藏和标记点了没反应」。
    // 必须用 `$$`（querySelectorAll 的数组版）。
    $$('[data-wd]').forEach(function (a) {
      a.onclick = function (ev) {
        ev.preventDefault();
        var t = a.dataset.wd;
        if (!BY_WORD[t]) return;
        dictState.picked = t;
        dictState.detailOpen = true;
        renderWordDetail(t, hostSel, noBack);
        if (!hostSel) openDictLayer('#dictWordLayer');   // 词典页里点同根词 → 就在词条层里换词
      };
    });
    if ($('#wdPractice')) $('#wdPractice').onclick = function () { startQuiz({ words: [w], dir: 'cn2en', count: 1 }); go('quiz'); };
    var starBtn = $('#wdStar');
    if (starBtn) starBtn.onclick = function () {
      progress[word] = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0, hist: [] };
      progress[word].star = !progress[word].star;
      saveAll();
      renderWordDetail(word, hostSel, noBack);
      toast(progress[word].star ? '已收藏 · 词典筛「收藏」就能找到' : '已取消收藏');
    };
    $('#wdMark').onclick = function () {
      progress[word] = progress[word] || { s: 0, due: todayStr(), seen: 0, right: 0, wrong: 0, hist: [] };
      progress[word].due = todayStr(); saveAll(); toast('已加入今日复习'); renderDict();
    };
  }

  /* P2-4 错题打印单：把错词排成「左侧词 + 右侧手写横线」的单页，浏览器打印即可带走。
     纯本地生成，不联网、不引第三方库；打印完那个窗口自己关掉。 */
  function printWrongSheet(kind) {
    var ws = kind ? wrongWordsOf(kind) : wrongWords();
    if (!ws.length) { toast('错题本是空的，先去做几道题'); return; }
    var rows = ws.slice(0, 200).map(function (w, i) {
      var r = progress[w.w] || {};
      var kinds = ERR_KINDS.filter(function (e) { return e.k !== 'hot' && errCount(r, e.k) > 0; })
        .map(function (e) { return e.name; }).join('/');
      return '<tr>' +
        '<td class="n">' + (i + 1) + '</td>' +
        '<td class="cn">' + esc(w.cn) + '</td>' +
        '<td class="blank"></td>' +
        '<td class="tag">' + esc((w.pos || '') + (kinds ? ' · ' + kinds : '')) + '</td>' +
        '</tr>';
    }).join('');
    var html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">' +
      '<title>雾读 · 错题打印单 ' + todayStr() + '</title><style>' +
      'body{font:13px/1.6 "Microsoft YaHei",system-ui;margin:18px;color:#111}' +
      'h1{font-size:17px;margin:0 0 4px}.meta{color:#666;font-size:12px;margin-bottom:12px}' +
      'table{width:100%;border-collapse:collapse}' +
      'th,td{border-bottom:1px solid #ddd;padding:9px 6px;text-align:left;vertical-align:middle}' +
      'th{background:#f3f6fa;font-size:12px;color:#444}' +
      '.n{width:34px;color:#888}.cn{width:38%}.blank{width:34%;border-bottom:1px solid #999}' +
      '.tag{width:22%;color:#888;font-size:11px}' +
      '@media print{body{margin:10mm}.no-print{display:none}}' +
      '</style></head><body>' +
      '<h1>雾读 · 错题打印单</h1>' +
      '<div class="meta">' + todayStr() + ' · 共 ' + ws.length + ' 个词' +
      (ws.length > 200 ? '（只印前 200 个）' : '') + ' · 右侧横线留给自己手写，写完再对答案</div>' +
      '<table><thead><tr><th>#</th><th>中文释义</th><th>写出英文</th><th>词性 / 错因</th></tr></thead><tbody>' +
      rows + '</tbody></table>' +
      '<div class="no-print" style="margin-top:16px"><button onclick="window.print()">打印 / 存 PDF</button></div>' +
      '</body></html>';
    var w2 = window.open('', '_blank');
    if (!w2) { toast('浏览器拦了新窗口 —— 允许弹出窗口后重试'); return; }
    w2.document.write(html);
    w2.document.close();
    toast('打印单已生成 · 共 ' + ws.length + ' 个词');
  }

  /* 关掉词条层，回到下面那一层（可能是搜索层，也可能是词典主页） */
  function closeWordDetail() {
    dictState.detailOpen = false;
    closeDictLayer('#dictWordLayer');
    resetScroll();
  }

  /* ---------------- 默写 ---------------- */
  var quiz = null;

  function renderQuizLevels() {
    var levels = [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6']];
    var cur = (quiz && quiz.level) || 'all';
    $('#quizLevel').innerHTML = levels.map(function (l) {
      return '<button class="chip' + (cur === l[0] ? ' on' : '') + '" data-ql="' + l[0] + '">' + l[1] + '</button>';
    }).join('');
    renderQuizResume();
  }

  /* ---------------- 断点续学（清单 P0-9） ----------------
     答题中途接电话 / 切 App / 误触返回，回来还能接着答。
     存的是「题目词表 + 每题方向 + 进度 + 对错 + 答题记录」，不含 DOM，重启也能还原；
     不存当前这道题的输入（避免泄露提示），续上时从这道题重新答。 */
  var LS_QUIZ = 'wudu.quiz.v1';

  function quizSnapshot() {
    if (!quiz || !quiz.queue || !quiz.queue.length) return null;
    if (quiz.pos >= quiz.queue.length) return null;      // 最后一题答完＝整轮结束，不必续
    return {
      v: 1,
      level: quiz.level, dir: quiz.dir, scope: quiz.scope, planned: quiz.planned,
      items: quiz.queue.map(function (it) { return it.w.w + '|' + it.dir; }),
      pos: quiz.pos, right: quiz.right, wrong: quiz.wrong,
      log: (quiz.log || []).map(function (x) { return [x.w, x.correct ? 1 : 0, x.given || '']; }),
      savedAt: Date.now()
    };
  }
  function saveQuizSession() {
    var snap = quizSnapshot();
    try {
      if (snap) localStorage.setItem(LS_QUIZ, JSON.stringify(snap));
      else localStorage.removeItem(LS_QUIZ);
    } catch (e) { /* 写不进去就退化成「不记进度」，不能影响答题 */ }
    var nat = window.WUDU_NATIVE;
    if (nat && nat.isNative && snap) nat.store(LS_QUIZ, JSON.stringify(snap));
  }
  function clearQuizSession() { try { localStorage.removeItem(LS_QUIZ); } catch (e) {} }
  function loadQuizSession() {
    var s = load(LS_QUIZ, null);
    if (!s || s.v !== 1 || !s.items || !s.items.length) return null;
    if (s.pos >= s.items.length) return null;
    return s;
  }
  function resumeQuiz() {
    var s = loadQuizSession();
    if (!s) { toast('没有可续的进度'); return false; }
    var items = [], missing = 0;
    s.items.forEach(function (k) {
      var p = String(k).split('|');
      var w = BY_WORD[p[0]];
      if (!w) { missing++; return; }
      items.push({ w: w, dir: p[1] || 'cn2en', streak: 0, need: 1, loops: 0, t0: 0 });
    });
    if (!items.length) { clearQuizSession(); toast('上次那批词已不在词库里，重新开始吧'); return false; }
    var dPool = bankOf((s.level && s.level !== 'all') ? s.level : null);
    if (dPool.length < 4) dPool = WORDS;
    var pos = Math.max(0, Math.min(s.pos, items.length - 1));
    quiz = {
      level: s.level || 'all', dir: s.dir || 'cn2en', scope: s.scope || 'due',
      adapt: adaptProfile(), queue: items, pos: pos, planned: s.planned || items.length,
      passed: 0, right: s.right || 0, wrong: s.wrong || 0, answered: false,
      distractorPool: dPool,
      log: (s.log || []).map(function (x) { return { w: x[0], correct: !!x[1], given: x[2] || '' }; }),
      resumed: true
    };
    $('#quizSetup').style.display = 'none';
    $('#quizResult').style.display = 'none';
    $('#quizRun').style.display = 'block';
    document.body.classList.add('quizzing');
    renderQuizResume();
    renderQuizQuestion();
    toast('已接上上次 · 第 ' + (pos + 1) + ' / ' + items.length + ' 题' + (missing ? '（' + missing + ' 词已失效）' : ''));
    return true;
  }
  function renderQuizResume() {
    var setup = document.getElementById('quizSetup');
    if (!setup || !setup.parentNode) return;
    var host = document.getElementById('quizResume');
    if (!host) {
      host = document.createElement('div');
      host.id = 'quizResume';
      setup.parentNode.insertBefore(host, setup);
    }
    var s = loadQuizSession();
    // 正在答题中不显示（避免挡住题面）
    if (!s || (quiz && quiz.queue && quiz.pos < quiz.queue.length && quiz.queue[quiz.pos] && !quiz.answered && $('#quizRun').style.display !== 'none')) {
      host.style.display = 'none'; host.innerHTML = '';
      renderHomeResume(false);
      return;
    }
    host.style.display = '';
    host.innerHTML = resumeBannerHtml(s, 'quizResumeGo', 'quizResumeDrop');
    var g = document.getElementById('quizResumeGo'), dr = document.getElementById('quizResumeDrop');
    if (g) g.onclick = function () { resumeQuiz(); };
    if (dr) dr.onclick = function () { clearQuizSession(); renderQuizResume(); renderHomeResume(false); toast('已放弃上次进度'); };
    renderHomeResume(true, s);
  }
  // 首页也提示「上次没答完」—— 真机上 App 被杀后重开是落在首页，提示只放默写页会看不到
  function renderHomeResume(show, s) {
    var home = document.getElementById('view-home');
    if (!home) return;
    var host = document.getElementById('homeResume');
    if (!host) {
      var head = home.querySelector('.page-head');
      if (!head || !head.parentNode) return;
      host = document.createElement('div');
      host.id = 'homeResume';
      head.parentNode.insertBefore(host, head.nextSibling);
    }
    s = s || loadQuizSession();
    var running = !!(quiz && quiz.queue && quiz.pos < quiz.queue.length && $('#quizRun') && $('#quizRun').style.display !== 'none');
    if (!show || !s || running) { host.style.display = 'none'; host.innerHTML = ''; return; }
    host.style.display = '';
    host.innerHTML = resumeBannerHtml(s, 'homeResumeGo', 'homeResumeDrop');
    var g = document.getElementById('homeResumeGo'), dr = document.getElementById('homeResumeDrop');
    if (g) g.onclick = function () { go('quiz'); resumeQuiz(); };
    if (dr) dr.onclick = function () { clearQuizSession(); renderHomeResume(false); toast('已放弃上次进度'); };
  }
  function resumeBannerHtml(s, goId, dropId) {
    var done = s.pos, total = s.items.length;
    var tries = (s.right || 0) + (s.wrong || 0);
    var rate = tries ? Math.round(s.right / tries * 100) : null;
    var when = '';
    try {
      var mins = Math.round((Date.now() - (s.savedAt || 0)) / 60000);
      when = mins < 1 ? '刚刚' : mins < 60 ? (mins + ' 分钟前') : mins < 1440 ? (Math.round(mins / 60) + ' 小时前') : (Math.round(mins / 1440) + ' 天前');
    } catch (e) {}
    return '⏸ <b>上次没答完</b> —— ' + when + '停在第 ' + (done + 1) + ' / ' + total + ' 题' +
      (rate === null ? '' : ' · 本轮正确率 ' + rate + '%') +
      '<div class="row" style="margin-top:8px">' +
      '<button class="btn sm primary" id="' + goId + '">继续上次</button>' +
      '<button class="btn sm ghost" id="' + dropId + '">放弃</button></div>';
  }

  function pickPool(level, scope) {
    var pool = bankOf(level === 'all' ? null : level);
    if (scope === 'new') {
      pool = pool.filter(function (w) { return !progress[w.w] || !progress[w.w].seen; });
    } else if (scope === 'wrong') {
      pool = pool.filter(function (w) { return progress[w.w] && progress[w.w].wrong > 0 && progress[w.w].s < MASTER_STAGE; });
    } else if (scope === 'due') {
      var dueP = pool.filter(function (w) { return isDue(w.w); });
      // 清单 P0-2：到期词先按「错词优先 → 阶段低优先」排，再按每日复习上限截断 ——
      // 否则某天几百个到期词会一股脑压上来（对齐 Anki 的 daily limit 思路）
      dueP.sort(function (a, b) {
        var ra = progress[a.w] || {}, rb = progress[b.w] || {};
        if ((rb.wrong || 0) !== (ra.wrong || 0)) return (rb.wrong || 0) - (ra.wrong || 0);
        return (ra.s || 0) - (rb.s || 0);
      });
      var cap = settings.maxReview || 60;
      if (dueP.length > cap) dueP = dueP.slice(0, cap);
      var fresh = pool.filter(function (w) { return !progress[w.w] || !progress[w.w].seen; });
      pool = dueP.concat(shuffle(fresh));
    }
    return pool;
  }

  /* 一键开始：按今日到期复习 + 自适应额度组卷，直接进答题（首页卡片单击用） */
  function quickStart() {
    var dy = dynamicToday(settings.level, settings.minutes);
    var n = Math.max(10, Math.min(50, (dy.due || 0) + (dy.newQuota || 0)));
    startQuiz({
      level: settings.level,
      scope: dy.due > 0 ? 'due' : 'all',
      dir: 'mix',
      count: n
    });
    go('quiz');
    toast('今日任务 ' + n + ' 题 · ' + (dy.adapt ? dy.adapt.name : '标准档'));
  }

  /* 回到默写设置页（答题中途退出用） */
  function backToSetup() {
    quiz = null;
    $('#quizRun').style.display = 'none';
    $('#quizResult').style.display = 'none';
    $('#quizSetup').style.display = 'block';
    document.body.classList.remove('quizzing');
    renderQuizLevels();
    toast('回到设置页，改完再开始');
  }

  /* 安卓返回键（MainActivity 通过 evaluateJavascript 调用）。
     对齐 AnkiDroid 的 doubleBackPressCallback：**会丢东西的动作都要按两下**，
     第一下只给一句提示，2 秒内再按一下才真的执行。 */
  var lastBackAt = 0, lastBackWhat = '';
  function backGuard(key, tip) {
    var now = Date.now();
    if (lastBackWhat === key && now - lastBackAt < 2000) { lastBackAt = 0; lastBackWhat = ''; return true; }
    lastBackWhat = key; lastBackAt = now;
    toast(tip);
    return false;
  }
  window.__onBackKey = function () {
    var cur = (location.hash || '').replace('#', '') || 'home';
    var runEl = $('#quizRun');
    var quizzing = cur === 'quiz' && quiz && quiz.queue && runEl && runEl.style.display !== 'none';
    if (quizzing) {
      if (backGuard('quiz', '再按一次返回键结束本轮（已答的题都已记录）')) backToSetup();
      return 'handled';
    }
    if (cur === 'dict' && anyDictLayerOpen()) {          // 词典：先关层，再谈其他
      if ($('#dictWordLayer') && !$('#dictWordLayer').hidden) closeWordDetail();
      else closeDictLayer('#dictSearchLayer');
      return 'handled';
    }
    // 多步流程：第 2 步按返回先退回第 1 步
    if (cur === 'quiz' && wizPop('quiz')) return 'handled';
    if (cur === 'focus' && wizPop('focus')) return 'handled';
    if (cur === 'wrong' && wizPop('wrong')) return 'handled';
    if (document.body.classList.contains('focusing')) {
      if ($('#hardMask')) return 'handled';                       // 挑战弹层开着：返回键不生效
      if (settings.focusHard && !hardUnlocked()) { openHardGate(); return 'handled'; }
      if (backGuard('focus', '再按一次返回键结束本段专注')) { endFocus(false); }
      return 'handled';
    }
    if (cur !== 'home') { go('home'); return 'handled'; }
    if (backGuard('exit', '再按一次返回键退出雾读')) return 'exit';
    return 'handled';
  };

  function startQuiz(opts) {
    opts = opts || {};
    var level = opts.level || 'all';
    var scope = opts.scope || 'due';
    var dir = opts.dir || 'en2cn';
    var count = opts.count || 20;

    var pool = opts.words || pickPool(level, scope);
    // P1-6：例句级题型必须挑有例句的词，否则出不来题
    if (dir === 'excloze' || dir === 'exlisten') {
      pool = pool.filter(function (w) { return w.ex && w.ex.length; });
      if (!pool.length) { toast('这些词里没有带例句的，换个来源试试'); return; }
    }
    if (!pool.length) { toast('这个条件下没有可练的词，换个来源试试'); return; }
    clearQuizSession();   // 开新一轮＝作废旧进度（P0-9）

    // 乱序 + 优先到期/错词
    pool = shuffle(pool).slice(0, count);

    // 干扰项池：与本级同源，避免一眼看穿
    var distractorPool = bankOf(level === 'all' ? null : level);
    if (distractorPool.length < 4) distractorPool = WORDS;

    // 自适应：混合模式下按当前档位决定「中→英拼写」的出现概率
    var prof = adaptProfile();
    quiz = {
      level: level, dir: dir, scope: scope, adapt: prof,
      queue: pool.map(function (w) {
        var d = dir;
        if (dir === 'mix') d = (Math.random() < prof.hardBias) ? 'cn2en' : 'en2cn';
        var ex = null;
        if (w.ex && w.ex.length) ex = w.ex[Math.floor(Math.random() * w.ex.length)];
        return { w: w, dir: d, ex: ex, streak: 0, need: 1, loops: 0, t0: 0, answered: false };
      }),
      pos: 0, planned: pool.length, passed: 0,
      right: 0, wrong: 0, answered: false, distractorPool: distractorPool, log: []
    };
    $('#quizSetup').style.display = 'none';
    $('#quizResult').style.display = 'none';
    $('#quizRun').style.display = 'block';
    document.body.classList.add('quizzing');    // 沉浸答题：收起侧栏与底部 Tab，屏幕全给题目
    renderQuizLevels();
    renderQuizQuestion();
  }

  function renderQuizQuestion() {
    var q = quiz, item = q.queue[q.pos];
    if (!item) { endQuiz(); return; }
    var w = item.w;
    var isEn2Cn = item.dir === 'en2cn';
    var isListen = item.dir === 'listen';

    // 自检 G4：答错回炉会把 queue 撑大 —— 分母必须锁定「本轮计划题量」，否则第 1 题答错就变成 3 / 22
    var doneN = Math.min(q.done || 0, q.planned || q.queue.length);
    var totalN = q.planned || q.queue.length;
    $('#quizProgress').textContent = doneN + ' / ' + totalN;
    $('#quizModeTag').textContent = isEn2Cn ? '认词 · 英→中'
      : (isListen ? '听写 · 听音拼写'
      : (item.dir === 'excloze' ? '例句填空' : (item.dir === 'exlisten' ? '例句听写' : '默写 · 中→英')));
    $('#quizRight').textContent = '✓ ' + q.right;
    $('#quizWrong').textContent = '✗ ' + q.wrong;
    $('#quizBar').style.width = (q.pos / q.queue.length * 100) + '%';
    q.answered = !!item.answered;   // 往返翻页：每题自己的作答态独立保存
    item.t0 = item.t0 || Date.now();   // 自适应用的答题用时基准（回看不再重置）

    var body = $('#quizCardBody'), actions = $('#quizActions');
    body.className = 'card quiz-card';

    if (isEn2Cn) {
      var opts = [w.cn];
      var used = {}; used[w.cn] = 1;
      var guard = 0;
      while (opts.length < 4 && guard++ < 300) {
        var cand = q.distractorPool[Math.floor(Math.random() * q.distractorPool.length)];
        if (!cand || used[cand.cn] || cand.w === w.w) continue;
        used[cand.cn] = 1; opts.push(cand.cn);
      }
      opts = shuffle(opts);
      body.innerHTML =
        '<div class="quiz-sub">选择正确的中文释义</div>' +
        '<div class="quiz-prompt">' + esc(w.w) +
        ' <button class="spk-btn" data-say="' + esc(w.w) + '" title="朗读">🔊</button></div>' +
        '<div class="quiz-sub">' + esc(w.ph || '') + '</div>' +
        '<div class="opt-grid" style="margin-top:18px" id="quizOpts">' +
        opts.map(function (o) { return '<button class="opt" data-opt="' + esc(o) + '">' + esc(o) + '</button>'; }).join('') +
        '</div>';
      actions.innerHTML =
        '<div class="row" style="justify-content:center;margin-top:10px">' +
        '<button class="btn ghost sm" id="quizPrev" title="回到上一题"' + (quiz.pos <= 0 ? ' disabled' : '') + '>⬅ 上一题</button>' +
        '<button class="btn ghost sm" id="quizSkip" title="不判对错，直接看下一个词">➡ 下一题</button>' +
        '</div>' +
        '<span class="flow-note">点选答案即可（按 <span class="kbd">1</span>-<span class="kbd">4</span> 快捷选择）</span>';
      $$('#quizOpts .opt').forEach(function (b) {
        b.onclick = function () { answerChoice(b, b.dataset.opt === w.cn); };
      });
      if (q.answered) {
        // 往返翻页回看：已答过的认词题高亮正确答案
        $$('#quizOpts .opt').forEach(function (b) {
          b.classList.add(b.dataset.opt === w.cn ? 'ok' : 'no');
        });
      }
      if ($('#quizPrev')) $('#quizPrev').onclick = prevQuestion;
      if ($('#quizSkip')) $('#quizSkip').onclick = skipQuestion;
    } else {
      var exItem = item.ex || null;
      var promptHtml;
      if (item.dir === 'excloze' && exItem) {
        // 例句填空：把目标词挖空，剩下的语境都给你
        promptHtml = '<div class="quiz-sub">把横线处的词补出来</div>' +
          '<div class="quiz-prompt cn" style="font-size:19px;line-height:1.65">' + esc(blankSentence(exItem.en, w.w)) + '</div>' +
          (exItem.cn ? '<div class="small muted" style="margin-top:6px">' + esc(exItem.cn) + '</div>' : '');
      } else if (item.dir === 'exlisten' && exItem) {
        // 例句听写：只放整句发音 + 中文翻译，让耳朵和拼写一起用
        promptHtml = '<div class="quiz-sub">听整句发音，写出句中那个词</div>' +
          '<div class="quiz-prompt"><button class="spk-btn lg" id="quizReplay" title="再听一遍">🔊</button>' +
          '<div class="small muted" style="margin-top:8px">点喇叭再听一遍 · 音源在本机，离线也能练</div></div>' +
          (exItem.cn ? '<div class="small muted" style="margin-top:6px">' + esc(exItem.cn) + '</div>' : '');
      } else {
        promptHtml = '<div class="quiz-sub">' + (isListen ? '听发音，把这个单词写出来' : '写出对应的英语单词') + '</div>' +
          (isListen
            ? '<div class="quiz-prompt"><button class="spk-btn lg" id="quizReplay" title="再听一遍">🔊</button>' +
              '<div class="small muted" style="margin-top:8px">点喇叭再听一遍 · 音源在本机，离线也能练</div></div>'
            : '<div class="quiz-prompt cn">' + esc(w.cn) + '</div>');
      }
      body.innerHTML =
        promptHtml +
        '<div class="quiz-sub">' + esc(w.pos || '') + ' · ' + (w.w.length) + ' 个字母</div>' +
        '<div class="spell-wrap" id="spellWrap">' +
        // 输入层必须在 .spell-wrap **里面**：它是 absolute 定位，放外面会相对更外层容器铺开，
        // 可点区变成整页（2026-09-25 实测 375×776，点哪都算点输入框，反而乱）
        // 2026-09-25 昀晞：回到上一题要能接着打字 —— 已答态不再锁输入框。
        // 默写是学习模块（不是考试），回看、改字、重判都该允许。
        '<input class="spell-input" id="quizInput" maxlength="' + (w.w.length + 6) + '" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done">' +
        '</div>' +
        '<div class="row" style="justify-content:center;margin-top:6px">' +
        '<button class="btn ghost sm" id="quizPrev" title="回到上一题"' + (quiz.pos <= 0 ? ' disabled' : '') + '>⬅ 上一题</button>' +
        '<button class="btn" id="quizSubmit">提交</button>' +
        '<button class="btn ghost sm" id="quizHintBtn">💡 提示</button>' +
        '<button class="btn ghost sm" id="quizPaper">📄 纸笔模式</button>' +
        '<button class="btn ghost sm" id="quizSkip" title="不判对错，直接看下一个词">➡ 下一题</button>' +
        '</div>';
      actions.innerHTML = '<span class="flow-note">输入直接写在横线上 · 按 <span class="kbd">Enter</span> 提交 · 差 1 个字母（词长 ≥5）算对</span>';
      var input = $('#quizInput');
      input.value = item.given || '';   // 回看时把上次写的字带回来
      // 一条输入线（2026-09-25 昀晞：横线彻底删掉）：输入框自己显示字、自己带光标，
      // 不再往字母槽里搬字符，也不再自己算点到了哪一格。
      var sw = $('#spellWrap');
      if (sw) sw.onclick = function () { input.focus(); };
      var focusIn = function () {
        try { input.focus({ preventScroll: true }); } catch (e) { input.focus(); }
        // 键盘弹起后会盖住下半屏，把字母槽滚到可视中间
        setTimeout(function () {
          var el = $('#spellWrap');
          if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        }, 300);
      };
      setTimeout(focusIn, 80);
      // 例句听写：进来先自动播一遍，喇叭可重播
      if (item.dir === 'exlisten' && exItem) {
        setTimeout(function () { speak(exItem.en); }, 260);
        var rp = $('#quizReplay');
        if (rp) rp.onclick = function (ev) { ev.preventDefault(); speak(exItem.en); };
      }
      var lastSent = null, lastSentAt = 0;
      var submit = function () {
        var val = input.value.trim();
        if (!val) { toast('先写点什么，或者用纸笔模式 / 跳过'); return; }
        // 2026-09-25 昀晞「不要重复输入步骤、不要提交两次」：回车键、软键盘的 keydown/keypress、
        // 屏幕上的「提交」按钮，都可能把同一次敲击送进来两遍 —— 用「内容 + 时间」双闸，
        // 同一个答案只认第一次；改了字随时能再交（内容变了就不算重复）。
        var now = Date.now();
        if (val === lastSent && (now - lastSentAt) < 1500) return;
        lastSent = val; lastSentAt = now;
        var jd = judge(val, w.w);
        try {
          // 已答过（回看 / 想重打一遍）→ 走重判：刷新显示与本轮对错，但不重复写记忆曲线
          if (q.answered) reanswer(jd, val); else answerText(jd, val);
        } catch (err) {
          // 2026-09-25 昀晞手机端「回车没反应」之后加的兜底：提交链路上任何异常
          // 原本都会静默吞掉，表现就是「字在输入线上、什么都没发生」。现在至少说出来。
          try { console.error('[雾读] 提交出错', err); } catch (_) {}
          toast('提交出错了：' + ((err && err.message) || err));
        }
      };
      $('#quizSubmit').onclick = function () { submit(); };
      // 回车 = 提交。手机软键盘给的形状并不统一 —— 有的给 key='Enter'，有的只给 keyCode 13，
      // 中文输入法还会先进组合态。能认的都认，别只认 key === 'Enter'。
      var isEnterKey = function (e) {
        return e.key === 'Enter' || e.key === 'Go' || e.key === 'Done' || e.key === 'Send' ||
               e.keyCode === 13 || e.which === 13;
      };
      input.onkeydown = function (e) {
        if (!isEnterKey(e)) return;
        if (e.isComposing || e.keyCode === 229) return;   // 组合态：这一下先给输入法，不抢
        e.preventDefault();
        e.stopPropagation();
        submit();
      };
      var hintLevel = 0;
      $('#quizHintBtn').onclick = function () {
        hintLevel = Math.min(2, hintLevel + 1);
        var hint = hintOf(w.w, hintLevel);     // 与单词等长：'_' = 未揭示（自检 N2）
        var cur = input.value.split('');
        var out = '';
        for (var i = 0; i < w.w.length; i++) {
          var hc = hint.charAt(i);
          out += (hc && hc !== '_') ? hc : (cur[i] || ' ');
        }
        input.value = out.replace(/\s+$/, '');
        focusIn();
        // 自检 N4：hintLevel 封顶 2，到头了就别再承诺「再点给更多」
        toast(hintLevel >= 2 ? '提示已给到头（首字母与末字母）' : '提示已填进横线 · 再点一次给更多');
      };
      $('#quizPaper').onclick = function () { revealAndAssess(); };
      if ($('#quizPrev')) $('#quizPrev').onclick = prevQuestion;
      if ($('#quizSkip')) $('#quizSkip').onclick = skipQuestion;   // 翻页：不判对错直接下一个
      if (isListen) {
        var rp = $('#quizReplay');
        if (rp) rp.onclick = function () { speak(w.w); };
        setTimeout(function () { speak(w.w); }, 200);       // 进题先把音放出来
      }
    }
  }
  /* 拼写输入：2026-09-25 昀晞 —— 「不要很多横线，就一条输入线」+「横线彻底删除」。
     原先的 slotsHtml()（生成 N 个字母槽）与 syncSlots()（把字符搬进槽里）已整体删除：
     输入框自己可见、自己显示字，光标与逐位修改全部交给系统原生行为。
     硬核模式（#hardInput）同样只保留一条输入线。 */
  // 提示：返回与单词**等长**的串，'_' 表示未揭示。
  // 自检 N1/N2：旧版用空格占位，调用方还要 replace(/\s+/g,'') 去掉 —— 一是单字母词会输出 "a  a"，
  // 二是去掉空格后索引整体错位（self-made 会少揭示一个字母）。
  // 把例句里的目标词挖成横线（P1-6）：容忍复数与常见词形变化，找不到就退化成整词替换
  function blankSentence(en, word) {
    var s = String(en || '');
    var w = String(word || '');
    if (!w) return s;
    // 2026-09-25 修：这里原本应当是以 '\\$&' 结尾的转义替换，被某次脚本替换时把 $& 当成
    // 「匹配内容」展开了，写坏成了一段函数签名。后果：单词含正则特殊字符时 esc2 会拼出非法正则。
    var esc2 = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var re = new RegExp('\\b' + esc2 + '(?:s|es|ed|d|ing|ies)?\\b', 'gi');
    var hit = false;
    var out = s.replace(re, function () { hit = true; return '______'; });
    if (hit) return out;
    return s.replace(new RegExp(esc2, 'i'), '______');
  }

  function hintOf(word, level) {
    var w = String(word || ''), n = w.length, out = [];
    for (var i = 0; i < n; i++) out.push('_');
    if (!n) return '';
    if (n === 1) { out[0] = w[0]; return out.join(''); }        // 单字母词：直接给出来，不重复首尾
    if (level <= 0) { out[0] = w[0]; }
    else if (level === 1) { var k = Math.ceil(n / 2); for (var j = 0; j < k; j++) out[j] = w[j]; }
    else { out[0] = w[0]; out[n - 1] = w[n - 1]; }
    return out.join('');
  }

  function answerChoice(btn, correct) {
    if (quiz.answered) return;
    quiz.answered = true;
    var w = quiz.queue[quiz.pos].w;
    $$('#quizOpts .opt').forEach(function (b) {
      if (b.dataset.opt === w.cn) b.classList.add('ok');
    });
    if (!correct) btn.classList.add('no');
    finish(correct, w, null, { ok: correct, kind: correct ? 'exact' : 'wrong' }, { reason: 'meaning' });
  }
  function answerText(jd, given) {
    if (quiz.answered) return;
    quiz.answered = true;
    finish(jd.ok, quiz.queue[quiz.pos].w, given, jd);
  }
  // 纸笔模式：不输入，直接揭答案，自己判对错
  function revealAndAssess() {
    var q = quiz;
    var already = q.answered;
    var w = q.queue[q.pos].w;
    var body = $('#quizCardBody');
    body.insertAdjacentHTML('beforeend',
      '<div class="quiz-answer reveal">' +
        '<div class="small muted" style="margin-bottom:8px">📄 纸笔模式 —— 在纸上写完再对照</div>' +
        answerCard(w) +
      '</div>' +
      '<div class="row" style="justify-content:center;margin-top:14px">' +
        '<span class="small muted">我在纸上写得……</span>' +
        (already ? '' : '<button class="btn ok-btn" id="selfRight">✓ 写对了</button>' +
        '<button class="btn no-btn" id="selfWrong">✗ 写错了</button>') +
        '<button class="btn ghost sm" id="quizPrev" title="回到上一题"' + (q.pos <= 0 ? ' disabled' : '') + '>⬅ 上一题</button>' +
        '<button class="btn ghost sm" id="selfSkip" title="不判对错，直接看下一个词">➡ 翻页</button>' +
      '</div>');
    if ($('#quizInput')) $('#quizInput').disabled = true;
    $('#quizActions').innerHTML = '';
    if (!already) {
      q.answered = true;
      $('#selfRight').onclick = function () { finish(true, w, null, { ok: true, kind: 'self' }, { skipCard: true }); };
      $('#selfWrong').onclick = function () { finish(false, w, null, { ok: false, kind: 'self' }, { skipCard: true }); };
    }
    if ($('#quizPrev')) $('#quizPrev').onclick = prevQuestion;
    $('#selfSkip').onclick = skipQuestion;   // 纸笔练习也能一路翻页，不必每题自评
  }
  // 答案卡：词条 + 记忆阶段倒计时
  function answerCard(w) {
    return '<div><b>' + esc(w.w) + '</b> ' +
      '<button class="spk-btn sm" data-say="' + esc(w.w) + '" title="朗读">🔊</button> ' +
      '<span class="muted">' + esc(w.ph || '') + '</span> ' +
      '<span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span></div>' +
      '<div style="margin-top:4px">' + esc(w.pos || '') + ' ' + esc(w.cn) + '</div>' +
      (w.note ? '<div class="small muted" style="margin-top:6px">' + esc(w.note) + '</div>' : '') +
      (w.ex && w.ex[0] ? '<div class="ex-sent" style="margin-top:8px"><div class="en">' + esc(w.ex[0].en) +
        '</div><div class="cn">' + esc(w.ex[0].cn) + '</div></div>' : '') +
      reviewHint(w);
  }
  // 掌握度倒计时：离遗忘还有多远
  function reviewHint(w) {
    var r = pRec(w.w);
    var stage = r ? r.s : 0;
    var max = INTERVALS.length - 1;
    var pct = Math.round(stage / max * 100);
    var txt = r
      ? ('记忆阶段 ' + stage + '/' + max + ' · 下次复习 ' + r.due + (stage >= MASTER_STAGE ? ' · 已掌握' : ''))
      : '新词 · 答完进入记忆曲线';
    return '<div class="rv-row"><div class="rv-bar"><i style="width:' + pct + '%"></i></div>' +
      '<span class="small muted">' + txt + '</span></div>';
  }
  // 提交后的输入反馈：输入框闪一下（对=绿，错=红+抖动）+ 震动
  function flashInput(ok) {
    var inp = $('#quizInput');
    if (!inp) return;
    inp.classList.remove('fb-ok', 'fb-no');
    void inp.offsetWidth;            // 强制重排，让动画能连续触发
    inp.classList.add(ok ? 'fb-ok' : 'fb-no');
    buzz(ok ? [35] : [70, 45, 70]);
  }

  // 答错的原因：调用方明示优先，否则从判定结果推断（空着交卷 / 拼错）
  function reasonOf(correct, jd, opt) {
    if (correct) return null;
    if (opt && opt.reason) return opt.reason;
    if (jd && jd.kind === 'empty') return 'blank';
    return 'spell';
  }

  // 答案卡（提交后、回看重判后都用它渲染）—— 2026-09-25 从 finish() 里抽出来复用
  function renderAnswerCard(correct, w, given, jd) {
    var cls = correct ? 'ok' : 'no';
    var kindTag = (jd && jd.kind && KIND_LABEL[jd.kind]) ? ' <span class="badge due">' + KIND_LABEL[jd.kind] + '</span>' : '';
    var head = correct ? '✅ 正确' : '❌ 正确答案';
    var givenLine = '';
    if (given && !correct) {
      givenLine = '<div class="diff-line">你写的：<code>' + diffHtml(given, w.w) + '</code></div>' +
        '<div class="small muted">绿=对 · 红=多打 · 灰=漏打</div>';
    }
    // 同一题可能被重判多次：先清掉上一次的答案卡，避免越叠越多
    var olds = $$('#quizCardBody .quiz-answer');
    olds.forEach(function (el) { if (!el.classList.contains('reveal')) el.parentNode.removeChild(el); });
    $('#quizCardBody').insertAdjacentHTML('beforeend',
      '<div class="quiz-answer ' + cls + '">' +
        '<div class="row" style="margin-bottom:6px"><b>' + esc(head) + '</b>' + kindTag + '</div>' +
        givenLine +
        answerCard(w) +
        '</div>');
  }
  // 回看重判（2026-09-25 昀晞：默写是学习模块 —— 回上一题要能接着打字，改完能重新判）。
  // 口径：按最新一次作答刷新答案卡与本轮对错，但不重复写记忆曲线、不增加「本轮走过题数」。
  function reanswer(jd, given) {
    var q = quiz, item = q.queue[q.pos], w = item.w;
    if (item.correct) q.right = Math.max(0, q.right - 1); else q.wrong = Math.max(0, q.wrong - 1);
    item.correct = jd.ok;
    item.given = given;
    if (jd.ok) { q.right++; item.streak = Math.max(1, item.streak || 0); }
    else { q.wrong++; item.streak = 0; }
    $('#quizRight').textContent = '✓ ' + q.right;
    $('#quizWrong').textContent = '✗ ' + q.wrong;
    renderAnswerCard(jd.ok, w, given, jd);
    flashInput(jd.ok);
    saveQuizSession();
  }

  function finish(correct, w, given, jd, opt) {
    opt = opt || {};
    var q = quiz, item = q.queue[q.pos];
    // 2026-09-25 修：原来这里把布尔型的 answered 当计数器用（+1），而 renderQuizQuestion
    // 每题开头又把它重置为 false —— 进度分子永远停在 1；且 q.answered 的布尔语义被污染。
    // 现在拆开：answered 只管「本题是否已作答」，新增 q.done 专管本轮走过几题。
    q.answered = true;
    item.answered = true;   // 往返翻页：每题作答态落回题目自身
    q.done = (q.done || 0) + 1;
    if (correct) q.right++; else q.wrong++;
    if (given) flashInput(correct);
    recordAnswer(w.w, correct, reasonOf(correct, jd, opt));
    markNew(w.w);
    // 自适应样本：只记「首次作答」，回炉重练不重复计入，避免同一题刷高正确率
    var ms = item.t0 ? (Date.now() - item.t0) : 0;
    if (!item._sampled) { item._sampled = 1; logAdapt(correct, ms, item.dir); }
    item.given = given || null;
    item.correct = correct;
    q.log.push({ w: w.w, correct: correct, given: given || null, kind: (jd && jd.kind) || '' });

    // 错题回炉：答错 → 连对两次才算过；答对但未达要求 → 回队尾重来
    var requeue = false;
    if (correct) {
      item.streak++;
      if (item.streak >= item.need) q.passed++; else requeue = true;
    } else {
      item.streak = 0; item.need = 2; requeue = true;
    }
    var topped = item.loops >= ((q.adapt && q.adapt.loops) || 3);
    if (requeue && !topped) {
      item.loops++;
      q.queue.push({ w: item.w, dir: item.dir, streak: item.streak, need: item.need, loops: item.loops, t0: 0, _sampled: 1, answered: false });
    } else if (requeue && topped) {
      q.passed++;   // 回炉次数用尽，放行，避免死循环
      requeue = false;
    }

    $('#quizRight').textContent = '✓ ' + q.right;
    $('#quizWrong').textContent = '✗ ' + q.wrong;
    // 2026-09-25 修：doneN / totalN 原本是 renderQuizQuestion() 里的局部变量，在这里是
    // undefined —— 这行会抛 ReferenceError，把下面「下一题」按钮的创建整段中断，
    // 表现就是「纸笔模式写完点了没反应 / 答完题进不了下一题」。就地算，不再跨作用域取值。
    var _tn = q.planned || q.queue.length || 1;
    var _dn = Math.min(q.done || 0, _tn);
    $('#quizBar').style.width = Math.min(100, (_dn / _tn * 100)) + '%';
    saveQuizSession();   // 断点续学：每答一题就把进度落盘（P0-9）

    if (!opt.skipCard) renderAnswerCard(correct, w, given, jd);
    // 2026-09-25 昀晞：提交后不再锁输入框 —— 回到上一题 / 就在本题都应当能接着打字、改字、重判。
    var remain = q.queue.length - q.pos - 1;
    $('#quizActions').innerHTML =
      '<button class="btn ghost sm" id="quizPrev" title="回到上一题"' + (q.pos <= 0 ? ' disabled' : '') + '>⬅ 上一题</button>' +
      '<button class="btn primary" id="quizNext">' + (remain > 0 ? '下一题 →' : '看本轮结果') + '</button>' +
      (requeue ? '<span class="flow-note">↩ 这题稍后会再出现（连对两次才算过）</span>' : '');
    if ($('#quizPrev')) $('#quizPrev').onclick = prevQuestion;
    // 2026-09-25：不再把焦点抢到「下一题」按钮上。手机上软键盘的回车键会激活当前聚焦的按钮，
    // 于是「按回车看答案」会变成「按回车直接跳走」。焦点留在输入框，回车只管提交 / 重判。
    var keepFocus = $('#quizInput');
    if (keepFocus && !keepFocus.disabled) { try { keepFocus.focus({ preventScroll: true }); } catch (e) { keepFocus.focus(); } }
    $('#quizNext').onclick = nextQuestion;
  }
  function nextQuestion() {
    if (!quiz) return;
    quiz.pos++;
    stopSpeak();
    saveQuizSession();
    if (quiz.pos >= quiz.queue.length) endQuiz(); else renderQuizQuestion();
  }
  function prevQuestion() {
    if (!quiz || quiz.pos <= 0) return;
    quiz.pos--;
    stopSpeak();
    saveQuizSession();
    renderQuizQuestion();
  }
  /* 翻页（2026-09-25 昀晞要的「无论答没答对都可以翻页」）：
     不判对错、不写回忆记录、不改记忆阶段，只往前走一题。
     这样纯纸笔练习（只在纸上写、不在 App 里对答案）也能一路刷下去。
     2026-09-25 二次修：加「上一题」，实现往返翻页；回看态 q.answered 已置位，不会再计分。 */
  function skipQuestion() {
    var q = quiz;
    if (!q) return;
    var item = q.queue[q.pos];
    if (!item) { endQuiz(); return; }
    q.answered = true;                       // 本轮的提交 / 选项 / 自评守卫一并失效，防重复计分
    item.answered = true;
    q.done = (q.done || 0) + 1;
    q.skipped = (q.skipped || 0) + 1;
    nextQuestion();
  }
  function endQuiz() {
    var q = quiz;
    clearQuizSession();   // 一轮走完＝清掉断点（P0-9）
    renderQuizResume();
    $('#quizRun').style.display = 'none';
    $('#quizResult').style.display = 'block';
    var total = q.right + q.wrong;
    var rate = total ? Math.round(q.right / total * 100) : 0;
    var plannedN = q.planned || total;
    var requeued = Math.max(0, total - plannedN);   // 自检 G4：多出来的是错题回炉，明说比让用户困惑好
    var wrongList = q.log.filter(function (x) { return !x.correct; });
    $('#quizResult').innerHTML =
      '<div class="card" style="text-align:center">' +
      '<div class="card-title" style="justify-content:center">本轮完成</div>' +
      '<div class="countdown">' + rate + '%<small>正确率</small></div>' +
      '<div class="muted small" style="margin-top:6px">本轮 ' + plannedN + ' 题' +
        (requeued ? '（含错题回炉 ' + requeued + ' 次）' : '') +
        ' · 答对 ' + q.right + ' · 答错 ' + q.wrong + '</div>' +
      '<div class="bar" style="max-width:420px;margin:16px auto 0"><i style="width:' + rate + '%"></i></div>' +
      '<div class="row" style="justify-content:center;margin-top:18px">' +
      '<button class="btn primary" id="quizAgain">再来一轮</button>' +
      (wrongList.length ? '<button class="btn" id="quizWrongAgain">只练这 ' + wrongList.length + ' 个错词</button>' : '') +
      '<button class="btn ghost" id="quizBack">回到设置</button>' +
      '</div></div>' +
      (wrongList.length ? '<div class="card"><div class="card-title">本轮错词</div><ul class="list-plain">' +
        wrongList.map(function (x) {
          var w = BY_WORD[x.w];
          return '<li><b>' + esc(w.w) + '</b> <span class="muted">' + esc(w.cn) + '</span>' +
            (x.given ? ' <span class="badge bad">你写：' + esc(x.given) + '</span>' : '') + '</li>';
        }).join('') + '</ul></div>' : '') +
      '<details class="fold"><summary>本轮全部题目（' + q.log.length + '）</summary><ul class="list-plain">' +
        q.log.map(function (x) {
          var w = BY_WORD[x.w];
          return '<li>' + (x.correct ? '✓' : '✗') + ' <b>' + esc(w.w) + '</b> <span class="muted">' + esc(w.cn) + '</span></li>';
        }).join('') + '</ul></details>';

    $('#quizAgain').onclick = function () { startQuiz({ level: q.level, scope: q.scope, dir: q.dir, count: 20 }); };
    if ($('#quizWrongAgain')) {
      $('#quizWrongAgain').onclick = function () {
        var ws = wrongList.map(function (x) { return BY_WORD[x.w]; });
        startQuiz({ words: ws, dir: q.dir, count: ws.length, level: q.level });
      };
    }
    $('#quizBack').onclick = function () {
      $('#quizResult').style.display = 'none';
      $('#quizSetup').style.display = 'block';
      document.body.classList.remove('quizzing');   // 自检 G2：不回退沉浸态会让侧栏/底栏一直藏着，像页面坏了
    };
    saveAll();
  }

  /* ---------------- 真题 ---------------- */
  var realFilter = { level: 'all', type: 'all' };
  var realState = null;

  function renderRealList() {
    var types = ['all'].concat(PAPERS.map(function (p) { return p.type; }).filter(function (t, i, a) { return a.indexOf(t) === i; }));
    $('#realFilter').innerHTML =
      [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6']].map(function (l) {
        return '<button class="chip' + (realFilter.level === l[0] ? ' on' : '') + '" data-rl="' + l[0] + '">' + l[1] + '</button>';
      }).join('') +
      types.map(function (t) {
        return '<button class="chip' + (realFilter.type === t ? ' on' : '') + '" data-rt="' + t + '">' + (t === 'all' ? '全题型' : t) + '</button>';
      }).join('');

    var list = PAPERS.filter(function (p) {
      if (realFilter.level !== 'all' && p.level !== realFilter.level) return false;
      if (realFilter.type !== 'all' && p.type !== realFilter.type) return false;
      return true;
    });
    var realCount = list.filter(function (p) { return p.verified === true; }).length;
    var head = '<div class="card" style="margin-bottom:14px"><div class="split-row">' +
      '<span class="small muted">共 <b>' + list.length + '</b> 套' +
      (realCount ? ' · 其中网上抓取的真题 <b>' + realCount + '</b> 套' : '') +
      ' · 按题型与级别筛选</span></div></div>';
    $('#realList').innerHTML = head + (list.length ? list.map(function (p) {
      var tag = p.verified === true ? '<span class="badge good">真题</span>'
        : (p.verified === false ? '<span class="badge">仿真</span>' : '');
      return '<div class="paper-item" data-paper="' + esc(p.id) + '">' +
        '<div><div style="font-weight:600">' + esc(p.title) + '</div>' +
        '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.type) + ' · ' + esc((p.prompt || '').slice(0, 46)) + '</div></div>' +
        '<div class="row">' + tag + '<span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span>' +
        '<button class="btn sm primary">进入</button></div></div>';
    }).join('') : '<div class="card empty">这个筛选项下暂时没有题目。</div>');
  }

  function openPaper(id) {
    var p = PAPERS.filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    realState = { p: p, filled: {}, active: null, checked: false, page: 0, pages: null, pageHost: null };
    pgGo('#realTabs', 'run');
    renderPaper();
    resetScroll();
  }
  function closePaper() {
    pgGo('#realTabs', 'list');
    renderRealList();
  }

  /* 把长试卷拆成一页一页（阅读 / 长难句：短文一页，每题一页） */
  function splitPaperPages(container, p) {
    if (p.type !== '阅读理解' && p.type !== '阅读长难句') return null;
    var card = container.querySelector('.card');
    if (!card) return null;
    var kids = Array.prototype.slice.call(card.childNodes), qIdx = [];
    kids.forEach(function (n, i) {
      if (n.nodeType === 1 && n.querySelector && n.querySelector('.opt')) qIdx.push(i);
    });
    if (!qIdx.length) return null;
    var tail = kids.slice(qIdx[qIdx.length - 1] + 1);
    var pages = [{ label: p.type === '阅读理解' ? '短文' : '长难句', nodes: kids.slice(0, qIdx[0]) }];
    qIdx.forEach(function (from, qi) {
      var to = (qi + 1 < qIdx.length) ? qIdx[qi + 1] : kids.length;
      var arr = kids.slice(from, to);
      pages.push({
        label: '第 ' + (qi + 1) + ' / ' + qIdx.length + ' 题',
        nodes: (qi === qIdx.length - 1) ? arr.concat(tail) : arr
      });
    });
    return pages;
  }
  function pagerHtml(pages, cur) {
    if (!pages || pages.length <= 1) return '';
    return '<div class="card pager">' +
      '<button class="btn sm" id="pgPrev"' + (cur === 0 ? ' disabled' : '') + '>← 上一页</button>' +
      '<span class="small muted">' + (cur + 1) + ' / ' + pages.length + ' · ' + esc(pages[cur].label || '') + '</span>' +
      '<button class="btn sm" id="pgNext"' + (cur === pages.length - 1 ? ' disabled' : '') + '>下一页 →</button>' +
      '<span class="pager-dots">' + pages.map(function (pg, i) {
        return '<i class="pager-dot' + (i === cur ? ' on' : '') + '" data-pg="' + i + '"></i>';
      }).join('') + '</span></div>';
  }
  function bindPager(pages) {
    var st = realState;
    if (!pages || pages.length <= 1) return;
    function jump(i) {
      st.page = Math.max(0, Math.min(pages.length - 1, i));
      renderPaper();
      resetScroll();
    }
    var prev = $('#pgPrev'), next = $('#pgNext');
    if (prev) prev.onclick = function () { jump(st.page - 1); };
    if (next) next.onclick = function () { jump(st.page + 1); };
    $$('#realRun .pager-dot').forEach(function (d) {
      d.onclick = function () { jump(parseInt(d.dataset.pg, 10) || 0); };
    });
  }

  function renderPaper() {
    var st = realState, p = st.p;
    var head = '<div class="spread" style="margin-bottom:14px">' +
      '<div><h2 style="margin:0 0 4px;font-size:20px">' + esc(p.title) + '</h2>' +
      '<div class="small muted">' + esc(p.year) + ' · ' + esc(p.type) + ' <span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span></div></div>' +
      '<button class="btn" id="paperBack">← 返回题目列表</button></div>';
    var body = '';

    if (p.type === '选词填空') {
      body = '<div class="card">' +
        '<div class="card-title">题目要求</div><p style="margin:0" class="muted">' + esc(p.prompt) + '</p>' +
        '<div class="sep"></div>' +
        '<div class="bank" id="paperBank">' + (p.bank || []).map(function (b) {
          return '<span class="chip' + (Object.keys(st.filled).some(function (k) { return st.filled[k] === b; }) ? ' used' : '') +
            '" data-word="' + esc(b) + '">' + esc(b) + '</span>';
        }).join('') + '</div>' +
        '<div class="passage" id="paperPassage">' + passageHtml(p) + '</div>' +
        '<div class="sep"></div>' +
        '<div class="row"><button class="btn primary" id="paperCheck">提交判分</button>' +
        '<button class="btn ghost" id="paperReset">清空重做</button>' +
        '<span class="flow-note">先点词库里的词，再点空格填入。</span></div>' +
        '<div id="paperFeedback"></div>' +
        '</div>';
    } else if (p.type === '翻译') {
      body = '<div class="card">' +
        '<div class="card-title">中文原文</div><div class="passage">' + esc(p.source || '') + '</div>' +
        '<div class="sep"></div>' +
        '<div class="card-title">题目要求</div><p class="muted" style="margin:0">' + esc(p.prompt || '') + '</p>' +
        '<div class="sep"></div>' +
        '<div class="card-title">我的译文（可选）</div>' +
        '<textarea class="input" id="transInput" rows="6" placeholder="先自己写一遍，再看参考译文 —— 这一步比抄答案有用得多。"></textarea>' +
        '<div class="row" style="margin-top:12px"><button class="btn primary" id="paperCheck">对照参考译文</button>' +
        '<button class="btn ghost" id="paperBack2">← 返回</button></div>' +
        '<div id="paperFeedback"></div></div>';
    } else if (p.type === '阅读长难句') {
      body = '<div class="card"><div class="card-title">长难句</div>' +
        '<div class="passage">' + esc(p.sentence || '') + '</div><div class="sep"></div>' +
        (p.questions || []).map(function (q, qi) {
          return '<div style="margin-bottom:16px"><div style="font-weight:600;margin-bottom:8px">' + (qi + 1) + '. ' + esc(q.q) + '</div>' +
            '<div class="opt-grid">' + (q.options || []).map(function (o, oi) {
              return '<button class="opt" data-q="' + qi + '" data-o="' + oi + '">' + String.fromCharCode(65 + oi) + '. ' + esc(o) + '</button>';
            }).join('') + '</div><div id="qfb' + qi + '"></div></div>';
        }).join('') +
        '<div class="row"><button class="btn" id="revealLong">查看译文与语法点</button>' +
        '<button class="btn ghost" id="paperBack2">← 返回</button></div>' +
        '<div id="longExtra" style="display:none"></div></div>';
    } else if (p.type === '阅读理解') {
      body = '<div class="card"><div class="card-title">阅读短文' +
        (p.verified === true ? ' <span class="badge good">网上抓取的真题</span>' : '') + '</div>' +
        '<div class="passage">' + esc(p.passage || '') + '</div>' +
        ((p.keyWords || []).length ? '<div class="wd-block"><h4>本篇词汇</h4><div class="chip-row">' +
          p.keyWords.map(function (k) { return '<span class="chip">' + esc(k.w) + ' · ' + esc(k.cn) + '</span>'; }).join('') + '</div></div>' : '') +
        '<div class="sep"></div>' +
        (p.questions || []).map(function (q, qi) {
          return '<div style="margin-bottom:16px"><div style="font-weight:600;margin-bottom:8px">' + (qi + 1) + '. ' + esc(q.q) + '</div>' +
            '<div class="opt-grid">' + (q.options || []).map(function (o, oi) {
              return '<button class="opt" data-q="' + qi + '" data-o="' + oi + '">' + String.fromCharCode(65 + oi) + '. ' + esc(o) + '</button>';
            }).join('') + '</div><div id="qfb' + qi + '"></div></div>';
        }).join('') +
        '<div class="row"><button class="btn" id="revealLong">查看参考译文</button>' +
        '<button class="btn ghost" id="paperBack2">← 返回</button></div>' +
        '<div id="longExtra" style="display:none"></div></div>';
    } else if (p.type === '写作') {
      body = '<div class="card"><div class="card-title">题目</div><p style="margin:0">' + esc(p.prompt || '') + '</p>' +
        '<div class="sep"></div><div class="card-title">提纲</div><ul class="list-plain">' +
        (p.outline || []).map(function (o) { return '<li>' + esc(o) + '</li>'; }).join('') + '</ul>' +
        '<div class="sep"></div>' +
        '<div class="card-title">我的草稿（可选）</div>' +
        '<textarea class="input" id="writeInput" rows="8" placeholder="按提纲写够字数（四级 120-180 / 六级 150-200 词），写完再看范文与自检。"></textarea>' +
        '<div class="row" style="margin-top:12px"><button class="btn primary" id="paperCheck">看范文与亮点表达</button>' +
        '<button class="btn ghost" id="paperBack2">← 返回</button></div>' +
        '<div id="paperFeedback"></div></div>';
    }
    // 每次进入题目都换一个全新容器，避免 click 监听器逐题累积
    var host = $('#realRun');
    host.innerHTML = '';
    var root = document.createElement('div');
    root.innerHTML = head;
    host.appendChild(root);
    st.root = root;

    // 长试卷分页：首次进入时切好页，之后翻页只移动节点（答题状态不丢）
    if (!st.pageHost) {
      st.pageHost = document.createElement('div');
      st.pageHost.innerHTML = body;
      st.pages = splitPaperPages(st.pageHost, p);
    }
    if (st.pages) {
      var cur = Math.min(st.page || 0, st.pages.length - 1);
      st.page = cur;
      var wrap = document.createElement('div');
      wrap.className = 'card paper-page';
      st.pages[cur].nodes.forEach(function (n) { wrap.appendChild(n); });
      root.appendChild(wrap);
      root.insertAdjacentHTML('beforeend', pagerHtml(st.pages, cur));
      bindPager(st.pages);
    } else {
      var whole = document.createElement('div');
      whole.innerHTML = body;
      while (whole.firstChild) root.appendChild(whole.firstChild);
    }
    bindPaper(p);
  }

  function passageHtml(p) {
    var st = realState;
    var text = p.passage || '';
    // 把 (n)______ 替换成可点击空位
    return esc(text).replace(/\((\d+)\)_{2,}/g, function (m, n) {
      var n2 = parseInt(n, 10);
      var bl = (p.blanks || []).filter(function (b) { return b.n === n2; })[0];
      var filled = st.filled[n2];
      var cls = 'blank-slot' + (filled ? ' filled' : '');
      if (st.checked && bl) cls += looseEq(filled || '', bl.answer) ? ' ok' : ' no';
      return '<span class="' + cls + '" data-blank="' + n2 + '">' + esc(filled || '（' + n2 + '）______') + '</span>';
    });
  }

  function bindPaper(p) {
    var st = realState;
    $('#paperBack').onclick = closePaper;
    if ($('#paperBack2')) $('#paperBack2').onclick = closePaper;

    if (p.type === '选词填空') {
      $$('#realRun .bank .chip').forEach(function (c) {
        c.onclick = function () {
          $$('#realRun .bank .chip').forEach(function (x) { x.classList.remove('sel'); });
          c.classList.add('sel');
          st.active = c.dataset.word;
        };
      });
      st.root.addEventListener('click', function (e) {
        var slot = e.target.closest ? e.target.closest('.blank-slot') : null;
        if (!slot) return;
        var n = slot.dataset.blank;
        if (st.active) {
          st.filled[n] = st.active;
          st.active = null;
          st.checked = false;
          $('#paperPassage').innerHTML = passageHtml(p);
          $$('#realRun .bank .chip').forEach(function (x) {
            x.classList.toggle('used', Object.keys(st.filled).some(function (k) { return st.filled[k] === x.dataset.word; }));
            x.classList.remove('sel');
          });
          $('#paperFeedback').innerHTML = '';
        } else if (st.filled[n]) {
          delete st.filled[n];
          st.checked = false;
          $('#paperPassage').innerHTML = passageHtml(p);
          $$('#realRun .bank .chip').forEach(function (x) {
            x.classList.toggle('used', Object.keys(st.filled).some(function (k) { return st.filled[k] === x.dataset.word; }));
          });
          $('#paperFeedback').innerHTML = '';
        } else {
          toast('先在上面词库里点一个词');
        }
      });
      $('#paperCheck').onclick = function () { checkCloze(p); };
      $('#paperReset').onclick = function () { st.filled = {}; st.checked = false; $('#paperPassage').innerHTML = passageHtml(p); $('#paperFeedback').innerHTML = ''; };
    }

    if (p.type === '翻译' || p.type === '写作') {
      $('#paperCheck').onclick = function () {
        var fb = $('#paperFeedback');
        if (p.type === '翻译') {
          // 自检 F6：草稿框原来从不被读取，写完切页即丢 —— 现在先把你写的渲染出来，再做关键词覆盖自检
          var mine = String((($('#transInput') || {}).value) || '').trim();
          var draft = '';
          if (mine) {
            var kws = p.keyWords || [];
            var hit = kws.filter(function (k) { return keywordHit(mine, k.w); });
            var nWords = (mine.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            draft = '<div class="sep"></div><div class="card-title">你的译文 <span class="tag small muted">' + nWords + ' 个英文词</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(mine) + '</div>' +
              (kws.length ? '<div class="spread small" style="margin-top:8px"><span>采分点覆盖 <b>' + hit.length + ' / ' + kws.length + '</b></span>' +
                '<span class="muted">本地规则，只查关键词是否出现</span></div><div style="margin-top:6px">' +
                kws.map(function (k) {
                  var ok = keywordHit(mine, k.w);
                  return '<span class="badge ' + (ok ? 'good' : 'bad') + '" style="margin:3px 6px 3px 0">' + (ok ? '✓ ' : '✗ ') + esc(k.w) + ' · ' + esc(k.cn) + '</span>';
                }).join('') + '</div>' : '');
          }
          fb.innerHTML = draft + '<div class="sep"></div>' +
            '<div class="card-title">参考译文</div><div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.reference || '') + '</div>' +
            '<div class="wd-block"><h4>采分点</h4><ul>' + (p.points || []).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>' +
            ((p.keyWords || []).length ? '<div class="wd-block"><h4>关键词</h4><div class="chip-row">' +
              p.keyWords.map(function (k) { return '<span class="chip">' + esc(k.w) + ' · ' + esc(k.cn) + '</span>'; }).join('') + '</div></div>' : '');
        } else {
          var myW = String((($('#writeInput') || {}).value) || '').trim();
          var wDraft = '';
          if (myW) {
            // 2026-09-25：作文不再做检测，这里只回放草稿 + 给范文（原「连接词覆盖 + 完整版体检指引」已删）
            var nw = (myW.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;
            var paras = myW.split(/\n\s*\n/).filter(function (x) { return x.trim(); }).length;
            wDraft = '<div class="sep"></div><div class="card-title">你的草稿 <span class="tag small muted">' + nw + ' 词 · ' + paras + ' 段</span></div>' +
              '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px;white-space:pre-wrap">' + esc(myW) + '</div>';
          }
          fb.innerHTML = wDraft + '<div class="sep"></div><div class="card-title">范文</div>' +
            '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.sample || '') + '</div>' +
            '<div class="wd-block"><h4>亮点表达</h4><ul>' + (p.expressions || []).map(function (x) {
              return '<li><b>' + esc(x.en) + '</b> —— ' + esc(x.cn) + '</li>';
            }).join('') + '</ul></div>';
        }
        countPaper();
      };
    }

    if (p.type === '阅读长难句' || p.type === '阅读理解') {
      $$('#realRun .opt').forEach(function (b) {
        b.onclick = function () {
          var qi = parseInt(b.dataset.q, 10), oi = parseInt(b.dataset.o, 10);
          var q = p.questions[qi];
          $$('#realRun .opt[data-q="' + qi + '"]').forEach(function (x) { x.classList.remove('ok', 'no'); });
          var ok = oi === q.answer;
          b.classList.add(ok ? 'ok' : 'no');
          if (!ok) $$('#realRun .opt[data-q="' + qi + '"][data-o="' + q.answer + '"]').forEach(function (x) { x.classList.add('ok'); });
          $('#qfb' + qi).innerHTML = '<div class="blank-explain ' + (ok ? 'ok' : 'no') + '">' +
            (ok ? '✓ 正确。' : '✗ 再想想。') + esc(q.explain || '') + '</div>';
        };
      });
      var rvLong = $('#revealLong');
      if (rvLong) rvLong.onclick = function () {
        var box = $('#longExtra');
        box.style.display = 'block';
        box.innerHTML = '<div class="sep"></div><div class="card-title">参考译文</div>' +
          '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.translation || '（本篇暂无参考译文）') + '</div>' +
          ((p.points || []).length ? '<div class="wd-block"><h4>语法点</h4><ul>' +
            p.points.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>' : '');
      };
    }
  }

  function checkCloze(p) {
    var st = realState;
    st.checked = true;
    $('#paperPassage').innerHTML = passageHtml(p);
    var right = 0, total = (p.blanks || []).length;
    var html = '<div class="sep"></div><div class="card-title">逐空解析</div>';
    (p.blanks || []).forEach(function (b) {
      var got = st.filled[b.n];
      var ok = looseEq(got || '', b.answer);
      if (ok) right++;
      html += '<div class="blank-explain ' + (ok ? 'ok' : 'no') + '"><b>' + b.n + '. ' + esc(b.answer) + '</b>' +
        (ok ? ' <span class="badge good">正确</span>' : ' <span class="badge bad">你填了 ' + esc(got || '空') + '</span>') +
        '<div style="margin-top:4px">' + esc(b.explain || '') + '</div></div>';
    });
    html += '<div class="wd-block"><h4>本题考查</h4><ul>' + (p.points || []).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';
    $('#paperFeedback').innerHTML = html;
    toast('得分 ' + right + ' / ' + total);
    countPaper();
  }
  function countPaper() {
    var d = stats[todayStr()] || { answered: 0, right: 0, wrong: 0, newWords: 0, papers: 0 };
    d.papers = (d.papers || 0) + 1;
    stats[todayStr()] = d;
    saveAll();
  }

  /* ==========================================================
     语法模式：按考点刷题 + 五类题型 + 错题本
     ========================================================== */
  var GRAMMAR = window.GRAMMAR_BANK || [];
  var grammarProg = load('wudu.grammar.v1', {});
  var gState = { point: 'all', run: null };

  function grammarPoints() {
    var ps = [];
    GRAMMAR.forEach(function (g) { if (g && g.point && ps.indexOf(g.point) < 0) ps.push(g.point); });
    return ps;
  }
  function gKey(g, idx) { return g.id + '#' + idx; }

  function renderGrammarList() {
    pgGo('#grammarTabs', 'list');
    var host = $('#grammarList');
    if (!GRAMMAR.length) { host.innerHTML = '<div class="card empty">语法题库未加载 —— 检查 assets/js/data/grammar.js</div>'; $('#grammarFilter').innerHTML = ''; return; }

    $('#grammarFilter').innerHTML = ['all'].concat(grammarPoints()).map(function (p) {
      return '<button class="chip' + (gState.point === p ? ' on' : '') + '" data-gp="' + esc(p) + '">' +
        (p === 'all' ? '全部考点' : esc(p)) + '</button>';
    }).join('');

    var list = GRAMMAR.filter(function (g) { return gState.point === 'all' || g.point === gState.point; });
    var total = list.reduce(function (a, g) { return a + (g.items || []).length; }, 0);
    var wrongTotal = Object.keys(grammarProg).filter(function (k) { return grammarProg[k].wrong > 0; }).length;

    host.innerHTML =
      '<div class="card" style="margin-bottom:16px"><div class="spread">' +
        '<span class="small muted">' + list.length + ' 个专题 · ' + total + ' 道题' +
        (wrongTotal ? ' · 错题本 ' + wrongTotal + ' 题' : '') + '</span>' +
        '<div class="row">' +
          (wrongTotal ? '<button class="btn" id="gWrongOnly">只练错题（' + wrongTotal + '）</button>' : '') +
          '<select class="input" id="gCount" style="width:104px;padding:8px 10px">' +
            '<option value="20" selected>20 题</option>' +
            '<option value="30">30 题</option>' +
            '<option value="50">50 题</option>' +
            '<option value="0">全部（' + total + '）</option>' +
          '</select>' +
          '<button class="btn primary" id="gStartAll">开始本轮练习</button>' +
        '</div>' +
      '</div></div>' +
      list.map(function (g) {
        var wc = (g.items || []).filter(function (it, i) { return grammarProg[gKey(g, i)] && grammarProg[gKey(g, i)].wrong > 0; }).length;
        return '<div class="card g-card" data-gid="' + esc(g.id) + '">' +
          '<div class="spread"><div><b style="font-size:16px">' + esc(g.point) + ' · ' + esc(g.sub) + '</b> ' +
            '<span class="badge ' + (g.level || 'cet4') + '">' + String(g.level || 'cet4').toUpperCase() + '</span>' +
            '<span class="badge">频率 ' + '★'.repeat(g.freq || 1) + '</span>' +
            (wc ? ' <span class="badge bad">错题 ' + wc + '</span>' : '') + '</div>' +
            '<span class="badge">' + (g.items || []).length + ' 题</span></div>' +
          '<div class="small muted" style="margin-top:8px">' + esc(String(g.rule || '').slice(0, 96)) + (String(g.rule || '').length > 96 ? '…' : '') + '</div>' +
        '</div>';
      }).join('');

    $('#gStartAll').onclick = function () {
      var pool = [];
      list.forEach(function (g) {
        (g.items || []).forEach(function (it, i) { pool.push({ g: g, idx: i, item: it }); });
      });
      var want = parseInt(($('#gCount') || {}).value, 10);
      if (isNaN(want)) want = 20;
      var picked = shuffle(pool);
      picked = (want > 0) ? picked.slice(0, want) : picked;
      startGrammar(picked);
    };
    if ($('#gWrongOnly')) {
      $('#gWrongOnly').onclick = function () {
        var pool = [];
        GRAMMAR.forEach(function (g) {
          (g.items || []).forEach(function (it, i) {
            if (grammarProg[gKey(g, i)] && grammarProg[gKey(g, i)].wrong > 0) pool.push({ g: g, idx: i, item: it });
          });
        });
        startGrammar(shuffle(pool));
      };
    }
    $$('#grammarList .g-card').forEach(function (c) {
      c.onclick = function () { openGrammarCard(c.dataset.gid); };
    });
  }

  function openGrammarCard(id) {
    var g = GRAMMAR.filter(function (x) { return x.id === id; })[0];
    if (!g) return;
    var items = (g.items || []).map(function (it, i) { return { g: g, idx: i, item: it }; });
    $('#grammarList').innerHTML =
      '<div class="spread" style="margin-bottom:14px">' +
        '<div><h2 style="margin:0 0 4px;font-size:20px">' + esc(g.point) + ' · ' + esc(g.sub) + '</h2>' +
        '<div class="small muted">' + String(g.level || 'cet4').toUpperCase() + ' · 频率 ' + '★'.repeat(g.freq || 1) + '</div></div>' +
        '<button class="btn" id="gBack">← 返回考点列表</button></div>' +
      '<div class="card"><div class="card-title">规则</div><div>' + esc(g.rule || '') + '</div>' +
        ((g.tips || []).length ? '<div class="wd-block"><h4>易错提醒</h4><ul>' +
          g.tips.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul></div>' : '') +
        ((g.examples || []).length ? '<div class="wd-block"><h4>例句</h4>' +
          g.examples.map(function (e) {
            return '<div class="ex-sent"><div class="en">' + esc(e.en) + '</div><div class="cn">' + esc(e.cn) + '</div>' +
              (e.note ? '<div class="small muted" style="margin-top:3px">' + esc(e.note) + '</div>' : '') + '</div>';
          }).join('') + '</div>' : '') +
        '<div class="row" style="margin-top:16px"><button class="btn primary" id="gStartThis">练习这个考点的 ' + items.length + ' 道题</button></div>' +
      '</div>';
    $('#gBack').onclick = renderGrammarList;
    $('#gStartThis').onclick = function () { startGrammar(shuffle(items)); };
  }

  function startGrammar(items) {
    if (!items.length) { toast('没有可练的题'); return; }
    gState.run = { queue: items, pos: 0, right: 0, wrong: 0, answered: false, log: [] };
    pgGo('#grammarTabs', 'run');
    renderGrammarQuestion();
    resetScroll();
  }

  function renderGrammarQuestion() {
    var r = gState.run, cur = r.queue[r.pos];
    if (!cur) { endGrammar(); return; }
    var g = cur.g, it = cur.item;
    r.answered = false;
    var TYPE = { choice: '四选一', error: '改错', fill: '填空', reorder: '连词成句', analysis: '长难句解析' };
    var head =
      '<div class="spread" style="margin-bottom:10px">' +
        '<div class="row"><span class="badge">' + (r.pos + 1) + ' / ' + r.queue.length + '</span>' +
        '<span class="badge">' + esc(g.point) + '</span>' +
        '<span class="badge due">' + (TYPE[it.type] || it.type) + '</span></div>' +
        '<div class="row"><span class="badge good">✓ ' + r.right + '</span><span class="badge bad">✗ ' + r.wrong + '</span>' +
        '<button class="btn sm ghost" id="gQuit">结束</button></div>' +
      '</div>' +
      '<div class="bar" style="margin-bottom:16px"><i style="width:' + (r.pos / r.queue.length * 100) + '%"></i></div>';

    var body = '';
    if (it.type === 'choice' || it.type === 'analysis') {
      var q = it.type === 'analysis' ? ('句子：' + it.sentence + '<div style="margin-top:10px">' + esc(it.question) + '</div>') : esc(it.q);
      body = '<div class="card"><div class="card-title">' + (TYPE[it.type]) + '</div>' +
        '<div class="passage">' + (it.type === 'analysis' ? '<i>' + esc(it.sentence) + '</i><div style="margin-top:12px">' + esc(it.question) + '</div>' : esc(it.q)) + '</div>' +
        '<div class="opt-grid" style="margin-top:16px" id="gOpts">' +
        (it.options || []).map(function (o, i) {
          return '<button class="opt" data-i="' + i + '">' + String.fromCharCode(65 + i) + '. ' + esc(o) + '</button>';
        }).join('') + '</div></div>';
    } else if (it.type === 'error') {
      body = '<div class="card"><div class="card-title">改错</div>' +
        '<div class="passage">' + esc(it.q || '找出下面句子的错误并改正。') + '</div>' +
        '<div class="ex-sent" style="margin-top:10px"><div class="en">' + esc(it.wrong) + '</div></div>' +
        '<div class="row" style="margin-top:14px"><input class="input" id="gInput" placeholder="写出改正后的整句…" autocomplete="off" spellcheck="false" style="flex:1">' +
        '<button class="btn primary" id="gSubmit">提交</button><button class="btn ghost" id="gReveal">看答案</button></div></div>';
    } else if (it.type === 'fill') {
      body = '<div class="card"><div class="card-title">填空</div>' +
        '<div class="passage">' + esc(it.q) + '</div>' +
        '<div class="row" style="margin-top:14px"><input class="input" id="gInput" placeholder="填入答案…" autocomplete="off" spellcheck="false" style="flex:1;max-width:420px">' +
        '<button class="btn primary" id="gSubmit">提交</button><button class="btn ghost" id="gReveal">看答案</button></div></div>';
    } else if (it.type === 'reorder') {
      body = '<div class="card"><div class="card-title">连词成句</div>' +
        (it.cn ? '<div class="small muted" style="margin-bottom:10px">目标意思：' + esc(it.cn) + '</div>' : '') +
        '<div class="reorder-answer" id="gBuilt"><span class="muted small">点下面的词块，按顺序拼成句子</span></div>' +
        '<div class="chip-row" id="gWords" style="margin-top:12px">' +
        (it.words || []).map(function (w, i) { return '<button class="chip" data-wi="' + i + '">' + esc(w) + '</button>'; }).join('') + '</div>' +
        '<div class="row" style="margin-top:14px"><button class="btn primary" id="gSubmit">提交</button>' +
        '<button class="btn ghost" id="gReset">重排</button><button class="btn ghost" id="gReveal">看答案</button></div></div>';
    }

    $('#grammarRun').innerHTML = head + body + '<div id="gFeedback"></div>';
    $('#gQuit').onclick = function () { if (gState.run) endGrammar(); };

    if (it.type === 'choice' || it.type === 'analysis') {
      $$('#gOpts .opt').forEach(function (b) {
        b.onclick = function () {
          if (r.answered) return;
          r.answered = true;
          var i = parseInt(b.dataset.i, 10);
          var ok = i === it.answer;
          $$('#gOpts .opt').forEach(function (x) {
            if (parseInt(x.dataset.i, 10) === it.answer) x.classList.add('ok');
          });
          if (!ok) b.classList.add('no');
          grammarSettle(ok, it, '选项 ' + String.fromCharCode(65 + i), null);
        };
      });
    } else if (it.type === 'reorder') {
      var built = [];
      var words = it.words || [];
      var usedIdx = [];
      function redraw() {
        var host = $('#gBuilt');
        host.innerHTML = built.length
          ? built.map(function (w, i) { return '<span class="chip on" data-bi="' + i + '">' + esc(w) + '</span>'; }).join(' ')
          : '<span class="muted small">点下面的词块，按顺序拼成句子</span>';
        $$('#gBuilt .chip').forEach(function (c) {
          c.onclick = function () { built.splice(parseInt(c.dataset.bi, 10), 1); redraw(); };
        });
        $$('#gWords .chip').forEach(function (c) {
          c.classList.toggle('used', usedIdx.indexOf(parseInt(c.dataset.wi, 10)) >= 0);
        });
      }
      $$('#gWords .chip').forEach(function (c) {
        c.onclick = function () {
          var i = parseInt(c.dataset.wi, 10);
          if (usedIdx.indexOf(i) >= 0) return;
          usedIdx.push(i); built.push(words[i]); redraw();
        };
      });
      $('#gReset').onclick = function () { built = []; usedIdx = []; redraw(); };
      $('#gSubmit').onclick = function () {
        if (r.answered) return;
        r.answered = true;
        var jd = judge(built.join(' '), it.answer);
        grammarSettle(jd.ok, it, built.join(' '), jd);
      };
      $('#gReveal').onclick = function () { grammarReveal(it); };
    } else {
      var input = $('#gInput');
      if (input) input.focus();
      var submit = function () {
        if (r.answered) return;
        var val = (input.value || '').trim();
        if (!val) { toast('先写点什么，或者点「看答案」'); return; }
        r.answered = true;
        var jd = judge(val, it.type === 'error' ? it.right : it.answer);
        grammarSettle(jd.ok, it, val, jd);
      };
      $('#gSubmit').onclick = submit;
      input.onkeydown = function (e) { if (e.key === 'Enter') { e.stopPropagation(); submit(); } };
      $('#gReveal').onclick = function () { grammarReveal(it); };
    }
  }

  function grammarReveal(it) {
    var r = gState.run;
    if (r.answered) return;
    r.answered = true;
    grammarSettle(false, it, null, { ok: false, kind: 'self' }, { revealOnly: true });
  }

  function grammarSettle(ok, it, given, jd, opt) {
    opt = opt || {};
    var r = gState.run, cur = r.queue[r.pos];
    var key = gKey(cur.g, cur.idx);
    if (ok) {
      r.right++;
      if (grammarProg[key] && !opt.revealOnly) {
        grammarProg[key].wrong = Math.max(0, grammarProg[key].wrong - 1);
      }
    } else {
      r.wrong++;
      grammarProg[key] = grammarProg[key] || { wrong: 0, last: '' };
      grammarProg[key].wrong++;
      grammarProg[key].last = todayStr();
    }
    save('wudu.grammar.v1', grammarProg);
    r.log.push({ g: cur.g, idx: cur.idx, item: it, ok: ok });

    var answerText = it.type === 'error' ? it.right : it.answer;
    var fb = '<div class="card" style="margin-top:16px"><div class="quiz-answer ' + (ok ? 'ok' : 'no') + '">' +
      '<div class="row" style="margin-bottom:6px"><b>' + (ok ? '✅ 正确' : '❌ 正确答案') + '</b>' +
      (jd && KIND_LABEL[jd.kind] ? '<span class="badge due">' + KIND_LABEL[jd.kind] + '</span>' : '') + '</div>' +
      (given && !ok ? '<div class="diff-line">你写的：<code>' + diffHtml(given, answerText) + '</code></div>' : '') +
      '<div style="font-size:17px;margin-top:4px"><b>' + esc(answerText) + '</b></div>' +
      (it.explain ? '<div style="margin-top:8px">' + esc(it.explain) + '</div>' : '') +
      (it.translation ? '<div class="small muted" style="margin-top:6px">参考译文：' + esc(it.translation) + '</div>' : '') +
      '</div></div>';

    $('#gFeedback').innerHTML = fb;
    $('#grammarRun').insertAdjacentHTML('beforeend',
      '<div class="row" style="justify-content:center;margin-top:16px">' +
      '<button class="btn primary" id="gNext">' + (r.pos + 1 >= r.queue.length ? '看结果' : '下一题 →') + '</button>' +
      '<button class="btn ghost" id="gRule">看这个考点的规则</button></div>');
    $('#gNext').focus();
    $('#gNext').onclick = function () { r.pos++; if (r.pos >= r.queue.length) endGrammar(); else renderGrammarQuestion(); };
    $('#gRule').onclick = function () {
      var g = cur.g;
      toast(g.point + ' · ' + g.sub);
      $('#gFeedback').insertAdjacentHTML('beforeend',
        '<div class="card" style="margin-top:12px"><div class="card-title">规则回顾</div>' + esc(g.rule || '') +
        ((g.tips || []).length ? '<ul class="list-plain" style="margin-top:8px">' + g.tips.map(function (t) { return '<li>· ' + esc(t) + '</li>'; }).join('') + '</ul>' : '') + '</div>');
    };
  }

  function endGrammar() {
    var r = gState.run;
    if (!r) return;
    pgGo('#grammarTabs', 'list');
    var total = r.right + r.wrong;
    var rate = total ? Math.round(r.right / total * 100) : 0;
    var wrongList = r.log.filter(function (x) { return !x.ok; });
    $('#grammarList').innerHTML =
      '<div class="card" style="text-align:center">' +
      '<div class="card-title" style="justify-content:center">本轮完成</div>' +
      '<div class="countdown">' + rate + '%<small>正确率</small></div>' +
      '<div class="muted small" style="margin-top:6px">共 ' + total + ' 题 · 对 ' + r.right + ' · 错 ' + r.wrong + '</div>' +
      '<div class="row" style="justify-content:center;margin-top:18px">' +
      (wrongList.length ? '<button class="btn primary" id="gRetryWrong">只练这 ' + wrongList.length + ' 道错题</button>' : '') +
      '<button class="btn" id="gBackList">回到考点列表</button></div></div>' +
      (wrongList.length ? '<div class="card"><div class="card-title">本轮错题</div><ul class="list-plain">' +
        wrongList.map(function (x) {
          var a = x.item.type === 'error' ? x.item.right : x.item.answer;
          return '<li><b>' + esc(x.g.point) + ' · ' + esc(x.g.sub) + '</b> → 正确答案：' + esc(a) + '</li>';
        }).join('') + '</ul></div>' : '');
    if ($('#gRetryWrong')) $('#gRetryWrong').onclick = function () { startGrammar(shuffle(wrongList)); };
    $('#gBackList').onclick = renderGrammarList;
    gState.run = null;
  }

  /* ==========================================================
     翻译训练：先自己写 → 采分点自检 → 解锁逐句对照
     ========================================================== */
  var TRBANK = window.TRANSLATION_BANK || [];
  var trFilter = { level: 'all' };
  var trState = null;

  function renderTrList() {
    pgGo('#trTabs', 'list');
    if (!TRBANK.length) { $('#trList').innerHTML = '<div class="card empty">翻译题库未加载 —— 检查 assets/js/data/translate.js</div>'; $('#trFilter').innerHTML = ''; return; }
    $('#trFilter').innerHTML = [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6']].map(function (l) {
      return '<button class="chip' + (trFilter.level === l[0] ? ' on' : '') + '" data-tl="' + l[0] + '">' + l[1] + '</button>';
    }).join('');
    var list = TRBANK.filter(function (p) { return trFilter.level === 'all' || p.level === trFilter.level; });
    $('#trList').innerHTML = list.map(function (p) {
      var rec = trRecord(p.id);
      return '<div class="paper-item" data-tr="' + esc(p.id) + '">' +
        '<div><div style="font-weight:600">' + esc(p.title) + '</div>' +
        '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.topic || '') + ' · ' + (p.sentences || []).length + ' 句逐句对照' +
        (rec ? ' · 已练 ' + rec.times + ' 次' : '') + '</div></div>' +
        '<div class="row"><span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span>' +
        '<button class="btn sm primary">开始</button></div></div>';
    }).join('');
  }
  var trProg = load('wudu.translate.v1', {});
  function trRecord(id) { return trProg[id] || null; }

  function openTr(id) {
    var p = TRBANK.filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    trState = { p: p, unlocked: false };
    pgGo('#trTabs', 'run');
    $('#trRun').innerHTML =
      '<div class="spread" style="margin-bottom:14px">' +
        '<div><h2 style="margin:0 0 4px;font-size:20px">' + esc(p.title) + '</h2>' +
        '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.topic || '') + ' <span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span></div></div>' +
        '<button class="btn" id="trBack">← 返回列表</button></div>' +
      '<div class="card"><div class="card-title">中文原文（请先完整译一遍，再往下走）</div>' +
        '<div class="passage">' + esc(p.source) + '</div>' +
        '<div class="sep"></div>' +
        '<div class="card-title">我的译文</div>' +
        '<textarea class="input" id="trInput" rows="7" placeholder="在这里翻译…… 提交后才会解锁采分点自检与参考译文。"></textarea>' +
        '<div class="row" style="margin-top:12px">' +
          '<button class="btn primary" id="trSubmit">提交并做采分点自检</button>' +
          '<button class="btn ghost" id="trSkip">跳过，直接看答案</button>' +
          '<span class="flow-note">关键词 ' + (p.keyWords || []).length + ' 个 · 采分点 ' + (p.scoring || []).length + ' 条</span>' +
        '</div>' +
        '<div id="trFeedback"></div>' +
      '</div>';
    $('#trBack').onclick = renderTrList;
    $('#trSubmit').onclick = function () { trReveal(true); };
    $('#trSkip').onclick = function () { trReveal(false); };
  }

  // 关键词覆盖自检：把译文与关键词做词形近似匹配
  function keywordHit(text, w) {
    var t = ' ' + normalizeAns(text) + ' ', key = normalizeAns(w);
    if (!key) return false;
    if (t.indexOf(' ' + key) >= 0) return true;
    // 自检 F1：只比原形会把正确表达判成「漏译」—— economies 对 economy、well-known 对 known 都该算命中
    var forms = variantForms(key).concat(stems(key), stems(norm(key)));
    if (forms.some(function (v) { return v && t.indexOf(' ' + v) >= 0; })) return true;
    // 连字符 / 空格互换（well-known ↔ well known），再按词逐个做词形比对（复数、单三、过去式）
    var flat = (' ' + t + ' ').replace(/-/g, ' ').replace(/\s+/g, ' ');
    var keyFlat = key.replace(/-/g, ' ');
    if (flat.indexOf(' ' + keyFlat + ' ') >= 0) return true;
    if (keyFlat.indexOf(' ') < 0) {
      var ks = stems(keyFlat);
      var toks = flat.split(' ');
      for (var i = 0; i < toks.length; i++) {
        if (!toks[i]) continue;
        if (ks.indexOf(toks[i]) >= 0) return true;
        if (stems(toks[i]).indexOf(keyFlat) >= 0) return true;
      }
    }
    return false;
  }

  function trReveal(withCheck) {
    var p = trState.p, fb = $('#trFeedback');
    var mine = ($('#trInput') || {}).value || '';
    var kws = p.keyWords || [];
    var hit = kws.filter(function (k) { return keywordHit(mine, k.w); });
    var miss = kws.filter(function (k) { return !keywordHit(mine, k.w); });
    var words = (mine.match(/[A-Za-z][A-Za-z'-]*/g) || []).length;

    var html = '<div class="sep"></div>';
    if (withCheck && mine.trim()) {
      html += '<div class="card-title">① 采分点自检 <span class="tag small muted">本地规则，只查关键词覆盖，不做语义批改</span></div>' +
        '<div class="spread small"><span>关键词覆盖 <b>' + hit.length + ' / ' + kws.length + '</b></span>' +
        '<span class="muted">你写了 ' + words + ' 个英文词</span></div>' +
        '<div class="rv-row"><div class="rv-bar" style="flex:1;max-width:100%"><i style="width:' +
          (kws.length ? Math.round(hit.length / kws.length * 100) : 0) + '%"></i></div></div>' +
        '<div style="margin-top:10px">' + kws.map(function (k) {
          var ok = keywordHit(mine, k.w);
          return '<span class="badge ' + (ok ? 'good' : 'bad') + '" style="margin:3px 6px 3px 0">' +
            (ok ? '✓ ' : '✗ ') + esc(k.w) + ' · ' + esc(k.cn) + '</span>';
        }).join('') + '</div>' +
        (miss.length ? '<div class="flow-note" style="margin-top:8px">带 ✗ 的是没检出的关键词 —— 可能是漏译，也可能是你用了别的说法，自己核对一下。</div>' : '<div class="flow-note" style="margin-top:8px">关键词全覆盖，棒。</div>');
    } else {
      html += '<div class="flow-note">已跳过自检，直接看答案。下次先写一遍，效果差很多哦。</div>';
    }

    html += '<div class="sep"></div>' +
      '<div class="card-title">② 逐句对照</div>' +
      '<table class="day-table"><thead><tr><th style="width:38%">中文原句</th><th>参考译文</th></tr></thead><tbody>' +
      (p.sentences || []).map(function (s) {
        return '<tr><td>' + esc(s.cn) + '</td><td>' + esc(s.ref) +
          ((s.points || []).length ? '<div class="small muted" style="margin-top:4px">' + s.points.map(function (x) { return '· ' + esc(x); }).join('<br>') + '</div>' : '') +
          '</td></tr>';
      }).join('') + '</tbody></table>' +
      '<div class="wd-block"><h4>整段参考译文</h4><div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(p.reference) + '</div></div>' +
      '<div class="wd-block"><h4>评分要点（四六级 15 分制口径）</h4><ul>' + (p.scoring || []).map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="wd-block"><h4>常见扣分点</h4><ul>' + (p.pitfalls || []).map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="row" style="margin-top:14px"><button class="btn primary" id="trNext">下一篇 →</button>' +
      '<button class="btn" id="trBack2">回到列表</button></div>';

    fb.innerHTML = html;
    trState.unlocked = true;
    var rec = trProg[p.id] || { times: 0, last: '' };
    rec.times++; rec.last = todayStr();
    trProg[p.id] = rec;
    save('wudu.translate.v1', trProg);
    countStudy();
    $('#trBack2').onclick = renderTrList;
    $('#trNext').onclick = function () {
      var list = TRBANK.filter(function (x) { return trFilter.level === 'all' || x.level === trFilter.level; });
      var i = list.map(function (x) { return x.id; }).indexOf(p.id);
      var nx = list[(i + 1) % list.length];
      if (nx) openTr(nx.id);
    };
  }

  // 学过一次就记一次当日学习（给总览打卡用）
  function countStudy() {
    var d = stats[todayStr()] || { answered: 0, right: 0, wrong: 0, newWords: 0, papers: 0 };
    d.answered++; d.right++;
    stats[todayStr()] = d;
    saveAll();
  }


  /* ==========================================================
     写作素材：连贯词表 / 高频错误 / 中式英语纠正（工具页，不参与作文评分）
     ========================================================== */
  var WKIT = window.WRITING_KIT || {};
  var wrFilter = { level: 'all' };
  var wrState = null;

  function wcCount(t) { return (String(t).match(/[A-Za-z][A-Za-z'-]*/g) || []).length; }
  function splitSentences(t) {
    return String(t).split(/[.!?]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 2; });
  }
  function splitParas(t) {
    return String(t).split(/\n\s*\n|\n/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 2; });
  }
  function stdev(arr) {
    if (arr.length < 2) return 0;
    var m = arr.reduce(function (a, b) { return a + b; }, 0) / arr.length;
    return Math.sqrt(arr.reduce(function (a, b) { return a + (b - m) * (b - m); }, 0) / arr.length);
  }
  function wrTopics() { return (WKIT.topics || []); }

  function renderWrList() {
    pgGo('#wrTabs', 'list');
    var topics = wrTopics();
    if (!topics.length) { $('#wrList').innerHTML = '<div class="card empty">写作资源未加载 —— 检查 assets/js/data/writing.js</div>'; $('#wrFilter').innerHTML = ''; return; }
    $('#wrFilter').innerHTML = [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6']].map(function (l) {
      return '<button class="chip' + (wrFilter.level === l[0] ? ' on' : '') + '" data-wl="' + l[0] + '">' + l[1] + '</button>';
    }).join('');
    var list = topics.filter(function (t) { return wrFilter.level === 'all' || t.level === wrFilter.level; });
    $('#wrList').innerHTML =
      '<div class="card" style="margin-bottom:14px"><div class="spread">' +
        '<span class="small muted">' + list.length + ' 个话题 · 写完提交就能对范文 · 亮点表达 · 同义升级</span>' +
        '<button class="btn" id="wrKit">素材库（衔接词 / 常见错误 / 中式英语）</button>' +
      '</div></div>' +
      list.map(function (t) {
        return '<div class="paper-item" data-wr="' + esc(t.id) + '">' +
          '<div><div style="font-weight:600">' + esc(t.title) + '</div>' +
          '<div class="small muted">' + esc(t.topic) + ' · 提纲 ' + (t.outline || []).length + ' 条 · 亮点表达 ' + (t.expressions || []).length + ' 条</div></div>' +
          '<div class="row"><span class="badge ' + t.level + '">' + String(t.level).toUpperCase() + '</span>' +
          '<button class="btn sm primary">开始写</button></div></div>';
      }).join('');
    $('#wrKit').onclick = openWritingKit;
  }

  function openWritingKit() {
    var c = WKIT.connectors || {};
    var names = { addition: '递进', contrast: '转折', cause: '因果', example: '举例', conclusion: '总结' };
    $('#wrList').innerHTML =
      '<div class="spread" style="margin-bottom:14px"><h2 style="margin:0;font-size:20px">写作素材库</h2>' +
      '<button class="btn" id="wrBack">← 返回话题</button></div>' +
      '<div class="card"><div class="card-title">衔接词（对应「结构逻辑」）</div>' +
      Object.keys(c).map(function (k) {
        return '<div style="margin-bottom:8px"><span class="badge due">' + (names[k] || k) + '</span> ' +
          (c[k] || []).map(function (w) { return '<span class="chip" style="margin:3px">' + esc(w) + '</span>'; }).join('') + '</div>';
      }).join('') + '</div>' +
      '<div class="card" style="margin-top:14px"><div class="card-title">常见错误类型</div><ul class="list-plain">' +
      (WKIT.commonErrors || []).map(function (e) {
        return '<li><b>' + esc(e.name) + '</b> —— ' + esc(e.desc) +
          (e.example ? '<div class="small muted">例：' + esc(e.example) + '</div>' : '') + '</li>';
      }).join('') + '</ul></div>' +
      '<div class="card" style="margin-top:14px"><div class="card-title">中式英语纠正（' + ((WKIT.chinglish || []).length) + ' 条）</div><ul class="list-plain">' +
      (WKIT.chinglish || []).map(function (x) {
        return '<li><span class="badge bad">✗</span> ' + esc(x.pattern) + ' → <span class="badge good">✓</span> ' + esc(x.suggest) +
          '<div class="small muted">' + esc(x.cn) + '</div></li>';
      }).join('') + '</ul></div>';
    $('#wrBack').onclick = renderWrList;
  }

  function openWr(id) {
    var t = wrTopics().filter(function (x) { return x.id === id; })[0];
    if (!t) return;
    wrState = { topic: t };
    pgGo('#wrTabs', 'run');
    var range = t.level === 'cet6' ? '150-200' : '120-180';   // 四级 120-180 / 六级 150-200，只作写作提示
    $('#wrRun').innerHTML =
      '<div class="spread" style="margin-bottom:14px">' +
        '<div><h2 style="margin:0 0 4px;font-size:20px">' + esc(t.title) + '</h2>' +
        '<div class="small muted">' + esc(t.topic) + ' · 要求 ' + range + ' 词 <span class="badge ' + t.level + '">' + String(t.level).toUpperCase() + '</span></div></div>' +
        '<button class="btn" id="wrBack2">← 返回话题</button></div>' +
      '<div class="card"><div class="card-title">题目</div><div>' + esc(t.prompt) + '</div>' +
        '<div class="wd-block"><h4>提纲</h4><ul>' + (t.outline || []).map(function (o) { return '<li>' + esc(o) + '</li>'; }).join('') + '</ul></div>' +
      '</div>' +
      '<div class="card" style="margin-top:14px"><div class="card-title">我的作文</div>' +
        '<textarea class="input" id="wrInput" rows="12" placeholder="按提纲写 ' + range + ' 词，写完点「提交」直接对范文。"></textarea>' +
        '<div class="row" style="margin-top:12px">' +
          '<button class="btn primary" id="wrCheck">提交，看范文</button>' +
          '<span class="flow-note" id="wrLive"></span>' +
        '</div>' +
        '<div id="wrFeedback"></div>' +
      '</div>';
    $('#wrBack2').onclick = renderWrList;
    var input = $('#wrInput');
    input.oninput = function () {
      $('#wrLive').textContent = '当前 ' + wcCount(input.value) + ' 词 · ' + splitParas(input.value).length + ' 段';
    };
    // 2026-09-25 昀晞：作文不做检测 —— 离线判不了语义，给个「体检报告」反而误导。
    // 提交＝把范文、亮点表达、同义升级摆出来，自己对照；没写也能点（当参考资料看）。
    $('#wrCheck').onclick = function () {
      $('#wrFeedback').innerHTML = writingAnswer(t);
      countStudy();
    };
  }

  /* 2026-09-25 昀晞：本地作文体检整块删除（「离线检测作文这个软件做不到」）。
     原来那套「内容完整性 / 结构逻辑 / 语言准确性 / 语言丰富度」四项评分，本质是词表命中 + 拼写表匹配，
     给出的百分比会让人以为被评过 —— 现在只给范文与表达，由自己对照。
     如果将来要判分，应走真正的模型/服务，不要再捡回这套本地规则。 */

  function writingAnswer(t) {
    return '<div class="sep"></div>' +
      '<div class="card-title">范文与亮点表达</div>' +
      '<div class="passage" style="background:var(--panel-2);padding:12px;border-radius:10px">' + esc(t.sample || '') + '</div>' +
      '<div class="wd-block"><h4>亮点表达</h4><ul>' +
      (t.expressions || []).map(function (e) { return '<li><b>' + esc(e.en) + '</b> —— ' + esc(e.cn) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="wd-block"><h4>同义升级</h4><ul>' +
      (t.upgrades || []).map(function (u) { return '<li>' + esc(u.from) + ' → <b>' + esc(u.to) + '</b>（' + esc(u.cn) + '）</li>'; }).join('') + '</ul></div>';
  }

  /* ==========================================================
     专注模式：把训练关进一个计时笼子里
     ========================================================== */
  var FOCUS_TASKS = {
    'quiz-cn2en': { name: '默写 · 打字填写', view: 'quiz', setup: function () { $('#quizDir').value = 'cn2en'; } },
    'quiz-en2cn': { name: '认词 · 四选一', view: 'quiz', setup: function () { $('#quizDir').value = 'en2cn'; } },
    'quiz-listen': { name: '听写 · 听音拼写', view: 'quiz', setup: function () { $('#quizDir').value = 'listen'; } },
    'grammar': { name: '语法专项', view: 'grammar' },
    'real': { name: '真题训练', view: 'real' },
    'translate': { name: '翻译训练', view: 'translate' },
    'write': { name: '写作训练', view: 'write' }
  };
  // 自检 B：一次脏数据（非数组 / 元素不是对象）会让首页与专注页整屏白且无法自愈 —— 读取即净化
  var focusLog = (function () {
    var v = load('wudu.focus.v1', []);
    if (!Array.isArray(v)) return [];
    return v.filter(function (x) { return x && typeof x === 'object' && typeof x.minutes === 'number'; });
  })();
  var focusLast = '';   // 最近一次专注的结算卡（只保留一次，避免叠加把页面撑长）
  var focusState = { on: false, task: 'quiz-cn2en', total: 1500, left: 1500, timer: null, paused: false, base: null };

  function focusTodayMinutes() {
    var d = todayStr();
    return focusLog.filter(function (x) { return x.date === d; })
      .reduce(function (a, x) { return a + x.minutes; }, 0);
  }
  function focusStreak() {
    var days = {}, n = 0, d = todayStr();
    focusLog.forEach(function (x) { days[x.date] = 1; });
    if (!days[d]) d = addDays(d, -1);
    while (days[d]) { n++; d = addDays(d, -1); }
    return n;
  }

  function focusGoStep(n) {
    if (n === 2) {
      var t = FOCUS_TASKS[focusState.task] || FOCUS_TASKS['quiz-cn2en'];
      var el = $('#focusPicked');
      if (el) el.innerHTML = '已选：<b>' + esc(t.name) + '</b>';
      wizPush('focus', 'time');
    } else {
      wizReset('focus');
    }
  }

  /* 错题本：错过的词（wrong > 0 且未掌握），按错次排序 */
  function wrongWords() {
    return WORDS.filter(function (w) {
      var r = progress[w.w];
      return r && r.wrong > 0 && r.s < MASTER_STAGE;
    }).sort(function (a, b) { return (progress[b.w].wrong || 0) - (progress[a.w].wrong || 0); });
  }

  /* ---------------- 错题本：三页（总览 → 分类列表 → 词条详情） ----------------
     分类依据是「答错那一刻发生了什么」：拼错 / 想不起 / 认错释义 / 反复错。
     列表页自带检索与排序，词条页复用词典详情并补上这个人的错误记录。 */
  var wrongKind = 'all', wrongSort = 'wrong', wrongKw = '';

  function errCount(r, k) { return (r && r.errs && r.errs[k]) || 0; }
  function errTotal() {
    var n = 0;
    Object.keys(progress).forEach(function (k) {
      var r = progress[k];
      if (!r.wrong || r.s >= MASTER_STAGE) return;
      if (r.errs) Object.keys(r.errs).forEach(function (e) { n += r.errs[e]; });
      else n += r.wrong;
    });
    return n;
  }
  function wrongWordsOf(kind) {
    var ws = wrongWords();
    if (kind === 'hot') return ws.filter(function (w) { return (progress[w.w].wrong || 0) >= 2; });
    if (kind && kind !== 'all') return ws.filter(function (w) { return errCount(progress[w.w], kind) > 0; });
    return ws;
  }
  function kindMeta(k) {
    for (var i = 0; i < ERR_KINDS.length; i++) if (ERR_KINDS[i].k === k) return ERR_KINDS[i];
    return { k: 'all', icon: '📚', name: '全部错题', hint: '不分错因，一次看全 —— 可搜可排' };
  }
  function startPractice(pool, label) {
    if (!pool.length) { toast('这里暂时没有可练的词'); return; }
    startQuiz({ words: pool, dir: 'mix', count: pool.length });
    go('quiz');
    toast(label + ' · ' + pool.length + ' 个词');
  }

  // 第 1 页：总览
  function renderWrong() {
    var ws = wrongWords();
    var due = ws.filter(function (w) { return progress[w.w].due <= todayStr(); });
    var hot = ws.filter(function (w) { return (progress[w.w].wrong || 0) >= 2; });
    // 空态引导（昀晞 2026-09-25「按钮点了没反应像占位符」）：错词本为空时，
    // 页面上每个操作都该有明确反馈 —— 顶部给一条能直接点走的横幅，其余按钮置灰。
    var empty = ws.length === 0;
    var banner = document.getElementById('wrongEmpty');
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'wrongEmpty';
      var hostB = document.getElementById('wrongStats');
      if (hostB && hostB.parentNode) hostB.parentNode.insertBefore(banner, hostB);
    }
    if (banner) {
      if (empty) {
        banner.style.display = '';
        banner.innerHTML = '📭 错词本还是空的 —— 去默写或语法里答几道题，<b>答错的词会自动进来</b>。' +
          '<button class="btn sm primary" id="wrongEmptyGo" style="margin-left:8px">去默写</button>';
        var gb = document.getElementById('wrongEmptyGo');
        if (gb) gb.onclick = function () { go('quiz'); };
      } else {
        banner.style.display = 'none';
        banner.innerHTML = '';
      }
    }
    if ($('#wrongStats')) {
      $('#wrongStats').innerHTML =
        statCard(ws.length, '错词总数') +
        statCard(due.length, '今天该复习') +
        statCard(hot.length, '反复错') +
        statCard(errTotal(), '累计错次');
    }
    // 空态直接瘦身：既然没有错词，「今天该复习」卡与「移出错题本」按钮都没有意义，
    // 隐掉它们，让空态页一屏放得下（呼应昀晞「无意义部分删掉」的一贯要求）
    var step1 = document.getElementById('wrongStep1');
    if (step1) step1.classList.toggle('wbx-empty', empty);
    if ($('#wrongDue')) {
      $('#wrongDue').innerHTML = '<div class="card"><div class="spread" style="align-items:baseline">' +
        '<div><div class="card-title" style="margin:0">今天该复习的错题</div>' +
        '<div class="big">' + due.length + ' <span class="small muted">个</span></div></div>' +
        '<button class="btn primary sm" id="wrongDueGo"' + (due.length ? '' : ' disabled') + '>' +
        (due.length ? '开始复习' : '今天没有') + '</button></div>' +
        '<div class="flow-note">按记忆曲线，到点的错词排最前 —— 先清它们最划算。</div></div>';
      var g = $('#wrongDueGo');
      if (g) g.onclick = function () {
        if (!due.length) { toast('今天没有到期的错词 —— 明天再来'); return; }
        startPractice(due.slice(0, 30), '今日错题');
      };
    }
    // 搜索框：空库时置灰并说明，避免「点了没反应」
    var qi = $('#wrongQ'), qb = $('#wrongQBtn');
    if (qi && qb) {
      qi.disabled = empty;
      qb.disabled = empty;
      qi.placeholder = empty ? '错词本还是空的 —— 先去答题' : '搜错题 · 单词或中文都行';
    }
    if ($('#wrongKinds')) {
      $('#wrongKinds').innerHTML = ERR_KINDS.map(function (e) {
        var n = wrongWordsOf(e.k).length;
        return '<div class="wbx-kind' + (n ? '' : ' zero') + '" data-wk="' + e.k + '">' +
          '<div class="ki">' + e.icon + '</div>' +
          '<div class="km"><div class="kn">' + e.name + '</div><div class="kh">' + e.hint + '</div></div>' +
          '<div class="knum">' + n + '</div><div class="kgo">›</div></div>';
      }).join('') +
      '<div class="wbx-kind" data-wk="all"><div class="ki">📚</div>' +
        '<div class="km"><div class="kn">全部错题</div><div class="kh">不分错因一次看全（可搜可排序）</div></div>' +
        '<div class="knum">' + ws.length + '</div><div class="kgo">›</div></div>';
    }
    var wcBtn = $('#wrongClear');
    if (wcBtn) wcBtn.disabled = empty;
    // P2-4：打印单按钮在第一页（总览）上，绑定必须放这里 —— 放 renderWrongList 里要先进分类页才生效
    var prBtn = $('#wrongPrint');
    if (prBtn) {
      prBtn.disabled = empty;
      prBtn.onclick = function () { printWrongSheet(null); };
    }
    // 说明只在「有搜索词」时出现 —— 平时不占版面（错题本要能一屏放下）
    var note = $('#wrongQNote');
    if (note) {
      if (wrongKw) { note.style.display = ''; note.textContent = '当前搜索「' + wrongKw + '」· 点分类进列表看结果'; }
      else { note.style.display = 'none'; note.textContent = ''; }
    }
  }

  // 第 2 页：某一类的列表
  function wrongOpenList(kind, kw) {
    wrongKind = kind || 'all';
    if (typeof kw === 'string') wrongKw = kw.trim();
    renderWrongList();
    wizPush('wrong', 'list');
  }
  function renderWrongList() {
    var meta = kindMeta(wrongKind);
    var all = wrongWordsOf(wrongKind);
    var list;
    if (wrongKw) {
      list = all.map(function (w) { return { w: w, sc: dictScore(w, wrongKw) }; })
        .filter(function (x) { return x.sc > 0; })
        .sort(function (a, b) { return b.sc - a.sc; })
        .map(function (x) { return x.w; });
    } else {
      list = all.slice();
      if (wrongSort === 'recent') list.sort(function (a, b) {
        return String(progress[b.w].lastErrDate || '').localeCompare(String(progress[a.w].lastErrDate || ''));
      });
      else if (wrongSort === 'az') list.sort(function (a, b) { return a.w < b.w ? -1 : 1; });
      else list.sort(function (a, b) { return (progress[b.w].wrong || 0) - (progress[a.w].wrong || 0); });
    }
    if ($('#wrongKindTitle')) $('#wrongKindTitle').textContent = meta.name;
    if ($('#wrongKindHint')) $('#wrongKindHint').textContent =
      wrongKw ? ('在「' + meta.name + '」里搜「' + wrongKw + '」，按相关度排') : meta.hint;
    if ($('#wrongKindCount')) $('#wrongKindCount').textContent = list.length + ' 个';
    var si = $('#wrongQ2');
    if (si && si.value !== wrongKw) si.value = wrongKw;
    if ($('#wrongSort')) {
      $('#wrongSort').innerHTML = [['wrong', '错得最多'], ['recent', '最近错的'], ['az', '字母序']].map(function (s) {
        return '<button class="chip' + (wrongSort === s[0] ? ' on' : '') + '" data-ws="' + s[0] + '">' + s[1] + '</button>';
      }).join('') + (wrongKw ? '<span class="tag small muted">搜索中 · 已按相关度排</span>' : '');
    }
    if ($('#wrongList')) {
      $('#wrongList').innerHTML = list.length ? list.map(function (w) {
        var r = progress[w.w];
        var chips = ERR_KINDS.filter(function (e) { return e.k !== 'hot'; })
          .filter(function (e) { return errCount(r, e.k) > 0; })
          .map(function (e) { return '<span class="wbx-chip">' + e.icon + ' ' + e.name + ' ' + errCount(r, e.k) + '</span>'; })
          .join('');
        return '<div class="wbx-row" data-w="' + esc(w.w) + '">' +
          '<div class="top"><span class="w">' + hi(w.w, wrongKw) + '</span>' +
          '<span class="badge ' + lvlCls(w.level) + '">' + lvlTag(w.level) + '</span>' +
          '<span class="badge bad">✗' + (r.wrong || 0) + '</span>' +
          '<span class="c">' + hi(w.cn, wrongKw) + '</span></div>' +
          '<div class="wbx-log">' + chips +
          '<span class="wbx-chip">阶段 ' + r.s + '/' + (INTERVALS.length - 1) + '</span>' +
          '<span class="wbx-chip">下次 ' + r.due + '</span></div></div>';
      }).join('') : '<div class="empty">' + (wrongKw ? '这一类里没搜到「' + esc(wrongKw) + '」。' : '这一类还是干净的 —— 换个分类看看，或去做几道题。') + '</div>';
    }
    var pb = $('#wrongPractice');
    if (pb) {
      pb.textContent = list.length ? ('开始复习这一类 · ' + Math.min(30, list.length) + ' 个') : '这一类暂时没有错词';
      pb.disabled = !list.length;
    }
    // P2-4：把当前这一类（或全部）排成可打印的手写单
    var pr = $('#wrongPrint');
    if (pr) pr.onclick = function () { printWrongSheet(wrongKind === 'all' ? null : wrongKind); };
  }

  // 第 3 页：单个错词
  function wrongOpenWord(word) {
    if (!BY_WORD[word]) return;
    renderWordDetail(word, '#wrongDetail', true);
    wizPush('wrong', 'detail');
  }


  function renderFocus() {
    var all = focusLog.reduce(function (a, x) { return a + x.minutes; }, 0);
    var todayMin = focusTodayMinutes();
    var goal = settings.focusGoal || 50;
    var pct = Math.min(100, Math.round(todayMin / goal * 100));
    $('#focusStats').innerHTML = (focusLast || '') +
      '<details class="fold" style="margin-top:12px"><summary>统计与今日目标</summary>' +
      '<div class="grid c4" style="margin-top:2px;padding-bottom:10px">' +
      statCard(todayMin + '′', '今日专注') +
      statCard(all + '′', '累计专注') +
      statCard(focusLog.length, '专注次数') +
      statCard(focusStreak(), '连续天数') +
      '</div>' +
      '<div style="padding:0 0 12px"><div class="spread">' +
        '<span class="small muted">今日目标 ' + todayMin + '′ / ' + goal + '′</span>' +
        '<span class="badge ' + (pct >= 100 ? 'good' : '') + '">' + pct + '%' +
        (pct >= 100 ? ' · 已达标 🎉' : '') + '</span></div>' +
        '<div class="bar" style="margin-top:8px"><i style="width:' + pct + '%"></i></div>' +
      '</div>' +
      '</details>';
    var recent = focusLog.slice(-12).reverse();
    $('#focusHistory').innerHTML = '<div class="card" style="margin-top:12px"><div class="card-title">专注记录 <span class="tag small muted">最近 ' + recent.length + ' 条</span></div>' +
      (recent.length ? '<div style="overflow:auto"><table class="day-table"><thead><tr>' +
        '<th>时间</th><th>内容</th><th>时长 / 答题</th><th>结果</th></tr></thead><tbody>' +
        recent.map(function (x) {
          return '<tr><td>' + x.date + '</td><td>' + esc(x.taskName) + '</td>' +
            '<td>' + x.minutes + '′ · ' + x.answered + ' 题' + (x.rate === null ? '' : ' · ' + x.rate + '%') + '</td>' +
            '<td>' + (x.completed ? '✅ 跑完' : '⏹ 提前结束') + '</td></tr>';
        }).join('') + '</tbody></table></div>'
        : '<div class="muted small">还没有专注记录 —— 上面选一个任务，按下「开始专注」。</div>') +
      '</div>';
  }

  function logSession(f, finished) {
    var used = Math.max(0, Math.round((f.total - f.left) / 60));
    var s2 = stats[todayStr()] || {};
    var answered = (s2.answered || 0) - f.base.a;
    var right = (s2.right || 0) - f.base.r;
    var nw = (s2.newWords || 0) - f.base.n;
    var rec = {
      date: todayStr(), task: f.task, taskName: FOCUS_TASKS[f.task].name,
      minutes: used, answered: answered, right: right,
      rate: answered > 0 ? Math.round(right / answered * 100) : null,
      newWords: nw, completed: !!finished, phase: f.phase
    };
    focusLog.push(rec);
    save('wudu.focus.v1', focusLog);
    // 重设基线，避免下一段把同一批答题重复计入
    f.base = { a: s2.answered || 0, r: s2.right || 0, n: s2.newWords || 0 };
    return rec;
  }

  function startFocus() {
    if (focusState.on) { toast('专注已经开始了'); return; }
    var task = focusState.task || 'quiz-cn2en';
    var t = FOCUS_TASKS[task];
    var min = parseInt($('#focusMinutes').value, 10) || 25;
    var hide = $('#focusHide').value === '1';
    var brk = parseInt($('#focusBreak').value, 10) || 0;
    var full = $('#focusFull').value === '1';
    settings.focusGoal = parseInt($('#focusGoal').value, 10) || 50;
    saveAll();
    var s0 = stats[todayStr()] || {};
    focusState = {
      on: true, task: task, phase: 'work', workMin: min, breakMin: brk, pomodoro: brk > 0,
      total: min * 60, left: min * 60, timer: null, paused: false, hide: hide,
      base: { a: s0.answered || 0, r: s0.right || 0, n: s0.newWords || 0 }
    };
    document.body.classList.add('focusing');
    document.body.classList.toggle('hide-side', hide);
    $('#focusBar').classList.remove('rest');
    $('#fbPause').textContent = '暂停';
    updateFocusBar();
    focusState.timer = setInterval(focusTick, 1000);
    if (t.view === 'quiz') {
      // 第 3 步：直接进「单词界面」答题，不再停在设置页
      startQuiz({
        level: settings.level,
        scope: 'due',
        dir: task === 'quiz-en2cn' ? 'en2cn' : 'cn2en',
        count: 20
      });
      go('quiz');
    } else {
      go(t.view);
      if (t.setup) t.setup();
    }
    if (full) {
      try {
        var el = document.documentElement;
        var fn = el.requestFullscreen || el.webkitRequestFullscreen;
        if (fn) { var p = fn.call(el); if (p && p.catch) p.catch(function () {}); }
      } catch (e) {}
    }
    toast('专注开始 · ' + min + ' 分钟 · ' + t.name + (brk ? '（番茄钟：休息 ' + brk + ' 分钟）' : ''));
  }

  function buzz(pattern) {
    if (!buzzOn) return;
    try { if (navigator.vibrate) navigator.vibrate(pattern); } catch (e) {}
    // WebView 里 navigator.vibrate 常常无声无息 —— 原生外壳用真触感反馈
    if (window.WUDU_NATIVE && window.WUDU_NATIVE.isNative) {
      window.WUDU_NATIVE.haptic((pattern && pattern.length > 1) ? 'no' : 'tap');
    }
  }

  // 自检 G3：休息遮罩（body.on-break）必须与 phase 严格一致 —— 任何路径漏加/漏删都会出现「计时条在动、锁屏没了」
  function syncBreakMask() {
    var f = focusState;
    var should = !!(f && f.on && f.phase === 'break');
    document.body.classList.toggle('on-break', should);
    if (!should && $('#breakMask')) { try { document.body.classList.remove('on-break'); } catch (e) {} }
  }

  function focusTick() {
    var f = focusState;
    if (!f.on || f.paused) { syncBreakMask(); return; }
    f.left--;
    syncBreakMask();
    if (f.left > 0) {
      updateFocusBar();
      if (f.phase === 'break' && f.left === 10) toast('休息还剩 10 秒');
      return;
    }
    if (f.phase === 'work') {
      logSession(f, true);
      if (f.pomodoro) {
        f.phase = 'break';
        f.total = f.breakMin * 60;
        f.left = f.total;
        $('#focusBar').classList.add('rest');
        document.body.classList.add('on-break');   // 硬一点：休息锁屏
        updateFocusBar();
        buzz([320, 120, 320]);
        toast('这一段完成 · 休息 ' + f.breakMin + ' 分钟（训练区已锁）');
        return;
      }
      f.left = 0;
      updateFocusBar();
      endFocus(true);
      return;
    }
    // 休息结束，自动开下一段
    skipBreak(true);
  }

  // 结束休息（natural=true 表示自然到点）
  function skipBreak(natural) {
    var f = focusState;
    if (!f.on || f.phase !== 'break') return;
    // 自检 G1：休息段原来完全不记账，于是「休息 5 分钟」在专注记录里凭空消失；
    // 这里补一条 phase='break' 的记录（completed 按是否自然到点），并重设基线
    try {
      if ((f.total - f.left) >= 30) logSession(f, !!natural);
    } catch (e) {}
    f.phase = 'work';
    f.total = f.workMin * 60;
    f.left = f.total;
    document.body.classList.remove('on-break');
    $('#focusBar').classList.remove('rest');
    updateFocusBar();
    if (!natural) buzz([120]);
    toast(natural ? '休息结束 · 自动进入下一段' : '跳过休息 · 继续专注');
  }

  function updateFocusBar() {
    var f = focusState;
    $('#fbTime').textContent = Math.floor(f.left / 60) + ':' + String(f.left % 60).padStart(2, '0');
    $('#fbTask').textContent = (f.phase === 'break' ? '☕ 休息中 · ' : '') + FOCUS_TASKS[f.task].name;
    if (f.phase === 'break') {
      var bt = $('#breakTime');
      if (bt) bt.textContent = Math.floor(f.left / 60) + ':' + String(f.left % 60).padStart(2, '0');
      var be = document.querySelector('.break-emoji');
      if (be) be.textContent = f.left <= 10 ? '⏳' : '☕';
    }
    var s2 = stats[todayStr()] || {};
    var done = (s2.answered || 0) - f.base.a;
    $('#fbCount').textContent =
      (done > 0 ? '本段已答 ' + done + ' 题 · ' : '') +
      '今日 ' + focusTodayMinutes() + '′ / 目标 ' + (settings.focusGoal || 50) + '′';
  }

  /* ---------------- 专注强硬模式 ----------------
     开了强硬模式后，专注进行中不能直接退出：先学完 3 个生词，才会给一串退出密码。
     想偷懒就得先真的记点东西 —— 这是拿「离开的成本」换专注。 */
  var hardState = null;
  function hardUnlocked() {
    try { return sessionStorage.getItem('wudu.hard.ok') === '1'; } catch (e) { return false; }
  }
  function pickHardWords(n) {
    var pool = WORDS.filter(function (w) {
      var r = progress[w.w];
      return r && r.wrong > 0 && r.s < MASTER_STAGE;
    });
    if (pool.length < n) pool = WORDS.filter(function (w) {
      var r = progress[w.w];
      return !r || r.s < MASTER_STAGE;
    });
    if (pool.length < n) pool = WORDS.slice();
    return shuffle(pool).slice(0, n);
  }
  function openHardGate() {
    // 自检 B2：词库为空时 pickHardWords 返回空数组 → 弹层里什么都没有，用户被卡死
    if (!WORDS.length) { toast('词库还没加载好，稍后再试'); return; }
    if ($('#hardMask')) return;
    hardState = {
      words: pickHardWords(3), i: 0,
      pass: String(Math.floor(1000 + Math.random() * 9000))
    };
    document.body.appendChild(el(
      '<div class="hard-mask" id="hardMask"><div class="hard-card">' +
        '<div class="hard-head"><b>🔒 强硬模式</b>' +
        '<span class="small muted">学完这 3 个生词，才给退出密码 —— 这段专注才不白开。</span></div>' +
        '<div id="hardBody"></div>' +
      '</div></div>'));
    renderHardTask();
    buzz([40]);
  }
  function renderHardTask() {
    var st = hardState, body = $('#hardBody');
    if (!st || !body) return;
    if (!st.words || !st.words.length || !st.words[st.i]) {
      body.innerHTML = '<div class="empty">题目数据缺失 —— 返回后重新进入专注</div>';
      return;
    }
    var w = st.words[st.i];
    body.innerHTML =
      '<div class="row small muted" style="justify-content:space-between;margin-top:10px">' +
        '<span>第 ' + (st.i + 1) + ' / ' + st.words.length + ' 个</span>' +
        '<span>' + esc(w.pos || '') + ' · ' + w.w.length + ' 个字母</span></div>' +
      '<div class="hard-cn">' + esc(w.cn) + '</div>' +
      ((w.ex && w.ex[0]) ? '<div class="small muted" style="text-align:center">' + esc(w.ex[0].en) + '</div>' : '') +
      '<div class="spell-wrap" id="hardWrap">' +
        // 同默写：输入层要放进 .spell-wrap 里，否则 absolute 会相对外层容器铺开（可点区失控）
        '<input class="spell-input" id="hardInput" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false">' +
      '</div>' +
      '<div class="row" style="justify-content:center;margin-top:8px">' +
        '<button class="btn primary" id="hardSubmit">对一下</button>' +
        '<button class="btn ghost sm" id="hardAudio">🔊 听发音</button></div>' +
      '<div class="small muted" id="hardTip" style="text-align:center;margin-top:8px">写在横线上，写对才算过</div>';
    var inp = $('#hardInput');
    inp.value = '';
    // 一条输入线（2026-09-25 昀晞：横线彻底删掉）：光标与逐位修改交给系统原生行为，
    // 不再自己算「离手指最近的是哪一格」——字母槽已经不存在了。
    $('#hardWrap').onclick = function () { inp.focus(); };
    $('#hardAudio').onclick = function () { speak(w.w); };
    $('#hardSubmit').onclick = checkHard;
    inp.onkeydown = function (e) { if (e.key === 'Enter') { e.stopPropagation(); checkHard(); } };
    setTimeout(function () { try { inp.focus(); } catch (e2) {} }, 120);
  }
  function checkHard() {
    var st = hardState;
    if (!st) return;
    var w = st.words[st.i];
    var inp = $('#hardInput');
    var val = inp ? inp.value.trim() : '';
    if (!val) { toast('先写出来再说'); return; }
    var jd = judge(val, w.w);
    recordAnswer(w.w, jd.ok, jd.ok ? null : 'spell');
    markNew(w.w);
    if (!jd.ok) {
      $('#hardTip').innerHTML = '差一点 —— 正确写法 <b>' + esc(w.w) + '</b>，再写一遍';
      inp.value = '';
      buzz([70, 45, 70]);
      setTimeout(function () { try { inp.focus(); } catch (e2) {} }, 60);
      return;
    }
    buzz([35]);
    if (st.i + 1 >= st.words.length) { hardFinished(); return; }
    st.i++;
    renderHardTask();
  }
  function hardFinished() {
    var st = hardState;
    $('#hardBody').innerHTML =
      '<div class="hard-pass">这三个词都过了一遍 · 退出密码</div>' +
      '<div class="hard-pass-num">' + st.pass + '</div>' +
      '<div class="row" style="justify-content:center;gap:8px;margin-top:6px">' +
        '<input class="input" id="hardPassIn" maxlength="6" inputmode="numeric" placeholder="输入密码" ' +
        'style="max-width:150px;text-align:center;letter-spacing:3px">' +
        '<button class="btn primary" id="hardPassOk">解锁退出</button></div>' +
      '<div class="row" style="justify-content:center;margin-top:10px">' +
        '<button class="btn ghost sm" id="hardStay">不了，继续学下去</button></div>';
    $('#hardPassOk').onclick = function () {
      var v = ($('#hardPassIn') || {}).value || '';
      if (v.trim() !== st.pass) { toast('密码不对，再看一眼'); buzz([70, 45, 70]); return; }
      try { sessionStorage.setItem('wudu.hard.ok', '1'); } catch (e) {}
      closeHardGate();
      toast('已解锁 · 这段专注可以结束了');
    };
    $('#hardStay').onclick = function () { closeHardGate(); updateFocusBar(); };
  }
  function closeHardGate() {
    var m = $('#hardMask');
    if (m && m.parentNode) m.parentNode.removeChild(m);
    hardState = null;
  }

  function endFocus(finished) {
    var f = focusState;
    if (!f.on) return;
    // 强硬模式：想「提前」跑，先过「学 3 个生词」这一关（正常跑完的放行）
    if (settings.focusHard && !hardUnlocked() && !finished) { openHardGate(); return; }
    clearInterval(f.timer);
    var rec = null;
    if ((f.total - f.left) >= 30) rec = logSession(f, !!finished && f.phase === 'work');
    f.on = false;
    document.body.classList.remove('focusing', 'hide-side', 'on-break');
    $('#focusBar').classList.remove('rest');
    try { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen(); } catch (e) {}
    var todayMin = focusTodayMinutes();
    var goal = settings.focusGoal || 50;
    var overGoal = todayMin >= goal;
    // 结算卡只保留最近一次（旧版是 insertAdjacentHTML 追加，连跑几段会越叠越长）
    focusLast =
      '<div class="card" style="margin-top:12px"><div class="focus-done">' +
        '<div class="small muted">' + (finished ? '⏱ 这段专注跑完了' : '⏹ 提前结束') + ' · ' + esc(FOCUS_TASKS[f.task].name) +
        (f.phase === 'break' ? '（休息阶段结束）' : '') + ' · ' + (rec ? rec.minutes : 0) + '′</div>' +
        '<div class="grid c3" style="margin-top:10px">' +
          statCard(rec ? rec.answered : 0, '本段答题') +
          statCard(rec && rec.rate !== null ? rec.rate + '%' : '—', '正确率') +
          statCard(rec ? rec.newWords : 0, '新学单词') +
        '</div>' +
        '<div class="flow-note" style="margin-top:10px">' +
          (overGoal ? '今天的专注目标已经达成了 🎉 剩下的时间可以轻松点。'
            : (!rec ? '这段太短了，没记进账 —— 至少专注 30 秒才计数哦。'
              : '距离今日目标还差 ' + (goal - todayMin) + ' 分钟。')) +
        '</div>' +
      '</div></div>';
    // P2-3：结算时顺手报一句今日任务的完成度，让「专注」和「今天该做的事」连上
    var t2 = (stats[todayStr()] && stats[todayStr()].answered) || 0;
    var focusGoalNow = settings.focusGoal || 50;
    var head = finished ? '专注完成，休息一下' : '这段专注已记录';
    toast(head + ' · 今日专注 ' + todayMin + '′ / ' + focusGoalNow + '′' + (todayMin >= focusGoalNow ? ' ✅' : ''));
    go('focus');
    renderHome();   // 首页今日任务跟着刷新（无缝，不切页）
  }

  /* ==========================================================
     听力训练：TTS 朗读 + 理解题（纯离线，无需音频文件）
     ========================================================== */
  var LBANK = window.LISTENING_BANK || [];
  var lsFilter = { level: 'all' };
  var lsState = null;

  function renderLsList() {
    var run = $('#lsRun'), list = $('#lsList');
    if (run) run.style.display = 'none';
    if (list) list.style.display = 'block';
    if (!LBANK.length) {
      $('#lsFilter').innerHTML = '';
      $('#lsList').innerHTML = '<div class="card empty">听力材料还没到位（<code>assets/js/data/listening.js</code> 尚未加载）。<br>' +
        '<span class="small">朗读本身已经能用 —— 词典、默写、例句旁边的 🔊 都可以点。</span></div>';
      return;
    }
    $('#lsFilter').innerHTML = [['all', '全部'], ['cet4', 'CET-4'], ['cet6', 'CET-6']].map(function (l) {
      return '<button class="chip' + (lsFilter.level === l[0] ? ' on' : '') + '" data-ll="' + l[0] + '">' + l[1] + '</button>';
    }).join('');
    var arr = LBANK.filter(function (p) { return lsFilter.level === 'all' || p.level === lsFilter.level; });
    var types = arr.map(function (p) { return p.type; }).filter(function (t, i, a) { return a.indexOf(t) === i; });
    $('#lsList').innerHTML =
      '<div class="card" style="margin-bottom:14px"><div class="split-row">' +
        '<span class="small muted">共 <b>' + arr.length + '</b> 套材料 · ' + types.join(' / ') +
        ' · 朗读由系统语音合成，不是考场原音</span></div></div>' +
      arr.map(function (p) {
        return '<div class="paper-item" data-ls="' + esc(p.id) + '">' +
          '<div><div style="font-weight:600">' + esc(p.title) + '</div>' +
          '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.type) + ' · ' +
          (p.script || []).length + ' 段 / ' + (p.questions || []).length + ' 题</div></div>' +
          '<div class="row">' + (p.verified === true ? '<span class="badge good">真题</span>' : '<span class="badge">仿真</span>') +
          '<span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span>' +
          '<button class="btn sm primary">去听</button></div></div>';
      }).join('');
  }

  /* ==========================================================
     听力（三段式）：听材料 → 答题 → 原文
     2026-09-25 重构。昀晞反馈：「原文应该放在答题后，而且播放键离题目太远了，
     做成多页的方式，参照市面成熟方案」。
     改前的问题（同一个根因）：单页从上到下堆 4 块 ——
       ① 标题 ② ▶播放全文 ③【听力原文】④【理解题】
       → 原文排在题目之前 = 答题前就能看到答案；播放键到题目隔着一整篇原文。
     现在：页1 只听不放原文 / 页2 每题一页且顶部常驻迷你播放条 / 页3 原文答完才解锁。
     保留：lsPlay 单句重听 + localListen 离线音源（E10「手机朗读不支持」的解法，不能丢）。
     ========================================================== */
  function openLs(id) {
    var p = LBANK.filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    lsState = { p: p, aPage: 0, done: {}, scriptOpen: false };
    $('#lsList').style.display = 'none';
    $('#lsRun').style.display = 'block';

    /* ---- 页 1：听材料（不放原文） ---- */
    $('#lsHead').innerHTML =
      '<div class="spread" style="margin-bottom:12px">' +
        '<div><h2 style="margin:0 0 4px;font-size:20px">' + esc(p.title) + '</h2>' +
        '<div class="small muted">' + esc(p.year || '') + ' · ' + esc(p.type) +
        ' <span class="badge ' + p.level + '">' + String(p.level).toUpperCase() + '</span>' +
        ' · ' + (p.script || []).length + ' 段 / ' + (p.questions || []).length + ' 题</div></div>' +
        '<button class="btn" id="lsBack2">← 返回</button></div>';
    $('#lsPlayer').innerHTML =
      '<div class="card"><div class="card-title">先完整听一遍，再答题</div>' +
        '<div class="flow-note" style="margin-bottom:10px">原文在答完题后才解锁 —— 先靠耳朵抓信息，效果最好。</div>' +
        '<div class="row">' +
          '<button class="btn primary" id="lsPlay">▶ 播放全文</button>' +
          '<button class="btn" id="lsStop">⏹ 停止</button>' +
        '</div>' +
        '<div class="flow-note" style="margin-top:8px">' + lsSourceNote(p) + '</div>' +
        '<div class="row" style="margin-top:14px"><button class="btn primary" id="lsGoAnswer">开始答题 →</button></div>' +
      '</div>';

    /* ---- 页 3：原文（先渲好；未答完时显示解锁提示） ---- */
    renderLsScriptPane();
    /* ---- 页 2：答题（每题一页） ---- */
    renderLsAnswerPage();

    /* ---- 事件 ---- */
    var back = $('#lsBack2');
    if (back) back.onclick = function () { stopSpeak(); renderLsList(); };
    var stop = $('#lsStop');
    if (stop) stop.onclick = function () { stopSpeak(); toast('已停止朗读'); };
    var play = $('#lsPlay');
    if (play) play.onclick = function () { lsPlay(p, -1); };
    var go = $('#lsGoAnswer');
    if (go) go.onclick = function () { pgGo('#lsTabs', 'answer'); };

    pgGo('#lsTabs', 'listen');
  }

  /* 音源状态提示（离线本机音源 / 系统 TTS / 浏览器 TTS） */
  function lsSourceNote(p) {
    return localListen(p.id) ? '🎧 本机音源 · 离线可播'
      : (!tts.ok ? '⚠ 这个环境不支持朗读'
        : (!tts.enabled ? '朗读开关关着 · 去「设置」里打开'
          : (tts.native ? '系统语音引擎朗读 · 对话会换音色' : '浏览器语音合成朗读 · 对话会换音色')));
  }
  function lsAnsweredCount() {
    var n = 0;
    (lsState.p.questions || []).forEach(function (q, i) { if (lsState.done[i]) n++; });
    return n;
  }
  function lsAnsweredAll() {
    var qs = lsState.p.questions || [];
    return qs.length > 0 && qs.every(function (q, i) { return lsState.done[i]; });
  }

  /* 页 3：原文 —— 答完全部题才解锁；未答完给一个带二次确认的「仍要查看」 */
  function renderLsScriptPane() {
    var p = lsState.p;
    if (!lsAnsweredAll() && !lsState.scriptOpen) {
      var left = (p.questions || []).length - lsAnsweredCount();
      $('#lsScriptWrap').innerHTML =
        '<div class="card"><div class="card-title">原文还没解锁</div>' +
        '<div class="flow-note">还剩 <b>' + left + '</b> 题没答 —— 答完自动解锁。' +
        '先靠耳朵做一遍，再对照原文，记忆留存更好。</div>' +
        '<div class="row" style="margin-top:12px">' +
          '<button class="btn primary" id="lsBackAnswer">← 回去答题</button>' +
          '<button class="btn ghost" id="lsForceScript">仍要查看原文</button>' +
        '</div></div>';
      var back = $('#lsBackAnswer');
      if (back) back.onclick = function () { pgGo('#lsTabs', 'answer'); };
      var force = $('#lsForceScript');
      if (force) force.onclick = function () { lsState.scriptOpen = true; renderLsScriptPane(); };
      return;
    }
    $('#lsScriptWrap').innerHTML =
      '<div class="card"><div class="card-title">听力原文 <span class="tag small muted">点任意一句可单独重听</span></div>' +
        '<div id="lsScript">' + (p.script || []).map(function (s, i) {
          return '<div class="ls-line" data-ls-line="' + i + '">' +
            (s.speaker && s.speaker !== 'N' ? '<span class="ls-spk">' + esc(s.speaker) + '</span> ' : '') +
            esc(s.text) + '</div>';
        }).join('') + '</div></div>' +
      ((p.keyWords || []).length ? '<div class="card" style="margin-top:14px"><div class="card-title">本篇词汇</div>' +
        '<div class="wd-block"><div class="chip-row">' +
          p.keyWords.map(function (k) {
            return '<span class="chip" data-say="' + esc(k.w) + '">' + esc(k.w) + ' · ' + esc(k.cn) + ' 🔊</span>';
          }).join('') + '</div></div></div>' : '');
    $$('#lsScript .ls-line').forEach(function (el) {
      el.onclick = function () { lsPlay(lsState.p, parseInt(el.dataset.lsLine, 10)); };
    });
  }

  /* 页 2：答题 —— 每题一页；顶部常驻迷你播放条（播放键就在题上，不用滚） */
  function renderLsAnswerPage() {
    var p = lsState.p;
    var qs = p.questions || [];
    if (!qs.length) {
      $('#lsAnswer').innerHTML = '<div class="card empty">这套材料没有理解题。</div>';
      return;
    }
    var qi = Math.max(0, Math.min(lsState.aPage, qs.length - 1));
    lsState.aPage = qi;
    var q = qs[qi];
    var isLast = (qi === qs.length - 1);
    $('#lsAnswer').innerHTML =
      '<div class="card" style="margin-bottom:12px"><div class="spread">' +
        '<button class="btn sm primary" id="lsMiniPlay">▶ 再听一遍</button>' +
        '<button class="btn sm" id="lsMiniStop">⏹ 停止</button>' +
        '<span class="flow-note">' + lsSourceNote(p) + '</span>' +
      '</div></div>' +
      '<div class="card">' +
        '<div class="spread" style="margin-bottom:10px">' +
          '<div class="card-title" style="margin:0">第 ' + (qi + 1) + ' / ' + qs.length + ' 题</div>' +
          '<span class="tag small muted" id="lsAnswerProg">已答 ' + lsAnsweredCount() + ' / ' + qs.length + '</span>' +
        '</div>' +
        '<div style="font-weight:600;margin-bottom:10px">' + esc(q.q) + '</div>' +
        '<div class="opt-grid">' + (q.options || []).map(function (o, oi) {
          return '<button class="opt" data-lq="' + qi + '" data-lo="' + oi + '">' +
            String.fromCharCode(65 + oi) + '. ' + esc(o) + '</button>';
        }).join('') + '</div>' +
        '<div id="lfb' + qi + '"></div>' +
        '<div class="row" style="margin-top:14px">' +
          '<button class="btn" id="lsPrevQ"' + (qi === 0 ? ' disabled' : '') + '>← 上一题</button>' +
          (isLast
            ? '<button class="btn primary" id="lsFinishQ">完成，看原文 →</button>'
            : '<button class="btn primary" id="lsNextQ">下一题 →</button>') +
        '</div>' +
      '</div>';

    var mini = $('#lsMiniPlay');
    if (mini) mini.onclick = function () { lsPlay(p, -1); };
    var mstop = $('#lsMiniStop');
    if (mstop) mstop.onclick = function () { stopSpeak(); toast('已停止朗读'); };
    var prev = $('#lsPrevQ');
    if (prev) prev.onclick = function () { lsState.aPage = Math.max(0, qi - 1); renderLsAnswerPage(); };
    var next = $('#lsNextQ');
    if (next) next.onclick = function () { lsState.aPage = Math.min(qs.length - 1, qi + 1); renderLsAnswerPage(); };
    var fin = $('#lsFinishQ');
    if (fin) fin.onclick = function () {
      if (!lsAnsweredAll()) {
        var left = qs.length - lsAnsweredCount();
        toast('还有 ' + left + ' 题没答 —— 答完再看原文更有效');
      }
      lsState.scriptOpen = lsAnsweredAll();
      renderLsScriptPane();
      pgGo('#lsTabs', 'script');
    };
    $$('#lsAnswer .opt').forEach(function (b) {
      b.onclick = function () {
        var oi = parseInt(b.dataset.lo, 10);
        $$('#lsAnswer .opt[data-lq="' + qi + '"]').forEach(function (x) { x.classList.remove('ok', 'no'); });
        var ok = oi === q.answer;
        b.classList.add(ok ? 'ok' : 'no');
        if (!ok) {
          var right = document.querySelector('#lsAnswer .opt[data-lq="' + qi + '"][data-lo="' + q.answer + '"]');
          if (right) right.classList.add('ok');
        }
        $('#lfb' + qi).innerHTML = '<div class="blank-explain ' + (ok ? 'ok' : 'no') + '">' +
          (ok ? '✓ 正确。' : '✗ 再听一遍。') + esc(q.explain || '') + '</div>';
        if (!lsState.done[qi]) { lsState.done[qi] = true; countStudy(); }
        var prog = $('#lsAnswerProg');
        if (prog) prog.textContent = '已答 ' + lsAnsweredCount() + ' / ' + qs.length;
        if (lsAnsweredAll()) toast('全部答完 · 原文已解锁');
      };
    });
  }

  function lsPlay(p, only) {
    // 单句重听：先用逐句音源（离线，手机上没装 TTS 引擎也有声）
    if (only >= 0) {
      var lline = localListenLine(p.id, only);
      if (lline) {
        stopSpeak();
        $$('#lsScript .ls-line').forEach(function (el) { el.classList.remove('playing'); });
        if ($('#lsScript')) {
          var one = $('#lsScript').querySelector('[data-ls-line="' + only + '"]');
          if (one) one.classList.add('playing');
        }
        playLocal(lline, {
          onEnd: function () { $$('#lsScript .ls-line').forEach(function (el) { el.classList.remove('playing'); }); }
        });
        return;
      }
    }
    // 整段播放：优先本机音源（离线、音色统一、不依赖系统 TTS）
    var localFull = (only < 0) ? localListen(p.id) : null;
    if (localFull) {
      stopSpeak();
      $$('#lsScript .ls-line').forEach(function (el) { el.classList.remove('playing'); });
      if ($('#lsScript')) {
        var f = $('#lsScript').querySelector('[data-ls-line="0"]');
        if (f) f.classList.add('playing');
      }
      playLocal(localFull, {
        onEnd: function () { $$('#lsScript .ls-line').forEach(function (el) { el.classList.remove('playing'); }); }
      });
      toast('本机音源播放 · 离线可用');
      return;
    }
    if (!tts.ok) { toast('这个环境不支持语音合成'); return; }
    var lines = (p.script || []).map(function (s, i) {
      return {
        text: s.text, lang: 'en-US',
        rate: s.speaker === 'W' ? 0.96 : (s.speaker === 'M' ? 0.9 : 0.94),
        pitch: s.speaker === 'W' ? 1.08 : (s.speaker === 'M' ? 0.9 : 1),
        gap: 380
      };
    });
    if (only >= 0 && lines[only]) lines = [lines[only]];
    $$('#lsScript .ls-line').forEach(function (el) { el.classList.remove('playing'); });
    if (only >= 0 && $('#lsScript')) {
      var cur = $('#lsScript').querySelector('[data-ls-line="' + only + '"]');
      if (cur) cur.classList.add('playing');
    }
    speakSeq(lines);
    if (only < 0) toast('开始朗读 · 共 ' + lines.length + ' 段');
  }

  /* ---------------- 计划 ---------------- */
  function renderPlan() {
    ensurePlan();
    pgGo('#planTabs', 'setup');
    $('#planLevel').value = settings.level;
    $('#planDate').value = settings.examDate;
    $('#planMinutes').value = settings.minutes;
    $('#planRest').value = settings.restDays;
    drawPlan(settings.plan);
  }
  function drawPlan(plan) {
    var left = Math.max(0, diffDays(todayStr(), plan.examDate));
    var nowName = plan.phases.filter(function (p) { return todayStr() >= p.from && todayStr() <= p.to; })[0];
    var rows = daySchedule(plan, Math.min(21, Math.max(7, left)));
    var dy = dynamicToday(plan.level, plan.minutes);
    var prof = dy.adapt || adaptProfile(), smp = prof.sample;

    var html = '' +
      '<div class="row" style="margin-top:12px"><button class="btn sm ghost" id="planEdit">← 改设置</button>' +
      '<span class="flow-note">要改级别 / 考试日 / 每日时间，点左边回到设置。</span></div>' +
      '<div class="grid c4" style="margin-top:12px">' +
      statCard(left, '距考试（天）') +
      statCard(plan.remain, '待覆盖新词') +
      statCard(plan.newPerDay, '计划每日新词') +
      statCard(plan.minutes, '每日预算（分钟）') +
      '</div>' +
      '<div class="card" style="margin-top:16px"><div class="card-title">今日动态额度 <span class="tag small muted">复习多了新词自动缩</span></div>' +
      '<div class="grid c4">' +
      statCard(dy.due, '今日到期复习') +
      statCard(dy.newQuota, '今日新词额度') +
      statCard(dy.estMinutes, '预计用时（分钟）') +
      statCard(dy.budgetWords, '单词总容量') +
      '</div>' +
      (dy.newQuota === 0 && dy.due > 0
        ? '<div class="flow-note" style="margin-top:8px">今天到期复习已经把额度占满 —— 先清复习，新词明天再铺。</div>'
        : '<div class="flow-note" style="margin-top:8px">额度算法：总容量 = 每日分钟 ÷ 18 秒；新词额度 = （总容量 − 今日到期复习量）× 自适应倍率 ' + prof.newMul + '（复习词约 8 秒/个，新词约 25 秒/个）。</div>' +
          (dy.estMinutes > plan.minutes
            ? '<div class="flow-note" style="margin-top:8px">⏱ 按现在这个额度预计 ' + dy.estMinutes + ' 分钟，超过你设定的 ' + plan.minutes + ' 分钟预算 —— 想守时就把档位切回「自动」或「标准」。</div>'
            : '')) +
      '</div>' +
      '<div class="card" style="margin-top:16px"><div class="card-title">学习难度自适应 <span class="tag small muted">按近 ' + ADAPT_WINDOW_DAYS + ' 日答题自动升降</span></div>' +
      '<div class="grid c4">' +
      statCard(esc(prof.name), prof.mode === 'auto' ? '当前档位（自动）' : '当前档位（手动锁定）') +
      statCard(smp.n, '近 ' + ADAPT_WINDOW_DAYS + ' 日样本（题）') +
      statCard(smp.n ? Math.round(smp.rate * 100) + '%' : '—', '正确率') +
      statCard(smp.avgSec === null ? '—' : smp.avgSec + ' s', '拼写题平均用时') +
      '</div>' +
      '<div class="flow-note" style="margin-top:8px">' + esc(prof.desc) + '　·　' +
      (prof.coldStart
        ? '样本不足 ' + ADAPT_MIN_SAMPLE + ' 题，先按标准档跑；多练几轮就会自动跟上你的水平。'
        : '自动判定：' + esc(ADAPT_MODES[prof.autoKey].name) +
          (prof.mode === 'auto' ? '（已生效）' : '（现被手动锁定为 ' + esc(prof.name) + '）')) +
      '</div>' +
      '<div class="row" style="margin-top:10px">' +
      adaptBtn('auto', '自动', prof.mode) +
      adaptBtn('chill', '轻松', prof.mode) +
      adaptBtn('normal', '标准', prof.mode) +
      adaptBtn('push', '挑战', prof.mode) +
      '<span class="small muted">切到「自动」＝交给我按正确率与用时提降；手动档位会一直锁住，直到你切回自动。</span>' +
      '</div></div>' +
      (plan.warning ? '<div class="card" style="margin-top:16px;border-color:var(--warn)"><div class="card-title" style="color:var(--warn)">⚠ 时间预算提示</div><div>' + esc(plan.warning) + '</div></div>' : '') +
      '<div class="card" style="margin-top:16px"><div class="card-title">阶段划分 <span class="tag small muted">共 ' + plan.days + ' 天 · 有效学习日 ' + plan.effectiveDays + ' 天</span></div>' +
      plan.phases.map(function (p) {
        var cur = nowName && nowName.name === p.name;
        return '<div class="phase' + (cur ? ' now' : '') + '">' +
          '<div class="spread"><h4>' + esc(p.name) + (cur ? ' <span class="badge due">进行中</span>' : '') + '</h4>' +
          '<span class="meta">' + p.from + ' → ' + p.to + '</span></div>' +
          '<div class="meta">每日新词 ' + p.newPerDay + ' 个 · 配比 ' + esc(p.ratio) + '</div>' +
          '<div style="margin-top:8px">' + esc(p.focus) + '</div></div>';
      }).join('') + '</div>' +
      '<div class="card" style="margin-top:16px"><div class="card-title">逐日任务表 <span class="tag small muted">前 ' + rows.length + ' 天</span></div>' +
      '<div style="overflow:auto"><table class="day-table"><thead><tr>' +
      '<th>日期</th><th>阶段</th><th>新词</th><th>复习</th><th>真题</th><th>预计用时</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var isToday = r.date === todayStr();
        var s = stats[r.date];
        var done = s && s.answered >= (r.newWords + r.review) * 0.8;
        return '<tr><td class="' + (isToday ? 'today' : done ? 'done' : '') + '">' + r.date + (isToday ? ' · 今天' : '') + '</td>' +
          '<td>' + esc(r.phase.split(' · ')[0]) + '</td>' +
          '<td>' + (r.isRest ? '休息' : r.newWords) + '</td>' +
          '<td>' + r.review + '</td>' +
          '<td>' + (r.paper ? '1 套' : '—') + '</td>' +
          '<td>' + r.minutes + ' 分钟</td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<div class="flow-note">复习量为按记忆曲线估算的滚动复习量，实际以「默写模式 · 今日应复习」为准。</div></div>' +
      '<div class="row" style="margin-top:16px">' +
      '<button class="btn primary" id="planApplyQuiz">按今日任务开始默写</button>' +
      '<button class="btn" id="planGoReal">去练一套真题</button></div>';

    $('#planOut').innerHTML = html;
    var pe = $('#planEdit');
    if (pe) pe.onclick = function () {
      pgGo('#planTabs', 'setup');
      resetScroll();
    };
    $$('#planOut [data-adapt]').forEach(function (btn) {
      btn.onclick = function () {
        var m = btn.dataset.adapt;
        setAdaptMode(m);
        toast(m === 'auto' ? '已切回自动档，跟着你的正确率走' : '已锁定为' + ADAPT_MODES[m].name);
        drawPlan(settings.plan);
      };
    });
    var b = $('#planApplyQuiz');
    if (b) b.onclick = function () {
      startQuiz({ level: settings.level, scope: 'due', dir: 'en2cn', count: Math.min(50, settings.plan.newPerDay + 10) });
      go('quiz');
    };
    var b2 = $('#planGoReal');
    if (b2) b2.onclick = function () { go('real'); };
  }
  /* ---------------- 设置页（对齐市面 App 的「我的」式设置） ---------------- */
  /* ---------------- 学习报告 ----------------
     数据只从本机已有记录里算：stats（每日答题）/ progress（每词状态）/
     grammarProg 等各模块进度 / focusLog（专注）。不做任何上传。 */
  var reportDays = 14;
  function rptRow(label, cur, total, unit) {
    var pct = total ? Math.min(100, Math.round(cur / total * 100)) : 0;
    return '<div class="rpt-row"><span class="lbl">' + label + '</span>' +
      '<span class="bar"><span class="bar" style="display:block"><i style="width:' + pct + '%"></i></span></span>' +
      '<span class="val">' + cur + (total ? ' / ' + total : '') + ' ' + (unit || '') + '</span></div>';
  }
  function renderReport() {
    if (!$('#reportChart')) return;
    var today = todayStr();
    var totalAns = 0, totalRight = 0, activeDays = 0, totalNew = 0, paperDone = 0;
    Object.keys(stats).forEach(function (k) {
      var s = stats[k] || {};
      totalAns += s.answered || 0;
      totalRight += s.right || 0;
      totalNew += s.newWords || 0;
      paperDone += s.papers || 0;
      if ((s.answered || 0) > 0) activeDays++;
    });
    var rate = totalAns ? Math.round(totalRight / totalAns * 100) : 0;
    var focusMin = focusLog.reduce(function (a, x) { return a + x.minutes; }, 0);
    var c = counts();

    if ($('#reportStats')) {
      $('#reportStats').innerHTML =
        statCard(totalAns, '累计答题') +
        statCard(rate + '%', '总正确率') +
        statCard(c.learned + ' / ' + WORDS.length, '已学单词') +
        statCard(focusMin + '′', '累计专注');
    }
    if ($('#reportRange')) {
      $('#reportRange').innerHTML = [[7, '近 7 天'], [14, '近 14 天'], [30, '近 30 天']].map(function (r) {
        return '<button class="chip' + (reportDays === r[0] ? ' on' : '') + '" data-rd="' + r[0] + '">' + r[1] + '</button>';
      }).join('');
    }

    var win = [];
    for (var i = reportDays - 1; i >= 0; i--) {
      var d = addDays(today, -i);
      win.push({ d: d, s: stats[d] || { answered: 0, right: 0, wrong: 0, newWords: 0 } });
    }
    var max = 1, winAns = 0, winRight = 0;
    win.forEach(function (x) {
      max = Math.max(max, x.s.answered || 0);
      winAns += x.s.answered || 0;
      winRight += x.s.right || 0;
    });
    if ($('#reportCurveNote')) {
      $('#reportCurveNote').textContent = '这 ' + reportDays + ' 天 ' + winAns + ' 题' +
        (winAns ? ' · 正确率 ' + Math.round(winRight / winAns * 100) + '%' : ' · 还没开始');
    }
    $('#reportChart').innerHTML = win.map(function (x) {
      var n = x.s.answered || 0;
      var h = Math.max(3, Math.round(n / max * 100));
      return '<div class="rpt-bar" title="' + x.d + ' · ' + n + ' 题' + (n ? '，正确 ' + (x.s.right || 0) : '') + '">' +
        '<b>' + (n || '') + '</b><i style="height:' + h + '%"></i>' +
        '<span>' + x.d.slice(5).replace('-', '/') + '</span></div>';
    }).join('');

    // 记忆阶段分布（阶段越高越牢）
    var stages = [];
    for (var k = 0; k < INTERVALS.length; k++) stages.push(0);
    Object.keys(progress).forEach(function (w) {
      var r = progress[w];
      if (!r || !r.seen) return;
      stages[Math.max(0, Math.min(stages.length - 1, r.s || 0))]++;
    });
    var smax = Math.max(1, Math.max.apply(null, stages));
    if ($('#reportStages')) {
      var rows = [];
      for (var s2 = stages.length - 1; s2 >= 0; s2--) {
        var tag = s2 >= MASTER_STAGE ? '阶段 ' + s2 + ' · 已掌握' : '阶段 ' + s2;
        rows.push('<div class="rpt-row"><span class="lbl">' + tag + '</span>' +
          '<span class="bar" style="display:block"><i style="display:block;height:100%;width:' +
          Math.round(stages[s2] / smax * 100) + '%"></i></span>' +
          '<span class="val">' + stages[s2] + ' 词</span></div>');
      }
      $('#reportStages').innerHTML = rows.join('');
    }

    renderReportExtra();

    // 最该补的词
    var weak = WORDS.filter(function (w) {
      var r = progress[w.w];
      return r && r.wrong > 0 && r.s < MASTER_STAGE;
    }).sort(function (a, b) { return (progress[b.w].wrong || 0) - (progress[a.w].wrong || 0); }).slice(0, 8);
    if ($('#reportWeak')) {
      $('#reportWeak').innerHTML = weak.length ? weak.map(function (w) {
        var r = progress[w.w];
        return '<div class="rpt-row"><span class="lbl"><b>' + esc(w.w) + '</b></span>' +
          '<span class="val" style="flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left">' +
          esc(w.cn) + '</span>' +
          '<span class="val">✗' + (r.wrong || 0) + '</span></div>';
      }).join('') : '<div class="muted small">还没有错词 —— 干净得像刚下过雨。</div>';
    }

    // 各模块练了多少
    var gDone = 0;
    Object.keys(grammarProg || {}).forEach(function (k) {
      var r = grammarProg[k];
      if (r && ((r.wrong || 0) > 0 || r.last)) gDone++;
    });
    var lsDone = 0;
    if ($('#reportModules')) {
      $('#reportModules').innerHTML =
        rptRow('单词默写', c.learned, WORDS.length, '词有记录') +
        rptRow('已掌握', c.mastered, WORDS.length, '词') +
        rptRow('累计新词', totalNew, WORDS.length, '词') +
        rptRow('真题完成', paperDone, PAPERS.length, '套') +
        rptRow('语法练习', gDone, 90, '题有记录') +
        rptRow('专注次数', focusLog.length, 0, '次');
    }

    // 一句话建议（按数据挑最该补的短板）
    var tip;
    if (!totalAns) tip = '还没有答题记录 —— 去「默写模式」点一下就开始，10 个词也算数。';
    else if (c.wrong > 30) tip = '错题堆到 ' + c.wrong + ' 个了，先去错题本按「反复错」那一类清一轮，比刷新题见效快。';
    else if (rate < 65) tip = '总正确率 ' + rate + '% —— 说明题刷得比记的狠，把每日新词量调小一点、复习量补上。';
    else if (c.due > 0) tip = '今天有 ' + c.due + ' 个词到期，先清到期再做新词，记忆曲线才接得上。';
    else if (activeDays < 3) tip = '学习天数还少 —— 每天十分钟不断档，比周末突击两小时管用。';
    else tip = '节奏挺稳：正确率 ' + rate + '%，已掌握 ' + c.mastered + ' 词。保持每天清空到期词就行。';
    if ($('#reportAdvice')) {
      $('#reportAdvice').innerHTML = '<div class="card-title">下一步建议</div><div>' + tip + '</div>';
    }
  }

  function renderSettings() {
    var lv = $('#setLevel');
    if (lv) {
      lv.innerHTML = [['cet4', 'CET-4 四级'], ['cet6', 'CET-6 六级']].map(function (o) {
        return '<option value="' + o[0] + '"' + (settings.level === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
      }).join('');
    }
    if ($('#setDate')) $('#setDate').value = settings.examDate;
    if ($('#setMinutes')) $('#setMinutes').innerHTML = [15, 20, 30, 40, 60, 90].map(function (m) {
      return '<option value="' + m + '"' + (settings.minutes === m ? ' selected' : '') + '>' + m + ' 分钟</option>';
    }).join('');
    if ($('#setRest')) $('#setRest').innerHTML = [0, 1, 2, 3].map(function (r) {
      return '<option value="' + r + '"' + (settings.restDays === r ? ' selected' : '') + '>' + r + ' 天</option>';
    }).join('');
    if ($('#ttsRate')) $('#ttsRate').value = tts.rate;
    if ($('#ttsRateTxt')) $('#ttsRateTxt').textContent = tts.rate.toFixed(2) + '×';
    if ($('#setMaxReview')) $('#setMaxReview').value = settings.maxReview || 60;
    if ($('#setWordCount')) $('#setWordCount').textContent = WORDS.length;
    if ($('#setPaperCount')) $('#setPaperCount').textContent = PAPERS.length;
    if ($('#ttsBtn')) $('#ttsBtn').textContent = tts.enabled ? '🔊 开' : '🔇 关';
    if ($('#setVoice')) {
      $('#setVoice').textContent = (settings.voice === 'uk') ? '🇬🇧 英音' : '🇺🇸 美音';
      $('#setVoice').disabled = !hasUKAudio();
      if (!hasUKAudio()) $('#setVoice').title = '本机没有英音音源';
    }
    if ($('#buzzBtn')) $('#buzzBtn').textContent = buzzOn ? '📳 开' : '📴 关';
    var tb = $('#themeBtn');
    if (tb) tb.textContent = (document.documentElement.getAttribute('data-theme') === 'dark') ? '☀ 切到日间' : '🌙 切到夜间';
    if ($('#setHard')) $('#setHard').textContent = settings.focusHard ? '🔒 开' : '🔓 关';
    if ($('#remindBtn')) $('#remindBtn').textContent = (settings.remind === false) ? '🔕 关' : '🔔 开';
    if ($('#remindAt')) $('#remindAt').value = settings.remindAt || '20:00';
    if ($('#remindExamTip')) {
      var NAT = window.WUDU_NATIVE;
      var dd = Math.max(0, diffDays(todayStr(), settings.examDate));
      $('#remindExamTip').textContent = (NAT && NAT.isNative)
        ? ('已排 · 还有 ' + dd + ' 天')
        : '装成 App 后生效';
    }
  }

  function saveSettingsFromPage() {
    settings.level = ($('#setLevel') && $('#setLevel').value) || settings.level;
    settings.examDate = ($('#setDate') && $('#setDate').value) || settings.examDate;
    settings.minutes = parseInt(($('#setMinutes') || {}).value, 10) || settings.minutes;
    settings.restDays = parseInt(($('#setRest') || {}).value, 10) || 0;
    settings.maxReview = Math.max(10, Math.min(300, parseInt(($('#setMaxReview') || {}).value, 10) || 60));
    settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
    saveAll();
    renderPlan(); renderHome(); renderSettings();
    toast('已保存 · 距考试 ' + Math.max(0, diffDays(todayStr(), settings.examDate)) + ' 天');
  }

  function statCard(num, lbl) {
    return '<div class="card stat"><div class="num">' + num + '</div><div class="lbl">' + lbl + '</div></div>';
  }

  /* ---------------- 页内分页 ----------------
     长页面（开学、设置…）按「开关」切成几屏：点一下切换，不用一路往下刷。
     结构：.pg-bar(内含 .pg-tab[data-pg]) + 同级若干 .pg-panel[data-pg-panel]。 */
  function bindPg(sel) {
    var bar = $(sel);
    if (!bar) return;
    var view = bar.closest ? bar.closest('.view') : null;
    if (!view) { console.warn('[雾读] bindPg(' + sel + ') 失败：#focus 页签不在 .view 内 —— 检查 index.html 里该页的 </div> 是否多了一个'); return; }
    bar.addEventListener('click', function (e) {
      var b = e.target.closest('[data-pg]');
      if (!b) return;
      var key = b.dataset.pg;
      $$(sel + ' .pg-tab').forEach(function (x) {
        var on = x === b;
        x.classList.toggle('on', on);
        x.setAttribute('aria-selected', on ? 'true' : 'false');   // 翻页 tab 的状态（P1-10）
      });
      $$('.pg-panel').forEach(function (p) {
        if (view.contains(p)) p.classList.toggle('on', p.dataset.pgPanel === key);
      });
      resetScroll();
    });
  }
  function pgGo(sel, key) {
    var bar = $(sel);
    if (!bar) return;
    var t = bar.querySelector('[data-pg="' + key + '"]');
    if (t) t.click();
  }
  /* 当前停在哪一页（读页签的 .on）—— 替代原先靠 style.display 判断的老写法。
     2026-09-25 全站多页化：视图改用 .pg-panel 控制显隐后，style.display 不再反映真实状态，
     安卓返回键等判断必须走这个函数。 */
  function pgCurrent(sel) {
    var t = $(sel + ' .pg-tab.on');
    return t ? t.dataset.pg : null;
  }

  /* ==========================================================
     报告页附加区：成就徽章（P2-1）+ 词汇量快测（P2-6）
     两者都塞在「概览」面板里 #reportWeak 之后，不另开页面（少一层跳转）
     ========================================================== */
  var BADGE_KIND_NAME = {
    streak: '连续学习', mastered: '已掌握词数', answered: '累计答题',
    focus: '累计专注', wrongFixed: '错词转掌握', accuracy: '单日正确率'
  };
  function badgeMetrics() {
    var c = counts();
    var answered = 0, bestAcc = 0;
    Object.keys(stats).forEach(function (d) {
      var st = stats[d] || {};
      answered += st.answered || 0;
      if ((st.answered || 0) >= 20) {
        var acc = Math.round((st.right || 0) / st.answered * 100);
        if (acc > bestAcc) bestAcc = acc;
      }
    });
    var focusMin = 0;
    (focusLog || []).forEach(function (x) { focusMin += x.minutes || 0; });
    var fixed = 0;
    Object.keys(progress).forEach(function (w) {
      var r = progress[w];
      if (r && (r.wrong || 0) > 0 && r.s >= MASTER_STAGE) fixed++;
    });
    return { streak: streak(), mastered: c.mastered, answered: answered, focus: focusMin, wrongFixed: fixed, accuracy: bestAcc };
  }
  function badgeDone(b, m) {
    if (b.kind === 'accuracy') {
      // 正确率类还要满足「当日至少答 minAnswered 题」，避免 1 题 100% 就发奖
      return m.accuracy >= b.need;
    }
    return (m[b.kind] || 0) >= b.need;
  }
  function renderBadges(host) {
    var list = window.WUDU_BADGES || [];
    if (!list.length) { host.innerHTML = ''; return; }
    var m = badgeMetrics();
    var got = list.filter(function (b) { return badgeDone(b, m); });
    var soon = list.filter(function (b) { return !badgeDone(b, m); })
      .sort(function (a, b) { return (m[b.kind] || 0) / b.need - (m[a.kind] || 0) / a.need; }).slice(0, 4);
    host.innerHTML = '<div class="card" style="margin-top:12px"><div class="spread" style="align-items:baseline">' +
      '<div class="card-title" style="margin:0">成就徽章 <span class="tag small muted">纯本地 · 没有排行榜</span></div>' +
      '<span class="badge ' + (got.length ? 'good' : '') + '">' + got.length + ' / ' + list.length + '</span></div>' +
      '<div class="row" style="flex-wrap:wrap;gap:8px;margin-top:8px">' +
      list.map(function (b) {
        var ok = badgeDone(b, m);
        return '<span class="chip' + (ok ? ' on' : '') + '" style="cursor:default;opacity:' + (ok ? 1 : .45) + '" title="' +
          esc(b.desc) + '">' + b.icon + ' ' + esc(b.name) + '</span>';
      }).join('') + '</div>' +
      (soon.length ? '<div class="flow-note" style="margin-top:8px">快拿到的：' +
        soon.map(function (b) {
          return esc(b.name) + '（' + esc(BADGE_KIND_NAME[b.kind] || '') + ' ' + (m[b.kind] || 0) + ' / ' + b.need + '）';
        }).join(' · ') + '</div>' : '<div class="flow-note" style="margin-top:8px">全部到手 —— 剩下的时间留给真题吧。</div>') +
      '</div>';
  }

  var vocabState = null;
  function vocabTiers() { return ((window.VOCAB_TEST || {}).tiers) || []; }
  function renderVocabTest(host) {
    var tiers = vocabTiers();
    if (!tiers.length) { host.innerHTML = ''; return; }
    if (!vocabState || vocabState.phase === 'idle') {
      host.innerHTML = '<div class="card" style="margin-top:12px"><div class="card-title">词汇量快测 <span class="tag small muted">3 分钟 · 90 题分层抽样</span></div>' +
        '<div class="small muted">按词频分三层抽题（四级核心 / 四级其余 / 六级），按各层正确率折算总量。结果只作参考，不写进学习记录。</div>' +
        '<div class="row" style="margin-top:10px"><button class="btn primary" id="vtStart">开始快测</button></div></div>';
      var b = document.getElementById('vtStart');
      if (b) b.onclick = function () {
        vocabState = { phase: 'run', ti: 0, qi: 0, hit: {}, total: 0, right: 0 };
        renderReportExtra();
      };
      return;
    }
    if (vocabState.phase === 'run') {
      var t = tiers[vocabState.ti];
      if (!t) { vocabState.phase = 'done'; renderReportExtra(); return; }
      var it = t.items[vocabState.qi];
      if (!it) { vocabState.ti++; vocabState.qi = 0; renderReportExtra(); return; }
      var doneN = Object.keys(vocabState.hit).reduce(function (a, k) { return a + vocabState.hit[k].n; }, 0);
      var totalN = tiers.reduce(function (a, x) { return a + x.items.length; }, 0);
      host.innerHTML = '<div class="card" style="margin-top:12px"><div class="spread" style="align-items:baseline">' +
        '<div class="card-title" style="margin:0">词汇量快测 · ' + esc(t.name) + '</div>' +
        '<span class="badge">' + (doneN + 1) + ' / ' + totalN + '</span></div>' +
        '<div class="quiz-prompt" style="font-size:26px;margin:10px 0 4px">' + esc(it.w) + '</div>' +
        '<div class="small muted">选出它最合适的中文释义</div>' +
        '<div class="opt-grid" style="margin-top:12px">' +
        it.options.map(function (o, i) {
          return '<button class="opt" data-vt="' + i + '">' + esc(o) + '</button>';
        }).join('') + '</div>' +
        '<div class="row" style="margin-top:10px"><button class="btn ghost sm" id="vtQuit">结束并看结果</button></div></div>';
      // 2026-09-25 修：同 renderWordDetail 那处 —— 原来写 `$('#reportExtra [data-vt]')`，
  // `$` 是 querySelector（返回元素或 null）不是数组，没有该元素时 `null.forEach` 抛异常，
  // 会让报告页词汇量快测的选项点不动。必须用 `$$`。
  $$('#reportExtra [data-vt]').forEach(function (b) {
        b.onclick = function () {
          var pick = parseInt(b.dataset.vt, 10);
          var ok = pick === it.answer;
          if (!vocabState.hit[t.key]) vocabState.hit[t.key] = { n: 0, right: 0, size: t.size };
          vocabState.hit[t.key].n++;
          if (ok) { vocabState.hit[t.key].right++; vocabState.right++; }
          vocabState.total++;
          b.classList.add(ok ? 'ok' : 'no');
          setTimeout(function () { vocabState.qi++; renderReportExtra(); }, 220);
        };
      });
      var q = document.getElementById('vtQuit');
      if (q) q.onclick = function () { vocabState.phase = 'done'; renderReportExtra(); };
      return;
    }
    // done：按层折算总量
    var est = 0, rows = [];
    tiers.forEach(function (t) {
      var h = vocabState.hit[t.key];
      if (!h || !h.n) { rows.push('<div class="rpt-row"><span class="lbl">' + esc(t.name) + '</span><span class="val">未测</span></div>'); return; }
      var rate = h.right / h.n;
      var estN = Math.round(rate * t.size);
      est += estN;
      rows.push('<div class="rpt-row"><span class="lbl">' + esc(t.name) + '</span>' +
        '<span class="val">' + h.right + ' / ' + h.n + ' 对 · 折算 ' + estN + ' 词</span></div>');
    });
    host.innerHTML = '<div class="card" style="margin-top:12px"><div class="card-title">词汇量估算结果</div>' +
      '<div class="big">约 ' + est + ' <span class="small muted">词</span></div>' +
      rows.join('') +
      '<div class="flow-note" style="margin-top:8px">算法：各层正确率 × 该层词数后求和，是抽样估计不是精算；测的题越多越准。</div>' +
      '<div class="row" style="margin-top:10px"><button class="btn" id="vtAgain">再测一次</button></div></div>';
    var ag = document.getElementById('vtAgain');
    if (ag) ag.onclick = function () { vocabState = { phase: 'idle' }; renderReportExtra(); };
  }
  function renderReportExtra() {
    var anchor = document.getElementById('reportWeak');
    if (!anchor || !anchor.parentNode) return;
    var host = document.getElementById('reportExtra');
    if (!host) {
      host = document.createElement('div');
      host.id = 'reportExtra';
      anchor.parentNode.insertBefore(host, anchor.nextSibling);
    }
    renderBadges(host);
    var vt = document.createElement('div');
    host.appendChild(vt);
    renderVocabTest(vt);
  }

  /* ==========================================================
     P1-10 无障碍：把「能用眼睛看懂」的界面补上语义
     静态按钮 / 输入框用可见文本兜底；动态生成的节点（选项、词表、
     弹层）由 MutationObserver 持续补齐 —— 手改 65 个按钮改漏一处就白搭。
     ========================================================== */
  function a11yLabel(el) {
    var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (t) return t.slice(0, 40);
    return el.getAttribute('title') || el.id || el.className || '按钮';
  }
  function applyA11y(root) {
    if (!root || !root.querySelectorAll) return;
    var add = 0;
    // 答题选项：读成「选项：xxx」，并带上对错状态 —— 判分后状态会变，所以每次都重算（P1-10）
    Array.prototype.forEach.call(root.querySelectorAll('.opt'), function (b) {
      var base = b.dataset.a11yBase ||
        (b.dataset.a11yBase = (b.textContent || '').replace(/\s+/g, ' ').trim());
      var mark = b.classList.contains('ok') ? '，正确答案'
        : (b.classList.contains('no') ? '，选错' : '');
      var want = '选项：' + base + mark;
      if (b.getAttribute('aria-label') !== want) {
        if (!b.getAttribute('aria-label')) add++;
        b.setAttribute('aria-label', want);
      }
    });
    // 真题「选词填空」的空位
    Array.prototype.forEach.call(root.querySelectorAll('.blank-slot'), function (x) {
      var t = (x.textContent || '').replace(/\s+/g, ' ').trim() || '空';
      var st = x.classList.contains('ok') ? '，答对' : (x.classList.contains('no') ? '，答错' : '');
      x.setAttribute('role', 'button');
      x.setAttribute('aria-label', '填空位，当前：' + t + st);
    });
    Array.prototype.forEach.call(root.querySelectorAll('button:not([aria-label])'), function (b) {
      b.setAttribute('aria-label', a11yLabel(b));
      if (b.tagName === 'BUTTON' && !b.getAttribute('type')) b.setAttribute('type', 'button');
      if (b.disabled) b.setAttribute('aria-disabled', 'true');
      add++;
    });
    Array.prototype.forEach.call(root.querySelectorAll('input:not([aria-label]),textarea:not([aria-label]),select:not([aria-label])'), function (i) {
      i.setAttribute('aria-label', i.getAttribute('placeholder') || i.getAttribute('title') || i.id || '输入框');
      add++;
    });
    // 容器语义：选项组 / 列表 / 字母输入槽 / 进度条
    Array.prototype.forEach.call(root.querySelectorAll('.opt-grid:not([role])'), function (g) {
      g.setAttribute('role', 'group'); g.setAttribute('aria-label', '选项');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.word-list:not([role]),.list-plain:not([role])'), function (l) {
      l.setAttribute('role', 'list');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.spell-wrap:not([role])'), function (x) {
      x.setAttribute('role', 'textbox'); x.setAttribute('aria-label', '按字母填空');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.bar:not([role])'), function (x) {
      x.setAttribute('role', 'progressbar'); x.setAttribute('aria-label', '进度');
    });
    Array.prototype.forEach.call(root.querySelectorAll('.wbx-kind:not([role]),.mode-card:not([aria-pressed])'), function (x) {
      x.setAttribute('role', 'button');
      x.setAttribute('aria-pressed', x.classList.contains('on') ? 'true' : 'false');
    });
    return add;
  }
  var _a11yOn = false;
  function a11yInit() {
    if (_a11yOn) return;
    _a11yOn = true;
    applyA11y(document);
    // 状态区：屏幕阅读器要能听到 toast 与提示条
    var ts = document.getElementById('toast');
    if (ts) { ts.setAttribute('role', 'status'); ts.setAttribute('aria-live', 'polite'); }
    // 动态节点：答题选项、词表、弹层都是运行时生成的，必须持续补
    if (window.MutationObserver) {
      var pend = null;
      var mo = new MutationObserver(function () {
        if (pend) return;
        pend = setTimeout(function () { pend = null; applyA11y(document); }, 120);
      });
      mo.observe(document.body, { childList: true, subtree: true });
    }
  }

  /* ---------------- 事件绑定 ---------------- */
  function bindGlobal() {
    bindPg('#homeTabs');
    bindPg('#setTabs');
    bindPg('#reportTabs');
    bindPg('#focusTabs');
    bindPg('#lsTabs');   // 听力三段式（2026-09-25）：听材料 / 答题 / 原文
    bindPg('#realTabs');   // 真题分页（2026-09-25）：选卷 / 作答
    bindPg('#grammarTabs');   // 语法分页（2026-09-25）：选题 / 答题
    bindPg('#trTabs');   // 翻译分页（2026-09-25）：选题 / 作答
    bindPg('#wrTabs');   // 写作分页（2026-09-25）：选题 / 写作
    bindPg('#planTabs');   // 计划分页（2026-09-25）：设置 / 计划
    bindPg('#dictTabs');   // 词典分页（2026-09-25）：查词 / 词条 / 真题
    $('#nav').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-view]');
      if (b) go(b.dataset.view);
    });
    document.addEventListener('click', function (e) {
      var g = e.target.closest('[data-go]');
      if (g) {
        // 首页「默写模式」卡片：单击即按今日任务直接开考，不再停在设置页
        if (g.dataset.quick && g.dataset.go === 'quiz') { quickStart(); return; }
        go(g.dataset.go);
      }
      var s = e.target.closest('[data-say]');
      if (s) {
        e.preventDefault();
        var txt = s.dataset.say;
        if (s.dataset.sayStop !== undefined) { stopSpeak(); return; }
        speak(txt, { lang: s.dataset.sayLang, rate: parseFloat(s.dataset.sayRate) || undefined });
      }
    });

    // 朗读 / 震动开关（照 Duolingo 的做法：声音类反馈必须能一键关）
    var ttsBtn = $('#ttsBtn'), buzzBtn = $('#buzzBtn');
    function syncToggles() {
      if (ttsBtn) ttsBtn.textContent = tts.enabled ? '🔊 朗读：开' : '🔇 朗读：关';
      if (buzzBtn) buzzBtn.textContent = buzzOn ? '📳 震动：开' : '📴 震动：关';
    }
    try {
      if (localStorage.getItem('wudu.tts') === '0') tts.enabled = false;
      if (localStorage.getItem('wudu.buzz') === '0') buzzOn = false;
    } catch (e) {}
    if (ttsBtn) ttsBtn.onclick = function () {
      tts.enabled = !tts.enabled;
      if (!tts.enabled) stopSpeak();
      try { localStorage.setItem('wudu.tts', tts.enabled ? '1' : '0'); } catch (e) {}
      syncToggles();
      toast(tts.enabled ? '朗读已打开' : '朗读已关闭');
    };
    if (buzzBtn) buzzBtn.onclick = function () {
      buzzOn = !buzzOn;
      try { localStorage.setItem('wudu.buzz', buzzOn ? '1' : '0'); } catch (e) {}
      syncToggles();
      if (buzzOn) buzz([30]);
      toast(buzzOn ? '震动已打开' : '震动已关闭');
    };
    syncToggles();

    // 专注强硬模式
    var shBtn = $('#setHard');
    if (shBtn) shBtn.onclick = function () {
      settings.focusHard = !settings.focusHard;
      saveAll(); renderSettings();
      toast(settings.focusHard
        ? '强硬模式已开 · 专注进行中学完 3 个生词才给退出密码'
        : '强硬模式已关');
    };

    // 学习报告：区间切换
    var rr = $('#reportRange');
    if (rr) rr.addEventListener('click', function (e) {
      var c = e.target.closest('[data-rd]'); if (!c) return;
      reportDays = parseInt(c.dataset.rd, 10) || 14;
      renderReport();
    });

    // 提醒（系统通知，APK 内生效）
    var rb = $('#remindBtn');
    if (rb) rb.onclick = function () {
      settings.remind = (settings.remind === false);
      saveAll(); renderSettings();
      if (settings.remind) { applyReminders(); toast('每日提醒已开 · ' + settings.remindAt); }
      else {
        if (window.WUDU_NATIVE) window.WUDU_NATIVE.cancelDaily();
        toast('每日提醒已关');
      }
    };
    var ra = $('#remindAt');
    if (ra) ra.onchange = function () {
      settings.remindAt = ra.value || '20:00';
      saveAll(); applyReminders(); toast('提醒时间改成 ' + settings.remindAt);
    };

    // 主题
    var themeBtn = $('#themeBtn');
    var savedTheme = localStorage.getItem('wudu.theme') || 'light';
    document.documentElement.dataset.theme = savedTheme;
    themeBtn.textContent = savedTheme === 'dark' ? '☀ 切换日间' : '🌙 切换夜间';
    themeBtn.onclick = function () {
      var t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = t;
      localStorage.setItem('wudu.theme', t);
      themeBtn.textContent = t === 'dark' ? '☀ 切换日间' : '🌙 切换夜间';
      if (window.WUDU_NATIVE) window.WUDU_NATIVE.applyStatusBar();
    };

    // 词典
    var si = $('#dictSearch');
    var timer = null;
    si.oninput = function () {
      clearTimeout(timer);
      timer = setTimeout(function () { runDictSearch(si.value); }, 160);
    };
    si.onkeydown = function (e) { if (e.key === 'Enter') { runDictSearch(si.value); } };
    $('#dictSearchBtn').onclick = function () { runDictSearch(si.value); };
    // 切页签 → 重渲染那一类（bindPg 已经把 .on 切好，这里只管内容）
    $('#dictTabs').addEventListener('click', function (e) {
      if (!e.target.closest('[data-pg]')) return;
      renderDict();
    });
    // 点词 → 弹词条层。委托到整个词典区，主页表与搜索结果表共用一套逻辑。
    $('#view-dict').addEventListener('click', function (e) {
      var it = e.target.closest('.word-item'); if (!it || !it.dataset.w) return;
      dictState.picked = it.dataset.w;
      dictState.detailOpen = true;
      renderWordDetail(it.dataset.w);
      openDictLayer('#dictWordLayer');
    });
    var dsb = $('#dictSearchBack');
    if (dsb) dsb.onclick = function () { closeDictLayer('#dictSearchLayer'); };
    var dwb = $('#dictWordBack');
    if (dwb) dwb.onclick = closeWordDetail;

    // 默写：第 1 步选作答方式 → 第 2 步定范围与题量 → 开始
    function quizGoStep(n) {
      if (n === 2) {
        var names = { cn2en: '打字填写', en2cn: '四选一认词', listen: '听音拼写', mix: '混合随机' };
        var el = $('#quizPicked');
        if (el) el.innerHTML = '已选：<b>' + (names[$('#quizDir').value] || '打字填写') + '</b>';
        wizPush('quiz', 'config');
      } else {
        wizReset('quiz');
      }
    }
    function beginQuiz(dir) {
      startQuiz({
        level: (quiz && quiz.level) || 'all',
        scope: $('#quizScope').value,
        dir: dir || $('#quizDir').value,
        count: parseInt($('#quizCount').value, 10)
      });
    }
    $$('#quizDirPick .mode-card').forEach(function (b) {
      b.onclick = function () {
        $$('#quizDirPick .mode-card').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        $('#quizDir').value = b.dataset.dir;
        quizGoStep(2);
      };
    });
    var qb1 = $('#quizBack1');
    if (qb1) qb1.onclick = function () { quizGoStep(1); };
    $('#quizLevel').addEventListener('click', function (e) {
      var c = e.target.closest('[data-ql]'); if (!c) return;
      quiz = quiz || {}; quiz.level = c.dataset.ql; renderQuizLevels();
    });
    $('#quizStart').onclick = function () { beginQuiz(); };
    $('#quizQuit').onclick = function () { if (quiz && quiz.queue) endQuiz(); };
    var qsb = $('#quizSetupBack');
    if (qsb) qsb.onclick = backToSetup;

    // 错题本（三页：总览 → 分类列表 → 词条）
    function wrongBack() {
      wizPop('wrong');
      if (wizCur('wrong') === 'overview') renderWrong(); else renderWrongList();
    }
    var wkHost = $('#wrongKinds');
    if (wkHost) wkHost.addEventListener('click', function (e) {
      var c = e.target.closest('[data-wk]'); if (!c) return;
      wrongKw = '';
      wrongOpenList(c.dataset.wk, '');
    });
    var wq = $('#wrongQ');
    if (wq) wq.onkeydown = function (e) { if (e.key === 'Enter') { e.stopPropagation(); wrongOpenList('all', wq.value); } };
    var wqb = $('#wrongQBtn');
    if (wqb) wqb.onclick = function () { wrongOpenList('all', wq ? wq.value : ''); };
    var wl = $('#wrongList');
    if (wl) wl.addEventListener('click', function (e) {
      var it = e.target.closest('[data-w]'); if (!it) return;
      wrongOpenWord(it.dataset.w);
    });
    var wq2 = $('#wrongQ2');
    if (wq2) {
      wq2.onkeydown = function (e) { if (e.key === 'Enter') { e.stopPropagation(); wrongKw = wq2.value.trim(); renderWrongList(); } };
      wq2.oninput = function () { if (!wq2.value.trim() && wrongKw) { wrongKw = ''; renderWrongList(); } };
    }
    var wq2c = $('#wrongQ2Clear');
    if (wq2c) wq2c.onclick = function () { wrongKw = ''; if (wq2) wq2.value = ''; renderWrongList(); };
    var wsHost = $('#wrongSort');
    if (wsHost) wsHost.addEventListener('click', function (e) {
      var c = e.target.closest('[data-ws]'); if (!c) return;
      wrongSort = c.dataset.ws; renderWrongList();
    });
    var wp = $('#wrongPractice');
    if (wp) wp.onclick = function () {
      var all = wrongWordsOf(wrongKind);
      var pool = (wrongKw ? all.filter(function (w) { return dictScore(w, wrongKw) > 0; }) : all).slice(0, 30);
      startPractice(pool, kindMeta(wrongKind).name);
    };
    var wb1 = $('#wrongBack1'); if (wb1) wb1.onclick = wrongBack;
    var wb2 = $('#wrongBack2'); if (wb2) wb2.onclick = wrongBack;
    var wc = $('#wrongClear');
    if (wc) wc.onclick = function () {
      var n = 0;
      Object.keys(progress).forEach(function (k) {
        if (progress[k].wrong > 0 && progress[k].s >= MASTER_STAGE) { progress[k].wrong = 0; n++; }
      });
      if (!n) { toast('还没有已掌握的错词可清'); return; }
      saveAll(); renderWrong(); toast('清掉了 ' + n + ' 个已掌握的词');
    };

    // 打卡
    var ckB = $('#ckBtn');
    if (ckB) ckB.onclick = doCheckin;

    // 设置页
    var sSave = $('#setSave');
    if (sSave) sSave.onclick = saveSettingsFromPage;
    var sReset = $('#setReset');
    if (sReset) sReset.onclick = function () {
      settings = defaultSettings();
      settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
      saveAll(); renderPlan(); renderHome(); renderSettings();
      toast('已恢复默认（四级 / 下一个考试日 / 40 分钟）');
    };
    // P1-4：打包逻辑独立出来 —— 「导出文件」与「复制备份文本」用同一份，避免两边字段跑偏
    function buildPack() {
      return {
        app: 'wudu', at: todayStr(), v: 2,
        progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin,
        grammar: load('wudu.grammar.v1', {}), translate: load('wudu.translate.v1', {}),
        focus: load('wudu.focus.v1', []), quiz: load('wudu.quiz.v1', null)
      };
    }
    // 导入校验与落地（文件导入 / 剪贴板导入共用）—— 自检 D1/C3 的守卫都在这里
    function applyPack(o, done) {
      var isObj = function (x) { return !!x && typeof x === 'object' && !Array.isArray(x); };
      if (!isObj(o) || !isObj(o.progress) || !isObj(o.stats) || !isObj(o.settings)) {
        toast('导入失败：缺少必要字段（progress / stats / settings）');
        return false;
      }
      try {
        localStorage.setItem('wudu.preimport', JSON.stringify({
          at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
        }));
      } catch (e) {}
      progress = o.progress;
      stats = o.stats;
      adapt = isObj(o.adapt) ? o.adapt : { mode: 'auto', recent: [] };
      checkin = sanitizeCheckin(isObj(o.checkin) ? o.checkin : { days: [] });
      settings = Object.assign(defaultSettings(), o.settings);
      if (isObj(o.grammar)) save('wudu.grammar.v1', o.grammar);
      if (isObj(o.translate)) save('wudu.translate.v1', o.translate);
      if (Array.isArray(o.focus)) save('wudu.focus.v1', o.focus);
      try {
        renderHome(); renderPlan(); renderSettings();
        saveAll();
        if (done) done();
      } catch (e) {
        toast('导入完成，但页面渲染出错：' + e.message + '（已留导入前快照）');
      }
      return true;
    }

    var sExp = $('#setExport');
    if (sExp) sExp.onclick = function () {
      try {
        var pack = buildPack();
        var blob = new Blob([JSON.stringify(pack)], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'wudu-backup-' + todayStr() + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        toast('已导出学习数据');
      } catch (e) { toast('导出失败：' + e.message); }
    };
    // 清单 P0-3：错词本导出 CSV（UTF-8 BOM，Excel 不乱码，也能导进 Anki）
    var sCsv = $('#setWrongCsv');
    if (sCsv) sCsv.onclick = function () {
      var ws = wrongWords();
      if (!ws.length) { toast('错题本是空的，先去做几道题'); return; }
      var head = ['word', 'phonetic', 'pos', 'cn', '错次', '错误形式', '最近错日', '下次复习'];
      var rows = [head];
      ws.forEach(function (w) {
        var r = progress[w.w] || {};
        var kinds = ERR_KINDS.filter(function (e) { return e.k !== 'hot' && errCount(r, e.k) > 0; })
          .map(function (e) { return e.name + '×' + errCount(r, e.k); }).join(' / ');
        rows.push([w.w, w.ph || '', w.pos || '', w.cn || '', r.wrong || 0,
          kinds || (r.lastErr ? (ERR_NAME[r.lastErr] || '') : ''), r.lastErrDate || '', r.due || '']);
      });
      var csv = rows.map(function (row) {
        return row.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(',');
      }).join('\r\n');
      try {
        var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'wudu-wrong-' + todayStr() + '.csv';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        toast('已导出 ' + ws.length + ' 个错词（CSV）');
      } catch (e) { toast('导出失败：' + e.message); }
    };

    // P1-4：把备份文本塞进剪贴板（手机端「发给自己」就这么走）
    var sCopy = $('#setCopyPack');
    if (sCopy) sCopy.onclick = function () {
      var txt;
      try { txt = JSON.stringify(buildPack()); }
      catch (e) { toast('打包失败：' + e.message); return; }
      var okTip = '已复制备份文本 · 粘到微信发给自己，电脑端「从剪贴板导入」就能接上';
      var fallback = function () {
        try {
          var ta = document.createElement('textarea');
          ta.value = txt;
          ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.select();
          var ok = document.execCommand('copy');
          ta.remove();
          toast(ok ? okTip : '这个环境不让复制 —— 改用「导出」存文件');
        } catch (e) { toast('复制失败，改用「导出」存文件'); }
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(function () { toast(okTip); }, fallback);
      } else fallback();
    };

    // P1-4：从剪贴板导入（电脑上复制好，手机上粘）
    var sPaste = $('#setPasteImport');
    if (sPaste) sPaste.onclick = function () {
      var go2 = function (txt) {
        var o = null;
        try { o = JSON.parse(String(txt || '').trim()); }
        catch (e) { toast('剪贴板里不是备份文本（JSON 解析失败）'); return; }
        applyPack(o, function () { toast('已从剪贴板导入学习数据'); });
      };
      if (navigator.clipboard && navigator.clipboard.readText) {
        navigator.clipboard.readText().then(go2, function () {
          var t = window.prompt('浏览器不让直接读剪贴板 —— 把备份文本粘到这里：', '');
          if (t) go2(t);
        });
      } else {
        var t2 = window.prompt('把备份文本粘到这里：', '');
        if (t2) go2(t2);
      }
    };

    var sImp = $('#setImport'), sImpF = $('#setImportFile');
    if (sImp && sImpF) {
      sImp.onclick = function () { sImpF.click(); };
      sImpF.onchange = function () {
        var f = sImpF.files && sImpF.files[0]; if (!f) return;
        var fr = new FileReader();
        fr.onload = function () {
          var o = null;
          try { o = JSON.parse(String(fr.result)); }
          catch (e) { toast('导入失败：这不是有效的 JSON 文件'); return; }
          // P1-4：校验与落地统一走 applyPack（与剪贴板导入同一套守卫）
          applyPack(o, function () { toast('已导入学习数据'); });
        };
        fr.readAsText(f);
      };
    }
    /* ---------- P1-4 多端互通（局域网直传，同源、不碰公网） ----------
       2026-09-25 昀晞「默认就能互通」：
         · 电脑上：node serve.js 8899 --lan（/sync 端点默认开）
         · 电脑上打开的网页，服务端会把配对码自动告诉它（只回给本机来源）→ 不用手输
         · 手机连同一 Wi-Fi 打开电脑给的地址，点「🔁 一键互传」即可
       合并策略：同一个词谁学得更晚用谁的 —— 不做整包覆盖，免得新进度被旧包冲掉。 */
    var syncAutoCode = '';   // 服务端自动给的配对码（只在本机来源时会给）
    function syncCode() {
      var c = $('#setSyncCode');
      var typed = c ? String(c.value || '').trim() : '';
      return typed || syncAutoCode;   // 手输的优先（手机端），其次用自动拿到的（电脑端）
    }
    function syncNote(txt, bad) {
      var n = $('#setSyncNote');
      if (!n) return;
      n.textContent = txt || '';
      n.style.color = bad ? 'var(--bad)' : 'var(--text-3)';
    }
    function mergeIntoPack(theirs) {
      var isObj = function (x) { return !!x && typeof x === 'object' && !Array.isArray(x); };
      if (!isObj(theirs) || !isObj(theirs.progress)) return null;
      var merged = 0, fresh = 0;
      Object.keys(theirs.progress).forEach(function (k) {
        var t = theirs.progress[k], m = progress[k];
        if (!t) return;
        if (!m) { progress[k] = t; fresh++; return; }
        var tl = String(t.last || ''), ml = String(m.last || '');
        var take = false;
        if (tl !== ml) take = tl > ml;
        else {
          take = (Number(t.s) || 0) > (Number(m.s) || 0) ||
            ((Number(t.s) || 0) === (Number(m.s) || 0) && (Number(t.seen) || 0) > (Number(m.seen) || 0));
        }
        if (take) { progress[k] = t; merged++; }
      });
      // 统计按天取「每项较大值」：两端同一天都学过时不重复累加，也不会互相抹掉
      if (isObj(theirs.stats)) {
        Object.keys(theirs.stats).forEach(function (d) {
          var t = theirs.stats[d], m = stats[d];
          if (!isObj(t)) return;
          if (!m) { stats[d] = t; return; }
          ['answered', 'right', 'wrong', 'newWords', 'papers'].forEach(function (f) {
            m[f] = Math.max(Number(m[f]) || 0, Number(t[f]) || 0);
          });
        });
      }
      // 打卡日历取并集
      if (isObj(theirs.checkin) && Array.isArray(theirs.checkin.days)) {
        var seen = {};
        checkin.days.forEach(function (d) { seen[d] = 1; });
        theirs.checkin.days.forEach(function (d) {
          if (typeof d === 'string' && !seen[d]) { checkin.days.push(d); seen[d] = 1; }
        });
        checkin.days.sort();
      }
      return { merged: merged, fresh: fresh };
    }
    function syncCall(path, opt) {
      var url = path + (path.indexOf('?') >= 0 ? '&' : '?') + 'code=' + encodeURIComponent(syncCode());
      return fetch(url, opt).then(function (r) {
        return r.json().catch(function () { return { ok: false, err: 'HTTP ' + r.status }; })
          .then(function (j) {
            if (!r.ok || j.ok === false) throw new Error(j.err || ('HTTP ' + r.status));
            return j;
          });
      });
    }
    function syncProbe() {
      var host = $('#setSyncBox');
      fetch('/sync/ping', { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          if (!host) return;
          if (j && j.on) {
            if (j.code) {
              // 本机来源：服务端把配对码直接给了 —— 填进框里看得见、可改，也当成默认码用
              syncAutoCode = String(j.code);
              var cEl = $('#setSyncCode');
              if (cEl && !cEl.value) cEl.value = syncAutoCode;
              syncNote('已连上电脑端（' + j.host + ':' + j.port + '）· 配对码已自动带上，点「🔁 一键互传」就行');
            } else {
              syncNote('电脑端同步已开（' + j.host + ':' + j.port + '）—— 填上控制台打印的配对码就能对传');
            }
          } else if (j) syncNote('电脑端跑着服务但同步被关了：启动时去掉 --no-sync');
          else syncNote('这台设备不是从电脑端服务打开的（手机要和电脑同一 Wi-Fi，并用电脑给的地址打开本页）');
        })
        .catch(function () {
          if (host) syncNote('连不到电脑端服务：手机需与电脑同一 Wi-Fi，并用电脑端地址打开本页');
        });
    }
    /* 一键互传：先拉（把另一端的进度并进来）再推（把合并后的整包发回去），
       省掉「先点取、再点传」两步。合并仍走 mergeIntoPack 的「谁学得晚用谁」。 */
    var sBoth = $('#setSyncBoth');
    if (sBoth) sBoth.onclick = function () {
      if (!syncCode()) { toast('还没拿到配对码 —— 确认电脑端服务开着，或手动填控制台那 6 位'); return; }
      toast('正在与另一端互传…');
      syncCall('/sync/latest').then(function (j) {
        var pack = null;
        try { pack = JSON.parse(j.data); } catch (e) { throw new Error('文件不是合法 JSON'); }
        var r = mergeIntoPack(pack) || { fresh: 0, merged: 0 };
        saveAll();
        return syncCall('/sync/put', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(buildPack())
        }).then(function (p) {
          renderHome(); renderPlan(); renderSettings();
          syncNote('互传完成：并入 ' + r.fresh + ' 新词 / 更新 ' + r.merged + ' 词，再把本机 ' + p.words + ' 条推了回去');
          toast('已互传');
        });
      }).catch(function (e) {
        syncNote('互传失败：' + e.message, true);
        toast('互传失败：' + e.message);
      });
    };
    var sPush = $('#setSyncPush'), sPull = $('#setSyncPull');
    if (sPush) sPush.onclick = function () {
      if (!syncCode()) { toast('先填电脑控制台上打印的 6 位配对码'); return; }
      toast('正在上传…');
      syncCall('/sync/put', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildPack())
      }).then(function (j) {
        syncNote('已上传：' + j.file + '（' + j.words + ' 条进度）');
        toast('已传到电脑');
      }).catch(function (e) {
        syncNote('上传失败：' + e.message, true);
        toast('上传失败：' + e.message);
      });
    };
    if (sPull) sPull.onclick = function () {
      if (!syncCode()) { toast('先填电脑控制台上打印的 6 位配对码'); return; }
      syncCall('/sync/latest').then(function (j) {
        var pack = null;
        try { pack = JSON.parse(j.data); } catch (e) { throw new Error('文件不是合法 JSON'); }
        var r = mergeIntoPack(pack);
        if (!r) throw new Error('拿到的不是雾读备份包');
        saveAll();
        renderHome(); renderPlan(); renderSettings();
        syncNote('已合并：新学 ' + r.fresh + ' 词，更新 ' + r.merged + ' 词');
        toast('已从电脑合并（新 ' + r.fresh + ' / 更新 ' + r.merged + '）');
      }).catch(function (e) {
        syncNote('拉取失败：' + e.message, true);
        toast('拉取失败：' + e.message);
      });
    };
    syncProbe();
    var sWipe = $('#setWipe');
    if (sWipe) sWipe.onclick = function () {
      if (!confirm('清空全部进度？词库记录、统计、打卡都会归零。\n（会先存一份快照，误点可找回）')) return;
      // 自检 D4：清空前留快照（独立键、不进镜像），否则连后路一起清掉
      try {
        localStorage.setItem('wudu.prewipe', JSON.stringify({
          at: Date.now(), progress: progress, stats: stats, settings: settings, adapt: adapt, checkin: checkin
        }));
      } catch (e) {}
      progress = {}; stats = {}; adapt = { mode: 'auto', recent: [] }; checkin = { days: [] };
      // 自检 F3：旧版漏清语法 / 翻译 / 专注 / 未完成会话 —— 清完报告页还显示旧数据，还会弹「继续上次」
      save('wudu.grammar.v1', {}); save('wudu.translate.v1', {}); save('wudu.focus.v1', []);
      grammarProg = {}; trProg = {}; focusLog = []; focusLast = '';
      clearQuizSession();
      saveAll(); renderHome(); renderPlan(); renderSettings();
      toast('已清空，一切从头开始');
    };
    var voiceBtn = $('#setVoice');
    if (voiceBtn) voiceBtn.onclick = function () {
      settings.voice = (settings.voice === 'uk') ? 'us' : 'uk';
      saveAll(); renderSettings();
      toast(settings.voice === 'uk' ? '已切到英音（高频词 2378 条，其余自动用美音）' : '已切回美音');
      var w = (dictState.picked) || 'welcome';
      speak(w === 'welcome' ? 'welcome' : w);   // 立刻试听一句，免得不知道有没有生效
    };
    var rt2 = $('#ttsRate');
    if (rt2) rt2.oninput = function () {
      tts.rate = parseFloat(rt2.value) || 0.95;
      if ($('#ttsRateTxt')) $('#ttsRateTxt').textContent = tts.rate.toFixed(2) + '×';
      try { localStorage.setItem('wudu.tts.rate', String(tts.rate)); } catch (e) {}
    };
    try {
      var savedRate = parseFloat(localStorage.getItem('wudu.tts.rate'));
      if (savedRate) tts.rate = savedRate;
    } catch (e) {}

    // 真题
    $('#realFilter').addEventListener('click', function (e) {
      var l = e.target.closest('[data-rl]'), t = e.target.closest('[data-rt]');
      if (l) realFilter.level = l.dataset.rl;
      if (t) realFilter.type = t.dataset.rt;
      renderRealList();
    });
    $('#realList').addEventListener('click', function (e) {
      var it = e.target.closest('[data-paper]'); if (!it) return;
      openPaper(it.dataset.paper);
    });

    // 语法
    $('#grammarFilter').addEventListener('click', function (e) {
      var c = e.target.closest('[data-gp]'); if (!c) return;
      gState.point = c.dataset.gp; renderGrammarList();
    });

    // 翻译
    $('#trFilter').addEventListener('click', function (e) {
      var c = e.target.closest('[data-tl]'); if (!c) return;
      trFilter.level = c.dataset.tl; renderTrList();
    });
    $('#trList').addEventListener('click', function (e) {
      var it = e.target.closest('[data-tr]'); if (!it) return;
      openTr(it.dataset.tr);
    });

    // 听力
    $('#lsFilter').addEventListener('click', function (e) {
      var c = e.target.closest('[data-ll]'); if (!c) return;
      lsFilter.level = c.dataset.ll; renderLsList();
    });
    $('#lsList').addEventListener('click', function (e) {
      var it = e.target.closest('[data-ls]'); if (!it) return;
      openLs(it.dataset.ls);
    });

    // 写作
    $('#wrFilter').addEventListener('click', function (e) {
      var c = e.target.closest('[data-wl]'); if (!c) return;
      wrFilter.level = c.dataset.wl; renderWrList();
    });
    $('#wrList').addEventListener('click', function (e) {
      var it = e.target.closest('[data-wr]'); if (!it) return;
      openWr(it.dataset.wr);
    });

    // 专注：第 1 步选内容 → 第 2 步定时间 → 开始进训练界面
    $$('#focusTaskPick .mode-card').forEach(function (b) {
      b.onclick = function () {
        $$('#focusTaskPick .mode-card').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        focusState.task = b.dataset.task;
        focusGoStep(2);
      };
    });
    var fb1 = $('#focusBack1');
    if (fb1) fb1.onclick = function () { focusGoStep(1); };
    $('#focusStart').onclick = startFocus;
    $('#fbPause').onclick = function () {
      if (!focusState.on) return;
      focusState.paused = !focusState.paused;
      $('#fbPause').textContent = focusState.paused ? '继续' : '暂停';
      toast(focusState.paused ? '已暂停计时' : '继续专注');
    };
    // 结束专注要二次确认（防手滑退出）
    var stopArmed = false, stopTimer = null;
    function disarmStop() {
      stopArmed = false;
      clearTimeout(stopTimer);
      var b = $('#fbStop');
      if (b) b.textContent = '结束专注';
    }
    $('#fbStop').onclick = function () {
      if (!focusState.on) return;
      if (!stopArmed) {
        stopArmed = true;
        $('#fbStop').textContent = '再点一次结束';
        stopTimer = setTimeout(disarmStop, 3000);
        return;
      }
      disarmStop();
      endFocus(false);
    };
    // 休息锁屏：长按 3 秒才能跳过
    var breakHold = null;
    var skipBtn = $('#breakSkip');
    skipBtn.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      if (breakHold) return;
      skipBtn.textContent = '别松手… 3';
      breakHold = setTimeout(function () {
        breakHold = null;
        skipBtn.textContent = '长按 3 秒跳过休息';
        skipBreak(false);
      }, 3000);
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) {
      skipBtn.addEventListener(ev, function () {
        if (breakHold) {
          clearTimeout(breakHold);
          breakHold = null;
          skipBtn.textContent = '松早了，再来一次（长按 3 秒）';
          setTimeout(function () { skipBtn.textContent = '长按 3 秒跳过休息'; }, 1400);
        }
      });
    });

    // 计划
    $('#planGen').onclick = function () {
      settings.level = $('#planLevel').value;
      settings.examDate = $('#planDate').value || defaultExamDate();
      settings.minutes = Math.max(5, parseInt($('#planMinutes').value, 10) || 40);
      settings.restDays = Math.max(0, Math.min(3, parseInt($('#planRest').value, 10) || 0));
      settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
      saveAll(); drawPlan(settings.plan);
      pgGo('#planTabs', 'plan');
      toast('计划已更新 · 往下看结果');
    };
    $('#planReset').onclick = function () {
      settings = defaultSettings();
      settings.plan = planOf(settings.level, settings.examDate, settings.minutes, settings.restDays);
      saveAll(); renderPlan(); toast('已恢复默认（四级 / 下一个考试日 / 40 分钟）');
    };

    // 全局快捷键：Esc 返回上一层，数字键选项
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        if ($('#view-real').classList.contains('on') && pgCurrent('#realTabs') === 'run') { closePaper(); return; }
        if ($('#view-grammar').classList.contains('on') && pgCurrent('#grammarTabs') === 'run') { renderGrammarList(); return; }
        if ($('#view-translate').classList.contains('on') && pgCurrent('#trTabs') === 'run') { renderTrList(); return; }
        if ($('#view-write').classList.contains('on') && pgCurrent('#wrTabs') === 'run') { renderWrList(); return; }
      }
      if ($('#view-grammar').classList.contains('on') && gState.run && !gState.run.answered) {
        var n = parseInt(e.key, 10);
        if (n >= 1 && n <= 4) { var o = $$('#gOpts .opt')[n - 1]; if (o) o.click(); }
      }
    });

    // 键盘快捷键（默写/认词）
    document.addEventListener('keydown', function (e) {
      if (!$('#view-quiz').classList.contains('on')) return;
      // 2026-09-25 昀晞（手机端反馈）：回车不再自动跳下一题 —— 提交完要能先看清答案、
      // 接着改字重判。翻页只走屏幕上的「下一题 →」按钮，免得软键盘回车把答案一闪带过。
      var cur = quiz && quiz.queue && quiz.queue[quiz.pos];
      if (quiz && !quiz.answered && cur && cur.dir === 'en2cn') {
        var n = parseInt(e.key, 10);
        if (n >= 1 && n <= 4) {
          var opts = $$('#quizOpts .opt');
          if (opts[n - 1]) opts[n - 1].click();
        }
      }
    });
  }

  /* ---------------- 启动 ---------------- */
  function apiApp() {
    try { return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) || null; } catch (e) { return null; }
  }
  // 每日学习提醒 + 考前一晚提醒：只有装成 APK 才真的发得出来
  function applyReminders() {
    var NAT = window.WUDU_NATIVE;
    if (!NAT || !NAT.isNative) return;
    if (settings.remind === false) { NAT.cancelDaily(); return; }
    var at = String(settings.remindAt || '20:00').split(':');
    var h = parseInt(at[0], 10), m = parseInt(at[1], 10);
    if (isNaN(h) || isNaN(m)) { h = 20; m = 0; }
    NAT.daily(h, m).then(function (ok) {
      if (ok === false && NAT.permission) NAT.permission();
    });
    if (settings.examDate) NAT.examReminder(settings.examDate);
  }
  var VIEWS = ['home', 'dict', 'quiz', 'grammar', 'listening', 'translate', 'write', 'real', 'focus', 'wrong', 'plan', 'report', 'settings'];

  /* P1-8：启动水合 —— 首屏仍**同步**读 localStorage（不能为异步等待拖慢开屏），
     随后在后台问 IndexedDB 要最新的一份：内容不同才覆盖内存 + 重渲染当前页。
     迁移：IDB 里还没有该键、localStorage 里有 → 搬过去（绝不覆盖 IDB 已有数据）。 */
  function hydrateFromStore() {
    var S = window.WUDU_STORE;
    if (!S || !S.ready) return;
    S.ready.then(function (ok) {
      if (!ok) return null;
      return S.migrate([LS_PROGRESS, LS_STATS]);
    }).then(function () {
      return Promise.all([S.get(LS_PROGRESS), S.get(LS_STATS)]);
    }).then(function (rows) {
      if (!rows) return;
      var changed = [];
      var pair = [
        [LS_PROGRESS, rows[0], function (o) { progress = o; }],
        [LS_STATS, rows[1], function (o) { stats = o; }]
      ];
      pair.forEach(function (p) {
        if (!p[1]) return;
        var cur = null;
        try { cur = JSON.stringify(p[0] === LS_PROGRESS ? progress : stats); } catch (e) { cur = null; }
        if (cur === p[1]) return;                       // 与内存一致，不动
        try { p[2](JSON.parse(p[1])); changed.push(p[0]); } catch (e) {}
      });
      if (!changed.length) return;
      invalidateCounts();
      if (window.__wudu) { window.__wudu.progress = progress; window.__wudu.stats = stats; }
      var v = (location.hash || '').replace('#', '');
      go(VIEWS.indexOf(v) >= 0 ? v : 'home');           // 重渲染，让恢复的数据立刻可见
      try { console.log('[雾读] 已从 IndexedDB 恢复：' + changed.join('、')); } catch (e) {}
    }).catch(function () {});
  }

  function boot() {
    buildWordBank();
    a11yInit();          // P1-10：先把静态语义补齐（动态节点由 MutationObserver 跟）
    bindGlobal();
    ttsInit();
    var startView = (location.hash || '').replace('#', '');
    go(VIEWS.indexOf(startView) >= 0 ? startView : 'home');
    // 支持 #hash 直达（PWA 快捷方式 / 收藏夹）
    window.addEventListener('hashchange', function () {
      var v = (location.hash || '').replace('#', '');
      if (VIEWS.indexOf(v) >= 0) go(v);
    });
    if (!WORDS.length) {
      toast('词库数据未加载，请检查 assets/js/data/ 下的文件');
    }
    hydrateFromStore();          // P1-8：异步水合（不阻塞首屏）
    // 顶部提示：到期复习
    var c = counts();
    if (c.due > 0) setTimeout(function () { toast('今天有 ' + c.due + ' 个词到期待复习'); }, 700);
    // 开屏动画收尾：等首页第一次渲染完再淡出，避免闪白
    var sp = document.getElementById('splash');
    if (sp) {
      setTimeout(function () {
        sp.classList.add('out');
        setTimeout(function () { if (sp.parentNode) sp.parentNode.removeChild(sp); }, 600);
      }, 900);
    }
    // 原生外壳（APK 里才生效）：状态栏 / 键盘 / 启动图 / 存储镜像 / 系统提醒
    var NAT = window.WUDU_NATIVE;
    if (NAT && NAT.isNative) {
      NAT.init();
      setTimeout(function () { NAT.hideSplash(); }, 260);
      NAT.restore().then(function (n) {
        // 只会在「localStorage 被清空但原生镜像还在」时命中，补回来重载一次
        if (n > 0 && !sessionStorage.getItem('wudu.restored')) {
          try { sessionStorage.setItem('wudu.restored', '1'); } catch (e) {}
          location.reload();
        }
      });
      applyReminders();
      if (apiApp()) apiApp().addListener('appStateChange', function (st) {
        if (st.isActive) { applyReminders(); renderCheckin && renderCheckin(); }
      });
    }
    window.__wudu = {
      WORDS: WORDS, progress: progress, settings: settings, stats: stats,
      // 便于自测/排障的纯函数出口（不参与业务流程）
      judge: judge, normalizeAns: normalizeAns, lev: lev, diffHtml: diffHtml,
      dynamicToday: dynamicToday, planOf: planOf,
      GRAMMAR: GRAMMAR, TRBANK: TRBANK, WKIT: WKIT
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
