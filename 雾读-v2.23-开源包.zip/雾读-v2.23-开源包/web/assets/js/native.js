/* 雾读 · 原生外壳桥（Capacitor）
   ------------------------------------------------------------------
   浏览器里打开时这一层全部降级为 no-op；装成 APK 时才走原生插件。
   覆盖：状态栏融入 / 原生震动 / 启动图 / 系统通知提醒 / 原生存储镜像 / 键盘避让。
   设计原则：能力探测（有才用），失败静默（不打断学习）。 */
(function () {
  var C = window.Capacitor;
  var isNative = !!(C && C.isNativePlatform && C.isNativePlatform());

  function P(name) {
    try { return (C && C.Plugins && C.Plugins[name]) || null; } catch (e) { return null; }
  }
  function quiet(p) { if (p && typeof p.catch === 'function') p.catch(function () {}); return p; }

  var DAILY_ID = 1001, EXAM_ID = 1002;

  var N = window.WUDU_NATIVE = {
    isNative: isNative,

    /* ---- 触感：手机上用原生 Haptics（WebView 的 navigator.vibrate 常年不生效）---- */
    haptic: function (kind) {
      var H = P('Haptics');
      if (!H) return false;
      try {
        if (kind === 'ok') quiet(H.notification({ type: 'SUCCESS' }));
        else if (kind === 'no') quiet(H.notification({ type: 'ERROR' }));
        else quiet(H.impact({ style: 'MEDIUM' }));
        return true;
      } catch (e) { return false; }
    },

    /* ---- 存储镜像：localStorage 之外再存一份原生 Preferences，清缓存不丢进度 ---- */
    store: function (key, value) {
      var S = P('Preferences');
      if (!S) return;
      try {
        if (value === null || value === undefined) quiet(S.remove({ key: 'wudu:' + key }));
        else quiet(S.set({ key: 'wudu:' + key, value: String(value) }));
      } catch (e) {
        // 自检 M7：镜像写失败原先一点痕迹都没有，而界面正承诺「清缓存不丢进度」—— 至少留个日志
        try { console.warn('[雾读] 原生镜像写入失败', key, e && e.message); } catch (_) {}
      }
    },
    restore: function () {
      var S = P('Preferences');
      if (!S || !window.localStorage) return Promise.resolve(0);
      // 自检 M5：原清单里有根本不存在的 wudu.write.v1，却漏了 wudu.quiz.v1（断点续学的进度）
      var keys = ['wudu.progress.v1', 'wudu.settings.v1', 'wudu.stats.v1', 'wudu.grammar.v1',
        'wudu.translate.v1', 'wudu.focus.v1', 'wudu.quiz.v1', 'wudu.adapt.v1', 'wudu.checkin.v1'];
      var healed = 0;
      return Promise.all(keys.map(function (k) {
        return S.get({ key: 'wudu:' + k }).then(function (r) {
          var cur = localStorage.getItem(k);
          if (!cur && r && r.value) { localStorage.setItem(k, r.value); healed++; }
          return null;
        }).catch(function () { return null; });
      })).then(function () { return healed; });
    },

    /* ---- 状态栏：跟随页面明暗，覆盖在 WebView 之上（页面自己留安全区）---- */
    applyStatusBar: function () {
      var SB = P('StatusBar');
      if (!SB) return;
      var dark = document.documentElement.getAttribute('data-theme') === 'dark';
      try {
        quiet(SB.setOverlaysWebView({ overlay: false }));
        quiet(SB.setBackgroundColor({ color: dark ? '#0f1922' : '#ffffff' }));
        quiet(SB.setStyle({ style: dark ? 'DARK' : 'LIGHT' }));
      } catch (e) {}
    },

    /* ---- 系统通知：每日学习提醒 + 考前一天提醒（App 才有的能力）---- */
    permission: function () {
      var L = P('LocalNotifications');
      if (!L) return Promise.resolve(false);
      return L.checkPermissions().then(function (p) {
        if (p.display === 'granted') return true;
        return L.requestPermissions().then(function (p2) { return p2.display === 'granted'; });
      }).catch(function () { return false; });
    },
    daily: function (hour, minute, tip) {
      var L = P('LocalNotifications');
      if (!L) return Promise.resolve(false);
      return this.permission().then(function (ok) {
        if (!ok) return false;
        return L.cancel({ notifications: [{ id: DAILY_ID }] })
          .catch(function () {})
          .then(function () {
            return L.schedule({
              notifications: [{
                id: DAILY_ID,
                title: '雾读 · 今日份单词',
                body: tip || '到点了，把今天该复习的词清一遍 —— 十分钟就够。',
                schedule: { on: { hour: hour, minute: minute }, repeats: true, allowWhileIdle: true }
              }]
            });
          }).then(function () { return true; }).catch(function () { return false; });
      });
    },
    cancelDaily: function () {
      var L = P('LocalNotifications');
      if (!L) return Promise.resolve(false);
      return L.cancel({ notifications: [{ id: DAILY_ID }] }).then(function () { return true; }).catch(function () { return false; });
    },
    examReminder: function (examDate, daysLeft) {
      var L = P('LocalNotifications');
      if (!L || !examDate) return Promise.resolve(false);
      var at = new Date(examDate + 'T20:00:00');
      if (isNaN(at.getTime()) || at.getTime() < Date.now()) return Promise.resolve(false);
      return this.permission().then(function (ok) {
        if (!ok) return false;
        return L.cancel({ notifications: [{ id: EXAM_ID }] }).catch(function () {}).then(function () {
          return L.schedule({
            notifications: [{
              id: EXAM_ID,
              title: '雾读 · 明天就是考试日',
              body: '今晚别开新词了，把错题本里「反复错」那一类过一遍就收工。',
              schedule: { at: at, allowWhileIdle: true }
            }]
          });
        }).then(function () { return true; }).catch(function () { return false; });
      });
    },

    /* ---- 键盘：让 WebView 收缩而不是整体上推（底部 Tab 不被顶飞）---- */
    initKeyboard: function () {
      var K = P('Keyboard');
      if (!K) return;
      try {
        if (K.setResizeMode) quiet(K.setResizeMode({ mode: 'native' }));
        if (K.setScroll) quiet(K.setScroll({ isDisabled: false }));
      } catch (e) {}
    },

    /* ---- 启动：隐藏原生启动图（页面自己的开屏动画接管）---- */
    hideSplash: function () {
      var S = P('SplashScreen');
      if (!S) return;
      try { quiet(S.hide({ fadeDuration: 220 })); } catch (e) {}
    },
    keepSplash: function () {
      var S = P('SplashScreen');
      if (!S) return;
      try { quiet(S.show({ duration: 900 })); } catch (e) {}
    },

    init: function () {
      if (!isNative) return;
      this.initKeyboard();
      this.applyStatusBar();
    }
  };

  N.init();
})();
