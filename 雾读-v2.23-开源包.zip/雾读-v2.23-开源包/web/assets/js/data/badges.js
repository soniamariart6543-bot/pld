// 雾读 · 成就徽章定义（window.WUDU_BADGES）
// kind：streak 连续学习天数 / mastered 已掌握词数 / answered 累计答题数 /
//       focus 累计专注分钟 / wrongFixed 错词转掌握数 / accuracy 单日正确率（need 为百分比整数，minAnswered 为当日最低答题数）
window.WUDU_BADGES = [
  { id: "firstDay", name: "第一天", icon: "🌱", desc: "完成第一次学习", kind: "streak", need: 1 },
  { id: "streak3", name: "三日之约", icon: "🕯️", desc: "连续 3 天有学习记录", kind: "streak", need: 3 },
  { id: "streak7", name: "连续一周", icon: "🔥", desc: "连续 7 天有学习记录", kind: "streak", need: 7 },
  { id: "streak14", name: "两周不断", icon: "🌙", desc: "连续 14 天有学习记录", kind: "streak", need: 14 },
  { id: "streak30", name: "满月自习", icon: "🪐", desc: "连续 30 天有学习记录", kind: "streak", need: 30 },
  { id: "streak100", name: "百日之静", icon: "🌌", desc: "连续 100 天有学习记录", kind: "streak", need: 100 },
  { id: "master10", name: "初识十词", icon: "🌾", desc: "掌握 10 个词（记忆阶段 ≥5）", kind: "mastered", need: 10 },
  { id: "master100", name: "百词入册", icon: "📖", desc: "掌握 100 个词（记忆阶段 ≥5）", kind: "mastered", need: 100 },
  { id: "master500", name: "半千小径", icon: "🧭", desc: "掌握 500 个词（记忆阶段 ≥5）", kind: "mastered", need: 500 },
  { id: "master1000", name: "千词达成", icon: "📚", desc: "掌握 1000 个词（记忆阶段 ≥5）", kind: "mastered", need: 1000 },
  { id: "master2500", name: "两千半程", icon: "🗂️", desc: "掌握 2500 个词（记忆阶段 ≥5）", kind: "mastered", need: 2500 },
  { id: "master4000", name: "四千词汇", icon: "🏔️", desc: "掌握 4000 个词（记忆阶段 ≥5）", kind: "mastered", need: 4000 },
  { id: "answered20", name: "答满二十", icon: "✏️", desc: "累计答题 20 道", kind: "answered", need: 20 },
  { id: "answered200", name: "两百落笔", icon: "🖊️", desc: "累计答题 200 道", kind: "answered", need: 200 },
  { id: "answered1000", name: "千题过手", icon: "📝", desc: "累计答题 1000 道", kind: "answered", need: 1000 },
  { id: "answered5000", name: "五千次落笔", icon: "🌊", desc: "累计答题 5000 道", kind: "answered", need: 5000 },
  { id: "focus15", name: "一刻钟", icon: "⏳", desc: "累计专注 15 分钟", kind: "focus", need: 15 },
  { id: "focus180", name: "三小时灯火", icon: "🕰️", desc: "累计专注 180 分钟", kind: "focus", need: 180 },
  { id: "focus1200", name: "二十小时", icon: "🌠", desc: "累计专注 1200 分钟", kind: "focus", need: 1200 },
  { id: "wrongFixed10", name: "拾回十词", icon: "🧺", desc: "把 10 个错词练到掌握", kind: "wrongFixed", need: 10 },
  { id: "wrongFixed50", name: "错词半百", icon: "🗝️", desc: "把 50 个错词练到掌握", kind: "wrongFixed", need: 50 },
  { id: "wrongFixed200", name: "两百次回头", icon: "🌿", desc: "把 200 个错词练到掌握", kind: "wrongFixed", need: 200 },
  { id: "accuracy90", name: "九成准确", icon: "🎯", desc: "单日答题满 20 且正确率 ≥90%", kind: "accuracy", need: 90, minAnswered: 20 },
  { id: "accuracy100", name: "一日无错", icon: "✨", desc: "单日答题满 30 且全对", kind: "accuracy", need: 100, minAnswered: 30 },
];
