window.WRITING_KIT = {
  topics: [
    {
      id: "culture-traditional-festival",
      level: "cet4",
      topic: "传统文化",
      title: "介绍一个中国传统节日",
      prompt: "Suppose your university is holding an essay contest on traditional Chinese festivals. Write an essay of 120-180 words about the festival you like most.",
      outline: ["点明你最喜欢的节日是什么", "介绍它的时间与主要习俗", "说明它对你的意义，收束全文"],
      sample: "The festival I like most is the Spring Festival, which is deeply rooted in Chinese culture. It usually falls in late January or early February, marking the beginning of a new lunar year. Preparations start weeks in advance. Families clean their houses, put up red couplets and prepare a big reunion dinner. On New Year's Eve, we gather around the table, share dishes such as dumplings and fish, and stay up late to welcome the new year. What makes the festival special to me is not the food but the reunion. Relatives who live far away come back home, and the custom of giving red envelopes passes down from generation to generation, carrying good wishes for the young. For me, the Spring Festival is more than a holiday. It reminds me where I come from and teaches me to value family above everything else. That is why I will always celebrate it with a full heart.",
      expressions: [
        { en: "be deeply rooted in", cn: "深深植根于" },
        { en: "pass down from generation to generation", cn: "代代相传" },
        { en: "mark the beginning of", cn: "标志着……的开始" },
        { en: "gather around the table", cn: "围坐在桌旁" },
        { en: "stay up late to welcome the new year", cn: "守岁迎新" },
        { en: "value A above everything else", cn: "把 A 看得比什么都重要" }
      ],
      upgrades: [
        { from: "important", to: "significant", cn: "重要的" },
        { from: "a lot of", to: "a considerable number of", cn: "大量的" },
        { from: "like", to: "be fond of", cn: "喜欢" },
        { from: "happy", to: "delighted", cn: "高兴的" },
        { from: "many people think", to: "it is widely believed that", cn: "许多人认为" }
      ],
      keywords: ["festival", "tradition", "custom", "celebrate", "reunion", "heritage"]
    },
    {
      id: "society-urban-transport",
      level: "cet4",
      topic: "社会发展",
      title: "谈谈城市公共交通的改善",
      prompt: "Suppose your university is holding an essay contest on social development. Write an essay of 120-180 words on the changes that urban public transport has brought to people's daily life.",
      outline: ["概述公共交通这些年的变化", "举例说明具体便利之处", "总结改善带来的益处并展望"],
      sample: "Over the past decade, urban public transport in China has changed beyond recognition, and these changes have had a far-reaching impact on the daily life of ordinary people. Subway lines have been extended to the suburbs, and shared bikes are available at almost every corner. As a result, a journey that once took an hour by bus now takes only twenty minutes. Moreover, mobile payment makes it possible to board a bus or a train without carrying any cash. These improvements benefit commuters in several ways. Students like me can save both time and money, while elderly citizens enjoy free or discounted rides. Cleaner energy also helps to reduce air pollution, which is good news for everyone. In my opinion, public transport is the backbone of a modern city. I hope that more small cities will enjoy the same convenience in the near future.",
      expressions: [
        { en: "change beyond recognition", cn: "变得今非昔比，让人认不出来" },
        { en: "have a far-reaching impact on", cn: "对……产生深远影响" },
        { en: "make it possible to do sth", cn: "使做某事成为可能" },
        { en: "save both time and money", cn: "既省时又省钱" },
        { en: "the backbone of", cn: "……的支柱" },
        { en: "in the near future", cn: "在不久的将来" }
      ],
      upgrades: [
        { from: "get better", to: "improve remarkably", cn: "明显改善" },
        { from: "very big", to: "enormous", cn: "巨大的" },
        { from: "easy", to: "convenient", cn: "方便的" },
        { from: "change", to: "transform", cn: "改变，使转变" },
        { from: "help", to: "contribute to", cn: "有助于" }
      ],
      keywords: ["transport", "commute", "convenience", "subway", "development", "urban", "efficiency"]
    },
    {
      id: "tech-online-learning",
      level: "cet4",
      topic: "科技与教育",
      title: "线上学习对大学生的影响",
      prompt: "Suppose your university is holding an essay contest on technology and education. Write an essay of 120-180 words on the effects of online learning on college students.",
      outline: ["说明线上学习已成为大学生活的一部分", "分析它的优势", "指出它的不足并提出你的看法"],
      sample: "With the rapid development of information technology, online learning has become an inseparable part of university life. Online courses offer us great flexibility. We can attend a lecture at midnight if we wish, pause a video and take notes, or replay a difficult part as many times as we need. What is more, we have access to first-class resources that were once out of reach for students in small cities. However, this convenience comes at a price. Without face-to-face contact, some students find it hard to concentrate, and they are easily distracted by short videos and games. In addition, a lack of immediate feedback may leave doubts unanswered. In my view, online learning should be regarded as a complement to, rather than a replacement for, traditional classes. Only by combining the two can we make the most of our college years.",
      expressions: [
        { en: "with the rapid development of", cn: "随着……的迅速发展" },
        { en: "an inseparable part of", cn: "……不可分割的一部分" },
        { en: "have access to", cn: "有机会获得，能够接触到" },
        { en: "out of reach", cn: "遥不可及，够不到" },
        { en: "come at a price", cn: "是有代价的" },
        { en: "make the most of", cn: "充分利用" }
      ],
      upgrades: [
        { from: "good", to: "beneficial", cn: "有益的" },
        { from: "bad", to: "harmful", cn: "有害的" },
        { from: "more and more", to: "an increasing number of", cn: "越来越多的" },
        { from: "can", to: "be capable of", cn: "能够" },
        { from: "use", to: "make use of", cn: "利用" }
      ],
      keywords: ["online", "course", "flexibility", "resource", "concentrate", "technology", "education"]
    },
    {
      id: "environment-green-living",
      level: "cet4",
      topic: "环境与健康",
      title: "低碳生活从我做起",
      prompt: "Suppose your university is holding an essay contest on environment and health. Write an essay of 120-180 words on how college students can live a low-carbon life.",
      outline: ["提出环保已成为一种生活方式", "列举你坚持的低碳小习惯", "说明这些小事的意义并发出倡议"],
      sample: "Environmental protection is no longer an abstract slogan; it has taken root in our campus. Low-carbon living actually starts with small habits. I always turn off the lights when I leave the dormitory and take my own shopping bag instead of using plastic ones. Moreover, I choose to walk or ride a shared bike rather than take a taxi for short distances. These habits may seem insignificant, but they add up. A single plastic bag takes hundreds of years to break down, while a saved kilowatt-hour of electricity means less coal burned at the power plant. What is more, when one student keeps such habits, roommates tend to follow. In conclusion, protecting the environment does not require great deeds, and the rewards are worth the effort in the long run. As long as everyone makes a contribution, we can pass down a cleaner planet from generation to generation.",
      expressions: [
        { en: "take root in", cn: "在……扎根" },
        { en: "start with small habits", cn: "从小习惯做起" },
        { en: "add up", cn: "积少成多，累积起来" },
        { en: "break down", cn: "分解，降解" },
        { en: "make a contribution", cn: "做出贡献" },
        { en: "in the long run", cn: "从长远来看" }
      ],
      upgrades: [
        { from: "important", to: "crucial", cn: "至关重要的" },
        { from: "do", to: "carry out", cn: "执行，开展" },
        { from: "save", to: "conserve", cn: "节约，保护" },
        { from: "waste", to: "squander", cn: "浪费" },
        { from: "protect", to: "preserve", cn: "保护，维护" }
      ],
      keywords: ["environment", "low-carbon", "recycle", "pollution", "habit", "energy", "sustainable"]
    },
    {
      id: "campus-club-activity",
      level: "cet4",
      topic: "校园生活",
      title: "参加社团活动的收获",
      prompt: "Suppose your university is holding an essay contest on campus life. Write an essay of 120-180 words about what you have gained from taking part in a student club.",
      outline: ["说明你参加了哪个社团", "讲述你在社团中的经历与变化", "总结收获并给新生建议"],
      sample: "Looking back on my first year at college, joining the English club was the decision I am proudest of. At the beginning I was a shy girl who could hardly speak in front of others. The club, however, gave me a stage. I took part in debate competitions, hosted a Christmas party and even interviewed a foreign teacher. Every activity pushed me one step forward. What I gained is far more than language skills. I learned how to cooperate with teammates, how to manage my time between study and rehearsals, and how to stay calm when things went wrong. These abilities will benefit me long after I graduate. All things considered, a club is not merely a place to kill time. It is a small society where we learn to grow, and I would encourage every freshman to find one that suits them.",
      expressions: [
        { en: "look back on", cn: "回顾" },
        { en: "take part in", cn: "参加" },
        { en: "push sb one step forward", cn: "促使某人前进一步" },
        { en: "far more than", cn: "远不止" },
        { en: "cooperate with", cn: "与……合作" },
        { en: "stay calm", cn: "保持冷静" }
      ],
      upgrades: [
        { from: "take part in", to: "participate in", cn: "参与" },
        { from: "help sb do", to: "enable sb to do", cn: "使某人能够做" },
        { from: "learn", to: "acquire", cn: "获得，习得" },
        { from: "happy", to: "rewarding", cn: "有收获的" },
        { from: "a lot of", to: "numerous", cn: "许多的" }
      ],
      keywords: ["club", "activity", "campus", "cooperate", "confidence", "freshman", "experience"]
    },
    {
      id: "growth-career-planning",
      level: "cet6",
      topic: "个人成长与职业规划",
      title: "大学生该如何规划职业",
      prompt: "Suppose your university is holding an essay contest on personal growth. Write an essay of 150-200 words on how college students should plan their careers.",
      outline: ["指出职业规划是每个大学生迟早要面对的事", "说明规划要建立在自我认知与实践之上", "强调规划是动态过程并总结"],
      sample: "Career planning is a topic that every university student will eventually have to face, yet many of us put off planning until the last semester. To begin with, a clear plan grows out of self-knowledge. Before choosing a direction, we should ask ourselves what we are genuinely good at and what kind of life we hope to lead. Internships and part-time jobs are valuable precisely because they turn abstract imagination into first-hand experience, and such experience also tells us which working environment we actually enjoy. Furthermore, planning does not mean rigidity. The job market changes so rapidly that a plan made three years ago may already be out of date. What matters is the ability to learn continuously and to keep pace with the times. In conclusion, career planning should be regarded as an ongoing process rather than a one-time task. The earlier we start, the more confidently we will step into the working world. A thoughtful plan made today will save us considerable anxiety tomorrow.",
      expressions: [
        { en: "put off", cn: "推迟，拖延" },
        { en: "grow out of", cn: "源自，产生于" },
        { en: "first-hand experience", cn: "亲身经历" },
        { en: "out of date", cn: "过时的" },
        { en: "keep pace with the times", cn: "与时代同步" },
        { en: "an ongoing process", cn: "一个持续的过程" }
      ],
      upgrades: [
        { from: "decide", to: "make a decision", cn: "做决定" },
        { from: "think", to: "hold the view that", cn: "持……的观点" },
        { from: "need", to: "require", cn: "需要" },
        { from: "get", to: "obtain", cn: "获得" },
        { from: "hard", to: "challenging", cn: "具有挑战性的" }
      ],
      keywords: ["career", "planning", "self-knowledge", "internship", "goal", "ability", "growth"]
    },
    {
      id: "internet-social-media-balance",
      level: "cet6",
      topic: "互联网与社交媒体",
      title: "社交媒体与真实社交的平衡",
      prompt: "Suppose your university is holding an essay contest on the Internet and social media. Write an essay of 150-200 words on how students can keep a balance between social media and real-life communication.",
      outline: ["描述社交媒体已融入校园生活", "承认它带来的便利", "指出过度使用的危害，提出应对办法"],
      sample: "Social media is now woven into the fabric of campus life. We check our phones the moment we wake up, share photographs over lunch, and fall asleep to the glow of a screen. There is no denying that social media brings real convenience. A message reaches a friend on the other side of the world within seconds, and study groups can exchange materials without ever meeting. For students far from home, a video call is a genuine comfort. Nevertheless, the line between staying connected and being addicted is easily crossed. Endless scrolling eats into time that should belong to reading and exercise, and the carefully edited lives of others can breed anxiety rather than inspiration. Some students even find face-to-face conversation awkward, having grown used to emojis and short messages. Therefore, what we need is not to abandon social media but to use it on our own terms. Setting a time limit and putting the phone away during meals are simple yet effective steps. Only when we control the tool instead of being controlled by it can we enjoy genuine connection.",
      expressions: [
        { en: "be woven into the fabric of", cn: "融入……的方方面面" },
        { en: "there is no denying that", cn: "无可否认" },
        { en: "within seconds", cn: "几秒钟之内" },
        { en: "a genuine comfort", cn: "真正的慰藉" },
        { en: "eat into", cn: "消耗，侵占（时间、金钱）" },
        { en: "on our own terms", cn: "按我们自己的方式" }
      ],
      upgrades: [
        { from: "spend time on", to: "devote time to", cn: "把时间投入到" },
        { from: "many problems", to: "a range of problems", cn: "一系列问题" },
        { from: "affect", to: "exert an influence on", cn: "对……施加影响" },
        { from: "stop", to: "give up", cn: "放弃" },
        { from: "good", to: "positive", cn: "积极的" }
      ],
      keywords: ["social media", "connection", "addiction", "screen", "privacy", "communication", "balance"]
    },
    {
      id: "culture-cross-exchange",
      level: "cet6",
      topic: "文化交流",
      title: "如何向世界讲好中国故事",
      prompt: "Suppose your university is holding an essay contest on cultural exchange. Write an essay of 150-200 words on how Chinese college students can tell China's story well to the world.",
      outline: ["指出讲好中国故事是青年一代的任务", "强调先理解自身文化", "说明要用对方能懂的方式表达，最后总结"],
      sample: "Telling China's story well to the world is a task that falls on the shoulders of the younger generation, and university students are in a unique position to take up this task. The first step is to understand our own culture thoroughly. A festival is not merely a holiday, and a poem is not merely a text; behind each lies a way of thinking that has been passed down for centuries. Without such understanding, our introduction will sound hollow and superficial. Equally important is the ability to speak in a language the audience understands. Instead of quoting abstract slogans, we can share personal stories, compare customs with those of other countries, and explain the reasons behind our traditions. When a foreign friend asks why we celebrate the Mid-Autumn Festival, a warm account of family reunions will be far more convincing than any textbook definition. In conclusion, cultural exchange is a two-way street. While presenting our heritage, we should also listen with an open mind, for mutual respect is the foundation on which genuine understanding is built.",
      expressions: [
        { en: "fall on the shoulders of", cn: "落在……的肩上" },
        { en: "take up", cn: "承担，着手做" },
        { en: "be passed down for centuries", cn: "传承了数百年" },
        { en: "far more convincing than", cn: "比……有说服力得多" },
        { en: "a two-way street", cn: "双向的互动，需要双方努力" },
        { en: "mutual respect", cn: "相互尊重" }
      ],
      upgrades: [
        { from: "show", to: "demonstrate", cn: "展示，说明" },
        { from: "tell", to: "convey", cn: "传达" },
        { from: "important", to: "vital", cn: "极其重要的" },
        { from: "understand", to: "gain an insight into", cn: "深入了解" },
        { from: "difference", to: "distinction", cn: "差别，区别" }
      ],
      keywords: ["culture", "exchange", "heritage", "tradition", "communication", "respect", "audience"]
    }
  ],
  connectors: {
    addition: ["Moreover", "In addition", "Furthermore", "What is more", "Besides", "Additionally"],
    contrast: ["However", "Nevertheless", "On the contrary", "In contrast", "By contrast", "Nonetheless"],
    cause: ["Therefore", "Consequently", "As a result", "Thus", "Hence", "For this reason"],
    example: ["For instance", "For example", "To illustrate", "A case in point is", "To take one example"],
    conclusion: ["In conclusion", "To sum up", "All things considered", "In a nutshell", "To conclude", "In summary"]
  },
  spellingMap: {
    "recieve": "receive",
    "seperate": "separate",
    "definately": "definitely",
    "accomodation": "accommodation",
    "occured": "occurred",
    "begining": "beginning",
    "beleive": "believe",
    "acheive": "achieve",
    "adress": "address",
    "agressive": "aggressive",
    "apparant": "apparent",
    "arguement": "argument",
    "basicly": "basically",
    "becuase": "because",
    "calender": "calendar",
    "cemetary": "cemetery",
    "changable": "changeable",
    "collegue": "colleague",
    "comming": "coming",
    "commitee": "committee",
    "completly": "completely",
    "concious": "conscious",
    "curiousity": "curiosity",
    "decieve": "deceive",
    "developement": "development",
    "diffrent": "different",
    "dissapoint": "disappoint",
    "embarass": "embarrass",
    "enviroment": "environment",
    "existance": "existence",
    "experiance": "experience",
    "familar": "familiar",
    "finaly": "finally",
    "foriegn": "foreign",
    "goverment": "government",
    "grammer": "grammar",
    "happend": "happened",
    "hieght": "height",
    "immediatly": "immediately",
    "independant": "independent",
    "intrest": "interest",
    "knowlege": "knowledge",
    "liesure": "leisure",
    "loosing": "losing",
    "maintenence": "maintenance",
    "neccessary": "necessary",
    "noticable": "noticeable",
    "occassion": "occasion",
    "oppurtunity": "opportunity",
    "paralell": "parallel",
    "peice": "piece",
    "posession": "possession",
    "prefered": "preferred",
    "priviledge": "privilege",
    "probaly": "probably",
    "proffesional": "professional",
    "pronounciation": "pronunciation",
    "publically": "publicly",
    "questionaire": "questionnaire",
    "reciept": "receipt"
  },
  chinglish: [
    { pattern: "very much like", suggest: "like ... very much / be fond of", cn: "「非常喜欢」不要写成 very much like" },
    { pattern: "open the light", suggest: "turn on the light", cn: "「开灯」用 turn on，不用 open" },
    { pattern: "although ... but ...", suggest: "although ... / ... 但不再加 but", cn: "although 与 but 不能同时出现在一句里" },
    { pattern: "I very like it", suggest: "I like it very much", cn: "very 不能直接修饰动词" },
    { pattern: "learn knowledge", suggest: "gain knowledge / acquire knowledge", cn: "知识是「获得」的，不是「学习」的，属搭配错误" },
    { pattern: "there have many people", suggest: "there are many people", cn: "「有」在 there be 句型中用 be，不用 have" },
    { pattern: "How to say this in English", suggest: "How do you say this in English", cn: "单独提问要用完整问句，不能只写 how to do" },
    { pattern: "go to home", suggest: "go home", cn: "home 作副词时前面不加 to" },
    { pattern: "according to my opinion", suggest: "in my opinion", cn: "固定搭配是 in my opinion" },
    { pattern: "in nowadays", suggest: "nowadays", cn: "nowadays 本身就是副词，前面不加介词" },
    { pattern: "I with my friend go to", suggest: "I go to ... with my friend", cn: "英文里「和谁一起」通常放在句末" },
    { pattern: "play an important role for", suggest: "play an important role in", cn: "固定搭配用介词 in" },
    { pattern: "discuss about the problem", suggest: "discuss the problem", cn: "discuss 是及物动词，后面不加 about" },
    { pattern: "the reason is because", suggest: "the reason is that", cn: "reason 与 because 语义重复，用 that 引导" },
    { pattern: "I very happy", suggest: "I am very happy", cn: "形容词作表语不能省略 be 动词" }
  ],
  commonErrors: [
    {
      id: "subject-verb",
      name: "主谓一致",
      desc: "第三人称单数漏 -s、there be 就近原则错误、主语与谓语被插入语隔开时错配",
      example: "The number of students are increasing. → is"
    },
    {
      id: "article",
      name: "冠词误用",
      desc: "可数名词单数前漏 a / an，特指漏 the，泛指却多加了 the",
      example: "I want to be doctor. → a doctor"
    },
    {
      id: "tense",
      name: "时态不一致",
      desc: "同一段落内时态跳换，或时间状语与谓语时态矛盾",
      example: "Last year I go to Beijing and visit the Great Wall. → went, visited"
    },
    {
      id: "plural",
      name: "名词单复数",
      desc: "可数名词该用复数时用单数，不可数名词误加 -s",
      example: "There are many information online. → much information"
    },
    {
      id: "relative-pronoun",
      name: "从句关系词误用",
      desc: "定语从句中 which / that / who / where 混用，或从句已完整却仍加关系代词",
      example: "This is the house where I lived in. → which I lived in / where I lived"
    },
    {
      id: "conjunction",
      name: "连接词误用",
      desc: "although 与 but、because 与 so 成对出现，或并列句缺少连接词",
      example: "Although he was tired, but he kept working. → Although he was tired, he kept working."
    },
    {
      id: "fragment",
      name: "句子片段",
      desc: "以从属连词或短语开头却缺少主句，不能独立成句",
      example: "Because I was late. → Because I was late, I missed the bus."
    },
    {
      id: "comma-splice",
      name: "逗号连接句",
      desc: "两个完整句子仅用逗号相连，缺少连词、分号或句号",
      example: "I like reading, my brother likes sports. → I like reading, while my brother likes sports."
    },
    {
      id: "parallel",
      name: "平行结构失衡",
      desc: "and / or 或列举中词性、形式不一致",
      example: "She likes swimming, reading and to paint. → and painting"
    },
    {
      id: "pronoun",
      name: "代词指代不明",
      desc: "代词与先行词数、性不一致，或一个代词同时指向多个名词",
      example: "Alice and Mary are close friends, and she often helps her with her homework. → Alice often helps Mary with her homework."
    }
  ]
};
