window.REAL_PAPERS = [
  {
    id: "cet4-2023-06-cloze-1",
    level: "cet4",
    year: "2023年6月",
    type: "选词填空",
    title: "大学图书馆的数字化转型",
    prompt: "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    bank: ["access", "decline", "digital", "efficient", "expand", "librarian", "reliable", "shelf", "tradition", "volume"],
    passage: "Modern university libraries are going through a major (1)______ transformation. Instead of rows of printed (2)______, students now rely on online databases that give instant (3)______ to millions of articles. This change has made research far more (4)______, though some readers still miss the quiet (5)______ of browsing between shelves. Librarians, meanwhile, have become guides to these new systems rather than keepers of printed pages, and most students say they would not willingly give up the convenience. Yet the old reading rooms are still full in the weeks before examinations.",
    blanks: [
      { n: 1, answer: "digital", explain: "digital transformation 是固定搭配『数字化转型』，修饰 transformation。" },
      { n: 2, answer: "volume", explain: "rows of volumes 指『成排的书卷』；volume 作可数名词表示一册书，此处用复数，题干词库给的 volume 需变复数填入。" },
      { n: 3, answer: "access", explain: "give access to 是固定搭配『给……提供访问权』，access 不可数。" },
      { n: 4, answer: "efficient", explain: "far more + 形容词原级构成比较级，形容研究效率高，用 efficient。" },
      { n: 5, answer: "tradition", explain: "the quiet tradition of browsing 指『安静翻书的传统』，of 短语作后置定语。" }
    ],
    points: ["固定搭配 give access to", "far more + adj. 比较级", "volume 的复数与词义"]
  },
  {
    id: "cet4-2023-12-cloze-1",
    level: "cet4",
    year: "2023年12月",
    type: "选词填空",
    title: "大学生志愿服务的新形态",
    prompt: "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    bank: ["benefit", "commit", "community", "demand", "flexible", "gradually", "motivate", "organization", "participate", "reward"],
    passage: "Volunteering among college students has changed a great deal in recent years. Rather than joining a single (1)______ for a whole term, many students now prefer short, (2)______ projects that fit around their busy class schedules. They (3)______ in weekend tutoring, animal rescue or neighbourhood clean-ups, often for just a few hours at a time. Such work clearly brings an obvious (4)______ to the (5)______, yet the main reason students give for taking part is personal: it helps them feel useful, connected and confident.",
    blanks: [
      { n: 1, answer: "organization", explain: "join a single organization 指『加入某一个固定的志愿组织』，与后文 for a whole term 呼应；organization 作可数名词用单数。" },
      { n: 2, answer: "flexible", explain: "short, flexible projects 为并列形容词修饰 projects，flexible『灵活的』与 fit around their schedules 语义一致。" },
      { n: 3, answer: "participate", explain: "participate in 是固定搭配『参与』，主语 They 用动词原形作谓语。" },
      { n: 4, answer: "benefit", explain: "bring a benefit to 表示『给……带来好处』，benefit 此处作可数名词，前有 an obvious 修饰用单数。" },
      { n: 5, answer: "community", explain: "the community 指『社区』，与 neighbourhood clean-ups 属同一语义场，是志愿服务的受益对象。" }
    ],
    points: ["participate in 的固定搭配", "bring a benefit to 句型", "并列形容词修饰名词"]
  },
  {
    id: "cet4-2024-06-cloze-1",
    level: "cet4",
    year: "2024年6月",
    type: "选词填空",
    title: "城市夜经济的发展",
    prompt: "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    bank: ["attract", "consume", "economy", "extend", "gradual", "leisure", "range", "revenue", "shift", "urban"],
    passage: "In many Chinese cities, shops and restaurants now (1)______ their opening hours well into the night. This so-called night (2)______ has become an important source of local income and employment. Young people in particular treat evening hours as (3)______ time, spending on snacks, films and live music. The (4)______ of choices is wide and prices are usually reasonable. City governments, however, must also control noise and waste, so the growth has been (5)______ rather than sudden. Many small businesses depend on this evening trade, and food stalls sometimes stay open until midnight, when the streets are still crowded with customers.",
    blanks: [
      { n: 1, answer: "extend", explain: "extend opening hours 是固定搭配『延长营业时间』；主语为 shops and restaurants，用动词原形。" },
      { n: 2, answer: "economy", explain: "night economy 是『夜经济』这一专有说法，与 source of local income and employment 同义呼应。" },
      { n: 3, answer: "leisure", explain: "leisure time 指『休闲时间』，与 spending on snacks, films and live music 对应。" },
      { n: 4, answer: "range", explain: "the range of choices 指『选择的范围』，range 在此为可数名词单数，谓语用 is。" },
      { n: 5, answer: "gradual", explain: "has been + 形容词作表语，与 rather than sudden 形成对照，需用形容词 gradual 而非副词 gradually。" }
    ],
    points: ["extend 的搭配与词义", "range 表『范围』可数用法", "be + adj. 与 rather than 的对照结构"]
  },
  {
    id: "cet6-2023-06-cloze-1",
    level: "cet6",
    year: "2023年6月",
    type: "选词填空",
    title: "人工智能进入新闻编辑室",
    prompt: "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    bank: ["accuracy", "algorithm", "automate", "credibility", "draft", "editorial", "generate", "interpret", "oversight", "verify"],
    passage: "Newsrooms are experimenting with tools that can (1)______ routine reports in seconds. Systems trained on large archives quickly produce a readable (2)______, but journalists still (3)______ every figure before publication. What worries editors most is not speed but (4)______: readers must be able to trust what they read, and an (5)______ that cannot explain its own choices makes that trust harder to keep. Some outlets now label such pieces clearly, while others publish them with barely any warning to readers, and editors insist the technology saves time rather than judgement.",
    blanks: [
      { n: 1, answer: "automate", explain: "automate routine reports 指『自动生成程式化的报道』；情态动词 can 后接动词原形。" },
      { n: 2, answer: "draft", explain: "produce a readable draft 指『产出一份可读的初稿』，前有 a 修饰，用单数可数名词。" },
      { n: 3, answer: "verify", explain: "verify every figure 指『核实每一个数字』，but 连接的两句均为一般现在时，用动词原形。" },
      { n: 4, answer: "credibility", explain: "not ... but ... 结构要求前后同类，speed 为名词，故填名词 credibility『可信度』，与后文 trust 呼应。" },
      { n: 5, answer: "algorithm", explain: "an algorithm 指『一种算法』，后接 that 引导的定语从句；元音音素前用 an。" }
    ],
    points: ["not ... but ... 的对称结构", "情态动词后接动词原形", "credibility 与 trust 的语义衔接"]
  },
  {
    id: "cet6-2023-12-cloze-1",
    level: "cet6",
    year: "2023年12月",
    type: "选词填空",
    title: "远程办公对城市结构的影响",
    prompt: "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    bank: ["commute", "density", "disperse", "flexible", "infrastructure", "migrate", "productivity", "sustain", "virtual", "welfare"],
    passage: "When millions of employees began working from home, the daily (1)______ shrank and demand for office space fell sharply. Some analysts expected cities to (2)______ into smaller towns, but the evidence so far is mixed. Firms that adopt (3)______ arrangements report stable or even higher (4)______, yet they also worry about weaker teamwork. Planners now argue that (5)______ — transport, broadband and housing — matters more than ever, because workers can choose where to live. Some companies have already reduced their office space, while others are quietly expanding it again.",
    blanks: [
      { n: 1, answer: "commute", explain: "the daily commute 指『日常通勤』，与 demand for office space fell 同属办公模式变化的结果。" },
      { n: 2, answer: "disperse", explain: "expect cities to disperse 指『预期城市人口向外分散』；disperse 作不及物动词，与 into smaller towns 搭配。" },
      { n: 3, answer: "flexible", explain: "flexible arrangements 指『灵活的工作安排』，与前文 working from home 呼应，作定语修饰名词。" },
      { n: 4, answer: "productivity", explain: "higher productivity 指『更高的生产率』，与 stable 并列作 report 的宾语，为不可数名词。" },
      { n: 5, answer: "infrastructure", explain: "破折号后的 transport, broadband and housing 是同位解释，故填 infrastructure『基础设施』，不可数。" }
    ],
    points: ["破折号同位语提示词义", "expect sb./sth. to do 结构", "productivity 与 stable 的并列"]
  },
  {
    id: "cet4-2023-06-trans-1",
    level: "cet4",
    year: "2023年6月",
    type: "翻译",
    title: "中国的茶文化",
    prompt: "请将下面这段关于中国传统文化的文字翻译成英文。",
    source: "茶是中国人日常生活中最常见的饮品之一。早在唐代，饮茶就已成为一种普遍的习惯，并逐渐形成了独特的茶文化。中国人不仅讲究茶叶的品质，还注重泡茶的水温和器具。如今，茶馆遍布城市与乡村，人们在品茶的同时交流感情、洽谈事务。",
    reference: "Tea is one of the most common drinks in the daily life of Chinese people. As early as the Tang Dynasty, drinking tea had become a widespread habit, and a unique tea culture gradually took shape. Chinese people care not only about the quality of tea leaves but also about the water temperature and the utensils used for brewing. Today teahouses can be found in both cities and the countryside, where people enjoy tea while building friendships and discussing business.",
    points: [
      "『最常见的饮品之一』译为 one of the most common drinks，注意 one of 后接可数名词复数。",
      "『逐渐形成』用 take shape，与主语 culture 搭配，时态与前半句一致用过去时。",
      "『不仅……还……』用 not only ... but also ... 结构，前后所接成分类别须一致。",
      "『在品茶的同时』用 while + doing 结构，避免在一个句中并列两个谓语。"
    ],
    keyWords: [
      { w: "tea culture", cn: "茶文化" },
      { w: "widespread", cn: "普遍的、广泛的" },
      { w: "take shape", cn: "形成、成形" },
      { w: "utensil", cn: "器具、用具" },
      { w: "brew", cn: "冲泡（茶、咖啡）" },
      { w: "teahouse", cn: "茶馆" }
    ]
  },
  {
    id: "cet4-2023-12-trans-1",
    level: "cet4",
    year: "2023年12月",
    type: "翻译",
    title: "中国高速铁路的发展",
    prompt: "请将下面这段关于中国社会发展的文字翻译成英文。",
    source: "近年来，中国高速铁路发展迅速，运营里程居世界首位。高铁把许多原本需要一整天的旅程缩短到几个小时，使人们能够在不同城市之间当天往返。它不仅方便了出行，也带动了沿线中小城市的经济发展。越来越多的人选择乘高铁旅游、探亲或通勤。",
    reference: "In recent years, China's high-speed railway has developed rapidly, with its operating mileage ranking first in the world. High-speed trains have shortened many journeys that once took a whole day to just a few hours, enabling people to make same-day round trips between different cities. They have not only made travel more convenient but also boosted the economy of small and medium-sized cities along the lines. More and more people choose to travel, visit relatives or commute by high-speed rail.",
    points: [
      "『运营里程居世界首位』可用 with + 独立主格结构译出，避免另起一句。",
      "『缩短到几个小时』用 shorten ... to ...，原状态用定语从句 that once took a whole day 表达。",
      "『使人们能够』用现在分词 enabling 作结果状语。",
      "『带动经济发展』可译为 boost / promote the economy，注意『沿线』用 along the lines。"
    ],
    keyWords: [
      { w: "high-speed railway", cn: "高速铁路" },
      { w: "operating mileage", cn: "运营里程" },
      { w: "same-day round trip", cn: "当天往返" },
      { w: "boost", cn: "推动、促进" },
      { w: "commute", cn: "通勤" },
      { w: "along the lines", cn: "沿线的" }
    ]
  },
  {
    id: "cet6-2023-06-trans-1",
    level: "cet6",
    year: "2023年6月",
    type: "翻译",
    title: "科技创新与社会责任",
    prompt: "请将下面这段关于科技与教育的文字翻译成英文，注意句式衔接与逻辑关系。",
    source: "创新是推动一个国家持续发展的重要动力。近年来，中国在人工智能、量子通信和新能源等领域投入了大量资源，取得了一系列突破。这些成果不仅提升了产业竞争力，也改变了普通人的生活方式。然而，技术快速进步的同时，如何保护个人隐私、缩小数字鸿沟，已成为社会必须面对的问题。",
    reference: "Innovation is an important driving force for the sustained development of a country. In recent years, China has invested considerable resources in fields such as artificial intelligence, quantum communication and new energy, making a series of breakthroughs. These achievements have not only enhanced the competitiveness of industries but also changed the way ordinary people live. However, along with rapid technological progress, how to protect personal privacy and narrow the digital divide has become a problem that society must confront.",
    points: [
      "『在……领域投入资源』用 invest resources in fields such as ...，such as 后并列名词。",
      "『取得突破』用 make breakthroughs，以现在分词作结果状语使句子更紧凑。",
      "『已成为社会必须面对的问题』用 has become a problem that ... must confront，that 引导定语从句。",
      "『缩小数字鸿沟』为固定译法 narrow the digital divide。"
    ],
    keyWords: [
      { w: "driving force", cn: "动力" },
      { w: "breakthrough", cn: "突破" },
      { w: "competitiveness", cn: "竞争力" },
      { w: "digital divide", cn: "数字鸿沟" },
      { w: "personal privacy", cn: "个人隐私" },
      { w: "confront", cn: "面对、应对" }
    ]
  },
  {
    id: "cet6-2023-12-trans-1",
    level: "cet6",
    year: "2023年12月",
    type: "翻译",
    title: "乡村振兴与教育均衡",
    prompt: "请将下面这段关于社会发展的文字翻译成英文，注意中文长句的拆分与重组。",
    source: "乡村振兴战略实施以来，中国农村的面貌发生了显著变化。道路、网络和医疗设施不断改善，越来越多的年轻人选择返乡创业。教育资源的均衡配置尤其受到重视，许多乡村学校得到了新的教学楼和优秀教师。这些努力正在缩小城乡差距，为农村孩子提供更多机会。",
    reference: "Since the rural revitalization strategy was implemented, the face of the Chinese countryside has changed markedly. Roads, internet access and medical facilities have kept improving, and an increasing number of young people choose to return home to start businesses. Balanced allocation of educational resources has received particular attention, with many rural schools gaining new teaching buildings and excellent teachers. These efforts are narrowing the gap between urban and rural areas and providing more opportunities for rural children.",
    points: [
      "『自……实施以来』用 Since + 从句（过去时），主句用现在完成时。",
      "『不断改善』用 have kept improving，比单纯用 improve 更能体现持续性。",
      "『尤其受到重视』用 receive particular attention，注意被动语态在英文中更常用主动表达。",
      "『缩小城乡差距』用 narrow the gap between urban and rural areas。"
    ],
    keyWords: [
      { w: "rural revitalization", cn: "乡村振兴" },
      { w: "markedly", cn: "显著地" },
      { w: "return home to start businesses", cn: "返乡创业" },
      { w: "balanced allocation", cn: "均衡配置" },
      { w: "narrow the gap", cn: "缩小差距" },
      { w: "urban and rural areas", cn: "城乡" }
    ]
  },
  {
    id: "cet6-2023-06-longsent-1",
    level: "cet6",
    year: "2023年6月",
    type: "阅读长难句",
    title: "长难句：否定词提前的倒装结构",
    sentence: "Not until researchers had compared thousands of samples collected over two decades did they realize that the decline, which many had blamed on climate alone, was in fact driven largely by human activity.",
    questions: [
      {
        q: "What does the sentence suggest about the cause of the decline?",
        options: [
          "It was driven largely by human activity.",
          "It was caused entirely by climate change.",
          "It has been reversed by recent research.",
          "It was first noticed two decades ago."
        ],
        answer: 0,
        explain: "主句为 was in fact driven largely by human activity，其中 in fact 与插入定语从句中的 blamed on climate alone 形成对比，说明真正主因是人类活动，故选 A。B 是作者所纠正的普遍误解，C、D 均无依据。"
      },
      {
        q: "What is the function of the clause 'which many had blamed on climate alone'?",
        options: [
          "It shows that the researchers' conclusion was widely accepted.",
          "It indicates a common assumption that the study later challenged.",
          "It explains the method used to compare the samples.",
          "It describes the climate of the region studied."
        ],
        answer: 1,
        explain: "该非限制性定语从句补充说明『此前许多人把这一下降归因于气候』，与主句 in fact driven largely by human activity 构成对照，功能是引出被研究修正的普遍看法，故选 B。"
      }
    ],
    translation: "直到研究人员比较了两十年间收集的数千份样本之后，他们才意识到：这一（物种或指标）下降，许多人此前只归因于气候，实际上主要是由人类活动造成的。",
    points: [
      "Not until 置于句首引起主句部分倒装：did they realize。",
      "which 引导非限制性定语从句，修饰 the decline，补充背景信息。",
      "that 引导宾语从句，从句主语 the decline 与谓语 was driven 之间插入定语从句。",
      "be driven by 表『由……造成／驱动』，largely 表程度。"
    ]
  },
  {
    id: "cet6-2023-12-longsent-1",
    level: "cet6",
    year: "2023年12月",
    type: "阅读长难句",
    title: "长难句：so ... that 倒装与插入语",
    sentence: "So complex is the system that even its designers admit they cannot fully predict how it will behave when unexpected data, rather than the patterns it was trained on, are fed into it.",
    questions: [
      {
        q: "What can be inferred about the system from this sentence?",
        options: [
          "Its designers fully understand its behaviour.",
          "It fails only when the data match its training patterns.",
          "Its complexity prevents even its designers from fully predicting its behaviour.",
          "It becomes simpler when unexpected data are fed into it."
        ],
        answer: 2,
        explain: "So complex is the system that ... admit they cannot fully predict 说明系统过于复杂，连设计者也无法完全预测其行为，故选 C。"
      },
      {
        q: "Which part of the sentence introduces the contrast between two kinds of data?",
        options: [
          "So complex is the system that ...",
          "when unexpected data, rather than the patterns it was trained on, are fed into it",
          "even its designers admit they cannot fully predict",
          "how it will behave"
        ],
        answer: 1,
        explain: "rather than 引导的插入成分把 unexpected data 与 the patterns it was trained on 两种输入数据对照起来，位于 when 引导的时间状语从句中，故选 B。"
      }
    ],
    translation: "这个系统如此复杂，以至于连它的设计者也承认：当输入的是意料之外的数据，而不是它当初训练时所用的模式时，他们无法完全预测它会如何表现。",
    points: [
      "So + adj. 置于句首引起完全倒装：So complex is the system that ...。",
      "so ... that ... 引导结果状语从句。",
      "rather than 作插入成分表对比，连接两个并列名词短语。",
      "the patterns it was trained on 中省略了关系代词 that/which，on 不可丢。",
      "feed ... into ... 用于描述数据输入。"
    ]
  },
  {
    id: "cet6-2024-06-longsent-1",
    level: "cet6",
    year: "2024年6月",
    type: "阅读长难句",
    title: "长难句：主语从句与 not ... but ... 结构",
    sentence: "What makes the finding unusual, according to the team that published it, is not the size of the sample but the fact that the effect appeared among participants who had slept fewer than six hours.",
    questions: [
      {
        q: "According to the sentence, what makes the finding unusual?",
        options: [
          "The fact that the sample was unusually large.",
          "The fact that the effect appeared only in a particular group of participants.",
          "The fact that the team published it last month.",
          "The fact that the effect appeared in all participants."
        ],
        answer: 1,
        explain: "表语部分为 not the size of the sample but the fact that ...，即不寻常之处在于效应只出现在睡眠少于六小时的参与者身上，故选 B。"
      },
      {
        q: "What does the construction 'not ... but ...' emphasise in this sentence?",
        options: [
          "The size of the sample rather than the research team.",
          "The restricted condition under which the effect appeared.",
          "The importance of sleep for the general public.",
          "The unusual nature of the research method."
        ],
        answer: 1,
        explain: "not ... but ... 否定了样本规模这一因素，强调『效应只在特定条件下出现』这一事实，即其出现条件受限，故选 B。"
      }
    ],
    translation: "据发表该研究结果的团队所说，使这一发现显得不寻常的，并不是样本的规模，而是这样一个事实：这种效应只在睡眠不足六小时的参与者身上出现。",
    points: [
      "What 引导主语从句，整个从句作句子主语，谓语用单数 is。",
      "according to ... 为插入成分，插在主语与谓语之间。",
      "not ... but ... 连接两个并列的表语成分，形成对比强调。",
      "the fact that ... 中 that 引导同位语从句，说明 fact 的具体内容。",
      "who had slept fewer than six hours 为限制性定语从句修饰 participants。"
    ]
  },
  {
    id: "cet4-2023-06-writing-1",
    level: "cet4",
    year: "2023年6月",
    type: "写作",
    title: "大学生时间管理的重要性",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a short essay entitled The Importance of Time Management for College Students. You should write at least 120 words but no more than 180 words, following the outline given below.",
    outline: [
      "大学生活中时间管理的重要性",
      "目前部分同学在时间安排上存在的问题及原因",
      "你对如何做好时间管理的建议"
    ],
    sample: "The Importance of Time Management for College Students\n\nCollege life offers far more freedom than high school, and that freedom makes time management a decisive skill. With classes, part-time jobs and social activities competing for attention, students who plan their days carefully can study efficiently and still find time to relax.\n\nUnfortunately, many students fail to manage their time well. Some delay their assignments until the night before the deadline, while others lose hours to short videos and games without noticing. The root cause is simple: they have never been taught how to set priorities.\n\nIn my view, two simple habits help a lot. First, make a weekly plan and mark the tasks that must be finished. Second, break large tasks into small ones and give each a clear deadline. In this way, we can control our time instead of being controlled by it.",
    expressions: [
      { en: "make time management a decisive skill", cn: "使时间管理成为一项决定性技能" },
      { en: "compete for attention", cn: "争夺注意力" },
      { en: "delay one's assignments until the night before the deadline", cn: "把作业拖到截止前最后一晚" },
      { en: "set priorities", cn: "分清主次、确定优先级" },
      { en: "break large tasks into small ones", cn: "把大任务拆分成小任务" },
      { en: "control our time instead of being controlled by it", cn: "掌控时间而不是被时间掌控" }
    ]
  },
  {
    id: "cet6-2023-12-writing-1",
    level: "cet6",
    year: "2023年12月",
    type: "写作",
    title: "人工智能对未来就业市场的影响",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the impact of artificial intelligence on the future job market. You should write at least 150 words but no more than 200 words, following the outline given below.",
    outline: [
      "人工智能正在改变就业市场的结构与需求",
      "这一变化给求职者带来的机遇与挑战",
      "大学生应如何为此做好准备"
    ],
    sample: "The Impact of Artificial Intelligence on the Future Job Market\n\nArtificial intelligence is reshaping the job market at a speed few industries can ignore. Routine tasks such as data entry, basic translation and simple customer service are increasingly automated, while demand grows for engineers, analysts and professionals who can work alongside intelligent systems.\n\nThis shift brings both opportunities and risks. On the one hand, new roles appear faster than many expected, and skilled workers enjoy greater bargaining power. On the other hand, employees whose jobs consist mainly of repetitive procedures face real pressure to retrain, and the gap between those who adapt and those who do not may well widen.\n\nFor college students, the sensible response is to build skills that machines handle poorly. Critical thinking, cross-cultural communication and the ability to frame a problem clearly are hard to automate. Meanwhile, a basic command of data tools makes us more competitive rather than more replaceable. Preparation, not panic, is what the moment requires.",
    expressions: [
      { en: "reshape the job market", cn: "重塑就业市场" },
      { en: "work alongside intelligent systems", cn: "与智能系统协同工作" },
      { en: "enjoy greater bargaining power", cn: "拥有更强的议价能力" },
      { en: "face real pressure to retrain", cn: "面临重新学习技能的切实压力" },
      { en: "a basic command of data tools", cn: "对数据工具的基本掌握" },
      { en: "Preparation, not panic, is what the moment requires.", cn: "此刻需要的是准备，而不是恐慌。" }
    ]
  }
];
