window.GRAMMAR_BANK = [
  {
    "id": "tense-perfect-vs-past",
    "point": "时态",
    "sub": "现在完成时 vs 一般过去时",
    "level": "cet4",
    "freq": 5,
    "rule": "现在完成时强调过去动作对现在的影响，不与明确过去时间状语连用；一般过去时只陈述过去发生的动作，必带或隐含具体过去时间。判断口诀：句中出现 yesterday/last week/in 2019 等明确过去时间，一律用一般过去时。",
    "tips": [
      "信号词：already / yet / just / ever / never / since / for 多与现在完成时连用",
      "since + 时间点用完成时，for + 时间段用完成时",
      "have been to 去过（已回来） vs have gone to 去了（还没回）"
    ],
    "examples": [
      {
        "en": "I have lived here for ten years.",
        "cn": "我在这儿住了十年了。",
        "note": "for + 时间段，强调持续到现在"
      },
      {
        "en": "I visited Beijing last summer.",
        "cn": "我去年夏天去了北京。",
        "note": "last summer 是明确过去时间，只能用一般过去时"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "By the time we got to the cinema, the film ____.",
        "options": [
          "has started",
          "had started",
          "starts",
          "was starting"
        ],
        "answer": 1,
        "explain": "by the time + 过去动作，主句用过去完成时表示「过去的过去」。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "I have seen him yesterday at the library.",
        "right": "I saw him yesterday at the library.",
        "explain": "yesterday 是明确过去时间，不能用现在完成时。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The company ____ (launch) three new products since 2020.",
        "answer": "has launched",
        "explain": "since + 时间点，主句用现在完成时。"
      },
      {
        "type": "reorder",
        "words": [
          "for",
          "she",
          "has",
          "worked",
          "this",
          "company",
          "five",
          "years"
        ],
        "answer": "She has worked for this company five years.",
        "cn": "她在这家公司工作五年了。",
        "explain": "现在完成时 + for 时间段，主语 She 用 has。"
      },
      {
        "type": "analysis",
        "sentence": "It is the third time that he has failed to keep the promise he made to his parents.",
        "question": "句中 that 从句为什么用现在完成时而不用一般过去时？",
        "options": [
          "因为句子主语是 It",
          "因为 It is the + 序数词 + time that 结构要求从句用完成时",
          "因为 promise 是不可数名词",
          "因为从句省略了时间状语"
        ],
        "answer": 1,
        "explain": "It is the first/second/third time that... 是固定结构，从句必须用现在完成时；若主句是 It was，则从句用过去完成时。",
        "translation": "这已经是他第三次未能遵守对父母许下的承诺了。"
      }
    ]
  },
  {
    "id": "tense-past-perfect",
    "point": "时态",
    "sub": "过去完成时与「过去的过去」",
    "level": "cet4",
    "freq": 5,
    "rule": "过去完成时表示在过去某一时间点之前已经完成的动作，即「过去的过去」，结构为 had + 过去分词。句中通常有另一个过去动作或 by / before / when 等作参照点；若用 after、before 已明确先后顺序，也可用一般过去时。",
    "tips": [
      "had done 需要一个过去的参照点，孤立使用多为错句",
      "before / after 已表明顺序时，两种时态可互换",
      "hardly...when 与 no sooner...than 的主句用过去完成时"
    ],
    "examples": [
      {
        "en": "When I arrived at the station, the train had already left.",
        "cn": "我到车站时，火车已经开走了。",
        "note": "arrived 是过去参照点，left 发生在它之前，用过去完成时"
      },
      {
        "en": "He told me that he had finished the report the day before.",
        "cn": "他告诉我他前一天就完成了那份报告。",
        "note": "主句 told 为过去时，宾语从句动作更早，用 had finished"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "By the end of last term, we ____ over two thousand English words.",
        "options": [
          "learn",
          "learned",
          "had learned",
          "have learned"
        ],
        "answer": 2,
        "explain": "By the end of + 过去时间，动作在该时间点前已完成，用过去完成时。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "When the police arrived, the thief ran away already.",
        "right": "When the police arrived, the thief had already run away.",
        "explain": "ran away 发生在 arrived 之前，应用过去完成时；already 位于 had 之后、过去分词之前。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：She ____ (not see) such a beautiful sunset before she came to the seaside.",
        "answer": "had not seen",
        "explain": "before 从句为过去时，主句动作发生更早，用过去完成时。"
      },
      {
        "type": "reorder",
        "words": [
          "had",
          "the",
          "meeting",
          "begun",
          "when",
          "we",
          "arrived",
          "at",
          "the",
          "hall"
        ],
        "answer": "The meeting had begun when we arrived at the hall.",
        "cn": "我们到大厅时，会议已经开始了。",
        "explain": "when 从句用过去时作参照，主句动作更早，用过去完成时。"
      },
      {
        "type": "analysis",
        "sentence": "By the time the rescue team reached the village, the flood had destroyed more than thirty houses and left hundreds of people homeless.",
        "question": "句中 had destroyed 为什么用过去完成时？",
        "options": [
          "因为洪水是自然现象",
          "因为该动作发生在 reached 之前，构成「过去的过去」",
          "因为句首是 By the time",
          "因为 houses 是可数名词复数"
        ],
        "answer": 1,
        "explain": "By the time 引导的从句用一般过去时 reached 作参照点，主句动作发生在其之前，故用过去完成时；并列的 left 与 had destroyed 共用 had。",
        "translation": "救援队到达那个村庄时，洪水已经冲毁了三十多所房屋，并使数百人无家可归。"
      }
    ]
  },
  {
    "id": "nonfinite-participle-adverbial",
    "point": "非谓语动词",
    "sub": "分词作状语：现在分词与过去分词的选择",
    "level": "cet4",
    "freq": 5,
    "rule": "分词作状语时，其逻辑主语必须与句子主语一致。现在分词 doing 表示主动或进行，与句子主语是主谓关系；过去分词 done 表示被动或完成，与句子主语是动宾关系。若分词动作先于谓语动作发生，则用完成式 having done。",
    "tips": [
      "先判断分词与句子主语是主动还是被动关系",
      "having done 强调分词动作先于主句动作发生",
      "分词作状语不能再加连词，也不能自带主语"
    ],
    "examples": [
      {
        "en": "Seeing the teacher coming, the students stopped talking.",
        "cn": "看到老师走来，学生们停止了交谈。",
        "note": "students 主动发出 see 的动作，用现在分词"
      },
      {
        "en": "Built in 1890, the bridge is still in use today.",
        "cn": "这座桥建于 1890 年，如今仍在使用。",
        "note": "bridge 是被建造的，用过去分词表被动"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ from the top of the tower, the city looks like a huge garden.",
        "options": [
          "Seeing",
          "Seen",
          "To see",
          "Having seen"
        ],
        "answer": 1,
        "explain": "城市是「被看」的对象，与句子主语 the city 是动宾关系，用过去分词。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Comparing with his brother, Tom is more patient.",
        "right": "Compared with his brother, Tom is more patient.",
        "explain": "Tom 是被比较的对象，应用过去分词 compared with 作状语。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：____ (not know) what to say, she kept silent.",
        "answer": "Not knowing",
        "explain": "否定词 not 置于分词之前；she 主动发出 know 的动作，用现在分词。"
      },
      {
        "type": "reorder",
        "words": [
          "having",
          "the",
          "his",
          "homework",
          "finished",
          "boy",
          "went",
          "out",
          "to",
          "play"
        ],
        "answer": "Having finished his homework the boy went out to play.",
        "cn": "完成作业后，那个男孩出去玩了。",
        "explain": "finish 的动作先于 went out，且与主语 the boy 是主谓关系，用现在分词的完成式。"
      },
      {
        "type": "analysis",
        "sentence": "Faced with such a difficult situation, the young manager decided to turn to his former teacher for advice.",
        "question": "句中 Faced with 为什么用过去分词而不用现在分词？",
        "options": [
          "因为句首的单词需要大写",
          "因为主语 the young manager 是这一处境的承受者，与 face 构成动宾关系",
          "因为 decided 是过去式",
          "因为 with 是介词"
        ],
        "answer": 1,
        "explain": "be faced with 是固定搭配，主语是承受者，故用过去分词表被动。",
        "translation": "面对如此困难的局面，这位年轻的经理决定向他从前的老师求助。"
      }
    ]
  },
  {
    "id": "nonfinite-infinitive-vs-gerund",
    "point": "非谓语动词",
    "sub": "动词后接不定式还是动名词",
    "level": "cet4",
    "freq": 4,
    "rule": "有些动词后只能接不定式（decide, hope, manage, offer, afford, refuse），有些只能接动名词（enjoy, avoid, suggest, mind, practise, finish），还有 like、remember、forget、stop、try 后接两者意义不同。不定式多表具体或未完成的动作，动名词多表习惯或已发生的动作。考试常考 remember、forget、stop、try 等词后接两者意思不同的辨析，要结合动作发生的时间先后判断。",
    "tips": [
      "avoid / enjoy / mind / suggest 后只能接动名词",
      "remember doing 记得做过，remember to do 记得去做",
      "介词后一律用动名词，to 作介词时也一样"
    ],
    "examples": [
      {
        "en": "He suggested going to the museum this weekend.",
        "cn": "他建议这周末去博物馆。",
        "note": "suggest 后接动名词，不接不定式"
      },
      {
        "en": "She stopped to answer the phone.",
        "cn": "她停下来去接电话。",
        "note": "stop to do 表示停下当前动作去做另一件事"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "I still remember ____ the little village for the first time.",
        "options": [
          "to visit",
          "visiting",
          "visit",
          "visited"
        ],
        "answer": 1,
        "explain": "remember doing 表示记得做过某事，动作已经发生。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "They decided going abroad for further study.",
        "right": "They decided to go abroad for further study.",
        "explain": "decide 后只能接不定式作宾语。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：You should avoid ____ (make) the same mistake twice.",
        "answer": "making",
        "explain": "avoid 后只能接动名词作宾语。"
      },
      {
        "type": "reorder",
        "words": [
          "to",
          "we",
          "him",
          "persuade",
          "tried",
          "to",
          "join",
          "us"
        ],
        "answer": "We tried to persuade him to join us.",
        "cn": "我们试图说服他加入我们。",
        "explain": "try to do 表示努力做某事，persuade sb to do 为固定搭配。"
      },
      {
        "type": "analysis",
        "sentence": "Instead of complaining about the noisy environment, the students chose to move to the reading room on the second floor.",
        "question": "句中 complaining 为什么用动名词形式？",
        "options": [
          "因为 Instead of 中的 of 是介词，其后必须接动名词",
          "因为 complain 没有不定式形式",
          "因为句首需要名词",
          "因为主语是复数"
        ],
        "answer": 0,
        "explain": "介词 of 后接动名词，Instead of doing 表示「与其做某事」。",
        "translation": "与其抱怨嘈杂的环境，学生们选择搬到二楼的阅览室。"
      }
    ]
  },
  {
    "id": "clause-relative-pronoun",
    "point": "从句",
    "sub": "定语从句关系词选择（that / which / whose）",
    "level": "cet4",
    "freq": 5,
    "rule": "关系代词在定语从句中作主语或宾语时，指人用 who、whom、that，指物用 which、that。先行词被 all、only、序数词或最高级修饰，或先行词为不定代词时，一般只用 that。whose 表所属关系，可指人也可指物，其后须紧跟名词。非限制性定语从句只能用 which 或 who。",
    "tips": [
      "介词提前时只能用 whom 或 which",
      "whose 后面必须紧跟名词",
      "非限制性定语从句不能用 that"
    ],
    "examples": [
      {
        "en": "This is the only book that I can find on the subject.",
        "cn": "这是我在此主题上唯一能找到的书。",
        "note": "先行词被 only 修饰，关系词只用 that"
      },
      {
        "en": "The house whose windows face south is warmer in winter.",
        "cn": "窗户朝南的那所房子冬天更暖和。",
        "note": "whose 表所属关系，指代 the house"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "She is the kind of person ____ always helps others.",
        "options": [
          "who",
          "which",
          "whom",
          "whose"
        ],
        "answer": 0,
        "explain": "先行词 person 指人，关系词在从句中作主语，用 who。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "This is the most interesting film which I have ever seen.",
        "right": "This is the most interesting film that I have ever seen.",
        "explain": "先行词被最高级修饰时，关系代词只用 that。"
      },
      {
        "type": "fill",
        "q": "用适当的关系词填空：The scientist ____ name is known to everyone will give us a lecture.",
        "answer": "whose",
        "explain": "空格后紧跟名词 name，表所属关系，用 whose。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "book",
          "is",
          "that",
          "I",
          "bought",
          "yesterday",
          "interesting",
          "very"
        ],
        "answer": "The book that I bought yesterday is very interesting.",
        "cn": "我昨天买的那本书非常有趣。",
        "explain": "关系词在从句中作 bought 的宾语，指物用 that 或 which。"
      },
      {
        "type": "analysis",
        "sentence": "The professor mentioned several books, none of which had been translated into Chinese at that time.",
        "question": "句中 none of which 的用法说明了什么？",
        "options": [
          "非限制性定语从句中，指物时介词 of 后只能用 which，不能用 that",
          "which 在此处作连词",
          "none of 后面必须接 that",
          "该从句是同位语从句"
        ],
        "answer": 0,
        "explain": "在「代词或数词 + of + 关系代词」结构中，指物只能用 which，不能用 that。",
        "translation": "教授提到了几本书，当时这些书都还没有中译本。"
      }
    ]
  },
  {
    "id": "clause-noun-clause-that-what",
    "point": "从句",
    "sub": "名词性从句中 that 与 what、whether 与 if 的选择",
    "level": "cet6",
    "freq": 4,
    "rule": "that 在名词性从句中只起连接作用，不充当成分且无词义；what 在从句中必须充当主语、宾语或表语，意为「所……的」。主语从句和表语从句中表示「是否」只能用 whether；介词后、句首以及不定式前也只能用 whether。if 只引导宾语从句和条件状语从句。",
    "tips": [
      "从句中缺主语或宾语，用 what 而非 that",
      "位于句首表示「是否」只能用 whether",
      "that 引导主语从句时不能省略"
    ],
    "examples": [
      {
        "en": "What he said at the meeting surprised everyone.",
        "cn": "他在会上说的话让所有人都很吃惊。",
        "note": "从句缺 said 的宾语，用 what 引导"
      },
      {
        "en": "That she passed the exam made her parents happy.",
        "cn": "她通过了考试，这让她的父母很高兴。",
        "note": "从句成分完整、无词义，用 that 引导"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ matters most is not how much you earn but how much you save.",
        "options": [
          "That",
          "What",
          "Which",
          "It"
        ],
        "answer": 1,
        "explain": "从句缺少主语，用 what 引导主语从句。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "If he will come to the party is still unknown.",
        "right": "Whether he will come to the party is still unknown.",
        "explain": "主语从句表示「是否」只能用 whether，不能用 if。"
      },
      {
        "type": "fill",
        "q": "用适当的连接词填空：We all believe ____ he is honest and hardworking.",
        "answer": "that",
        "explain": "宾语从句成分完整、无词义，用 that 引导，口语中可省略。"
      },
      {
        "type": "reorder",
        "words": [
          "he",
          "told",
          "me",
          "what",
          "had",
          "he",
          "done",
          "yesterday"
        ],
        "answer": "He told me what he had done yesterday.",
        "cn": "他告诉了我他昨天做了什么。",
        "explain": "从句缺 done 的宾语，用 what；主句为过去时，从句动作更早，用过去完成时。"
      },
      {
        "type": "analysis",
        "sentence": "Whether the new policy will actually reduce the cost of living remains a question that concerns millions of ordinary families.",
        "question": "句首为什么用 Whether 而不用 If？",
        "options": [
          "因为 Whether 更正式",
          "因为引导主语从句表示「是否」时只能用 whether",
          "因为该句是否定句",
          "因为 remains 是第三人称单数"
        ],
        "answer": 1,
        "explain": "主语从句位于句首时，表示「是否」必须用 whether，不能用 if。",
        "translation": "新政策是否真能降低生活成本，仍是关系到数百万普通家庭的问题。"
      }
    ]
  },
  {
    "id": "subjunctive-if-condition",
    "point": "虚拟语气",
    "sub": "虚拟语气在 if 条件句中的时态后退",
    "level": "cet4",
    "freq": 4,
    "rule": "与现在事实相反：if 从句用一般过去式（be 动词统一用 were），主句用 would / could / might + 动词原形。与过去事实相反：从句用 had + 过去分词，主句用 would have + 过去分词。与将来事实相反：从句用一般过去式或 were to do、should do，主句用 would + 动词原形。",
    "tips": [
      "与现在相反时，从句的 be 动词一律用 were",
      "与过去相反时，从句和主句都要用完成形式",
      "省略 if 时需把 had / were / should 提到主语之前"
    ],
    "examples": [
      {
        "en": "If I were you, I would accept the offer.",
        "cn": "如果我是你，我就会接受这个提议。",
        "note": "与现在事实相反，从句用 were，主句用 would + 动词原形"
      },
      {
        "en": "If he had studied harder, he would have passed the exam.",
        "cn": "如果他当时学得更努力，本可以通过考试。",
        "note": "与过去事实相反，从句用 had done，主句用 would have done"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "If it ____ not for your help, I could not have finished the project on time.",
        "options": [
          "were",
          "was",
          "had been",
          "has been"
        ],
        "answer": 2,
        "explain": "主句是 could not have finished，与过去事实相反，从句用 had been。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "If I would have known the truth, I would have told you.",
        "right": "If I had known the truth, I would have told you.",
        "explain": "if 条件句中不能用 would have done，必须用 had done。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：If she ____ (be) here now, she would give us a hand.",
        "answer": "were",
        "explain": "与现在事实相反，从句的 be 动词用 were。"
      },
      {
        "type": "reorder",
        "words": [
          "i",
          "were",
          "if",
          "i",
          "would",
          "you",
          "accept",
          "the",
          "offer"
        ],
        "answer": "If I were you I would accept the offer.",
        "cn": "如果我是你，我就会接受这个提议。",
        "explain": "与现在事实相反，从句用 were，主句用 would + 动词原形。"
      },
      {
        "type": "analysis",
        "sentence": "Had the local government taken immediate measures, the losses caused by the flood would have been much smaller.",
        "question": "句首的 Had the local government taken 属于什么结构？",
        "options": [
          "一般疑问句的倒装",
          "省略 if 的虚拟条件句，把 had 提到主语之前构成倒装",
          "过去完成时的强调句",
          "主语从句的倒装"
        ],
        "answer": 1,
        "explain": "虚拟条件句中省略 if 时，had、were、should 需提到主语之前，形成倒装。",
        "translation": "如果当地政府当初立即采取措施，洪水造成的损失本会小得多。"
      }
    ]
  },
  {
    "id": "subjunctive-should-do",
    "point": "虚拟语气",
    "sub": "建议、要求、命令类从句中的 should + 动词原形",
    "level": "cet6",
    "freq": 4,
    "rule": "在表示建议、要求、命令、坚持的动词（suggest, advise, demand, require, insist, order, propose）及其名词、形容词后面的 that 从句中，谓语用 should + 动词原形，should 通常可以省略。常见句型还有 It is necessary / important / essential that，以及 lest、for fear that 引导的从句。学习时先确认主句动词属于哪一类，再检查从句谓语是否用了动词原形，或者是否用了 should 加动词原形。",
    "tips": [
      "suggest 表示「暗示」时，从句用陈述语气",
      "insist 表示「坚持说」时不用虚拟语气",
      "should 省略后从句谓语是动词原形，不要加 s"
    ],
    "examples": [
      {
        "en": "The doctor advised that he should give up smoking at once.",
        "cn": "医生建议他立刻戒烟。",
        "note": "advise 后的从句用 should + 动词原形，should 可省略"
      },
      {
        "en": "It is necessary that every student should attend the meeting.",
        "cn": "每个学生都应当参加这次会议。",
        "note": "It is necessary that 句型中同样用 should + 动词原形"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The manager demanded that the report ____ before Friday.",
        "options": [
          "is finished",
          "was finished",
          "be finished",
          "will be finished"
        ],
        "answer": 2,
        "explain": "demand 后的从句用 should + 动词原形，should 省略后直接用 be。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "His suggestion is that we will start early tomorrow.",
        "right": "His suggestion is that we should start early tomorrow.",
        "explain": "suggestion 作主语时，表语从句用 should + 动词原形。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The committee insisted that the plan ____ (carry) out at once.",
        "answer": "(should) be carried",
        "explain": "insist 表示坚持要求，从句用 should + 动词原形；plan 是被执行的对象，用被动语态。"
      },
      {
        "type": "reorder",
        "words": [
          "suggested",
          "that",
          "he",
          "we",
          "leave",
          "early"
        ],
        "answer": "He suggested that we leave early.",
        "cn": "他建议我们早点动身。",
        "explain": "suggest 表示建议，从句谓语用 should 加动词原形，should 可省略，故用 leave。"
      },
      {
        "type": "analysis",
        "sentence": "It is essential that every applicant be given a fair chance to explain why he or she is qualified for the position.",
        "question": "句中的 be given 为什么用动词原形？",
        "options": [
          "因为主语是单数名词",
          "因为 It is essential that 句型要求从句用 should + 动词原形，should 被省略",
          "因为 applicant 是不可数名词",
          "因为该句是被动语态"
        ],
        "answer": 1,
        "explain": "在 It is essential / necessary / important that 结构中，从句谓语用 should + 动词原形。",
        "translation": "每个申请人都应获得公平的机会，说明自己为何胜任这一职位，这一点至关重要。"
      }
    ]
  },
  {
    "id": "inversion-negative-fronting",
    "point": "倒装",
    "sub": "否定词或否定短语置于句首引起部分倒装",
    "level": "cet4",
    "freq": 3,
    "rule": "当否定副词或否定短语（never, hardly, seldom, scarcely, rarely, little, nowhere, not until, no sooner, by no means, in no case 等）置于句首时，句子用部分倒装：把助动词、情态动词或 be 动词提到主语之前。no sooner 引起的倒装只发生在主句，than 从句仍用陈述语序。常见固定句式是 hardly 加 when 与 no sooner 加 than，前半句倒装，后半句不倒装，两种结构的时态搭配也要按规律记牢。",
    "tips": [
      "not until 置于句首时，倒装的是主句",
      "no sooner...than 中 than 从句不倒装",
      "hardly...when 中 when 从句用一般过去时"
    ],
    "examples": [
      {
        "en": "Never have I seen such a magnificent sunrise.",
        "cn": "我从未见过如此壮丽的日出。",
        "note": "否定词 never 置于句首，助动词 have 提到主语之前"
      },
      {
        "en": "Not until midnight did he finish his homework.",
        "cn": "直到午夜他才写完作业。",
        "note": "not until 置于句首，主句借助 did 构成倒装"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "Hardly ____ the office when the telephone rang.",
        "options": [
          "he had entered",
          "had he entered",
          "he has entered",
          "has he entered"
        ],
        "answer": 1,
        "explain": "Hardly 置于句首，主句用过去完成时并部分倒装。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Not until he lost his health he realized its value.",
        "right": "Not until he lost his health did he realize its value.",
        "explain": "not until 置于句首时，主句要部分倒装，借助 did。"
      },
      {
        "type": "fill",
        "q": "按倒装要求填空：Seldom ____ we see such a talented young pianist.",
        "answer": "do",
        "explain": "seldom 置于句首，一般现在时借助助动词 do 构成部分倒装。"
      },
      {
        "type": "reorder",
        "words": [
          "have",
          "never",
          "i",
          "such",
          "a",
          "beautiful",
          "view",
          "seen"
        ],
        "answer": "Never have I seen such a beautiful view.",
        "cn": "我从未见过如此美丽的景色。",
        "explain": "否定词 never 置于句首，助动词 have 提前，构成部分倒装。"
      },
      {
        "type": "analysis",
        "sentence": "No sooner had the students settled down in the classroom than the bell for the first class rang.",
        "question": "than 后面的从句为什么不用倒装？",
        "options": [
          "因为 than 是介词",
          "因为倒装只发生在前一个分句，than 引导的分句用陈述语序",
          "因为 the bell 是主语",
          "因为整个句子是过去时"
        ],
        "answer": 1,
        "explain": "no sooner 置于句首时只倒装主句，than 引导的分句用陈述语序。",
        "translation": "学生们刚在教室里坐定，第一节课的铃声就响了。"
      }
    ]
  },
  {
    "id": "inversion-only-and-concession",
    "point": "倒装",
    "sub": "only + 状语置首的倒装与 as / though 让步倒装",
    "level": "cet6",
    "freq": 3,
    "rule": "only 修饰状语（副词、介词短语或状语从句）并置于句首时，主句用部分倒装；only 修饰主语时句子不倒装。as 或 though 引导让步状语从句时，可把表语、状语或动词原形提到句首，构成「形容词或副词加 as 加主语加系动词」的倒装形式。",
    "tips": [
      "only 修饰主语时句子不倒装",
      "only 引导的状语从句本身不倒装",
      "as 引导让步从句时，句首名词前不加冠词"
    ],
    "examples": [
      {
        "en": "Only when he lost everything did he realize the value of friendship.",
        "cn": "直到失去一切，他才意识到友谊的价值。",
        "note": "only + 状语从句置于句首，主句倒装"
      },
      {
        "en": "Tired as he was, he kept on working.",
        "cn": "虽然他很累，却还在继续工作。",
        "note": "as 引导让步从句，表语 tired 提到句首"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "Only in this way ____ the problem on time.",
        "options": [
          "we can solve",
          "can we solve",
          "we solved",
          "solved we"
        ],
        "answer": 1,
        "explain": "only 加介词短语置于句首，主句用部分倒装。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Only after the meeting we learned the truth.",
        "right": "Only after the meeting did we learn the truth.",
        "explain": "only 加时间状语从句置于句首，主句用 did 构成部分倒装。"
      },
      {
        "type": "fill",
        "q": "按倒装要求填空：Hard as he ____, he could not finish the task on time.",
        "answer": "tried",
        "explain": "as 引导让步从句时，只把状语 hard 提前，其余部分保持陈述语序，故用 tried。"
      },
      {
        "type": "reorder",
        "words": [
          "only",
          "did",
          "he",
          "then",
          "realize",
          "the",
          "danger",
          "of",
          "the",
          "situation"
        ],
        "answer": "Only then did he realize the danger of the situation.",
        "cn": "直到那时他才意识到处境的危险。",
        "explain": "only 加副词 then 置于句首，主句用 did 构成部分倒装。"
      },
      {
        "type": "analysis",
        "sentence": "Young as she is, the new manager has already won the respect of the whole team.",
        "question": "句中 Young as she is 的语法作用是什么？",
        "options": [
          "由 as 引导的让步状语从句，表语提前构成倒装，意为虽然她很年轻",
          "as 引导的原因状语从句",
          "这是一个比较结构",
          "这是强调句的省略形式"
        ],
        "answer": 0,
        "explain": "as 引导让步从句时表语提前；句首为形容词时，其前不加冠词。",
        "translation": "这位新经理虽然年轻，却已经赢得了整个团队的尊重。"
      }
    ]
  },
  {
    "id": "agreement-modifier-subject",
    "point": "主谓一致",
    "sub": "主语带有修饰语及 there be 句型中的主谓一致",
    "level": "cet4",
    "freq": 4,
    "rule": "主语后接 along with、together with、as well as、rather than、including、besides 等短语时，谓语与最前面的中心词保持一致，因为这些短语不是并列连词。there be 句型中，be 动词与最靠近它的名词保持一致，遵循就近原则；both...and 连接两个主语时谓语用复数。",
    "tips": [
      "as well as 连接两个主语，谓语随第一个主语走",
      "there be 句型遵循就近原则",
      "both...and 连接主语时谓语用复数"
    ],
    "examples": [
      {
        "en": "The teacher as well as the students is going to attend the lecture.",
        "cn": "老师和学生们都打算去听讲座。",
        "note": "as well as 不改变主语数，谓语随 The teacher 用 is"
      },
      {
        "en": "There is a pen and two books on the desk.",
        "cn": "桌上有一支笔和两本书。",
        "note": "there be 遵循就近原则，与 a pen 保持一致"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "Tom, along with his friends, ____ every Sunday morning at the sports center.",
        "options": [
          "swim",
          "swims",
          "are swimming",
          "have swum"
        ],
        "answer": 1,
        "explain": "along with 是附加成分，主语 Tom 为第三人称单数，用 swims。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The manager together with his assistants have visited the factory.",
        "right": "The manager together with his assistants has visited the factory.",
        "explain": "together with 不影响主语的数，谓语与 The manager 保持一致。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：There ____ (be) two apples and a pear on the table.",
        "answer": "are",
        "explain": "there be 句型遵循就近原则，与 two apples 一致，用复数 are。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "students",
          "as",
          "well",
          "as",
          "is",
          "the",
          "teacher",
          "coming"
        ],
        "answer": "The teacher as well as the students is coming.",
        "cn": "老师和学生们都要来了。",
        "explain": "as well as 连接主语时，谓语与第一个主语 The teacher 保持一致。"
      },
      {
        "type": "analysis",
        "sentence": "Neither the students nor the teacher was aware of the sudden change in the examination schedule.",
        "question": "句中谓语为什么用 was 而不是 were？",
        "options": [
          "因为 change 是单数名词",
          "因为 neither...nor 连接两个主语时遵循就近原则，谓语与 the teacher 保持一致",
          "因为该句是被动语态",
          "因为 aware 是形容词"
        ],
        "answer": 1,
        "explain": "neither...nor 连接主语时，谓语与最靠近的主语保持一致。",
        "translation": "学生们和老师都没有察觉到考试时间安排的突然变化。"
      }
    ]
  },
  {
    "id": "agreement-collective-and-quantity",
    "point": "主谓一致",
    "sub": "集合名词、不定代词及数量短语作主语",
    "level": "cet4",
    "freq": 3,
    "rule": "集合名词 family、team、class、government 作整体看待时谓语用单数，强调其成员时用复数。everyone、anybody、nobody、each、either、neither 等不定代词作主语时谓语用单数。a number of 加复数名词谓语用复数，the number of 加复数名词谓语用单数。判断时先找到主语真正的中心词，再看它是否可数、是否被看作一个整体，最后才能确定谓语的单复数形式。",
    "tips": [
      "each of 加复数名词作主语，谓语用单数",
      "the number of 表示数量，谓语用单数",
      "分数或百分数加 of 加名词，谓语与该名词的数一致"
    ],
    "examples": [
      {
        "en": "The number of students who study abroad is increasing.",
        "cn": "出国留学的学生人数在增加。",
        "note": "the number of 表示数量，谓语用单数"
      },
      {
        "en": "Everyone in the class has finished the assignment.",
        "cn": "班里每个人都完成了作业。",
        "note": "everyone 作主语时谓语用单数 has"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "A number of new houses ____ built in the village last year.",
        "options": [
          "was",
          "were",
          "has been",
          "is"
        ],
        "answer": 1,
        "explain": "a number of 意为许多，主语为复数，谓语用 were。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The number of traffic accidents have increased sharply.",
        "right": "The number of traffic accidents has increased sharply.",
        "explain": "the number of 表示某类事物的数量，谓语用单数。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：Each of the students ____ (have) a copy of the new textbook.",
        "answer": "has",
        "explain": "each of 加复数名词作主语时，谓语用单数。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "watching",
          "family",
          "are",
          "the",
          "match"
        ],
        "answer": "The family are watching the match.",
        "cn": "这家人正在看比赛。",
        "explain": "family 强调家庭成员时谓语用复数，与 are watching 呼应。"
      },
      {
        "type": "analysis",
        "sentence": "Two thirds of the surface of the earth is covered by water, while two thirds of the students in our class come from the countryside.",
        "question": "前一个 two thirds 后的谓语为什么用 is？",
        "options": [
          "因为 two thirds 表示单数概念",
          "因为 of 后接的是不可数名词 the surface，分数修饰不可数名词时谓语用单数",
          "因为 covered 是被动语态",
          "因为 earth 是专有名词"
        ],
        "answer": 1,
        "explain": "分数或百分数加 of 加名词作主语时，谓语与该名词的数一致：不可数名词用单数，复数名词用复数。",
        "translation": "地球表面的三分之二是水，而我们班三分之二的学生来自农村。"
      }
    ]
  },
  {
    "id": "article-definite-indefinite",
    "point": "冠词与名词",
    "sub": "定冠词与不定冠词的泛指、特指区别",
    "level": "cet4",
    "freq": 3,
    "rule": "第一次提到某事物或泛指某一类中的任意一个时用不定冠词 a 或 an；再次提到或双方都明确的对象用定冠词 the。独一无二的事物、最高级、序数词、乐器名称前，以及 the 加形容词表示一类人时，都用定冠词。用 an 还是 a 取决于读音而非首字母。",
    "tips": [
      "an 取决于读音，如 an hour、a university",
      "最高级与序数词前一般要加 the",
      "play the piano 加 the，play football 不加"
    ],
    "examples": [
      {
        "en": "He bought a dictionary and the dictionary turned out to be very useful.",
        "cn": "他买了一本词典，这本词典后来非常有用。",
        "note": "首次提到用 a，再次提到用 the"
      },
      {
        "en": "The young should respect the old.",
        "cn": "年轻人应当尊重老年人。",
        "note": "the 加形容词可以表示一类人"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "He is ____ honest boy and everyone trusts him.",
        "options": [
          "a",
          "an",
          "the",
          "a few"
        ],
        "answer": 1,
        "explain": "honest 中的 h 不发音，该词以元音音素开头，用 an。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "She plays piano very well and often gives performances.",
        "right": "She plays the piano very well and often gives performances.",
        "explain": "乐器名称前要加定冠词 the。"
      },
      {
        "type": "fill",
        "q": "用适当的冠词填空：____ Yangtze River is the longest river in China.",
        "answer": "The",
        "explain": "江河名称前要用定冠词 the。"
      },
      {
        "type": "reorder",
        "words": [
          "is",
          "the",
          "he",
          "tallest",
          "boy",
          "in",
          "his",
          "class"
        ],
        "answer": "He is the tallest boy in his class.",
        "cn": "他是班上最高的男孩。",
        "explain": "形容词最高级前要加定冠词 the。"
      },
      {
        "type": "analysis",
        "sentence": "It is said that the professor has just returned from an interview with a famous writer, and the interview will be published next month.",
        "question": "句中第二个 the interview 为什么用定冠词？",
        "options": [
          "因为 interview 是不可数名词",
          "因为该名词在上文已经出现过，属于再次提到的特指对象",
          "因为句中出现了 next month",
          "因为 published 是被动语态"
        ],
        "answer": 1,
        "explain": "同一名词第二次出现时表示特指，应用定冠词。",
        "translation": "据说这位教授刚刚结束了对一位著名作家的采访，这次采访将于下月发表。"
      }
    ]
  },
  {
    "id": "noun-uncountable-zero-article",
    "point": "冠词与名词",
    "sub": "不可数名词、可数复数与固定搭配中的零冠词",
    "level": "cet4",
    "freq": 3,
    "rule": "不可数名词如 information、advice、furniture、equipment、luggage、news、progress 没有复数形式，也不与 a、an 连用，表示数量时借助 a piece of 等单位词。泛指复数名词或抽象名词前一般不加冠词；三餐、球类运动、学科名称以及 by 加交通工具等固定搭配中用零冠词。",
    "tips": [
      "information / advice / furniture 不可数，不能加 s",
      "泛指复数名词前不加 the",
      "by bus、at school、go to bed 等搭配不加冠词"
    ],
    "examples": [
      {
        "en": "She gave me some useful advice on how to prepare for the interview.",
        "cn": "她给了我一些关于如何准备面试的有用建议。",
        "note": "advice 不可数，用 some 修饰"
      },
      {
        "en": "Children need love and attention.",
        "cn": "孩子们需要关爱和关注。",
        "note": "泛指复数名词与抽象名词前用零冠词"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The teacher gave us some useful ____ on how to improve our writing.",
        "options": [
          "advices",
          "advice",
          "an advice",
          "the advices"
        ],
        "answer": 1,
        "explain": "advice 是不可数名词，没有复数形式，也不能用 a、an 修饰。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "I have bought a new furniture for my bedroom.",
        "right": "I have bought a piece of new furniture for my bedroom.",
        "explain": "furniture 不可数，表示一件家具要用 a piece of furniture。"
      },
      {
        "type": "fill",
        "q": "填入恰当的单位词：The manager asked us to collect two ____ of information before the meeting.",
        "answer": "pieces",
        "explain": "information 不可数，用 a piece of 计量，two 后接可数复数 pieces。"
      },
      {
        "type": "reorder",
        "words": [
          "go",
          "we",
          "to",
          "school",
          "by",
          "bus",
          "every",
          "day"
        ],
        "answer": "We go to school by bus every day.",
        "cn": "我们每天乘公交车上学。",
        "explain": "go to school 与 by bus 都是零冠词的固定搭配。"
      },
      {
        "type": "analysis",
        "sentence": "Although he is only ten years old, he can play basketball and the violin quite well.",
        "question": "句中 basketball 前不加冠词而 the violin 前加 the，原因是什么？",
        "options": [
          "因为 basketball 这个单词更长",
          "因为球类运动名称前用零冠词，而乐器名称前用定冠词 the",
          "因为 play 是及物动词",
          "因为 violin 是外来词"
        ],
        "answer": 1,
        "explain": "play 加球类运动用零冠词，play 加乐器要用 the。",
        "translation": "虽然他只有十岁，但篮球打得不错，小提琴也拉得相当好。"
      }
    ]
  },
  {
    "id": "prep-verb-collocation",
    "point": "介词与搭配",
    "sub": "动词与介词的固定搭配辨析",
    "level": "cet4",
    "freq": 5,
    "rule": "动词与介词的搭配需整体记忆：accuse sb of、remind sb of、rob sb of、prevent sb from、protect sb from、depend on、insist on、result in 表示导致、result from 表示由什么引起、account for、look forward to。判断时先看介词后的宾语，再回想要用哪个介词。遇到介词填空要先回忆动词本身的固定搭配，再确认介词后接的宾语形式，如果后面是动词则必须用动名词。",
    "tips": [
      "result in 导致，result from 由什么造成",
      "accuse sb of 与 charge sb with 不同",
      "look forward to 中 to 是介词，后接动名词"
    ],
    "examples": [
      {
        "en": "The heavy rain resulted in a serious traffic jam.",
        "cn": "大雨造成了严重的交通堵塞。",
        "note": "result in 表示导致，后面跟结果"
      },
      {
        "en": "We are looking forward to hearing from you soon.",
        "cn": "我们期待着尽快收到你的来信。",
        "note": "look forward to 中 to 为介词，后接动名词"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The new policy is expected to result ____ a sharp rise in employment.",
        "options": [
          "from",
          "in",
          "of",
          "to"
        ],
        "answer": 1,
        "explain": "result in 表示导致，后面接结果；result from 表示由什么引起。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The heavy fog prevented the plane to take off on time.",
        "right": "The heavy fog prevented the plane from taking off on time.",
        "explain": "prevent sth from doing sth 是固定搭配。"
      },
      {
        "type": "fill",
        "q": "填入恰当的介词：We should never judge a person ____ his appearance.",
        "answer": "by",
        "explain": "judge sb by sth 表示根据什么来判断某人。"
      },
      {
        "type": "reorder",
        "words": [
          "she",
          "her",
          "reminded",
          "me",
          "of",
          "promise"
        ],
        "answer": "She reminded me of her promise.",
        "cn": "她让我想起了她的承诺。",
        "explain": "remind sb of sth 表示使某人想起某事。"
      },
      {
        "type": "analysis",
        "sentence": "The sharp drop in sales resulted from a combination of poor management and the sudden change of consumer tastes.",
        "question": "句中 resulted from 应如何理解？",
        "options": [
          "意为导致，后面接结果",
          "意为由什么造成，主语是结果，from 后面接原因",
          "相当于 resulted in",
          "表示取决于"
        ],
        "answer": 1,
        "explain": "result from 的主语是结果，from 后面跟原因，意为由什么引起。",
        "translation": "销量的急剧下降是由管理不善与消费者口味突变共同造成的。"
      }
    ]
  },
  {
    "id": "prep-adj-noun-collocation",
    "point": "介词与搭配",
    "sub": "形容词、名词与介词的搭配及易混介词辨析",
    "level": "cet6",
    "freq": 4,
    "rule": "常见形容词加介词搭配：be interested in、be good at、be proud of、be responsible for、be sensitive to、be confident of、be keen on、be aware of。名词加介词搭配：a solution to、an approach to、an attitude towards、a demand for、confidence in、an increase in。易混介词要按搭配整体记忆。记忆时把形容词和名词与它的常用介词连成一个整体一起背，遇到 solution to、the key to 这类结构不要按汉语习惯换成 of，也不要随手换成 for。",
    "tips": [
      "solution / approach / key 后接 to 而不是 of",
      "be responsible for 表示对什么负责",
      "be aware of 与 be conscious of 意思相近"
    ],
    "examples": [
      {
        "en": "She is very confident of winning the first prize.",
        "cn": "她非常有信心赢得一等奖。",
        "note": "be confident of 表示对结果有信心"
      },
      {
        "en": "We are all aware of the importance of protecting the environment.",
        "cn": "我们都意识到保护环境的重要性。",
        "note": "be aware of 后接名词或动名词"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The committee has finally found a solution ____ the problem.",
        "options": [
          "of",
          "to",
          "for",
          "with"
        ],
        "answer": 1,
        "explain": "solution to 是固定搭配，表示什么的解决办法。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "He is responsible of training the new employees.",
        "right": "He is responsible for training the new employees.",
        "explain": "be responsible for 表示对什么负责。"
      },
      {
        "type": "fill",
        "q": "填入恰当的介词：Children are usually very curious ____ the world around them.",
        "answer": "about",
        "explain": "be curious about 是固定搭配，表示对什么好奇。"
      },
      {
        "type": "reorder",
        "words": [
          "is",
          "she",
          "interested",
          "in",
          "music",
          "classical"
        ],
        "answer": "She is interested in classical music.",
        "cn": "她对古典音乐感兴趣。",
        "explain": "be interested in 是固定搭配，in 后接名词。"
      },
      {
        "type": "analysis",
        "sentence": "The sudden increase in the number of tourists has put great pressure on the transport system of the small town.",
        "question": "句中 increase in 与 pressure on 体现了什么搭配规律？",
        "options": [
          "两者都是随机选择，没有规律",
          "表示在某方面的增长用 in，表示对某对象施加压力用 on，两者都是固定搭配",
          "in 与 on 在此可以互换",
          "in 表被动，on 表主动"
        ],
        "answer": 1,
        "explain": "表示在某一领域或方面的增加常用 in；put pressure on sb or sth 表示给什么施加压力。",
        "translation": "游客人数的骤增给这个小镇的交通系统带来了巨大压力。"
      }
    ]
  },
  {
    "id": "parallel-structure",
    "point": "平行结构与强调句",
    "sub": "并列句与并列成分的平行结构",
    "level": "cet4",
    "freq": 3,
    "rule": "由 and、but、or、not only...but also、both...and、either...or、as well as、rather than 连接的成分必须在语法形式上保持一致：名词对名词、不定式对不定式、从句对从句。比较结构与 than 的前后也要求形式对称，否则句子会失去平衡。做题时先找出并列连词，再看连词两边是否属于同一语法类别，如果两边形式不同，就要改动其中一边使它们对应起来。",
    "tips": [
      "not only...but also 连接的两个成分形式须一致",
      "either...or 连接的结构要对称",
      "比较结构前后要保持同一语法形式"
    ],
    "examples": [
      {
        "en": "She likes reading, swimming and travelling.",
        "cn": "她喜欢阅读、游泳和旅行。",
        "note": "三个并列成分都用动名词，形式一致"
      },
      {
        "en": "He is not only an excellent teacher but also a talented writer.",
        "cn": "他不仅是一位出色的老师，还是一位有才华的作家。",
        "note": "not only 与 but also 后面都是名词短语"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The new job requires patience, creativity and ____.",
        "options": [
          "to work hard",
          "working hard",
          "hard work",
          "work hardly"
        ],
        "answer": 2,
        "explain": "and 前面是名词，并列成分应保持为名词短语 hard work。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "He likes to swim in summer and skating in winter.",
        "right": "He likes to swim in summer and to skate in winter.",
        "explain": "并列的宾语应保持相同形式，可统一用不定式。"
      },
      {
        "type": "fill",
        "q": "按平行结构填空：The teacher told us to read the text carefully and ____ (take) notes while reading.",
        "answer": "take",
        "explain": "and 连接的两个不定式并列，第二个 to 可以省略，故用动词原形。"
      },
      {
        "type": "reorder",
        "words": [
          "not",
          "only",
          "he",
          "sings",
          "well",
          "but",
          "also",
          "dances",
          "beautifully"
        ],
        "answer": "He not only sings well but also dances beautifully.",
        "cn": "他不仅歌唱得好，舞也跳得漂亮。",
        "explain": "not only...but also 连接两个谓语动词，形式保持一致。"
      },
      {
        "type": "analysis",
        "sentence": "The purpose of the survey is to find out what students think of the new canteen and how they would like it to be improved.",
        "question": "句中 what 从句与 how 从句并列，这体现了什么原则？",
        "options": [
          "宾语从句必须成对出现",
          "并列成分应保持形式一致，两个从句都在 find out 后作宾语",
          "how 从句在此是状语从句",
          "what 从句在此是定语从句"
        ],
        "answer": 1,
        "explain": "and 连接的并列成分形式一致，两个从句均作 find out 的宾语。",
        "translation": "这项调查的目的是了解学生们对新食堂的看法，以及他们希望食堂如何改进。"
      }
    ]
  },
  {
    "id": "emphasis-it-that",
    "point": "平行结构与强调句",
    "sub": "强调句 It is ... that ... 与 not until 的强调结构",
    "level": "cet4",
    "freq": 3,
    "rule": "强调句的基本结构是 It is 或 It was 加被强调部分加 that 或 who 加其余部分，可以强调主语、宾语或状语，但不能强调谓语动词。被强调部分指人时可用 who，其余情况用 that。强调 not until 结构时，把 not until 部分整体提前，that 后面的句子用陈述语序。",
    "tips": [
      "去掉 It is 与 that 后句子仍能成立，才是强调句",
      "强调谓语动词要用 do、does、did",
      "not until 被强调后，that 从句用陈述语序"
    ],
    "examples": [
      {
        "en": "It was in the library that I met my old classmate.",
        "cn": "我就是在图书馆遇到老同学的。",
        "note": "强调地点状语 in the library，用 that"
      },
      {
        "en": "It is Mary who often helps me with my English.",
        "cn": "经常帮我学英语的正是玛丽。",
        "note": "被强调部分指人，可用 who"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "It was not until midnight ____ the fire was finally put out.",
        "options": [
          "when",
          "that",
          "then",
          "which"
        ],
        "answer": 1,
        "explain": "not until 的强调句结构为 It was not until...that...，that 后接陈述语序。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "It is the teachers that makes the school a better place.",
        "right": "It is the teachers that make the school a better place.",
        "explain": "强调句中 that 后的谓语应与被强调的主语 the teachers 保持一致。"
      },
      {
        "type": "fill",
        "q": "按强调句结构填空：It was last week ____ he told me the news.",
        "answer": "that",
        "explain": "被强调部分是时间状语，用 that 连接。"
      },
      {
        "type": "reorder",
        "words": [
          "was",
          "it",
          "john",
          "who",
          "broke",
          "the",
          "window"
        ],
        "answer": "It was John who broke the window.",
        "cn": "打破窗户的正是约翰。",
        "explain": "被强调部分指人，用 who 连接，其余部分保持陈述语序。"
      },
      {
        "type": "analysis",
        "sentence": "It was not until he had failed three times that he came to understand the importance of careful preparation.",
        "question": "句中的 that 从句为什么用陈述语序？",
        "options": [
          "因为该从句本身是疑问句",
          "因为 not until 的强调句固定为 It was not until...that 加陈述语序",
          "因为 he 是代词",
          "因为主句是过去时"
        ],
        "answer": 1,
        "explain": "强调结构 It was not until ... that ... 中，that 后面用陈述语序，不倒装。",
        "translation": "直到失败了三次，他才明白认真准备的重要性。"
      }
    ]
  },
  {
    "id": "tense-future-perfect",
    "point": "时态",
    "sub": "将来完成时与将来完成进行时",
    "level": "cet6",
    "freq": 4,
    "rule": "将来完成时表示到将来某一刻之前已经完成，构成为 will have + 过去分词，常与 by + 将来时间、by the time 从句连用。判断方法：先看状语是不是将来截止点，是则用将来完成时；若强调动作持续到那个截止点并仍在继续，就用 will have been + 现在分词。口诀：by 到将来，完成先行；持续未完，进行补位。",
    "tips": [
      "by + 将来时间后用 will have done，表示到那时已经完成。",
      "by the time 引导的从句用一般现在时表将来，主句才用将来完成时。",
      "侧重持续多久用将来完成进行时，侧重做完了用将来完成时。"
    ],
    "examples": [
      {
        "en": "By the end of this year, she will have published three papers.",
        "cn": "到今年年底，她将已经发表三篇论文。",
        "note": "by 引出将来截止点，动作在该点前完成，故用将来完成时。"
      },
      {
        "en": "By next June, he will have been working in this company for ten years.",
        "cn": "到明年六月，他就在这家公司工作满十年了。",
        "note": "强调持续到将来某时且仍继续，用将来完成进行时。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "By the time you get to the cinema, the film ____.",
        "options": [
          "will begin",
          "will have begun",
          "has begun",
          "began"
        ],
        "answer": 1,
        "explain": "by the time 从句用现在时表将来；主句动作在你到达之前就已完成，所以用将来完成时。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "By the end of next month, we will finish all the experiments.",
        "right": "By the end of next month, we will have finished all the experiments.",
        "explain": "by + 将来时间是截止点，动作在该点前完成，须用将来完成时；一般将来时没有这层截止含义。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：By the end of 2030, scientists ____ (develop) much better batteries for electric cars.",
        "answer": "will have developed",
        "explain": "by 引导的时间是将来截止点，动作到那时已完成，故填 will have developed。"
      },
      {
        "type": "reorder",
        "words": [
          "The",
          "workers",
          "will",
          "have",
          "completed",
          "the",
          "bridge",
          "before",
          "the",
          "rainy",
          "season",
          "comes"
        ],
        "answer": "The workers will have completed the bridge before the rainy season comes.",
        "cn": "在雨季来临之前，工人们将已经建好这座桥。",
        "explain": "before 从句用一般现在时表将来，主句表示到那个时间点已完成，故用将来完成时 will have completed。"
      },
      {
        "type": "analysis",
        "sentence": "By the time the new library opens to the public next spring, the workers will have been building it for nearly three years, and the city will have spent over fifty million yuan on the project.",
        "question": "句中 will have been building 使用将来完成进行时的原因是什么？",
        "options": [
          "表示到将来某时动作已经结束并有了结果",
          "强调动作持续到将来某时且仍可能继续",
          "表示过去将来要发生的动作",
          "表示按计划即将发生的动作"
        ],
        "answer": 1,
        "explain": "将来完成进行时强调动作持续到将来某时并可能继续，而 will have spent 强调到那时已完成的结果，两者分工不同。",
        "translation": "到明年春天新图书馆向公众开放时，工人们将已经建了将近三年，而这座城市在这个项目上也将已投入五千多万元。"
      }
    ]
  },
  {
    "id": "tense-perfect-continuous",
    "point": "时态",
    "sub": "现在完成进行时与现在完成时辨析",
    "level": "cet4",
    "freq": 5,
    "rule": "现在完成进行时 have been doing 表示动作从过去持续到现在、可能仍在继续，强调过程不断；现在完成时 have done 强调动作已完成或对现在造成的结果。判断方法：状语是一段持续的时间且强调一直在做，用完成进行时；出现 already、yet、just 或强调次数与结果，用现在完成时。口诀：重在过程用进行，重在结果用完成。",
    "tips": [
      "强调次数或结果用现在完成时，过程不断才用完成进行时。",
      "状态动词如 know、be 表持续状态，一般不用完成进行时。",
      "How long 提问常用现在完成进行时，回答看强调过程还是结果。"
    ],
    "examples": [
      {
        "en": "I have been reading that novel for a week, but I still have not finished it.",
        "cn": "那本小说我读了一周了，但还没读完。",
        "note": "强调一直在读这个持续过程，用现在完成进行时。"
      },
      {
        "en": "I have read that novel three times, so I know the story well.",
        "cn": "那本小说我读过三遍，所以对情节很熟。",
        "note": "强调次数与结果，动作已经完成，用现在完成时。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "I'm sorry I'm late. ____ for me long?",
        "options": [
          "Do you wait",
          "Did you wait",
          "Have you been waiting",
          "Have you waited"
        ],
        "answer": 2,
        "explain": "说话时等待仍在继续，且强调这段持续的过程，所以用现在完成进行时；一般过去时只问过去某一次动作。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "I have been knowing him since we were children.",
        "right": "I have known him since we were children.",
        "explain": "know 表示持续的状态，本身已含一直之意，不能用于进行时；since 引导的时间状语只需现在完成时。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The children are covered in mud because they ____ (play) football in the rain for an hour.",
        "answer": "have been playing",
        "explain": "for an hour 表示动作持续了一段时间，身上有泥正是这段持续动作留下的结果，故用现在完成进行时。"
      },
      {
        "type": "reorder",
        "words": [
          "She",
          "has",
          "been",
          "studying",
          "Japanese",
          "since",
          "she",
          "was",
          "ten"
        ],
        "answer": "She has been studying Japanese since she was ten.",
        "cn": "她从十岁起就一直在学日语。",
        "explain": "since 从句给出时间起点，动作从过去持续到现在并仍在继续，故用现在完成进行时 has been studying。"
      },
      {
        "type": "analysis",
        "sentence": "Although he has written five novels in the past ten years, he has been working on his sixth one for nearly three years and still has not finished it.",
        "question": "为什么前半句用 has written，而后半句用 has been working on？",
        "options": [
          "两者可以互换，表达上没有区别",
          "前者强调十年间完成的数量结果，后者强调持续且尚未结束",
          "前者是过去时，后者是现在时",
          "前者强调持续，后者强调完成"
        ],
        "answer": 1,
        "explain": "has written 与数量 five 搭配，强调十年间已完成的结果；has been working on 则强调持续未断、尚未结束的过程。",
        "translation": "虽然他在过去十年里写了五部小说，但他的第六部已经写了将近三年，至今仍未完成。"
      }
    ]
  },
  {
    "id": "nonfinite-infinitive-attribute-result",
    "point": "非谓语动词",
    "sub": "不定式作定语与结果状语",
    "level": "cet4",
    "freq": 4,
    "rule": "不定式作定语紧跟名词，与名词构成动宾或主谓关系，如 something to eat、the first to arrive；ability、chance 等抽象名词后也常用不定式。作结果状语多见于 too...to、enough to、only to（出乎意料的结果）结构。判断方法：它与前面的名词是动宾或主谓关系就是定语，若说明前面动作的结果则是状语。口诀：名词后作定语，only to 表结果。",
    "tips": [
      "something to eat 中名词是 eat 的逻辑宾语，属动宾关系。",
      "too...to 表示太……以致不能，不定式本身已含否定意义。",
      "only to do 表示出乎意料的最终结果，常与主句用逗号分开。"
    ],
    "examples": [
      {
        "en": "He hurried to the airport, only to find that his flight had been cancelled.",
        "cn": "他赶到机场，结果却发现航班已被取消。",
        "note": "only to do 表示出乎意料的最终结果，作结果状语。"
      },
      {
        "en": "I have nothing to write with, so may I borrow your pen?",
        "cn": "我没有可以写字的笔，能借你的钢笔用一下吗？",
        "note": "不定式修饰 nothing，且不能省略介词 with。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "In the relay race, Tom was the first ____ the finish line and the last ____ the track.",
        "options": [
          "to cross / to leave",
          "crossing / leaving",
          "to cross / leaving",
          "cross / leave"
        ],
        "answer": 0,
        "explain": "the first、the last 后接不定式作定语，说明被修饰名词的具体动作；两个并列部分结构应一致，所以都用不定式。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The ice on the lake is too thin to skate on it.",
        "right": "The ice on the lake is too thin to skate on.",
        "explain": "too...to 结构中不定式的逻辑宾语就是句子主语 the ice，介词 on 后不能再加 it，否则宾语重复。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The lecture was so boring as ____ (make) half of the students fall asleep.",
        "answer": "to make",
        "explain": "so + 形容词 + as to do 是结果状语结构，意为如此……以致，故填不定式 to make，不能填 making。"
      },
      {
        "type": "reorder",
        "words": [
          "We",
          "hurried",
          "to",
          "the",
          "station",
          "only",
          "to",
          "find",
          "the",
          "train",
          "had",
          "left"
        ],
        "answer": "We hurried to the station only to find the train had left.",
        "cn": "我们匆匆赶到车站，结果却发现火车已经开走了。",
        "explain": "only to do 作结果状语，表示出乎意料的最终结果；发现火车开走显然不是我们赶往车站的目的。"
      },
      {
        "type": "analysis",
        "sentence": "The girl hurried home only to find that her grandmother had been sent to hospital, which was the last thing she wanted to hear.",
        "question": "句中 only to find 充当什么成分，表达什么意思？",
        "options": [
          "目的状语，表示她回家的目的",
          "结果状语，表示出乎意料的最终结果",
          "定语，修饰前面的 home",
          "宾语补足语，补充说明 her grandmother"
        ],
        "answer": 1,
        "explain": "only to do 是结果状语并含出乎意料之意；若表目的应用 to find 且不能加 only，only 正是点明结果的意外性。",
        "translation": "女孩匆匆赶回家，结果却发现祖母已被送去医院，这是她最不想听到的消息。"
      }
    ]
  },
  {
    "id": "nonfinite-absolute-construction",
    "point": "非谓语动词",
    "sub": "独立主格结构的构成与用法",
    "level": "cet6",
    "freq": 4,
    "rule": "独立主格结构由名词或代词加上非谓语动词（也可加形容词、副词）构成，它的逻辑主语与主句主语不同，在句中作状语，表示时间、原因、条件或伴随。判断方法：状语部分的逻辑主语与主句主语不一致时，不能用普通分词状语，必须保留自己的主语形成独立主格；加连词后即可变成从句。常见形式：名词 + doing 表主动、名词 + done 表被动、with + 名词 + 分词。口诀：主不同，自带来；加连词，便成句。",
    "tips": [
      "独立主格的逻辑主语与主句主语不同，这是它与分词状语的根本区别。",
      "名词后用 done 表被动或已完成，用 doing 表主动或正在进行。",
      "with + 名词 + 分词也属独立主格，with 后的名词是逻辑主语。"
    ],
    "examples": [
      {
        "en": "The homework finished, the children ran out to play.",
        "cn": "作业做完了，孩子们跑出去玩了。",
        "note": "homework 与主句主语不同，故用独立主格表被动完成。"
      },
      {
        "en": "Weather permitting, the sports meeting will be held as scheduled.",
        "cn": "如果天气允许，运动会将如期举行。",
        "note": "permit 的逻辑主语 weather 与主句主语不同。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ no bus available, we had to walk home in the rain.",
        "options": [
          "There being",
          "There is",
          "Being",
          "There was"
        ],
        "answer": 0,
        "explain": "there be 结构的独立主格用 there being，不能用 There is 那样的完整句子。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The meeting was over, we all went home.",
        "right": "The meeting being over, we all went home.",
        "explain": "两个完整句子不能只用逗号连接；meeting 与主句主语不同，应把 be 改为非谓语形式 being。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The problem ____ (settle), we moved on to the next item on the agenda.",
        "answer": "settled",
        "explain": "problem 与 settle 是被动关系且已完成，独立主格用名词加过去分词，故填 settled。"
      },
      {
        "type": "reorder",
        "words": [
          "The",
          "work",
          "done",
          "we",
          "went",
          "out",
          "for",
          "a",
          "walk"
        ],
        "answer": "The work done, we went out for a walk.",
        "cn": "活干完了，我们出去散了散步。",
        "explain": "work 与 do 是被动关系且动作已完成，故用名词加过去分词的独立主格结构，在句中作时间状语。"
      },
      {
        "type": "analysis",
        "sentence": "All things considered, the committee decided that the new policy should be put into practice before the end of the year.",
        "question": "句首的 All things considered 是什么结构，为什么用 considered 而不用 considering？",
        "options": [
          "分词作状语，逻辑主语是主句主语 the committee",
          "独立主格结构，all things 与 consider 是被动关系",
          "动名词短语作主语",
          "宾语从句被省略了引导词"
        ],
        "answer": 1,
        "explain": "all things 是 consider 的逻辑主语且为被动关系即事情被考虑，与主句主语 the committee 不同，故用独立主格。",
        "translation": "综合考虑所有因素之后，委员会决定这项新政策应在年底前付诸实施。"
      }
    ]
  },
  {
    "id": "clause-relative-pronoun-vs-adverb",
    "point": "从句",
    "sub": "关系代词与关系副词的选择",
    "level": "cet4",
    "freq": 5,
    "rule": "关系代词 who、which、that 等在定语从句中作主语、宾语或定语；关系副词 when、where、why 在从句中作时间、地点、原因状语。判断方法：把先行词代回从句，缺主语或宾语就用关系代词，成分齐全只缺状语才用关系副词。注意 the reason why 后从句完整，而 the reason that he gave 中 that 要作宾语。口诀：缺主宾用代词，缺状语用副词。",
    "tips": [
      "把先行词放回从句，缺主语或宾语用关系代词，缺状语才用关系副词。",
      "why 后从句完整，gave 缺宾语时须用 that 或 which。",
      "介词提前时只能用 which 或 whom，不能用 that 或 who。"
    ],
    "examples": [
      {
        "en": "This is the house where my grandparents lived for forty years.",
        "cn": "这就是我祖父母住了四十年的房子。",
        "note": "从句成分完整，只缺地点状语，故用 where。"
      },
      {
        "en": "This is the house which my grandparents built in 1980.",
        "cn": "这就是我祖父母 1980 年建的房子。",
        "note": "从句缺 built 的宾语，须用关系代词 which。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "I still remember the day ____ we first met in that small town.",
        "options": [
          "which",
          "that",
          "when",
          "where"
        ],
        "answer": 2,
        "explain": "从句 we first met 成分齐全，只缺时间状语；先行词 the day 表时间，故用关系副词 when。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "This is the reason why he gave me yesterday.",
        "right": "This is the reason that he gave me yesterday.",
        "explain": "从句 he gave me 中 gave 缺直接宾语，须用关系代词 that；why 只能作原因状语，不能充当宾语。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：I will never forget the summer I ____ (spend) with my grandparents in the countryside.",
        "answer": "spent",
        "explain": "关系代词在从句中作 spend 的宾语被省略，主句讲的是过去的事，所以从句用一般过去时 spent。"
      },
      {
        "type": "reorder",
        "words": [
          "This",
          "is",
          "the",
          "reason",
          "that",
          "he",
          "gave",
          "for",
          "being",
          "late"
        ],
        "answer": "This is the reason that he gave for being late.",
        "cn": "这就是他为迟到给出的理由。",
        "explain": "从句中 gave 后面缺宾语，所以用关系代词 that 而不是关系副词 why，why 只能作状语。"
      },
      {
        "type": "analysis",
        "sentence": "The small town where I spent my childhood has now become a popular tourist attraction that attracts thousands of visitors every year.",
        "question": "句中 where 和 that 分别充当什么成分，为什么不能互换？",
        "options": [
          "两者都作状语，可以互换",
          "where 在第一个从句中作地点状语，that 在第二个从句中作主语",
          "where 作主语，that 作宾语",
          "where 是关系代词，that 是关系副词"
        ],
        "answer": 1,
        "explain": "where 前的从句成分完整只缺地点状语，故用关系副词；第二个从句 attracts 之前缺主语，故用关系代词 that，两者不能互换。",
        "translation": "我度过童年的那个小镇如今已经成了每年吸引成千上万游客的热门景点。"
      }
    ]
  },
  {
    "id": "clause-noun-that-vs-what",
    "point": "从句",
    "sub": "名词性从句连接词辨析",
    "level": "cet6",
    "freq": 5,
    "rule": "that 在名词性从句中只起连接作用，不作任何成分，所以它后面必须是结构完整的句子；what 相当于 the thing that，在从句中必须充当主语、宾语或表语，用 what 就意味着从句缺成分。判断方法：把从句单独拿出来分析成分，主谓宾齐全就用 that，缺主语或宾语就用 what。口诀：从句缺成分用 what，成分齐全用 that。",
    "tips": [
      "what 在从句中必须充当主语、宾语或表语，用 what 就说明从句缺成分。",
      "that 只起连接作用不作成分，因此它后面必须是完整的句子。",
      "that 引导主语从句或同位语从句时通常不省略，宾语从句才可以省略。"
    ],
    "examples": [
      {
        "en": "What he said at the meeting surprised everyone present.",
        "cn": "他在会上说的话让在场的每个人都很吃惊。",
        "note": "从句缺宾语，故用 what 引导并在从句中作宾语。"
      },
      {
        "en": "That he passed the exam without any preparation surprised us all.",
        "cn": "他毫无准备就通过了考试，这让我们都很吃惊。",
        "note": "从句结构完整，that 只作引导词，不充当成分。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ he told me last night was really disappointing.",
        "options": [
          "That",
          "What",
          "Which",
          "Whether"
        ],
        "answer": 1,
        "explain": "从句中 told 缺直接宾语，须用 what 引导主语从句并充当宾语；that 不作成分。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "I don't know that I should do next.",
        "right": "I don't know what I should do next.",
        "explain": "从句中 do 缺宾语，只有 what 能充当该宾语；that 只起连接作用，要求从句本身完整。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：What we need most right now ____ (be) more time and a clearer plan.",
        "answer": "is",
        "explain": "what 引导的主语从句作主语时，谓语通常用单数；这里说的是当前的需要，所以填 is 而不是 are。"
      },
      {
        "type": "reorder",
        "words": [
          "What",
          "she",
          "said",
          "at",
          "the",
          "meeting",
          "made",
          "us",
          "think"
        ],
        "answer": "What she said at the meeting made us think.",
        "cn": "她在会上说的话让我们深思。",
        "explain": "said 后面缺宾语，须用 what 引导主语从句；整个从句作句子主语，谓语用 made。"
      },
      {
        "type": "analysis",
        "sentence": "It is still not clear whether the company will accept our offer, but what is certain is that we have done everything we could.",
        "question": "句中 what 与 that 在从句中的作用有什么不同？",
        "options": [
          "两者作用相同，完全可以互换",
          "what 在从句中作主语，that 只起连接作用而不作成分",
          "what 只起连接作用，that 在从句中作主语",
          "what 引导定语从句，that 引导名词性从句"
        ],
        "answer": 1,
        "explain": "what 在 what is certain 中充当从句主语；that 引导的从句结构完整，只起连接作用而不作成分，这就是两者的区别。",
        "translation": "公司是否会接受我们的报价仍不清楚，但可以确定的是，我们已经做了能做的一切。"
      }
    ]
  },
  {
    "id": "virt-mixed-subjunctive",
    "point": "虚拟语气",
    "sub": "混合虚拟：主从句时间不一致",
    "level": "cet6",
    "freq": 4,
    "rule": "混合虚拟指 if 从句与主句所指时间不一致：从句说过去用 had done，主句说现在用 would do；从句说现在用过去式，主句说过去用 would have done。判断口诀「先找时间词，再分头后退——过去退完成，现在退过去」：从句里的 yesterday、last week 对主句的 now、today 就是信号。",
    "tips": [
      "从句与主句时间不一致时，两边各自按自己的时间后退，不强求时态对应。",
      "常见组合：过去条件 had done 配现在结果 would do。",
      "信号词：从句有 yesterday，主句有 now、today。"
    ],
    "examples": [
      {
        "en": "If she had finished her homework earlier, she would be watching TV now.",
        "cn": "如果她早些完成作业，现在就在看电视了。",
        "note": "从句指过去、主句指现在，两边各自后退。"
      },
      {
        "en": "If I were more patient, I would not have quarreled with him yesterday.",
        "cn": "如果我更有耐心一些，昨天就不会和他吵架了。",
        "note": "从句指现在用过去式，主句指过去用完成式。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "If he ____ the doctor's advice last month, he would not be suffering from such a bad cold now.",
        "options": [
          "followed",
          "had followed",
          "follows",
          "would follow"
        ],
        "answer": 1,
        "explain": "last month 指过去用 had followed，now 指现在用 would be doing。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "If I had taken your advice, I will be feeling much better now.",
        "right": "If I had taken your advice, I would be feeling much better now.",
        "explain": "从句是过去虚拟，主句由 now 指向现在，须用 would 加动词，不能用 will。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：If he were a careful driver, he ____ (not have) so many accidents last year.",
        "answer": "would not have had",
        "explain": "从句用 were 说明与现在相反，主句 last year 指过去，故用 would not have had。"
      },
      {
        "type": "reorder",
        "words": [
          "if",
          "i",
          "had",
          "known",
          "you",
          "were",
          "coming",
          "i",
          "would",
          "be",
          "waiting",
          "at",
          "the",
          "airport",
          "now"
        ],
        "answer": "If I had known you were coming, I would be waiting at the airport now.",
        "cn": "要是我知道你要来，我现在就在机场等着了。",
        "explain": "从句 had known 指过去，主句 now 指现在，这是混合虚拟搭配。"
      },
      {
        "type": "analysis",
        "sentence": "If the government had invested more in public transport ten years ago, the city would not be struggling with such heavy traffic and air pollution today.",
        "question": "该句为何采用 had invested 与 would not be struggling 的组合？",
        "options": [
          "从句与主句都指过去，只是主句用了进行时",
          "从句的条件与过去事实相反，主句的结果出现在现在，两者时间不同",
          "主句用进行时是为了表示将来的动作",
          "had invested 是过去完成时的陈述用法，与虚拟无关"
        ],
        "answer": 1,
        "explain": "从句的条件针对过去，用 had done；主句的结果针对现在，用 would be doing，两句话时间不同。",
        "translation": "如果政府十年前在公共交通上投入更多，这座城市今天就不会为如此严重的交通拥堵和空气污染而苦恼。"
      }
    ]
  },
  {
    "id": "virt-implied-condition",
    "point": "虚拟语气",
    "sub": "含蓄条件句：but for 用法",
    "level": "cet4",
    "freq": 4,
    "rule": "含蓄条件句不出现 if 从句，而用 but for、without、otherwise、or 等词暗示条件，谓语形式与 if 虚拟句一致。but for、without 后接名词，意为「要不是」，主句用 would have done；otherwise 前一分句陈述事实，后一分句用 would have done 表示相反结果。判断方法：句中无 if 却出现「本该发生而未发生」的结果，就找哪个词替代了条件。",
    "tips": [
      "but for 与 without 后只接名词，不能接句子。",
      "otherwise 前句陈述事实，后句用 would have done。",
      "or 表示「否则」时语义接近 otherwise，触发虚拟语气。"
    ],
    "examples": [
      {
        "en": "But for the timely rescue, the fishermen would have lost their lives.",
        "cn": "要不是及时营救，那些渔民就没命了。",
        "note": "but for 表「要不是」，主句用完成虚拟形式。"
      },
      {
        "en": "The road was blocked by the flood; otherwise we would have arrived on time.",
        "cn": "道路被洪水阻断，否则我们就准时到达了。",
        "note": "otherwise 引出相反结果，主句与过去相反。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ your generous support, we could not have completed the survey in such a short time.",
        "options": [
          "But for",
          "Because of",
          "As for",
          "Thanks to"
        ],
        "answer": 0,
        "explain": "后句 could not have completed 是虚拟形式，只有 But for 表示「要不是」。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Without your timely warning, the accident would happen yesterday.",
        "right": "Without your timely warning, the accident would have happened yesterday.",
        "explain": "yesterday 指过去，主句须用 would have done。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：I was busy with my thesis last week; otherwise I ____ (join) your trip to the mountains.",
        "answer": "would have joined",
        "explain": "otherwise 前句是过去事实，后句表示相反结果，用 would have joined。"
      },
      {
        "type": "reorder",
        "words": [
          "but",
          "for",
          "the",
          "heavy",
          "fog",
          "the",
          "plane",
          "would",
          "have",
          "taken",
          "off",
          "on",
          "time"
        ],
        "answer": "But for the heavy fog, the plane would have taken off on time.",
        "cn": "要不是大雾，飞机本会准时起飞。",
        "explain": "but for 等于 if it had not been for，主句随之用完成式。"
      },
      {
        "type": "analysis",
        "sentence": "Without the financial support of his parents and the encouragement of his tutor, the young researcher would never have completed the experiment that later won him a national award.",
        "question": "句中 Without 引导的短语在语法上起什么作用？",
        "options": [
          "作原因状语，说明主句谓语发生的真实原因",
          "作含蓄条件，相当于 If it had not been for，与主句构成过去虚拟",
          "作方式状语，修饰 completed 所指的动作方式",
          "作主语，与谓语 would never have completed 保持一致"
        ],
        "answer": 1,
        "explain": "Without 加名词替代了 if 从句，表示与过去相反的条件，主句用 would never have completed。",
        "translation": "没有父母的经济支持和导师的鼓励，这位年轻研究者绝不会完成那项后来为他赢得国家级奖项的实验。"
      }
    ]
  },
  {
    "id": "inv-if-omitted",
    "point": "倒装",
    "sub": "省略 if 的虚拟条件句倒装",
    "level": "cet4",
    "freq": 5,
    "rule": "虚拟条件句省略 if 时，要把从句中的 were、had、should 提到主语之前构成部分倒装，如 Were I you, I would take the job。三点注意：只有这三个词能提前，从句含实义动词过去式则不能省 if；倒装只在从句，主句语序不变；not 留在主语后，如 Had it not been for。",
    "tips": [
      "能提前的只有 were、had、should，实义动词过去式不能。",
      "倒装只在条件从句，主句仍用 would、could 加动词的正常语序。",
      "not 不倒装，写作 Had it not been for。"
    ],
    "examples": [
      {
        "en": "Were I in charge of the project, I would set a more realistic schedule.",
        "cn": "如果我负责这个项目，我会制定更现实的进度表。",
        "note": "省略 if 后 were 提到主语之前。"
      },
      {
        "en": "Should you change your mind, please let me know before Friday.",
        "cn": "万一你改变主意，请在周五之前告诉我。",
        "note": "省略 if 后 should 提前，表示将来条件。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "____ it not been for the traffic jam, we would have caught the early train.",
        "options": [
          "If",
          "Had",
          "Were",
          "Should"
        ],
        "answer": 1,
        "explain": "主句 would have caught 说明与过去相反，省略 if 后把 had 提到句首。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Was I you, I would apologize to her right now.",
        "right": "Were I you, I would apologize to her right now.",
        "explain": "省略 if 的虚拟条件句中 be 一律用 were 并提前，构成 Were I you。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：____ (be) it not for his encouragement, I would not be standing here today.",
        "answer": "Were",
        "explain": "省略 if 后把 were 提到主语前，Were it not for 表示与现在相反。"
      },
      {
        "type": "reorder",
        "words": [
          "had",
          "she",
          "taken",
          "the",
          "medicine",
          "she",
          "would",
          "have",
          "recovered",
          "by",
          "now"
        ],
        "answer": "Had she taken the medicine, she would have recovered by now.",
        "cn": "要是她吃了药，现在早就康复了。",
        "explain": "省略 if 后 had 提前；by now 指到现在的结果，主句用完成式。"
      },
      {
        "type": "analysis",
        "sentence": "Had the committee not postponed the decision, the construction of the new library would have started before the rainy season and the students would be reading there this autumn.",
        "question": "句中 Had 位于句首的原因是什么？",
        "options": [
          "这是疑问句常用的主谓倒装结构",
          "虚拟条件句省略 if，把 had 提前，从句表示与过去事实相反",
          "had 是助动词，用于构成过去完成时的疑问式",
          "为了强调谓语动作，句子使用了全部倒装"
        ],
        "answer": 1,
        "explain": "从句省略 if，只把 had 提到句首，not 仍留在主语后；主句用 would have started。",
        "translation": "如果委员会没有推迟这项决定，新图书馆本会在雨季前开工，今年秋天学生们就会在那里看书了。"
      }
    ]
  },
  {
    "id": "inv-so-such-fronting",
    "point": "倒装",
    "sub": "so / such 置首与表语前置倒装",
    "level": "cet6",
    "freq": 3,
    "rule": "so 加形容词或副词、such 加名词短语置于句首表示强调时，其所在主句要部分倒装：So loudly did he shout that everyone turned around。作表语的形容词、分词或介词短语提到句首也用倒装：Gone are the days of handwritten letters。口诀：so、such 打头就倒装，表语一提也倒装。",
    "tips": [
      "so 后接形容词或副词，such 后接名词短语，置首都倒装。",
      "结果从句 that... 语序不变，倒装只在 so / such 所在的主句。",
      "Gone、Present 等表语置首时主语在后，谓语与真主语一致。"
    ],
    "examples": [
      {
        "en": "So convincing was his argument that even his critics changed their minds.",
        "cn": "他的论证如此有说服力，连批评他的人都改变了想法。",
        "note": "So 加形容词置首，主句须部分倒装。"
      },
      {
        "en": "Such was the impact of the speech that the hall fell into complete silence.",
        "cn": "演讲的冲击力如此之大，整个大厅陷入彻底的寂静。",
        "note": "Such 置首作表语，句子倒装为 Such was..."
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "So absorbed ____ in his work that he did not notice the heavy rain outside.",
        "options": [
          "he was",
          "was he",
          "he is",
          "is he"
        ],
        "answer": 1,
        "explain": "so 加形容词置首时主句部分倒装，把 was 提前；后句表明发生在过去。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "So difficult the task was that no one wanted to accept it.",
        "right": "So difficult was the task that no one wanted to accept it.",
        "explain": "so 加形容词置首须部分倒装，故 the task was 应改为 was the task。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：Such ____ (be) the popularity of the new app that its server broke down twice in one day.",
        "answer": "was",
        "explain": "such 置首作表语须倒装；broke down 说明是过去，故填 was。"
      },
      {
        "type": "reorder",
        "words": [
          "so",
          "rapidly",
          "did",
          "the",
          "city",
          "develop",
          "that",
          "its",
          "population",
          "doubled",
          "in",
          "a",
          "decade"
        ],
        "answer": "So rapidly did the city develop that its population doubled in a decade.",
        "cn": "这座城市发展得如此迅速，十年内人口翻了一番。",
        "explain": "so 加副词置首引起主句倒装，故用 did the city develop。"
      },
      {
        "type": "analysis",
        "sentence": "Gone are the days when people had to queue for hours to buy a train ticket, since a few taps on a mobile phone can now complete the whole booking in seconds.",
        "question": "句中 Gone are the days 这一结构成立的原因是什么？",
        "options": [
          "Gone 是分词，与 are 一起构成现在完成时",
          "表语 Gone 提到句首引起倒装，真正的主语是 the days",
          "the days 是时间状语，因此谓语 are 提到了它的前面",
          "这是 there be 句型的变体，用来表示存在"
        ],
        "answer": 1,
        "explain": "表语 Gone 置首，谓语 are 提到真正主语 the days 之前，形成全部倒装。",
        "translation": "人们不得不排队数小时才能买到一张火车票的日子已经过去，如今在手机上轻点几下就能在几秒内完成订票。"
      }
    ]
  },
  {
    "id": "agree-either-or-nor",
    "point": "主谓一致",
    "sub": "并列主语的就近与就远原则",
    "level": "cet4",
    "freq": 4,
    "rule": "or、either...or、neither...nor、not only...but also 连接的并列主语，谓语与最靠近它的那个一致，这叫就近原则。with、together with、as well as 引出的是附加说明，不算并列主语，谓语仍与第一个主语一致，这叫就远原则。both...and 连接的主语用复数。口诀：or 看最近，with 看最前。",
    "tips": [
      "either...or 与 neither...nor 一律就近一致。",
      "as well as、with 引出的成分不是主语，谓语看核心主语。",
      "both...and 连接两个主语时谓语固定用复数。"
    ],
    "examples": [
      {
        "en": "Neither the manager nor the employees were satisfied with the new schedule.",
        "cn": "经理和员工都不满意新的日程安排。",
        "note": "就近一致，靠近谓语的是复数 employees。"
      },
      {
        "en": "The teacher, as well as her students, is looking forward to the summer camp.",
        "cn": "老师连同她的学生们都盼望着夏令营。",
        "note": "as well as 是附加成分，谓语看前面的主语。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "Not only the students but also their supervisor ____ invited to the opening ceremony.",
        "options": [
          "were",
          "was",
          "have been",
          "are"
        ],
        "answer": 1,
        "explain": "not only...but also 遵循就近原则，靠近谓语的是单数 supervisor，故用 was。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "Either the twin brothers or their cousin have taken the dictionary away.",
        "right": "Either the twin brothers or their cousin has taken the dictionary away.",
        "explain": "either...or 就近一致，靠近谓语的是单数 cousin，故用 has。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：The professor, together with his two assistants, ____ (be) going to attend the conference in Beijing.",
        "answer": "is",
        "explain": "together with 引出的成分不是主语，谓语与 The professor 一致，用 is。"
      },
      {
        "type": "reorder",
        "words": [
          "neither",
          "the",
          "teacher",
          "nor",
          "the",
          "students",
          "were",
          "late",
          "for",
          "the",
          "meeting"
        ],
        "answer": "Neither the teacher nor the students were late for the meeting.",
        "cn": "老师和学生们开会都没有迟到。",
        "explain": "neither...nor 连接主语时谓语与最近的主语 the students 一致。"
      },
      {
        "type": "analysis",
        "sentence": "Not only the quality of the products but also the after-sales service of this company has won the trust of customers who used to buy from its competitors.",
        "question": "句中谓语用单数 has won 的依据是什么？",
        "options": [
          "主语是 the quality of the products，中心词 quality 为单数",
          "not only...but also 遵循就近原则，靠近谓语的 the after-sales service 是单数",
          "company 是集合名词，谓语必须用单数",
          "定语从句中的 customers 决定了主句谓语用单数"
        ],
        "answer": 1,
        "explain": "not only...but also 就近原则，紧靠谓语的是单数 the after-sales service，故用 has won。",
        "translation": "这家公司不仅产品质量过硬，其售后服务也赢得了那些过去从竞争对手处购买产品的顾客的信任。"
      }
    ]
  },
  {
    "id": "agree-relative-clause",
    "point": "主谓一致",
    "sub": "定语从句与 one of 结构的一致",
    "level": "cet6",
    "freq": 4,
    "rule": "定语从句谓语的数由先行词决定。one of the 加复数名词加 who 的结构中，who 的先行词是复数名词，从句谓语用复数；若 one 前有 the only、the very 限定，先行词就是 one，从句谓语改用单数。此外，a number of 表「许多」用复数谓语，the number of 表数量用单数谓语。口诀：who 跟先行词走，only one 用单数。",
    "tips": [
      "定语从句谓语与先行词一致，先找出 who 指代哪个名词。",
      "one of 结构从句用复数，the only one 用单数。",
      "a number of 用复数谓语，the number of 用单数谓语。"
    ],
    "examples": [
      {
        "en": "He is one of the few students who have ever won the national scholarship.",
        "cn": "他是少数几个曾获得国家奖学金的学生之一。",
        "note": "who 的先行词是复数 students，故用 have。"
      },
      {
        "en": "The number of tourists visiting the ancient town has risen sharply in recent years.",
        "cn": "近年来到这座古镇旅游的游客数量急剧上升。",
        "note": "the number of 表数量，谓语用单数。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "She is the only one of the applicants who ____ the final interview so far.",
        "options": [
          "have passed",
          "has passed",
          "have been passed",
          "pass"
        ],
        "answer": 1,
        "explain": "the only one of 加复数加 who 中，先行词是单数 the only one。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "This is one of the questions that has puzzled economists for decades.",
        "right": "This is one of the questions that have puzzled economists for decades.",
        "explain": "one of the questions that 中 that 指复数 questions，从句用 have。"
      },
      {
        "type": "fill",
        "q": "用括号中动词的适当形式填空：A number of volunteers ____ (be) needed to help organize the charity concert.",
        "answer": "are",
        "explain": "a number of 表「许多」，后接复数名词作主语时谓语用复数。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "number",
          "of",
          "students",
          "studying",
          "abroad",
          "has",
          "increased",
          "in",
          "recent",
          "years"
        ],
        "answer": "The number of students studying abroad has increased in recent years.",
        "cn": "近年来出国留学的学生数量有所增加。",
        "explain": "the number of 表数量，中心词是 number，谓语用单数。"
      },
      {
        "type": "analysis",
        "sentence": "The professor is one of those researchers who are convinced that the data collected over the past decade will reshape our understanding of urban life.",
        "question": "定语从句中谓语用 are 而不是 is 的原因是什么？",
        "options": [
          "主句主语 the professor 是单数，从句须与主句保持一致",
          "who 的先行词是复数 those researchers，从句谓语随之用复数",
          "data 是不可数名词，从句谓语因此用复数",
          "convinced 后面还有 that 从句，谓语须用复数"
        ],
        "answer": 1,
        "explain": "who 的先行词是 those researchers 而非 one，从句用 are；主句仍与 professor 一致。",
        "translation": "这位教授是那些确信过去十年所收集的数据将重塑我们对城市生活理解的研究者之一。"
      }
    ]
  },
  {
    "id": "art-an-the-zero-choices",
    "point": "冠词与名词",
    "sub": "a an the 与零冠词的选择",
    "level": "cet4",
    "freq": 5,
    "rule": "判断冠词分三步：先看名词是特指还是泛指——说话人和听话人都能确定所指的对象，用 the；泛指某一类中的一个，用 a/an。再看发音而非拼写选 a 还是 an：辅音音素前用 a，元音音素前用 an，所以是 an hour、a university、a European country。最后处理固定用法与零冠词：独一无二的事物、序数词、最高级、乐器、方位名前用 the；三餐、球类、学科、by bus 一类交通方式前不加冠词。口诀：特指加 the，泛指用 a；选 a 或 an 看音不看字母，惯用法单独记。",
    "tips": [
      "a 或 an 由后接词的读音决定：an hour、a useful tool，不看首字母看音标。",
      "独一无二的事物、序数词、最高级、乐器、方位名前通常加 the，如 the sun、play the violin。",
      "三餐、球类、学科、by bus 等固定短语前用零冠词，不要凭直觉补 the。"
    ],
    "examples": [
      {
        "en": "She plays the violin every evening, but she never plays basketball on Sunday mornings.",
        "cn": "她每天晚上拉小提琴，但从不打周日上午的篮球。",
        "note": "乐器前用 the，球类运动前用零冠词，属固定规则。"
      },
      {
        "en": "It took me an hour to find the book that the teacher had recommended.",
        "cn": "我花了一个小时才找到老师推荐的那本书。",
        "note": "hour 的首音是元音音素用 an；后文那本书特指用 the。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "Tom is ____ honest boy, and everyone in ____ village likes him.",
        "options": [
          "a; the",
          "an; the",
          "an; a",
          "the; the"
        ],
        "answer": 1,
        "explain": "honest 中的 h 不发音，首音素是元音，故用 an；village 是双方都能确定的那一个特定村庄，须用 the 表特指。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The teacher gave us an useful advice on how to improve our listening skills.",
        "right": "The teacher gave us some useful advice on how to improve our listening skills.",
        "explain": "advice 是不可数名词，不能加不定冠词；而且 useful 的首音素是辅音 j，即使可数也应用 a，故改为 some。"
      },
      {
        "type": "fill",
        "q": "在空格处填入恰当的冠词：Of all the subjects I have learned, economics is ____ most difficult one.",
        "answer": "the",
        "explain": "形容词最高级前通常加 the 表示最……的；most difficult 后接 one，需要定冠词点明比较范围。"
      },
      {
        "type": "reorder",
        "words": [
          "an",
          "hour",
          "spent",
          "she",
          "writing",
          "essay",
          "the",
          "about",
          "education"
        ],
        "answer": "She spent an hour writing the essay about education.",
        "cn": "她花了一个小时写那篇关于教育的文章。",
        "explain": "spend 后接时间段用 an hour，hour 首音素为元音故用 an；the essay 指后文限定的那一篇，故用定冠词。"
      },
      {
        "type": "analysis",
        "sentence": "In a small town near the coast, a retired teacher who had spent the greater part of his life in the classroom was giving the children a lesson that they would never forget.",
        "question": "句中 the greater part of his life 与 a lesson 的冠词使用分别依据什么？",
        "options": [
          "两者都是特指，因此都可以换用 the",
          "the greater part 表示由 of 短语限定的确定部分，a lesson 用于首次引入新信息",
          "a lesson 在此表示类别，相当于 any lesson",
          "the 与 a 在此可以互换，语法上没有任何差别"
        ],
        "answer": 1,
        "explain": "the greater part of his life 的范围由 of 短语限定，双方都能确定，故用 the；a lesson 是首次提及的新信息，虽带定语从句仍用不定冠词引入。",
        "translation": "在海岸边的一个小镇上，一位在教室里度过了大半生的退休教师正在给孩子们上一堂他们永远不会忘记的课。"
      }
    ]
  },
  {
    "id": "noun-uncountable-quantifier",
    "point": "冠词与名词",
    "sub": "不可数名词的量化与具体化",
    "level": "cet4",
    "freq": 4,
    "rule": "不可数名词没有复数形式，前面不能直接加 a/an 或数词，量化要靠量词短语：a piece of、an item of、a great deal of、a large amount of 等，谓语动词的单复数跟量词走，不跟后面的不可数名词走。有些名词抽象时不可数，一旦具体化就可以数：a great success（一件成功的事）、a pleasant surprise（一件令人惊喜的事）、two coffees（两杯咖啡）。判断方法是问一句能不能加 s 并数出来，能数的用可数用法，不能数的保持原形。口诀：不可数看量词，抽象具体可数化。",
    "tips": [
      "information、advice、equipment、furniture、luggage 没有复数形式，也不能加 a/an。",
      "量化用 a piece of advice、a great deal of information，谓语与量词保持一致。",
      "抽象名词具体化后可数：a success、a pleasure、a shock、three coffees。"
    ],
    "examples": [
      {
        "en": "The equipment in the new laboratory is expensive, so the school has bought only two pieces of it.",
        "cn": "新实验室里的设备很贵，所以学校只买了两件。",
        "note": "equipment 不可数，作主语用单数 is，计量靠 piece。"
      },
      {
        "en": "Learning that she had passed the exam was such a pleasant surprise that she called her parents at once.",
        "cn": "得知自己通过了考试，这意外之喜让她立刻给父母打了电话。",
        "note": "surprise 在此具体化为一件令人惊喜的事，故可用 a。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The professor offered us some practical ____ on how to prepare for the interview, and every ____ of it proved useful.",
        "options": [
          "advices; piece",
          "advice; piece",
          "advice; pieces",
          "advices; pieces"
        ],
        "answer": 1,
        "explain": "advice 是不可数名词，没有复数形式，故第一空用 advice；every 只能修饰单数名词，量词 piece 须保持单数。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The furnitures in the office are new, and the informations about them are on the desk.",
        "right": "The furniture in the office is new, and the information about it is on the desk.",
        "explain": "furniture 与 information 都是不可数名词，不能加 s，作主语时谓语和代词都要用单数，故改为 is 与 it。"
      },
      {
        "type": "fill",
        "q": "用括号中所给词的适当形式填空：The teacher gave me several ____ (piece) of advice about writing my thesis.",
        "answer": "pieces",
        "explain": "advice 不可数，计量要借 piece；several 只能修饰可数名词复数，因此 piece 必须变成复数 pieces。"
      },
      {
        "type": "reorder",
        "words": [
          "amount",
          "large",
          "of",
          "a",
          "information",
          "was",
          "collected",
          "the",
          "survey",
          "in"
        ],
        "answer": "A large amount of information was collected in the survey.",
        "cn": "这次调查中收集到了大量信息。",
        "explain": "information 不可数，不能与数词直接连用，须用 a large amount of 量化，谓语与 amount 一致用单数 was。"
      },
      {
        "type": "analysis",
        "sentence": "Although the research team had collected a great deal of information over three years, the equipment used to analyse it was so outdated that the results were not reliable enough for publication.",
        "question": "句中 a great deal of information 与 the equipment 的用法体现了不可数名词的什么规则？",
        "options": [
          "information 与 equipment 都是可数名词，前面加 a 即可",
          "两者均不可数：information 用 a great deal of 量化，equipment 不加 an，谓语用单数 was",
          "a great deal of 只能修饰可数名词，equipment 前省略了 the",
          "information 作主语时谓语应用复数 were，equipment 可以加 s"
        ],
        "answer": 1,
        "explain": "两个名词都不可数：information 只能靠量词短语量化，equipment 不能加不定冠词，作主语时谓语用单数 was；只有可数的 results 才用复数。",
        "translation": "尽管研究团队在三年里收集了大量信息，但用于分析这些信息的设备太过陈旧，结果不足以可靠地发表。"
      }
    ]
  },
  {
    "id": "prep-time-place-in-on-at",
    "point": "介词与搭配",
    "sub": "时间与地点介词 in on at",
    "level": "cet4",
    "freq": 5,
    "rule": "时间上按长短分层：at 用于时刻与瞬间（at seven o'clock、at noon、at Christmas），on 用于具体某一天以及被修饰限定的早中晚（on Monday、on May 1st、on a cold morning），in 用于较长时段（in 2026、in May、in the morning）和表示多久之后。地点上按范围大小分层：at 把地点看成一个点（at the door、at the station），on 指接触的平面或线（on the wall、on the street），in 指立体空间与范围（in the room、in China）。口诀：时间看长短，地点看大小；点用 at，面用 on，体用 in。",
    "tips": [
      "时刻、正午、午夜用 at，具体某天与星期用 on，年、月、季节、世纪用 in。",
      "地点按范围判断：at 是点，on 是面，in 是体，如 at the corner 与 in the corner。",
      "in 加一段时间还可表将来：in two weeks 意为两周之后。"
    ],
    "examples": [
      {
        "en": "The lecture will begin at nine o'clock on Friday morning in the main hall.",
        "cn": "讲座将于周五上午九点在大礼堂开始。",
        "note": "at 表精确时刻，on 用于具体某天的时段，in 指空间范围。"
      },
      {
        "en": "She grew up in a small village and now works at a bank on the main street of the city.",
        "cn": "她在一个小村庄长大，现在在市里主街上的一家银行工作。",
        "note": "村庄与城市是范围用 in，银行与街道是点与面用 at 和 on。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The conference was held ____ the morning of May 5th, and the guests arrived ____ the airport two hours earlier.",
        "options": [
          "in; at",
          "on; at",
          "at; in",
          "on; in"
        ],
        "answer": 1,
        "explain": "morning 被 of May 5th 限定为具体某一天的早上，因此用 on；airport 在行程中被看成一个点，用 at，不用 in。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "My cousin will arrive at Shanghai in next Monday and stay there for two weeks.",
        "right": "My cousin will arrive in Shanghai next Monday and stay there for two weeks.",
        "explain": "上海是范围较大的城市，视为立体范围须用 in；next Monday 本身已是时间状语，前面不能再加介词 in。"
      },
      {
        "type": "fill",
        "q": "在空格处填入恰当的介词：There is a beautiful picture ____ the wall above the sofa.",
        "answer": "on",
        "explain": "画挂在墙上，与墙面是接触的平面关系，故用 on；若说 in the wall 则指嵌进墙体内部，与句意不符。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "meeting",
          "in",
          "is",
          "scheduled",
          "conference",
          "room",
          "at",
          "three",
          "o'clock",
          "the"
        ],
        "answer": "The meeting is scheduled at three o'clock in the conference room.",
        "cn": "会议定于三点在会议室举行。",
        "explain": "at three o'clock 表示精确时刻用 at，in the conference room 表示处在立体空间内用 in，语序上地点后于时间。"
      },
      {
        "type": "analysis",
        "sentence": "On a rainy morning in early April, a group of researchers arrived at the small station on the edge of the town and waited in the crowded hall for the train that would take them to the capital.",
        "question": "句中 on a rainy morning、at the small station、in the crowded hall 三处介词的使用依据分别是什么？",
        "options": [
          "三处都是固定搭配，没有规律可循，只能逐个背",
          "早晨被 rainy 限定为具体的某一个早晨故用 on，车站被视为行程中的一个点故用 at，大厅是立体空间故用 in",
          "早晨用 on 是因为它属于上午，车站用 at 是因为它是建筑物，大厅用 in 是因为它在室内",
          "三处都可以换成 in，句子意思保持不变"
        ],
        "answer": 1,
        "explain": "on 用于被限定为具体的某个早晨，at 把车站看成一个点，in 表示人处于大厅这一立体空间之内，三者正对应具体某天、点、体三条判断标准。",
        "translation": "在四月初一个下着雨的早晨，一群研究人员到达了小镇边上的那个小车站，并在拥挤的候车大厅里等候开往首都的列车。"
      }
    ]
  },
  {
    "id": "prep-verb-adj-collocation",
    "point": "介词与搭配",
    "sub": "动词形容词的介词固定搭配",
    "level": "cet6",
    "freq": 4,
    "rule": "动词和形容词后面的介词由词义关系决定，不能靠语感乱猜，要成组记忆。account for 表示解释原因或占比例，result in 后面接结果、result from 后面接原因，depend on、consist of、cope with 各有固定伙伴。形容词方面：be aware of、be capable of、be superior to、be familiar with（人熟悉某物）与 be familiar to（某物为人熟知）。易混点还有 because of 只能接名词性成分，due to 多作表语或定语，owing to 常放句首。口诀：先定词义关系，再认介词伙伴，方向不能反。",
    "tips": [
      "result in 引出结果，result from 引出原因，方向相反，不能混用。",
      "be superior to、be inferior to、be senior to 中用 to 而不用 than。",
      "be familiar with 的主语是人，be familiar to 的主语是被熟悉的事物。"
    ],
    "examples": [
      {
        "en": "The sharp rise in fuel prices resulted in higher transport costs, which resulted from the global supply shortage.",
        "cn": "燃油价格猛涨导致了运输成本上升，而这一涨价源于全球供应短缺。",
        "note": "result in 后面接结果，result from 后面接原因，方向相反。"
      },
      {
        "en": "Our new manager is quite familiar with the local market, and his name is familiar to almost every client here.",
        "cn": "我们的新经理对本地市场相当熟悉，而他的名字几乎为这里每位客户所熟知。",
        "note": "人熟悉事物用 with，事物为人所知用 to，主语不同搭配不同。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The decline in sales can be partly ____ the poor after-sales service, and it has ____ a serious loss of customers.",
        "options": [
          "attributed to; resulted in",
          "attributed with; resulted from",
          "contributed to; resulted in",
          "attributed to; resulted from"
        ],
        "answer": 0,
        "explain": "attribute A to B 表示把 A 归因于 B，搭配固定用 to；销售下滑带来客户流失，后者是结果，所以第二空用 result in。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The students are quite aware about the importance of time management, but few of them are capable to put it into practice.",
        "right": "The students are quite aware of the importance of time management, but few of them are capable of putting it into practice.",
        "explain": "aware 后固定接 of 而不接 about；capable 后也接 of，且介词后须用动名词，故 to put 改为 of putting。"
      },
      {
        "type": "fill",
        "q": "在空格处填入恰当的介词：Whether we can finish the project on time depends ____ how well the team cooperates.",
        "answer": "on",
        "explain": "depend 表示取决于时与 on 固定连用，后面可接名词或从句，介词不能省略，也不能换成 of。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "increase",
          "in",
          "number",
          "students",
          "resulted",
          "from",
          "of",
          "new",
          "policy",
          "the",
          "the"
        ],
        "answer": "The increase in the number of students resulted from the new policy.",
        "cn": "学生人数的增加是这项新政策带来的结果。",
        "explain": "result from 后面接原因，此处 the new policy 正是原因；increase in the number of students 为固定表达，介词不可替换。"
      },
      {
        "type": "analysis",
        "sentence": "Researchers who are familiar with urban planning argue that the sharp drop in housing prices resulted from a combination of tighter credit rules and a slowdown in migration, rather than from any single policy introduced by the local government.",
        "question": "句中 be familiar with 与 resulted from 的搭配，下列分析哪一项正确？",
        "options": [
          "familiar with 应改为 familiar to，因为主语是研究者",
          "resulted from 引出的是房价下跌的原因，若换成 resulted in 逻辑方向就会颠倒",
          "resulted from 后面的介词可以省略，直接接名词短语",
          "familiar with 可以换成 aware 而介词保持不变"
        ],
        "answer": 1,
        "explain": "familiar with 的主语是人，表示研究者熟悉城市规划，搭配正确；resulted from 引出原因，即信贷收紧与迁移放缓，改成 result in 就把因果关系倒过来了。",
        "translation": "熟悉城市规划的研究者认为，房价大幅下跌是信贷规则收紧与人口迁移放缓共同作用的结果，而不是地方政府出台的某一项政策造成的。"
      }
    ]
  },
  {
    "id": "parallel-structure-agreement",
    "point": "平行结构与强调句",
    "sub": "并列结构的一致性与对称",
    "level": "cet4",
    "freq": 4,
    "rule": "并列结构要求 and、or、but、not only...but also、either...or、as well as 连接的成分在语法性质上一致：名词对名词、动名词对动名词、不定式对不定式、从句对从句。判断时先把连词两侧的成分分别拆出来，比较形式是否相同，再看它们是否共同充当同一个介词宾语、同一个表语或同一个谓语。常见错误是把不定式与动名词混用、把名词短语与完整句子混用。比较结构同样讲究对称：the more...the more 前后要对应，as...as 中间要用同类成分，than 前后也要同形。口诀：连词两侧，形式对等。",
    "tips": [
      "not only...but also 连接的两部分必须同形，都是名词、动名词或从句。",
      "介词后面并列的成分要同为名词或动名词，不能一半接句子。",
      "the more...the more 与 as...as 中间要求结构对称，位置也要对应。"
    ],
    "examples": [
      {
        "en": "The job requires patience, accuracy and the ability to work under pressure.",
        "cn": "这份工作需要耐心、准确以及在压力下工作的能力。",
        "note": "三项并列同为名词性成分，形式保持一致。"
      },
      {
        "en": "She is not only responsible for training new staff but also in charge of the annual budget.",
        "cn": "她不仅负责培训新员工，还主管年度预算。",
        "note": "not only 与 but also 后面都接形容词短语，结构对称。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "The new employee is good at ____ problems and ____ with customers, which makes her popular in the team.",
        "options": [
          "solving; communicating",
          "solve; communicate",
          "solving; communicate",
          "solve; communicating"
        ],
        "answer": 0,
        "explain": "and 连接的两个成分共同作介词 at 的宾语，必须同为动名词，所以两空都用 -ing 形式才能保持平行。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "The manager asked us to check the figures carefully, to correct the mistakes and sending the report before Friday.",
        "right": "The manager asked us to check the figures carefully, to correct the mistakes and to send the report before Friday.",
        "explain": "and 连接的三件事与前面的 to check 并列，须同为不定式；sending 与不定式形式不一致，应改为 to send。"
      },
      {
        "type": "fill",
        "q": "用括号中所给词的适当形式填空：Reading widely and ____ (write) regularly are the two habits that help her improve her English.",
        "answer": "writing",
        "explain": "and 连接的两个成分共同作句子主语，与 reading 并列须同为动名词，故用 writing，谓语也随之用复数 are。"
      },
      {
        "type": "reorder",
        "words": [
          "the",
          "plan",
          "is",
          "practical",
          "and",
          "affordable",
          "for",
          "students",
          "most"
        ],
        "answer": "The plan is practical and affordable for most students.",
        "cn": "这个方案对大多数学生来说既实用又负担得起。",
        "explain": "and 连接 practical 与 affordable 两个形容词共同作表语，形式对称；for most students 说明适用对象，置于句末。"
      },
      {
        "type": "analysis",
        "sentence": "What the committee finally recommended was not only to reduce the number of meetings but also to publish the minutes online so that every member could follow the discussion without attending in person.",
        "question": "句中 not only...but also 连接的是什么成分，这种并列对形式提出了什么要求？",
        "options": [
          "连接的是两个分句，所以 but also 后面必须是完整句子",
          "连接的是两个不定式短语 to reduce 与 to publish，共同作表语，形式必须一致",
          "连接的是名词短语与从句，属于合法搭配",
          "连接的是谓语动词，所以两部分都用动词原形"
        ],
        "answer": 1,
        "explain": "was 后面由 not only...but also 连接两个不定式短语共同作表语；正因形式必须平行，第二项才重复 to 而不能直接用 publish。",
        "translation": "委员会最终建议的不仅是减少会议次数，还要把会议记录公布到网上，以便每位成员无需亲自到场也能了解讨论过程。"
      }
    ]
  },
  {
    "id": "cleft-it-that-not-until",
    "point": "平行结构与强调句",
    "sub": "强调句判断与 not until 式",
    "level": "cet6",
    "freq": 4,
    "rule": "强调句的基本形式是 It is/was 加被强调成分加 that/who，再加句子其余部分。判断方法：去掉 It is/was 和 that/who，若剩下的词仍能组成一个完整句子，就是强调句，否则多半是主语从句或定语从句。被强调的成分可以是主语、宾语或状语，但不能是谓语。强调人时 that 可以换成 who；强调时间或地点只能用 that，不能换成 when 或 where。not...until 的强调式为 It is/was not until 加被强调部分加 that，后面用陈述语序，句子不倒装。口诀：去掉 It is 与 that，句子还完整就是强调句。",
    "tips": [
      "去掉 It is/was 与 that/who 后若剩一个完整句子，即为强调句。",
      "强调时间或地点只能用 that，不能换成 when 或 where。",
      "not until 的强调式是 It was not until...that，后面不倒装。"
    ],
    "examples": [
      {
        "en": "It was in the library that she first met her future business partner.",
        "cn": "她第一次遇见未来的商业伙伴就是在图书馆。",
        "note": "被强调的是地点状语，只能用 that，不能用 where。"
      },
      {
        "en": "It was not until the meeting ended that he told me the truth.",
        "cn": "直到会议结束，他才把真相告诉我。",
        "note": "not until 的强调式用 that 引导，后面保持陈述语序。"
      }
    ],
    "items": [
      {
        "type": "choice",
        "q": "It was not until midnight ____ the firefighters brought the fire under control.",
        "options": [
          "when",
          "that",
          "which",
          "then"
        ],
        "answer": 1,
        "explain": "这是 not...until 的强调句，结构为 It was not until...that...，只能用 that 引导，且 that 后面是陈述语序。"
      },
      {
        "type": "error",
        "q": "找出下面句子的错误并改正",
        "wrong": "It was in the small café where we discussed the plan for the new project.",
        "right": "It was in the small café that we discussed the plan for the new project.",
        "explain": "去掉 It was 与引导词后剩下的 we discussed the plan in the small café 是完整句，说明是强调句；强调地点须用 that 而非 where。"
      },
      {
        "type": "fill",
        "q": "在空格处填入恰当的动词：It ____ my parents who encouraged me to study abroad.",
        "answer": "was",
        "explain": "句子叙述的是过去的事，强调句的 be 动词要与后面从句的时态一致，故用 was；被强调成分指人，用 who 引导。"
      },
      {
        "type": "reorder",
        "words": [
          "was",
          "it",
          "in",
          "beijing",
          "he",
          "that",
          "met",
          "his",
          "wife",
          "first"
        ],
        "answer": "It was in Beijing that he first met his wife.",
        "cn": "他第一次遇见妻子就是在北京。",
        "explain": "强调地点状语 in Beijing 时用 It was...that...，不能用 where；被强调部分提到 that 之前，其余部分保持陈述语序。"
      },
      {
        "type": "analysis",
        "sentence": "It was not until the researchers had compared the data from more than twenty hospitals that they realized how widely the treatment had been applied in rural areas.",
        "question": "下列关于该句结构的说法，哪一项正确？",
        "options": [
          "这是 not until 引导的时间状语从句，主句需要倒装",
          "这是 It was not until...that... 强调句，that 后面是陈述语序的完整主句",
          "这是定语从句，that 指代前面的名词 hospitals",
          "这是主语从句，It 是形式主语，真正主语是 that 从句"
        ],
        "answer": 1,
        "explain": "去掉 It was 与 that 后，剩余部分仍能组成完整句子，说明是强调句；that 后面是陈述语序的主句，既不倒装，也不是定语从句或主语从句。",
        "translation": "直到研究人员比较了二十多家医院的数据之后，他们才意识到这种疗法在农村地区的应用范围有多么广。"
      }
    ]
  }
];
