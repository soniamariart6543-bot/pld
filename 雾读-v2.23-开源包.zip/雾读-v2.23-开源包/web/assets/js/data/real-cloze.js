window.REAL_CLOZE = [
  {
    "id": "cet4-2016-06-a",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "iPad 与医学院教学",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "fast",
      "policy",
      "launch",
      "dependent",
      "reliable",
      "growing",
      "designed",
      "give",
      "treatments",
      "prospect"
    ],
    "passage": "But the (1)______ popularity of electronic medical records has forced hospital-based doctors to become (2)______ on computers throughout the day, and desktops - which keep doctors from bedsides - are (3)______ giving way to wireless devices. As clerical loads increased, \"something had to (4)______, and that was always face time with patients,\" says Dr. Bhakti Patel, a former chief resident in the University of Chicago's internal-medicine program. In fall 2010, she helped (5)______ a pilot project in Chicago to see if the iPad could improve working conditions and patient care.",
    "blanks": [
      {
        "n": 1,
        "answer": "growing",
        "explain": "growing 作定语修饰 popularity，意为日益增长的人气。"
      },
      {
        "n": 2,
        "answer": "dependent",
        "explain": "形容词作表语，固定搭配 become dependent on 意为依赖。"
      },
      {
        "n": 3,
        "answer": "fast",
        "explain": "fast 作副词修饰 giving way，are giving way to 表正让位于。"
      },
      {
        "n": 4,
        "answer": "give",
        "explain": "情态动词 had to 后接动词原形；something had to give 意为必须让步。"
      },
      {
        "n": 5,
        "answer": "launch",
        "explain": "help 后接动词原形，help launch a project 意为协助启动项目。"
      }
    ],
    "points": [
      "固定搭配 growing popularity",
      "副词修饰 giving way",
      "help + 动词原形"
    ]
  },
  {
    "id": "cet4-2016-06-b",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "运动与学业成绩",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "review",
      "attendance",
      "tend",
      "consequently",
      "performance",
      "feasible",
      "particularly",
      "survive",
      "depressing",
      "current"
    ],
    "passage": "Physical activity does the body good, and there's growing evidence that it helps the brain too. Researchers in the Netherlands report that children who get more exercise, whether at school or on their own, (1)______ to have higher GPAs and better scores on standardized tests. In a (2)______ of 14 studies that looked at physical activity and academic (3)______, investigators found that the more children moved, the better their grades were in school, (4)______ in the basic subjects of math, English and reading. The data will certainly fuel the ongoing debate over whether physical education classes should be cut as schools struggle to (5)______ on smaller budgets.",
    "blanks": [
      {
        "n": 1,
        "answer": "tend",
        "explain": "tend to do 为固定搭配，主语复数故用原形，表往往如此。"
      },
      {
        "n": 2,
        "answer": "review",
        "explain": "a review of 14 studies 意为对研究的综述，名词作介词宾语。"
      },
      {
        "n": 3,
        "answer": "performance",
        "explain": "academic performance 为固定搭配，指学业成绩，作 of 宾语。"
      },
      {
        "n": 4,
        "answer": "particularly",
        "explain": "副词 particularly 用于强调，后接 in 引出所举学科。"
      },
      {
        "n": 5,
        "answer": "survive",
        "explain": "survive on 意为靠……维持；struggle to 后接动词原形。"
      }
    ],
    "points": [
      "固定搭配 tend to do",
      "固定搭配 academic performance",
      "固定搭配 survive on"
    ]
  },
  {
    "id": "cet4-2016-12-a",
    "level": "cet4",
    "year": "2016年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "大脑是否存在性别差异",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "categorizing",
      "figure",
      "challenges",
      "tastes",
      "searched",
      "briefly",
      "similarities",
      "abnormal",
      "slightly",
      "applied"
    ],
    "passage": "A new study (1)______ that belief, questioning whether brains really can be distinguished by gender. In the study, Tel Aviv University researchers (2)______ for sex differences throughout the entire human brain. And what did they find? Not much. Rather than offer evidence for (3)______ brains as \"male\" or \"female,\" research shows that brains fall into a wide range, with most people falling right in the middle. Daphna Joel, who led the study, said her research found that while there are some gender-based (4)______, many different types of brain can't always be distinguished by gender. While the \"average\" male and \"average\" female brains were (5)______ different, you couldn't tell it by looking at individual brain scans.",
    "blanks": [
      {
        "n": 1,
        "answer": "challenges",
        "explain": "主语单数，谓语用 challenges，与 belief 搭配表质疑。"
      },
      {
        "n": 2,
        "answer": "searched",
        "explain": "固定搭配 search for 意为搜寻，此处用过去式 searched。"
      },
      {
        "n": 3,
        "answer": "categorizing",
        "explain": "介词 for 后接动名词，固定搭配 categorize as 意为归类为。"
      },
      {
        "n": 4,
        "answer": "similarities",
        "explain": "形容词 gender-based 修饰名词复数，指与性别相关的相似处。"
      },
      {
        "n": 5,
        "answer": "slightly",
        "explain": "副词 slightly 修饰 different，表示略有差异。"
      }
    ],
    "points": [
      "第三人称单数谓语",
      "介词 for 后接动名词",
      "副词修饰形容词"
    ]
  },
  {
    "id": "cet4-2016-12-b",
    "level": "cet4",
    "year": "2016年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "海洋升温研究",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "levels",
      "explore",
      "indifferent",
      "absorb",
      "voyage",
      "picture",
      "excursion",
      "contribute",
      "mixed",
      "floor"
    ],
    "passage": "The ocean is heating up. That's the conclusion of a new study that finds that Earth's oceans now (1)______ heat at twice the rate they did 18 years ago. Around half of ocean heat intake since 1865 has taken place since 1997, researchers report online in Nature Climate Change. Warming waters are known to (2)______ to coral bleaching(珊瑚白化) and they take up more space than cooler waters, raising sea (3)______. While the top of the ocean is well studied, its depths are more difficult to (4)______. The researchers gathered 150 years of ocean temperature data in order to get a better (5)______ of heat absorption from surface to seabed.",
    "blanks": [
      {
        "n": 1,
        "answer": "absorb",
        "explain": "主语 oceans 为复数，谓语用原形 absorb；now 提示一般现在时。"
      },
      {
        "n": 2,
        "answer": "contribute",
        "explain": "固定搭配 contribute to 意为导致，be known to 后接原形。"
      },
      {
        "n": 3,
        "answer": "levels",
        "explain": "sea levels 为固定搭配，作 raising 的宾语，指海平面上升。"
      },
      {
        "n": 4,
        "answer": "explore",
        "explain": "be difficult to do 结构中用原形 explore，指深海难以探测。"
      },
      {
        "n": 5,
        "answer": "picture",
        "explain": "固定搭配 get a picture of 意为了解，此处名词作宾语。"
      }
    ],
    "points": [
      "主语复数用动词原形",
      "固定搭配 sea levels",
      "固定搭配 get a picture of"
    ]
  },
  {
    "id": "cet4-2017-06-a",
    "level": "cet4",
    "year": "2017年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "中国早期啤酒酿造",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "suggest",
      "resources",
      "surprising",
      "consuming",
      "test",
      "direct",
      "reached",
      "remains",
      "inform",
      "exclusively"
    ],
    "passage": "Now, researchers have found a (1)______ ingredient in residue(残留物) from 5000-year-old beer brewing equipment. While digging two pits at a site in the central plains of China, scientists discovered fragments from pots and vessels. The different shapes of the containers (2)______ they were used to brew, filter, and store beer. They may be ancient \"beer-making tools,\" and the earliest (3)______ evidence of beer brewing in China, the researchers reported in the Proceedings of the National Academy of Sciences. To (4)______ that theory, the team examined the yellowish, dried (5)______ inside the vessels.",
    "blanks": [
      {
        "n": 1,
        "answer": "surprising",
        "explain": "形容词作定语修饰 ingredient，与下文 unexpected 呼应。"
      },
      {
        "n": 2,
        "answer": "suggest",
        "explain": "主语为复数，谓语用原形 suggest，后接从句表表明。"
      },
      {
        "n": 3,
        "answer": "direct",
        "explain": "形容词 direct 修饰 evidence，与 earliest 并列指直接证据。"
      },
      {
        "n": 4,
        "answer": "test",
        "explain": "不定式表目的；固定搭配 test a theory 意为验证理论。"
      },
      {
        "n": 5,
        "answer": "remains",
        "explain": "名词 remains 意为残渣，作 examined 的宾语，被形容词修饰。"
      }
    ],
    "points": [
      "形容词作定语",
      "形容词作定语",
      "名词作宾语"
    ]
  },
  {
    "id": "cet4-2017-06-b",
    "level": "cet4",
    "year": "2017年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "运动、咖啡因与视觉",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "solution",
      "slowing",
      "phenomenon",
      "commit",
      "cycling",
      "sensitive",
      "involved",
      "cautiously",
      "effectively",
      "preventing"
    ],
    "passage": "Muscle performance can also be affected by a (1)______ called \"central fatigue,\" in which an imbalance in the body's chemical messengers prevents the central nervous system from directing muscle movements (2)______. It was not known, however, whether central fatigue might also affect motor systems not directly (3)______ in the exercise itself, such as those that move the eyes. To find out, researchers gave 11 volunteer cyclists a carbohydrate(碳水化合物的) (4)______ either with a moderate dose of caffeine(咖啡因), which is known to stimulate the central nervous system, or as a placebo(安慰剂) without, during 3 hours of (5)______.",
    "blanks": [
      {
        "n": 1,
        "answer": "phenomenon",
        "explain": "名词 phenomenon 作介词宾语，后置的过去分词短语修饰它。"
      },
      {
        "n": 2,
        "answer": "effectively",
        "explain": "副词 effectively 修饰动名词 directing，表有效地指挥。"
      },
      {
        "n": 3,
        "answer": "involved",
        "explain": "固定搭配 be involved in 意为参与，过去分词短语作定语。"
      },
      {
        "n": 4,
        "answer": "solution",
        "explain": "名词 solution 意为溶液，作 gave 的直接宾语。"
      },
      {
        "n": 5,
        "answer": "cycling",
        "explain": "介词 of 后接动名词 cycling，指三小时骑行，呼应 cyclists。"
      }
    ],
    "points": [
      "名词作介词宾语",
      "固定搭配 be involved in",
      "介词 of 后接动名词"
    ]
  },
  {
    "id": "cet4-2017-12-a",
    "level": "cet4",
    "year": "2017年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "老鼠与鸽子的医疗本领",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "indicate",
      "suspicious",
      "associated",
      "peak",
      "preventing",
      "visual",
      "slight",
      "treated",
      "sensitive",
      "prohibiting"
    ],
    "passage": "Recently it was shown that they could be trained to be as accurate as humans at detecting breast cancer in images. Rats are often (1)______ with spreading disease rather than (2)______ it, but this long-tailed animal is highly (3)______. Inside a rat's nose are up to 1,000 different types of olfactory receptors(嗅觉感受器), whereas humans only have 100 to 200 types. This gives rats the ability to detect (4)______ smells. As a result, some rats are being put to work to detect TB(肺结核). When the rats detect the smell, they stop and rub their legs to (5)______ a sample is infected.",
    "blanks": [
      {
        "n": 1,
        "answer": "associated",
        "explain": "固定搭配 be associated with 意为与……相关联，often 提示现在时。"
      },
      {
        "n": 2,
        "answer": "preventing",
        "explain": "rather than 后接动名词，与前面的 spreading 并列。"
      },
      {
        "n": 3,
        "answer": "sensitive",
        "explain": "形容词作表语，highly sensitive 指高度灵敏，下文数据支撑。"
      },
      {
        "n": 4,
        "answer": "slight",
        "explain": "形容词 slight 修饰 smells，与 detect 搭配指察觉微弱气味。"
      },
      {
        "n": 5,
        "answer": "indicate",
        "explain": "不定式表目的，indicate 后接从句，指示意样本已被感染。"
      }
    ],
    "points": [
      "固定搭配 be associated with",
      "副词 highly 修饰形容词",
      "不定式表目的"
    ]
  },
  {
    "id": "cet4-2017-12-b",
    "level": "cet4",
    "year": "2017年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "互联网的早期发展",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "limited",
      "reservations",
      "advantage",
      "equipped",
      "commercial",
      "remained",
      "maintained",
      "incoming",
      "local",
      "innovation"
    ],
    "passage": "The Internet was developed during the 1970s by the Department of Defense. In the case of an attack, military advisers suggested the (1)______ of being able to operate one computer from another terminal. In the early days, the Internet was used mainly by scientists to communicate with other scientists. The Internet (2)______ under government control until 1984. One early problem faced by Internet users was speed. Phone lines could only transmit information at a (3)______ rate. The development of fiber-optic(光纤) cables allowed for billions of bits of information to be received every minute. Companies like Intel developed faster microprocessors, so personal computers could process the (4)______ signals at a more rapid rate. In the early 1990s, the World Wide Web was developed, in large part, for (5)______ purposes.",
    "blanks": [
      {
        "n": 1,
        "answer": "advantage",
        "explain": "名词 advantage 作 suggested 的宾语，后接 of 短语。"
      },
      {
        "n": 2,
        "answer": "remained",
        "explain": "remain 后接介词短语表持续处于，此处用过去式。"
      },
      {
        "n": 3,
        "answer": "limited",
        "explain": "形容词 limited 修饰 rate，指有限的速率，与下文光纤对比。"
      },
      {
        "n": 4,
        "answer": "incoming",
        "explain": "形容词 incoming 修饰 signals，指输入的、外来的信号。"
      },
      {
        "n": 5,
        "answer": "commercial",
        "explain": "形容词 commercial 修饰 purposes，for 短语表商业目的。"
      }
    ],
    "points": [
      "名词作宾语",
      "形容词作定语",
      "for...purposes 表目的"
    ]
  },
  {
    "id": "cet4-2018-06-a",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "洛杉矶的空气污染治理",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "innovation",
      "sum",
      "pollutants",
      "assisted",
      "restricted",
      "domestic",
      "detail",
      "inhabitants",
      "consequence",
      "frequently"
    ],
    "passage": "Since the 1940s, southern California has had a reputation for smog. Things are not as bad as they once were but, according to the American Lung Association, Los Angeles is still the worst city in the United States for levels of (1)______. Gazing down on the city from the Getty Center, an art museum in the Santa Monica Mountains, one would find the view of the Pacific Ocean blurred by the haze(霾). Nor is the state's bad air (2)______ to its south. Fresno, in the central valley, comes top of the list in America for year-round pollution. Residents' hearts and lungs are affected as a (3)______. All of which, combined with California's reputation as the home of technological (4)______, makes the place ideal for developing and testing systems designed to monitor pollution in (5)______.",
    "blanks": [
      {
        "n": 1,
        "answer": "pollutants",
        "explain": "名词复数作 of 的宾语，levels of pollutants 指污染物浓度。"
      },
      {
        "n": 2,
        "answer": "restricted",
        "explain": "固定搭配 be restricted to 意为限于，Nor 引起倒装。"
      },
      {
        "n": 3,
        "answer": "consequence",
        "explain": "固定短语 as a consequence 意为结果，名词作介词宾语。"
      },
      {
        "n": 4,
        "answer": "innovation",
        "explain": "名词 innovation 作 of 的宾语，指技术创新的发源地。"
      },
      {
        "n": 5,
        "answer": "detail",
        "explain": "固定短语 in detail 意为详细地，作状语修饰 monitor。"
      }
    ],
    "points": [
      "名词作介词宾语",
      "固定短语 as a consequence",
      "固定短语 in detail"
    ]
  },
  {
    "id": "cet4-2018-06-b",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "曼彻斯特太阳能大楼",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "collection",
      "cheaper",
      "undertaken",
      "range",
      "scale",
      "discovered",
      "constructed",
      "consulted",
      "cleaner",
      "height"
    ],
    "passage": "An office tower on Miller Street in Manchester is completely covered in solar panels. They are used to create some of the energy used by the insurance company inside. When the tower was first (1)______ in 1962, it was covered with thin square stones. These small square stones became a problem for the building and continued to fall off the face for 40 years until a major renovation was (2)______. During this renovation the building's owners, CIS, (3)______ the solar panel company, Solarcentury. They agreed to cover the entire building in solar panels. In 2004, the completed CIS tower became Europe's largest (4)______ of vertical solar panels. A vertical solar project on such a large (5)______ has never been repeated since.",
    "blanks": [
      {
        "n": 1,
        "answer": "constructed",
        "explain": "被动语态 was constructed，in 1962 提示用过去分词。"
      },
      {
        "n": 2,
        "answer": "undertaken",
        "explain": "被动语态 was undertaken，与 renovation 搭配指实施翻修。"
      },
      {
        "n": 3,
        "answer": "consulted",
        "explain": "consult 意为咨询，此处用过去式，指业主咨询太阳能公司。"
      },
      {
        "n": 4,
        "answer": "collection",
        "explain": "名词作表语，largest collection of 指规模最大的集合。"
      },
      {
        "n": 5,
        "answer": "scale",
        "explain": "固定搭配 on a large scale 意为大规模地，作状语。"
      }
    ],
    "points": [
      "被动语态 be + 过去分词",
      "一般过去时",
      "固定搭配 on a large scale"
    ]
  },
  {
    "id": "cet4-2018-12-a",
    "level": "cet4",
    "year": "2018年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "空气污染的经济代价",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "constant",
      "ability",
      "damage",
      "relates",
      "associated",
      "undermine",
      "sources",
      "described",
      "innovated",
      "regularly"
    ],
    "passage": "Millions die early from air pollution each year. Air pollution costs the global economy more than $5 trillion annually in welfare costs, with the most serious (1)______ occurring in the developing world. The figures include a number of costs (2)______ with air pollution. Lost income alone amounts to $225 billion a year. The report includes both indoor and outdoor air pollution. Indoor pollution, which includes (3)______ like home heating and cooking, has remained (4)______ over the past several decades despite advances in the area. Levels of outdoor pollution have grown rapidly along with rapid growth in industry and transportation. Director of Institute for Health Metrics and Evaluation Chris Murray (5)______ it as an \"urgent call to action.\"",
    "blanks": [
      {
        "n": 1,
        "answer": "damage",
        "explain": "名词 damage 作 with 的宾语，此处为不可数，指严重损害。"
      },
      {
        "n": 2,
        "answer": "associated",
        "explain": "固定搭配 be associated with 意为与……相关，分词短语作定语。"
      },
      {
        "n": 3,
        "answer": "sources",
        "explain": "名词复数作宾语，like 引出例证，指室内污染的来源。"
      },
      {
        "n": 4,
        "answer": "constant",
        "explain": "形容词作 remain 的表语，意思为保持不变。"
      },
      {
        "n": 5,
        "answer": "described",
        "explain": "describe...as... 意为把……描述为，此处用过去式。"
      }
    ],
    "points": [
      "名词作介词宾语",
      "名词复数作宾语",
      "固定搭配 describe as"
    ]
  },
  {
    "id": "cet4-2018-12-b",
    "level": "cet4",
    "year": "2018年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201606-201812%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "职场难言之信的传递方式",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "surveyed",
      "escape",
      "warning",
      "silent",
      "convenience",
      "reward",
      "effectively",
      "prompt",
      "particularly",
      "intimate"
    ],
    "passage": "Have you ever used email to apologize to a colleague? Delivered a (1)______ to a subordinate(下属) with a voice-mail message? Flown by plane across the country just to deliver important news in person? The various communication options at our fingertips today can be good for (2)______ and productivity - and at the same time very troublesome. With so many ways to communicate, how should a manager choose the one that's best - (3)______ when the message to be delivered is bad or unwelcome news for the recipient? We've (4)______ business communication consultants and etiquette(礼仪) experts to come up with the following guidelines for (5)______ using the alternative ways of delivering difficult messages.",
    "blanks": [
      {
        "n": 1,
        "answer": "warning",
        "explain": "名词 warning 作 delivered 的宾语，与上文并列句一致。"
      },
      {
        "n": 2,
        "answer": "convenience",
        "explain": "名词作介词宾语，与 productivity 并列，指沟通更便利。"
      },
      {
        "n": 3,
        "answer": "particularly",
        "explain": "副词用于强调，particularly when 意为尤其是当……时。"
      },
      {
        "n": 4,
        "answer": "surveyed",
        "explain": "现在完成时 have 加过去分词 surveyed，意为咨询了专家。"
      },
      {
        "n": 5,
        "answer": "effectively",
        "explain": "副词 effectively 修饰动名词 using，指有效地使用。"
      }
    ],
    "points": [
      "名词作宾语",
      "副词表强调",
      "副词修饰动名词"
    ]
  },
  {
    "id": "cet4-2019-06-a",
    "level": "cet4",
    "year": "2019年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "自动驾驶立法之争",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "dominance",
      "reward",
      "bid",
      "knots",
      "legislation",
      "deputy",
      "migrated",
      "fleets",
      "replace",
      "contrast"
    ],
    "passage": "The center of American automobile innovation has in the past decade moved 2,000 miles away. It has (1)______ from Detroit to Silicon Valley, where self-driving vehicles are coming to life. In a (2)______ to take production back to Detroit, Michigan lawmakers have introduced (3)______ that could make their state the best place in the country, if not the world, to develop self-driving vehicles and put them on the road. \"Michigan's (4)______ in auto research and development is under attack from several states and countries which desire to (5)______ our leadership in transportation.",
    "blanks": [
      {
        "n": 1,
        "answer": "migrated",
        "explain": "空前 has 提示现在完成时，需过去分词；migrate from...to... 指从底特律迁往硅谷。"
      },
      {
        "n": 2,
        "answer": "bid",
        "explain": "in a bid to do sth 是固定搭配，意为「为了做某事」，后接不定式表目的。"
      },
      {
        "n": 3,
        "answer": "legislation",
        "explain": "introduced 需名词作宾语；下文 four bills（四项法案）提示填 legislation 立法。"
      },
      {
        "n": 4,
        "answer": "dominance",
        "explain": "名词所有格后需名词；dominance in 表「在……的主导地位」，与 under attack 呼应。"
      },
      {
        "n": 5,
        "answer": "replace",
        "explain": "desire to do sth 后接动词原形；replace our leadership 意为取代我们的领先地位。"
      }
    ],
    "points": [
      "现在完成时 has + 过去分词",
      "in a bid to 固定搭配",
      "dominance 与介词 in 搭配",
      "desire to do 后接原形"
    ]
  },
  {
    "id": "cet4-2019-12-a",
    "level": "cet4",
    "year": "2019年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "瓶装水的微塑料",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "contains",
      "instant",
      "sealed",
      "adequate",
      "revealing",
      "modified",
      "released",
      "solves",
      "natural",
      "defending"
    ],
    "passage": "It's hot so you grab a bottle of water from a local vendor. It's the safe thing to do, right? The bottle is (1)______, and the label says \"pure water\". But maybe what's inside is not so (2)______. Would you still be drinking it if you knew that more than 90 percent of all bottled water sold around the world (3)______ microplastics? That's the conclusion of a recently (4)______ study, which analysed 259 bottles from 11 brands sold in nine countries, (5)______ an average of 325 plastic particles per litre of water.",
    "blanks": [
      {
        "n": 1,
        "answer": "sealed",
        "explain": "be sealed 表示「密封的」，过去分词作表语，与后文 pure water 的语境一致。"
      },
      {
        "n": 2,
        "answer": "natural",
        "explain": "not so natural 指不那么天然，so 后需形容词，与下文塑料微粒形成对照。"
      },
      {
        "n": 3,
        "answer": "contains",
        "explain": "主语指瓶装水整体，谓语用第三人称单数 contains，意为「含有」微塑料。"
      },
      {
        "n": 4,
        "answer": "released",
        "explain": "过去分词作前置定语修饰 study，recently released study 即最近发布的研究。"
      },
      {
        "n": 5,
        "answer": "revealing",
        "explain": "现在分词短语作状语，补充说明分析结果；reveal 意为揭示、显示。"
      }
    ],
    "points": [
      "not so + 形容词作表语",
      "第三人称单数谓语 contains",
      "过去分词作前置定语",
      "现在分词短语作结果状语"
    ]
  },
  {
    "id": "cet4-2020-09-a",
    "level": "cet4",
    "year": "2020年9月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "财务压力的三种类型",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "tend",
      "statement",
      "extreme",
      "appearance",
      "avoid",
      "normal",
      "proposition",
      "rebelled",
      "inaction",
      "definitely"
    ],
    "passage": "Money therefore becomes a stressful topic, and so the thought of sitting down and planning is an unattractive (1)______. Those suffering inherited financial anxiety (2)______ to follow one of two patterns. Either they put their head in the sand: they would (3)______ examining their financial statements, budgeting, and discussing financial matters with those closest to them. Alternatively, they would go to the other (4)______, and micro-analyze everything, to the point of complete (5)______. They're convinced that whatever decision they make will be the wrong one.",
    "blanks": [
      {
        "n": 1,
        "answer": "proposition",
        "explain": "an unattractive proposition 指不吸引人的选择，不定冠词 an 后需名词。"
      },
      {
        "n": 2,
        "answer": "tend",
        "explain": "tend to do sth 为固定搭配，主语 Those suffering... 为复数，故用原形 tend。"
      },
      {
        "n": 3,
        "answer": "avoid",
        "explain": "would 后接动词原形；avoid doing sth 表避免做某事，与逃避态度一致。"
      },
      {
        "n": 4,
        "answer": "extreme",
        "explain": "go to the other extreme 为固定表达，意为走向另一个极端，与上文形成对比。"
      },
      {
        "n": 5,
        "answer": "inaction",
        "explain": "介词 of 后需名词；complete inaction 指彻底不作为，与上文过度分析相反。"
      }
    ],
    "points": [
      "tend to do sth 固定搭配",
      "avoid doing sth 搭配",
      "other extreme 固定表达",
      "介词 of 后接名词 inaction"
    ]
  },
  {
    "id": "cet4-2020-12-a",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "信任是组织的基础",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "constantly",
      "stacks",
      "essential",
      "tracked",
      "miserable",
      "credible",
      "watching",
      "gather",
      "suspicion",
      "exploring"
    ],
    "passage": "Trust is fundamental to life. If you can't trust anything, life becomes intolerable. You can't have relationships without trust, let alone good ones. In the workplace, too, trust is (1)______. An organization without trust will be full of fear and (2)______. If you work for a boss who doesn't trust their employees to do things right, you'll have a (3)______ time. They'll be checking up on you all the time, correcting \"mistakes\" and (4)______ reminding you to do this or that. Colleagues who don't trust one another will need to spend more time (5)______ their backs than doing any useful work.",
    "blanks": [
      {
        "n": 1,
        "answer": "essential",
        "explain": "形容词作表语，trust is essential 表信任至关重要，与下文反面论述呼应。"
      },
      {
        "n": 2,
        "answer": "suspicion",
        "explain": "与 fear 并列作 of 的宾语，suspicion 意为怀疑，符合缺乏信任的组织氛围。"
      },
      {
        "n": 3,
        "answer": "miserable",
        "explain": "形容词修饰 time，have a miserable time 意为日子很难熬，与 boss 反复检查呼应。"
      },
      {
        "n": 4,
        "answer": "constantly",
        "explain": "副词修饰 reminding，表示不停地提醒，与 all the time 语义一致。"
      },
      {
        "n": 5,
        "answer": "watching",
        "explain": "spend time doing sth 需动名词；watch one's back 意为提防、留意身后。"
      }
    ],
    "points": [
      "形容词作表语 essential",
      "名词与 fear 并列作宾语",
      "spend time doing 结构",
      "constantly 修饰动词"
    ]
  },
  {
    "id": "cet4-2021-06-a",
    "level": "cet4",
    "year": "2021年6月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "撒哈拉银蚁的耐热",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "species",
      "moderate",
      "crawling",
      "tiny",
      "hunt",
      "adapting",
      "literally",
      "remote",
      "extreme",
      "crowded"
    ],
    "passage": "Most animals seek shade when temperatures in the Sahara Desert soar to 120 degrees Fahrenheit. But for the Saharan silver ant, (1)______ from their underground nests into the sun's brutal rays to (2)______ for food, this is the perfect time to seek lunch. In 2015 these ants were joined in the desert by scientists from two Belgian universities, who spent a month in the (3)______ heat tracking the ants and digging out their nests. The goal was simple, to discover how the (4)______ adapted to the kind of heat that can (5)______ melt the bottom of shoes.",
    "blanks": [
      {
        "n": 1,
        "answer": "crawling",
        "explain": "现在分词作后置修饰，from...into... 提示蚂蚁是爬出巢穴，符合动作方式。"
      },
      {
        "n": 2,
        "answer": "hunt",
        "explain": "不定式表目的，hunt for food 意为觅食，与后文 seek lunch 呼应。"
      },
      {
        "n": 3,
        "answer": "extreme",
        "explain": "形容词作定语修饰 heat；上文 120 degrees Fahrenheit 提示是极端高温。"
      },
      {
        "n": 4,
        "answer": "species",
        "explain": "定冠词 the 后接单数名词表类别，species 指前文提到的撒哈拉银蚁这一物种。"
      },
      {
        "n": 5,
        "answer": "literally",
        "explain": "副词修饰 melt，literally 表确实、真能，强调高温足以融化鞋底。"
      }
    ],
    "points": [
      "现在分词作后置修饰",
      "不定式表目的 hunt for food",
      "literally 修饰 melt",
      "the + 单数名词表类别"
    ]
  },
  {
    "id": "cet4-2021-12-a",
    "level": "cet4",
    "year": "2021年12月",
    "source": "https://archive.org/download/cet46collect/%E5%9B%9B%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "噩梦与清醒梦",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "aware",
      "amount",
      "fear",
      "mechanical",
      "limited",
      "depart",
      "avoid",
      "timidity",
      "answer",
      "drastically"
    ],
    "passage": "The sheets are damp with sweat. You're cold, but your heart is racing as if a killer just chased you down a dark street. It was just a nightmare, you tell yourself, there's nothing to be afraid of. But you're still filled with (1)______. Given how unsettling and haunting nightmares can be, is there a way for dreamers to (2)______, or even turn off, these bad dreams as they happen? Research is (3)______, but some studies suggest that people who can master lucid dreaming - that is, the ability to be (4)______ that a nightmare is happening and possibly even control it without waking up - may hold the (5)______.",
    "blanks": [
      {
        "n": 1,
        "answer": "fear",
        "explain": "be filled with 后接名词，fear 与上文 nightmare、afraid 形成语义呼应。"
      },
      {
        "n": 2,
        "answer": "avoid",
        "explain": "a way for sb to do sth 需动词原形；avoid 与 turn off 并列，指避开噩梦。"
      },
      {
        "n": 3,
        "answer": "limited",
        "explain": "形容词作表语，Research is limited 表研究有限，与 but 后的让步转折呼应。"
      },
      {
        "n": 4,
        "answer": "aware",
        "explain": "be aware that... 表意识到……，与清醒梦知道自己在做梦的定义一致。"
      },
      {
        "n": 5,
        "answer": "answer",
        "explain": "hold the answer 为固定表达，意为掌握答案，与句首疑问句呼应。"
      }
    ],
    "points": [
      "be filled with + 名词",
      "a way to do sth 结构",
      "be aware that 从句",
      "固定表达 hold the answer"
    ]
  },
  {
    "id": "cet6-2019-06-a",
    "level": "cet6",
    "year": "2019年6月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "意大利面与健康",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "adverse",
      "championed",
      "clinical",
      "contribute",
      "contrary",
      "lumped",
      "magnified",
      "minimum",
      "ration",
      "weighing"
    ],
    "passage": "\"The study found that pasta didn't (1)______ to weight gain or increase in body fat,\" said lead author Dr John Sievenpiper. \"In (2)______ the evidence, we can now say with some confidence that pasta does not have an (3)______ effect on body weight outcomes when it is consumed as part of a healthy dietary pattern.\" In fact, analysis actually showed a small weight loss. So (4)______ to concerns, perhaps pasta can be part of a healthy diet. Those involved in the (5)______ trials on average ate 3.3 servings of pasta a week instead of other carbohydrates, one serving equaling around half a cup. They lost around half a kilogram over an average follow-up of 12 weeks.",
    "blanks": [
      {
        "n": 1,
        "answer": "contribute",
        "explain": "contribute to 为固定搭配，意为「导致、促成」，此处与 didn't 构成否定。"
      },
      {
        "n": 2,
        "answer": "weighing",
        "explain": "介词 in 后需动名词作宾语，weigh the evidence 意为「权衡证据」。"
      },
      {
        "n": 3,
        "answer": "adverse",
        "explain": "空处修饰名词 effect，需形容词；adverse effect 意为「不利影响」。"
      },
      {
        "n": 4,
        "answer": "contrary",
        "explain": "contrary to 为固定搭配，意为「与……相反」，与前文担忧形成对照。"
      },
      {
        "n": 5,
        "answer": "clinical",
        "explain": "clinical trials 意为「临床试验」，是医学语境下的固定搭配。"
      }
    ],
    "points": [
      "contribute to 意为导致",
      "介词 in 后接动名词",
      "contrary to 意为与…相反",
      "clinical trials 临床试验"
    ]
  },
  {
    "id": "cet6-2019-06-b",
    "level": "cet6",
    "year": "2019年6月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "飞行汽车的未来",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "autonomous",
      "detached",
      "dual",
      "glamour",
      "imminent",
      "odds",
      "pouring",
      "prototypes",
      "repressing",
      "ultimate"
    ],
    "passage": "The dream of personalised flight is still vivid in the minds of many inventors, some developing cycle-powered craft, others (1)______ money into jetpacks(喷气飞行背包). However, the flying car has always remained the (2)______ symbol of personal transport freedom. Several companies around the world have produced (3)______ that can drive on roads and fly. Airbus has a futuristic modular(组件式的) concept involving a passenger capsule that can be (4)______ from the road-going chassis(底盘) and picked up by a helicopter-type machine. But all these concepts are massively expensive, require safety certification standards for road and air, need (5)______ controls, involve complex folding wings and propellers, and have to be flown from air-strips. So they are likely to remain rich people's playthings rather than practical transport solutions for the masses.",
    "blanks": [
      {
        "n": 1,
        "answer": "pouring",
        "explain": "pour money into 为固定搭配，意为「向……大量投入资金」。"
      },
      {
        "n": 2,
        "answer": "ultimate",
        "explain": "空处修饰 symbol，需形容词；ultimate 意为「终极的」。"
      },
      {
        "n": 3,
        "answer": "prototypes",
        "explain": "及物动词 produced 后接名词宾语，从句说明是样机样车。"
      },
      {
        "n": 4,
        "answer": "detached",
        "explain": "be 后接过去分词构成被动，detached from 指可与底盘分离。"
      },
      {
        "n": 5,
        "answer": "dual",
        "explain": "空处修饰 controls，需形容词；dual 指双重操纵装置。"
      }
    ],
    "points": [
      "pour money into 固定搭配",
      "形容词修饰 symbol",
      "produced 后接名词宾语",
      "detached from 构成被动"
    ]
  },
  {
    "id": "cet6-2019-06-c",
    "level": "cet6",
    "year": "2019年6月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "低温下的钢材脆性",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "abruptly",
      "additives",
      "approach",
      "besieged",
      "comparable",
      "components",
      "hollow",
      "relevant",
      "strived",
      "violent"
    ],
    "passage": "So scientists have (1)______ to find a solution by mixing it with expensive metals such as nickel. Yuuji Kimura and colleagues in Japan tried a more physical (2)______. Rather than adding other metals, they developed a complex mechanical process involving repeated heating and very severe mechanical deformation, known as tempforming. The resulting steel appears to achieve a combination of strength and toughness that is (3)______ to that of modern steels that are very rich in alloy content and, therefore, very expensive. Kimura's team intends to use its tempformed steel to make ultra-high strength parts, such as bolts. They hope to reduce both the number of (4)______ needed in a construction job and their weight - by replacing solid supports with (5)______ tubes, for example.",
    "blanks": [
      {
        "n": 1,
        "answer": "strived",
        "explain": "空前 have 提示现在完成时，需过去分词；strive to do 意为「努力做」。"
      },
      {
        "n": 2,
        "answer": "approach",
        "explain": "空前有形容词 physical 修饰，空处需名词，与上句 solution 呼应。"
      },
      {
        "n": 3,
        "answer": "comparable",
        "explain": "后接 to that of，构成 be comparable to 固定搭配，意为「与……相当」。"
      },
      {
        "n": 4,
        "answer": "components",
        "explain": "the number of 后需可数名词复数，与 supports、tubes 同为构件。"
      },
      {
        "n": 5,
        "answer": "hollow",
        "explain": "修饰 tubes 需形容词，与前半句 solid 形成对照，意为「空心的」。"
      }
    ],
    "points": [
      "have + 过去分词完成时",
      "形容词 physical 修饰名词",
      "comparable to 意为相当",
      "the number of 后接复数"
    ]
  },
  {
    "id": "cet6-2019-12-a",
    "level": "cet6",
    "year": "2019年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "饮食与大脑健康",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "assessed",
      "assigned",
      "deficits",
      "designated",
      "detrimental",
      "digestion",
      "excelling",
      "indulging",
      "loopholes",
      "rapidly"
    ],
    "passage": "Perhaps worse, the (1)______ effects of an unhealthy diet and insufficient exercise are not limited to your body. Recent research has also shown that (2)______ in a high-fat and high-sugar diet may have negative effects on your brain, causing learning and memory (3)______. Studies have found obesity is associated with impairments in cognitive functioning, as (4)______ by a range of learning and memory tests, such as the ability to remember a list of words presented some minutes or hours earlier. There is also a growing body of evidence that diet induced cognitive impairments can emerge (5)______ - within weeks or even days.",
    "blanks": [
      {
        "n": 1,
        "answer": "detrimental",
        "explain": "修饰 effects 需形容词；unhealthy diet 提示为负面作用。"
      },
      {
        "n": 2,
        "answer": "indulging",
        "explain": "从句主语位置需动名词；indulge in 意为「沉溺于」。"
      },
      {
        "n": 3,
        "answer": "deficits",
        "explain": "causing 后需名词宾语，deficits 指记忆与学习缺陷。"
      },
      {
        "n": 4,
        "answer": "assessed",
        "explain": "as + 过去分词表「如……所评估的」，与主语构成被动。"
      },
      {
        "n": 5,
        "answer": "rapidly",
        "explain": "修饰动词 emerge 需副词，后文 within weeks 提示速度快。"
      }
    ],
    "points": [
      "形容词修饰 effects",
      "indulge in 意为沉溺于",
      "causing 后接名词宾语",
      "as + 过去分词表被动"
    ]
  },
  {
    "id": "cet6-2019-12-b",
    "level": "cet6",
    "year": "2019年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "城市空气污染治理",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "alternate",
      "crown",
      "determine",
      "generated",
      "locating",
      "merged",
      "miniatures",
      "particles",
      "switching",
      "synonymous"
    ],
    "passage": "What is more important, the decisions that we make now about the design of our cities will (1)______ the everyday lives and health of the coming generations. So what would a smoke-free, or at least low-pollution, city be like? Traffic has become (2)______ with air pollution, and many countries intend to ban the sale of new petrol and diesel cars in the next two decades. But simply (3)______ to electric cars will not mean pollution-free cities. The level of emissions they cause will depend on how the electricity to run them is (4)______, while brakes, tyres and roads all create tiny airborne (5)______ as they wear out.",
    "blanks": [
      {
        "n": 1,
        "answer": "determine",
        "explain": "will 后需动词原形，主语 decisions 与宾语构成决定关系。"
      },
      {
        "n": 2,
        "answer": "synonymous",
        "explain": "后接 with，构成 be synonymous with 固定搭配，意为「密不可分」。"
      },
      {
        "n": 3,
        "answer": "switching",
        "explain": "副词 simply 后需动名词作主语；switch to 意为「转向」。"
      },
      {
        "n": 4,
        "answer": "generated",
        "explain": "与 is 构成被动语态，需过去分词，指电如何被「产生」。"
      },
      {
        "n": 5,
        "answer": "particles",
        "explain": "形容词修饰语后需名词，磨损产生的是空气中的微粒。"
      }
    ],
    "points": [
      "will 后接动词原形",
      "synonymous with 固定搭配",
      "副词后接动名词作主语",
      "be + 过去分词构成被动"
    ]
  },
  {
    "id": "cet6-2019-12-c",
    "level": "cet6",
    "year": "2019年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "人与物的拟人化",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "alleviate",
      "apparently",
      "arrogant",
      "circumstances",
      "competitive",
      "conceded",
      "consciousness",
      "excluded",
      "lonely",
      "spectacularly"
    ],
    "passage": "But even without gadgets that understand our spoken commands, research suggests that, as bizarre is it sounds, under certain (1)______ people regularly ascribe human traits to everyday objects. Sometimes we see things as human because we are (2)______. In one experiment, people who reported feeling isolated were more likely than others to attribute (3)______ to various gadgets. In turn, feeling close to objects can (4)______ loneliness. When college students were reminded of a time they had been (5)______ in a social setting, they compensated by exaggerating their number of friends - unless they were first given tasks that caused them to interact with their phone as if it had human qualities.",
    "blanks": [
      {
        "n": 1,
        "answer": "circumstances",
        "explain": "under certain 提示搭配，意为「在特定情况下」。"
      },
      {
        "n": 2,
        "answer": "lonely",
        "explain": "系动词 are 后需形容词作表语，下文 isolated 为同义线索。"
      },
      {
        "n": 3,
        "answer": "consciousness",
        "explain": "attribute 后需名词宾语，此处指把「意识」赋予物件。"
      },
      {
        "n": 4,
        "answer": "alleviate",
        "explain": "can 后需动词原形，宾语 loneliness 提示应表「缓解」。"
      },
      {
        "n": 5,
        "answer": "excluded",
        "explain": "had been 后需过去分词构成被动，in a social setting 提示被排斥。"
      }
    ],
    "points": [
      "under certain 后接名词",
      "系动词后接形容词作表语",
      "attribute 后接名词宾语",
      "can 后接动词原形"
    ]
  },
  {
    "id": "cet6-2020-07-a",
    "level": "cet6",
    "year": "2020年7月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "自然生态危机报告",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "capacity",
      "declaration",
      "deteriorating",
      "grabbed",
      "inventory",
      "junction",
      "monotonous",
      "overwhelming",
      "stagnation",
      "stake"
    ],
    "passage": "The United Nations issued a report last week warning that humans are destroying nature at such a rate that life on Earth is at risk. When the report came out, it naturally (1)______ headlines. But obviously it didn't hijack the news agenda in the manner of a major terrorist attack or (2)______ of war. The report from the Intergovernmental Science-Policy Platform on Biodiversity and Ecosystem Services (IPBES) is clear on what's at (3)______ and what needs to change. IPBES chair Robert Watson says the \"(4)______ evidence\" presents an ominous(凶兆的) picture. \"The health of ecosystems on which we and all other species depend is (5)______ more rapidly than ever,\" Robert Watson said.",
    "blanks": [
      {
        "n": 1,
        "answer": "grabbed",
        "explain": "主语 it 指报告，需过去式谓语；grab headlines 意为「占据头条」。"
      },
      {
        "n": 2,
        "answer": "declaration",
        "explain": "与 attack 并列作介词宾语，需名词；declaration of war 指宣战。"
      },
      {
        "n": 3,
        "answer": "stake",
        "explain": "at stake 为固定搭配，意为「处于紧要关头」。"
      },
      {
        "n": 4,
        "answer": "overwhelming",
        "explain": "引号内修饰 evidence，需形容词，下文提示证据分量极重。"
      },
      {
        "n": 5,
        "answer": "deteriorating",
        "explain": "is 与 more rapidly 提示进行时，需现在分词，意为「恶化」。"
      }
    ],
    "points": [
      "grab headlines 占据头条",
      "at stake 意为处于紧要关头",
      "形容词修饰 evidence",
      "be + 现在分词进行时"
    ]
  },
  {
    "id": "cet6-2020-09-a",
    "level": "cet6",
    "year": "2020年9月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA201906-202112%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "找借口与自我设限",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "contrary",
      "heaving",
      "labeled",
      "legacies",
      "momentum",
      "obsessed",
      "potential",
      "reciprocal",
      "ruin",
      "viciously"
    ],
    "passage": "In fact, the people most likely to become chronic excuse makers are those (1)______ with success. Such people are so afraid of being (2)______ a failure at anything that they constantly develop one handicap or another in order to explain away failure. Though self-handicapping can be an effective way of coping with performance anxiety now and then, in the end, researchers say, it will lead to (3)______. In the long run, excuse makers fail to live up to their true (4)______ and lose the status they care so much about. And despite their protests to the (5)______ they have only themselves to blame.",
    "blanks": [
      {
        "n": 1,
        "answer": "obsessed",
        "explain": "those 后需后置定语，be obsessed with 意为「痴迷于」。"
      },
      {
        "n": 2,
        "answer": "labeled",
        "explain": "being 后需过去分词构成被动，label sb. a failure 指贴失败标签。"
      },
      {
        "n": 3,
        "answer": "ruin",
        "explain": "lead to 后需名词宾语，与下文 fail 呼应，指走向毁灭。"
      },
      {
        "n": 4,
        "answer": "potential",
        "explain": "live up to 意为「达到」，与 true 搭配的名词指「潜力」。"
      },
      {
        "n": 5,
        "answer": "contrary",
        "explain": "to the contrary 为固定搭配，此处 contrary 作名词。"
      }
    ],
    "points": [
      "obsessed with 固定搭配",
      "being 后接过去分词被动",
      "lead to 后接名词宾语",
      "live up to 固定搭配"
    ]
  },
  {
    "id": "cet6-2022-06-a",
    "level": "cet6",
    "year": "2022年6月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "巴斯温泉与城市兴起",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "natural",
      "designates",
      "constructed",
      "remedy",
      "principally",
      "extract",
      "previous",
      "incorporates",
      "aesthetically",
      "offspring"
    ],
    "passage": "The city of Bath was founded by the Romans almost two thousand years ago. It has been famous for its (1)______ pleasing architecture and healing thermal springs ever since. There are three hot springs in Bath; one is the King's Spring upon which the Roman Baths and a temple were (2)______. The other two are the Cross Spring and the Hetling Spring close to each other in Hot Bath Street. Although Bath is (3)______ known as a Roman and Georgian city, many people came in the intervening centuries to make use of the (4)______ waters. While the Georgians made 'taking the waters' or bathing particularly fashionable, it was (5)______ generations who paved the way, creating greater interest in Bath and its springs.",
    "blanks": [
      {
        "n": 1,
        "answer": "aesthetically",
        "explain": "副词修饰形容词，aesthetically pleasing 表审美悦目。"
      },
      {
        "n": 2,
        "answer": "constructed",
        "explain": "被动语态 were constructed，指神庙与浴场建在泉上。"
      },
      {
        "n": 3,
        "answer": "principally",
        "explain": "副词修饰 known，principally 意为「主要地」。"
      },
      {
        "n": 4,
        "answer": "natural",
        "explain": "形容词修饰 waters，指天然泉水，呼应上文 healing thermal springs。"
      },
      {
        "n": 5,
        "answer": "previous",
        "explain": "形容词修饰 generations，指前几代人更早为巴斯铺路。"
      }
    ],
    "points": [
      "副词修饰形容词 aesthetically pleasing",
      "被动语态 were constructed",
      "previous generations 的时间对比"
    ]
  },
  {
    "id": "cet6-2022-06-b",
    "level": "cet6",
    "year": "2022年6月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "善意思维与身心健康",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "cognitive",
      "adversely",
      "prone",
      "insulation",
      "boost",
      "amiably",
      "recurrent",
      "signify",
      "compassion",
      "connected"
    ],
    "passage": "Having the ability to switch off the body's natural threat response can (1)______ a person's immune system. This, in turn, gives them a greater likelihood of recovering quickly from illness. These findings help us to further understand some of our clinical trials research findings, where we show that individuals with (2)______ depression benefit particularly from a self-awareness-based (3)______ therapy. They essentially learn to become more sympathetic to themselves. The sense is that for people (4)______ to depression, meeting their negative thoughts and feelings with (5)______ is a radically different way; that these thoughts are not facts. It introduces a different way of being and knowing that is quite transformative for many people.",
    "blanks": [
      {
        "n": 1,
        "answer": "boost",
        "explain": "can 后接动词原形，boost 与 immune system 搭配。"
      },
      {
        "n": 2,
        "answer": "recurrent",
        "explain": "形容词修饰 depression，指反复发作的抑郁。"
      },
      {
        "n": 3,
        "answer": "cognitive",
        "explain": "形容词修饰 therapy，cognitive therapy 为认知疗法术语。"
      },
      {
        "n": 4,
        "answer": "prone",
        "explain": "be prone to 固定搭配，意为易患……的。"
      },
      {
        "n": 5,
        "answer": "compassion",
        "explain": "介词 with 后接名词，与上文 sympathetic 呼应。"
      }
    ],
    "points": [
      "情态动词后接动词原形",
      "be prone to 固定搭配",
      "形容词修饰名词"
    ]
  },
  {
    "id": "cet6-2022-09-a",
    "level": "cet6",
    "year": "2022年9月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "旅鸽的灭绝",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "vulnerable",
      "tracts",
      "delicacy",
      "expired",
      "estimates",
      "robust",
      "hatched",
      "unprecedented",
      "edible",
      "refuge"
    ],
    "passage": "The now extinct passenger pigeon has the dubious honor of being the last species anyone ever expected to disappear. At one point, there were more passenger pigeons than any other species of bird. Rough (1)______ of their population went as high as five billion and they accounted for around 40 percent of the total indigenous bird population of North America in the early 19th century. Despite their huge population, passenger pigeons were (2)______ to human intrusion into their nesting territory. Their nests were shabby things and two weeks after the eggs (3)______, the parent pigeons would abandon their offspring, leaving them to take care of themselves. People discovered that these baby pigeons were really tasty, and the adult birds were also quite (4)______. First the Native Americans and then the transplanted Europeans came to consider the birds a great (5)______.",
    "blanks": [
      {
        "n": 1,
        "answer": "estimates",
        "explain": "Rough 后接复数名词，下文数据为线索。"
      },
      {
        "n": 2,
        "answer": "vulnerable",
        "explain": "be vulnerable to 固定搭配，指易受侵入伤害。"
      },
      {
        "n": 3,
        "answer": "hatched",
        "explain": "after 从句中 eggs 与 hatch 为主动关系。"
      },
      {
        "n": 4,
        "answer": "edible",
        "explain": "形容词作表语，与 tasty 并列，指可食用。"
      },
      {
        "n": 5,
        "answer": "delicacy",
        "explain": "名词作宾补，a great delicacy 指难得美味。"
      }
    ],
    "points": [
      "be vulnerable to 固定搭配",
      "时间状语从句的主谓关系",
      "名词作宾语补足语"
    ]
  },
  {
    "id": "cet6-2022-12-a",
    "level": "cet6",
    "year": "2022年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "两次惊魂遭遇",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "apparent",
      "froze",
      "network",
      "dedication",
      "struck",
      "barely",
      "overriding",
      "terrifying",
      "access",
      "indignation"
    ],
    "passage": "A few months later, crisis (1)______ again. While my husband was locking his bike to drop off our 3-year-old daughter for her preschool-aged day camp, a different woman approached. Swiftly and for no (2)______ reason, she bent down, picked up our daughter, and began to carry her down the street. It was so fast and confusing that my daughter (3)______ cried. My husband, in a burst of speed, chased the woman and reclaimed our daughter. The woman, clearly confused, retreated into the public library. A (4)______ of homeless people who generally know the other homeless in the area said they did not recognize the woman. The woman was so clearly unwell that when she was taken into custody she was incoherent. Heartbreakingly, she called our daughter by the name of someone else's child. Each part of the episode was as haunting as it was (5)______.",
    "blanks": [
      {
        "n": 1,
        "answer": "struck",
        "explain": "主语 crisis 与 strike 为主动，表危机袭来。"
      },
      {
        "n": 2,
        "answer": "apparent",
        "explain": "for no apparent reason 固定搭配，指无明显理由。"
      },
      {
        "n": 3,
        "answer": "barely",
        "explain": "副词修饰 cried，barely 表几乎没哭出声。"
      },
      {
        "n": 4,
        "answer": "network",
        "explain": "a network of 后接 people，名词作主语中心词。"
      },
      {
        "n": 5,
        "answer": "terrifying",
        "explain": "as...as 比较中需形容词，与 haunting 并列。"
      }
    ],
    "points": [
      "副词修饰动词",
      "for no apparent reason 固定搭配",
      "as...as 同级比较需形容词"
    ]
  },
  {
    "id": "cet6-2022-12-b",
    "level": "cet6",
    "year": "2022年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "企业全球竞争优势",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "competitive",
      "fiscal",
      "revenues",
      "appropriate",
      "aesthetic",
      "safeguarding",
      "ship",
      "clusters",
      "reproduced",
      "strategic"
    ],
    "passage": "Apple is an outstanding case of a company whose unique capabilities give it a worldwide (1)______ advantage, particularly with respect to its ability to build platforms from a product base that integrates functional and (2)______ design. Apple has been able to leverage and exploit its California-based design and marketing advantages successfully throughout the world. IKEA is another such case. The do-it-yourself furniture and houseware company first developed a compelling set of capabilities to design, manufacture and (3)______ furniture at low cost and sell it in a novel way in Sweden. Later, IKEA successfully (4)______ this formula in many other countries. By contrast, Telefonica, a Spanish telecommunications company that is now the world's fifth largest telecom by (5)______, first developed its special advantage abroad.",
    "blanks": [
      {
        "n": 1,
        "answer": "competitive",
        "explain": "形容词修饰 advantage，competitive advantage 为术语。"
      },
      {
        "n": 2,
        "answer": "aesthetic",
        "explain": "形容词与 functional 并列修饰 design。"
      },
      {
        "n": 3,
        "answer": "ship",
        "explain": "并列不定式中 ship 作动词，意为运送。"
      },
      {
        "n": 4,
        "answer": "reproduced",
        "explain": "副词后接谓语，reproduced this formula 指复制模式。"
      },
      {
        "n": 5,
        "answer": "revenues",
        "explain": "介词 by 后接名词，表按收入计算的排名。"
      }
    ],
    "points": [
      "competitive advantage 商业术语",
      "并列不定式需动词原形",
      "介词 by 后接名词表计量"
    ]
  },
  {
    "id": "cet6-2022-12-c",
    "level": "cet6",
    "year": "2022年12月",
    "source": "https://archive.org/download/cet46collect/%E5%85%AD%E7%BA%A7%E9%80%89%E8%AF%8D%E5%A1%AB%E7%A9%BA202206-%E4%BB%8A%20%E5%8F%AF%E6%89%93%E5%8D%B0.pdf",
    "verified": true,
    "type": "选词填空",
    "title": "美国高校减少用煤",
    "prompt": "从下面 10 个词中选 5 个填入空格（每词限用一次）。",
    "bank": [
      "released",
      "consumption",
      "replacement",
      "void",
      "abandoned",
      "negligent",
      "surplus",
      "contrive",
      "access",
      "duplications"
    ],
    "passage": "American colleges and universities are using 64 percent less coal than they did a decade ago, burning 700,000 tons last year, down from 2 million tons in 2008, the U.S. Energy Information Administration (EIA) said in a report (1)______ yesterday. All 57 schools that were burning coal in 2008 are using less now, and 20 have (2)______ coal completely, EIA found. Most universities have turned to natural gas as a (3)______, with state funding backing the fuel switch. While academic institutions use less than 0.1 percent of U.S. coal burned for power, campus coal use has a history dating back to the 1800s when (4)______ to power was scarce. Many universities still operate their own power plants. The Public Utility Regulatory Policies Act of 1978 encouraged more electricity generation by allowing institutions to sell (5)______ power to utilities.",
    "blanks": [
      {
        "n": 1,
        "answer": "released",
        "explain": "过去分词作后置定语，与 report 为被动关系。"
      },
      {
        "n": 2,
        "answer": "abandoned",
        "explain": "现在完成时 have 后接过去分词，指彻底弃用。"
      },
      {
        "n": 3,
        "answer": "replacement",
        "explain": "介词 as 后接名词，指天然气作为替代品。"
      },
      {
        "n": 4,
        "answer": "access",
        "explain": "access to 固定搭配，名词作从句主语。"
      },
      {
        "n": 5,
        "answer": "surplus",
        "explain": "形容词修饰 power，指多余电力可供出售。"
      }
    ],
    "points": [
      "过去分词作后置定语",
      "现在完成时 have + 过去分词",
      "access to 固定搭配"
    ]
  }
];
