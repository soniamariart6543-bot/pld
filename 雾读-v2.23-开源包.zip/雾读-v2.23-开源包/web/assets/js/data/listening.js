window.LISTENING_BANK = [
  {
    id: "cet4-2021-06-news-1",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "短篇新闻",
    title: "爱画画的男孩被餐厅请去装修",
    script: [
      { speaker: "N", text: "And finally in tonight's news, a nine-year-old boy named Joe told not to draw in class wins a job decorating a restaurant with his drawings rather than shutting down the habit of drawing in his school's workbook." },
      { speaker: "N", text: "Joe's parents decided to encourage his creativity by sending their son to an after-school art class. His teacher recognized Joe's talent and posted all his work online, which led to something pretty wonderful." },
      { speaker: "N", text: "A restaurant named Number 4 in Newcastle contacted Joe's teachers to ask if the nine-year-old could come and decorate the dining room with his drawings. Every day after school, Joe's dad drives him to the restaurant, so he can put his ideas straight on the wall." },
      { speaker: "N", text: "Once he's all done, the work will remain there permanently. Joe's dad says Joe is a really talented little boy. He's excellent at school. He's great at football, but drawing is definitely what he is most passionate about." }
    ],
    questions: [
      { q: "What did Joe's parents decide to do?", options: ["Enrol him in a Newcastle football club.", "Send him to an after-school art class.", "Forbid him to draw in his workbook.", "Help him post his drawings online."], answer: 1, explain: "原文说 Joe's parents decided to encourage his creativity by sending their son to an after-school art class，与 B 项 send him to an after-school art class 完全对应。" },
      { q: "What did the restaurant, Number 4, do?", options: ["Contacted Joe to decorate its dining-room.", "Hired Joe to paint all the walls of its buildings.", "Renovated its kitchen and all the dining-rooms.", "Asked Joe for permission to use his online drawings."], answer: 0, explain: "原文 A restaurant named Number 4 in Newcastle contacted Joe's teachers to ask if the nine-year-old could come and decorate the dining room，即联系 Joe 去装饰餐厅。" }
    ],
    keyWords: [
      { w: "decorate", cn: "装饰；装修" },
      { w: "creativity", cn: "创造力" },
      { w: "talent", cn: "天赋；才能" },
      { w: "workbook", cn: "练习册" },
      { w: "passionate", cn: "热爱的；充满热情的" },
      { w: "permanently", cn: "永久地" },
      { w: "art class", cn: "美术课；美术班" }
    ]
  },
  {
    id: "cet4-2021-06-news-2",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "短篇新闻",
    title: "女子悬赏五千英镑寻回爱犬",
    script: [
      { speaker: "N", text: "Christine Marshall, a 34-year-old mum of one, posted a tearful video on social media Wednesday, begging for the safe return of her beloved pet dog." },
      { speaker: "N", text: "After combing through the security video outside a shop, Christine has now posted an image of a man suspected of stealing the dog. The image appears to show a man carrying the dog in his arms." },
      { speaker: "N", text: "Christine also believes the video obtained from the shop shows the dog being stolen by a man before driving off in a car, which had been waiting nearby." },
      { speaker: "N", text: "The family is now offering a 5,000 pound reward for the safe return of the dog after launching a social media campaign to find the thief. The dog is six and a half years old and was last seen wearing a red collar." },
      { speaker: "N", text: "Christine said, 'We will pay that to anyone who brings him home, as long as they are not responsible for his disappearance.'" }
    ],
    questions: [
      { q: "What is Christine Marshall trying to do?", options: ["Get her pet dog back.", "Beg for help from the police.", "Identify the suspect on the security video.", "Post pictures of her pet dog on social media."], answer: 0, explain: "原文 posted a tearful video... begging for the safe return of her beloved pet dog，说明她的目的是把宠物狗找回来。" },
      { q: "What does the news report say about Christine Marshall's family?", options: ["It is suffering a great deal from the incident.", "It is helping the police with the investigation.", "It is bringing the case to the local district court.", "It is offering a big reward to anyone who helps."], answer: 3, explain: "原文 The family is now offering a 5,000 pound reward for the safe return of the dog，即家庭出重金悬赏。" }
    ],
    keyWords: [
      { w: "tearful", cn: "流泪的；含泪的" },
      { w: "beloved", cn: "心爱的" },
      { w: "suspected", cn: "被怀疑的" },
      { w: "reward", cn: "赏金；报酬" },
      { w: "campaign", cn: "活动；运动" },
      { w: "collar", cn: "项圈" },
      { w: "disappearance", cn: "失踪；消失" }
    ]
  },
  {
    id: "cet4-2021-06-news-3",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "短篇新闻",
    title: "伦敦随意付费的早餐咖啡店",
    script: [
      { speaker: "N", text: "London's eggs and bread cafe offers boiled eggs, toast, jam, and bacon, as well as tea, coffee, and orange juice. But at the end of the meal, customers don't have to worry about the bill." },
      { speaker: "N", text: "Hungry customers can pay whatever amount they can afford to eat at the cafe or nothing at all. Owner Guy Wilson says his cafe aims to build community rather than profits. He wants to provide a bridge for people to connect in an area that has been divided by class and wealth, by providing affordable breakfast." },
      { speaker: "N", text: "The cafe is open in the mornings every day of the year, and has two members of staff or supervisors on shift every day. The cafe doesn't use volunteers, but pays its staff to ensure consistency in its service. It doesn't take donations and doesn't want to be seen as a charity." },
      { speaker: "N", text: "Mr. Wilson says when people start to know other people around them, they realize they're not that different and whatever their financial background or their educational background, most people will have something in common with each other. He says it's important that his cafe can offer his customers security and permanence." }
    ],
    questions: [
      { q: "What does Guy Wilson say his cafe aims to do?", options: ["Provide free meals to the local poor.", "Help people connect with each other.", "Help eliminate class difference in his area.", "Provide customers with first-class service."], answer: 1, explain: "原文 his cafe aims to build community rather than profits，以及 provide a bridge for people to connect，对应 B 项。" },
      { q: "What does the news report say about eggs and bread cafe?", options: ["It does not supervise its employees.", "It donates regularly to a local charity.", "It does not use volunteers.", "It is open round the clock."], answer: 2, explain: "原文 The cafe doesn't use volunteers, but pays its staff，直接对应 C 项。" },
      { q: "What happens when people start to know each other according to Guy Wilson?", options: ["They will realise the importance of communication.", "They will come to the cafe even more frequently.", "They will care less about their own background.", "They will find they have something in common."], answer: 3, explain: "原文 most people will have something in common with each other，对应 D 项。" }
    ],
    keyWords: [
      { w: "affordable", cn: "负担得起的" },
      { w: "community", cn: "社区；共同体" },
      { w: "volunteers", cn: "志愿者" },
      { w: "consistency", cn: "一致性；稳定性" },
      { w: "charity", cn: "慈善机构" },
      { w: "donations", cn: "捐赠" },
      { w: "in common", cn: "共有；相同之处" }
    ]
  },
  {
    id: "cet4-2021-06-conv-1",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "长对话",
    title: "筹备周六聚会的食物与饮品",
    script: [
      { speaker: "M", text: "So what time do you think we should have the party on Saturday?" },
      { speaker: "W", text: "How about inviting people to come at 6:00 PM, then we'll have the afternoon to prepare food and drink and stuff like that?" },
      { speaker: "M", text: "Yes. I was thinking that around six would be good too. What food should we provide?" },
      { speaker: "W", text: "Well, I had thought about baking a cake and some biscuits, and now I think we should prepare some sandwiches and snacks and some other kinds of food so that people can just help themselves rather than getting everyone to sit down at the table to eat a meal. I think that's a bit too formal. It's better to let people walk around and talk to each other or sit where they like." },
      { speaker: "M", text: "Yes, that sounds good. I'll go to the supermarket to get some drinks. I think I might try that big new supermarket on the other side of town, see what they have. I've not been there before. I think we should get some beer and wine and some fruit juice and other soft drinks. What do you think?" },
      { speaker: "W", text: "Sounds great. I think those drinks will be enough. And I heard that the new supermarket offers some big discounts to attract customers, so going there should be a great idea. What should we do about music?" },
      { speaker: "M", text: "Maybe we should also ask Paul to bring his computer and speakers so that we can play some music. He has a great collection of different stuff." },
      { speaker: "W", text: "Yes. All right." }
    ],
    questions: [
      { q: "What are the speakers mainly talking about?", options: ["A surprise party for Paul's birthday.", "Travel plans for the coming weekend.", "Preparations for Saturday's get-together.", "The new market on the other side of town."], answer: 2, explain: "对话通篇在商量周六聚会的到场时间、食物与饮料，即 C 项「周六聚会的准备工作」。" },
      { q: "Why does the woman say it is a good idea to serve foods that guests can help themselves to?", options: ["It makes the hostess's job a whole lot easier.", "It enables guests to walk around and chat freely.", "It saves considerable time and labor.", "It requires fewer tables and chairs."], answer: 1, explain: "原文 It's better to let people walk around and talk to each other or sit where they like，对应 B 项。" },
      { q: "What does the woman say about the new supermarket?", options: ["It offers some big discounts.", "It is quite close to her house.", "It is more spacious and less crowded.", "It sells local wines and soft drinks."], answer: 0, explain: "原文 the new supermarket offers some big discounts to attract customers，直接对应 A 项。" }
    ],
    keyWords: [
      { w: "supermarket", cn: "超市" },
      { w: "discounts", cn: "折扣" },
      { w: "sandwiches", cn: "三明治" },
      { w: "snacks", cn: "点心；零食" },
      { w: "speakers", cn: "音箱；扬声器" },
      { w: "formal", cn: "正式的" },
      { w: "soft drinks", cn: "软饮料；不含酒精的饮料" }
    ]
  },
  {
    id: "cet4-2021-06-conv-2",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "长对话",
    title: "买车计划与二手车行朋友",
    script: [
      { speaker: "W", text: "I'm thinking of buying a car. I wouldn't need to use it every day, but I think it would be very convenient to have one for the weekends." },
      { speaker: "M", text: "That's exciting. Would this be your first car?" },
      { speaker: "W", text: "Nope." },
      { speaker: "M", text: "I actually owned a car for a little while when I lived in Miami. You see, in America, many cities don't have good public transport. So most people need their own car to get around." },
      { speaker: "W", text: "I see." },
      { speaker: "M", text: "So have you got your mind set on a specific model?" },
      { speaker: "W", text: "No, not really. I've heard that German cars are very reliable, but I haven't decided on a specific model yet. I'd also like it to be small so that it's easy to drive in the city." },
      { speaker: "M", text: "I have a friend who sells second-hand cars. In fact, I think his family owns the business. He's a really nice guy and he knows a lot about cars. I could give you his phone number if you want, and you could call him and ask him questions." },
      { speaker: "W", text: "Hmm. That's nice of you, but I don't want to feel obliged to buy one of his cars." },
      { speaker: "M", text: "Oh no. He's not like that. He's a good friend of mine and he would never try to pressure you." },
      { speaker: "W", text: "Well, if you trust him, then I guess it should be okay. To be honest, I could use some help in deciding what type of vehicle would best suit my needs. Speaking to an expert would be a good idea." },
      { speaker: "M", text: "Exactly. You have nothing to worry about. He's a lovely guy and he'll be happy to help." }
    ],
    questions: [
      { q: "What does the woman say about German cars?", options: ["They are reliable.", "They are compact.", "They are spacious.", "They are easy to drive."], answer: 0, explain: "原文 I've heard that German cars are very reliable，女士认为德国车可靠，对应 A 项。" },
      { q: "What does the man recommend the woman do?", options: ["Buy a second-hand car.", "Trust her own judgment.", "Seek advice from his friend.", "Look around before deciding."], answer: 2, explain: "原文 I have a friend who sells second-hand cars... I could give you his phone number if you want，男士建议找他的朋友咨询，对应 C 项。" },
      { q: "What do we learn about the man's friend from the conversation?", options: ["He sells new cars.", "He can be trusted.", "He is starting a business.", "He is a successful car dealer."], answer: 1, explain: "原文 He's a good friend of mine and he would never try to pressure you，女士最后说 if you trust him，可见此人可信，对应 B 项。" }
    ],
    keyWords: [
      { w: "convenient", cn: "方便的" },
      { w: "model", cn: "型号" },
      { w: "reliable", cn: "可靠的" },
      { w: "second-hand", cn: "二手的" },
      { w: "obliged", cn: "有义务的；不得不的" },
      { w: "pressure", cn: "施压" },
      { w: "expert", cn: "专家" }
    ]
  },
  {
    id: "cet4-2021-06-passage-1",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "听力篇章",
    title: "北美的野猪为何是入侵物种",
    script: [
      { speaker: "N", text: "Pigs are not native to North America. They were first introduced to California by Spanish and Russian explorers and settlers many centuries ago. In the early times, pigs were allowed to wander freely in search of food. This practice also allowed many pigs to escape from farms and live in the wild, which became a problem." },
      { speaker: "N", text: "In fact, as one of the most damaging invasive species on the continent, wild pigs caused millions of dollars in crop damage yearly. They also harbored dozens of diseases that threaten both humans and farm animals. Forest patches with wild pigs have been found to have considerably reduced plant and animal diversity." },
      { speaker: "N", text: "In addition to either eating other animals or their food supply, wild pigs damaged native habitats by reaching up crosses and rubbing on trees. Their activities may also create opportunities for invasive plants to colonize these areas. Wild pigs will eat almost anything containing calories. Mice, deer, birds, snakes and frogs are among their victims." },
      { speaker: "N", text: "They can also harm other wild species through indirect competition rather than eating them or shrinking their food supply. On one particular United States island, wild pigs themselves became an attractive food source for a species of mainland eagle. Eagles began breeding on the island and also feeding on a species of native fox. The foxes were almost wiped out completely." }
    ],
    questions: [
      { q: "What do we learn about early pigs in North America?", options: ["Many escaped from farms and became wild.", "They were actually native to North America.", "Many got killed in the wild when searching for food.", "They were hunted by Spanish and Russian explorers."], answer: 0, explain: "原文 This practice also allowed many pigs to escape from farms and live in the wild，对应 A 项。" },
      { q: "Why are wild pigs a threat to humans?", options: ["They often make sudden attacks on people.", "They break up nature's food supply chain.", "They cause much environmental pollution.", "They carry a great many diseases."], answer: 3, explain: "原文 They also harbored dozens of diseases that threaten both humans and farm animals，对应 D 项。" },
      { q: "What does the passage say about the native foxes on a U.S. island?", options: ["They lived peacefully with wild pigs.", "They ran out of food completely.", "They fell victim to eagles.", "They reproduced quickly."], answer: 2, explain: "原文 Eagles began breeding on the island and also feeding on a species of native fox. The foxes were almost wiped out completely，即狐狸成为鹰的猎物，对应 C 项。" }
    ],
    keyWords: [
      { w: "invasive", cn: "入侵性的" },
      { w: "species", cn: "物种" },
      { w: "crop damage", cn: "农作物损害" },
      { w: "diseases", cn: "疾病" },
      { w: "diversity", cn: "多样性" },
      { w: "habitats", cn: "栖息地" },
      { w: "calories", cn: "卡路里；热量" },
      { w: "wiped out", cn: "被消灭；被灭绝" }
    ]
  },
  {
    id: "cet4-2021-06-passage-2",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "听力篇章",
    title: "在太空烘焙咖啡豆的创业计划",
    script: [
      { speaker: "N", text: "A pair of entrepreneurs are planning to build and launch a spacecraft that would carry and roast coffee beans in outer space. The craft will use the heat of re-entry to roast coffee beans, as they float inside it in a pressurized tank. The effect would be to roast the beans all over and produce perfect coffee." },
      { speaker: "N", text: "The businessmen say that on earth, beans can easily break apart and get burned in the roaster. But if gravity is removed, the beans float around in a heated oven, receiving 360 degrees of evenly distributed heat and roasting to near perfection. The spacecraft will reach a height of around 200 kilometers. The beans would then be roasted by the heat generated by the craft's 20-minute re-entry into earth's atmosphere. Temperatures in the pressurized tank will be kept to around 200 degrees Celsius." },
      { speaker: "N", text: "Once back on earth, the planet's first space roasted beans would be used to make coffee that would be sold for the first time in Dubai. This is where the pair's company is based. It is not clear how much they would charge for a cup." },
      { speaker: "N", text: "Surprisingly, the Space Roaster concept, should it go ahead, will not be the first attempt to take coffee into space. In 2015, two Italian companies collaborated on the construction of a similar type of spacecraft, which was the first coffee machine designed for use in space." }
    ],
    questions: [
      { q: "What are a pair of entrepreneurs planning to do?", options: ["Taste coffee while in outer space.", "Roast coffee beans in outer space.", "Develop a new strain of coffee bean.", "Use a pressurised tank to brew coffee."], answer: 1, explain: "原文开头 planning to build and launch a spacecraft that would carry and roast coffee beans in outer space，对应 B 项。" },
      { q: "What does the passage say about coffee beans roasted on earth?", options: ["They can easily get burned.", "They float around in the oven.", "They have to be heated to 360 degrees Celsius.", "They receive evenly distributed heat."], answer: 0, explain: "原文 on earth, beans can easily break apart and get burned in the roaster，对应 A 项。" },
      { q: "What did the two Italian companies do in 2015?", options: ["They charged a high price for their space-roasted coffee beans.", "They set up a branch in Dubai to manufacture coffee roasters.", "They collaborated on building the first space coffee machine.", "They abandoned the attempt to roast coffee beans in space."], answer: 2, explain: "原文 In 2015, two Italian companies collaborated on the construction of a similar type of spacecraft, which was the first coffee machine designed for use in space。" }
    ],
    keyWords: [
      { w: "entrepreneurs", cn: "企业家；创业者" },
      { w: "spacecraft", cn: "宇宙飞船；航天器" },
      { w: "roast", cn: "烘焙；烤" },
      { w: "gravity", cn: "重力" },
      { w: "pressurized tank", cn: "加压罐；压力容器" },
      { w: "atmosphere", cn: "大气层" },
      { w: "Celsius", cn: "摄氏度" },
      { w: "collaborated", cn: "合作" }
    ]
  },
  {
    id: "cet4-2021-06-passage-3",
    level: "cet4",
    year: "2021年6月",
    source: "https://cet4.koolearn.com/20210612/855601.html",
    verified: true,
    type: "听力篇章",
    title: "阿拉斯加小村 Takotna 的水果派",
    script: [
      { speaker: "N", text: "In cold and snowy Alaska, there's a village called Takotna. It has a population of a mere 49 adults. Each March, this tiny village swells up in numbers because it is located in the middle of a race that takes place every year. It is a seven-day race called 'The Iditarod Trail'. And participants stop at Takotna for the obligatory 24-hour rest." },
      { speaker: "N", text: "Lucky for them, Takotna is famous for its delicious fruit pies. Weeks before the competitors arrive, the residents of Takotna start preparing what is without question their biggest event of the year. The whole village chips in to help, including the kids, who end up developing their baking skills at an early age. Exhausted and hungry racers are greeted with delightful pies of all kinds, such as apple, orange, lemon, or banana." },
      { speaker: "N", text: "They consume the pies as a stomach-warming race fuel. The toughness of the race allows for racers to eat pretty much whatever they want. The more calories, the better. Takotna has gained a reputation for its dessert-based hospitality since the 1970s. It started with one person, Jane Newton. Jane moved from Iditarod with her husband in 1972 and opened a restaurant. Her rich and filling fruit pies quickly got the racers' attention, and the village gained some fame as a result. Proud residents then started to refer to Jane as the queen of Takotna." }
    ],
    questions: [
      { q: "Why do a lot of people come to the village of Takotna every March?", options: ["It is the best time for sightseeing.", "A race passes through it annually.", "They come to clean the Iditarod Trail.", "It is when the villagers choose a queen."], answer: 1, explain: "原文 it is located in the middle of a race that takes place every year，说明每年有比赛经过这里，对应 B 项。" },
      { q: "What is the village of Takotna famous for?", options: ["Its children's baking skills.", "Its unique winter scenery.", "Its tasty fruit pies.", "Its great food variety."], answer: 2, explain: "原文 Takotna is famous for its delicious fruit pies，直接对应 C 项。" },
      { q: "Who comes to help with the event of the year?", options: ["The contestants.", "The entire village.", "Jane Newton and her friends.", "People from the state of Idaho."], answer: 1, explain: "原文 The whole village chips in to help, including the kids，即全村人都来帮忙，对应 B 项。" },
      { q: "What does the passage say about Jane Newton?", options: ["She owned a restaurant in Idaho.", "She married her husband in 1972.", "She went to Alaska to compete in a race.", "She helped the village to become famous."], answer: 3, explain: "原文 Her rich and filling fruit pies quickly got the racers' attention, and the village gained some fame as a result，即她让村子出了名，对应 D 项。" }
    ],
    keyWords: [
      { w: "population", cn: "人口" },
      { w: "race", cn: "比赛；赛事" },
      { w: "Iditarod Trail", cn: "艾迪塔罗德小道（阿拉斯加雪橇犬比赛路线）" },
      { w: "residents", cn: "居民" },
      { w: "baking", cn: "烘焙" },
      { w: "reputation", cn: "名声；声誉" },
      { w: "hospitality", cn: "好客；款待" },
      { w: "calories", cn: "卡路里；热量" }
    ]
  },
  {
    id: "cet6-2021-06-conv-1",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348546/",
    verified: true,
    type: "长对话",
    title: "离职面谈该不该说真话",
    script: [
      { speaker: "M", text: "It's my last day at work tomorrow. I'll start my new job in 2 weeks. My human resources manager wants to conduct an interview with me before I leave." },
      { speaker: "W", text: "Ah, an exit interview. Are you looking forward to it?" },
      { speaker: "M", text: "I'm not sure how I feel about it. I resigned because I've been unhappy at that company for a long time, but I'm not sure if I should tell them how I really feel." },
      { speaker: "W", text: "To my way of thinking, there are two main potential benefits that come from unleashing an agitated stream of truth during an exit interview. The first is release. Unburdening yourself of frustration, and perhaps even anger to someone who isn't a friend or close colleague can be wonderfully free." },
      { speaker: "M", text: "Let me guess. The second is that the criticism will, theoretically, help the organization I'm leaving to improve, making sure employees of the future are less likely to encounter what I did?" },
      { speaker: "W", text: "That's right. But the problem with the company improvement part is that very often it doesn't happen. An exit interview is supposed to be private, but often isn't. In my company, the information gained from these interviews is often not confidential. The information is used as dirt against another manager, or can be traded among senior managers." },
      { speaker: "M", text: "Now you've got me rethinking what I'll disclose in the interview. There is always a chance that it could affect my reputation and my ability to network in the industry. It is a pretty small industry after all." },
      { speaker: "W", text: "Anything you initially gained from the instant satisfaction of telling it like it is, you might lose down the track by injuring your future career prospects." },
      { speaker: "M", text: "Right. Perhaps I would be better getting things off my chest by going to one of those rate-your-employer websites." },
      { speaker: "W", text: "You could. And don't do the interview at all. Exit interviews are not mandatory." }
    ],
    questions: [
      { q: "What do we learn about the man from the conversation?", options: ["He will tell the management how he really feels.", "He will meet his new manager in two weeks.", "He is going to attend a job interview.", "He is going to leave his present job."], answer: 3, explain: "原文 It's my last day at work tomorrow. I'll start my new job in 2 weeks，说明他即将离开现在的工作，对应 D 项。" },
      { q: "What does the woman think of the information gained from an exit interview?", options: ["It should be kept private.", "It should be carefully analyzed.", "It can be quite useful to senior managers.", "It can improve interviewees' job prospects."], answer: 0, explain: "原文 An exit interview is supposed to be private, but often isn't，她认为这类信息本应保密，对应 A 项。" },
      { q: "Why does the man want to rethink what he will say in the coming exit interview?", options: ["It may leave a negative impression on the interviewer.", "It may adversely affect his future career prospects.", "It may displease his immediate superiors.", "It may do harm to his fellow employees."], answer: 1, explain: "原文 it could affect my reputation and my ability to network in the industry，即担心影响未来的职业发展，对应 B 项。" },
      { q: "What does the man think he had better do?", options: ["Prepare a comprehensive exit report.", "Do some practice for the exit interview.", "Network with his close friends to find a better employer.", "Pour out his frustrations on a rate-your-employer website."], answer: 3, explain: "原文 Perhaps I would be better getting things off my chest by going to one of those rate-your-employer websites，对应 D 项。" }
    ],
    keyWords: [
      { w: "exit interview", cn: "离职面谈" },
      { w: "confidential", cn: "保密的" },
      { w: "reputation", cn: "名声；声誉" },
      { w: "mandatory", cn: "强制的；必须的" },
      { w: "frustration", cn: "挫败感；懊恼" },
      { w: "disclose", cn: "透露；公开" },
      { w: "career prospects", cn: "职业前景" }
    ]
  },
  {
    id: "cet6-2021-06-conv-2",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348548/",
    verified: true,
    type: "长对话",
    title: "访谈植物学家 Jane Foster 的雨林考察",
    script: [
      { speaker: "M", text: "Today, I'm talking to the renowned botanist, Jane Foster." },
      { speaker: "W", text: "Thank you for inviting me to join you on the show, Henry." },
      { speaker: "M", text: "Recently, Jane, you've become quite a celebrity, since the release of your latest documentary. Can you tell us a little about it?" },
      { speaker: "W", text: "Well, it follows my expedition to study the vegetation indigenous to the rain forest in equatorial areas of southeast Asia." },
      { speaker: "M", text: "You certainly get to travel to some very exotic locations." },
      { speaker: "W", text: "It was far from glamorous, to be honest. The area we visited was accessible only by canoe and the living conditions in the hut were primitive to say the least. There was no electricity. Our water supply was a nearby stream." },
      { speaker: "M", text: "How were the weather conditions while you were there?" },
      { speaker: "W", text: "The weather was not conducive to our work at all, since the humidity was almost unbearable. At midday, we stayed in the hut and did nothing. It was too humid to either work or sleep." },
      { speaker: "M", text: "How long did your team spend in the jungle?" },
      { speaker: "W", text: "Originally, we planned to be there for a month. But in the end, we stayed for only 2 weeks." },
      { speaker: "M", text: "Why did you cut the expedition short?" },
      { speaker: "W", text: "Halfway through the trip, we received news that a hurricane was approaching. We had to evacuate on very short notice." },
      { speaker: "M", text: "That sounds like a fascinating anecdote." },
      { speaker: "W", text: "It was frightening. The fastest evacuation route was through river rapids. We had to navigate them carrying all of our equipment." },
      { speaker: "M", text: "So overall was the journey unsuccessful?" },
      { speaker: "W", text: "Absolutely not. We gathered a massive amount of data about the local plant life." },
      { speaker: "M", text: "Why do you put up with such adverse conditions?" },
      { speaker: "W", text: "Botany is an obsession for me. Many of the destinations I visit have stunning scenery. I get to meet a variety of people from all over the world." },
      { speaker: "M", text: "So where will your next destination be?" },
      { speaker: "W", text: "I haven't decided yet." },
      { speaker: "M", text: "Then we can leave it for another vacation. Thanks." }
    ],
    questions: [
      { q: "What does the man want Jane Foster to talk about?", options: ["Her unsuccessful journey.", "Her month-long expedition.", "Her latest documentary.", "Her career as a botanist."], answer: 2, explain: "原文 since the release of your latest documentary. Can you tell us a little about it，男士想让她谈谈最新的纪录片，对应 C 项。" },
      { q: "Why does the woman describe her experience as far from glamorous?", options: ["She had to live like a vegetarian.", "She was caught in a hurricane.", "She had to endure many hardships.", "She suffered from water shortage."], answer: 2, explain: "原文 the living conditions in the hut were primitive... There was no electricity. Our water supply was a nearby stream，说明她吃了不少苦，对应 C 项。" },
      { q: "Why did the woman and those who went with her end their trip halfway?", options: ["A hurricane was coming.", "A flood was approaching.", "They had no more food in the canoe.", "They could no longer bear the humidity."], answer: 0, explain: "原文 Halfway through the trip, we received news that a hurricane was approaching，对应 A 项。" },
      { q: "What does the woman think of the journey?", options: ["It was memorable.", "It was unbearable.", "It was uneventful.", "It was fruitful."], answer: 3, explain: "原文 So overall was the journey unsuccessful? Absolutely not. We gathered a massive amount of data，可见她认为此行收获很大，对应 D 项。" }
    ],
    keyWords: [
      { w: "botanist", cn: "植物学家" },
      { w: "documentary", cn: "纪录片" },
      { w: "expedition", cn: "考察；远征" },
      { w: "humidity", cn: "湿度" },
      { w: "hurricane", cn: "飓风" },
      { w: "evacuate", cn: "撤离；疏散" },
      { w: "adverse", cn: "不利的；恶劣的" }
    ]
  },
  {
    id: "cet6-2021-06-passage-1",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348549/",
    verified: true,
    type: "听力篇章",
    title: "科学术语为何让读者疏远科学",
    script: [
      { speaker: "N", text: "Scientists often use specialized jargon terms while communicating with laymen. Most of them don't realize the harmful effects of this practice. In a new study, people exposed to jargon when reading about subjects like autonomous vehicles and surgical robots later said they were less interested in science than others who read about the same topics, but without the use of specialized terms. They also felt less informed about science and less qualified to discuss science topics." },
      { speaker: "N", text: "It's noteworthy that it made no difference if the jargon terms were defined in the text. Even when the terms were defined, readers still felt the same lack of engagement as readers who read jargon that wasn't explained. The problem is that the mere presence of jargon sends a discouraging message to readers." },
      { speaker: "N", text: "Hillary Schulman, the author of the study, asserts that specialized words are a signal. Jargon tells people that the message isn't for them. There's an even darker side to how people react to jargon. In another study, researchers found that reading scientific articles containing jargon led people to doubt the actual science. They found the opposite when a text is easier to read: people are more persuaded." },
      { speaker: "N", text: "Thus, it's important to communicate clearly when talking about complex science subjects. This is especially true with issues related to public health, like the safety of new medications and the benefits of vaccines. Schulman concedes that the use of jargon is appropriate with scientific audiences. But scientists who want to communicate with the general public need to modify their language. They need to eliminate jargon." }
    ],
    questions: [
      { q: "What does the passage say about the use of jargon terms by experts?", options: ["It diminishes laymen's interest in science.", "It ensures the accuracy of their arguments.", "It makes their expressions more explicit.", "It hurts laymen's dignity and self-esteem."], answer: 0, explain: "原文 people exposed to jargon... said they were less interested in science，即术语削弱了普通人对科学的兴趣，对应 A 项。" },
      { q: "What do researchers find about people reading scientific articles containing jargon terms?", options: ["They can learn to communicate with scientists.", "They tend to disbelieve the actual science.", "They feel great respect towards scientists.", "They will see the complexity of science."], answer: 1, explain: "原文 reading scientific articles containing jargon led people to doubt the actual science，对应 B 项。" },
      { q: "What does Schulman suggest scientists do when communicating with the general public?", options: ["Find appropriate topics.", "Stimulate their interest.", "Explain all the jargon terms.", "Do away with jargon terms."], answer: 3, explain: "原文 But scientists who want to communicate with the general public... They need to eliminate jargon，对应 D 项 do away with（去除）。" }
    ],
    keyWords: [
      { w: "jargon", cn: "行话；专业术语" },
      { w: "laymen", cn: "外行人；非专业人士" },
      { w: "noteworthy", cn: "值得注意的" },
      { w: "engagement", cn: "参与；投入" },
      { w: "scientific articles", cn: "科学文章" },
      { w: "public health", cn: "公共卫生" },
      { w: "vaccines", cn: "疫苗" },
      { w: "eliminate", cn: "消除；去掉" }
    ]
  },
  {
    id: "cet6-2021-06-passage-2",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348550/",
    verified: true,
    type: "听力篇章",
    title: "得克萨斯的石油热潮与兴衰",
    script: [
      { speaker: "N", text: "At the beginning of the twentieth century, on the Gulf coast in the US state of Texas, there was a hill where gas leakage was so noticeable that schoolboys would sometimes set the hill on fire. Patio Higgins, a disreputable local businessman, became convinced that there was oil below the gassy hill. Oil wells weren't drilled back then. They were essentially dug. The sand under the hill defeated several attempts by Higgins' workers to make a proper hole." },
      { speaker: "N", text: "Higgins had forecast oil at 1000 feet, a totally made-up figure. Higgins subsequently hired a mining engineer, Captain Anthony Lucas. After encountering several setbacks, Captain Lucas decided to use a drill, and his innovations created the modern oil drilling industry. In January 1901, at 1020 feet, almost precisely the depth predicted by Higgins, wild gas roared and the well suddenly ejected mud and six tons of drilling pipe out of the ground, terrifying those present. For the next nine days until the well was capped, the well poured out more oil than all the wells in America combined." },
      { speaker: "N", text: "In those days, Texas was almost entirely rural, with no large cities and practically no industry. Cotton and beef were the foundation of the economy. Higgins' well changed that. The boom made some prospectors millionaires, but the sudden surplus of petroleum was not entirely a blessing for Texas. In the 1930s, prices crashed to the point that in some parts of the country, oil was cheaper than water. That would become a familiar pattern of the boom or bust Texas economy." }
    ],
    questions: [
      { q: "What did Texas businessman Patio Higgins believe?", options: ["The local gassy hill might start a huge fire.", "There was oil leakage along the Gulf Coast.", "The erupting gas might endanger local children.", "There were oil deposits below a local gassy hill."], answer: 3, explain: "原文 became convinced that there was oil below the gassy hill，对应 D 项。" },
      { q: "What prevented Higgins' workers from digging a proper hole to get the oil?", options: ["The massive gas underground.", "Their lack of the needed skill.", "The sand under the hill.", "Their lack of suitable tools."], answer: 2, explain: "原文 The sand under the hill defeated several attempts by Higgins' workers to make a proper hole，对应 C 项。" },
      { q: "What does the passage say about Captain Lucas' drilling method?", options: ["It rendered many oil workers jobless.", "It was not as effective as he claimed.", "It gave birth to the oil drilling industry.", "It was not popularized until years later."], answer: 2, explain: "原文 his innovations created the modern oil drilling industry，对应 C 项。" },
      { q: "What do we learn about Texas's oil industry boom?", options: ["It radically transformed the state's economy.", "It resulted in an oil surplus all over the world.", "It totally destroyed the state's rural landscape.", "It ruined the state's cotton and beef industries."], answer: 0, explain: "原文 Cotton and beef were the foundation of the economy. Higgins' well changed that，说明石油彻底改变了该州经济结构，对应 A 项。" }
    ],
    keyWords: [
      { w: "gas leakage", cn: "气体泄漏" },
      { w: "oil wells", cn: "油井" },
      { w: "drill", cn: "钻探；钻孔" },
      { w: "setbacks", cn: "挫折；阻碍" },
      { w: "prospectors", cn: "勘探者；找矿人" },
      { w: "surplus", cn: "过剩；盈余" },
      { w: "boom", cn: "繁荣；热潮" }
    ]
  },
  {
    id: "cet6-2021-06-recording-1",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_bec/p1348551/",
    verified: true,
    type: "听力篇章",
    title: "糟糕管理者的四大成因研究",
    script: [
      { speaker: "N", text: "Most people dislike their jobs. It's an astonishing but statistical fact. A primary cause of employee dissatisfaction, according to fresh research, is that many believe they have terrible managers. Few describe their managers as malicious or manipulative, though; while those types certainly exist, they are a minority." },
      { speaker: "N", text: "The majority of managers seemingly just don't know any better. They're often emulating bad managers they've had in the past. It's likely they've never read a management book or attended a management course. The researchers interviewed employees about their managers, beginning with a question about the worst manager they had ever had. From this, the researchers came up with four main causes of why some managers are perceived as being simply awful at their jobs." },
      { speaker: "N", text: "The first cause was company culture, which was seen by employees as enabling poor management practices. It was specifically stressful work environments, minimal training, and a lack of accountability that were found to be the most blameworthy. Often a manager's superiors can effectively encourage a manager's distasteful behavior when they fail to discipline the person's wrongdoings. Such workplaces are sometimes described as toxic." },
      { speaker: "N", text: "The second cause was attributed to the managers' characteristics: those deemed to be most destructive were odd people, those without drive, those who allow personal problems into the workplace, and those with an unpleasant temperament or personality in general. The third cause of poor management was associated with their deficiency of qualifications. Not so much the form of variety one obtains from a university, but the informal variety that comes from credible work experience and professional accomplishments." },
      { speaker: "N", text: "The fourth cause concerned managers who've been promoted for reasons other than potential. One reason in particular why these people had been promoted was that they had been around the longest. It wasn't their skill set or other merits that got them the job, it was their tenure. A point worth making is that the study was based only on the perspective of employees. The researchers didn't ask senior leaders what they thought of their front-line managers. It's quite possible they're content with how the individuals they promoted are now performing, merrily ignorant of the damage they're actually causing. Which might explain why, as the researchers conclude, those same middle managers are usually unaware that they are a bad manager." }
    ],
    questions: [
      { q: "What is a primary cause of employee dissatisfaction according to recent research?", options: ["Unsuitable jobs.", "Bad managers.", "Insufficient motivation.", "Tough regulations."], answer: 1, explain: "原文 A primary cause of employee dissatisfaction... is that many believe they have terrible managers，对应 B 项。" },
      { q: "What is one of the causes for poor management practices?", options: ["Ineffective training.", "Toxic company culture.", "Lack of regular evaluation.", "Overburdening of managers."], answer: 1, explain: "原文 The first cause was company culture... Such workplaces are sometimes described as toxic，对应 B 项。" },
      { q: "What do we learn about the study on job dissatisfaction?", options: ["It collected feedback from both employers and employees.", "It was conducted from frontline managers' point of view.", "It provided meaningful clues to solving the problem.", "It was based only on the perspective of employees."], answer: 3, explain: "原文 the study was based only on the perspective of employees，对应 D 项。" }
    ],
    keyWords: [
      { w: "dissatisfaction", cn: "不满" },
      { w: "malicious", cn: "恶意的" },
      { w: "emulating", cn: "模仿；效仿" },
      { w: "toxic", cn: "有毒的；不良的" },
      { w: "accountability", cn: "问责；责任心" },
      { w: "promoted", cn: "被提升的" },
      { w: "tenure", cn: "任期；资历" }
    ]
  },
  {
    id: "cet6-2021-06-recording-2",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348552/",
    verified: true,
    type: "听力篇章",
    title: "西澳矿业的自动化革命",
    script: [
      { speaker: "N", text: "With the use of driverless vehicles seemingly inevitable, mining companies in the vast Australian desert state of Western Australia are definitely taking the lead. Iron ore is a key ingredient in steel-making. The mining companies here produce almost 300 million tons of iron ore a year. The 240 giant autonomous trucks in use in the Western Australian mines can weigh 400 tons fully loaded and travel at speeds of up to sixty kilometers per hour." },
      { speaker: "N", text: "They are a technological leap, transporting iron ore along routes which run for hundreds of kilometers from mines to their destinations. When the truck arrives at its destination, staff in the operation center direct it precisely where to unload. Vast quantities of iron ore are then transported by autonomous trains to ocean ports. Advocates argue these automated vehicles will change mining forever. It may only be five years before the use of automation technology leads to a fully robotic mine." },
      { speaker: "N", text: "A range of factors has pushed Western Australia's desert region to the lead of this automation revolution. These include the huge size of the mines, the scale of equipment and the repetitive nature of some of the work. Then there's the area's remoteness, at 502,000 square kilometers. It can sometimes make recruiting staff a challenge. Another consideration is the risks when humans interact with large machinery. There are also the financial imperatives. The ongoing push by the mining corporations to be more productive and more efficient is another powerful driver in embracing automation technology." },
      { speaker: "N", text: "The concept of a fully autonomous mine is a bit of a misleading term, however. This is because the more technology is put into the field, the more people are needed to deploy, maintain and improve it. The automation and digitization of the industry is creating a need for different jobs. These include data scientists and engineers in automation and artificial intelligence. The mining companies claim automation and robotics present opportunities to make mining more sustainable and safer. Workers' unions have accepted the inevitability of the introduction of new technology, but they still have reservations about the rise of automation technology. Their main concern is the potential impact on remote communities. As automation spreads further, the question is how these remote communities will survive when the old jobs are eliminated. And this may well prove to be the most significant impact of robotic technology in many places around the world." }
    ],
    questions: [
      { q: "What does the passage say about the mining industry in Western Australia?", options: ["It is seeing an automation revolution.", "It is bringing prosperity to the region.", "It is yielding an unprecedented profit.", "It is expanding at an accelerating speed."], answer: 0, explain: "原文 mining companies in Western Australia are definitely taking the lead... this automation revolution，对应 A 项。" },
      { q: "What is the impact of the digitization of the mining industry?", options: ["It exhausts resources sooner.", "It creates a lot of new jobs.", "It causes conflicts between employers and employees.", "It calls for the retraining of unskilled mining workers."], answer: 1, explain: "原文 The automation and digitization of the industry is creating a need for different jobs，即创造出新的岗位需求，对应 B 项。" },
      { q: "What is the attitude of workers' union towards the introduction of new technology?", options: ["They welcome it with open arms.", "They will wait to see its effect.", "They are strongly opposed to it.", "They accept it with reservations."], answer: 3, explain: "原文 Workers' unions have accepted the inevitability... but they still have reservations，对应 D 项。" }
    ],
    keyWords: [
      { w: "autonomous", cn: "自动的；无人驾驶的" },
      { w: "iron ore", cn: "铁矿石" },
      { w: "remoteness", cn: "偏远" },
      { w: "recruiting", cn: "招聘" },
      { w: "digitization", cn: "数字化" },
      { w: "sustainable", cn: "可持续的" },
      { w: "unions", cn: "工会" }
    ]
  },
  {
    id: "cet6-2021-06-recording-3",
    level: "cet6",
    year: "2021年6月",
    source: "https://m.hujiang.com/en_fanyi/p1348553/",
    verified: true,
    type: "听力篇章",
    title: "全球道路死亡与泰国交通安全",
    script: [
      { speaker: "N", text: "According to official statistics, Thailand's annual road death rate is almost double the global average. Thai people know that their roads are dangerous, but they don't know this could easily be changed. Globally, road accidents kill more people every year than any infectious disease. Researchers at the Institute for Health Metrics and Evaluation in America put the death toll in 2017 at 1.24 million." },
      { speaker: "N", text: "According to the institute, the overall number of deaths has been more or less static since the turn of the century. But that disguises a lot of changes in individual countries. In many poor countries, road accidents are killing more people than ever before. Those countries have swelling young populations, a fast-growing fleet of cars and motorbikes, and a limited supply of surgeons. It is impossible to know for sure, because official statistics are so inadequate. But deaths are thought to have risen by 40% since 1990 in many low income countries. In many rich countries, by contrast, roads are becoming even safer. In Estonia and Ireland, for example, the number of deaths has fallen by about two thirds since the late 1990s." },
      { speaker: "N", text: "But the most important and intriguing changes are taking place in middle income countries, which contain most of the world's people and have some of the most dangerous roads. According to researchers in China and South Africa, traffic deaths have been falling since 2000, and in India since 2012, and the Philippines reached its peak four years ago. The question is whether Thailand can soon follow suit." },
      { speaker: "N", text: "Rob McKinney, head of the International Road Assessment Program, says that all countries tend to go through three phases. They begin with poor, slow roads. In the second phase, as they grow wealthier, they pave the roads, allowing traffic to move faster and pushing up the death rate. Lastly, in the third phase, countries act to make their roads safer. The trick, then, is to reach the third stage sooner by focusing earlier and more closely on fatal accidents. How to do that? The solution lies not just in better infrastructure, but in better social incentives. Safe driving habits are practices which people know they should follow but often don't. Dangerous driving is not a fixed cultural trait, as some imagine. People respond to incentives such as traffic laws that are actually enforced." }
    ],
    questions: [
      { q: "What does the speaker say about traffic accidents in Thailand?", options: ["Their cost to the nation's economy is incalculable.", "They kill more people than any infectious disease.", "Their annual death rate is about twice that of the global average.", "They have experienced a gradual decline since the year of 2017."], answer: 2, explain: "原文 Thailand's annual road death rate is almost double the global average，对应 C 项。" },
      { q: "What do we learn from an American institute's statistics regarding road deaths?", options: ["They show a difference between rich and poor nations.", "They don't reflect the changes in individual countries.", "They rise and fall from year to year.", "They are not as reliable as claimed."], answer: 1, explain: "原文 the overall number of deaths has been more or less static... But that disguises a lot of changes in individual countries，即总体数据掩盖了各国差异，对应 B 项。" },
      { q: "What is said about middle income countries?", options: ["Many of them have increasing numbers of cars on the road.", "Many of them are following the example set by Thailand.", "Many of them have seen a decline in road-death rates.", "Many of them are investing heavily in infrastructure."], answer: 2, explain: "原文 traffic deaths have been falling since 2000, and in India since 2012, and the Philippines reached its peak，即中等收入国家死亡率在下降，对应 C 项。" },
      { q: "What else could be done to reduce fatal road accidents in addition to safer roads?", options: ["Foster better driving behavior.", "Provide better training for drivers.", "Abolish all outdated traffic rules.", "Impose heavier penalties on speeding."], answer: 0, explain: "原文 The solution lies not just in better infrastructure, but in better social incentives... People respond to incentives such as traffic laws that are actually enforced，即培养更安全的驾驶行为，对应 A 项。" }
    ],
    keyWords: [
      { w: "infectious disease", cn: "传染病" },
      { w: "death toll", cn: "死亡人数" },
      { w: "static", cn: "静止的；不变的" },
      { w: "middle income countries", cn: "中等收入国家" },
      { w: "infrastructure", cn: "基础设施" },
      { w: "incentives", cn: "激励；诱因" },
      { w: "enforced", cn: "被执行的；被强制实施的" }
    ]
  }
];
