window.REAL_READING = [
{
    "id": "cet6-2020-09-reading-1",
    "level": "cet6",
    "year": "2020年9月",
    "source": "https://m.hujiang.com/en_becgaoji/p1328752/",
    "verified": true,
    "type": "阅读理解",
    "title": "英国肥胖问题与政府干预 (Obesity and government intervention)",
    "passage": "It is not controversial to say that an unhealthy diet causes bad health. Obesity raises susceptibility to cancer, and Britain is the sixth most obese country on Earth. That is a public health emergency. But naming the problem is the easy part. No one disputes the costs in quality of life and depleted health budgets of an obese population, but the quest for solutions gets diverted by ideological arguments around responsibility and choice.\n\nHistorical precedent suggests that science and politics can overcome resistance from businesses the pollute and poison but it takes time, and success often starts small. So it is heartening to note that a programme in Leeds has achieved a reduction in childhood obesity, becoming the first UK city to reverse a fattening trend.\n\nMany members of parliament are uncomfortable even with their own governments anti-obesity strategy, since it involves a \"sugar tax \" and a ban on the sale of energy drinks to under-16s. Bans and taxes can be blunt instruments, but their harshest critics can rarely suggest better methods. These critics just oppose regulation itself.\n\nThe relationship between poor health and inequality is too pronounced for governments to be passive about large-scale intervention. People living in the most deprived areas are four times more prone to die from avoidable causes than counterparts in more affluent places. As the structural nature of public health problems becomes harder to ignore, the complaint about overprotective government loses potency.\n\nGovernment action works when individuals are motivated to respond. The function of a well-designed state intervention is not to deprive people of liberty but to build social capacity and infrastructure that helps people take responsibility for their wellbeing. The obesity crisis will not have a solution devised by left or right ideology-but experience indicates that the private sector needs the incentive of regulation before it starts taking public health emergencies seriously.",
    "questions": [
      {
        "q": "Why is the obesity problem in Britain so difficult to solve?",
        "options": [
          "Government health budgets are depleted.",
          "People disagree as to who should do what.",
          "Individuals are not ready to take their responsibilities.",
          "Industry lobbying makes it hard to get healthy foods."
        ],
        "answer": 1,
        "explain": "第一段指出解决之道被「围绕责任与选择的意识形态争论」岔开，即各方对「谁该做什么」争执不下，故选B。A只是结果不是难解原因；C、D文中未如此表述。"
      },
      {
        "q": "What can we learn from the past experience in tackling public health emergencies?",
        "options": [
          "Governments have a role to play.",
          "Public health is a scientific issue.",
          "Priority should be given to deprived regions.",
          "Businesses responsibility should be stressed."
        ],
        "answer": 0,
        "explain": "第二段「science and politics can overcome resistance from businesses」表明需要科学与政治（即政府）共同发力，利兹的成功也源于政府项目，故选A。B、C、D均非该段要点。"
      },
      {
        "q": "What does the author imply about some critics of bans and taxes concerning unhealthy drinks?",
        "options": [
          "They are not aware of the consequences of obesity.",
          "They have not come up with anything more constructive.",
          "They are uncomfortable with parliament's anti-obesity debate.",
          "They have their own motives in opposing government regulation."
        ],
        "answer": 1,
        "explain": "第四段说禁令与税收虽粗暴，但最激烈的批评者「rarely suggest better methods」，即拿不出更好的办法，故选B。A、C、D文中均无依据。"
      },
      {
        "q": "Why does the author stress the relationship between poor health and inequality?",
        "options": [
          "To demonstrate the dilemma of people living in deprived areas.",
          "To bring to light the root cause of widespread obesity in Britain.",
          "To highlight the area deserving the most attention from the public.",
          "To justify government intervention in solving the obesity problem."
        ],
        "answer": 3,
        "explain": "第五段用贫困地区死亡率高说明问题具结构性，政府不能被动，从而为大规模干预提供正当理由，故选D。A、B、C停留在现象描述，未点出论证目的。"
      },
      {
        "q": "When will government action be effective?",
        "options": [
          "When the polarised debate is abandoned.",
          "When ideological differences are resolved.",
          "When individuals have the incentive to act accordingly.",
          "When the private sector realises the severity of the crisis."
        ],
        "answer": 2,
        "explain": "末段首句「Government action works when individuals are motivated to respond」，即个人有动机配合时才奏效，故选C。A、B、D都不是该句所给条件。"
      }
    ],
    "keyWords": [
      {
        "w": "obesity",
        "cn": "肥胖（症）"
      },
      {
        "w": "susceptibility",
        "cn": "易感性，敏感度"
      },
      {
        "w": "depleted",
        "cn": "被耗尽的"
      },
      {
        "w": "ideological",
        "cn": "意识形态的"
      },
      {
        "w": "precedent",
        "cn": "先例，前例"
      },
      {
        "w": "intervention",
        "cn": "干预，介入"
      },
      {
        "w": "potency",
        "cn": "效力，影响力"
      },
      {
        "w": "wellbeing",
        "cn": "福祉，健康幸福"
      }
    ],
    "translation": "说饮食不健康会导致健康受损并无争议。肥胖会增加患癌的易感性，而英国是地球上第六肥胖的国家。这是一场公共卫生紧急事件。但指出问题只是容易的部分。没有人质疑肥胖人口在生活质量和医疗预算被耗尽方面的代价，然而寻求解决方案的努力被围绕责任与选择的意识形态争论所岔开。而那些靠销售致胖产品获利的企业游说，更让水变得浑浊。历史先例表明，科学与政治能够战胜污染与毒害企业的阻力，但这需要时间，成功往往始于微小之处。因此令人欣慰的是，利兹的一个项目已使儿童肥胖率下降，成为英国首个扭转肥胖趋势的城市。效果在年幼儿童和更贫困地区最为明显。许多议员甚至对本国的反肥胖战略也感到不安，因为它涉及「糖税」以及禁止向 16 岁以下出售能量饮料。禁令与税收可能是粗暴的工具，但最激烈的批评者很少能提出更好的办法，他们只是反对监管本身。健康不良与不平等之间的关系太过显著，政府不可能对大规模干预无动于衷。最贫困地区的人们因可避免原因死亡的可能性是富裕地区的四倍。随着公共卫生问题的结构性本质越来越难以忽视，对「政府过度保护」的抱怨便失去了威力。只有个人有动机回应时，政府行动才有效。个人需要能扩大其获得好选择机会的政府。精心设计的国家干预，其功能不是剥夺人们的自由，而是构建社会能力与基础设施，帮助人们为自己的福祉负责。肥胖危机不会有左翼或右翼意识形态设计出的解决方案——但经验表明，私营部门需要监管的激励，才会认真对待公共卫生紧急事件。"
  },
{
    "id": "cet6-2020-09-reading-2",
    "level": "cet6",
    "year": "2020年9月",
    "source": "https://m.hujiang.com/en_becgaoji/p1328752/",
    "verified": true,
    "type": "阅读理解",
    "title": "澳大利亚珊瑚海海洋保护区计划 (The Coral Sea marine reserve plan)",
    "passage": "Home to virgin reefs, rare sharks and vast numbers of exotic fish, the Coral Sea is a unique haven of biodiversity off the northeastern coast of Australia. If a proposal by the Australian government goes ahead, the region will also become the world's largest marine protected area, with restrictions or bans on fishing. mining and marine farming.\n\nThe Coral Sea reserve would cover almost 990 000 square kilometers and stretch as far as 1 100 kilometers from the coast. Unveiled recently by environment minister Tony Burke, the proposal would be the last in a series of proposed marine reserves around Australia's coast.\n\nBut the scheme is attracting criticism from scientists and conservation groups, who argue that the government hasn't gone far enough in protecting the Coral Sea, or in other marine reserves in the coastal network.\n\nAs Nature went to press, the Australian government had not responded to specific criticisms of the plan. But Robin Beaman, a marine geologist at James Cook Univest says that the reserve does \"broadly protect the range of habitats\" in the sea. \"I can testify to the huge effort that government agencies and other organisations have put into trying to understand the ecological values of this vast area\" he says.\n\nCritics say that the southwestern reserve offers the greatest protection to the offshore areas where commercial opportunities are fewest and where there is little threat to the environment, a contention also levelled at the Coral Sea plan.",
    "questions": [
      {
        "q": "What do we learn from the passage about the Coral Sea?",
        "options": [
          "It is exceptionally rich in marine life.",
          "It is the biggest marine protected area.",
          "It remains largely undisturbed by humans.",
          "It is a unique haven of endangered species."
        ],
        "answer": 0,
        "explain": "首段用原始珊瑚礁、稀有鲨鱼和大量奇异鱼类说明其海洋生物极其丰富，故选A。B是「若提案通过将成」的未来状态；C、D与原文「unique haven of biodiversity」不符。"
      },
      {
        "q": "What does the Australian government plan to do according to Tony Burke?",
        "options": [
          "Make a new proposal to protect the Coral Sea.",
          "Revise its conservation plan owing to criticisms.",
          "Upgrade the established reserves to protect marine life.",
          "Complete the series of marine reserves around its coast."
        ],
        "answer": 3,
        "explain": "第二段说该提案「would be the last in a series of proposed marine reserves around Australia's coast」，即完成环海岸保护区系列，故选D。A、B、C均未在文中出现。"
      },
      {
        "q": "What is scientists' argument about the Coral Sea proposal?",
        "options": [
          "The government has not done enough for marine protection.",
          "It will not improve the marine reserves along Australia's coast.",
          "The government has not consulted them in drawing up the proposal.",
          "It is not based on sufficient investigations into the ecological system."
        ],
        "answer": 0,
        "explain": "第三段明确科学家与保护团体认为政府「hasn't gone far enough in protecting the Coral Sea」，即保护力度不够，故选A。C、D文中未提，B过于绝对。"
      },
      {
        "q": "What does marine geologist Robin Beaman say about the Coral Sea plan?",
        "options": [
          "It can compare with the British government's effort in the Indian Ocean.",
          "It will result in the establishment of the world's largest marine reserve.",
          "It will ensure the sustainability of the fishing industry around the coast.",
          "It is a tremendous joint effort to protect the range of marine habitats."
        ],
        "answer": 3,
        "explain": "Robin Beaman 称该保护区「broadly protect the range of habitats」，并强调政府机构与其他组织的巨大共同努力，故选D。A的比较来自第四段 Possingham，非 Beaman 观点。"
      },
      {
        "q": "What do critics think of the Coral Sea plan?",
        "options": [
          "It will do more harm than good to the environment.",
          "It will adversely affect Australia's fishing industry.",
          "It will protect regions that actually require little protection.",
          "It will win little support from environmental organisations."
        ],
        "answer": 2,
        "explain": "末段批评者指出保护区重点覆盖商业机会最少、环境威胁最小的近海区，这一指责同样适用于珊瑚海计划，故选C。A、B、D均非批评者的原话。"
      }
    ],
    "keyWords": [
      {
        "w": "biodiversity",
        "cn": "生物多样性"
      },
      {
        "w": "haven",
        "cn": "避难所，天堂"
      },
      {
        "w": "marine",
        "cn": "海洋的"
      },
      {
        "w": "reserve",
        "cn": "保护区；储备"
      },
      {
        "w": "geologist",
        "cn": "地质学家"
      },
      {
        "w": "offshore",
        "cn": "近海的，离岸的"
      },
      {
        "w": "contention",
        "cn": "争论，论点"
      },
      {
        "w": "conservation",
        "cn": "保护，保育"
      }
    ],
    "translation": "珊瑚海位于澳大利亚东北海岸外，拥有原始珊瑚礁、稀有鲨鱼和大量奇异鱼类，是一个独特的生物多样性天堂。如果澳大利亚政府的提案得以推进，该区域还将成为世界上最大的海洋保护区，对捕鱼、采矿和海洋养殖加以限制或禁止。珊瑚海保护区将覆盖近 99 万平方公里，从海岸向外延伸达 1100 公里。环境部长托尼·伯克最近公布的这项提案，将是环绕澳大利亚海岸的一系列海洋保护区提案中的最后一项。但该方案正招致科学家和环保团体的批评，他们认为政府无论在保护珊瑚海，还是保护海岸网络中其他海洋保护区方面都做得还不够。批评者称，西南保护区对商业机会最少、环境威胁最小的近海区域给予了最大保护，这一指责同样指向珊瑚海计划。"
  },
{
    "id": "cet4-2016-06-reading-1",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://www.hujiang.com/c/yysjtlzt/p1187014/",
    "verified": true,
    "type": "阅读理解",
    "title": "把人类价值观写进机器人程序 (Turning human values into programmable code)",
    "passage": "As Artificial Intelligence (AI) becomes increasingly sophisticated, there are growing concerns that robots could become a threat. This danger can be avoided, according to computer science professor Stuart Russell, if we figure out how to turn human values into a programmable code.\n\nRussell argues that as robots take on more complicated tasks, it's necessary to translate our morals into AI language.\n\nFor example, if a robot does chores around the house, you wouldn't want it to put the pet cat in the oven to make dinner for the hungry children. \"You would want that robot preloaded with a good set of values,\" said Russell.\n\nSome robots are already programmed with basic human values. For example, mobile robots have been programmed to keep a comfortable distance from humans. Obviously there are cultural differences, but if you were talking to another person and they came up close in your personal space, you wouldn't think that's the kind of thing a properly brought-up person would do.\n\nRobots could also learn values from drawing patterns from large sets of data on human behavior. They are dangerous only if programmers are careless.\n\nThe biggest concern with robots going against human values is that human beings fail to do sufficient testing and they've produced a system that will break some kind of taboo.\n\nOne simple check would be to program a robot to check the correct course of action with a human when presented with an unusual situation.\n\nIf the robot is unsure whether an animal is suitable for the microwave, it has the opportunity to stop, send out beeps, and ask for directions from a human.\n\nThe most difficult step in programming values will be deciding exactly what we believe in moral, and how to create a set of ethical rules. But if we come up with an answer, robots could be good for humanity.",
    "questions": [
      {
        "q": "What does the author say about the threat of robots?",
        "options": [
          "It may constitute a challenge to computer programmers.",
          "It accompanies all machinery involving high technology.",
          "It can be avoided if human values are translated into their language.",
          "It has become an inevitable peril as technology gets more sophisticated."
        ],
        "answer": 2,
        "explain": "首段 Stuart Russell 指出，只要我们把人类价值观转成可编程代码，这一危险就能避免，C 与之完全对应。A 偷换概念；B 文中无据；D 与「can be avoided」直接矛盾。"
      },
      {
        "q": "What would we think of a person who invades our personal space according to the author?",
        "options": [
          "They are aggressive.",
          "They are outgoing.",
          "They are ignorant.",
          "They are ill-bred."
        ],
        "answer": 3,
        "explain": "第四段说若有人贴进你的私人空间，你不会认为这是「a properly brought-up person」的作为，即缺乏教养，D（ill-bred）对应。A 具攻击性、B 外向、C 无知均非原文的意思。"
      },
      {
        "q": "How do robots learn human values?",
        "options": [
          "By interacting with humans in everyday life situations.",
          "By following the daily routines of civilized human beings.",
          "By picking up patterns from massive data on human behavior.",
          "By imitating the behavior of properly brought-up human beings."
        ],
        "answer": 2,
        "explain": "第六段原句「Robots could also learn values from drawing patterns from large sets of data on human behavior」，C 是其同义改写。A、B、D 都是原文未提的学习途径。"
      },
      {
        "q": "What will a well-programmed robot do when facing an unusual situation?",
        "options": [
          "Keep a distance from possible dangers.",
          "Stop to seek advice from a human being.",
          "Trigger its built-in alarm system at once.",
          "Do sufficient testing before taking action."
        ],
        "answer": 1,
        "explain": "原文建议机器人在遇到异常情形时与人类核对正确做法，即 stop…ask for directions from a human，故选 B；沪江网校版给出的答案亦为 B（本页旧版答案误标为 D）。"
      },
      {
        "q": "What is most difficult to do when we turn human values into a programmable code?",
        "options": [
          "Determine what is moral and ethical.",
          "Design some large-scale experiments.",
          "Set rules for man-machine interaction.",
          "Develop a more sophisticated program."
        ],
        "answer": 0,
        "explain": "末段指出最难的一步是「deciding exactly what we believe in moral, and how to create a set of ethical rules」，即确定何为道德与伦理，A 对应。B、C、D 均未在原文出现。"
      }
    ],
    "keyWords": [
      {
        "w": "sophisticated",
        "cn": "复杂精密的，老练的"
      },
      {
        "w": "programmable",
        "cn": "可编程的"
      },
      {
        "w": "chores",
        "cn": "家务活"
      },
      {
        "w": "preloaded",
        "cn": "预先装载的"
      },
      {
        "w": "taboo",
        "cn": "禁忌"
      },
      {
        "w": "ethical",
        "cn": "伦理的，道德的"
      },
      {
        "w": "humanity",
        "cn": "人类；人性"
      }
    ],
    "translation": "随着人工智能越来越精密，人们日益担忧机器人可能成为一种威胁。计算机科学教授斯图尔特·拉塞尔认为，只要能设法把人类价值观转化为可编程代码，这种危险就可以避免。拉塞尔主张，随着机器人承担更复杂的任务，我们必须把道德翻译成人工智能的语言。例如，若机器人做家务，你不会希望它为给饥饿的孩子做饭而把宠物猫放进烤箱。拉塞尔说：「你会希望那个机器人预先装有一套良好的价值观。」有些机器人已经装有基本的人类价值观，比如移动机器人被设定与人保持舒适的距离。显然存在文化差异，但若和人交谈时对方贴进你的私人空间，你不会认为这是有教养者的举止。只要我们能把人类价值观设定为明确的规则，就有可能造出更精密的道德机器。机器人也可以从人类行为大数据中提取模式来学习价值观，只有当程序员粗心时它们才危险。机器人违背人类价值观的最大隐患，是人类没有做充分测试，造出的系统会打破某种禁忌。一个简单的检查办法是：让机器人在遇到异常情况时先与人类核对正确的行动方案。如果机器人不确定某只动物能否放进微波炉，它可以停下来发出嘟嘟声，向人类请示。最困难的一步是弄清我们究竟信奉什么道德、如何建立一套伦理规则；但一旦找到答案，机器人就能造福人类。"
  },
{
    "id": "cet4-2016-06-reading-2",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://www.hujiang.com/c/yysjtlzt/p1187014/",
    "verified": true,
    "type": "阅读理解",
    "title": "性格与长寿 (Personality and longevity)",
    "passage": "Why do some people live to be older than others? But what effect does your personality have on your longevity? Do some kinds of personalities lead to longer lives? A new study in the Journal of the American Geriatrics Society looked at this question by examining the personality characteristics of 246 children of people who had lived to be at least 100.\n\nThe study shows that those living the longest are more outgoing, more active and less neurotic than other people. Long-living women are also more likely to be sympathetic and cooperative than women with a normal life span. These findings are in agreement with what you would expect from the evolutionary theory: those who like to make friends and help others can gather enough resources to make it through tough times.\n\nInterestingly, however, other characteristics that you might consider advantageous had no impact on whether study participants were likely to live longer. Those who were more self-disciplined, for instance, were no more likely to live to be very old. Also, being open to new ideas had no relationship to long life, which might explain all those bad-tempered old people who are fixed in their ways.\n\nBut the new paper suggests that if you want long life, you should strive to be as outgoing as possible.\n\nUnfortunately, another recent study shows that your mother's personality may also help determine your longevity. That study looked at nearly 28,000 Norwegian mothers and found that those moms who were more anxious, depressed and angry were more likely to feed their kids unhealthy diets. Patterns of childhood eating can be hard to break when we're adults, which may mean that kids of depressed moms end up dying younger.\n\nPersonality isn't destiny, and everyone knows that individuals can learn to change. But both studies show that long life isn't just a matter of your physical health but of your mental health.",
    "questions": [
      {
        "q": "The aim of the study in the Journal of the American Geriatrics Society is ____.",
        "options": [
          "to see whether people's personality affects their life span",
          "to find out if one's lifestyle has any effect on their health",
          "to investigate the role of exercise in living a long life",
          "to examine all the factors contributing to longevity"
        ],
        "answer": 0,
        "explain": "首段说明该研究正是为回答「性格是否影响寿命」这一问题，A 与之对应。B、C 属于文章开头的传统解释而非研究目的；D 的「所有因素」范围过大。"
      },
      {
        "q": "What does the author imply about outgoing and sympathetic people?",
        "options": [
          "They have a good understanding of evolution.",
          "They are better at negotiating an agreement.",
          "They generally appear more resourceful.",
          "They are more likely to get over hardship."
        ],
        "answer": 3,
        "explain": "第二段用进化论解释：爱交友、乐于助人者能积累足够资源「make it through tough times」，即更易渡过难关，D 对应。A 曲解进化论，B、C 无原文依据。"
      },
      {
        "q": "What finding of the study might prove somewhat out of our expectation?",
        "options": [
          "Easy-going people can also live a relatively long life.",
          "Personality characteristics that prove advantageous actually vary with times.",
          "Such personality characteristics as self-discipline have no effect on longevity.",
          "Readiness to accept new ideas helps one enjoy longevity."
        ],
        "answer": 2,
        "explain": "第三段以「Interestingly, however」引出反直觉结论：自律、乐于接受新观念等看似有利的特质对长寿毫无影响，C 对应。D 与原文相反，A、B 无据。"
      },
      {
        "q": "What does the recent study of Norwegian mothers show?",
        "options": [
          "Children's personality characteristics are invariably determined by their mothers.",
          "People with unhealthy eating habits are likely to die sooner.",
          "Mothers' influence on children may last longer than fathers'.",
          "Mothers' negative personality characteristics may affect their children's life spans."
        ],
        "answer": 3,
        "explain": "第五段指出焦虑、抑郁、易怒的母亲更可能让孩子吃得不健康，进而可能使孩子更早离世，D 概括准确。A 的「必然决定」过绝对，B 偷换对象，C 全文未涉及父亲。"
      },
      {
        "q": "What can we learn from the findings of the two new studies?",
        "options": [
          "Anxiety and depression more often than not cut short one's life span.",
          "Longevity results from a combination of mental and physical health.",
          "Personality plays a decisive role in how healthy one is.",
          "Health is in large part related to one's lifestyle."
        ],
        "answer": 1,
        "explain": "末段总结：长寿不只是身体健康问题，也是心理健康问题，B 的「身心结合」与之吻合。A 只涉及一项研究，C 的「决定作用」过度，D 是常识而非本文结论。"
      }
    ],
    "keyWords": [
      {
        "w": "longevity",
        "cn": "长寿"
      },
      {
        "w": "neurotic",
        "cn": "神经质的，情绪不稳的"
      },
      {
        "w": "sympathetic",
        "cn": "有同情心的"
      },
      {
        "w": "cooperative",
        "cn": "乐于合作的"
      },
      {
        "w": "self-disciplined",
        "cn": "自律的"
      },
      {
        "w": "advantageous",
        "cn": "有利的"
      },
      {
        "w": "destiny",
        "cn": "命运"
      }
    ],
    "translation": "为什么有些人比别人活得更久？你熟知的标准答案包括饮食适度、坚持锻炼等。但性格对寿命有什么影响？某些性格是否更长寿？《美国老年医学会杂志》的一项新研究通过考察 246 位百岁以上老人的子女的性格特征来回答这个问题。研究显示，最长寿者比其他人更外向、更活跃、更少神经质；长寿女性也比普通寿命的女性更富同情心、更乐于合作。这些发现与进化论的预期一致：喜欢交友、乐于助人的人能积累足够资源以渡过艰难时期。然而有趣的是，其他你可能认为有利的特征对寿命并无影响——比如更自律的人并不更长寿，对新观念持开放态度也与长寿无关，这或许能解释那些固执己见的坏脾气老人。成年人能否成功改变性格，是心理学界长期争论的话题；但新论文暗示，若想长寿，你应尽可能外向。不幸的是，另一项近期研究表明，母亲的性格也可能影响你的寿命：该研究调查了近 2.8 万名挪威母亲，发现更焦虑、抑郁、易怒的母亲更可能给孩子不健康的饮食，而童年饮食模式成年后难以改变，这意味着抑郁母亲的孩子可能寿命更短。性格并非命运，人人都能学会改变；但两项研究都表明，长寿不仅是身体健康问题，也是心理健康问题。"
  },
{
    "id": "cet6-2017-12-reading-2",
    "level": "cet6",
    "year": "2017年12月",
    "source": "https://m.ygjj.com/sz/Home/DetailArticle?articleId=452453",
    "verified": true,
    "type": "阅读理解",
    "title": "18 小时城市与美国城市格局变迁 (18-hour cities)",
    "passage": "Twenty years ago, the Urban Land Institute defined the two types of cities that dominated the US landscape: smaller cities that operated around standard 9-5 business hours and large metropolitan areas that ran all 24 hours of the day.\n\nIn recent years, many mid-sized cities have begun to adopt a middle-of-the-road approach incorporating the excitement and opportunity of large cities with small cities' quiet after midnight. These 18-hour cities are beginning to make waves in real estate rankings and attract more real estate investment. What is underlying this new movement in real estate, and why do these cities have so much appeal?\n\n18-hour cities combine the best of 24-hour and 9-5 cities, which contributes to downtown revitalization. For decades, many downtown cores in small to mid-sized cities were abandoned after work hours by workers who lived in the suburbs. Movement out of city centers was widespread, and downtown tenants were predominantly made up of the working poor. This generated little commerce for downtown businesses in the evenings, which made business and generating tax revenue for municipal upkeep difficult.\n\nTransforming downtown areas so that they incorporate modern housing and improved walkability to local restaurants, retail, and entertainment, especially when combined with improved infrastructure for cyclists and public transit, makes them appeal to a more affluent demographic. These adjustments encourage employers in the knowledge and talent industries to keep their offices downtown. Access to foot traffic and proximity to transit allow the type of entertainment-oriented businesses such as bars and restaurants to stay open later, which attracts both younger, creative workers and baby boomers nearing retirement alike.\n\nThese 18-hour cities are rapidly on the rise and offer great opportunities for homeowner investment. In many of these cities such as Denver, a diverse and vigorous economy attracted to the urban core has offered stable employment for residents.",
    "questions": [
      {
        "q": "What do we learn about American cities twenty years ago?",
        "options": [
          "They were divided into residential and business areas.",
          "Their housing prices were linked with their prosperity.",
          "There was a clear divide between large and small cities.",
          "They were places where large investment capital flowed."
        ],
        "answer": 2,
        "explain": "首段说二十年前的美国城市分为两类：按 9-5 作息的小城市与全天 24 小时运转的大都市区，界限清晰，C 对应。A、B、D 所述均非首段内容。"
      },
      {
        "q": "What can be inferred from the passage about 18-hour cities?",
        "options": [
          "They especially appeal to small businesses.",
          "They have seen a rise in property prices.",
          "They have replaced quiet with excitement.",
          "They have changed America's landscape."
        ],
        "answer": 3,
        "explain": "首段指出这两类城市曾「dominated the US landscape」，而 18 小时城市正在崛起并在房地产排名中掀起波澜，可见其改变了美国的城市格局，D 正确。B、C 表述片面，A 无依据。"
      },
      {
        "q": "Years ago, many downtown cores in small to mid-sized cities ____.",
        "options": [
          "had hardly any business activity",
          "were crowded in business hours",
          "exhibited no signs of prosperity",
          "looked deserted in the evenings"
        ],
        "answer": 3,
        "explain": "第三段说市中心下班后被郊区通勤者抛弃，晚上商业寥寥，即「夜晚显得荒凉无人」，D 对应。B 与原文相反，A、C 措辞过绝对。"
      },
      {
        "q": "What characterizes the new downtown areas in 18-hour cities?",
        "options": [
          "A sudden emergence of the knowledge industry.",
          "Flooding in of large crowds of migrant workers.",
          "Modernized housing and improved infrastructure.",
          "More comfortable life and greater upward mobility."
        ],
        "answer": 2,
        "explain": "第四段明确新市中心整合了「modern housing」与「improved infrastructure for cyclists and public transit」，C 对应。A、B、D 均非该段所述特征。"
      },
      {
        "q": "What have 18-hour cities brought to the local residents?",
        "options": [
          "More chances for promotion.",
          "Healthier living environment.",
          "Greater cultural diversity.",
          "Better job opportunities."
        ],
        "answer": 3,
        "explain": "末段以丹佛为例，说明多元而活跃的经济为居民提供了「stable employment」，即更好的就业机会，D 对应。A、B、C 文中均未提及。"
      }
    ],
    "keyWords": [
      {
        "w": "metropolitan",
        "cn": "大都市的"
      },
      {
        "w": "revitalization",
        "cn": "复兴，复苏"
      },
      {
        "w": "tenants",
        "cn": "租户，房客"
      },
      {
        "w": "walkability",
        "cn": "步行便利性"
      },
      {
        "w": "infrastructure",
        "cn": "基础设施"
      },
      {
        "w": "affluent",
        "cn": "富裕的"
      },
      {
        "w": "suburbs",
        "cn": "郊区"
      }
    ],
    "translation": "二十年前，城市土地学会把主导美国城市面貌的两类城市界定为：围绕朝九晚五作息运转的小城市，以及全天 24 小时运转的大都市区。近年来，许多中等规模城市开始走中间路线，把大城市的活力与机会同小城市午夜后的宁静结合起来。这些「18 小时城市」开始在房地产排名中掀起波澜，吸引到更多地产投资。18 小时城市兼具 24 小时城市与 9-5 城市的长处，推动了市中心的复兴。几十年来，中小城市的许多市中心在下班后被住在郊区的上班族抛弃，市中租户多为在职穷人，晚间几乎带不来商业，使市政维护所需的税收难以产生。改造市中心、引入现代住房并改善通往餐馆、零售与娱乐场所的步行条件，尤其是改善自行车与公共交通基础设施，会使其吸引更富裕的人群。这些调整促使知识与人才行业的雇主把办公室留在市中心。人流量与交通便利也让酒吧、餐馆等娱乐型商户营业更晚，从而同时吸引年轻创意工作者与临近退休的婴儿潮一代。这些 18 小时城市正迅速崛起，为购房投资提供了良机：在丹佛等城市，被吸引到城市核心区的多元而活跃的经济为居民提供了稳定就业，恰当的业态组合撑起了住房入住率，推高了房产价值，并吸引到可观的投资资本。"
  },
{
    "id": "cet4-2017-12-reading-1",
    "level": "cet4",
    "year": "2017年12月",
    "source": "https://m.hujiang.com/en_kouyizhentidaan/p1226603/",
    "verified": true,
    "type": "阅读理解",
    "title": "The First-night Effect (睡眠首夜效应与半脑警戒)",
    "passage": "That people often experience trouble sleeping in a different bed in unfamiliar surrounding is a phenomenon known as the \"first-night\" effect. If a person stays in the same room the following night they tend to sleep more soundly. Yuka Sasaki and her colleagues at Brown University set out to investigate the origins of this effect.\nDr. Sasaki knew the first-night effect probably has something to do with how humans evolved. The puzzle was that benefit would be gained from it when performance might be affected the following day. She also knew from previous work conducted on birds and dolphins that these animals put half of their brains to sleep at a time so that they can rest while remaining alert enough to avoid predators (捕食者). This led her to wonder if people might be doing the same thing. To take a closer look, her team studied 35 healthy people as they slept in the unfamiliar environment of the university's Department of Psychological Sciences. The participants each slept in the department for two nights and were carefully monitored with techniques that looked at the activity pf their brains. During deep sleep, the participants' brains behaved in a similar manner seen in birds and dolphins. On the first night only, the left hemispheres (半球) of their brains did not sleep nearly as deeply as their right hemispheres did.\nCurious id the left hemispheres were indeed remaining awake to process information detected in the surrounding environment, Dr. Sasaki re-ran the experiment while presenting the sleeping participants with a mix of regularly timed beeps (蜂鸣声) of the same tone and irregular beeps of a different tone during the night. She worked out that, if the left hemisphere was staying alert to keep guard in a strange environment, then it would react to the irregular beeps by stirring people from sleep and would ignore the regularly timed ones. This is precisely what she found.",
    "questions": [
      {
        "q": "What did researchers find puzzling about the first-night effect?",
        "options": [
          "To what extent it can trouble people.",
          "What role it has played in evolution.",
          "What circumstances may trigger it.",
          "In what way it can be beneficial."
        ],
        "answer": 3,
        "explain": "原文「The puzzle was that benefit would be gained from it when performance might be affected」，即不解之处在于它有什么好处，D 与之对应。A、B、C 均非原文所问的困惑点。"
      },
      {
        "q": "What do we learn about Dr. Yuka Sasaki doing her research?",
        "options": [
          "She found birds and dolphins remain alert while asleep.",
          "She found birds and dolphins sleep in much the same way.",
          "She got some idea from previous studies on birds and dolphins.",
          "She conducted studies on birds' and dolphins' sleeping patterns."
        ],
        "answer": 2,
        "explain": "原文「She also knew from previous work conducted on birds and dolphins...」，说明她的想法来自前人研究，C 正确。鸟类海豚「保持警觉、半脑睡眠」是既有认识，不是她的发现。"
      },
      {
        "q": "What did Dr. Sasaki do when she first did her experiment?",
        "options": [
          "She monitored the brain activity of participants sleeping in a new environment.",
          "She recruited 35 participants from her Department of Psychological Sciences.",
          "She studied the differences between the two sides of participants' brains.",
          "She tested her findings about birds and dolphins on human subjects."
        ],
        "answer": 0,
        "explain": "原文说团队让 35 人在陌生的心理科学系睡觉，「carefully monitored with techniques that looked at the activity of their brains」，A 是其概括。B 曲解招募地点，C、D 非首次实验内容。"
      },
      {
        "q": "What did Dr. Sasaki do when she re-ran the experiment?",
        "options": [
          "She analyzed the negative effect of irregular tones on brains.",
          "She recorded participants' adaptation to changed environment.",
          "She exposed her participants to two different stimuli.",
          "She compared the responses of different participants."
        ],
        "answer": 2,
        "explain": "重做实验时她给出两类声音刺激：定时同调蜂鸣与不定时异调蜂鸣，即两种不同刺激，C 对应。A、B、D 均与原文不符（原网页该题题干误排为上一题文字，此处按页面原始选项与官方答案保留）。"
      },
      {
        "q": "What did Dr. Sasaki find about the participants in her experiment?",
        "options": [
          "They tended to enjoy certain tones more than others.",
          "They tended to perceive irregular beeps as a threat.",
          "They felt sleepy when exposed to regular beeps.",
          "They differed in their tolerance of irregular tones."
        ],
        "answer": 1,
        "explain": "末句「This is precisely what she found」指向上一句：左脑警戒会把不规则蜂鸣当作危险而惊醒人，即被感知为威胁，B 正确。A、C、D 原文都没有依据。"
      }
    ],
    "keyWords": [
      {
        "w": "unfamiliar",
        "cn": "不熟悉的；陌生的"
      },
      {
        "w": "phenomenon",
        "cn": "现象"
      },
      {
        "w": "alert",
        "cn": "警觉的"
      },
      {
        "w": "predators",
        "cn": "捕食者"
      },
      {
        "w": "hemispheres",
        "cn": "（大脑）半球"
      },
      {
        "w": "beeps",
        "cn": "蜂鸣声"
      },
      {
        "w": "precisely",
        "cn": "恰恰；精确地"
      }
    ],
    "translation": "在陌生环境的陌生床上睡不好，被称为「首夜效应」。Brown 大学的 Yuka Sasaki 想弄清它的来源。她从鸟类和海豚「半脑睡眠、另一半保持警觉」的既有研究中获得启发，让 35 名健康被试在陌生的心理科学系各睡两晚并监测脑活动，发现只有第一晚左半球睡得不如右半球深。她随后重做实验，交替播放定时同调与不定时异调的蜂鸣声：若左脑在陌生环境中警戒，就会对不规则蜂鸣做出反应并把人惊醒——结果正是如此。"
  },
{
    "id": "cet4-2018-06-reading-1",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://m.hujiang.com/en/p1243184/",
    "verified": true,
    "type": "阅读理解",
    "title": "Green Spaces and Well-being (城市绿地带来持久幸福感)",
    "passage": "Living in an urban area with green spaces has a long-lasting positive impact on people's mental well-being, a study has suggested. UK researchers found moving to a green space had a sustained positive effect, unlike pay rises or promotions, which only provided a short-term boost. Co-author Mathew White, from the European Centre for Environment and Human Health at the University of Exeter, UK, explained that the study showed people living in greener urban areas were displaying fewer signs of depression or anxiety. \"There could be a number of reasons,\" he said, \"for example, people do many things to make themselves happier: they strive for promotion or pay rises, or they get married. But the trouble with all those things is that within six months to a year, people are back to their original baseline levels of well-being. So, these things are not sustainable; they don't make us happy in the long term.\"\nDr. White said his team wanted to see whether living in greener urban areas had a lasting positive effect on people's sense of well-being or whether the effect also disappeared after a period of time.\nExplaining what the data revealed, he said: \"What you see is that even after three years, mental health is still better, which is unlike many of the other things that we think will make us happy.\" He observed that people living in green spaces were less stressed, and less stressed people made more sensible decisions and communicated better.\nWith a growing body of evidence establishing a link between urban green spaces and a positive impact on human well-being, Dr. White said, \"There's growing interest among public policy officials, but the trouble is who funds it. What we really need at a policy level is to decide where the money will come from to help support good quality local green spaces.\"",
    "questions": [
      {
        "q": "According to one study, what do green spaces do to people?",
        "options": [
          "Improve their work efficiency.",
          "Add to their sustained happiness.",
          "Help them build a positive attitude towards life.",
          "Lessen their concerns about material well-being."
        ],
        "answer": 1,
        "explain": "开篇指出住在有绿地的城区对心理健康有「long-lasting positive impact」「sustained positive effect」，B 的 sustained happiness 与之对应。A、C、D 原文均未提及。"
      },
      {
        "q": "What does Dr. White say people usually do to make themselves happier?",
        "options": [
          "Earn more money.",
          "Gain fame and popularity.",
          "Settle in an urban area.",
          "Live in a green environment."
        ],
        "answer": 0,
        "explain": "原文说人们为更快乐会「strive for promotion or pay rises」，争取加薪即多赚钱，A 正确。B 的成名、C 的定居城区原文没有，D 是研究结论而非人们通常的做法。"
      },
      {
        "q": "What does Dr. White try to find out about living in a greener urban area?",
        "options": [
          "How it affects different people.",
          "How strong its effect is.",
          "How long its positive effect lasts.",
          "How it benefits physically."
        ],
        "answer": 2,
        "explain": "原文说团队想弄清这种影响是「lasting」还是过一段时间也消失，是问持续时间，C 正确。A、B、D 与「lasting / disappeared」这一疑问焦点不符。"
      },
      {
        "q": "What did Dr. White research reveal about people living in a green environment?",
        "options": [
          "Their stress was more apparent than real.",
          "Their decisions required less deliberation.",
          "Their memories were greatly strengthened.",
          "Their communication with others improved."
        ],
        "answer": 3,
        "explain": "原文「less stressed people made more sensible decisions and communicated better」，D 直接对应。A、B、C 均为无据推断（B 把 sensible decisions 曲解为不用深思）。"
      },
      {
        "q": "According to Dr. White, what should the government do to build more green spaces in cities?",
        "options": [
          "Find financial support.",
          "Improve urban planning.",
          "Involve local residents in the effort.",
          "Raise public awareness of the issue."
        ],
        "answer": 0,
        "explain": "末段说政策层面的难题是「who funds it」，需要决定钱从哪来，即落实资金支持，A 正确。B、C、D 原文均未涉及。"
      }
    ],
    "keyWords": [
      {
        "w": "urban",
        "cn": "城市的"
      },
      {
        "w": "well-being",
        "cn": "幸福；身心健康"
      },
      {
        "w": "sustained",
        "cn": "持续的"
      },
      {
        "w": "baseline",
        "cn": "基线；基准水平"
      },
      {
        "w": "stressed",
        "cn": "有压力的"
      },
      {
        "w": "sensible",
        "cn": "明智的"
      }
    ],
    "translation": "研究表明，居住在带绿地的城区对心理健康有长期积极影响。英国研究者发现，搬到绿地附近带来的正向效果能持续，而加薪或升职只提供短期提升：人们通常在半年到一年内就回到原来的幸福基线，所以这些并不「可持续」。团队用英国家庭面板调查数据发现，即使三年后心理健康仍更好。住在绿地的人压力更小，而压力小的人决策更明智、沟通也更好。White 博士说，政策层面的难题是谁来出资支持优质的地方绿地。"
  },
{
    "id": "cet4-2019-12-reading-1",
    "level": "cet4",
    "year": "2019年12月",
    "source": "http://www.hxen.com/CET46/CET4/yuedu/2019-12-14/528745.html",
    "verified": true,
    "type": "阅读理解",
    "title": "Philadelphia's Soda Tax (费城苏打税之争)",
    "passage": "The fifth largest city in the US passed a significant soda tax proposal that will levy (征税) 1.5 cents per liquid ounce on distributors.\nPhiladelphia's new measure was approved by a 13 to 4 city council vote. It sets a new bar for similar initiatives across the county. It is proof that taxes on sugary drinks can win substantial support outside super-liberal areas.\nThe tax will apply to regular and diet sodas, as well as other drinks with added sugar, such as Gatorade and iced teas.\nWhile the city council vote was met with applause inside the council room, opponents to the measure, including soda lobbyists made sharp criticisms and a promise to challenge the tax in court.\n\"The tax passed today unfairly singles out beverages, including low- and no-calorie choices,\" said Lauren Kane, spokeswoman for the American Beverage Association. \"But most importantly, it is against the law. So we will side with the majority of the people of Philadelphia who oppose this tax and take legal action to stop it.\"\nAn industry backed anti-tax campaign has spent at least $4 million on advertisements. The ads criticized the measure, characterizing it as a \"grocery tax.\"\nPublic health groups applauded the approved tax as a step toward fixing certain lasting health issues that plague Americans. \"The move to recapture a small part of the profits from an industry that pushes a product that contributes to diabetes, obesity and heart disease in poorer communities in order to reinvest in those communities will sure be inspirational to many other places,\" said Jim Krieger, executive director of Healthy Food America. \"Indeed, we are already hearing from some of them. It's not just Berkeley anymore.\"\nSimilar measures in California's Albany, Oakland, San Francisco and Colorado's Boulder are becoming hot-button issues. Health advocacy groups have hinted that even more might be coming.",
    "questions": [
      {
        "q": "What does the passage say about the newly-approved soda tax in Philadelphia?",
        "options": [
          "It will change the lifestyle of many consumers.",
          "It may encourage other US cities to follow suit.",
          "It will cut soda consumption among low-income communities.",
          "It may influence the marketing strategies of the soda business."
        ],
        "answer": 1,
        "explain": "原文「It sets a new bar for similar initiatives across the county」，为全国类似举措立了新标杆，即可能带动其他城市效仿，B 正确。A、C、D 原文均无依据。"
      },
      {
        "q": "What will the opponents probably do to respond to the soda tax proposal?",
        "options": [
          "Bargain with the city council.",
          "Refuse to pay additional tax.",
          "Take legal action against it.",
          "Try to win public support."
        ],
        "answer": 2,
        "explain": "反对者表态「we will side with the majority... and take legal action to stop it」，即诉诸法律，C 对应。A、B、D 与原文行动不符。"
      },
      {
        "q": "What did the industry-backed anti-tax campaign do about the soda tax proposal?",
        "options": [
          "It tried to arouse hostile feelings among consumers.",
          "It tried to win grocers' support against the measure.",
          "It kept sending letters of protest to the media.",
          "It criticized the measure through advertising."
        ],
        "answer": 3,
        "explain": "原文「has spent at least $4 million on advertisements. The ads criticized the measure」，即花钱做广告批评该税，D 正确。A、B、C 原文都没有提到。"
      },
      {
        "q": "What did public health groups think the soda tax would do?",
        "options": [
          "Alert people to the risk of sugar-induced diseases.",
          "Help people to fix certain long-time health issues.",
          "Add to the fund for their research on diseases.",
          "Benefit low-income people across the country."
        ],
        "answer": 1,
        "explain": "原文「Public health groups applauded the approved tax as a step toward fixing certain lasting health issues」，B 与之一致。A、C、D 曲解了征税用途与公共卫生团体的态度。"
      },
      {
        "q": "What do we learn about similar measures concerning the soda tax in some other cities?",
        "options": [
          "They are becoming rather sensitive issues.",
          "They are spreading panic in the soda industry.",
          "They are reducing the incidence of sugar-induced diseases.",
          "They are taking away lot of profit from the soda industry."
        ],
        "answer": 0,
        "explain": "末段「Similar measures in California's Albany, Oakland, San Francisco and Colorado's Boulder are becoming hot-button issues」，hot-button 即敏感、易起争议，A 正确。B、C、D 均无原文支撑。"
      }
    ],
    "keyWords": [
      {
        "w": "levy",
        "cn": "征收（税、费）"
      },
      {
        "w": "beverages",
        "cn": "饮料"
      },
      {
        "w": "opponents",
        "cn": "反对者"
      },
      {
        "w": "applauded",
        "cn": "称赞；鼓掌欢迎"
      },
      {
        "w": "plague",
        "cn": "困扰；折磨"
      },
      {
        "w": "obesity",
        "cn": "肥胖"
      }
    ],
    "translation": "美国第五大城市通过了一项重要的苏打税提案，将对经销商按每液体盎司 1.5 美分征税。费城的新举措以 13 比 4 在市议会通过，为全国类似举措树立了新标杆，也证明含糖饮料税能在非极端自由派地区赢得支持——此前只有加州伯克利成功实施过。该税涵盖普通与无糖汽水以及其他加糖饮料，预计五年筹集 4.1 亿美元，主要用于资助全市学前班。饮料业与说客强烈反对并扬言起诉；行业资助的反税宣传花掉至少 400 万美元做广告，把该税说成「食品杂货税」。公共卫生团体则称赞这是解决长期健康问题的一步。加州与科罗拉多多个城市的类似举措正成为敏感议题。"
  },
{
    "id": "cet4-2020-12-reading-1",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202012/11135020.html",
    "verified": true,
    "type": "阅读理解",
    "title": "Boredom: Not All Bad",
    "passage": "Boredom has, paradoxically, become quite interesting to academics lately. In early May, London’s Boring Conference celebrated seven years of delighting in dullness. At this event, people flocked to talks about weather, traffic jams and vending-machine sounds, among other sleep-inducing topics. What, exactly, is everybody studying? One widely accepted psychological definition of boredom is “the distasteful experience of wanting, but being unable, to engage in satisfying activity.” Boredom has been linked to behavior issues including inattentive driving, mindless snacking, excessive drinking, and addictive gambling. In fact, many of us would choose pain over boredom. One team of psychologists discovered that two-thirds of men and a quarter of women would rather self-administer electric shocks than sit alone with their thoughts for 15 minutes. Researching this phenomenon, another team asked volunteers to watch boring, sad, or neutral films, during which they could self-administer electric shocks. The bored volunteers shocked themselves more and harder than the sad or neutral ones did. But boredom isn’t all bad. By encouraging self-reflection and daydreaming, it can spur creativity. An early study gave participants abundant time to complete problem-solving and word-association exercises. Once all the obvious answers were exhausted, participants gave more and more incentive answers to combat boredom. A British study took these findings one step further, asking subjects to complete a creative challenge (coming up with a list of alternative uses for a household item). One group of subjects did a boring activity first, while the others went straight to the creative task. Those whose boredom pumps had been primed were more productive. In our always-connected world, boredom may be a hard-to-define state, but it is a fertile one. Watch paint dry or water boil, or at least put away your smartphone for a while, and you might unlock your next big idea.",
    "questions": [
      {
        "q": "When are people likely to experience boredom, according to an accepted psychological definition?",
        "options": [
          "When they don't have the chance to do what they want.",
          "When they don't enjoy the materials they are studying.",
          "When they experience something unpleasant.",
          "When they engage in some routine activities."
        ],
        "answer": 0,
        "explain": "原文把无聊定义为想做却无法投入令人满意的活动，即没有机会做想做的事；B、C、D 偏离该定义，属偷换概念或过度引申。"
      },
      {
        "q": "What does the author say boredom can lead to?",
        "options": [
          "Determination",
          "Concentration",
          "Mental deterioration",
          "Harmful conduct"
        ],
        "answer": 3,
        "explain": "原文说无聊与不良驾驶、盲目吃零食、酗酒、赌博等行为问题相关，属有害行为；A、B、C 三项在文中均无依据。"
      },
      {
        "q": "What is the finding of one team of psychologists in their experiment?",
        "options": [
          "Volunteers prefer watching a boring movie to sitting alone deliberating.",
          "Many volunteers choose to hurt themselves rather than endure boredom.",
          "Male volunteers are more immune to the effects of boredom than females.",
          "Many volunteers are unable to resist boredom longer than fifteen minutes."
        ],
        "answer": 1,
        "explain": "实验中三分之二男性和四分之一女性宁愿电击自己，也不愿独自静坐思考 15 分钟，即宁可自伤也不忍受无聊；A 把两组实验杂糅，C、D 与原文不符。"
      },
      {
        "q": "Why does the author say boredom isn't all bad?",
        "options": [
          "It stimulates memorization.",
          "It allows time for relaxation.",
          "It may promote creative thinking.",
          "It may facilitate independent learning."
        ],
        "answer": 2,
        "explain": "紧接'无聊并非全坏'之后，原文指出它能促进自我反思与白日梦，从而激发创造力，C 是 it can spur creativity 的同义改写；其余三项文中未提。"
      },
      {
        "q": "What does the author suggests one do when faced with a challenging problem?",
        "options": [
          "Stop idling and think big.",
          "Unlock one's smartphone.",
          "Look around oneself for stimulation.",
          "Allow oneself some time to be bored."
        ],
        "answer": 3,
        "explain": "末段建议放下手机、让自己一段时间无所事事，就可能解锁新想法，与 D 一致；A、B 与文意相反，C 属无中生有。"
      }
    ],
    "keyWords": [
      {
        "w": "boredom",
        "cn": "无聊，厌烦"
      },
      {
        "w": "paradoxically",
        "cn": "自相矛盾地"
      },
      {
        "w": "distasteful",
        "cn": "令人反感的，讨厌的"
      },
      {
        "w": "dullness",
        "cn": "乏味，枯燥"
      },
      {
        "w": "inattentive",
        "cn": "注意力不集中的"
      },
      {
        "w": "creativity",
        "cn": "创造力"
      },
      {
        "w": "fertile",
        "cn": "富有创造力的，丰饶的"
      }
    ]
  },
{
    "id": "cet4-2020-12-reading-2",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://cet4.koolearn.com/20201215/846621.html",
    "verified": true,
    "type": "阅读理解",
    "title": "The Greening of Western Forests",
    "passage": "Forests in countries like Brazil and the Congo get a lot of attention from environmentalists, and it is easy to see why. South America and sub-Saharan Africa are experiencing deforestation on an enormous scale: every year almost 5 million hectares are lost. But forests are also changing in rich Western countries. They are growing larger, both in the sense that they occupy more and that the trees in them and bigger. What is going on? Forests are spreading in almost all Western countries, with fastest growth in places that historically had rather few tress. In 1990 28% of Spain was forested; now the proportion is 37%. Forests are gradually taking more and in America and Australia. Perhaps most astonishing is the trend in Ireland. Roughly 1% of that country was forested when it became independent in 1922. Forests cover 11% of the land, and the government wants to push the proportion to 18% by the 2040s. Two things are fertilising this growth. The first is the abandonment of farmland, especially in high, dry places where nothing grows terribly well. When farmers give up trying to earn a living from farming or herding trees simply move in. The second is government policy and subsidy. Throughout history, governments have protected and promoted forests for diverse reasons, ranging from the need for wooden warships to a desire to promote suburban house-building. Nowadays forests are increasingly welcome because they suck in carbon pollution from the air. The justifications change; the desire for more trees remains constant. The greening of the West does not delight everyone. Farmers complain that land is being taken out of use by generously subsidised tree plantations. Others simply dislike the appearance of forests planted in neat rows. They will have to get used to the trees, however. The growth of Western forests seems almost as unstoppable as deforestation elsewhere.",
    "questions": [
      {
        "q": "What is catching environmentalists' attention nowadays?",
        "options": [
          "Rich countries are stripping poor ones of their resources.",
          "Forests are fast shrinking in many developing countries.",
          "Forests are eating away the fertile farmland worldwide.",
          "Rich countries are doing little to address deforestation."
        ],
        "answer": 1,
        "explain": "首段第二句指出南美与撒哈拉以南非洲每年流失近 500 万公顷森林，这才是吸引环保人士的原因，巴西、刚果均属发展中国家，故选 B；A、C、D 均无中生有。"
      },
      {
        "q": "Which countries have the fastest forest growth?",
        "options": [
          "Those that have newly achieved independence.",
          "Those that at have the greatest demand for timber",
          "Those that used to have the lowest forest coverage.",
          "Those that provide enormous government subsidies."
        ],
        "answer": 2,
        "explain": "第二段首句指出增长最快的是历史上树木极少的地方，C 中覆盖率最低与 rather few trees 同义；A、D 属个别词干扰。"
      },
      {
        "q": "What has encouraged forest growth historically?",
        "options": [
          "The government's advocacy.",
          "The use of wood for fuel.",
          "The favorable climate.",
          "The green movement."
        ],
        "answer": 0,
        "explain": "第三段给出两个原因：农田被撂荒与政府政策与补贴的推动，选项中只有政府的提倡与之对应，故选 A；B、C、D 文中均未提及。"
      },
      {
        "q": "What account for our increasing desire for forests?",
        "options": [
          "Their unique scenic beauty.",
          "Their use as fruit plantation.",
          "Their capability of improving air quality.",
          "Their stable supply of building materials."
        ],
        "answer": 2,
        "explain": "原文说森林如今越来越受欢迎，因为它们吸收空气中的碳污染，C'改善空气质量'与之同义；A、B、D 文中没有依据。"
      },
      {
        "q": "What does the author conclude about the prospects of forestation?",
        "options": [
          "Deserts in sub-Saharan Africa will diminish gradually.",
          "It will play a more and more important role in people's lives.",
          "Forest destruction in the developing world will quickly slow down.",
          "Developed and developing countries are moving in opposite direction."
        ],
        "answer": 3,
        "explain": "末段把西方森林扩张与其他地区难以遏制的森林砍伐并置对比，说明发达国家与发展中国家趋势相反，故选 D；A、B、C 与文意不符。"
      }
    ],
    "keyWords": [
      {
        "w": "deforestation",
        "cn": "森林砍伐"
      },
      {
        "w": "hectare",
        "cn": "公顷"
      },
      {
        "w": "forested",
        "cn": "被森林覆盖的"
      },
      {
        "w": "proportion",
        "cn": "比例"
      },
      {
        "w": "subsidy",
        "cn": "补贴"
      },
      {
        "w": "abandonment",
        "cn": "放弃，撂荒"
      },
      {
        "w": "carbon",
        "cn": "碳"
      }
    ]
  },
{
    "id": "cet4-sim-reading-1",
    "level": "cet4",
    "year": "仿真",
    "source": "自撰仿真题",
    "verified": false,
    "type": "阅读理解",
    "title": "Remote Work and the Changing City",
    "passage": "Remote work was once a rare privilege granted to a few employees. Today it has become an ordinary arrangement in many industries, and its effects reach far beyond the individual desk. Supporters argue that working from home saves commuting time, reduces the cost of office space and allows people to organize their day around their own rhythms. Employees who once spent two hours a day on buses and trains can now use that time for exercise, family or additional sleep, and companies can hire talented people who live far from their headquarters. Critics, however, point to problems that are less visible. When colleagues rarely meet, casual conversations disappear, and with them the small pieces of information that used to travel through corridors. New employees in particular may struggle to learn the culture of an organization they have never visited. Some studies also suggest that remote workers find it harder to switch off in the evening, because the boundary between the office and the living room has been erased. The most likely future is not a complete return to the office, nor a permanent escape from it. Many firms are experimenting with a mixed model in which employees come to the office two or three days a week for meetings and training, and work at home for tasks that demand concentration. What matters, researchers say, is that the arrangement is designed deliberately rather than allowed to happen by accident.",
    "questions": [
      {
        "q": "What benefit of remote work is mentioned in the first paragraph?",
        "options": [
          "It increases salaries for skilled workers.",
          "It saves time that used to be spent travelling.",
          "It makes promotion faster for young staff.",
          "It removes the need for staff training."
        ],
        "answer": 1,
        "explain": "首段明确说居家办公省下通勤时间（saves commuting time），还降低办公场地成本，B 与其对应；A、C、D 文中均未提及。"
      },
      {
        "q": "What problem do critics emphasize?",
        "options": [
          "The loss of informal communication among colleagues.",
          "The rising cost of home electricity.",
          "The shortage of skilled workers.",
          "The decline of public transport."
        ],
        "answer": 0,
        "explain": "第二段指出同事很少见面时，随意的交谈及其传递的细碎信息消失了，A 与此对应；其余三项原文均无依据。"
      },
      {
        "q": "Why do some remote workers find it hard to switch off in the evening?",
        "options": [
          "They are given more tasks than before.",
          "Their managers call them at night.",
          "The line between work and private life has become unclear.",
          "They have no proper equipment at home."
        ],
        "answer": 2,
        "explain": "原文说办公室与客厅的界限被抹去（the boundary ... has been erased），即工作与生活边界模糊，故选 C；A、B、D 属编造。"
      },
      {
        "q": "What model are many firms experimenting with?",
        "options": [
          "A complete return to the office.",
          "A mixed arrangement of office and home work.",
          "A four-day working week.",
          "A system of hourly pay."
        ],
        "answer": 1,
        "explain": "末段说许多公司在试行混合模式：每周到办公室两三天开会与培训，其余时间在家做需要专注的工作，故选 B。"
      },
      {
        "q": "What do researchers say is important?",
        "options": [
          "Keeping the arrangement as flexible as possible.",
          "Reducing the number of meetings.",
          "Measuring output rather than hours.",
          "Planning the arrangement on purpose."
        ],
        "answer": 3,
        "explain": "末句强调这种安排应当是刻意设计出来的，而不是无意中形成的，D 有意识地规划与之对应。"
      }
    ],
    "keyWords": [
      {
        "w": "commuting",
        "cn": "通勤"
      },
      {
        "w": "headquarters",
        "cn": "总部"
      },
      {
        "w": "corridor",
        "cn": "走廊"
      },
      {
        "w": "deliberately",
        "cn": "刻意地"
      },
      {
        "w": "arrangement",
        "cn": "安排"
      },
      {
        "w": "boundary",
        "cn": "界限"
      }
    ]
  },
{
    "id": "cet4-sim-reading-2",
    "level": "cet4",
    "year": "仿真",
    "source": "自撰仿真题",
    "verified": false,
    "type": "阅读理解",
    "title": "Sleep, Memory and Student Performance",
    "passage": "Students often treat sleep as the first thing they can give up when an examination approaches. Staying up late feels productive: the desk lamp is on, the notes are open and progress seems visible. Yet a growing body of research suggests that this trade is a poor one, because memory does not simply record what happens during the day; it also needs time to organize it. During deep sleep the brain replays the patterns of activity that were produced while learning. This replay strengthens the connections between nerve cells, which is why a fact studied in the evening is often recalled more easily the next morning. Sleep also appears to help people separate important information from noise, so that the essential idea survives while irrelevant details fade. Volunteers who sleep after practising a new skill perform better than those who practise for the same length of time and then stay awake. The practical advice that follows is unglamorous. Regular bedtimes matter more than total hours, and a short review of difficult material just before sleeping is more useful than an extra hour of late-night reading. Students who plan their revision around sleep, rather than against it, usually discover that they can study less and remember more.",
    "questions": [
      {
        "q": "Why do students often give up sleep before an examination?",
        "options": [
          "They cannot fall asleep because of stress.",
          "They are asked to study all night by teachers.",
          "They have no fixed timetable.",
          "They believe late-night study shows progress."
        ],
        "answer": 3,
        "explain": "首段说熬夜学习让人感觉有效率——台灯亮着、笔记摊开、进度似乎看得见，即他们认为熬夜能带来进展，故选 D。"
      },
      {
        "q": "What happens during deep sleep according to the passage?",
        "options": [
          "The brain stores new facts permanently.",
          "The brain repeats learning-related activity.",
          "The body temperature rises quickly.",
          "The brain removes unimportant memories forever."
        ],
        "answer": 1,
        "explain": "第二段第一句说深睡时大脑重放学习时产生的活动模式，B 是其同义改写；A、C、D 均属过度推断或无依据。"
      },
      {
        "q": "What did the experiment with volunteers show?",
        "options": [
          "Those who slept after practice performed better.",
          "Those who practised longer forgot more.",
          "Sleep had no measurable effect on skills.",
          "Practising in the morning was more effective."
        ],
        "answer": 0,
        "explain": "原文说练习新技能后睡觉的志愿者比练习同样时长却不睡的人表现更好，故选 A；B、C、D 与实验结果相反或无依据。"
      },
      {
        "q": "What does the author say about bedtimes?",
        "options": [
          "They should be decided by doctors.",
          "They matter less than study hours.",
          "A regular schedule is more important than long hours.",
          "They should change with the examination date."
        ],
        "answer": 2,
        "explain": "末段指出规律的作息比总时长更重要（Regular bedtimes matter more than total hours），故选 C；B 与原文相反。"
      },
      {
        "q": "What is the author's advice to students?",
        "options": [
          "Review all notes the night before the exam.",
          "Give up exercise during the exam period.",
          "Study only in the morning.",
          "Plan revision so that it works with sleep."
        ],
        "answer": 3,
        "explain": "末句说按睡眠来安排复习、而不是与睡眠对抗的学生往往能学得更少却记得更多，故选 D；A、B、C 均非作者建议。"
      }
    ],
    "keyWords": [
      {
        "w": "replay",
        "cn": "重放"
      },
      {
        "w": "nerve cell",
        "cn": "神经细胞"
      },
      {
        "w": "irrelevant",
        "cn": "无关的"
      },
      {
        "w": "unglamorous",
        "cn": "平淡无奇的"
      },
      {
        "w": "revision",
        "cn": "复习"
      },
      {
        "w": "recall",
        "cn": "回想起"
      }
    ]
  },
{
    "id": "cet6-2016-06-reading-1",
    "level": "cet6",
    "year": "2016年6月",
    "source": "https://zhuanlan.zhihu.com/p/258368609",
    "verified": true,
    "type": "阅读理解",
    "title": "绿色营销与联邦贸易委员会《绿色指南》修订",
    "passage": "Manufacturers of products that claim to be environmentally friendly will face tighter rules on how they are advertised to consumers under changes proposed by the Federal Trade Commission The commission's revised\"Green Guides\"warn marketers against using labels that make broad claims,like\"eco—friendly\".Marketers must qualify their claims on the product packaging and limit them to a specific benefit,such as how much of the product is recycled. The revisions come at a time when green marketing is on the rise.According to a new study,the number of advertisements with green messages in mainstream magazines has risen since 1987,and peaked in 2008 at 10.4%.In 2009,the number dropped to 9% In the last five years or so.there has been an explosion of green claims and environmental claims.It is clear that consumers don't always know what they are getting. A handful of lawsuits have been filed in recent years against companies accused of using misleading environmental labels.In 2008 and 2009,class-action lawsuits(集体诉讼)were filed against SC Johnson for using\"Greenlist\"labels on its cleaning products.The lawsuits said that the label was misleading because it gave the impression that the products had been certified by a third party when the certification was the company's own. \"We are very proud of our accomplishments under the Greenlist system and we believe that we will prevail in these cases,\"Christopher Beard,director of public affairs for SC Johnson,said,while acknowledging that\"this has been an area that is difficult to navigate.\" \"About once a week.I have a client that will bring up a new certification I've never even heard of and I'm in this industry,\"said Kevin Wilhelm.chief executive officer of Sustainable Business Consulting.\"It's kind of a Wild West.anybody can claim themselves to be green.\"Mr.Wilhelm said the excess of labels made it difficult for businesses and consumers to know which labels they should Pay attention to.",
    "questions": [
      {
        "q": "What do the revised\"Green Guides\"require businesses to do?",
        "options": [
          "A) Manufacture as many green products as possible.",
          "B) Indicate whether their products are recyclable.",
          "C) Specify in what way their products are green.",
          "D) Attach green labels to all of their products."
        ],
        "answer": 2,
        "explain": "第二段要求把宣传限定为具体益处(specific benefit)，C 的 Specify 与之一致；A、D 非指南要求，B 曲解可回收举例。"
      },
      {
        "q": "What does the author say about consumers facing an explosion of green claims?",
        "options": [
          "A) They can easily see through the businesses'tricks.",
          "B) They have to spend lots of time choosing products.",
          "C) They have doubt about current green certification.",
          "D) They are not clear which products are truly green."
        ],
        "answer": 3,
        "explain": "第六段称 consumers don't always know what they are getting，D 对应；A 与原文相反，B、C 文中无据。"
      },
      {
        "q": "What was SC Johnson accused of in the class-action lawsuits?",
        "options": [
          "A) It gave consumers the impression that all its products were truly green.",
          "B) It gave a third party the authority to label its products as environmentally friendly.",
          "C) It misled consumers to believe that its products had been certified by a third party.",
          "D) It sold cleaning products that were not included in the official\"Greenlist\"."
        ],
        "answer": 2,
        "explain": "第七段指标签让人误以为经第三方认证，C 对应 misled；A 扩大为全部产品，B 与原文相反，D 未提。"
      },
      {
        "q": "How did Christopher Beard defend his company's labeling practice?",
        "options": [
          "A) There were no clear guidelines concerning green labeling.",
          "B) His company's products had been well received by the public.",
          "C) It was in conformity to the prevailing practice in the market.",
          "D) No law required the involvement of a third party in certification."
        ],
        "answer": 0,
        "explain": "第八段 Beard 承认该领域 difficult to navigate，即缺乏明确指引，A 对应；B、C、D 均无原文依据。"
      },
      {
        "q": "What does Kevin Wilhelm imply by saying\"It's kind of a Wild West\"(Lines 2-3,Para.11)?",
        "options": [
          "A) Businesses compete to produce green products.",
          "B) Each business acts its own way in green labeling.",
          "C) Consumers grow wild with products labeled green.",
          "D) Anything produced in the West can be labeled green."
        ],
        "answer": 1,
        "explain": "第十一段 Wild West 后即 anybody can claim themselves to be green，B 对应各行其是；A、C、D 曲解字面义。"
      }
    ],
    "keyWords": [
      {
        "w": "environmentally friendly",
        "cn": "环保的"
      },
      {
        "w": "certification",
        "cn": "认证"
      },
      {
        "w": "misleading",
        "cn": "误导性的"
      },
      {
        "w": "lawsuit",
        "cn": "诉讼"
      },
      {
        "w": "green marketing",
        "cn": "绿色营销"
      },
      {
        "w": "recycled",
        "cn": "回收利用的"
      },
      {
        "w": "navigate",
        "cn": "应对，驾驭"
      }
    ]
  },
{
    "id": "cet6-2017-12-reading-1",
    "level": "cet6",
    "year": "2017年12月",
    "source": "https://m.ygjj.com/xa/Home/DetailArticle?articleId=452457",
    "verified": true,
    "type": "阅读理解",
    "title": "机器人伦理、阿西莫夫三定律与决策难题",
    "passage": "In the beginning of the movie I, Robot, a robot has to decide whom to save after two cars plunge into the water—Del Spooner or a child. The robot's decision and its calculated approach raise an important question: would humans make the same choice? And which choice would we want our robotic counterparts to make? Isaac Asimov evaded the whole notion of morality in devising his three laws of robotics, which hold that 1. Robots cannot harm humans or allow humans to come to harm; 2. Robots must obey humans, except where the order would conflict with law 1; and 3. Robots must act in self-preservation, unless doing so conflicts with laws 1 or 2. These laws are programmed into Asimov's robots—they don't have to think, judge, or value. They simply don't do it. Whether it's possible to program a robot with safeguards such as Asimov's laws is debatable. A word such as \"harm\" is vague (what about emotional harm? Is replacing a human employee harm?), and abstract concepts present coding problems. The robots in Asimov's fiction expose complications and loopholes in the three laws, and even when the laws work, robots still have to assess situations. Assessing situations can be complicated. It's doubtful that a computer program can do that—at least, not without some undesirable results. A roboticist at the Bristol Robotics Laboratory programmed a robot to save human proxies (替身) called \"H-bots\" from danger. When one H-bot headed for danger, the robot successfully pushed it out of the way. But when two H-bots became imperiled, the robot chocked 42 percent of the time, unable to decide which to save and letting them both \"die.\" The experiment highlights the importance of morality: without it, how can a robot decide whom to save or what's best for humanity, especially if it can't calculate survival odds?",
    "questions": [
      {
        "q": "What question does the example in the movie raise?",
        "options": [
          "A) Whether robots can reach better decisions.",
          "B) Whether robots follow Asimov's zeroth law.",
          "C) How robots may make bad judgments.",
          "D) How robots should be programmed."
        ],
        "answer": 0,
        "explain": "首段末以机器人抉择引出人类会否同样选择、希望机器人怎么选，即能否作更好判断，A 对应；B、C、D 非首段设问。"
      },
      {
        "q": "What does the author think of Asimov's three laws of robotics?",
        "options": [
          "A) They are apparently divorced from reality.",
          "B) They did not follow the coding system of robotics.",
          "C) They laid a solid foundation for robotics.",
          "D) They did not take moral issues into consideration."
        ],
        "answer": 3,
        "explain": "第二段说 Asimov 制定三定律时 evaded the whole notion of morality，D 对应绕开道德；A、B、C 非作者观点。"
      },
      {
        "q": "What does the author say about Asimov's robots?",
        "options": [
          "A) They know what is good or bad for human beings.",
          "B) They are programmed not to hurt human beings.",
          "C) They perform duties in their owners' best interest.",
          "D) They stop working when a moral issue is involved."
        ],
        "answer": 2,
        "explain": "第三段列出机器人须服从人类，即按主人利益履职，C 对应 obey humans；A 与 don't have to judge 矛盾，B、D 无据。"
      },
      {
        "q": "What does the author want to say by mentioning the word \"harm\" in Asimov's laws?",
        "options": [
          "A) Abstract concepts are hard to program.",
          "B) It is hard for robots to make decisions.",
          "C) Robots may do harm in certain situations.",
          "D) Asimov's laws use too many vague terms."
        ],
        "answer": 0,
        "explain": "第四段指 harm 一词含糊、abstract concepts 带来编码难题，A 对应；B、C、D 非此处论点。"
      },
      {
        "q": "What has the roboticist at the Bristol Robotics Laboratory found in his experiment?",
        "options": [
          "A) Robots can be made as intelligent as human beings some day.",
          "B) Robots can have moral issues encoded into their programs.",
          "C) Robots can have trouble making decisions in complex scenarios.",
          "D) Robots can be programmed to perceive potential perils."
        ],
        "answer": 2,
        "explain": "第五段实验里机器人对两个受困替身有 42% 情况无法抉择，C 对应复杂情境难决策；A、B、D 与实验不符。"
      }
    ],
    "keyWords": [
      {
        "w": "morality",
        "cn": "道德"
      },
      {
        "w": "self-preservation",
        "cn": "自我保护"
      },
      {
        "w": "safeguards",
        "cn": "保障措施"
      },
      {
        "w": "loopholes",
        "cn": "漏洞"
      },
      {
        "w": "vague",
        "cn": "含糊的"
      },
      {
        "w": "assess",
        "cn": "评估"
      },
      {
        "w": "imperiled",
        "cn": "陷入危险的"
      }
    ]
  },
{
    "id": "cet6-2017-12-reading-3",
    "level": "cet6",
    "year": "2017年12月",
    "source": "https://m.ygjj.com/xa/Home/DetailArticle?articleId=452456",
    "verified": true,
    "type": "阅读理解",
    "title": "物联网、智能家居与智慧城市",
    "passage": "Our world now moves so fast that we seldom stop to see just how far we have come in just a few years. The latest iPhone 6s, for example, has a dual-core processor and fits nicely into your pocket. By comparison, you would expect to find a technological specification like this on your standard laptop in an office anywhere in the world. All researched agree that close to 25 billion devices, things and sensors will be connected by 2020 which incidentally is also the moment that Millennials（千禧一代） are expected to make up 75 percent of our overall workforce, and the fully connected home will become a reality for large numbers of people worldwide. However, this is just the tip of the proverbial iceberg as smart buildings and even cities increasingly become the norm as leaders and business owners begin to wake up to the massive savings that technology can deliver through connected sensors and new forms of automation coupled with intelligent energy and facilities management. Online security cameras, intelligent lighting and a wealth of sensors that control both temperature and air quality are offering an unprecedented level of control, efficiency, and improvements to what were once classed necessary costs when running a business or managing a large building. The biggest and most exciting challenge of this technology is how to creatively leverage this ever-growing amount data do deliver cost savings, improvements and tangible benefits to both businesses and citizens of these smart cities. The good news is that most of this technology is already invented. Let's face it, it wasn't too long ago that the idea of working from anywhere and at anytime was some form of a distant utopian（乌托邦式的） dream, and yet now we can perform almost any office-based task from any location in the world as long as we have access to the internet.",
    "questions": [
      {
        "q": "What does the example of iPhone 6s serve to show?",
        "options": [
          "A) The huge capacity of the smartphones people now use.",
          "B) The widespread use of smartphones all over the world.",
          "C) The huge impact of new technology on people's everyday life.",
          "D) The rapid technological progress in a very short period of time."
        ],
        "answer": 3,
        "explain": "首段以 iPhone 6s 说明昔日笔记本级配置如今入袋，例证技术短期飞跃，D 对应；A、B、C 均非该例中心。"
      },
      {
        "q": "What can we expect to see by the year 2020?",
        "options": [
          "A) Apps for the Internet of Things.",
          "B) The popularization of smart homes.",
          "C) The emergence of Millennials.",
          "D) Total globalization of the world."
        ],
        "answer": 1,
        "explain": "第三段称 2020 年 fully connected home 将对大量人成真，B 对应智能家居普及；A 是条件，C 是背景，D 无据。"
      },
      {
        "q": "What will business owners do when they become aware of the benefits of the Internet of Things?",
        "options": [
          "A) Employ fewer workers in their operations.",
          "B) Gain automatic control of their businesses.",
          "C) Invest in more smart buildings and cities.",
          "D) Embrace whatever new technology there is."
        ],
        "answer": 1,
        "explain": "第四五段称企业主因传感器与自动化获得空前 control 与效率，B 对应自动掌控；A、D 无据，C 是结果。"
      },
      {
        "q": "What is the most exciting challenge when we possess more and more data?",
        "options": [
          "A) How to turn it to profitable use.",
          "B) How to do real time data analysis.",
          "C) How to link the actionable systems.",
          "D) How to devise new ways to store it."
        ],
        "answer": 0,
        "explain": "第七段问如何创造性地 leverage 数据以带来成本节约与实益，A 对应转化为有利用途；B 已实现，C、D 无据。"
      },
      {
        "q": "What does the author think about working from anywhere and at anytime?",
        "options": [
          "A) It is feasible with a connection to the internet.",
          "B) It will thrive in smart buildings, cities and homes.",
          "C) It is still a distant utopian dream for ordinary workers.",
          "D) It will deliver tangible benefits to both boss and worker."
        ],
        "answer": 0,
        "explain": "第八段称只要接入互联网即可在世界任何地点办公，A 对应可行；C 与原文相反，B、D 无原文支持。"
      }
    ],
    "keyWords": [
      {
        "w": "dual-core",
        "cn": "双核的"
      },
      {
        "w": "sensors",
        "cn": "传感器"
      },
      {
        "w": "automation",
        "cn": "自动化"
      },
      {
        "w": "unprecedented",
        "cn": "前所未有的"
      },
      {
        "w": "leverage",
        "cn": "利用，撬动"
      },
      {
        "w": "efficiency",
        "cn": "效率"
      },
      {
        "w": "utopian",
        "cn": "乌托邦式的"
      }
    ]
  },
{
    "id": "cet6-2019-06-reading-1",
    "level": "cet6",
    "year": "2019年6月",
    "source": "http://www.hxen.com/CET46/CET6/zhenti/2020-03-01/532372_3.html",
    "verified": true,
    "type": "阅读理解",
    "title": "霍金谈人工智能：最好的事或最坏的事",
    "passage": "Professor Stephen Hawking has warned that the creation of powerful artificial intelligence (AI) will be \"either the best, or the worst thing, ever to happen to humanity\", and praised the creation of an academic institute dedicated to researching the future of intelligence as \"crucial to the future of our civilisation and our species\". Hawking was speaking at the opening of the Leverhulme Centre for the Future of Inteelgence (LCFI) at Cambridge University, a multi-disciplinary institute that will attempt to tackle some of the open-ended questions raised by the rapid pace of development in AI research. \"We spend a great deal of time studying history,\" Hawking said, \"which, let's face it, is mostly the history of stupidity. So it's a welcome change that people are studying instead the future of intelligence.\" While the world-renowned physicist has often been cautious about AI, rising concerns that humanity could be the architect of its own destruction if it creates a super-intelligence with a will of its own, he was also quick to highlight the positives that AI research can bring. \"The potential benefits of creating intelligence are huge,\" he said. \"We cannot predict what we might achieve when our own minds are amplified by AI. Perhaps with the tools of this new technological revolution, we will be able to undo some of the damage done to the natural world by the last one—industrialisation. In short, success in creating AI could be the biggest event in the history of our civilisation.\" The academic community is not alone in warning about the potential dangers of AI as well as the potential benefits. A number of pioneers from the technology industry, most famously the entrepreneur Elon Musk, have also expressed their concerns about the damage that a super-intelligent AI could do to humanity.",
    "questions": [
      {
        "q": "What did Stephen Hawking think of artificial intelligence?",
        "options": [
          "A) It would be vital to the progress of human civilisation.",
          "B) It might be a blessing or a disaster in the making.",
          "C) It might present challenges as well as opportunities.",
          "D) It would be a significant expansion of human intelligence."
        ],
        "answer": 1,
        "explain": "首句称 AI 是 either the best, or the worst thing，B 对应福祸相依；A 讲研究所，C 语气过轻，D 非其判断。"
      },
      {
        "q": "What did Hawking say about the creation of the LCFI?",
        "options": [
          "A) It would accelerate the progress of AI research.",
          "B) It would mark a step forward in the AI industry.",
          "C) It was extremely important to the destiny of humankind.",
          "D) It was an achievement of multi-disciplinary collaboration."
        ],
        "answer": 2,
        "explain": "首段末霍金称该研究所 crucial to the future of our civilisation，C 对应关乎人类命运；A、B、D 非原话含义。"
      },
      {
        "q": "What did Hawking say was a welcome change in AI research?",
        "options": [
          "A) The shift of research focus from the past to the future.",
          "B) The shift of research from theory to implementation.",
          "C) The greater emphasis on the negative impact of AI.",
          "D) The increasing awareness of mankind's past stupidity."
        ],
        "answer": 0,
        "explain": "第二段称人们转而研究未来智能是 a welcome change，A 对应重心由过去转向未来；B、C、D 无原文支撑。"
      },
      {
        "q": "What concerns did Hawking raise about AI?",
        "options": [
          "A) It may exceed human intelligence sooner or later.",
          "B) It may ultimately over-amplify the human mind.",
          "C) Super-intelligence may cause its own destruction.",
          "D) Super-intelligence may eventually ruin mankind."
        ],
        "answer": 3,
        "explain": "第三段称若造出 a super-intelligence with a will of its own，人类或自毁，D 对应；A、B、C 均非其忧虑。"
      },
      {
        "q": "What do we learn about some entrepreneurs from the technology industry?",
        "options": [
          "A) They are much influenced by the academic community.",
          "B) They are most likely to benefit from AI development.",
          "C) They share the same concerns about AI as academics.",
          "D) They believe they can keep AI under human control."
        ],
        "answer": 2,
        "explain": "末段称科技界先驱如 Elon Musk 亦有同样担忧，C 对应；A、B、D 文中均未提及。"
      }
    ],
    "keyWords": [
      {
        "w": "artificial intelligence",
        "cn": "人工智能"
      },
      {
        "w": "civilisation",
        "cn": "文明"
      },
      {
        "w": "humanity",
        "cn": "人类"
      },
      {
        "w": "amplified",
        "cn": "被放大的"
      },
      {
        "w": "super-intelligence",
        "cn": "超级智能"
      },
      {
        "w": "industrialisation",
        "cn": "工业化"
      },
      {
        "w": "multi-disciplinary",
        "cn": "多学科的"
      }
    ]
  },
{
    "id": "cet4-2022-06-reading-1",
    "level": "cet4",
    "year": "2022年6月",
    "source": "https://archive.org/download/cet46collect/四级仔细阅读202206-今_djvu.txt",
    "verified": true,
    "type": "阅读理解",
    "title": "社交媒体与员工留存 (Social media and employee retention)",
    "passage": "Social media can be a powerful communication tool for employees, helping them to collaborate, share ideas and solve problems. Research has shown that 82% of employees think social media can improve work relationships and 60% believe it can support decision-making processes.\n\nEmployers typically worry that social media is a productivity killer; more than half of U.S. employers reportedly block access to social media at work. In my research with 277 employees of a healthcare organization I found these concerns to be misguided. Social media doesn't reduce productivity nearly as much as it kills employee retention.\n\nIn the first part of the study, I surveyed the employees about why and how they used platforms like Facebook, Twitter, or LinkedIn. Respondents were then asked about their work behaviors, including whether they felt motivated in their jobs and showed initiative at work. I found that employees who engage in online social interactions with coworkers through social media blogs tend to be more motivated and come up with innovative ideas. But when employees interact with individuals outside the organization, they are less motivated and show less initiative.\n\nIn the second part of the study, I found 76% of employees using social media for work took an interest in other organizations they found on social media. When I examined how respondents expressed openness to new careers and employers, I found that they engaged in some key activities including researching new organizations and making new work connections.\n\nThese findings present a dilemma for managers: employees using social media at work are more engaged and more productive, but they are also more likely to leave your company. Managers should implement solutions that neutralize the retention risk caused by social media.\n\nManagers can use social media to directly reduce turnover intentions by recognizing employees' accomplishments and giving visibility to employees' success stories.",
    "questions": [
      {
        "q": "What does previous research about social media reveal?",
        "options": [
          "Most employees think positively of it.",
          "It improves employees' work efficiency.",
          "It enables employees to form connections.",
          "Employees spend much of their work time on it."
        ],
        "answer": 0,
        "explain": "首段引用研究数据：82% 员工认为社媒能改善工作关系、60% 认为有助决策，可见多数员工对其持肯定态度，故选 A。B、C、D 均非该段数据所支持。"
      },
      {
        "q": "What did the author's own research find about social media?",
        "options": [
          "It influences employees' work negatively.",
          "It does much harm to employee loyalty.",
          "It kills employees' motivation for work.",
          "It affects employers' decision-making."
        ],
        "answer": 1,
        "explain": "第二段原句「Social media doesn't reduce productivity nearly as much as it kills employee retention」，即它对员工留存的伤害远大于对效率的影响，B 对应。A、C 与作者否定的担忧混同，D 无据。"
      },
      {
        "q": "What did the author find in his study about the effect of online social interactions?",
        "options": [
          "It differs from employee to employee.",
          "It tends to vary with the platform used.",
          "It has much to do with whom employees interact with.",
          "It is hard to measure when employees interact with outsiders."
        ],
        "answer": 2,
        "explain": "第三段对比：与同事线上互动者更有动力、更有创意，而与组织外人士互动者动力与主动性反而下降，说明效果取决于互动的对象，C 对应。"
      },
      {
        "q": "What problem was found with employees using social media for work?",
        "options": [
          "They seldom expressed their inner thoughts.",
          "Most of them explored new job opportunities.",
          "They were reluctant to collaborate with others.",
          "Many of them ended with lower productivity."
        ],
        "answer": 1,
        "explain": "第四段指出 76% 用社媒办公的员工对社媒上发现的其他组织产生兴趣，并研究新组织、建立新的工作联系，即寻找新机会，B 对应。D 与作者结论相反。"
      },
      {
        "q": "What does the author suggest managers do to neutralize the retention risk?",
        "options": [
          "Give promotions to employees for their accomplishments.",
          "Create opportunities for employees to share success stories.",
          "Acknowledge employees' achievements through social media.",
          "Encourage employees to increase their visibility on social media."
        ],
        "answer": 2,
        "explain": "末段建议管理者用社媒「recognizing employees' accomplishments and giving visibility to employees' success stories」以降低离职意愿，C 对应。A 的「升职」原文未提。"
      }
    ],
    "keyWords": [
      {
        "w": "collaborate",
        "cn": "合作，协作"
      },
      {
        "w": "retention",
        "cn": "留存，保留"
      },
      {
        "w": "initiative",
        "cn": "主动性，进取心"
      },
      {
        "w": "turnover",
        "cn": "人员流动；营业额"
      },
      {
        "w": "neutralize",
        "cn": "抵消，中和"
      },
      {
        "w": "dilemma",
        "cn": "两难境地"
      },
      {
        "w": "visibility",
        "cn": "可见度，曝光度"
      }
    ],
    "translation": "社交媒体可以成为员工强大的沟通工具，帮助他们协作、交流想法和解决问题。研究显示，82% 的员工认为社交媒体能改善工作关系，60% 认为它有助于决策。雇主通常担心社交媒体是效率杀手，据称超过一半的美国雇主禁止在工作时访问社交媒体。我对一家医疗机构 277 名员工的研究发现，这些担忧是错位的：社交媒体对效率的削弱远不及它对员工留存的伤害。研究第一部分中，我调查了员工使用 Facebook、Twitter 或 LinkedIn 等平台的动机与方式，随后询问其工作行为。我发现，通过社交媒体与同事进行线上互动的员工往往更有动力、更有创意；但与组织外的人互动时，他们的动力和主动性反而更低。研究第二部分发现，76% 用社交媒体办公的员工对平台上发现的其他组织产生了兴趣，并开始研究新组织、建立新的工作联系。这些发现让管理者两难：上班用社媒的员工更投入、更高产，但也更容易离开公司。管理者应采取措施抵消社媒带来的留存风险，例如建立社媒群组促使员工协作、减少议论外部工作机会，并通过社媒表彰员工成就、宣传其成功故事来直接降低离职意愿。"
  }
];
