window.TRANSLATION_BANK = [
  {
    "id": "cet4-culture-tea",
    "level": "cet4",
    "year": "风格参照 2023 年 6 月",
    "topic": "传统文化",
    "title": "茶文化",
    "source": "茶是中国最受欢迎的饮品之一。中国人饮茶的历史可以追溯到几千年前。茶不仅是一种饮料，也是一种文化。如今，越来越多的年轻人开始学习茶艺。他们通过品茶来了解传统，也让自己慢下来。每年春天，许多游客会去南方茶园参观。",
    "sentences": [
      {
        "cn": "茶是中国最受欢迎的饮品之一。",
        "ref": "Tea is one of the most popular drinks in China.",
        "points": [
          "固定句型 one of the most popular + 名词复数",
          "drinks 用复数，不能写成 drink"
        ]
      },
      {
        "cn": "中国人饮茶的历史可以追溯到几千年前。",
        "ref": "The history of tea drinking in China can be traced back thousands of years.",
        "points": [
          "「追溯到」用 can be traced back to / date back to",
          "主语是 the history，谓语用被动"
        ]
      },
      {
        "cn": "茶不仅是一种饮料，也是一种文化。",
        "ref": "Tea is not only a kind of drink, but also a culture.",
        "points": [
          "not only ... but also ... 并列结构",
          "两句共用一个系动词 is，后句不重复"
        ]
      },
      {
        "cn": "如今，越来越多的年轻人开始学习茶艺。",
        "ref": "Nowadays, more and more young people are beginning to learn the art of tea.",
        "points": [
          "more and more + 名词复数",
          "「茶艺」译 the art of tea / tea ceremony"
        ]
      },
      {
        "cn": "他们通过品茶来了解传统，也让自己慢下来。",
        "ref": "By tasting tea, they learn about tradition and also slow themselves down.",
        "points": [
          "by + 动名词表方式",
          "「慢下来」用 slow oneself down，注意反身代词"
        ]
      },
      {
        "cn": "每年春天，许多游客会去南方茶园参观。",
        "ref": "Every spring, many tourists visit tea gardens in the south.",
        "points": [
          "「茶园」译 tea gardens / tea plantations",
          "时间状语置于句首，主句用一般现在时"
        ]
      }
    ],
    "reference": "Tea is one of the most popular drinks in China. The history of tea drinking in China can be traced back thousands of years. Tea is not only a kind of drink, but also a culture. Nowadays, more and more young people are beginning to learn the art of tea. By tasting tea, they learn about tradition and also slow themselves down. Every spring, many tourists visit tea gardens in the south.",
    "keyWords": [
      {
        "w": "beverage",
        "cn": "饮品；饮料"
      },
      {
        "w": "trace back to",
        "cn": "追溯到"
      },
      {
        "w": "the art of tea",
        "cn": "茶艺"
      },
      {
        "w": "tea garden",
        "cn": "茶园"
      },
      {
        "w": "tradition",
        "cn": "传统"
      },
      {
        "w": "slow down",
        "cn": "放慢；慢下来"
      },
      {
        "w": "tourist",
        "cn": "游客"
      }
    ],
    "scoring": [
      "内容完整：六句要点全部译出，「之一」「追溯到」等关键信息不漏",
      "语言准确：主谓一致、单复数与冠词使用正确",
      "表达流畅：句间衔接自然，避免逐字硬译",
      "用词地道：被动语态与固定搭配使用恰当"
    ],
    "pitfalls": [
      "漏译「之一」，写成 Tea is the most popular drink in China",
      "「追溯到」误译为 goes back to，忽略 can be traced back 的被动结构",
      "漏掉 not only ... but also 结构，两句简单并列",
      "冠词缺失或多余：a kind of drink 中冠词漏写"
    ]
  },
  {
    "id": "cet4-transport-hsr",
    "level": "cet4",
    "year": "风格参照 2022 年 12 月",
    "topic": "交通发展",
    "title": "中国高铁",
    "source": "过去十年间，中国的高速铁路发展迅速。如今，高铁已成为许多人出行的首选。它把原本十几个小时的旅程缩短到几个小时。高铁不仅方便了人们的出行，也促进了地区之间的交流。在一些城市，高铁站附近建起了新的商业区。未来，中国的高铁网络还将继续扩大。",
    "sentences": [
      {
        "cn": "过去十年间，中国的高速铁路发展迅速。",
        "ref": "Over the past decade, China's high-speed railway has developed rapidly.",
        "points": [
          "over the past + 时间段，主句用现在完成时",
          "「迅速发展」用 develop rapidly"
        ]
      },
      {
        "cn": "如今，高铁已成为许多人出行的首选。",
        "ref": "Today, high-speed trains have become the first choice for many travelers.",
        "points": [
          "「已成为」用 have become",
          "「首选」译 the first choice for"
        ]
      },
      {
        "cn": "它把原本十几个小时的旅程缩短到几个小时。",
        "ref": "It has shortened a journey of more than ten hours to just a few hours.",
        "points": [
          "shorten ... to ... 把……缩短到……",
          "「十几个小时」译 more than ten hours"
        ]
      },
      {
        "cn": "高铁不仅方便了人们的出行，也促进了地区之间的交流。",
        "ref": "High-speed rail not only makes travel easier, but also promotes communication between regions.",
        "points": [
          "not only ... but also 并列两个谓语，时态保持一致",
          "「地区之间」用 between regions"
        ]
      },
      {
        "cn": "在一些城市，高铁站附近建起了新的商业区。",
        "ref": "In some cities, new business districts have been built near high-speed railway stations.",
        "points": [
          "「建起了」用被动语态 have been built",
          "地点状语前置，注意逗号后主句完整"
        ]
      },
      {
        "cn": "未来，中国的高铁网络还将继续扩大。",
        "ref": "In the future, China's high-speed rail network will continue to expand.",
        "points": [
          "一般将来时 will continue to do",
          "「扩大」用 expand / be further extended"
        ]
      }
    ],
    "reference": "Over the past decade, China's high-speed railway has developed rapidly. Today, high-speed trains have become the first choice for many travelers. It has shortened a journey of more than ten hours to just a few hours. High-speed rail not only makes travel easier, but also promotes communication between regions. In some cities, new business districts have been built near high-speed railway stations. In the future, China's high-speed rail network will continue to expand.",
    "keyWords": [
      {
        "w": "high-speed railway",
        "cn": "高速铁路"
      },
      {
        "w": "the first choice",
        "cn": "首选"
      },
      {
        "w": "shorten",
        "cn": "缩短"
      },
      {
        "w": "promote",
        "cn": "促进"
      },
      {
        "w": "communication",
        "cn": "交流；沟通"
      },
      {
        "w": "business district",
        "cn": "商业区"
      },
      {
        "w": "expand",
        "cn": "扩大"
      }
    ],
    "scoring": [
      "内容完整：六句要点齐全，时间与数量信息无遗漏",
      "语言准确：现在完成时、被动语态与将来时使用正确",
      "表达流畅：not only ... but also 等连接结构自然",
      "拼写规范：high-speed、railway 等专有表达书写正确"
    ],
    "pitfalls": [
      "时态混乱：「过去十年间」误用一般过去时描述持续至今的变化",
      "漏译「首选」，简单写成 become popular",
      "单复数错误：ten hour 未加 s，写成 ten hours 才对",
      "冠词缺失：the first choice 中的定冠词被漏掉"
    ]
  },
  {
    "id": "cet4-craft-papercutting",
    "level": "cet4",
    "year": "风格参照 2023 年 6 月",
    "topic": "传统手工艺",
    "title": "剪纸",
    "source": "剪纸是中国最古老的民间艺术之一。人们用剪刀或小刀在纸上剪出各种图案。这些图案常常表达人们对幸福生活的向往。过年时，很多家庭会把剪纸贴在窗户上。如今，一些年轻人把剪纸与现代设计结合起来。这门手艺正在以新的方式传承下去。",
    "sentences": [
      {
        "cn": "剪纸是中国最古老的民间艺术之一。",
        "ref": "Paper-cutting is one of the oldest folk arts in China.",
        "points": [
          "one of the + 最高级 + 名词复数",
          "「剪纸」译 paper-cutting，作不可数名词用"
        ]
      },
      {
        "cn": "人们用剪刀或小刀在纸上剪出各种图案。",
        "ref": "People use scissors or small knives to cut various patterns out of paper.",
        "points": [
          "use sth to do sth 表工具",
          "「各种」用 various / all kinds of"
        ]
      },
      {
        "cn": "这些图案常常表达人们对幸福生活的向往。",
        "ref": "These patterns often express people's longing for a happy life.",
        "points": [
          "longing for 表「对……的向往」，后接名词",
          "「幸福生活」译 a happy life，注意冠词"
        ]
      },
      {
        "cn": "过年时，很多家庭会把剪纸贴在窗户上。",
        "ref": "During the Spring Festival, many families put paper-cuttings on their windows.",
        "points": [
          "时间状语用 during the Spring Festival",
          "put ... on ...，注意复数 families"
        ]
      },
      {
        "cn": "如今，一些年轻人把剪纸与现代设计结合起来。",
        "ref": "Nowadays, some young people combine paper-cutting with modern design.",
        "points": [
          "combine A with B 固定搭配",
          "design 此处为不可数名词，不加冠词"
        ]
      },
      {
        "cn": "这门手艺正在以新的方式传承下去。",
        "ref": "This craft is being passed down in new ways.",
        "points": [
          "现在进行时的被动语态 is being passed down",
          "pass down 表「传承」，介词用 in new ways"
        ]
      }
    ],
    "reference": "Paper-cutting is one of the oldest folk arts in China. People use scissors or small knives to cut various patterns out of paper. These patterns often express people's longing for a happy life. During the Spring Festival, many families put paper-cuttings on their windows. Nowadays, some young people combine paper-cutting with modern design. This craft is being passed down in new ways.",
    "keyWords": [
      {
        "w": "paper-cutting",
        "cn": "剪纸"
      },
      {
        "w": "folk art",
        "cn": "民间艺术"
      },
      {
        "w": "scissors",
        "cn": "剪刀"
      },
      {
        "w": "pattern",
        "cn": "图案"
      },
      {
        "w": "longing for",
        "cn": "对……的向往"
      },
      {
        "w": "combine ... with ...",
        "cn": "把……与……结合起来"
      },
      {
        "w": "pass down",
        "cn": "传承；传下去"
      }
    ],
    "scoring": [
      "内容完整：材料、图案寓意、贴窗花、创新传承等要点均有体现",
      "语言准确：被动语态与固定搭配（combine with, pass down）正确",
      "表达流畅：语义层次清楚，句子间有顺承关系",
      "用词得体：folk arts、craft、pattern 等文化词选用恰当"
    ],
    "pitfalls": [
      "漏译「之一」或把 one of the oldest 写成 the oldest",
      "搭配错误：combine paper-cutting to modern design（应把 to 改为 with）",
      "可数名词误用：把 scissors、paper-cutting 随意加复数 s",
      "时态错误：描述正在发生的变化未用现在进行时或现在完成时"
    ]
  },
  {
    "id": "cet4-festival-springfestival",
    "level": "cet4",
    "year": "风格参照 2021 年 12 月",
    "topic": "社会生活",
    "title": "春节返乡",
    "source": "春节是中国最重要的传统节日。每年这个时候，数以亿计的人要回家过年。火车票往往在几周前就被抢光了。人们提着大包小包，脸上却满是期待。对许多在外打工的人来说，回家是一年中最重要的事。一家人围坐在一起吃年夜饭，那种温暖难以形容。",
    "sentences": [
      {
        "cn": "春节是中国最重要的传统节日。",
        "ref": "The Spring Festival is the most important traditional festival in China.",
        "points": [
          "最高级 the most important + 名词",
          "专有节日名加定冠词 the"
        ]
      },
      {
        "cn": "每年这个时候，数以亿计的人要回家过年。",
        "ref": "Every year at this time, hundreds of millions of people go home for the festival.",
        "points": [
          "「数以亿计」用 hundreds of millions of",
          "people 作集合名词，谓语用复数"
        ]
      },
      {
        "cn": "火车票往往在几周前就被抢光了。",
        "ref": "Train tickets are often sold out weeks in advance.",
        "points": [
          "sold out 表「售罄」，用被动语态",
          "「提前几周」用 weeks in advance"
        ]
      },
      {
        "cn": "人们提着大包小包，脸上却满是期待。",
        "ref": "People carry big bags and small ones, but their faces are full of expectation.",
        "points": [
          "用 ones 替代前面出现过的 bags，避免重复",
          "be full of 表「充满」"
        ]
      },
      {
        "cn": "对许多在外打工的人来说，回家是一年中最重要的事。",
        "ref": "For many people working in other cities, going home is the most important thing of the year.",
        "points": [
          "for + 名词 + 现在分词作定语",
          "动名词 going home 作主语，谓语用单数"
        ]
      },
      {
        "cn": "一家人围坐在一起吃年夜饭，那种温暖难以形容。",
        "ref": "When the whole family sits around the table for the New Year's Eve dinner, the warmth is hard to describe.",
        "points": [
          "「难」译 be hard to do，用主动表被动",
          "「年夜饭」译 the New Year's Eve dinner"
        ]
      }
    ],
    "reference": "The Spring Festival is the most important traditional festival in China. Every year at this time, hundreds of millions of people go home for the festival. Train tickets are often sold out weeks in advance. People carry big bags and small ones, but their faces are full of expectation. For many people working in other cities, going home is the most important thing of the year. When the whole family sits around the table for the New Year's Eve dinner, the warmth is hard to describe.",
    "keyWords": [
      {
        "w": "the Spring Festival",
        "cn": "春节"
      },
      {
        "w": "traditional festival",
        "cn": "传统节日"
      },
      {
        "w": "hundreds of millions of",
        "cn": "数以亿计"
      },
      {
        "w": "be sold out",
        "cn": "售罄；卖完"
      },
      {
        "w": "in advance",
        "cn": "提前"
      },
      {
        "w": "expectation",
        "cn": "期待"
      },
      {
        "w": "the New Year's Eve dinner",
        "cn": "年夜饭"
      },
      {
        "w": "be full of",
        "cn": "充满"
      }
    ],
    "scoring": [
      "内容完整：准备返乡、购票、团聚等生活场景要点译全",
      "语言准确：动名词作主语、分词作定语等结构无语法错误",
      "表达流畅：口语化叙述读来自然，无逐字硬译痕迹",
      "用词地道：sold out、in advance、be full of 等搭配正确"
    ],
    "pitfalls": [
      "主谓不一致：hundreds of millions of people goes home（应用 go）",
      "漏译「之外」类限定语，把「在外打工的人」简化成 people",
      "搭配错误：in advance 误写成 in advanced",
      "标点与句数混乱：把两三个中文短句挤成一句，逻辑主语缺失"
    ]
  },
  {
    "id": "cet4-tech-mobilepayment",
    "level": "cet4",
    "year": "风格参照 2022 年 6 月",
    "topic": "科技生活",
    "title": "移动支付",
    "source": "如今，移动支付已经深入到中国人生活的方方面面。无论是在超市还是在路边小摊，人们都可以用手机付款。这种支付方式既方便又安全，因此大受欢迎。许多老年人也在学习使用手机支付。移动支付还改变了人们的消费习惯。有人认为，未来现金可能会越来越少见。",
    "sentences": [
      {
        "cn": "如今，移动支付已经深入到中国人生活的方方面面。",
        "ref": "Today, mobile payment has reached every aspect of Chinese people's lives.",
        "points": [
          "现在完成时 has reached 表影响延续至今",
          "「方方面面」译 every aspect of"
        ]
      },
      {
        "cn": "无论是在超市还是在路边小摊，人们都可以用手机付款。",
        "ref": "Whether in a supermarket or at a roadside stall, people can pay with their phones.",
        "points": [
          "whether ... or ... 引导让步状语从句（省略主语和谓语）",
          "支付方式用 pay with"
        ]
      },
      {
        "cn": "这种支付方式既方便又安全，因此大受欢迎。",
        "ref": "This way of paying is both convenient and safe, so it is very popular.",
        "points": [
          "both ... and ... 并列形容词",
          "so 引导结果状语从句"
        ]
      },
      {
        "cn": "许多老年人也在学习使用手机支付。",
        "ref": "Many elderly people are also learning to use mobile payment.",
        "points": [
          "learn to do sth 结构",
          "「老年人」用 the elderly / elderly people"
        ]
      },
      {
        "cn": "移动支付还改变了人们的消费习惯。",
        "ref": "Mobile payment has also changed people's spending habits.",
        "points": [
          "现在完成时表已发生的变化",
          "「消费习惯」译 spending habits，用复数"
        ]
      },
      {
        "cn": "有人认为，未来现金可能会越来越少见。",
        "ref": "Some people believe that cash may become less and less common in the future.",
        "points": [
          "宾语从句用 that 引导",
          "「越来越少见」用 less and less common"
        ]
      }
    ],
    "reference": "Today, mobile payment has reached every aspect of Chinese people's lives. Whether in a supermarket or at a roadside stall, people can pay with their phones. This way of paying is both convenient and safe, so it is very popular. Many elderly people are also learning to use mobile payment. Mobile payment has also changed people's spending habits. Some people believe that cash may become less and less common in the future.",
    "keyWords": [
      {
        "w": "mobile payment",
        "cn": "移动支付"
      },
      {
        "w": "aspect",
        "cn": "方面"
      },
      {
        "w": "roadside stall",
        "cn": "路边摊"
      },
      {
        "w": "convenient",
        "cn": "方便的"
      },
      {
        "w": "spending habit",
        "cn": "消费习惯"
      },
      {
        "w": "cash",
        "cn": "现金"
      },
      {
        "w": "popular",
        "cn": "受欢迎的"
      }
    ],
    "scoring": [
      "内容完整：普及范围、使用场景、优缺点、影响等要点无遗漏",
      "语言准确：现在完成时与并列结构使用正确，主谓一致",
      "表达流畅：说明性文字条理清楚，逻辑连接词使用恰当",
      "用词准确：every aspect、pay with、spending habits 等搭配地道"
    ],
    "pitfalls": [
      "时态错误：描述已发生的普及过程仍用一般现在时",
      "单复数错误：every aspect of Chinese people's life（life 应用复数 lives）",
      "漏译「无论是……还是……」，只译出其中一种场景",
      "介词错误：pay by their phones（应用 pay with）"
    ]
  },
  {
    "id": "cet6-tech-innovation",
    "level": "cet6",
    "year": "风格参照 2023 年 12 月",
    "topic": "科技创新",
    "title": "科技创新",
    "source": "近年来，科技创新已成为推动经济增长的重要力量。中国企业不断加大研发投入，努力掌握核心技术。与此同时，政府也出台政策鼓励年轻人投身科研。然而，基础研究仍然需要长期的耐心和稳定的支持。只有把创新成果转化为实际产品，技术才能真正造福社会。如何在开放合作与自主创新之间取得平衡，是各国共同面临的问题。",
    "sentences": [
      {
        "cn": "近年来，科技创新已成为推动经济增长的重要力量。",
        "ref": "In recent years, scientific and technological innovation has become an important force driving economic growth.",
        "points": [
          "in recent years 与现在完成时搭配",
          "现在分词 driving 作后置定语"
        ]
      },
      {
        "cn": "中国企业不断加大研发投入，努力掌握核心技术。",
        "ref": "Chinese enterprises keep increasing investment in research and development in an effort to master core technologies.",
        "points": [
          "keep doing 表持续做某事",
          "in an effort to do 表目的，比 to do 更书面"
        ]
      },
      {
        "cn": "与此同时，政府也出台政策鼓励年轻人投身科研。",
        "ref": "Meanwhile, the government has also introduced policies to encourage young people to devote themselves to scientific research.",
        "points": [
          "encourage sb to do sth 结构",
          "devote oneself to 中 to 为介词，后接名词"
        ]
      },
      {
        "cn": "然而，基础研究仍然需要长期的耐心和稳定的支持。",
        "ref": "However, basic research still requires long-term patience and stable support.",
        "points": [
          "however 作插入语，后接逗号",
          "「长期」用 long-term 作形容词"
        ]
      },
      {
        "cn": "只有把创新成果转化为实际产品，技术才能真正造福社会。",
        "ref": "Only when innovations are turned into practical products can technology truly benefit society.",
        "points": [
          "only + 状语从句置于句首，主句部分倒装",
          "「转化为」用 be turned into / translate into"
        ]
      },
      {
        "cn": "如何在开放合作与自主创新之间取得平衡，是各国共同面临的问题。",
        "ref": "How to strike a balance between open cooperation and independent innovation is a question facing all countries.",
        "points": [
          "how to do 结构作主语，谓语用单数 is",
          "strike a balance between A and B 固定搭配"
        ]
      }
    ],
    "reference": "In recent years, scientific and technological innovation has become an important force driving economic growth. Chinese enterprises keep increasing investment in research and development in an effort to master core technologies. Meanwhile, the government has also introduced policies to encourage young people to devote themselves to scientific research. However, basic research still requires long-term patience and stable support. Only when innovations are turned into practical products can technology truly benefit society. How to strike a balance between open cooperation and independent innovation is a question facing all countries.",
    "keyWords": [
      {
        "w": "scientific and technological innovation",
        "cn": "科技创新"
      },
      {
        "w": "economic growth",
        "cn": "经济增长"
      },
      {
        "w": "research and development",
        "cn": "研发"
      },
      {
        "w": "core technology",
        "cn": "核心技术"
      },
      {
        "w": "basic research",
        "cn": "基础研究"
      },
      {
        "w": "strike a balance",
        "cn": "取得平衡"
      },
      {
        "w": "independent innovation",
        "cn": "自主创新"
      },
      {
        "w": "benefit",
        "cn": "使受益；造福"
      }
    ],
    "scoring": [
      "内容完整：投入、政策、基础研究、成果转化、平衡等要点全部覆盖",
      "语言准确：倒装句、分词作定语、主语从句等结构使用规范",
      "表达流畅：论述层次分明，书面语体统一，无中式英语",
      "用词到位：devote oneself to、strike a balance 等六级高频搭配准确"
    ],
    "pitfalls": [
      "倒装缺失：Only when ... technology can truly benefit（应写成 can technology）",
      "介词错误：devote themselves to do scientific research（to 后应接动名词或名词）",
      "主谓不一致：动名词短语作主语时误用复数谓语",
      "漏译逻辑关系：however、meanwhile 等衔接词漏译，句间逻辑丢失"
    ]
  },
  {
    "id": "cet6-society-ruraleducation",
    "level": "cet6",
    "year": "风格参照 2023 年 6 月",
    "topic": "乡村振兴与教育",
    "title": "乡村振兴与乡村教育",
    "source": "乡村振兴战略实施以来，许多农村地区发生了巨大变化。道路修好了，网络也通了，农产品可以卖到更远的地方。然而，优质教育资源的缺乏仍然是农村面临的主要问题。近年来，越来越多的年轻教师愿意到乡村学校任教。一些城市学校通过互联网，把优质课程分享给农村学生。教育公平不仅关系到个人前途，也关系到乡村的未来。",
    "sentences": [
      {
        "cn": "乡村振兴战略实施以来，许多农村地区发生了巨大变化。",
        "ref": "Since the rural revitalization strategy was carried out, great changes have taken place in many rural areas.",
        "points": [
          "since 引导时间状语从句，主句用现在完成时",
          "take place 无被动语态，用主动形式"
        ]
      },
      {
        "cn": "道路修好了，网络也通了，农产品可以卖到更远的地方。",
        "ref": "Roads have been built and the internet is available, so agricultural products can be sold to more distant places.",
        "points": [
          "并列句用 so 表结果",
          "「修好了」用现在完成时的被动语态"
        ]
      },
      {
        "cn": "然而，优质教育资源的缺乏仍然是农村面临的主要问题。",
        "ref": "However, the shortage of quality educational resources remains a major problem in rural areas.",
        "points": [
          "「缺乏」名词化处理为 the shortage of",
          "remain 作系动词，后接名词短语"
        ]
      },
      {
        "cn": "近年来，越来越多的年轻教师愿意到乡村学校任教。",
        "ref": "In recent years, more and more young teachers are willing to teach in rural schools.",
        "points": [
          "be willing to do sth 表意愿",
          "「任教」用 teach in + 地点"
        ]
      },
      {
        "cn": "一些城市学校通过互联网，把优质课程分享给农村学生。",
        "ref": "Through the internet, some urban schools share quality courses with rural students.",
        "points": [
          "share sth with sb 固定搭配",
          "「城市学校」用 urban schools"
        ]
      },
      {
        "cn": "教育公平不仅关系到个人前途，也关系到乡村的未来。",
        "ref": "Educational equity concerns not only individual prospects but also the future of the countryside.",
        "points": [
          "concern 表「关系到」，及物动词",
          "not only ... but also 连接并列宾语"
        ]
      }
    ],
    "reference": "Since the rural revitalization strategy was carried out, great changes have taken place in many rural areas. Roads have been built and the internet is available, so agricultural products can be sold to more distant places. However, the shortage of quality educational resources remains a major problem in rural areas. In recent years, more and more young teachers are willing to teach in rural schools. Through the internet, some urban schools share quality courses with rural students. Educational equity concerns not only individual prospects but also the future of the countryside.",
    "keyWords": [
      {
        "w": "rural revitalization",
        "cn": "乡村振兴"
      },
      {
        "w": "take place",
        "cn": "发生"
      },
      {
        "w": "agricultural products",
        "cn": "农产品"
      },
      {
        "w": "quality educational resources",
        "cn": "优质教育资源"
      },
      {
        "w": "be willing to",
        "cn": "愿意"
      },
      {
        "w": "educational equity",
        "cn": "教育公平"
      },
      {
        "w": "the countryside",
        "cn": "乡村"
      }
    ],
    "scoring": [
      "内容完整：基础设施、教育短板、师资流入、资源共享、教育公平等要点齐备",
      "语言准确：现在完成时与被动语态使用正确，主谓一致",
      "表达流畅：转折与因果关系清晰，句间有呼应",
      "用词准确：take place、share with、be willing to 等搭配无误"
    ],
    "pitfalls": [
      "被动误用：great changes have been taken place（take place 不可用被动）",
      "时态混乱：since 从句后主句误用一般过去时",
      "搭配错误：share quality courses to rural students（应用 with）",
      "漏译「然而」「不仅……也……」等逻辑词，论述关系变模糊"
    ]
  },
  {
    "id": "cet6-env-green",
    "level": "cet6",
    "year": "风格参照 2022 年 12 月",
    "topic": "环境保护与绿色发展",
    "title": "绿色发展",
    "source": "随着环境问题日益突出，绿色发展已成为全球共识。中国政府承诺在2060年前实现碳中和。为此，许多城市正在推广新能源汽车和清洁能源。企业也开始把环保因素纳入生产决策。对普通人来说，节约用电、减少浪费同样重要。保护环境不是某个国家的事，而需要全世界的共同努力。",
    "sentences": [
      {
        "cn": "随着环境问题日益突出，绿色发展已成为全球共识。",
        "ref": "As environmental problems become increasingly serious, green development has become a global consensus.",
        "points": [
          "as 引导伴随状语从句，主句用现在完成时",
          "「日益突出」用 increasingly serious"
        ]
      },
      {
        "cn": "中国政府承诺在2060年前实现碳中和。",
        "ref": "The Chinese government has promised to achieve carbon neutrality before 2060.",
        "points": [
          "promise to do sth 表承诺",
          "「在……前」用 before + 时间点"
        ]
      },
      {
        "cn": "为此，许多城市正在推广新能源汽车和清洁能源。",
        "ref": "To this end, many cities are promoting new energy vehicles and clean energy.",
        "points": [
          "「为此」用 to this end 作连接性状语",
          "现在进行时表正在推进的政策"
        ]
      },
      {
        "cn": "企业也开始把环保因素纳入生产决策。",
        "ref": "Companies have also begun to take environmental factors into account in their production decisions.",
        "points": [
          "take ... into account 固定搭配",
          "begin to do 与现在完成时连用表至今的变化"
        ]
      },
      {
        "cn": "对普通人来说，节约用电、减少浪费同样重要。",
        "ref": "For ordinary people, saving electricity and reducing waste are equally important.",
        "points": [
          "动名词并列作主语，谓语用复数 are",
          "「同样重要」用 equally important"
        ]
      },
      {
        "cn": "保护环境不是某个国家的事，而需要全世界的共同努力。",
        "ref": "Protecting the environment is not the business of a single country but requires the joint efforts of the whole world.",
        "points": [
          "not ... but ... 连接两个谓语，注意结构对称",
          "「共同努力」译 joint efforts"
        ]
      }
    ],
    "reference": "As environmental problems become increasingly serious, green development has become a global consensus. The Chinese government has promised to achieve carbon neutrality before 2060. To this end, many cities are promoting new energy vehicles and clean energy. Companies have also begun to take environmental factors into account in their production decisions. For ordinary people, saving electricity and reducing waste are equally important. Protecting the environment is not the business of a single country but requires the joint efforts of the whole world.",
    "keyWords": [
      {
        "w": "green development",
        "cn": "绿色发展"
      },
      {
        "w": "global consensus",
        "cn": "全球共识"
      },
      {
        "w": "carbon neutrality",
        "cn": "碳中和"
      },
      {
        "w": "new energy vehicle",
        "cn": "新能源汽车"
      },
      {
        "w": "take ... into account",
        "cn": "把……考虑在内"
      },
      {
        "w": "joint efforts",
        "cn": "共同努力"
      },
      {
        "w": "equally important",
        "cn": "同样重要"
      }
    ],
    "scoring": [
      "内容完整：现状、承诺目标、政策举措、企业责任、公众行动等层次完整",
      "语言准确：动名词作主语、not ... but ... 并列结构等无语法错误",
      "表达流畅：逻辑衔接自然，语体正式，符合议论文风格",
      "用词到位：carbon neutrality、take into account 等高阶表达准确"
    ],
    "pitfalls": [
      "主谓不一致：动名词并列作主语时误用单数谓语",
      "搭配错误：take environmental factors into consider（应为 account）",
      "结构不对称：not ... but 前后一个接名词、一个接动词",
      "漏译「为此」等衔接语，段落逻辑松散"
    ]
  },
  {
    "id": "cet6-culture-tcm",
    "level": "cet6",
    "year": "风格参照 2021 年 6 月",
    "topic": "传统文化",
    "title": "中医药",
    "source": "中医药是中华民族几千年来积累的宝贵财富。它强调人与自然的和谐，注重预防疾病。近年来，中医药逐渐被更多国家的人们所接受。在抗击疫情的过程中，中药也发挥了一定作用。不过，中医药的现代化和标准化仍面临不少挑战。如何在继承传统的同时推动创新，是值得深入思考的问题。",
    "sentences": [
      {
        "cn": "中医药是中华民族几千年来积累的宝贵财富。",
        "ref": "Traditional Chinese medicine is a precious treasure accumulated by the Chinese nation over thousands of years.",
        "points": [
          "过去分词 accumulated 作后置定语",
          "「几千年来」用 over thousands of years"
        ]
      },
      {
        "cn": "它强调人与自然的和谐，注重预防疾病。",
        "ref": "It emphasizes harmony between humans and nature and focuses on preventing disease.",
        "points": [
          "「人与自然的和谐」译 harmony between humans and nature",
          "focus on 后接动名词"
        ]
      },
      {
        "cn": "近年来，中医药逐渐被更多国家的人们所接受。",
        "ref": "In recent years, traditional Chinese medicine has gradually been accepted by people in more countries.",
        "points": [
          "现在完成时的被动语态 has been accepted",
          "gradually 置于助动词之后、分词之前"
        ]
      },
      {
        "cn": "在抗击疫情的过程中，中药也发挥了一定作用。",
        "ref": "In the fight against the epidemic, Chinese herbal medicine also played a certain role.",
        "points": [
          "「发挥作用」用 play a role",
          "叙述已完成的过去事件用一般过去时"
        ]
      },
      {
        "cn": "不过，中医药的现代化和标准化仍面临不少挑战。",
        "ref": "However, the modernization and standardization of traditional Chinese medicine still face many challenges.",
        "points": [
          "并列名词短语作主语，谓语用复数 face",
          "「面临挑战」用 face challenges"
        ]
      },
      {
        "cn": "如何在继承传统的同时推动创新，是值得深入思考的问题。",
        "ref": "How to promote innovation while inheriting tradition is a question worth thinking about deeply.",
        "points": [
          "while doing 表「在……的同时」",
          "be worth doing 主动形式表被动"
        ]
      }
    ],
    "reference": "Traditional Chinese medicine is a precious treasure accumulated by the Chinese nation over thousands of years. It emphasizes harmony between humans and nature and focuses on preventing disease. In recent years, traditional Chinese medicine has gradually been accepted by people in more countries. In the fight against the epidemic, Chinese herbal medicine also played a certain role. However, the modernization and standardization of traditional Chinese medicine still face many challenges. How to promote innovation while inheriting tradition is a question worth thinking about deeply.",
    "keyWords": [
      {
        "w": "traditional Chinese medicine",
        "cn": "中医药"
      },
      {
        "w": "precious treasure",
        "cn": "宝贵财富"
      },
      {
        "w": "harmony",
        "cn": "和谐"
      },
      {
        "w": "prevent disease",
        "cn": "预防疾病"
      },
      {
        "w": "epidemic",
        "cn": "疫情；流行病"
      },
      {
        "w": "standardization",
        "cn": "标准化"
      },
      {
        "w": "be worth doing",
        "cn": "值得做"
      }
    ],
    "scoring": [
      "内容完整：历史价值、理念、国际认可、实际作用、挑战与思考等要点完整",
      "语言准确：分词作定语、被动语态、be worth doing 等结构无误",
      "表达流畅：说明与议论结合，语体规范，逻辑推进自然",
      "用词准确：play a role、face challenges 等搭配地道"
    ],
    "pitfalls": [
      "主谓不一致：the modernization and standardization ... faces（应用 face）",
      "结构错误：is worth to think about（be worth 后接动名词）",
      "漏译修饰语：「中华民族几千年来积累的」被整体省略",
      "时态一致性问题：同一段落中已完成事件与当前状态时态混用"
    ]
  },
  {
    "id": "cet6-eco-panda",
    "level": "cet6",
    "year": "风格参照 2022 年 6 月",
    "topic": "生态保护",
    "title": "大熊猫与生态保护",
    "source": "大熊猫是中国的国宝，也是世界上最受喜爱的动物之一。由于栖息地减少，大熊猫曾一度面临灭绝的危险。通过建立自然保护区，它们的数量近年来稳步增长。保护大熊猫也保护了同一片森林中的其他物种。如今，生态保护的理念正被越来越多的人接受。专家提醒，保护工作依然不能放松。",
    "sentences": [
      {
        "cn": "大熊猫是中国的国宝，也是世界上最受喜爱的动物之一。",
        "ref": "The giant panda is a national treasure of China and one of the most beloved animals in the world.",
        "points": [
          "one of the most + 形容词最高级 + 名词复数",
          "两个表语用 and 并列，共用系动词 is"
        ]
      },
      {
        "cn": "由于栖息地减少，大熊猫曾一度面临灭绝的危险。",
        "ref": "Because of the loss of habitats, giant pandas were once in danger of extinction.",
        "points": [
          "because of 后接名词短语，不能接句子",
          "「面临……的危险」用 be in danger of"
        ]
      },
      {
        "cn": "通过建立自然保护区，它们的数量近年来稳步增长。",
        "ref": "Thanks to the establishment of nature reserves, their numbers have grown steadily in recent years.",
        "points": [
          "thanks to 表原因，语体比 because of 更书面",
          "「稳步增长」用 grow steadily，与现在完成时搭配"
        ]
      },
      {
        "cn": "保护大熊猫也保护了同一片森林中的其他物种。",
        "ref": "Protecting giant pandas also protects other species living in the same forest.",
        "points": [
          "动名词短语作主语，谓语用单数",
          "现在分词 living 作后置定语"
        ]
      },
      {
        "cn": "如今，生态保护的理念正被越来越多的人接受。",
        "ref": "Today, the idea of ecological protection is being accepted by more and more people.",
        "points": [
          "现在进行时的被动语态 is being accepted",
          "「越来越多」用 more and more + 名词复数"
        ]
      },
      {
        "cn": "专家提醒，保护工作依然不能放松。",
        "ref": "Experts remind us that conservation work must not be relaxed.",
        "points": [
          "remind sb that ... 引导宾语从句",
          "must not 表禁止或不应，语气要准确"
        ]
      }
    ],
    "reference": "The giant panda is a national treasure of China and one of the most beloved animals in the world. Because of the loss of habitats, giant pandas were once in danger of extinction. Thanks to the establishment of nature reserves, their numbers have grown steadily in recent years. Protecting giant pandas also protects other species living in the same forest. Today, the idea of ecological protection is being accepted by more and more people. Experts remind us that conservation work must not be relaxed.",
    "keyWords": [
      {
        "w": "giant panda",
        "cn": "大熊猫"
      },
      {
        "w": "national treasure",
        "cn": "国宝"
      },
      {
        "w": "habitat",
        "cn": "栖息地"
      },
      {
        "w": "extinction",
        "cn": "灭绝"
      },
      {
        "w": "nature reserve",
        "cn": "自然保护区"
      },
      {
        "w": "species",
        "cn": "物种"
      },
      {
        "w": "conservation",
        "cn": "保护"
      }
    ],
    "scoring": [
      "内容完整：国宝地位、濒危原因、保护成效、生态意义、前景提醒等要点齐全",
      "语言准确：动名词作主语、现在分词作定语、进行时被动语态正确",
      "表达流畅：因果与递进关系清楚，语体统一为说明文风格",
      "用词准确：be in danger of、thanks to、species 单复数同形等处理正确"
    ],
    "pitfalls": [
      "species 单复数同形被误写成 speciess 或 specieses",
      "结构错误：Because of habitats decreased（because of 后误接句子）",
      "主谓不一致：动名词短语作主语时误用复数谓语",
      "漏译「没有放松」的否定语气，写成 must be relaxed"
    ]
  }
];
