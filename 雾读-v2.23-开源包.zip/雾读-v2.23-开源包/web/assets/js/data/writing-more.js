window.WRITING_MORE = [
  {
    id: "cet4-2022-06-writing-library",
    level: "cet4",
    year: "2022年6月",
    source: "https://cet4-6.xdf.cn/202206/11919675.html",
    verified: true,
    topic: "校园服务",
    title: "致校图书馆的服务建议书",
    prompt: "Directions: Suppose you are writing a proposal to your school library about improving its services, you are writing about its current problems and solutions. You should write at least 120 words but no more than 180 words.",
    outline: ["点明写信目的：就图书馆服务提出改进建议", "列举现存问题：馆员态度、藏书陈旧、阅览室照明", "提出可行方案并表达期待"],
    sample: "Dear Sir or Madam, I am a sophomore in our university. Having used our school library for nearly two years, I am writing to share some problems and possible solutions. To begin with, some librarians seem impatient when students ask for help, which discourages us from seeking assistance. In addition, quite a few books on the shelves are outdated and can hardly keep up with the latest research. The reading rooms are also poorly lit, so many of us have to give up studying there in the evening. To improve the service, I suggest that the library offer its staff regular training and update the collection every semester. It would also be helpful to repair the lights and extend the opening hours during the exam weeks. I would appreciate it if you could take my suggestions into consideration. Thank you for your time. Yours sincerely, Li Ming",
    expressions: [
      { en: "keep up with the latest research", cn: "跟上最新研究进展" },
      { en: "discourage sb. from doing sth.", cn: "使某人打消做某事的念头" },
      { en: "be poorly lit", cn: "照明不足" },
      { en: "extend the opening hours", cn: "延长开放时间" },
      { en: "take my suggestions into consideration", cn: "考虑我的建议" },
      { en: "I would appreciate it if you could...", cn: "若您能……我将不胜感激" }
    ],
    upgrades: [
      { from: "important", to: "significant", cn: "重要的" },
      { from: "many", to: "a considerable number of", cn: "许多" },
      { from: "problem", to: "drawback", cn: "弊端" },
      { from: "improve", to: "optimize", cn: "改进" },
      { from: "helpful", to: "conducive", cn: "有益的" }
    ],
    keywords: ["library", "service", "proposal", "librarian", "facility", "reading room"]
  },
  {
    id: "cet4-2022-06-writing-student-union",
    level: "cet4",
    year: "2022年6月",
    source: "https://cet4-6.xdf.cn/202206/11919675.html",
    verified: true,
    topic: "校园活动",
    title: "致学生会的课外活动建议书",
    prompt: "Directions: Suppose you are writing a proposal to the Students' Union about enriching extracurricular activities. You are writing about the current situation and your suggestions. You should write at least 120 words but no more than 180 words.",
    outline: ["说明当前课外活动偏少、形式单一", "建议增加体育活动、志愿活动与专家讲座", "总结意义并表达期待"],
    sample: "Dear President, I am Li Ming, a sophomore in our university. Noticing that our Students' Union is collecting advice on extracurricular activities, I would like to make three suggestions. First, it would be better to hold more sports events. At present, we have only one school-wide sports meeting a year, while a football league or a weekend run could attract far more participants. Second, I hope the Union can organize more volunteer programmes, such as helping children in rural primary schools or visiting nursing homes. Such experiences broaden our horizons and strengthen our sense of responsibility. Third, inviting experts from different fields to give lectures would benefit us a lot, since students are always eager to learn beyond textbooks. I am convinced that colorful activities will enrich campus life and make our university a more vibrant place. Thank you for your consideration. Yours sincerely, Li Ming",
    expressions: [
      { en: "collect advice on sth.", cn: "就某事征集建议" },
      { en: "broaden one's horizons", cn: "开阔视野" },
      { en: "strengthen one's sense of responsibility", cn: "增强责任感" },
      { en: "be eager to do sth.", cn: "渴望做某事" },
      { en: "enrich campus life", cn: "丰富校园生活" },
      { en: "Thank you for your consideration.", cn: "感谢您的考虑。" }
    ],
    upgrades: [
      { from: "good", to: "beneficial", cn: "有益的" },
      { from: "more and more", to: "an increasing number of", cn: "越来越多的" },
      { from: "give", to: "offer", cn: "提供" },
      { from: "think", to: "be convinced", cn: "确信" },
      { from: "activity", to: "programme", cn: "活动、项目" }
    ],
    keywords: ["extracurricular", "Students' Union", "sports meeting", "volunteer", "lecture", "campus life"]
  },
  {
    id: "cet4-2022-06-writing-clinic",
    level: "cet4",
    year: "2022年6月",
    source: "https://cet4-6.xdf.cn/202206/11919675.html",
    verified: true,
    topic: "校园服务",
    title: "致校医院的服务改进方案",
    prompt: "Directions: Suppose you are writing a proposal to the school clinic about improving its services. You are writing about the current problems and your solutions. You should write at least 120 words but no more than 180 words.",
    outline: ["说明写信目的：为校医院服务改进提建议", "指出问题：排队时间长、医嘱交代不清", "提出在线预约与书面提示等解决办法"],
    sample: "Dear Sir or Madam, I am Li Ming, a sophomore majoring in Business Administration. I am writing to make some suggestions on improving the services of our school clinic. During my recent visits, I noticed two problems that trouble many students. First, the waiting time is rather long, especially on Monday mornings, when dozens of students crowd into the small hall. Second, some doctors give explanations too briefly, and patients often leave without knowing how to take the medicine properly. To solve these problems, I suggest that the clinic introduce an online booking system, which allows students to choose a time slot in advance. It would also help if every patient could receive a printed note with clear instructions. I believe these measures will make the clinic more efficient and friendly. Thank you for your consideration. Yours sincerely, Li Ming",
    expressions: [
      { en: "make suggestions on sth.", cn: "就某事提出建议" },
      { en: "crowd into", cn: "涌入、挤进" },
      { en: "an online booking system", cn: "在线预约系统" },
      { en: "in advance", cn: "提前" },
      { en: "It would also help if...", cn: "如果……也会很有帮助" },
      { en: "make sth. more efficient", cn: "使某事更高效" }
    ],
    upgrades: [
      { from: "long", to: "lengthy", cn: "冗长的" },
      { from: "solve", to: "tackle", cn: "解决" },
      { from: "say", to: "state", cn: "说明" },
      { from: "clear", to: "explicit", cn: "清晰的" },
      { from: "friendly", to: "approachable", cn: "平易近人的" }
    ],
    keywords: ["clinic", "appointment", "waiting time", "patient", "instruction", "service"]
  },
  {
    id: "cet4-2020-12-writing-education",
    level: "cet4",
    year: "2020年12月",
    source: "https://cet4-6.xdf.cn/202012/11134696.html",
    verified: true,
    topic: "教育变迁",
    title: "教育方式的变化",
    prompt: "Directions: For this part, you are allowed 30 minutes to write on the topic Changes in the Way of Education. You should write at least 120 words but no more than 180 words.",
    outline: ["指出教育方式近十年的巨大变化", "分析变化原因：互联网普及与线上教学兴起", "表明态度：拥抱变化，重在独立思考"],
    sample: "The way we learn has changed enormously over the past decade, and the changes are still accelerating. When my parents were students, knowledge came almost entirely from textbooks and teachers. Today, a single smartphone can connect us with lectures given by the best universities in the world, yet it also tempts us with endless entertainment. Two forces explain this shift. The Internet has made information abundant and nearly free, while the pandemic pushed millions of classrooms online almost overnight. As a result, learning is no longer limited by time or space, but it demands far more self-discipline than before. In my view, we should welcome these changes instead of resisting them. What matters is not whether we study in a classroom or in front of a screen, but whether we keep a curious mind and the habit of thinking independently.",
    expressions: [
      { en: "change enormously", cn: "发生巨大变化" },
      { en: "be no longer limited by time or space", cn: "不再受时间或空间限制" },
      { en: "demand self-discipline", cn: "要求自律" },
      { en: "instead of resisting", cn: "而不是抵制" },
      { en: "What matters is not... but...", cn: "重要的不是……而是……" },
      { en: "a curious mind", cn: "一颗好奇的心" }
    ],
    upgrades: [
      { from: "change", to: "shift", cn: "转变" },
      { from: "big", to: "enormous", cn: "巨大的" },
      { from: "cause", to: "account for", cn: "解释、造成" },
      { from: "many", to: "millions of", cn: "数百万的" },
      { from: "think", to: "hold the view", cn: "持……观点" }
    ],
    keywords: ["education", "online course", "Internet", "self-discipline", "classroom", "independent thinking"]
  },
  {
    id: "cet4-2019-12-writing-university",
    level: "cet4",
    year: "2019年12月",
    source: "https://cet4.koolearn.com/20191214/836301.html",
    verified: true,
    topic: "校园生活",
    title: "给外国朋友推荐一所大学",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a letter to a foreign friend who wants to learn Chinese. Please recommend a university to him. You should write at least 120 words but no more than 180 words.",
    outline: ["回复朋友来华学中文的打算", "推荐母校并给出三条理由：课程、城市、语言环境", "提供帮助并表达期待"],
    sample: "Dear Tom, I am delighted to hear that you plan to learn Chinese in China. Since you asked for my recommendation, I would like to suggest Hunan Institute of Engineering, the university where I am studying. There are three reasons for my choice. First, the university offers a well-organized Chinese language programme for international students, with small classes and experienced teachers. Second, the campus is located in a city with a pleasant climate and low living costs, which means you can concentrate on your studies without worrying too much about money. Third, students here are friendly and patient, so you will have plenty of chances to practise Chinese in daily conversations. If you need any help with the application, please let me know. I am looking forward to seeing you on campus. Yours sincerely, Li Ming",
    expressions: [
      { en: "be delighted to hear that...", cn: "很高兴听说……" },
      { en: "ask for one's recommendation", cn: "征求某人的推荐" },
      { en: "a well-organized programme", cn: "组织良好的课程项目" },
      { en: "concentrate on one's studies", cn: "专心学业" },
      { en: "have plenty of chances to do sth.", cn: "有很多机会做某事" },
      { en: "look forward to doing sth.", cn: "期待做某事" }
    ],
    upgrades: [
      { from: "suggest", to: "recommend", cn: "推荐" },
      { from: "good", to: "well-organized", cn: "组织良好的" },
      { from: "help", to: "assistance", cn: "帮助" },
      { from: "happy", to: "delighted", cn: "高兴的" },
      { from: "chance", to: "opportunity", cn: "机会" }
    ],
    keywords: ["Chinese learning", "university", "recommendation", "campus", "international student", "application"]
  },
  {
    id: "cet4-2016-06-writing-thanks-parents",
    level: "cet4",
    year: "2016年6月",
    source: "https://m.koolearn.com/news/20160802/1092682.html",
    verified: true,
    topic: "感恩",
    title: "致父母的感谢信",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a letter to express your thanks to your parents or any other family member upon making a memorable achievement. You should write at least 120 words but no more than 180 words.",
    outline: ["点明写信目的：取得成绩后向父母致谢", "回顾父母给予的鼓励与教诲", "表达回报之心与祝福"],
    sample: "Dear Mom and Dad, I am writing to express my heartfelt thanks for everything you have done for me. Yesterday I received the news that I had won the first prize in the provincial English competition, and the first people I wanted to thank were you. This award means much more than a certificate to me. Whenever I felt discouraged by endless practice, it was your encouragement that gave me the strength to continue. You never pushed me to be perfect. Instead, you taught me to enjoy the process and to stand up again after every failure. The patience and warmth you have shown have shaped the person I am today. I know that no words can fully repay your love, but I promise to study harder and to take good care of myself. Thank you for always being there for me.",
    expressions: [
      { en: "express one's heartfelt thanks for...", cn: "对……表达由衷的感谢" },
      { en: "mean much more than...", cn: "意义远不止……" },
      { en: "feel discouraged by", cn: "因……感到气馁" },
      { en: "give sb. the strength to continue", cn: "给某人继续下去的力量" },
      { en: "repay sb.'s love", cn: "回报某人的爱" },
      { en: "be always there for sb.", cn: "始终陪伴、支持某人" }
    ],
    upgrades: [
      { from: "thanks", to: "gratitude", cn: "感激" },
      { from: "happy", to: "delighted", cn: "欣喜的" },
      { from: "always", to: "constantly", cn: "始终" },
      { from: "help", to: "support", cn: "支持" },
      { from: "important", to: "vital", cn: "至关重要的" }
    ],
    keywords: ["gratitude", "parents", "achievement", "encouragement", "failure", "promise"]
  },
  {
    id: "cet4-2016-06-writing-thanks-teacher",
    level: "cet4",
    year: "2016年6月",
    source: "https://m.koolearn.com/news/20160802/1092682.html",
    verified: true,
    topic: "感恩",
    title: "致中学老师的感谢信",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a letter to express your thanks to one of your school teachers upon entering college. You should write at least 120 words but no more than 180 words.",
    outline: ["说明入学之际写给老师的感谢信", "回忆老师当年的教学方式与鼓励", "说明老师的影响延续至今并致谢"],
    sample: "Dear Mr. Wang, I am writing to express my sincere gratitude to you upon entering college. Looking back on my three years in senior high school, I realize how much your teaching has influenced me. You not only explained grammar clearly but also encouraged us to read widely and to express our own ideas. When my English was still poor and I dared not speak in class, you gave me the chance to answer simple questions first, which gradually built up my confidence. Your patience and enthusiasm turned a demanding subject into an enjoyable journey. Now I am studying in college, and the habit of reading English every morning that you helped me form is still with me. Thank you for believing in me. I wish you good health and every happiness.",
    expressions: [
      { en: "express one's sincere gratitude to sb.", cn: "向某人致以诚挚谢意" },
      { en: "look back on", cn: "回顾" },
      { en: "encourage sb. to do sth.", cn: "鼓励某人做某事" },
      { en: "build up one's confidence", cn: "建立自信" },
      { en: "turn... into an enjoyable journey", cn: "把……变成愉快的旅程" },
      { en: "believe in sb.", cn: "信任、看好某人" }
    ],
    upgrades: [
      { from: "thank", to: "be grateful to", cn: "感激" },
      { from: "good", to: "outstanding", cn: "出色的" },
      { from: "help", to: "guide", cn: "引导" },
      { from: "show", to: "demonstrate", cn: "展现" },
      { from: "still", to: "to this day", cn: "至今" }
    ],
    keywords: ["gratitude", "teacher", "college", "confidence", "patience", "habit"]
  },
  {
    id: "cet4-2016-06-writing-thanks-friends",
    level: "cet4",
    year: "2016年6月",
    source: "https://m.koolearn.com/news/20160802/1092682.html",
    verified: true,
    topic: "友谊",
    title: "致困境中帮助过我的朋友",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a letter to express your thanks to your friends who helped you most when you were in difficulty. You should write at least 120 words but no more than 180 words.",
    outline: ["点明写信目的：感谢困境中施以援手的朋友", "回忆具体帮助的细节与当时心境", "阐释友谊的真谛并期待回报"],
    sample: "Dear Li Hua, I am writing to thank you for the help you gave me when I was in trouble last semester. I still remember the days before the final exams, when I fell ill and had to stay in the hospital for a week. You came to visit me every evening, brought me the notes you had taken in class, and patiently explained the difficult points I had missed. Without your help, I would certainly have failed the exam and probably lost my confidence as well. What moved me most was that you never mentioned it afterwards, as if it were something too small to remember. True friendship is not measured by words but by actions taken in difficult times. I hope that one day I can return your kindness. Yours sincerely, Li Ming",
    expressions: [
      { en: "be in trouble", cn: "处于困境" },
      { en: "explain the difficult points", cn: "讲解难点" },
      { en: "Without your help, I would...", cn: "没有你的帮助，我就会……" },
      { en: "What moved me most was that...", cn: "最让我感动的是……" },
      { en: "be measured by", cn: "以……来衡量" },
      { en: "return one's kindness", cn: "回报某人的善意" }
    ],
    upgrades: [
      { from: "help", to: "assistance", cn: "援助" },
      { from: "bad", to: "severe", cn: "严重的" },
      { from: "kind", to: "generous", cn: "慷慨的" },
      { from: "friend", to: "companion", cn: "同伴" },
      { from: "remember", to: "bear in mind", cn: "铭记" }
    ],
    keywords: ["friendship", "gratitude", "in difficulty", "hospital", "exam", "kindness"]
  },
  {
    id: "cet4-2017-12-writing-parents-children",
    level: "cet4",
    year: "2017年12月",
    source: "https://news.koolearn.com/20171216/1142051.html",
    verified: true,
    topic: "家庭关系",
    title: "如何处理父母与子女的关系",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a short essay on how to best handle the relationship between parents and children. You should write at least 120 words but no more than 180 words.",
    outline: ["指出亲子关系的重要性与现实冲突", "从父母与子女两个角度提出相处之道", "强调坦诚沟通的作用"],
    sample: "Few things matter more to our happiness than the relationship between parents and children, yet it is often the source of daily conflicts. In my opinion, mutual understanding and regular communication are the keys to handling it well. On the one hand, parents should respect their children as independent individuals. Instead of deciding everything for them, parents may listen to their opinions patiently and offer advice only when it is needed. On the other hand, children should try to see things from their parents' point of view. Most parents are simply worried about our health, study and future, and their strictness usually comes from love rather than from a desire to control us. Therefore, both sides should spend more time talking honestly. A family dinner without phones may achieve more than a hundred lectures.",
    expressions: [
      { en: "be the source of daily conflicts", cn: "是日常冲突的根源" },
      { en: "mutual understanding", cn: "相互理解" },
      { en: "see things from sb.'s point of view", cn: "从某人的角度看问题" },
      { en: "come from love rather than control", cn: "出于爱而非控制" },
      { en: "talk honestly", cn: "坦诚交谈" },
      { en: "achieve more than...", cn: "比……更有成效" }
    ],
    upgrades: [
      { from: "important", to: "essential", cn: "必不可少的" },
      { from: "talk", to: "communicate", cn: "沟通" },
      { from: "strict", to: "demanding", cn: "要求严格的" },
      { from: "help", to: "facilitate", cn: "促进" },
      { from: "always", to: "generally", cn: "通常" }
    ],
    keywords: ["parents", "children", "relationship", "understanding", "communication", "conflict"]
  },
  {
    id: "cet4-2017-12-writing-teacher-student",
    level: "cet4",
    year: "2017年12月",
    source: "https://news.koolearn.com/20171216/1142051.html",
    verified: true,
    topic: "师生关系",
    title: "如何处理师生关系",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a short essay on how to best handle the relationship between teachers and students. You should write at least 120 words but no more than 180 words.",
    outline: ["指出良好师生关系对课堂与校园的意义", "从尊重、沟通、界限三点提出做法", "总结：相互尊重是基础"],
    sample: "A healthy relationship between teachers and students benefits both the classroom and the whole campus. To handle it well, I believe respect, communication and clear boundaries are essential. First, students should respect teachers' efforts and treat them politely, while teachers need to respect students' personalities and avoid judging anyone by a single exam. Second, communication should go beyond the classroom. After class, a brief conversation about reading, hobbies or future plans can shorten the distance between the two sides and make teaching more effective. Third, both parties should keep proper boundaries: teachers ought to be fair to every student, and students should express disagreement in a civilized way rather than with anger. In short, a good teacher-student relationship is built on mutual respect. When both sides make an effort, learning becomes a pleasant journey for everyone.",
    expressions: [
      { en: "handle the relationship well", cn: "处理好关系" },
      { en: "go beyond the classroom", cn: "不局限于课堂" },
      { en: "shorten the distance between", cn: "拉近……之间的距离" },
      { en: "keep proper boundaries", cn: "保持恰当的界限" },
      { en: "express disagreement in a civilized way", cn: "以文明的方式表达分歧" },
      { en: "be built on mutual respect", cn: "建立在相互尊重之上" }
    ],
    upgrades: [
      { from: "good", to: "harmonious", cn: "和谐的" },
      { from: "talk", to: "conversation", cn: "交谈" },
      { from: "fair", to: "impartial", cn: "公正的" },
      { from: "help", to: "contribute to", cn: "有助于" },
      { from: "angry", to: "resentful", cn: "愤怒的" }
    ],
    keywords: ["teacher", "student", "relationship", "respect", "communication", "boundary"]
  },
  {
    id: "cet4-2018-06-writing-ability",
    level: "cet4",
    year: "2018年6月",
    source: "https://cet4-6.xdf.cn/201806/10795271.html",
    verified: true,
    topic: "个人能力",
    title: "口语能力的重要性及其培养",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a short essay on the importance of speaking ability and how to develop it. You should write at least 120 words but no more than 180 words.",
    outline: ["说明口语能力对学业与职业的意义", "给出三条培养路径：积累、练习、模仿", "强调能力靠练不靠天分"],
    sample: "Among all the abilities a college student can develop, the ability to speak in public is one that will serve you for a lifetime. It decides whether your ideas are heard, whether your work is recognized, and even how confident you appear in job interviews. To develop this ability, three steps may help. To begin with, read widely and take notes, because you cannot speak clearly about what you have not understood. Moreover, seize every chance to practise, such as joining a debate club or answering questions in class, where mistakes are cheap and feedback is immediate. Finally, learn from good speakers by observing how they organize their ideas and how they control their voice and pace. Speaking ability is not a gift but a skill, and like every skill it grows through practice.",
    expressions: [
      { en: "serve sb. for a lifetime", cn: "让某人受益终生" },
      { en: "seize every chance to practise", cn: "抓住每个练习的机会" },
      { en: "immediate feedback", cn: "即时反馈" },
      { en: "organize one's ideas", cn: "组织思路" },
      { en: "not a gift but a skill", cn: "不是天赋而是技能" },
      { en: "grow through practice", cn: "在实践中成长" }
    ],
    upgrades: [
      { from: "important", to: "crucial", cn: "至关重要的" },
      { from: "chance", to: "opportunity", cn: "机会" },
      { from: "good", to: "capable", cn: "有能力的" },
      { from: "learn", to: "acquire", cn: "习得" },
      { from: "practice", to: "deliberate practice", cn: "刻意练习" }
    ],
    keywords: ["speaking ability", "confidence", "debate", "practice", "feedback", "interview"]
  },
  {
    id: "cet4-2024-sim-writing-independent-thinking",
    level: "cet4",
    year: "仿真",
    source: "自撰仿真题",
    verified: false,
    topic: "科技与素养",
    title: "信息时代更要独立思考",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of thinking independently in the age of information explosion. You should write at least 120 words but no more than 180 words.",
    outline: ["描述信息过载的现实", "说明独立思考的两点价值：不被误导、独立决策", "给出培养方法并收束"],
    sample: "The age of information has made independent thinking both harder and more necessary. Every day we are surrounded by headlines, short videos and recommendations that are designed to catch our attention rather than to inform us. Without the ability to judge, we easily become followers of whatever is popular. Developing this ability matters for two reasons. First, independent thinkers are less likely to be misled by false information, which spreads faster than facts online. Second, they can form their own opinions and make better decisions, from choosing a major to spending money wisely. To develop the ability, we should read from different sources, question the evidence behind a claim, and take time to think before sharing. In short, independent thinking is the best protection we can give ourselves in a noisy world.",
    expressions: [
      { en: "be surrounded by", cn: "被……包围" },
      { en: "catch one's attention", cn: "吸引某人的注意力" },
      { en: "be misled by false information", cn: "被虚假信息误导" },
      { en: "question the evidence behind a claim", cn: "质疑说法背后的证据" },
      { en: "form one's own opinions", cn: "形成自己的观点" },
      { en: "in a noisy world", cn: "在喧嚣的世界里" }
    ],
    upgrades: [
      { from: "think", to: "judge independently", cn: "独立判断" },
      { from: "a lot of", to: "an overwhelming amount of", cn: "海量的" },
      { from: "wrong", to: "misleading", cn: "误导性的" },
      { from: "decide", to: "make informed decisions", cn: "做出明智决定" },
      { from: "problem", to: "challenge", cn: "挑战" }
    ],
    keywords: ["information explosion", "independent thinking", "short video", "false information", "evidence", "decision"]
  },
  {
    id: "cet6-2023-06-writing-information",
    level: "cet6",
    year: "2023年6月",
    source: "https://cet6.koolearn.com/20230508/871985.html",
    verified: true,
    topic: "信息技术",
    title: "先进技术下的有用信息困境",
    prompt: "For this part, you are allowed 30 minutes to write a short essay based on the picture below. You should focus on the difficulty in acquiring useful information in spite of advanced information technology. You are required to write at least 150 words but no more than 200 words.",
    outline: ["描述图画内容并点出矛盾", "分析原因：信息真假混杂、误导性内容泛滥", "提出对策：学会评估信息"],
    sample: "The picture shows a conversation in which one person complains that although we have a lot of information technology, we do not have much useful information. This complaint points to a problem that almost every Internet user faces today. Information technology has undoubtedly brought us convenience. Search engines, databases and social platforms put the sum of human knowledge at our fingertips. However, quantity is not quality. When we search for a topic, useful material is mixed with advertisements, rumours and repeated content, and separating them costs us a great deal of time. Worse still, some websites deliberately spread misleading information to attract clicks, and readers who lack judgment may accept it as truth. Therefore, the real challenge is not how to obtain information but how to evaluate it. As college students, we should learn to check the source of what we read, compare different views and remain sceptical about shocking claims. Only in this way can information technology truly serve us.",
    expressions: [
      { en: "point to a problem", cn: "指向一个问题" },
      { en: "put sth. at our fingertips", cn: "使某物触手可及" },
      { en: "quantity is not quality", cn: "数量不等于质量" },
      { en: "spread misleading information", cn: "传播误导性信息" },
      { en: "remain sceptical about", cn: "对……保持怀疑" },
      { en: "check the source of what we read", cn: "核查所读内容的来源" }
    ],
    upgrades: [
      { from: "problem", to: "predicament", cn: "困境" },
      { from: "a lot of", to: "a huge amount of", cn: "大量的" },
      { from: "wrong", to: "inaccurate", cn: "不准确的" },
      { from: "get", to: "obtain", cn: "获取" },
      { from: "judge", to: "evaluate", cn: "评估" }
    ],
    keywords: ["information technology", "useful information", "search engine", "rumour", "evaluate", "source"]
  },
  {
    id: "cet6-2021-06-writing-higher-education",
    level: "cet6",
    year: "2021年6月",
    source: "https://cet6.koolearn.com/20210612/844844.html",
    verified: true,
    topic: "教育发展",
    title: "中国高等教育的成就",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay based on the chart below. You should start your essay with a brief description of the chart and comment on China's achievements in higher education. You should write at least 150 words but no more than 200 words.",
    outline: ["简述图表反映的高等教育规模增长", "分析原因：政府投入与经济发展需求", "指出挑战：数量之外更要质量"],
    sample: "The chart presents the remarkable development of higher education in China over the past decades. It shows that the number of students enrolled in colleges and universities has grown continuously, and that the gross enrolment rate has risen to a level which would have been unimaginable forty years ago. Several factors account for these achievements. The government has invested heavily in education and expanded campuses across the country, which enables young people from rural areas to receive training their parents could only dream of. Meanwhile, a growing economy has created strong demand for skilled graduates, giving families a powerful reason to support their children's studies. Parents, too, are far more willing to invest in education than they were a generation ago. Nevertheless, the chart also reminds us of the challenges ahead. Quantity should be matched by quality, so universities are expected to improve teaching, strengthen research and help graduates find positions that suit their abilities. With such efforts, higher education will continue to support the nation's development.",
    expressions: [
      { en: "present the remarkable development of", cn: "展示……的显著发展" },
      { en: "the gross enrolment rate", cn: "毛入学率" },
      { en: "account for", cn: "解释、构成" },
      { en: "invest heavily in", cn: "在……上大力投入" },
      { en: "be matched by", cn: "与……相匹配" },
      { en: "remind us of the challenges ahead", cn: "提醒我们前方面临的挑战" }
    ],
    upgrades: [
      { from: "big", to: "remarkable", cn: "显著的" },
      { from: "increase", to: "soar", cn: "飙升" },
      { from: "reason", to: "factor", cn: "因素" },
      { from: "help", to: "enable", cn: "使……能够" },
      { from: "problem", to: "challenge", cn: "挑战" }
    ],
    keywords: ["higher education", "enrolment", "chart", "government", "graduate", "quality"]
  },
  {
    id: "cet6-2018-06-writing-trust",
    level: "cet6",
    year: "2018年6月",
    source: "https://news.koolearn.com/20180616/1154582.html",
    verified: true,
    topic: "商业伦理",
    title: "商家与消费者之间的信任",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of building trust between businesses and consumers. You should write at least 150 words but no more than 200 words.",
    outline: ["指出信任是交易的基础", "对比有无信任的两种后果", "提出建立信任的具体做法"],
    sample: "Trust is the invisible foundation of every business transaction, and building trust between businesses and consumers has become a decisive factor in long-term success. When trust is absent, costs rise for both sides. Consumers hesitate, ask endless questions and turn to competitors at the first sign of trouble, while companies spend huge amounts of money on advertising that is not believed. When trust is present, however, the relationship works in the opposite way. Customers return without much persuasion, recommend the brand to friends and are even willing to pay a little more for a product they believe in. Building such trust requires concrete actions rather than slogans. Companies should be honest about the quality and limits of their products, respond quickly when problems appear, and protect the personal data they collect. Consumers, in turn, should reward honest businesses and report misconduct. A company that breaks its promises may gain a short-term profit, but it loses its customers for good. In the long run, trust is not a cost but the most valuable asset a company can possess.",
    expressions: [
      { en: "the invisible foundation of", cn: "……的无形基础" },
      { en: "a decisive factor in long-term success", cn: "长期成功的决定因素" },
      { en: "at the first sign of trouble", cn: "一出现麻烦迹象" },
      { en: "be willing to pay a little more", cn: "愿意多付一点钱" },
      { en: "concrete actions rather than slogans", cn: "具体行动而非口号" },
      { en: "the most valuable asset", cn: "最宝贵的资产" }
    ],
    upgrades: [
      { from: "important", to: "decisive", cn: "决定性的" },
      { from: "buy", to: "purchase", cn: "购买" },
      { from: "show", to: "demonstrate", cn: "表明" },
      { from: "money", to: "capital", cn: "资本" },
      { from: "keep", to: "preserve", cn: "维持" }
    ],
    keywords: ["trust", "business", "consumer", "brand", "data", "reputation"]
  },
  {
    id: "cet6-2017-12-writing-help-others",
    level: "cet6",
    year: "2017年12月",
    source: "https://cet4-6.xdf.cn/201712/10745320.html",
    verified: true,
    topic: "价值观",
    title: "帮助别人，才会被帮助",
    prompt: "For this part, you are allowed 30 minutes to write an essay commenting on the saying 'Help others, and you will be helped when you are in need.' You can cite examples to illustrate your views. You should write at least 150 words but no more than 200 words.",
    outline: ["引出谚语并给出自己的判断", "举例论证善意会循环、助人也能提升自己", "补充说明帮助应出于真心"],
    sample: "Help others, and you will be helped when you are in need. The saying sounds simple, yet it captures a truth about human society that is often forgotten in a competitive age. Helping others brings us benefits in at least two ways. To begin with, kindness circulates like water. A student who spends an afternoon explaining maths to a classmate may later find that the same classmate shares valuable notes with him; a passenger who offers his seat on a crowded bus may inspire others to do the same. These small acts build the trust on which any community depends. Moreover, helping others strengthens our own abilities. When we teach, we understand better; when we volunteer, we learn to communicate and to work with people from different backgrounds. Of course, help should be given sincerely, not as an investment. But a society in which people are willing to lend a hand is always warmer and safer for everyone, including ourselves.",
    expressions: [
      { en: "capture a truth about", cn: "道出关于……的真理" },
      { en: "kindness circulates like water", cn: "善意如水般流转" },
      { en: "build the trust on which sth. depends", cn: "建立某事物所依赖的信任" },
      { en: "strengthen our own abilities", cn: "增强自身能力" },
      { en: "be given sincerely, not as an investment", cn: "出于真心而非投资" },
      { en: "lend a hand", cn: "伸出援手" }
    ],
    upgrades: [
      { from: "help", to: "assist", cn: "帮助" },
      { from: "give", to: "offer", cn: "给予" },
      { from: "good", to: "beneficial", cn: "有益的" },
      { from: "many", to: "numerous", cn: "众多的" },
      { from: "true", to: "genuine", cn: "真正的" }
    ],
    keywords: ["help", "kindness", "community", "trust", "volunteer", "society"]
  },
  {
    id: "cet6-2016-12-writing-innovation",
    level: "cet6",
    year: "2016年12月",
    source: "https://news.koolearn.com/20161221/1106564.html",
    verified: true,
    topic: "创新",
    title: "创新的重要性与鼓励措施",
    prompt: "Directions: For this part, you are allowed 30 minutes to write a short essay on innovation. Your essay should include the importance of innovation and measures to be taken to encourage innovation. You are required to write at least 150 words but no more than 200 words.",
    outline: ["提出创新是发展与增长的动力", "论述创新的重要性：提高效率、解决难题", "给出鼓励创新的具体措施"],
    sample: "Innovation has become the engine of national development and personal growth. From mobile payment to electric vehicles, the products that shape our daily lives are all the results of creative thinking, and the countries that encourage innovation enjoy an obvious advantage in the global economy. The importance of innovation is easy to see. It raises productivity, creates new industries and offers solutions to pressing problems such as pollution and disease. Without it, an economy simply repeats what has been done before and eventually loses its vitality. To encourage innovation, governments should protect intellectual property, fund basic research and reduce unnecessary barriers for small companies. Universities ought to connect laboratories with real needs and reward teachers who guide students in creative projects. As individuals, we can begin by questioning routine, reading beyond textbooks and turning our curiosity into small experiments. In short, innovation is not the privilege of geniuses but the habit of a society that keeps asking what could be better.",
    expressions: [
      { en: "the engine of national development", cn: "国家发展的引擎" },
      { en: "enjoy an obvious advantage", cn: "拥有明显优势" },
      { en: "offer solutions to pressing problems", cn: "为紧迫问题提供解决方案" },
      { en: "protect intellectual property", cn: "保护知识产权" },
      { en: "turn curiosity into experiments", cn: "把好奇心变成实验" },
      { en: "the privilege of geniuses", cn: "天才的特权" }
    ],
    upgrades: [
      { from: "new", to: "innovative", cn: "创新的" },
      { from: "make", to: "generate", cn: "产生" },
      { from: "help", to: "facilitate", cn: "促进" },
      { from: "problem", to: "issue", cn: "问题" },
      { from: "important", to: "vital", cn: "至关重要的" }
    ],
    keywords: ["innovation", "creativity", "productivity", "intellectual property", "research", "curiosity"]
  },
  {
    id: "cet6-2020-12-writing-communication",
    level: "cet6",
    year: "2020年12月",
    source: "https://cet4-6.xdf.cn/202012/11134795.html",
    verified: true,
    topic: "个人素养",
    title: "为何要鼓励学生培养沟通能力",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on why students should be encouraged to develop effective communication skills. You should write at least 150 words but no more than 200 words.",
    outline: ["提出沟通能力是大学阶段最宝贵的能力之一", "论证：沟通让知识转化为机会、塑造性格", "呼吁学生刻意练习"],
    sample: "Effective communication skills are among the most valuable abilities a student can develop in college, and there are strong reasons why we should be encouraged to acquire them. First, communication determines what happens to the knowledge we possess. A student who understands a theory but cannot explain it clearly may lose the chance to share his ideas, while a modest speaker who organizes his thoughts well can persuade an entire audience. In the classroom, in a laboratory team and at a job interview, communication is often what turns competence into opportunity. Even the best idea remains invisible unless it is expressed in a way that others can follow. Second, training in communication improves our character. Learning to listen patiently, to disagree politely and to express difficult messages without hurting others makes us more considerate and more mature, and these qualities matter for a lifetime. Therefore, universities and students alike should take communication seriously, and every student should practise it deliberately rather than rely on talent alone.",
    expressions: [
      { en: "turn competence into opportunity", cn: "把能力转化为机会" },
      { en: "persuade an entire audience", cn: "说服全场听众" },
      { en: "organize one's thoughts well", cn: "很好地组织思路" },
      { en: "listen patiently", cn: "耐心倾听" },
      { en: "express difficult messages without hurting others", cn: "表达难言之语而不伤人" },
      { en: "rely on talent alone", cn: "仅靠天分" }
    ],
    upgrades: [
      { from: "talk", to: "communicate", cn: "沟通" },
      { from: "good", to: "effective", cn: "有效的" },
      { from: "get", to: "acquire", cn: "获得" },
      { from: "important", to: "vital", cn: "至关重要的" },
      { from: "practice", to: "practise deliberately", cn: "刻意练习" }
    ],
    keywords: ["communication skills", "college student", "interview", "listening", "character", "practice"]
  },
  {
    id: "cet6-2019-12-writing-social-responsibility",
    level: "cet6",
    year: "2019年12月",
    source: "https://mtoutiao.xdf.cn/cet4-6/201912/11010314.html",
    verified: true,
    topic: "社会责任",
    title: "社会责任感的重要性",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of having a sense of social responsibility. You should write at least 150 words but no more than 200 words.",
    outline: ["指出社会责任感是公民的重要品质", "举例说明其表现与价值", "提出培养途径"],
    sample: "Having a sense of social responsibility has long been regarded as one of the most important qualities of a good citizen, and in modern society it is more necessary than ever. Social responsibility means caring about more than one's own interests. It appears when a company refuses to cut costs by polluting a river, when a driver chooses not to park on the sidewalk, and when a student volunteers to help elderly neighbours. Such behaviour may bring no immediate reward, yet it protects the environment in which all of us live and work. A society made up of people who ignore their duties soon pays a heavy price in public health, safety and trust. Developing this sense should start early and be practised daily. Schools can tell students the stories of responsible citizens, families can encourage children to take part in community service, and each of us can begin with small things, such as keeping public places clean. Responsibility is not an empty slogan but a habit worth keeping.",
    expressions: [
      { en: "be regarded as one of the most important qualities", cn: "被视为最重要的品质之一" },
      { en: "care about more than one's own interests", cn: "不只关心个人利益" },
      { en: "bring no immediate reward", cn: "不会立刻带来回报" },
      { en: "pay a heavy price in", cn: "在……方面付出沉重代价" },
      { en: "take part in community service", cn: "参与社区服务" },
      { en: "an empty slogan", cn: "空洞的口号" }
    ],
    upgrades: [
      { from: "important", to: "essential", cn: "必不可少的" },
      { from: "help", to: "contribute to", cn: "有助于" },
      { from: "duty", to: "obligation", cn: "义务" },
      { from: "bad", to: "detrimental", cn: "有害的" },
      { from: "habit", to: "practice", cn: "习惯做法" }
    ],
    keywords: ["social responsibility", "citizen", "community service", "duty", "public health", "trust"]
  },
  {
    id: "cet6-2019-12-writing-family-responsibility",
    level: "cet6",
    year: "2019年12月",
    source: "https://mtoutiao.xdf.cn/cet4-6/201912/11005547.html",
    verified: true,
    topic: "家庭责任",
    title: "家庭责任感的重要性",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of having a sense of family responsibility. You should write at least 150 words but no more than 200 words.",
    outline: ["提出家庭责任感是温暖家庭的基础", "论述其具体表现与延伸影响", "给出培养家庭责任感的做法"],
    sample: "A sense of family responsibility is the foundation of a warm home, and the importance of developing it deserves serious attention. For most of us, the family is the first place where we learn to care about others. In a household, responsibility takes concrete forms. Children may wash the dishes, take out the rubbish or help their grandparents with shopping; parents try to share housework, respect each other's work and spend time with their children. These ordinary duties, repeated day after day, keep the family running smoothly and allow every member to feel secure. What is more, the habit of taking responsibility at home shapes how we behave elsewhere. A student who keeps his promises to his parents is likely to be reliable in his team and honest in his career. To strengthen this sense, parents should treat children as family members rather than guests, giving them duties suitable for their age, and families may hold regular talks to discuss plans and expectations. In short, a home is built not by love alone, but by love carried out in responsibility.",
    expressions: [
      { en: "the foundation of a warm home", cn: "温暖家庭的基础" },
      { en: "deserve serious attention", cn: "值得认真对待" },
      { en: "take concrete forms", cn: "以具体形式体现" },
      { en: "keep the family running smoothly", cn: "让家庭运转顺畅" },
      { en: "shape how we behave elsewhere", cn: "影响我们在别处的行为" },
      { en: "love carried out in responsibility", cn: "以责任体现的爱" }
    ],
    upgrades: [
      { from: "duty", to: "obligation", cn: "责任、义务" },
      { from: "always", to: "consistently", cn: "一贯地" },
      { from: "help", to: "share", cn: "分担" },
      { from: "good", to: "reliable", cn: "可靠的" },
      { from: "important", to: "significant", cn: "重要的" }
    ],
    keywords: ["family responsibility", "housework", "parents", "children", "promise", "home"]
  },
  {
    id: "cet6-2019-12-writing-community-responsibility",
    level: "cet6",
    year: "2019年12月",
    source: "https://mtoutiao.xdf.cn/cet4-6/201912/11005547.html",
    verified: true,
    topic: "社区责任",
    title: "社区责任感的重要性",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of having a sense of community responsibility. You should write at least 150 words but no more than 200 words.",
    outline: ["指出社区是日常生活的直接环境", "举例说明社区责任的表现与意义", "提出培养社区责任感的途径"],
    sample: "When we talk about responsibility, we usually think of the family or the workplace, yet a sense of community responsibility matters just as much, for the community is the immediate environment of our daily life. Community responsibility means caring about the shared space we live in. Those who possess it will, for instance, sort their waste properly, keep quiet at night, attend meetings about parking problems, and help neighbours who are old or ill. Such behaviour makes the neighbourhood cleaner, friendlier and safer. What is more, this sense rests on the understanding that the community is our common home rather than a stranger's place. When a resident takes care of the flowers in the courtyard, everyone is able to enjoy them. To develop such a sense, community activities should be better organized, and residents, especially college students, can join volunteer programmes or local meetings to know their neighbours. In brief, a strong community grows out of the willingness of each citizen to take responsibility for it.",
    expressions: [
      { en: "the immediate environment of our daily life", cn: "我们日常生活的直接环境" },
      { en: "care about the shared space", cn: "关心共用的空间" },
      { en: "sort waste properly", cn: "正确分类垃圾" },
      { en: "rest on the understanding that...", cn: "基于……的认识" },
      { en: "join volunteer programmes", cn: "参加志愿项目" },
      { en: "grow out of the willingness of", cn: "源自……的意愿" }
    ],
    upgrades: [
      { from: "place", to: "neighbourhood", cn: "社区、街区" },
      { from: "important", to: "essential", cn: "必不可少的" },
      { from: "help", to: "assist", cn: "帮助" },
      { from: "clean", to: "tidy", cn: "整洁的" },
      { from: "want", to: "be willing to", cn: "愿意" }
    ],
    keywords: ["community", "responsibility", "neighbourhood", "volunteer", "resident", "public space"]
  },
  {
    id: "cet6-2024-sim-writing-digital-literacy",
    level: "cet6",
    year: "仿真",
    source: "自撰仿真题",
    verified: false,
    topic: "数字素养",
    title: "数字素养为何不可或缺",
    prompt: "Directions: For this part, you are allowed 30 minutes to write an essay on the importance of digital literacy in the modern world. You should write at least 150 words but no more than 200 words.",
    outline: ["提出数字素养已如读写能力般重要", "从辨别信息、提高效率、保护自己三点论证", "指出技术不断更新，须持续学习"],
    sample: "Digital literacy has become as essential as reading and writing. In a world where information, services and even medical advice are delivered through screens, the ability to use digital tools wisely decides not only how well we study and work but also how safely we live. Digital literacy matters for several reasons. First, it enables us to evaluate what we encounter online. Anyone can publish a claim today, and a careful user compares sources, checks evidence and refuses to spread content that cannot be verified. Second, it improves our efficiency, for mastering spreadsheets, databases and collaborative platforms allows us to solve problems that used to require weeks of manual work. Third, it protects us. Understanding privacy settings, passwords and common frauds reduces the risk of losing money or personal data. To develop this literacy, students should practise with real tools, read critically and keep learning, since technologies in this field change faster than textbooks. In short, digital literacy deserves a firm place in the curriculum.",
    expressions: [
      { en: "be as essential as reading and writing", cn: "与读写能力同样重要" },
      { en: "refuse to spread content that cannot be verified", cn: "拒绝传播无法核实的内容" },
      { en: "improve our efficiency", cn: "提高效率" },
      { en: "require weeks of manual work", cn: "需要数周的人工劳动" },
      { en: "reduce the risk of losing personal data", cn: "降低个人数据泄露的风险" },
      { en: "deserve a firm place in the curriculum", cn: "理应在课程中占有一席之地" }
    ],
    upgrades: [
      { from: "use", to: "utilize", cn: "利用" },
      { from: "check", to: "verify", cn: "核实" },
      { from: "fast", to: "rapidly evolving", cn: "快速演进的" },
      { from: "important", to: "indispensable", cn: "不可或缺的" },
      { from: "learn", to: "keep learning", cn: "持续学习" }
    ],
    keywords: ["digital literacy", "privacy", "password", "fraud", "online information", "curriculum"]
  }
];
