window.TRANSLATION_MORE = [
  {
    "id": "cet6-2014-06-bj-pollution",
    "level": "cet6",
    "year": "2014年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202601/15083680.html",
    "verified": true,
    "topic": "环境与治理",
    "title": "北京治理污染",
    "source_text": "北京计划未来三年投资7600亿元治理污染，从减少PM2.5排放入手。这一新公布的计划旨在减少四种主要污染源，包括500多万辆机动车的尾气(exhaust)排放、周边地区燃煤、来自北方的沙尘暴和本地的建筑灰尘。另850亿元用于新建或升级城市垃圾处理和污水(sewage)处理设施，加上300亿元投资未来三年的植树造林(forestation)。市政府还计划建设一批水循环利用工厂，并制止违章建筑，以改善环境。另外，北京还将更严厉地处罚违反排放标准的行为。",
    "sentences": [
      {
        "cn": "北京计划未来三年投资7600亿元治理污染，从减少PM2.5排放入手。",
        "ref": "Beijing plans to invest 760 billion yuan in pollution control over the next three years, starting with reducing PM2.5 emissions.",
        "points": [
          "invest ... in pollution control 的搭配",
          "starting with 现在分词作伴随状语"
        ]
      },
      {
        "cn": "这一新公布的计划旨在减少四种主要污染源，包括500多万辆机动车的尾气(exhaust)排放、周边地区燃煤、来自北方的沙尘暴和本地的建筑灰尘。",
        "ref": "This newly announced plan aims to reduce four major sources of pollution, including exhaust emissions from more than 5 million motor vehicles, coal burning in surrounding areas, sandstorms from the north, and local construction dust.",
        "points": [
          "aim to do 表示目的",
          "including 后并列四项，注意 and 的位置"
        ]
      },
      {
        "cn": "另850亿元用于新建或升级城市垃圾处理和污水(sewage)处理设施，加上300亿元投资未来三年的植树造林(forestation)。",
        "ref": "Another 85 billion yuan will be used to build or upgrade urban waste treatment and sewage treatment facilities, and 30 billion yuan will be invested in forestation over the next three years.",
        "points": [
          "be used to do 与 be invested in 两种被动结构",
          "数字换算：850亿 = 85 billion"
        ]
      },
      {
        "cn": "市政府还计划建设一批水循环利用工厂，并制止违章建筑，以改善环境。",
        "ref": "The municipal government also plans to build a number of water recycling plants and stop illegal construction to improve the environment.",
        "points": [
          "a number of 表示若干",
          "to improve 不定式表目的"
        ]
      },
      {
        "cn": "另外，北京还将更严厉地处罚违反排放标准的行为。",
        "ref": "In addition, Beijing will impose more severe penalties on violations of emission limits.",
        "points": [
          "impose penalties on 固定搭配",
          "violations of emission limits 名词化处理"
        ]
      }
    ],
    "reference": "Beijing plans to invest 760 billion yuan in pollution control over the next three years, starting with reducing PM2.5 emissions. This newly announced plan aims to reduce four major sources of pollution, including exhaust emissions from more than 5 million motor vehicles, coal burning in surrounding areas, sandstorms from the north, and local construction dust. Another 85 billion yuan will be used to build or upgrade urban waste treatment and sewage treatment facilities, and 30 billion yuan will be invested in forestation over the next three years. The municipal government also plans to build a number of water recycling plants and stop illegal construction to improve the environment. In addition, Beijing will impose more severe penalties on violations of emission limits.",
    "keyWords": [
      {
        "w": "pollution control",
        "cn": "污染治理"
      },
      {
        "w": "emission",
        "cn": "排放（物）"
      },
      {
        "w": "exhaust",
        "cn": "尾气"
      },
      {
        "w": "sewage",
        "cn": "污水"
      },
      {
        "w": "forestation",
        "cn": "植树造林"
      },
      {
        "w": "municipal government",
        "cn": "市政府"
      },
      {
        "w": "penalty",
        "cn": "处罚"
      }
    ],
    "scoring": [
      "四种污染源全部译出，无漏译",
      "数字与单位（760 billion / 85 billion / 30 billion）准确",
      "被动语态与将来时统一"
    ],
    "pitfalls": [
      "把「850亿」误译为 85 million",
      "「植树造林」漏译或错译成 planting trees only",
      "「违章建筑」直译成 illegal buildings 而不加 construction"
    ]
  },
  {
    "id": "cet6-2014-06-hot-words",
    "level": "cet6",
    "year": "2014年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202601/15083680.html",
    "verified": true,
    "topic": "文化与艺术",
    "title": "中文热词",
    "source_text": "中文热词通常反映社会变化和文化，有些在外国媒体上愈来愈流行。例如，土豪(tuhao)和大妈(dama)都是老词，但已获得了新的意义。土豪以前指那些欺压佃农和仆人的乡村地主，现在用于指花钱如流水或者喜欢炫耀财富的人。也就是说，土豪有钱，但没有品位。大妈是对中年妇女的称呼，但现在特指不久前金价下跌时大量购买黄金的中国妇女。土豪和大妈可能会被收入新版牛津(Oxford)英语词典；至今已有约120个中文词被加进了牛津英语词典，成了英语语言的一部分。",
    "sentences": [
      {
        "cn": "中文热词通常反映社会变化和文化，有些在外国媒体上愈来愈流行。",
        "ref": "Chinese hot words usually reflect social changes and culture, and some are becoming increasingly popular in foreign media.",
        "points": [
          "reflect 后接并列宾语",
          "increasingly 修饰比较级意味的 popular"
        ]
      },
      {
        "cn": "例如，土豪(tuhao)和大妈(dama)都是老词，但已获得了新的意义。",
        "ref": "For example, tuhao and dama are old words, but they have acquired new meanings.",
        "points": [
          "acquire new meanings 搭配",
          "拼音词直接保留不翻译"
        ]
      },
      {
        "cn": "土豪以前指那些欺压佃农和仆人的乡村地主，现在用于指花钱如流水或者喜欢炫耀财富的人。",
        "ref": "Tuhao used to refer to rural landlords who oppressed tenant farmers and servants, but now it is used to refer to people who spend money recklessly or like to show off their wealth.",
        "points": [
          "used to do 表过去常常",
          "定语从句 who oppressed ... 与 who spend ... 并列"
        ]
      },
      {
        "cn": "也就是说，土豪有钱，但没有品位。",
        "ref": "That is to say, tuhao people are rich but have no taste.",
        "points": [
          "that is to say 作插入语",
          "have no taste 表没有品位"
        ]
      },
      {
        "cn": "大妈是对中年妇女的称呼，但现在特指不久前金价下跌时大量购买黄金的中国妇女。",
        "ref": "Dama is a term for middle-aged women, but now it specifically refers to Chinese women who bought large amounts of gold when the gold price dropped not long ago.",
        "points": [
          "a term for 表示称呼",
          "when 引导时间状语从句叠加在定语从句之后"
        ]
      },
      {
        "cn": "土豪和大妈可能会被收入新版牛津(Oxford)英语词典；至今已有约120个中文词被加进了牛津英语词典，成了英语语言的一部分。",
        "ref": "Tuhao and dama may be included in the new edition of the Oxford English Dictionary; so far, about 120 Chinese words have been added to it and have become part of the English language.",
        "points": [
          "be included in 被动语态",
          "so far 常与现在完成时连用"
        ]
      }
    ],
    "reference": "Chinese hot words usually reflect social changes and culture, and some are becoming increasingly popular in foreign media. For example, tuhao and dama are old words, but they have acquired new meanings. Tuhao used to refer to rural landlords who oppressed tenant farmers and servants, but now it is used to refer to people who spend money recklessly or like to show off their wealth. That is to say, tuhao people are rich but have no taste. Dama is a term for middle-aged women, but now it specifically refers to Chinese women who bought large amounts of gold when the gold price dropped not long ago. Tuhao and dama may be included in the new edition of the Oxford English Dictionary; so far, about 120 Chinese words have been added to it and have become part of the English language.",
    "keyWords": [
      {
        "w": "hot words",
        "cn": "热词"
      },
      {
        "w": "acquire",
        "cn": "获得"
      },
      {
        "w": "rural landlord",
        "cn": "乡村地主"
      },
      {
        "w": "oppress",
        "cn": "欺压"
      },
      {
        "w": "show off",
        "cn": "炫耀"
      },
      {
        "w": "specifically",
        "cn": "特指"
      },
      {
        "w": "the Oxford English Dictionary",
        "cn": "牛津英语词典"
      }
    ],
    "scoring": [
      "拼音词 tuhao / dama 保留原拼写",
      "过去与现在对比的时态转换正确",
      "「也就是说」等插入语译出"
    ],
    "pitfalls": [
      "把「土豪」硬译成 local tyrant 造成误解",
      "漏译「也就是说」导致逻辑断裂",
      "「约120个」漏掉 about 造成数字失真"
    ]
  },
  {
    "id": "cet6-2014-06-cas-report",
    "level": "cet6",
    "year": "2014年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202601/15083680.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "中科院年度报告",
    "source_text": "最近，中国科学院(Chinese Academy of Sciences)出版了关于其最新科学发现与未来一年展望的年度系列报告。系列报告包括三部分：科学发展报告、高技术发展报告、中国可持续发展战略报告。第一份报告包含中国科学家的最新发现，诸如新粒子研究与H7N9病毒的研究突破。该报告还突出强调了未来几年需要关注的问题。第二份报告公布了一些应用科学研究的热门领域，如3D打印和人造器官研究。第三份报告呼吁加强顶层设计，以消除工业升级中的结构性障碍，并促进节能减排。",
    "sentences": [
      {
        "cn": "最近，中国科学院(Chinese Academy of Sciences)出版了关于其最新科学发现与未来一年展望的年度系列报告。",
        "ref": "Recently, the Chinese Academy of Sciences has published a series of annual reports on its latest scientific discoveries and prospects for the coming year.",
        "points": [
          "a series of 后接复数名词",
          "reports on ... 介词搭配"
        ]
      },
      {
        "cn": "系列报告包括三部分：科学发展报告、高技术发展报告、中国可持续发展战略报告。",
        "ref": "The series of reports includes three parts: the Science Development Report, the High-Tech Development Report, and the China Sustainable Development Strategy Report.",
        "points": [
          "冒号后并列三个专有报告名",
          "专有名词首字母大写"
        ]
      },
      {
        "cn": "第一份报告包含中国科学家的最新发现，诸如新粒子研究与H7N9病毒的研究突破。",
        "ref": "The first report contains the latest discoveries of Chinese scientists, such as breakthroughs in new particle research and H7N9 virus research.",
        "points": [
          "such as 举例",
          "breakthroughs in ... 搭配"
        ]
      },
      {
        "cn": "该报告还突出强调了未来几年需要关注的问题。",
        "ref": "The report also highlights issues that need to be paid attention to in the next few years.",
        "points": [
          "highlight 表示突出强调",
          "need to be paid attention to 被动不定式"
        ]
      },
      {
        "cn": "第二份报告公布了一些应用科学研究的热门领域，如3D打印和人造器官研究。",
        "ref": "The second report announces some popular fields of applied scientific research, such as 3D printing and artificial organ research.",
        "points": [
          "applied scientific research 应用科学研究",
          "such as 列举"
        ]
      },
      {
        "cn": "第三份报告呼吁加强顶层设计，以消除工业升级中的结构性障碍，并促进节能减排。",
        "ref": "The third report calls for strengthening top-level design to eliminate structural obstacles in industrial upgrading and promote energy conservation and emission reduction.",
        "points": [
          "call for doing 呼吁做某事",
          "to eliminate ... and promote ... 并列目的"
        ]
      }
    ],
    "reference": "Recently, the Chinese Academy of Sciences has published a series of annual reports on its latest scientific discoveries and prospects for the coming year. The series of reports includes three parts: the Science Development Report, the High-Tech Development Report, and the China Sustainable Development Strategy Report. The first report contains the latest discoveries of Chinese scientists, such as breakthroughs in new particle research and H7N9 virus research. The report also highlights issues that need to be paid attention to in the next few years. The second report announces some popular fields of applied scientific research, such as 3D printing and artificial organ research. The third report calls for strengthening top-level design to eliminate structural obstacles in industrial upgrading and promote energy conservation and emission reduction.",
    "keyWords": [
      {
        "w": "annual report",
        "cn": "年度报告"
      },
      {
        "w": "prospect",
        "cn": "展望"
      },
      {
        "w": "breakthrough",
        "cn": "突破"
      },
      {
        "w": "highlight",
        "cn": "突出强调"
      },
      {
        "w": "applied research",
        "cn": "应用研究"
      },
      {
        "w": "top-level design",
        "cn": "顶层设计"
      },
      {
        "w": "energy conservation",
        "cn": "节能减排（节能）"
      }
    ],
    "scoring": [
      "三份报告名称译全",
      "「诸如 / 如」的举例结构统一",
      "动词 highlight / announce / call for 选择准确"
    ],
    "pitfalls": [
      "把「系列报告」译成 a series of report（单复数错）",
      "漏译「顶层设计」",
      "「节能减排」只译一半"
    ]
  },
  {
    "id": "cet6-2014-12-painting",
    "level": "cet6",
    "year": "2014年12月",
    "source": "https://mtoutiao.xdf.cn/www/94/202601/15083685.html",
    "verified": true,
    "topic": "文化与艺术",
    "title": "传统中国画",
    "source_text": "反映在艺术和文学中的乡村生活理想是中国文明的重要特征。这在很大程度上归功于道家(Taoist)对自然的情感。传统中国画有两个最受欢迎的主题：一是家庭生活的各种幸福场景，画中往往有老人在家喝茶下棋，男人在耕田收割，妇女在织布缝衣，小孩在户外玩耍。另一个则是乡村生活的种种乐趣，画作常常有渔夫在湖上打渔，农夫在山上砍柴采药，或是书生在松树下吟诗作画。这两个主题可以分别代表儒家(Confucian)和道家的生活理想。",
    "sentences": [
      {
        "cn": "反映在艺术和文学中的乡村生活理想是中国文明的重要特征。",
        "ref": "The ideal of rural life reflected in art and literature is an important feature of Chinese civilization.",
        "points": [
          "reflected in 过去分词作后置定语",
          "an important feature of 搭配"
        ]
      },
      {
        "cn": "这在很大程度上归功于道家(Taoist)对自然的情感。",
        "ref": "This is largely due to Taoist sentiment towards nature.",
        "points": [
          "be due to 表示归功于",
          "largely 副词位置"
        ]
      },
      {
        "cn": "传统中国画有两个最受欢迎的主题：一是家庭生活的各种幸福场景，画中往往有老人在家喝茶下棋，男人在耕田收割，妇女在织布缝衣，小孩在户外玩耍。",
        "ref": "There are two most popular themes in traditional Chinese paintings. One is various scenes of happiness in family life, in which there are often the elderly drinking tea and playing chess at home, men plowing and harvesting, women weaving and sewing, and children playing outdoors.",
        "points": [
          "there be 句型引出主题",
          "in which 定语从句 + 现在分词并列"
        ]
      },
      {
        "cn": "另一个则是乡村生活的种种乐趣，画作常常有渔夫在湖上打渔，农夫在山上砍柴采药，或是书生在松树下吟诗作画。",
        "ref": "The other is the pleasures of rural life, with paintings often showing fishermen fishing on the lake, farmers gathering firewood and collecting herbs on the mountain, or scholars chanting poems and painting under pine trees.",
        "points": [
          "the other 与 one 呼应",
          "with 复合结构补充说明画面"
        ]
      },
      {
        "cn": "这两个主题可以分别代表儒家(Confucian)和道家的生活理想。",
        "ref": "These two themes can respectively represent the Confucian and Taoist ideals of life.",
        "points": [
          "respectively 分别",
          "Confucian / Taoist 专有形容词"
        ]
      }
    ],
    "reference": "The ideal of rural life reflected in art and literature is an important feature of Chinese civilization. This is largely due to Taoist sentiment towards nature. There are two most popular themes in traditional Chinese paintings. One is various scenes of happiness in family life, in which there are often the elderly drinking tea and playing chess at home, men plowing and harvesting, women weaving and sewing, and children playing outdoors. The other is the pleasures of rural life, with paintings often showing fishermen fishing on the lake, farmers gathering firewood and collecting herbs on the mountain, or scholars chanting poems and painting under pine trees. These two themes can respectively represent the Confucian and Taoist ideals of life.",
    "keyWords": [
      {
        "w": "the ideal of rural life",
        "cn": "乡村生活理想"
      },
      {
        "w": "civilization",
        "cn": "文明"
      },
      {
        "w": "Taoist",
        "cn": "道家的"
      },
      {
        "w": "sentiment",
        "cn": "情感"
      },
      {
        "w": "Confucian",
        "cn": "儒家的"
      },
      {
        "w": "chant poems",
        "cn": "吟诗"
      },
      {
        "w": "respectively",
        "cn": "分别地"
      }
    ],
    "scoring": [
      "两个主题的结构对称（one ... the other ...）",
      "画中人物动作的现在分词并列准确",
      "中西文化专有词 Taoist / Confucian 拼写正确"
    ],
    "pitfalls": [
      "把「归功于」误译为 thanks for 等错误搭配",
      "「砍柴采药」漏译动词",
      "把「书生」译成 bookman 之类不地道表达"
    ]
  },
  {
    "id": "cet6-2014-12-market-economy",
    "level": "cet6",
    "year": "2014年12月",
    "source": "https://mtoutiao.xdf.cn/www/94/202601/15083685.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "市场经济与十二五规划",
    "source_text": "自从1978年启动改革以来，中国已从计划经济转为以市场为基础的经济，并经历了经济和社会的快速发展。年均10%的GDP增长使5亿多人脱贫。联合国《千年宣言》中的“中国将实现人均收入翻一番”的目标已在1997年实现。目前，中国的“十二五”规划强调发展服务业和解决环境及社会不平衡的问题。政府已设立目标减少污染，提高能源效率，改善获得教育和医疗的机会，并扩大社会保障。中国现在7%的经济增长目标表明政府在重视生活质量而不是增长速度。",
    "sentences": [
      {
        "cn": "自从1978年启动改革以来，中国已从计划经济转为以市场为基础的经济，并经历了经济和社会的快速发展。",
        "ref": "Since the reform was launched in 1978, China has transformed from a planned economy to a market-based economy and experienced rapid economic and social development.",
        "points": [
          "since 引导时间状语常配现在完成时",
          "transform from A to B 结构"
        ]
      },
      {
        "cn": "年均10%的GDP增长使5亿多人脱贫。",
        "ref": "An average annual GDP growth of 10% has lifted more than 500 million people out of poverty.",
        "points": [
          "lift ... out of poverty 脱贫",
          "an average annual growth of 10% 数字表达"
        ]
      },
      {
        "cn": "联合国《千年宣言》中的“中国将实现人均收入翻一番”的目标已在1997年实现。",
        "ref": "The goal in the United Nations Millennium Declaration that China would double its per capita income was achieved in 1997.",
        "points": [
          "同位语从句 that China would ...",
          "per capita income 人均收入"
        ]
      },
      {
        "cn": "目前，中国的“十二五”规划强调发展服务业和解决环境及社会不平衡的问题。",
        "ref": "At present, China's 12th Five-Year Plan emphasizes developing the service industry and addressing environmental and social imbalances.",
        "points": [
          "emphasize doing 结构",
          "address problems 处理问题"
        ]
      },
      {
        "cn": "政府已设立目标减少污染，提高能源效率，改善获得教育和医疗的机会，并扩大社会保障。",
        "ref": "The government has set goals to reduce pollution, improve energy efficiency, improve access to education and medical care, and expand social security.",
        "points": [
          "set goals to do 结构",
          "access to 后接名词"
        ]
      },
      {
        "cn": "中国现在7%的经济增长目标表明政府在重视生活质量而不是增长速度。",
        "ref": "China's current 7% economic growth target indicates that the government is focusing on the quality of life rather than the speed of growth.",
        "points": [
          "indicate that 宾语从句",
          "rather than 对比结构"
        ]
      }
    ],
    "reference": "Since the reform was launched in 1978, China has transformed from a planned economy to a market-based economy and experienced rapid economic and social development. An average annual GDP growth of 10% has lifted more than 500 million people out of poverty. The goal in the United Nations Millennium Declaration that China would double its per capita income was achieved in 1997. At present, China's 12th Five-Year Plan emphasizes developing the service industry and addressing environmental and social imbalances. The government has set goals to reduce pollution, improve energy efficiency, improve access to education and medical care, and expand social security. China's current 7% economic growth target indicates that the government is focusing on the quality of life rather than the speed of growth.",
    "keyWords": [
      {
        "w": "planned economy",
        "cn": "计划经济"
      },
      {
        "w": "market-based economy",
        "cn": "以市场为基础的经济"
      },
      {
        "w": "per capita income",
        "cn": "人均收入"
      },
      {
        "w": "the service industry",
        "cn": "服务业"
      },
      {
        "w": "energy efficiency",
        "cn": "能源效率"
      },
      {
        "w": "social security",
        "cn": "社会保障"
      },
      {
        "w": "rather than",
        "cn": "而不是"
      }
    ],
    "scoring": [
      "since 与现在完成时搭配",
      "数字表达（10% / 500 million / 7%）准确",
      "「十二五」译法统一"
    ],
    "pitfalls": [
      "把「翻一番」译成 increase twice",
      "「脱贫」漏译 out of poverty",
      "「而不是」误用 instead of 导致结构错误"
    ]
  },
  {
    "id": "cet6-2014-12-education-equity",
    "level": "cet6",
    "year": "2014年12月",
    "source": "https://mtoutiao.xdf.cn/www/94/202601/15083685.html",
    "verified": true,
    "topic": "社会与教育",
    "title": "教育公平",
    "source_text": "中国将努力确保到2015年就业者接受过平均13.3年的教育。如果这一目标得以实现，今后大部分进入劳动力市场的人都须获得大学文凭。在未来几年，中国将着力增加职业学院的招生人数；除了关注高等教育之外，还将寻找新的突破口确保教育制度更加公平。中国正在努力推进利用教育资源，这样农村和欠发达地区将获得更多的支持。教育部还决定改善欠发达地区学生的营养，并为外来务工人员的子女提供在城市接受教育的同等机会。",
    "sentences": [
      {
        "cn": "中国将努力确保到2015年就业者接受过平均13.3年的教育。",
        "ref": "China will strive to ensure that by 2015 the average years of education received by employed people will reach 13.3.",
        "points": [
          "strive to ensure that 结构",
          "received by 过去分词作定语"
        ]
      },
      {
        "cn": "如果这一目标得以实现，今后大部分进入劳动力市场的人都须获得大学文凭。",
        "ref": "If this goal is achieved, most people entering the labor market in the future will have to obtain a college diploma.",
        "points": [
          "if 条件状语从句的被动",
          "entering the labor market 现在分词作定语"
        ]
      },
      {
        "cn": "在未来几年，中国将着力增加职业学院的招生人数；除了关注高等教育之外，还将寻找新的突破口确保教育制度更加公平。",
        "ref": "In the next few years, China will focus on increasing the enrollment of vocational colleges. In addition to paying attention to higher education, it will also seek new breakthroughs to ensure a more equitable education system.",
        "points": [
          "focus on doing 结构",
          "in addition to + 名词 / 动名词"
        ]
      },
      {
        "cn": "中国正在努力推进利用教育资源，这样农村和欠发达地区将获得更多的支持。",
        "ref": "China is working hard to make the best use of educational resources so that rural and underdeveloped areas will receive more support.",
        "points": [
          "make the best use of 充分利用",
          "so that 引导目的状语从句"
        ]
      },
      {
        "cn": "教育部还决定改善欠发达地区学生的营养，并为外来务工人员的子女提供在城市接受教育的同等机会。",
        "ref": "The Ministry of Education has also decided to improve the nutrition of students in underdeveloped areas and provide equal opportunities for the children of migrant workers to receive education in cities.",
        "points": [
          "decide to do 结构",
          "provide equal opportunities for sb. to do"
        ]
      }
    ],
    "reference": "China will strive to ensure that by 2015 the average years of education received by employed people will reach 13.3. If this goal is achieved, most people entering the labor market in the future will have to obtain a college diploma. In the next few years, China will focus on increasing the enrollment of vocational colleges. In addition to paying attention to higher education, it will also seek new breakthroughs to ensure a more equitable education system. China is working hard to make the best use of educational resources so that rural and underdeveloped areas will receive more support. The Ministry of Education has also decided to improve the nutrition of students in underdeveloped areas and provide equal opportunities for the children of migrant workers to receive education in cities.",
    "keyWords": [
      {
        "w": "strive to",
        "cn": "努力"
      },
      {
        "w": "labor market",
        "cn": "劳动力市场"
      },
      {
        "w": "diploma",
        "cn": "文凭"
      },
      {
        "w": "enrollment",
        "cn": "招生人数"
      },
      {
        "w": "vocational college",
        "cn": "职业学院"
      },
      {
        "w": "equitable",
        "cn": "公平的"
      },
      {
        "w": "migrant worker",
        "cn": "外来务工人员"
      }
    ],
    "scoring": [
      "will / will have to 等将来时统一",
      "职业教育、劳动力市场等教育类术语译准",
      "目的状语（so that / to ensure）合法"
    ],
    "pitfalls": [
      "把「13.3年」写成 13,3 年（标点错误）",
      "「职业学院的招生人数」漏掉 enrollment",
      "「欠发达地区」误译成 developing areas"
    ]
  },
  {
    "id": "cet6-2016-12-tourism",
    "level": "cet6",
    "year": "2016年12月",
    "source": "https://www.xdf.cn/94/202601/15084325.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "度假旅游",
    "source_text": "随着生活水平的提高，度假在中国人生活中的作用越来越重要。过去，中国人的时间主要花在谋生上，很少有机会外出旅游。然而，近年来中国旅游业发展迅速。经济的繁荣和富裕中产阶级的出现，引发了一个前所未有的旅游热潮。中国人不仅在国内旅游，出国旅游也越来越普遍。2016年国庆假期旅游总消费超过4000亿元。据世界贸易组织估计，中国有望到2020年成为世界最大的旅游国家，未来几年将成为出境旅游支出增长最快的国家。",
    "sentences": [
      {
        "cn": "随着生活水平的提高，度假在中国人生活中的作用越来越重要。",
        "ref": "With the improvement of living standards, the role of vacations in the lives of Chinese people is becoming increasingly important.",
        "points": [
          "with 复合结构表伴随",
          "play a role → the role ... is becoming"
        ]
      },
      {
        "cn": "过去，中国人的时间主要花在谋生上，很少有机会外出旅游。",
        "ref": "In the past, Chinese people spent most of their time making a living and had few opportunities to travel.",
        "points": [
          "spend time doing 结构",
          "few 表否定含义"
        ]
      },
      {
        "cn": "然而，近年来中国旅游业发展迅速。",
        "ref": "However, in recent years, China's tourism industry has developed rapidly.",
        "points": [
          "in recent years 配现在完成时",
          "rapidly 副词修饰 develop"
        ]
      },
      {
        "cn": "经济的繁荣和富裕中产阶级的出现，引发了一个前所未有的旅游热潮。",
        "ref": "The economic boom and the emergence of a prosperous middle class have triggered an unprecedented travel boom.",
        "points": [
          "名词化主语 + emerge 的名词 emergence",
          "trigger 引发"
        ]
      },
      {
        "cn": "中国人不仅在国内旅游，出国旅游也越来越普遍。",
        "ref": "Chinese people are not only traveling within the country, but international tourism is also becoming more and more common.",
        "points": [
          "not only ... but also ... 的倒装式表达",
          "within the country 国内"
        ]
      },
      {
        "cn": "2016年国庆假期旅游总消费超过4000亿元。据世界贸易组织估计，中国有望到2020年成为世界最大的旅游国家，未来几年将成为出境旅游支出增长最快的国家。",
        "ref": "During the National Day holiday in 2016, total tourism consumption exceeded 400 billion yuan. According to estimates by the World Trade Organization, China is expected to become the world's largest tourism country by 2020 and will be the fastest-growing country in terms of outbound tourism expenditure in the coming years.",
        "points": [
          "be expected to do 有望做某事",
          "in terms of 就……而言"
        ]
      }
    ],
    "reference": "With the improvement of living standards, the role of vacations in the lives of Chinese people is becoming increasingly important. In the past, Chinese people spent most of their time making a living and had few opportunities to travel. However, in recent years, China's tourism industry has developed rapidly. The economic boom and the emergence of a prosperous middle class have triggered an unprecedented travel boom. Chinese people are not only traveling within the country, but international tourism is also becoming more and more common. During the National Day holiday in 2016, total tourism consumption exceeded 400 billion yuan. According to estimates by the World Trade Organization, China is expected to become the world's largest tourism country by 2020 and will be the fastest-growing country in terms of outbound tourism expenditure in the coming years.",
    "keyWords": [
      {
        "w": "living standards",
        "cn": "生活水平"
      },
      {
        "w": "make a living",
        "cn": "谋生"
      },
      {
        "w": "tourism industry",
        "cn": "旅游业"
      },
      {
        "w": "middle class",
        "cn": "中产阶级"
      },
      {
        "w": "unprecedented",
        "cn": "前所未有的"
      },
      {
        "w": "outbound tourism",
        "cn": "出境旅游"
      },
      {
        "w": "expenditure",
        "cn": "支出"
      }
    ],
    "scoring": [
      "「随着……越来越……」句式译出",
      "数字 4000亿元 单位换算准确",
      "「旅游热潮」「出境旅游」术语地道"
    ],
    "pitfalls": [
      "把「4000亿元」写成 400 billion 少一位",
      "「谋生」误译成 make money",
      "「世界贸易组织」专有名词漏译"
    ]
  },
  {
    "id": "cet6-2016-12-chinese-learning",
    "level": "cet6",
    "year": "2016年12月",
    "source": "https://www.xdf.cn/94/202601/15084325.html",
    "verified": true,
    "topic": "社会与教育",
    "title": "汉语学习热",
    "source_text": "随着中国经济的蓬勃发展，学汉语的人数迅速增长，使汉语成了世界上人们最喜爱的语言之一。近年来，中国大学在国际上的排名也有了明显的提高。由于中国教育的巨大进步，中国成为最受海外学生欢迎的留学目的地之一就不足为奇了。2015年，近40万留学生涌入中国学习。他们学习的科目已不再限于中国语言和文化，而包括科学与工程。尽管美国和英国仍占全球教育市场的主导地位，但中国正在迅速赶上。",
    "sentences": [
      {
        "cn": "随着中国经济的蓬勃发展，学汉语的人数迅速增长，使汉语成了世界上人们最喜爱的语言之一。",
        "ref": "With the vigorous development of China's economy, the number of people learning Chinese is increasing rapidly, making Chinese one of the most popular languages in the world.",
        "points": [
          "the number of + 复数名词 + 单数谓语",
          "making ... 现在分词作结果状语"
        ]
      },
      {
        "cn": "近年来，中国大学在国际上的排名也有了明显的提高。",
        "ref": "In recent years, the ranking of Chinese universities in the world has also improved significantly.",
        "points": [
          "the ranking of ... in the world",
          "现在完成时表变化"
        ]
      },
      {
        "cn": "由于中国教育的巨大进步，中国成为最受海外学生欢迎的留学目的地之一就不足为奇了。",
        "ref": "It is no surprise that China has become one of the most popular study destinations for international students, thanks to the great progress of Chinese education.",
        "points": [
          "it is no surprise that 形式主语",
          "thanks to 由于"
        ]
      },
      {
        "cn": "2015年，近40万留学生涌入中国学习。",
        "ref": "In 2015, nearly 400,000 international students flocked to China to study.",
        "points": [
          "flock to 涌入",
          "数字表达 400,000"
        ]
      },
      {
        "cn": "他们学习的科目已不再限于中国语言和文化，而包括科学与工程。",
        "ref": "The subjects they study are no longer limited to Chinese language and culture, but also include science and engineering.",
        "points": [
          "be limited to 局限于",
          "no longer ... but also ... 对比"
        ]
      },
      {
        "cn": "尽管美国和英国仍占全球教育市场的主导地位，但中国正在迅速赶上。",
        "ref": "Although the United States and the United Kingdom still dominate the global education market, China is catching up quickly.",
        "points": [
          "although 让步状语从句不倒装",
          "dominate 作动词"
        ]
      }
    ],
    "reference": "With the vigorous development of China's economy, the number of people learning Chinese is increasing rapidly, making Chinese one of the most popular languages in the world. In recent years, the ranking of Chinese universities in the world has also improved significantly. It is no surprise that China has become one of the most popular study destinations for international students, thanks to the great progress of Chinese education. In 2015, nearly 400,000 international students flocked to China to study. The subjects they study are no longer limited to Chinese language and culture, but also include science and engineering. Although the United States and the United Kingdom still dominate the global education market, China is catching up quickly.",
    "keyWords": [
      {
        "w": "vigorous",
        "cn": "蓬勃的"
      },
      {
        "w": "ranking",
        "cn": "排名"
      },
      {
        "w": "study destination",
        "cn": "留学目的地"
      },
      {
        "w": "flock to",
        "cn": "涌入"
      },
      {
        "w": "be limited to",
        "cn": "局限于"
      },
      {
        "w": "dominate",
        "cn": "主导"
      },
      {
        "w": "catch up",
        "cn": "赶上"
      }
    ],
    "scoring": [
      "「之一」用 one of the + 最高级 + 复数",
      "主语 number 与谓语单复数一致",
      "as / although 引导从句结构完整"
    ],
    "pitfalls": [
      "the number of people 后谓语误用复数",
      "漏译「之一」",
      "把「科学与工程」译成 science and engineering 之外的自造词"
    ]
  },
  {
    "id": "cet6-2016-12-agriculture",
    "level": "cet6",
    "year": "2016年12月",
    "source": "https://www.xdf.cn/94/202601/15084325.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "中国农业",
    "source_text": "农业是中国的一个重要产业，从业者超过3亿。中国农业产量全球第一，主要生产水稻、小麦和豆类。虽然中国的农业用地仅占世界的百分之十，但为世界百分之二十的人口提供了粮食。中国早在7700年前就开始种植水稻。早在使用机械化和化肥之前，勤劳和有创造性的中国农民就已经采用各种各样的方法来增加农作物产量。中国农业的最新发展是推进有机农业。有机农业可以同时服务于多种目的，包括食品安全、大众健康和可持续发展。",
    "sentences": [
      {
        "cn": "农业是中国的一个重要产业，从业者超过3亿。",
        "ref": "Agriculture is an important industry in China, with over 300 million practitioners.",
        "points": [
          "with 复合结构补充数据",
          "practitioner 从业者"
        ]
      },
      {
        "cn": "中国农业产量全球第一，主要生产水稻、小麦和豆类。",
        "ref": "China ranks first in the world in terms of agricultural output, mainly producing rice, wheat, and beans.",
        "points": [
          "rank first in 排名第一",
          "现在分词 producing 补充说明"
        ]
      },
      {
        "cn": "虽然中国的农业用地仅占世界的百分之十，但为世界百分之二十的人口提供了粮食。",
        "ref": "Although China's agricultural land only accounts for 10% of the world's total, it feeds 20% of the global population.",
        "points": [
          "account for 占（比例）",
          "feed 养活 / 供养"
        ]
      },
      {
        "cn": "中国早在7700年前就开始种植水稻。",
        "ref": "China began cultivating rice as early as 7,700 years ago.",
        "points": [
          "begin doing 结构",
          "as early as 早在"
        ]
      },
      {
        "cn": "早在使用机械化和化肥之前，勤劳和有创造性的中国农民就已经采用各种各样的方法来增加农作物产量。",
        "ref": "Long before the use of machinery and chemical fertilizers, diligent and creative Chinese farmers had already adopted a variety of methods to increase crop yields.",
        "points": [
          "long before 引导时间状语",
          "过去完成时 had adopted"
        ]
      },
      {
        "cn": "中国农业的最新发展是推进有机农业。有机农业可以同时服务于多种目的，包括食品安全、大众健康和可持续发展。",
        "ref": "The latest development in Chinese agriculture is the promotion of organic farming. Organic agriculture can serve multiple purposes, including food safety, public health, and sustainable development.",
        "points": [
          "the promotion of 名词化",
          "serve purposes 服务于目的"
        ]
      }
    ],
    "reference": "Agriculture is an important industry in China, with over 300 million practitioners. China ranks first in the world in terms of agricultural output, mainly producing rice, wheat, and beans. Although China's agricultural land only accounts for 10% of the world's total, it feeds 20% of the global population. China began cultivating rice as early as 7,700 years ago. Long before the use of machinery and chemical fertilizers, diligent and creative Chinese farmers had already adopted a variety of methods to increase crop yields. The latest development in Chinese agriculture is the promotion of organic farming. Organic agriculture can serve multiple purposes, including food safety, public health, and sustainable development.",
    "keyWords": [
      {
        "w": "agriculture",
        "cn": "农业"
      },
      {
        "w": "practitioner",
        "cn": "从业者"
      },
      {
        "w": "agricultural output",
        "cn": "农业产量"
      },
      {
        "w": "fertilizer",
        "cn": "化肥"
      },
      {
        "w": "crop yield",
        "cn": "农作物产量"
      },
      {
        "w": "organic farming",
        "cn": "有机农业"
      },
      {
        "w": "sustainable development",
        "cn": "可持续发展"
      }
    ],
    "scoring": [
      "比例表达（10% / 20%）准确",
      "过去完成时与时间状语搭配",
      "农业类术语（产量 / 化肥 / 有机农业）译准"
    ],
    "pitfalls": [
      "「7700年前」数字写成 7.700 等错误格式",
      "「仅占」漏掉 only 导致语气失真",
      "把「大众健康」误译成 public healthy"
    ]
  },
  {
    "id": "cet6-2018-06-private-cars",
    "level": "cet6",
    "year": "2018年6月",
    "source": "https://www.xdf.cn/94/202601/15084379.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "私家车与新能源汽车",
    "source_text": "过去，拥有一种私家车对大部分中国人而言是件奢侈的事。如今，私家车在中国随处可见。汽车成了人们生活中不可或缺的一部分。人们不仅开车上下班，还经常驾车出游。有些城市的汽车增长速度过快，以至于交通拥堵和停车位不足的问题日益严重。因此，这些城市的市政府不得不出台新规，限制上路汽车的数目。由于空气污染日益严重，现在越来越多的人选择购买新能源汽车。中国政府也采取了一系列措施，支持新能源汽车的发展。",
    "sentences": [
      {
        "cn": "过去，拥有一种私家车对大部分中国人而言是件奢侈的事。如今，私家车在中国随处可见。",
        "ref": "In the past, owning a private car was a luxury for most Chinese people. Today, private cars are ubiquitous in China.",
        "points": [
          "动名词 owning 作主语",
          "ubiquitous 相当于 everywhere"
        ]
      },
      {
        "cn": "汽车成了人们生活中不可或缺的一部分。",
        "ref": "Cars have become an indispensable part of people's lives.",
        "points": [
          "an indispensable part of 搭配",
          "现在完成时表状态变化"
        ]
      },
      {
        "cn": "人们不仅开车上下班，还经常驾车出游。",
        "ref": "People not only drive to and from work but also frequently take road trips for leisure.",
        "points": [
          "not only ... but also ... 并列谓语",
          "take road trips 自驾出游"
        ]
      },
      {
        "cn": "有些城市的汽车增长速度过快，以至于交通拥堵和停车位不足的问题日益严重。",
        "ref": "In some cities, the rapid growth of automobiles has led to increasingly severe problems of traffic congestion and insufficient parking spaces.",
        "points": [
          "so ... that 语义改为 lead to",
          "increasingly severe 日益严重"
        ]
      },
      {
        "cn": "因此，这些城市的市政府不得不出台新规，限制上路汽车的数目。",
        "ref": "As a result, the municipal governments of these cities have had to introduce new regulations to limit the number of cars on the road.",
        "points": [
          "have had to 不得不",
          "introduce regulations 出台规定"
        ]
      },
      {
        "cn": "由于空气污染日益严重，现在越来越多的人选择购买新能源汽车。中国政府也采取了一系列措施，支持新能源汽车的发展。",
        "ref": "With the worsening air pollution, more and more people are now choosing to purchase new energy vehicles. The Chinese government has also taken a series of measures to support the development of new energy vehicles.",
        "points": [
          "with + 名词短语表原因",
          "take measures to do 采取措施"
        ]
      }
    ],
    "reference": "In the past, owning a private car was a luxury for most Chinese people. Today, private cars are ubiquitous in China. Cars have become an indispensable part of people's lives. People not only drive to and from work but also frequently take road trips for leisure. In some cities, the rapid growth of automobiles has led to increasingly severe problems of traffic congestion and insufficient parking spaces. As a result, the municipal governments of these cities have had to introduce new regulations to limit the number of cars on the road. With the worsening air pollution, more and more people are now choosing to purchase new energy vehicles. The Chinese government has also taken a series of measures to support the development of new energy vehicles.",
    "keyWords": [
      {
        "w": "private car",
        "cn": "私家车"
      },
      {
        "w": "luxury",
        "cn": "奢侈的事"
      },
      {
        "w": "ubiquitous",
        "cn": "随处可见的"
      },
      {
        "w": "indispensable",
        "cn": "不可或缺的"
      },
      {
        "w": "traffic congestion",
        "cn": "交通拥堵"
      },
      {
        "w": "new energy vehicle",
        "cn": "新能源汽车"
      },
      {
        "w": "municipal government",
        "cn": "市政府"
      }
    ],
    "scoring": [
      "过去与现在对比的时态（was / have become）正确",
      "not only ... but also ... 结构完整",
      "「新能源汽车」专有译法统一"
    ],
    "pitfalls": [
      "把「不得不」译成 must 丢失不得已含义",
      "「停车位不足」漏译 insufficient",
      "「一系列措施」漏掉 a series of"
    ]
  },
  {
    "id": "cet6-2018-06-high-speed-rail",
    "level": "cet6",
    "year": "2018年6月",
    "source": "https://www.xdf.cn/94/202601/15084379.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "中国高铁",
    "source_text": "中国目前拥有世界上最大最快的高速铁路网。高速列车的运行速度还将继续提升，更多的城市计划修建高铁站。高铁大大缩短了人们出行的时间。与航空相比，高铁的一大标准优势是其准点性，因为它基本不受天气或交通管制的影响。高铁极大地改变了中国人的生活方式。如今，它已经成了很多人商务旅行的首选交通工具。越来越多的人也在假日选择乘坐高铁外出旅游。还有不少年轻人选择在一个城市工作而住在邻近城市，每天乘坐高铁上下班。",
    "sentences": [
      {
        "cn": "中国目前拥有世界上最大最快的高速铁路网。",
        "ref": "China currently possesses the world's largest and fastest high-speed rail network.",
        "points": [
          "最高级并列 the largest and fastest",
          "possess 拥有"
        ]
      },
      {
        "cn": "高速列车的运行速度还将继续提升，更多的城市计划修建高铁站。",
        "ref": "The operational speeds of high-speed trains are still set to increase, and more cities are planning to build high-speed rail stations.",
        "points": [
          "be set to do 有望 / 将会",
          "plan to do 计划做"
        ]
      },
      {
        "cn": "高铁大大缩短了人们出行的时间。",
        "ref": "High-speed rail has significantly reduced travel time for people.",
        "points": [
          "significantly 大大地",
          "现在完成时表影响"
        ]
      },
      {
        "cn": "与航空相比，高铁的一大标准优势是其准点性，因为它基本不受天气或交通管制的影响。",
        "ref": "Compared with air travel, the standard advantage of high-speed rail is its punctuality, as it is largely unaffected by weather or traffic control.",
        "points": [
          "compared with 与……相比",
          "be unaffected by 不受影响"
        ]
      },
      {
        "cn": "高铁极大地改变了中国人的生活方式。如今，它已经成了很多人商务旅行的首选交通工具。",
        "ref": "High-speed rail has greatly changed the lifestyle of Chinese people. Nowadays, it has become the preferred mode of transportation for many people's business trips.",
        "points": [
          "the preferred mode of transportation 首选交通工具",
          "现在完成时表结果"
        ]
      },
      {
        "cn": "越来越多的人也在假日选择乘坐高铁外出旅游。还有不少年轻人选择在一个城市工作而住在邻近城市，每天乘坐高铁上下班。",
        "ref": "An increasing number of people also choose to travel by high-speed rail during holidays. Moreover, many young people opt to work in one city and live in a neighboring city, commuting daily by high-speed rail.",
        "points": [
          "an increasing number of + 复数",
          "commuting 现在分词作方式状语"
        ]
      }
    ],
    "reference": "China currently possesses the world's largest and fastest high-speed rail network. The operational speeds of high-speed trains are still set to increase, and more cities are planning to build high-speed rail stations. High-speed rail has significantly reduced travel time for people. Compared with air travel, the standard advantage of high-speed rail is its punctuality, as it is largely unaffected by weather or traffic control. High-speed rail has greatly changed the lifestyle of Chinese people. Nowadays, it has become the preferred mode of transportation for many people's business trips. An increasing number of people also choose to travel by high-speed rail during holidays. Moreover, many young people opt to work in one city and live in a neighboring city, commuting daily by high-speed rail.",
    "keyWords": [
      {
        "w": "high-speed rail network",
        "cn": "高速铁路网"
      },
      {
        "w": "operational speed",
        "cn": "运行速度"
      },
      {
        "w": "punctuality",
        "cn": "准点性"
      },
      {
        "w": "traffic control",
        "cn": "交通管制"
      },
      {
        "w": "preferred",
        "cn": "首选的"
      },
      {
        "w": "neighboring city",
        "cn": "邻近城市"
      },
      {
        "w": "commute",
        "cn": "通勤"
      }
    ],
    "scoring": [
      "比较结构（compared with）正确",
      "现在完成时贯穿全文",
      "「准点性」「交通管制」术语准确"
    ],
    "pitfalls": [
      "把「准点性」写成 on time（词性错误）",
      "「越来越多人」误用 more and more people are 单复数混乱",
      "漏译「标准优势」中的 standard"
    ]
  },
  {
    "id": "cet6-2018-06-shared-bikes",
    "level": "cet6",
    "year": "2018年6月",
    "source": "https://www.xdf.cn/94/202601/15084379.html",
    "verified": true,
    "topic": "经济与科技",
    "title": "共享单车",
    "source_text": "自行车曾经是中国城乡最主要的交通工具，中国一度被称为“自行车王国”。如今，随着城市交通拥挤和空气污染日益严重，骑自行车又开始流行起来。近来，中国企业家将移动互联网技术与传统自行车结合在一起，发明了一种称为共享单车的商业模式。共享单车的出现使得骑行更加方便。人们仅需用一部智能手机就可以随时使用共享单车。为了鼓励人们骑行，很多城市建立了自行车道。现在，越来越多的中国人也喜欢通过骑车健身。",
    "sentences": [
      {
        "cn": "自行车曾经是中国城乡最主要的交通工具，中国一度被称为“自行车王国”。",
        "ref": "Bicycles used to be the predominant means of transportation in both urban and rural areas of China, and the country was once dubbed the Kingdom of Bicycles.",
        "points": [
          "used to be 表过去状态",
          "be dubbed 被称为"
        ]
      },
      {
        "cn": "如今，随着城市交通拥挤和空气污染日益严重，骑自行车又开始流行起来。",
        "ref": "Nowadays, with increasing urban traffic congestion and worsening air pollution, cycling is regaining popularity.",
        "points": [
          "with + 名词短语表原因",
          "regain popularity 重新流行"
        ]
      },
      {
        "cn": "近来，中国企业家将移动互联网技术与传统自行车结合在一起，发明了一种称为共享单车的商业模式。",
        "ref": "Recently, Chinese entrepreneurs have combined mobile internet technology with traditional bicycles to create a business model known as shared bicycles.",
        "points": [
          "combine A with B 结构",
          "known as 过去分词作定语"
        ]
      },
      {
        "cn": "共享单车的出现使得骑行更加方便。人们仅需用一部智能手机就可以随时使用共享单车。",
        "ref": "The emergence of shared bicycles has made cycling more convenient. People can access a bike anytime using just a smartphone.",
        "points": [
          "make + 宾语 + 形容词",
          "using 现在分词作方式状语"
        ]
      },
      {
        "cn": "为了鼓励人们骑行，很多城市建立了自行车道。",
        "ref": "To encourage cycling, many cities have built dedicated bike lanes.",
        "points": [
          "to do 置于句首表目的",
          "dedicated bike lane 专用自行车道"
        ]
      },
      {
        "cn": "现在，越来越多的中国人也喜欢通过骑车健身。",
        "ref": "Nowadays, more and more Chinese people also enjoy cycling as a form of exercise.",
        "points": [
          "enjoy doing 结构",
          "as a form of exercise 作为锻炼方式"
        ]
      }
    ],
    "reference": "Bicycles used to be the predominant means of transportation in both urban and rural areas of China, and the country was once dubbed the Kingdom of Bicycles. Nowadays, with increasing urban traffic congestion and worsening air pollution, cycling is regaining popularity. Recently, Chinese entrepreneurs have combined mobile internet technology with traditional bicycles to create a business model known as shared bicycles. The emergence of shared bicycles has made cycling more convenient. People can access a bike anytime using just a smartphone. To encourage cycling, many cities have built dedicated bike lanes. Nowadays, more and more Chinese people also enjoy cycling as a form of exercise.",
    "keyWords": [
      {
        "w": "predominant",
        "cn": "最主要的"
      },
      {
        "w": "be dubbed",
        "cn": "被称为"
      },
      {
        "w": "congestion",
        "cn": "拥挤"
      },
      {
        "w": "entrepreneur",
        "cn": "企业家"
      },
      {
        "w": "emergence",
        "cn": "出现"
      },
      {
        "w": "bike lane",
        "cn": "自行车道"
      },
      {
        "w": "mobile internet",
        "cn": "移动互联网"
      }
    ],
    "scoring": [
      "「一度被称为」被动语态译出",
      "combine / make 等动词结构正确",
      "共享单车统一译 shared bicycles"
    ],
    "pitfalls": [
      "把「自行车王国」直译成 bicycle kingdom 不用 Kingdom of Bicycles 亦可但需首字母大写统一",
      "漏译「商业模式」",
      "「移动互联网」误译成 mobile Internet technology 之外的自造词"
    ]
  },
  {
    "id": "cet6-2018-12-museums",
    "level": "cet6",
    "year": "2018年12月",
    "source": "https://cet4-6.xdf.cn/202601/15084390.html",
    "verified": true,
    "topic": "文化与艺术",
    "title": "博物馆观展",
    "source_text": "在一些热门博物馆门前，排长队已很常见。这些博物馆必须采取措施限制参观人数。如今，展览形式越来越多样。一些大型博物馆利用多媒体和虚拟现实等先进技术，使展览更具吸引力。不少博物馆还举办在线展览，人们可在网上观赏珍稀展品。然而，现场观展的体验对大多数参观者还是更具吸引力。",
    "sentences": [
      {
        "cn": "在一些热门博物馆门前，排长队已很常见。",
        "ref": "It has become quite common to see long queues in front of some popular museums.",
        "points": [
          "it 作形式主语 + 不定式",
          "long queues 排长队"
        ]
      },
      {
        "cn": "这些博物馆必须采取措施限制参观人数。",
        "ref": "These museums have to take measures to restrict the number of visitors.",
        "points": [
          "take measures to do 采取措施",
          "restrict the number of 限制数量"
        ]
      },
      {
        "cn": "如今，展览形式越来越多样。",
        "ref": "Nowadays, the forms of exhibitions are becoming more diverse.",
        "points": [
          "the forms of exhibitions 展览形式",
          "more diverse 更多样"
        ]
      },
      {
        "cn": "一些大型博物馆利用多媒体和虚拟现实等先进技术，使展览更具吸引力。",
        "ref": "Some large museums use advanced technologies such as multimedia and virtual reality to make their exhibitions more attractive.",
        "points": [
          "such as 举例",
          "make + 宾语 + 形容词比较级"
        ]
      },
      {
        "cn": "不少博物馆还举办在线展览，人们可在网上观赏珍稀展品。",
        "ref": "Many museums also hold online exhibitions, allowing people to view rare exhibits on the internet.",
        "points": [
          "allowing 现在分词作结果状语",
          "rare exhibits 珍稀展品"
        ]
      },
      {
        "cn": "然而，现场观展的体验对大多数参观者还是更具吸引力。",
        "ref": "However, the experience of viewing exhibits on-site remains more appealing to most visitors.",
        "points": [
          "remain + 形容词表仍然",
          "be appealing to 对……有吸引力"
        ]
      }
    ],
    "reference": "It has become quite common to see long queues in front of some popular museums. These museums have to take measures to restrict the number of visitors. Nowadays, the forms of exhibitions are becoming more diverse. Some large museums use advanced technologies such as multimedia and virtual reality to make their exhibitions more attractive. Many museums also hold online exhibitions, allowing people to view rare exhibits on the internet. However, the experience of viewing exhibits on-site remains more appealing to most visitors.",
    "keyWords": [
      {
        "w": "queue",
        "cn": "队列"
      },
      {
        "w": "restrict",
        "cn": "限制"
      },
      {
        "w": "exhibition",
        "cn": "展览"
      },
      {
        "w": "virtual reality",
        "cn": "虚拟现实"
      },
      {
        "w": "rare exhibit",
        "cn": "珍稀展品"
      },
      {
        "w": "on-site",
        "cn": "现场的"
      },
      {
        "w": "appealing",
        "cn": "有吸引力的"
      }
    ],
    "scoring": [
      "形式主语 / 分词状语等高级句式用对",
      "「虚拟现实」「在线展览」术语准确",
      "转折词 however 位置正确"
    ],
    "pitfalls": [
      "把「排长队」译成 stand a long line",
      "漏译「先进技术」中的 advanced",
      "「更具吸引力」误用 more attractive than 而缺比较对象"
    ]
  },
  {
    "id": "cet6-2018-12-public-libraries",
    "level": "cet6",
    "year": "2018年12月",
    "source": "https://cet4-6.xdf.cn/202601/15084390.html",
    "verified": true,
    "topic": "社会与教育",
    "title": "公共图书馆",
    "source_text": "中国越来越重视公共图书馆，并鼓励人们充分利用。新近公布的统计数字表明，中国的公共图书馆数量在逐年增长。许多图书馆通过翻新和扩建，为读者创造了更为安静、舒适的环境。大型公共图书馆不仅提供种类繁多的参考资料，而且定期举办讲座、展览等活动。近年来，也出现了许多数字图书馆，从而节省了存放图书所需的空间。一些图书馆还推出了自助服务系统，使读者借书还书更加方便，进一步满足了读者的需求。",
    "sentences": [
      {
        "cn": "中国越来越重视公共图书馆，并鼓励人们充分利用。",
        "ref": "China is increasingly valuing public libraries and encouraging people to make full use of them.",
        "points": [
          "increasingly valuing 现在进行时表趋势",
          "make full use of 充分利用"
        ]
      },
      {
        "cn": "新近公布的统计数字表明，中国的公共图书馆数量在逐年增长。",
        "ref": "Recently released statistics indicate that the number of public libraries in China is growing year by year.",
        "points": [
          "recently released 过去分词作定语",
          "indicate that 引出宾语从句"
        ]
      },
      {
        "cn": "许多图书馆通过翻新和扩建，为读者创造了更为安静、舒适的环境。",
        "ref": "Many libraries have renovated and expanded their facilities to create quieter and more comfortable environments for readers.",
        "points": [
          "to create 表目的",
          "比较级并列 quieter and more comfortable"
        ]
      },
      {
        "cn": "大型公共图书馆不仅提供种类繁多的参考资料，而且定期举办讲座、展览等活动。",
        "ref": "Large public libraries not only offer a wide variety of reference materials but also regularly hold lectures, exhibitions, and other activities.",
        "points": [
          "a wide variety of 种类繁多",
          "not only ... but also ... 并列谓语"
        ]
      },
      {
        "cn": "近年来，也出现了许多数字图书馆，从而节省了存放图书所需的空间。",
        "ref": "In recent years, the emergence of many digital libraries has saved space that would otherwise be needed for storing books.",
        "points": [
          "that would otherwise be needed 虚拟语气定语从句",
          "save space 节省空间"
        ]
      },
      {
        "cn": "一些图书馆还推出了自助服务系统，使读者借书还书更加方便，进一步满足了读者的需求。",
        "ref": "Some libraries have also introduced self-service systems, making it more convenient for readers to borrow and return books, and further meeting their needs.",
        "points": [
          "making it + 形容词 + for sb. to do",
          "further meeting 分词并列"
        ]
      }
    ],
    "reference": "China is increasingly valuing public libraries and encouraging people to make full use of them. Recently released statistics indicate that the number of public libraries in China is growing year by year. Many libraries have renovated and expanded their facilities to create quieter and more comfortable environments for readers. Large public libraries not only offer a wide variety of reference materials but also regularly hold lectures, exhibitions, and other activities. In recent years, the emergence of many digital libraries has saved space that would otherwise be needed for storing books. Some libraries have also introduced self-service systems, making it more convenient for readers to borrow and return books, and further meeting their needs.",
    "keyWords": [
      {
        "w": "public library",
        "cn": "公共图书馆"
      },
      {
        "w": "statistics",
        "cn": "统计数字"
      },
      {
        "w": "renovate",
        "cn": "翻新"
      },
      {
        "w": "reference materials",
        "cn": "参考资料"
      },
      {
        "w": "digital library",
        "cn": "数字图书馆"
      },
      {
        "w": "self-service system",
        "cn": "自助服务系统"
      },
      {
        "w": "meet one's needs",
        "cn": "满足需求"
      }
    ],
    "scoring": [
      "「不仅……而且……」结构完整",
      "分词状语（making / meeting）并列正确",
      "「数字图书馆」「自助服务」术语准确"
    ],
    "pitfalls": [
      "把「逐年」漏译 year by year",
      "「借书还书」错译成 borrow books and return",
      "indicate 后从句时态与主句不一致"
    ]
  },
  {
    "id": "cet6-2019-12-peony",
    "level": "cet6",
    "year": "2019年12月",
    "source": "https://m.koolearn.com/news/20191214/1190062.html",
    "verified": true,
    "topic": "传统文化",
    "title": "牡丹与洛阳牡丹节",
    "source_text": "牡丹花色艳丽，形象高雅，象征着和平与繁荣，因而在中国被称为“花中之王”。中国各地都培育和种植牡丹。千百年来，创造了许多诗歌和绘画赞美牡丹。唐代时期，牡丹在皇家园林普遍种植并被誉为国花，因而特别风行。十世纪时，洛阳古城成为牡丹栽培中心，而且这一地位一直保持到今天。现在，成千上万的国内游客蜂拥到洛阳参加一年一度的牡丹节，欣赏洛阳牡丹的独特之美，同时探索九朝古都的历史。",
    "sentences": [
      {
        "cn": "牡丹花色艳丽，形象高雅，象征着和平与繁荣，因而在中国被称为“花中之王”。",
        "ref": "Peony, which features bright colour and graceful shape, symbolizes peace and prosperity and is thus well recognized as the king of flowers.",
        "points": [
          "which features 定语从句描写特征",
          "be recognized as 被认为是"
        ]
      },
      {
        "cn": "中国各地都培育和种植牡丹。千百年来，创造了许多诗歌和绘画赞美牡丹。",
        "ref": "Peonies are cultivated and grown in many parts of China. For thousands of years, a great number of poems and paintings have been produced to praise the flower.",
        "points": [
          "被动语态 be cultivated and grown",
          "a great number of + 复数"
        ]
      },
      {
        "cn": "唐代时期，牡丹在皇家园林普遍种植并被誉为国花，因而特别风行。",
        "ref": "In the Tang Dynasty, peonies were planted so widely in the royal gardens as the national flower that they enjoyed great popularity across the country.",
        "points": [
          "so ... that ... 结果状语从句",
          "enjoy popularity 风行"
        ]
      },
      {
        "cn": "十世纪时，洛阳古城成为牡丹栽培中心，而且这一地位一直保持到今天。",
        "ref": "In the 10th century, the ancient city of Luoyang became the centre of peony planting, and has remained as such since then.",
        "points": [
          "现在完成时 has remained 表持续",
          "as such 指代前述身份"
        ]
      },
      {
        "cn": "现在，成千上万的国内游客蜂拥到洛阳参加一年一度的牡丹节，欣赏洛阳牡丹的独特之美，同时探索九朝古都的历史。",
        "ref": "Nowadays, hundreds of thousands of domestic tourists pour into Luoyang for the annual peony festival, when they can both appreciate the unique beauty of the flowers and explore the history of the city which is known as the capital of six dynasties.",
        "points": [
          "when 引导非限制性定语从句",
          "both ... and ... 并列不定式"
        ]
      }
    ],
    "reference": "Peony, which features bright colour and graceful shape, symbolizes peace and prosperity and is thus well recognized as the king of flowers. Peonies are cultivated and grown in many parts of China. For thousands of years, a great number of poems and paintings have been produced to praise the flower. In the Tang Dynasty, peonies were planted so widely in the royal gardens as the national flower that they enjoyed great popularity across the country. In the 10th century, the ancient city of Luoyang became the centre of peony planting, and has remained as such since then. Nowadays, hundreds of thousands of domestic tourists pour into Luoyang for the annual peony festival, when they can both appreciate the unique beauty of the flowers and explore the history of the city which is known as the capital of six dynasties.",
    "keyWords": [
      {
        "w": "peony",
        "cn": "牡丹"
      },
      {
        "w": "graceful",
        "cn": "高雅的"
      },
      {
        "w": "prosperity",
        "cn": "繁荣"
      },
      {
        "w": "cultivate",
        "cn": "培育"
      },
      {
        "w": "royal garden",
        "cn": "皇家园林"
      },
      {
        "w": "the national flower",
        "cn": "国花"
      },
      {
        "w": "annual",
        "cn": "一年一度的"
      }
    ],
    "scoring": [
      "被动语态（are cultivated / were planted）使用正确",
      "so ... that ... 结构完整",
      "数字与朝代表达（the 10th century / the Tang Dynasty）准确"
    ],
    "pitfalls": [
      "把「花中之王」译成 king of flower（缺冠词 / 单复数）",
      "「九朝古都」历史称谓漏译",
      "「千百年来」与现在完成时脱节"
    ]
  },
  {
    "id": "cet6-2021-12-yanan",
    "level": "cet6",
    "year": "2021年12月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202112/11347723.html",
    "verified": true,
    "topic": "历史与地理",
    "title": "革命圣地延安",
    "source_text": "延安位于陕西省北部，地处黄河中游，是中国革命的圣地。毛泽东等老一辈革命家曾在这里生活战斗了十三个春秋，领导了抗日战争和解放战争，培育了延安精神，为中国革命做出了巨大贡献。延安的革命旧址全国数量最大，分布最广，级别最高。延安是全国爱国主义、革命传统和延安精神教育基地。延安有9个革命纪念馆，珍藏着中共中央和老一辈革命家在延安时期留存下来的大量重要物品，因此享有中国革命博物馆城的美誉。",
    "sentences": [
      {
        "cn": "延安位于陕西省北部，地处黄河中游，是中国革命的圣地。",
        "ref": "Located in the northern part of Shaanxi Province and in the middle reaches of the Yellow River, Yan'an is the sacred land of the Chinese Revolution.",
        "points": [
          "located in 过去分词作状语",
          "the middle reaches 中游"
        ]
      },
      {
        "cn": "毛泽东等老一辈革命家曾在这里生活战斗了十三个春秋，领导了抗日战争和解放战争，培育了延安精神，为中国革命做出了巨大贡献。",
        "ref": "The old generation of revolutionaries such as Mao Zedong lived and fought here for thirteen years, leading the War of Resistance against Japanese Aggression and the War of Liberation, cultivating the spirit of Yan'an, and making great contributions to the Chinese revolution.",
        "points": [
          "such as 举例同位语",
          "三个并列现在分词作伴随状语"
        ]
      },
      {
        "cn": "延安的革命旧址全国数量最大，分布最广，级别最高。",
        "ref": "Yan'an has the largest number of revolutionary sites that are distributed widest and have the highest level in the country.",
        "points": [
          "最高级并列 largest / widest / highest",
          "that 定语从句修饰 sites"
        ]
      },
      {
        "cn": "延安是全国爱国主义、革命传统和延安精神教育基地。",
        "ref": "Yan'an is a national base for patriotism, revolutionary tradition and the education of the Yan'an spirit.",
        "points": [
          "a base for 表示基地",
          "三个并列名词短语"
        ]
      },
      {
        "cn": "延安有9个革命纪念馆，珍藏着中共中央和老一辈革命家在延安时期留存下来的大量重要物品，因此享有中国革命博物馆城的美誉。",
        "ref": "There are nine revolutionary memorial halls, which hold a large number of important items left by the Central Committee of the Communist Party of China and the old generation of revolutionaries during the Yan'an period, so Yan'an enjoys the reputation of the museum city of the Chinese revolution.",
        "points": [
          "there be 句型 + which 定语从句",
          "left by 过去分词作后置定语"
        ]
      }
    ],
    "reference": "Located in the northern part of Shaanxi Province and in the middle reaches of the Yellow River, Yan'an is the sacred land of the Chinese Revolution. The old generation of revolutionaries such as Mao Zedong lived and fought here for thirteen years, leading the War of Resistance against Japanese Aggression and the War of Liberation, cultivating the spirit of Yan'an, and making great contributions to the Chinese revolution. Yan'an has the largest number of revolutionary sites that are distributed widest and have the highest level in the country. Yan'an is a national base for patriotism, revolutionary tradition and the education of the Yan'an spirit. There are nine revolutionary memorial halls, which hold a large number of important items left by the Central Committee of the Communist Party of China and the old generation of revolutionaries during the Yan'an period, so Yan'an enjoys the reputation of the museum city of the Chinese revolution.",
    "keyWords": [
      {
        "w": "sacred land",
        "cn": "圣地"
      },
      {
        "w": "revolutionary",
        "cn": "革命的"
      },
      {
        "w": "the War of Resistance against Japanese Aggression",
        "cn": "抗日战争"
      },
      {
        "w": "the War of Liberation",
        "cn": "解放战争"
      },
      {
        "w": "revolutionary site",
        "cn": "革命旧址"
      },
      {
        "w": "memorial hall",
        "cn": "纪念馆"
      },
      {
        "w": "reputation",
        "cn": "声誉"
      }
    ],
    "scoring": [
      "多动句处理为并列分词结构",
      "「抗日战争 / 解放战争」专有译名准确",
      "there be 与定语从句嵌套合法"
    ],
    "pitfalls": [
      "把「十三个春秋」译成 thirteen springs and autumns",
      "漏译「老一辈革命家」中的 the old generation",
      "「博物馆城」直译成 museum city 不加定冠词 the"
    ]
  },
  {
    "id": "cet6-2021-12-first-congress",
    "level": "cet6",
    "year": "2021年12月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202112/11347723.html",
    "verified": true,
    "topic": "历史与地理",
    "title": "中共一大会址纪念馆",
    "source_text": "中国共产党第一次全国代表大会会址位于上海兴业路76号，是一栋典型的上海式住宅，建于1920年秋。1921年7月23日，中国共产党第一次全国代表大会在此召开，大会通过了中国共产党的第一个纲领和第一个决议，选举产生了中央领导机构，宣告了中国共产党的诞生。1952年9月，中共一大会址修复，建立纪念馆并对外开放。纪念馆除了介绍参加一大的代表之外，还介绍党的历史发展进程，现已成为了解党史、缅怀革命先烈的爱国主义教育基地。",
    "sentences": [
      {
        "cn": "中国共产党第一次全国代表大会会址位于上海兴业路76号，是一栋典型的上海式住宅，建于1920年秋。",
        "ref": "Situated at No.76 Xingye Road, Shanghai, the Site of the First National Congress of the Communist Party of China is a typical Shanghai-style residence built in the fall of 1920.",
        "points": [
          "situated at 过去分词短语作状语",
          "built in 过去分词作后置定语"
        ]
      },
      {
        "cn": "1921年7月23日，中国共产党第一次全国代表大会在此召开，大会通过了中国共产党的第一个纲领和第一个决议，选举产生了中央领导机构，宣告了中国共产党的诞生。",
        "ref": "On July 23, 1921, the First National Congress of the CPC was held here, where the first programme and resolution of the CPC were passed, and the collective central leadership was elected, thus announcing the birth of the Communist Party of China.",
        "points": [
          "where 非限制性定语从句",
          "thus + 现在分词表结果"
        ]
      },
      {
        "cn": "1952年9月，中共一大会址修复，建立纪念馆并对外开放。",
        "ref": "In September 1952, the site was renovated, and a Memorial Hall was established and opened to the public.",
        "points": [
          "被动语态并列 was renovated / was established",
          "open to the public 对外开放"
        ]
      },
      {
        "cn": "纪念馆除了介绍参加一大的代表之外，还介绍党的历史发展进程，现已成为了解党史、缅怀革命先烈的爱国主义教育基地。",
        "ref": "In addition to introducing the representatives who participated in the First Congress, the Memorial Hall also introduces the historical development of the Party, and has become a patriotic education base for learning Party history and commemorating revolutionary martyrs.",
        "points": [
          "in addition to + 动名词",
          "for doing 表示用途"
        ]
      }
    ],
    "reference": "Situated at No.76 Xingye Road, Shanghai, the Site of the First National Congress of the Communist Party of China is a typical Shanghai-style residence built in the fall of 1920. On July 23, 1921, the First National Congress of the CPC was held here, where the first programme and resolution of the CPC were passed, and the collective central leadership was elected, thus announcing the birth of the Communist Party of China. In September 1952, the site was renovated, and a Memorial Hall was established and opened to the public. In addition to introducing the representatives who participated in the First Congress, the Memorial Hall also introduces the historical development of the Party, and has become a patriotic education base for learning Party history and commemorating revolutionary martyrs.",
    "keyWords": [
      {
        "w": "the First National Congress",
        "cn": "第一次全国代表大会"
      },
      {
        "w": "residence",
        "cn": "住宅"
      },
      {
        "w": "programme",
        "cn": "纲领"
      },
      {
        "w": "resolution",
        "cn": "决议"
      },
      {
        "w": "renovate",
        "cn": "修复"
      },
      {
        "w": "patriotic education base",
        "cn": "爱国主义教育基地"
      },
      {
        "w": "martyr",
        "cn": "先烈"
      }
    ],
    "scoring": [
      "日期与地点表达规范（No.76 / July 23, 1921）",
      "长句用从句或分词拆分而不堆砌",
      "党史类专有名词译名统一"
    ],
    "pitfalls": [
      "把「会址」译成 meeting place 而非 the Site",
      "「宣告了……诞生」漏译导致结果关系丢失",
      "「除了……之外」误用 except"
    ]
  },
  {
    "id": "cet6-2021-12-jinggangshan",
    "level": "cet6",
    "year": "2021年12月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202112/11347723.html",
    "verified": true,
    "topic": "历史与地理",
    "title": "井冈山革命摇篮",
    "source_text": "井冈山地处湖南江西两省交界处，因其辉煌的革命历史被誉为“中国革命红色摇篮”。1927年10月，毛泽东、朱德等老一辈革命家率领中国工农红军来到这里，开展了艰苦卓绝的斗争，创建了第一个农村革命根据地，点燃了中国革命的星星之火。他们开辟了“农村包围(besiege)城市，武装夺取政权”这一具有中国特色的革命道路，中国革命从这里迈向胜利。井冈山现有100多处革命旧址，成为一个“没有围墙的革命历史博物馆”，是爱国主义和革命传统教育的重要基地。",
    "sentences": [
      {
        "cn": "井冈山地处湖南江西两省交界处，因其辉煌的革命历史被誉为“中国革命红色摇篮”。",
        "ref": "Jinggangshan is located at the boundary of Hunan Province and Jiangxi Province, and is honored as the red cradle of the Chinese revolution for its glorious revolutionary history.",
        "points": [
          "be located at 表示地处",
          "be honored as 被誉为"
        ]
      },
      {
        "cn": "1927年10月，毛泽东、朱德等老一辈革命家率领中国工农红军来到这里，开展了艰苦卓绝的斗争，创建了第一个农村革命根据地，点燃了中国革命的星星之火。",
        "ref": "In October 1927, the old generation of revolutionaries such as Mao Zedong and Zhu De led the Chinese Workers' and Peasants' Red Army here, where they carried out extremely hard and bitter struggles, created the first rural revolutionary base and lit the sparks of the Chinese revolution.",
        "points": [
          "where 定语从句承接地点",
          "并列谓语 carried out / created / lit"
        ]
      },
      {
        "cn": "他们开辟了“农村包围(besiege)城市，武装夺取政权”这一具有中国特色的革命道路，中国革命从这里迈向胜利。",
        "ref": "They opened up a revolutionary road with Chinese characteristics of besieging the cities from the countryside and seizing power by armed force, and it is from here that the Chinese revolution marched toward victory.",
        "points": [
          "with Chinese characteristics 后置定语",
          "it is ... that 强调句"
        ]
      },
      {
        "cn": "井冈山现有100多处革命旧址，成为一个“没有围墙的革命历史博物馆”，是爱国主义和革命传统教育的重要基地。",
        "ref": "Jinggangshan now has more than 100 revolutionary sites and has become a revolutionary history museum without walls, an important base for patriotism and revolutionary tradition education.",
        "points": [
          "more than 100 表示 100 多处",
          "an important base for 同位语补充"
        ]
      }
    ],
    "reference": "Jinggangshan is located at the boundary of Hunan Province and Jiangxi Province, and is honored as the red cradle of the Chinese revolution for its glorious revolutionary history. In October 1927, the old generation of revolutionaries such as Mao Zedong and Zhu De led the Chinese Workers' and Peasants' Red Army here, where they carried out extremely hard and bitter struggles, created the first rural revolutionary base and lit the sparks of the Chinese revolution. They opened up a revolutionary road with Chinese characteristics of besieging the cities from the countryside and seizing power by armed force, and it is from here that the Chinese revolution marched toward victory. Jinggangshan now has more than 100 revolutionary sites and has become a revolutionary history museum without walls, an important base for patriotism and revolutionary tradition education.",
    "keyWords": [
      {
        "w": "boundary",
        "cn": "交界处"
      },
      {
        "w": "the Chinese Workers' and Peasants' Red Army",
        "cn": "中国工农红军"
      },
      {
        "w": "rural revolutionary base",
        "cn": "农村革命根据地"
      },
      {
        "w": "besiege",
        "cn": "包围"
      },
      {
        "w": "seize power",
        "cn": "夺取政权"
      },
      {
        "w": "with Chinese characteristics",
        "cn": "具有中国特色的"
      },
      {
        "w": "revolutionary tradition",
        "cn": "革命传统"
      }
    ],
    "scoring": [
      "地名与军队名称专有译法准确",
      "并列谓语与定语从句交替使用",
      "「具有中国特色」作后置定语"
    ],
    "pitfalls": [
      "「红色摇篮」误译成 red basket",
      "「100多处」漏译 more than",
      "把「武装夺取政权」直译成 take power by gun"
    ]
  },
  {
    "id": "cet4-2016-06-kungfu",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://news.koolearn.com/20160714/1090450.html",
    "verified": true,
    "topic": "传统文化",
    "title": "中国功夫",
    "source_text": "功夫(Kung Fu)是中国武术(martial arts)的俗称。中国武术的起源可以追溯到自卫的需要、狩猎活动以及古代中国的军事训练。它是中国传统体育运动的一种，年轻人和老年人都练。它已逐渐演变成了中国文化的独特元素。作为中国的国宝，功夫有上百种不同的风格，是世界上练得最多的武术形式。有些风格模仿了动物的动作，还有一些则受到了中国哲学思想、神话和传说的启发。",
    "sentences": [
      {
        "cn": "功夫(Kung Fu)是中国武术(martial arts)的俗称。",
        "ref": "Kung Fu is the common name of Chinese martial arts.",
        "points": [
          "the common name of 俗称",
          "专有名词 Kung Fu 首字母大写"
        ]
      },
      {
        "cn": "中国武术的起源可以追溯到自卫的需要、狩猎活动以及古代中国的军事训练。",
        "ref": "The origin of Chinese Kung Fu can be traced back to the needs of self-defense, hunting and ancient Chinese military training.",
        "points": [
          "be traced back to 追溯到",
          "并列三项宾语"
        ]
      },
      {
        "cn": "它是中国传统体育运动的一种，年轻人和老年人都练。",
        "ref": "It is one of the traditional Chinese sports which is practiced by both young and senior people.",
        "points": [
          "one of the + 复数名词",
          "be practiced by 被动语态"
        ]
      },
      {
        "cn": "它已逐渐演变成了中国文化的独特元素。",
        "ref": "It has gradually become a unique element in Chinese culture.",
        "points": [
          "现在完成时表演变结果",
          "a unique element in 搭配"
        ]
      },
      {
        "cn": "作为中国的国宝，功夫有上百种不同的风格，是世界上练得最多的武术形式。",
        "ref": "As a national treasure of China, Kung Fu has hundreds of styles, which is the most practiced martial arts form around the world.",
        "points": [
          "as 引导状语表身份",
          "which 非限制性定语从句"
        ]
      },
      {
        "cn": "有些风格模仿了动物的动作，还有一些则受到了中国哲学思想、神话和传说的启发。",
        "ref": "Some styles imitate the animal actions and others are inspired by Chinese philosophical thoughts, myths and legends.",
        "points": [
          "some ... and others ... 并列",
          "be inspired by 受到启发"
        ]
      }
    ],
    "reference": "Kung Fu is the common name of Chinese martial arts. The origin of Chinese Kung Fu can be traced back to the needs of self-defense, hunting and ancient Chinese military training. It is one of the traditional Chinese sports which is practiced by both young and senior people. It has gradually become a unique element in Chinese culture. As a national treasure of China, Kung Fu has hundreds of styles, which is the most practiced martial arts form around the world. Some styles imitate the animal actions and others are inspired by Chinese philosophical thoughts, myths and legends.",
    "keyWords": [
      {
        "w": "martial arts",
        "cn": "武术"
      },
      {
        "w": "be traced back to",
        "cn": "追溯到"
      },
      {
        "w": "self-defense",
        "cn": "自卫"
      },
      {
        "w": "national treasure",
        "cn": "国宝"
      },
      {
        "w": "imitate",
        "cn": "模仿"
      },
      {
        "w": "be inspired by",
        "cn": "受到……启发"
      },
      {
        "w": "legend",
        "cn": "传说"
      }
    ],
    "scoring": [
      "专有名词（Kung Fu / martial arts）写全",
      "被动语态（is practiced / are inspired）正确",
      "some ... others ... 对应关系清楚"
    ],
    "pitfalls": [
      "「俗称」误译成 is called by people",
      "漏译「上百种」的量词表达",
      "把「国宝」译成 national baby 之类误解"
    ]
  },
  {
    "id": "cet4-2016-06-weifang-kite",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://news.koolearn.com/20160714/1090450.html",
    "verified": true,
    "topic": "传统文化",
    "title": "潍坊风筝",
    "source_text": "在山东省潍坊市，风筝不仅仅是玩具，而且还是这座城市文化的标志。潍坊以“风筝之都”而闻名，已有将近2,400年放飞风筝的历史。传说中国古代哲学家墨子用了三年时间在潍坊制作了世界上首个风筝，但放飞的第一天风筝就坠落并摔坏了。也有人相信风筝是中国古代木匠鲁班发明的。据说他的风筝用木头和竹子制作，飞了三天后才落地。",
    "sentences": [
      {
        "cn": "在山东省潍坊市，风筝不仅仅是玩具，而且还是这座城市文化的标志。",
        "ref": "In Weifang City, Shandong Province, the kite is a cultural symbol of the city as well as a toy for children.",
        "points": [
          "as well as 强调前项",
          "a cultural symbol of 搭配"
        ]
      },
      {
        "cn": "潍坊以“风筝之都”而闻名，已有将近2,400年放飞风筝的历史。",
        "ref": "Weifang is known as the City of the Kite because it has a long history of two thousand four hundred years in flying the kite.",
        "points": [
          "be known as 以……闻名",
          "have a history of ... in doing"
        ]
      },
      {
        "cn": "传说中国古代哲学家墨子用了三年时间在潍坊制作了世界上首个风筝，但放飞的第一天风筝就坠落并摔坏了。",
        "ref": "It is said by some people that Motse, one of the philosophers in ancient China, spent three years in making the first kite in the world, and that the kite he made crashed the first day it flew in the sky.",
        "points": [
          "it is said that 句型",
          "spend time in doing 结构"
        ]
      },
      {
        "cn": "也有人相信风筝是中国古代木匠鲁班发明的。",
        "ref": "It is also believed by others that Luban, the greatest carpenter in ancient China, invented the kite.",
        "points": [
          "it is believed that 句型",
          "同位语 the greatest carpenter 补充说明"
        ]
      },
      {
        "cn": "据说他的风筝用木头和竹子制作，飞了三天后才落地。",
        "ref": "It is said that his kite made of wood and bamboo flew for three days before it landed on the ground.",
        "points": [
          "made of 过去分词作定语",
          "before 引导时间状语从句"
        ]
      }
    ],
    "reference": "In Weifang City, Shandong Province, the kite is a cultural symbol of the city as well as a toy for children. Weifang is known as the City of the Kite because it has a long history of two thousand four hundred years in flying the kite. It is said by some people that Motse, one of the philosophers in ancient China, spent three years in making the first kite in the world, and that the kite he made crashed the first day it flew in the sky. It is also believed by others that Luban, the greatest carpenter in ancient China, invented the kite. It is said that his kite made of wood and bamboo flew for three days before it landed on the ground.",
    "keyWords": [
      {
        "w": "kite",
        "cn": "风筝"
      },
      {
        "w": "be known as",
        "cn": "以……闻名"
      },
      {
        "w": "philosopher",
        "cn": "哲学家"
      },
      {
        "w": "carpenter",
        "cn": "木匠"
      },
      {
        "w": "be made of",
        "cn": "由……制成"
      },
      {
        "w": "land on the ground",
        "cn": "落地"
      },
      {
        "w": "the City of the Kite",
        "cn": "风筝之都"
      }
    ],
    "scoring": [
      "两个 it is said / believed that 句型译出",
      "数字 2,400 年表达正确",
      "人物专名（Motse / Luban）处理统一"
    ],
    "pitfalls": [
      "把「风筝之都」译成 kite city（缺定冠词与 of 结构）",
      "漏译「将近」导致数字失真",
      "「摔坏了」漏译"
    ]
  },
  {
    "id": "cet4-2016-06-wuzhen",
    "level": "cet4",
    "year": "2016年6月",
    "source": "https://news.koolearn.com/20160714/1090450.html",
    "verified": true,
    "topic": "历史与地理",
    "title": "乌镇水乡",
    "source_text": "乌镇是浙江的一座古老的水镇，坐落在京杭大运河畔。这是一处迷人的地方，有许多古桥、中式旅店和餐馆。在过去的一千年里，乌镇的水系和生活方式并未经历多少变化，是一座展现古文明的博物馆。乌镇所有房屋都用石木建造。数百年来，当地人沿着河边建起了住宅和集市。无数宽敞美丽的庭院藏身于屋舍之间，游客们每到一处都会有惊喜的发现。",
    "sentences": [
      {
        "cn": "乌镇是浙江的一座古老的水镇，坐落在京杭大运河畔。",
        "ref": "Wuzhen, an ancient water town in Zhejiang, lies at the riverside of the Beijing-Hangzhou Grand Canal.",
        "points": [
          "同位语 an ancient water town 补充",
          "lie at the riverside of 坐落于"
        ]
      },
      {
        "cn": "这是一处迷人的地方，有许多古桥、中式旅店和餐馆。",
        "ref": "It is an attractive town, enjoying many ancient bridges, Chinese style inns and restaurants.",
        "points": [
          "enjoying 现在分词作伴随状语",
          "并列三项名词"
        ]
      },
      {
        "cn": "在过去的一千年里，乌镇的水系和生活方式并未经历多少变化，是一座展现古文明的博物馆。",
        "ref": "Wuzhen did not experience much change in its river system and life style through the past one thousand years, which can be called a museum that displays the old civilization.",
        "points": [
          "not ... much 表否定",
          "which 定语从句进一步说明"
        ]
      },
      {
        "cn": "乌镇所有房屋都用石木建造。数百年来，当地人沿着河边建起了住宅和集市。",
        "ref": "All the houses there are built with stones and woods. For hundreds of years, the local people have built their houses and markets along the riverside.",
        "points": [
          "be built with 材料用 with",
          "现在完成时表延续"
        ]
      },
      {
        "cn": "无数宽敞美丽的庭院藏身于屋舍之间，游客们每到一处都会有惊喜的发现。",
        "ref": "Tourists will be surprised by the spacious and well-built courtyards among the houses everywhere they go.",
        "points": [
          "be surprised by 被动",
          "everywhere they go 状语从句"
        ]
      }
    ],
    "reference": "Wuzhen, an ancient water town in Zhejiang, lies at the riverside of the Beijing-Hangzhou Grand Canal. It is an attractive town, enjoying many ancient bridges, Chinese style inns and restaurants. Wuzhen did not experience much change in its river system and life style through the past one thousand years, which can be called a museum that displays the old civilization. All the houses there are built with stones and woods. For hundreds of years, the local people have built their houses and markets along the riverside. Tourists will be surprised by the spacious and well-built courtyards among the houses everywhere they go.",
    "keyWords": [
      {
        "w": "water town",
        "cn": "水镇"
      },
      {
        "w": "the Beijing-Hangzhou Grand Canal",
        "cn": "京杭大运河"
      },
      {
        "w": "inn",
        "cn": "旅店"
      },
      {
        "w": "river system",
        "cn": "水系"
      },
      {
        "w": "courtyard",
        "cn": "庭院"
      },
      {
        "w": "spacious",
        "cn": "宽敞的"
      },
      {
        "w": "market",
        "cn": "集市"
      }
    ],
    "scoring": [
      "同位语与定语从句使用正确",
      "现在完成时与时间状语搭配",
      "「京杭大运河」专名译准"
    ],
    "pitfalls": [
      "「水镇」误译成 water city",
      "「并未经历多少变化」双重否定漏一层",
      "「石木」误译成 stone and wood 单复数不当"
    ]
  },
  {
    "id": "cet4-2018-06-buses",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://cet4.koolearn.com/20180702/823974.html",
    "verified": true,
    "topic": "社会生活",
    "title": "城市公交车",
    "source_text": "公交车曾是中国人出行的主要交通工具。近年来，由于私家车数量不断增多，城市的交通问题越来越严重。许多城市为了鼓励更多人乘坐公交车出行，一直在努力改善公交车的服务质量。车辆的设施不断更新，车速也有了显著提高。然而，公交车的票价却依然相当低廉。现在，在大多数城市，许多当地老年市民都可以免费乘坐公交车。",
    "sentences": [
      {
        "cn": "公交车曾是中国人出行的主要交通工具。",
        "ref": "Buses used to be the main means of transportation for Chinese people.",
        "points": [
          "used to be 表过去状态",
          "means of transportation 交通工具"
        ]
      },
      {
        "cn": "近年来，由于私家车数量不断增多，城市的交通问题越来越严重。",
        "ref": "In recent years, with the continuous increase of private cars, the urban traffic problems have become more and more serious.",
        "points": [
          "with + 名词表原因",
          "more and more + 形容词"
        ]
      },
      {
        "cn": "许多城市为了鼓励更多人乘坐公交车出行，一直在努力改善公交车的服务质量。",
        "ref": "In order to encourage more people to travel by bus, many cities have been trying to improve the bus service quality.",
        "points": [
          "in order to 表目的",
          "现在完成进行时 have been trying"
        ]
      },
      {
        "cn": "车辆的设施不断更新，车速也有了显著提高。",
        "ref": "The facilities of bus are constantly updated and the speed has also been significantly improved.",
        "points": [
          "被动语态并列",
          "constantly / significantly 副词位置"
        ]
      },
      {
        "cn": "然而，公交车的票价却依然相当低廉。",
        "ref": "However, the bus fare is still quite low.",
        "points": [
          "however 作转折连接",
          "still 强调依然"
        ]
      },
      {
        "cn": "现在，在大多数城市，许多当地老年市民都可以免费乘坐公交车。",
        "ref": "Nowadays, in most cities, many local senior citizens can travel by bus for free.",
        "points": [
          "for free 免费",
          "senior citizens 老年市民"
        ]
      }
    ],
    "reference": "Buses used to be the main means of transportation for Chinese people. In recent years, with the continuous increase of private cars, the urban traffic problems have become more and more serious. In order to encourage more people to travel by bus, many cities have been trying to improve the bus service quality. The facilities of bus are constantly updated and the speed has also been significantly improved. However, the bus fare is still quite low. Nowadays, in most cities, many local senior citizens can travel by bus for free.",
    "keyWords": [
      {
        "w": "means of transportation",
        "cn": "交通工具"
      },
      {
        "w": "private car",
        "cn": "私家车"
      },
      {
        "w": "urban",
        "cn": "城市的"
      },
      {
        "w": "service quality",
        "cn": "服务质量"
      },
      {
        "w": "fare",
        "cn": "票价"
      },
      {
        "w": "senior citizen",
        "cn": "老年市民"
      },
      {
        "w": "for free",
        "cn": "免费"
      }
    ],
    "scoring": [
      "used to be / have been trying 时态准确",
      "被动与主动语态交替正确",
      "「票价」「老年市民」术语地道"
    ],
    "pitfalls": [
      "transportation 误拼成 transportations",
      "「免费」译成 free of money",
      "漏译「然而」的转折"
    ]
  },
  {
    "id": "cet4-2018-06-flights",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://cet4.koolearn.com/20180702/823974.html",
    "verified": true,
    "topic": "社会生活",
    "title": "乘飞机出行",
    "source_text": "过去，乘飞机出行对大多数中国人来说是难以想象的。如今随着经济的发展和生活水平的提高，越来越多的中国人包括许多农民和外出务工人员都能乘飞机出行。他们可以乘飞机到达所有大城市，还有许多城市也在筹建机场。航空服务不断改进，而且经常会有特价机票。近年来，节假日期间选择乘飞机外出旅游的人不断增加。",
    "sentences": [
      {
        "cn": "过去，乘飞机出行对大多数中国人来说是难以想象的。",
        "ref": "In the past, traveling by air was unimaginable for most Chinese people.",
        "points": [
          "动名词 traveling 作主语",
          "be unimaginable for sb. 搭配"
        ]
      },
      {
        "cn": "如今随着经济的发展和生活水平的提高，越来越多的中国人包括许多农民和外出务工人员都能乘飞机出行。",
        "ref": "Nowadays, with the development of economy and the improvement of living standards, more and more Chinese people, including many farmers and migrant workers, can travel by air.",
        "points": [
          "with + 名词表伴随",
          "including 插入语补充"
        ]
      },
      {
        "cn": "他们可以乘飞机到达所有大城市，还有许多城市也在筹建机场。",
        "ref": "They can fly to all domestic major cities, and many other cities are also planning to build their airports.",
        "points": [
          "fly to 飞往",
          "plan to do 计划做"
        ]
      },
      {
        "cn": "航空服务不断改进，而且经常会有特价机票。",
        "ref": "Meanwhile, aviation services are constantly improving and there are often special fares.",
        "points": [
          "there be 句型表存在",
          "special fares 特价机票"
        ]
      },
      {
        "cn": "近年来，节假日期间选择乘飞机外出旅游的人不断增加。",
        "ref": "In recent years, there have been increasing numbers of people who choose to travel by air during holidays.",
        "points": [
          "there have been 现在完成时",
          "who 定语从句修饰 people"
        ]
      }
    ],
    "reference": "In the past, traveling by air was unimaginable for most Chinese people. Nowadays, with the development of economy and the improvement of living standards, more and more Chinese people, including many farmers and migrant workers, can travel by air. They can fly to all domestic major cities, and many other cities are also planning to build their airports. Meanwhile, aviation services are constantly improving and there are often special fares. In recent years, there have been increasing numbers of people who choose to travel by air during holidays.",
    "keyWords": [
      {
        "w": "travel by air",
        "cn": "乘飞机出行"
      },
      {
        "w": "unimaginable",
        "cn": "难以想象的"
      },
      {
        "w": "living standards",
        "cn": "生活水平"
      },
      {
        "w": "migrant worker",
        "cn": "外出务工人员"
      },
      {
        "w": "aviation service",
        "cn": "航空服务"
      },
      {
        "w": "special fare",
        "cn": "特价机票"
      },
      {
        "w": "domestic",
        "cn": "国内的"
      }
    ],
    "scoring": [
      "动名词与 there be 句型交替",
      "数字人群表达（more and more / increasing numbers）准确",
      "「特价机票」术语地道"
    ],
    "pitfalls": [
      "把「难以想象」译成 can not imagine（结构混乱）",
      "「筹建机场」漏译 plan to build",
      "「节假日期间」漏译 during holidays"
    ]
  },
  {
    "id": "cet4-2018-06-subway",
    "level": "cet4",
    "year": "2018年6月",
    "source": "https://cet4.koolearn.com/20180702/823974.html",
    "verified": true,
    "topic": "社会生活",
    "title": "城市地铁",
    "source_text": "近年来，中国有越来越多的城市开始建造地铁。发展地铁有助于减少城市的交通拥堵和空气污染。地铁具有安全、快捷和舒适的优点，越来越多的人选择地铁作为每天上班或上学的主要交通工具。如今，在中国乘坐地铁正变得越来越方便。在有些城市里，乘客只需用卡或手机就可以乘坐地铁。许多当地老年市民还可以免费乘坐地铁。",
    "sentences": [
      {
        "cn": "近年来，中国有越来越多的城市开始建造地铁。",
        "ref": "In recent years, more cities in China have begun to build subways in a bid to reduce urban traffic congestion and air pollution.",
        "points": [
          "in a bid to 为了",
          "现在完成时表已开始"
        ]
      },
      {
        "cn": "发展地铁有助于减少城市的交通拥堵和空气污染。",
        "ref": "Developing subways helps reduce urban traffic congestion and air pollution.",
        "points": [
          "动名词作主语",
          "help do 结构"
        ]
      },
      {
        "cn": "地铁具有安全、快捷和舒适的优点，越来越多的人选择地铁作为每天上班或上学的主要交通工具。",
        "ref": "A growing number of people choose subway as their main means of daily transportation to work or school to enjoy its advantages of safety, speed and comfort.",
        "points": [
          "a growing number of 越来越多",
          "choose A as B 结构"
        ]
      },
      {
        "cn": "如今，在中国乘坐地铁正变得越来越方便。",
        "ref": "Nowadays, taking the subway is becoming increasingly convenient in China.",
        "points": [
          "现在进行时表趋势",
          "increasingly + 形容词"
        ]
      },
      {
        "cn": "在有些城市里，乘客只需用卡或手机就可以乘坐地铁。许多当地老年市民还可以免费乘坐地铁。",
        "ref": "Simply with IC cards or mobile phones, passengers in some cities are able to take the subway and many local senior citizens can also go out by subway for free.",
        "points": [
          "simply with 表凭借",
          "be able to do 能够"
        ]
      }
    ],
    "reference": "In recent years, more cities in China have begun to build subways in a bid to reduce urban traffic congestion and air pollution. Developing subways helps reduce urban traffic congestion and air pollution. A growing number of people choose subway as their main means of daily transportation to work or school to enjoy its advantages of safety, speed and comfort. Nowadays, taking the subway is becoming increasingly convenient in China. Simply with IC cards or mobile phones, passengers in some cities are able to take the subway and many local senior citizens can also go out by subway for free.",
    "keyWords": [
      {
        "w": "subway",
        "cn": "地铁"
      },
      {
        "w": "traffic congestion",
        "cn": "交通拥堵"
      },
      {
        "w": "air pollution",
        "cn": "空气污染"
      },
      {
        "w": "a growing number of",
        "cn": "越来越多的"
      },
      {
        "w": "convenient",
        "cn": "方便的"
      },
      {
        "w": "IC card",
        "cn": "公交卡"
      },
      {
        "w": "senior citizen",
        "cn": "老年市民"
      }
    ],
    "scoring": [
      "动名词作主语与 help do 结构正确",
      "「越来越……」表达多样",
      "「公交卡」可接受 IC card / bus card"
    ],
    "pitfalls": [
      "help 后误加 to 的重复结构写错",
      "「优点」漏译 advantages",
      "「免费乘坐」错译成 take free"
    ]
  },
  {
    "id": "cet4-2019-06-paper-cutting",
    "level": "cet4",
    "year": "2019年6月",
    "source": "https://news.koolearn.com/20190618/1179809.html",
    "verified": true,
    "topic": "传统文化",
    "title": "中国剪纸",
    "source_text": "剪纸是中国民间艺术的一种独特形式，已有2000年的历史。剪纸很可能源于汉代，继纸张发明之后。从此，它在中国的许多地方得到了普及。剪纸用的材料和工具很简单：纸和剪刀。剪纸作品通常是用红纸做成的，因为红色在中国传统文化中与幸福相连。因此，在婚礼、春节等喜庆场合，红颜色的剪纸是门窗装饰的首选。",
    "sentences": [
      {
        "cn": "剪纸是中国民间艺术的一种独特形式，已有2000年的历史。",
        "ref": "Paper cutting, with a history of over 2,000 years, is a unique form of Chinese folk art.",
        "points": [
          "with 复合结构插入补充",
          "a unique form of 搭配"
        ]
      },
      {
        "cn": "剪纸很可能源于汉代，继纸张发明之后。",
        "ref": "It is possible that such an art originated from the Han Dynasty, right after the invention of paper.",
        "points": [
          "it is possible that 句型",
          "originate from 起源于"
        ]
      },
      {
        "cn": "从此，它在中国的许多地方得到了普及。",
        "ref": "It gained great popularity all over China since then.",
        "points": [
          "gain popularity 得到普及",
          "since then 与完成 / 过去时搭配"
        ]
      },
      {
        "cn": "剪纸用的材料和工具很简单：纸和剪刀。剪纸作品通常是用红纸做成的，因为红色在中国传统文化中与幸福相连。",
        "ref": "The main materials and tools used in paper cutting are quite simple: only paper and scissors are needed. The works of paper cutting are often made of red paper, for red is connected with happiness in traditional Chinese culture.",
        "points": [
          "used in 过去分词作定语",
          "be connected with 与……相连"
        ]
      },
      {
        "cn": "因此，在婚礼、春节等喜庆场合，红颜色的剪纸是门窗装饰的首选。",
        "ref": "That is the reason why red paper cuttings are the top choice for the decoration of doors and windows on joyful occasions like weddings and the Spring Festival.",
        "points": [
          "that is the reason why 句型",
          "the top choice for 首选"
        ]
      }
    ],
    "reference": "Paper cutting, with a history of over 2,000 years, is a unique form of Chinese folk art. It is possible that such an art originated from the Han Dynasty, right after the invention of paper. It gained great popularity all over China since then. The main materials and tools used in paper cutting are quite simple: only paper and scissors are needed. The works of paper cutting are often made of red paper, for red is connected with happiness in traditional Chinese culture. That is the reason why red paper cuttings are the top choice for the decoration of doors and windows on joyful occasions like weddings and the Spring Festival.",
    "keyWords": [
      {
        "w": "paper cutting",
        "cn": "剪纸"
      },
      {
        "w": "folk art",
        "cn": "民间艺术"
      },
      {
        "w": "originate from",
        "cn": "起源于"
      },
      {
        "w": "scissors",
        "cn": "剪刀"
      },
      {
        "w": "be connected with",
        "cn": "与……相连"
      },
      {
        "w": "decoration",
        "cn": "装饰"
      },
      {
        "w": "joyful occasion",
        "cn": "喜庆场合"
      }
    ],
    "scoring": [
      "「已有2000年历史」表达准确",
      "被动与主动语态使用得当",
      "红色寓意相关的文化词译出"
    ],
    "pitfalls": [
      "paper cutting 误写成 papercutting 之外的不统一形式",
      "漏译「继纸张发明之后」的时间关系",
      "「首选」译成 first choice 而未强调 top choice 亦可接受但需完整"
    ]
  },
  {
    "id": "cet4-2019-06-lanterns",
    "level": "cet4",
    "year": "2019年6月",
    "source": "https://news.koolearn.com/20190618/1179809.html",
    "verified": true,
    "topic": "传统文化",
    "title": "中国灯笼",
    "source_text": "灯笼起源于东汉，最初主要用于照明。在唐代，人们用红灯笼来庆祝安定的生活。从那时起，灯笼在中国的许多地方流行起来。灯笼通常用色彩鲜艳的薄纸制作，形状和尺寸各异。在中国传统文化中，红灯笼象征生活美满和生意兴隆，通常在春节、元宵节和国庆节等节日期间悬挂。如今，世界上许多其他地方也能看到红灯笼。",
    "sentences": [
      {
        "cn": "灯笼起源于东汉，最初主要用于照明。",
        "ref": "Lanterns originated from the Eastern Han Dynasty and were first mainly used for lighting.",
        "points": [
          "originate from 起源于",
          "be used for doing 用于"
        ]
      },
      {
        "cn": "在唐代，人们用红灯笼来庆祝安定的生活。从那时起，灯笼在中国的许多地方流行起来。",
        "ref": "In the Tang Dynasty, people used red lanterns to celebrate a peaceful life. Since then, lanterns have gained popularity in many parts of China.",
        "points": [
          "use sth. to do 结构",
          "since then 配现在完成时"
        ]
      },
      {
        "cn": "灯笼通常用色彩鲜艳的薄纸制作，形状和尺寸各异。",
        "ref": "Lanterns are usually made of thin paper of bright colors in different shapes and sizes.",
        "points": [
          "be made of 由……制成",
          "in different shapes and sizes 并列"
        ]
      },
      {
        "cn": "在中国传统文化中，红灯笼象征生活美满和生意兴隆，通常在春节、元宵节和国庆节等节日期间悬挂。",
        "ref": "In traditional Chinese culture, red lanterns symbolize a happy life and booming business, and are usually hung during festivals such as the Spring Festival, the Lantern Festival and the National Day.",
        "points": [
          "symbolize + 名词",
          "such as 举例节日"
        ]
      },
      {
        "cn": "如今，世界上许多其他地方也能看到红灯笼。",
        "ref": "Nowadays, red lanterns can be seen in many other places in the world.",
        "points": [
          "can be seen 被动语态",
          "in many other places 状语位置"
        ]
      }
    ],
    "reference": "Lanterns originated from the Eastern Han Dynasty and were first mainly used for lighting. In the Tang Dynasty, people used red lanterns to celebrate a peaceful life. Since then, lanterns have gained popularity in many parts of China. Lanterns are usually made of thin paper of bright colors in different shapes and sizes. In traditional Chinese culture, red lanterns symbolize a happy life and booming business, and are usually hung during festivals such as the Spring Festival, the Lantern Festival and the National Day. Nowadays, red lanterns can be seen in many other places in the world.",
    "keyWords": [
      {
        "w": "lantern",
        "cn": "灯笼"
      },
      {
        "w": "the Eastern Han Dynasty",
        "cn": "东汉"
      },
      {
        "w": "lighting",
        "cn": "照明"
      },
      {
        "w": "symbolize",
        "cn": "象征"
      },
      {
        "w": "booming business",
        "cn": "生意兴隆"
      },
      {
        "w": "the Lantern Festival",
        "cn": "元宵节"
      },
      {
        "w": "hang",
        "cn": "悬挂"
      }
    ],
    "scoring": [
      "朝代与节日专名译准",
      "被动语态（are made of / be seen）正确",
      "象征意义的抽象词（美满 / 兴隆）译出"
    ],
    "pitfalls": [
      "把「东汉」译成 East Han（应为 Eastern Han）",
      "「形状和尺寸各异」漏译",
      "「悬挂」误用 hang 的时态形式（应为 hung）"
    ]
  },
  {
    "id": "cet4-2020-12-reunion-dinner",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://m.koolearn.com/news/20201212/1220492.html",
    "verified": true,
    "topic": "传统文化",
    "title": "春节团圆饭",
    "source_text": "春节前夕吃团圆饭是中国人的传统。团圆饭是一年中最重要的晚餐，也是家庭团聚的最佳时机，家人生活在不同地方的家庭尤其如此。团圆饭上的菜肴丰富多样，其中有些菜肴有特殊含义。例如，鱼是不可缺少的一道菜，因为汉语中的“鱼”字和“余”字听上一样。在中国的许多地方，饺子也是一道重要的佳肴，因为饺子象征着财富和好运。",
    "sentences": [
      {
        "cn": "春节前夕吃团圆饭是中国人的传统。",
        "ref": "It is a tradition for Chinese to have the family reunion meal on the Spring Festival Eve.",
        "points": [
          "it 作形式主语的句型",
          "on the Spring Festival Eve 时间状语"
        ]
      },
      {
        "cn": "团圆饭是一年中最重要的晚餐，也是家庭团聚的最佳时机，家人生活在不同地方的家庭尤其如此。",
        "ref": "The family reunion meal is not only the most important dinner in a year but also the best opportunity for family reunion, especially for those families whose members live in different places.",
        "points": [
          "not only ... but also ... 并列表语",
          "whose 引导定语从句"
        ]
      },
      {
        "cn": "团圆饭上的菜肴丰富多样，其中有些菜肴有特殊含义。",
        "ref": "The family reunion dinner consists of a great variety of dishes, some of which carry special meanings.",
        "points": [
          "consist of 由……组成",
          "some of which 非限制性定语从句"
        ]
      },
      {
        "cn": "例如，鱼是不可缺少的一道菜，因为汉语中的“鱼”字和“余”字听上一样。",
        "ref": "For example, fish is indispensable as fish sounds like surplus or abundant in Chinese.",
        "points": [
          "be indispensable 不可缺少",
          "sound like 听起来像"
        ]
      },
      {
        "cn": "在中国的许多地方，饺子也是一道重要的佳肴，因为饺子象征着财富和好运。",
        "ref": "In many areas of China, dumpling is also an important dish for it symbolizes wealth and fortune.",
        "points": [
          "for 引导原因并列句",
          "symbolize 象征"
        ]
      }
    ],
    "reference": "It is a tradition for Chinese to have the family reunion meal on the Spring Festival Eve. The family reunion meal is not only the most important dinner in a year but also the best opportunity for family reunion, especially for those families whose members live in different places. The family reunion dinner consists of a great variety of dishes, some of which carry special meanings. For example, fish is indispensable as fish sounds like surplus or abundant in Chinese. In many areas of China, dumpling is also an important dish for it symbolizes wealth and fortune.",
    "keyWords": [
      {
        "w": "the family reunion meal",
        "cn": "团圆饭"
      },
      {
        "w": "tradition",
        "cn": "传统"
      },
      {
        "w": "a great variety of",
        "cn": "丰富多样的"
      },
      {
        "w": "indispensable",
        "cn": "不可缺少的"
      },
      {
        "w": "surplus",
        "cn": "余（盈余）"
      },
      {
        "w": "dumpling",
        "cn": "饺子"
      },
      {
        "w": "fortune",
        "cn": "好运"
      }
    ],
    "scoring": [
      "形式主语与定语从句结构正确",
      "「鱼 / 余」谐音的象征意义译出",
      "菜肴与寓意词（财富 / 好运）准确"
    ],
    "pitfalls": [
      "把「春节前夕」译成 before the Spring Festival（与 on the Eve 不同）",
      "consist of 误写成 consist in",
      "漏译「尤其如此」的逻辑强调"
    ]
  },
  {
    "id": "cet4-2020-12-fish-thrift",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://m.koolearn.com/news/20201212/1220492.html",
    "verified": true,
    "topic": "传统文化",
    "title": "鱼与节俭美德",
    "source_text": "鱼是春节前夕餐桌上不可或缺的一道菜，因为汉语中“鱼”字的发音与“余”字的发音相同。正由于这个象征性的意义，春节期间鱼也作为礼物送给亲戚朋友。鱼的象征意义据说源于中国传统文化。中国人有节省的传统，他们认为节省得愈多，就感到愈为安全。今天，尽管人们愈来愈富裕了，但他们仍然认为节省是一种值得弘扬的美德。",
    "sentences": [
      {
        "cn": "鱼是春节前夕餐桌上不可或缺的一道菜，因为汉语中“鱼”字的发音与“余”字的发音相同。",
        "ref": "Fish is an indispensable dish on the dinner table on the Spring Festival Eve because fish sounds the same as surplus in Chinese.",
        "points": [
          "indispensable 不可或缺",
          "because 引导原因状语从句"
        ]
      },
      {
        "cn": "正由于这个象征性的意义，春节期间鱼也作为礼物送给亲戚朋友。",
        "ref": "It is for this symbolic meaning that fish is given as a gift to friends and relatives during the Spring Festival.",
        "points": [
          "it is ... that 强调句",
          "be given as a gift 作礼物送出"
        ]
      },
      {
        "cn": "鱼的象征意义据说源于中国传统文化。",
        "ref": "It is said that this symbolic meaning of fish originated from traditional Chinese culture.",
        "points": [
          "it is said that 句型",
          "originate from 起源于"
        ]
      },
      {
        "cn": "中国人有节省的传统，他们认为节省得愈多，就感到愈为安全。",
        "ref": "The Chinese people have the tradition of thrift. They believe that the more they save, the safer they feel.",
        "points": [
          "the more ... the more ... 比较级句型",
          "thrift 节俭"
        ]
      },
      {
        "cn": "今天，尽管人们愈来愈富裕了，但他们仍然认为节省是一种值得弘扬的美德。",
        "ref": "Today, although people are becoming richer and richer, they still regard thrift as a praiseworthy virtue.",
        "points": [
          "although 让步状语从句",
          "regard A as B 结构"
        ]
      }
    ],
    "reference": "Fish is an indispensable dish on the dinner table on the Spring Festival Eve because fish sounds the same as surplus in Chinese. It is for this symbolic meaning that fish is given as a gift to friends and relatives during the Spring Festival. It is said that this symbolic meaning of fish originated from traditional Chinese culture. The Chinese people have the tradition of thrift. They believe that the more they save, the safer they feel. Today, although people are becoming richer and richer, they still regard thrift as a praiseworthy virtue.",
    "keyWords": [
      {
        "w": "indispensable",
        "cn": "不可或缺的"
      },
      {
        "w": "symbolic",
        "cn": "象征性的"
      },
      {
        "w": "relative",
        "cn": "亲戚"
      },
      {
        "w": "thrift",
        "cn": "节俭"
      },
      {
        "w": "praiseworthy",
        "cn": "值得赞扬 / 弘扬的"
      },
      {
        "w": "virtue",
        "cn": "美德"
      },
      {
        "w": "originate from",
        "cn": "源于"
      }
    ],
    "scoring": [
      "强调句 it is ... that 结构正确",
      "the more ... the more ... 句型完整",
      "「美德 / 节俭」抽象词译准"
    ],
    "pitfalls": [
      "把「鱼 / 余」谐音关系漏译成 sounds same 而无对象",
      "regard ... as 误用 regard ... to be",
      "「值得弘扬」漏译 praiseworthy 的含义"
    ]
  },
  {
    "id": "cet4-2020-12-diet",
    "level": "cet4",
    "year": "2020年12月",
    "source": "https://m.koolearn.com/news/20201212/1220492.html",
    "verified": true,
    "topic": "社会生活",
    "title": "中国饮食的地区差异",
    "source_text": "生活在中国不同地区的人们饮食多种多样。北方人主要吃面食，南方人大多吃米饭。在沿海地区，海鲜和淡水水产品在人们饮食中占有相当大的比例，而在其他地区人们的饮食中，肉类和奶制品更为常见。四川、湖南等省份的居民普遍爱吃辛辣食物，而江苏和浙江人更喜欢甜食。然而，因为烹饪方式各异，同类食物的味道可能会有所不同。",
    "sentences": [
      {
        "cn": "生活在中国不同地区的人们饮食多种多样。",
        "ref": "People who live in different areas of China have different kinds of food.",
        "points": [
          "who 定语从句修饰 people",
          "different kinds of 多种多样"
        ]
      },
      {
        "cn": "北方人主要吃面食，南方人大多吃米饭。",
        "ref": "Those in the north mainly prefer food made of flour while those in the south mostly eat rice.",
        "points": [
          "those in the north 指代人群",
          "while 表对比"
        ]
      },
      {
        "cn": "在沿海地区，海鲜和淡水水产品在人们饮食中占有相当大的比例，而在其他地区人们的饮食中，肉类和奶制品更为常见。",
        "ref": "Along the coastal areas, sea food and fresh water products make up a considerable proportion of people's diet whereas in other places, meat and dairy products are more common.",
        "points": [
          "make up a proportion 占比例",
          "whereas 表对比"
        ]
      },
      {
        "cn": "四川、湖南等省份的居民普遍爱吃辛辣食物，而江苏和浙江人更喜欢甜食。",
        "ref": "The residents in Sichuan, Hunan and other provinces favour spicy food, but the citizens in Jiangsu and Zhejiang are fond of sweet food.",
        "points": [
          "favour / be fond of 表示偏爱",
          "but 表对比"
        ]
      },
      {
        "cn": "然而，因为烹饪方式各异，同类食物的味道可能会有所不同。",
        "ref": "However, owing to various cooking methods, the same food might taste different.",
        "points": [
          "owing to 由于",
          "might + 动词原形表可能"
        ]
      }
    ],
    "reference": "People who live in different areas of China have different kinds of food. Those in the north mainly prefer food made of flour while those in the south mostly eat rice. Along the coastal areas, sea food and fresh water products make up a considerable proportion of people's diet whereas in other places, meat and dairy products are more common. The residents in Sichuan, Hunan and other provinces favour spicy food, but the citizens in Jiangsu and Zhejiang are fond of sweet food. However, owing to various cooking methods, the same food might taste different.",
    "keyWords": [
      {
        "w": "flour",
        "cn": "面食（面粉）"
      },
      {
        "w": "coastal area",
        "cn": "沿海地区"
      },
      {
        "w": "make up",
        "cn": "占（比例）"
      },
      {
        "w": "proportion",
        "cn": "比例"
      },
      {
        "w": "dairy product",
        "cn": "奶制品"
      },
      {
        "w": "spicy food",
        "cn": "辛辣食物"
      },
      {
        "w": "cooking method",
        "cn": "烹饪方式"
      }
    ],
    "scoring": [
      "南北对比结构（while / whereas / but）交替使用",
      "「占比例」的地道表达准确",
      "地区与食物术语译准"
    ],
    "pitfalls": [
      "把「面食」译成 noodles only",
      "「淡水水产品」漏译 fresh water",
      "对比连词重复使用同一词导致语言单调"
    ]
  },
  {
    "id": "cet4-2022-06-sheepfold",
    "level": "cet4",
    "year": "2022年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202206/11919676.html",
    "verified": true,
    "topic": "寓言故事",
    "title": "亡羊补牢",
    "source_text": "从前有个人养了一群羊，一天早上他准备出去放羊，发现少了一只。他仔细一看，看到羊栏(sheepfold)上有个窟窿。显然夜间有狼钻进羊圈叼走了羊。邻居劝他修羊栏，可是他不听。第二天他发现狼又通过窟窿叼走一只羊。他想起邻居的话，就赶快堵上窟窿，把羊栏补好。此后，他的羊再也没有被叼走。故事告诉我们：出了问题及时补救，可以防止蒙受更大损失。",
    "sentences": [
      {
        "cn": "从前有个人养了一群羊，一天早上他准备出去放羊，发现少了一只。",
        "ref": "Once upon a time, a man, who kept a flock of sheep, was ready to herd them when he noticed one of them was gone.",
        "points": [
          "once upon a time 讲述故事开头",
          "be ready to do 准备做"
        ]
      },
      {
        "cn": "他仔细一看，看到羊栏(sheepfold)上有个窟窿。显然夜间有狼钻进羊圈叼走了羊。",
        "ref": "Observing carefully, he saw a hole in the sheepfold. Obviously, a wolf must have got in and taken the sheep away.",
        "points": [
          "现在分词作状语",
          "must have done 表对过去的推测"
        ]
      },
      {
        "cn": "邻居劝他修羊栏，可是他不听。",
        "ref": "His neighbour advised him to fix the sheepfold, but he would not listen.",
        "points": [
          "advise sb. to do 结构",
          "would not 表过去不愿"
        ]
      },
      {
        "cn": "第二天他发现狼又通过窟窿叼走一只羊。",
        "ref": "The next day he found that another sheep had been carried away by the wolf through the hole.",
        "points": [
          "find that 宾语从句",
          "过去完成时的被动 had been carried away"
        ]
      },
      {
        "cn": "他想起邻居的话，就赶快堵上窟窿，把羊栏补好。",
        "ref": "Remembering his neighbour's words, he hurried to repair the sheepfold by plugging the hole.",
        "points": [
          "现在分词作时间状语",
          "by doing 表方式"
        ]
      },
      {
        "cn": "此后，他的羊再也没有被叼走。故事告诉我们：出了问题及时补救，可以防止蒙受更大损失。",
        "ref": "Since then, no sheep was ever taken away again. The story tells us that if we solve the problem in time, we can prevent ourselves from suffering a bigger loss.",
        "points": [
          "no + 名词 + 肯定式谓语表否定",
          "prevent sb. from doing 结构"
        ]
      }
    ],
    "reference": "Once upon a time, a man, who kept a flock of sheep, was ready to herd them when he noticed one of them was gone. Observing carefully, he saw a hole in the sheepfold. Obviously, a wolf must have got in and taken the sheep away. His neighbour advised him to fix the sheepfold, but he would not listen. The next day he found that another sheep had been carried away by the wolf through the hole. Remembering his neighbour's words, he hurried to repair the sheepfold by plugging the hole. Since then, no sheep was ever taken away again. The story tells us that if we solve the problem in time, we can prevent ourselves from suffering a bigger loss.",
    "keyWords": [
      {
        "w": "a flock of sheep",
        "cn": "一群羊"
      },
      {
        "w": "herd",
        "cn": "放牧"
      },
      {
        "w": "sheepfold",
        "cn": "羊栏"
      },
      {
        "w": "must have done",
        "cn": "一定做过（推测）"
      },
      {
        "w": "plug the hole",
        "cn": "堵住窟窿"
      },
      {
        "w": "in time",
        "cn": "及时"
      },
      {
        "w": "prevent ... from ...",
        "cn": "防止……做……"
      }
    ],
    "scoring": [
      "故事叙述的时态统一（过去时 + 过去完成时）",
      "推测与被动结构正确",
      "寓意句（tell us that ...）译出"
    ],
    "pitfalls": [
      "把「他不听」译成 he didn't listen to（缺宾语）",
      "must have done 误写成 must done",
      "「蒙受更大损失」漏译 bigger loss"
    ]
  },
  {
    "id": "cet4-2023-06-lifelong-education",
    "level": "cet4",
    "year": "2023年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202306/13359970.html",
    "verified": true,
    "topic": "社会与教育",
    "title": "终身教育与继续教育",
    "source_text": "中国政府越来越重视终身教育，发展继续教育是构建终身教育的有效途径。高校作为人才培养的基地，拥有先进理念和丰富教学资源，理应成为继续教育的培养主体。近年来，许多高校努力适应社会需求，与用人单位沟通，探索出一条适应中国国情的继续教育新路。以使继续教育在国家战略中发挥更重大的作用。",
    "sentences": [
      {
        "cn": "中国政府越来越重视终身教育，发展继续教育是构建终身教育的有效途径。",
        "ref": "The Chinese government attaches progressively more importance to life-long education. Developing continuing education is an effective way to build life-long education.",
        "points": [
          "attach importance to 重视",
          "动名词作主语 + an effective way to do"
        ]
      },
      {
        "cn": "高校作为人才培养的基地，拥有先进理念和丰富教学资源，理应成为继续教育的培养主体。",
        "ref": "As the basis of talent cultivation, colleges and universities, with advanced ideas and abundant teaching resources, should be regarded as the main body of continuing education.",
        "points": [
          "as 引导状语表身份",
          "with 复合结构补充说明"
        ]
      },
      {
        "cn": "近年来，许多高校努力适应社会需求，与用人单位沟通，探索出一条适应中国国情的继续教育新路。",
        "ref": "In recent years, by meeting social needs and communicating with employers, many colleges and universities have found a new developmental way of continuing education that is suitable to China's national conditions.",
        "points": [
          "by doing 表方式",
          "that 定语从句修饰 way"
        ]
      },
      {
        "cn": "以使继续教育在国家战略中发挥更重大的作用。",
        "ref": "This is so as to ensure continuing education a greater role in the national strategy.",
        "points": [
          "so as to 表目的",
          "play a role 可省略为 ensure sb. a role"
        ]
      }
    ],
    "reference": "The Chinese government attaches progressively more importance to life-long education. Developing continuing education is an effective way to build life-long education. As the basis of talent cultivation, colleges and universities, with advanced ideas and abundant teaching resources, should be regarded as the main body of continuing education. In recent years, by meeting social needs and communicating with employers, many colleges and universities have found a new developmental way of continuing education that is suitable to China's national conditions. This is so as to ensure continuing education a greater role in the national strategy.",
    "keyWords": [
      {
        "w": "life-long education",
        "cn": "终身教育"
      },
      {
        "w": "continuing education",
        "cn": "继续教育"
      },
      {
        "w": "attach importance to",
        "cn": "重视"
      },
      {
        "w": "talent cultivation",
        "cn": "人才培养"
      },
      {
        "w": "teaching resources",
        "cn": "教学资源"
      },
      {
        "w": "employer",
        "cn": "用人单位"
      },
      {
        "w": "national conditions",
        "cn": "国情"
      }
    ],
    "scoring": [
      "attach importance to 搭配正确",
      "动名词与定语从句使用得当",
      "「终身教育 / 继续教育」术语译法统一"
    ],
    "pitfalls": [
      "importance 后误接 do 而非 to + 名词 / 动名词",
      "「用人单位」误译成 using company",
      "「发挥更重大的作用」结构残缺"
    ]
  },
  {
    "id": "cet4-2023-06-compulsory-education",
    "level": "cet4",
    "year": "2023年6月",
    "source": "https://mtoutiao.xdf.cn/cet4-6/202306/13360026.html",
    "verified": true,
    "topic": "社会与教育",
    "title": "中国义务教育",
    "source_text": "中国政府一直重视义务教育，使每个儿童都有受教育的机会。自1986年《义务教育法》生效以来，经过不懈努力，实现了全民义务教育的目标。如今，在中国，儿童从6岁开始上小学，从小学到初中接受九年义务教育。自2008年秋季开始，义务教育阶段无需缴纳学费。随着一系列教育改革的实施，中国义务教育质量显著提高。",
    "sentences": [
      {
        "cn": "中国政府一直重视义务教育，使每个儿童都有受教育的机会。",
        "ref": "The Chinese government has been emphasizing compulsory education all the time, making it available to each and every child.",
        "points": [
          "现在完成进行时表持续",
          "make sth. available to sb. 使可获得"
        ]
      },
      {
        "cn": "自1986年《义务教育法》生效以来，经过不懈努力，实现了全民义务教育的目标。",
        "ref": "Since the Law of Compulsory Education came into force in 1986, the authorities have made relentless efforts to achieve the goal of compulsory education for all.",
        "points": [
          "since 引导从句配现在完成时",
          "make efforts to do 努力做"
        ]
      },
      {
        "cn": "如今，在中国，儿童从6岁开始上小学，从小学到初中接受九年义务教育。",
        "ref": "Nowadays, children in China start school at 6 and receive 9-year compulsory education from the primary school to the junior middle school.",
        "points": [
          "9-year 作前置定语不加复数",
          "from ... to ... 范围表达"
        ]
      },
      {
        "cn": "自2008年秋季开始，义务教育阶段无需缴纳学费。",
        "ref": "In the autumn of 2008, free compulsory education took effect.",
        "points": [
          "take effect 生效 / 开始实施",
          "时间的准确表达"
        ]
      },
      {
        "cn": "随着一系列教育改革的实施，中国义务教育质量显著提高。",
        "ref": "With the implementation of a series of educational reforms, the quality of China's compulsory education has been considerably improved.",
        "points": [
          "with the implementation of 随着……实施",
          "现在完成时的被动"
        ]
      }
    ],
    "reference": "The Chinese government has been emphasizing compulsory education all the time, making it available to each and every child. Since the Law of Compulsory Education came into force in 1986, the authorities have made relentless efforts to achieve the goal of compulsory education for all. Nowadays, children in China start school at 6 and receive 9-year compulsory education from the primary school to the junior middle school. In the autumn of 2008, free compulsory education took effect. With the implementation of a series of educational reforms, the quality of China's compulsory education has been considerably improved.",
    "keyWords": [
      {
        "w": "compulsory education",
        "cn": "义务教育"
      },
      {
        "w": "come into force",
        "cn": "生效"
      },
      {
        "w": "relentless",
        "cn": "不懈的"
      },
      {
        "w": "junior middle school",
        "cn": "初中"
      },
      {
        "w": "take effect",
        "cn": "开始实施"
      },
      {
        "w": "implementation",
        "cn": "实施"
      },
      {
        "w": "considerably",
        "cn": "显著地"
      }
    ],
    "scoring": [
      "since 与现在完成时搭配",
      "数字与学制表达（9-year）正确",
      "法律与政策名称译准"
    ],
    "pitfalls": [
      "把「9年」写成 9 years 作前置定语（多余复数）",
      "「生效」误用 take affect（拼写）",
      "漏译「一系列」的 a series of"
    ]
  }
];
