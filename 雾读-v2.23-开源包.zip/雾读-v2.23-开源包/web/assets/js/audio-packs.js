/* 雾读 · 音频分包清单（清单 P0-5）
   ------------------------------------------------------------
   网页端（整个工程目录都在）四个包全有；APK 里只带小包，例句包按需不带 ——
   这份文件由 android-app/sync-www.ps1 在打包时重新生成，覆盖成实际带走的包。
   app.js 读它决定「本地音源到底有没有」：没有就直接走系统 TTS，
   不让每次播放都去撞一次 404（那样例句听写会一顿一顿的）。
   字段：words 单词 / listen 听力 / uk 英音 / lines 例句（约 127 MB，不进 APK） */
window.WUDU_AUDIO_PACKS = { words: true, listen: true, uk: true, lines: true, at: 'source' };
